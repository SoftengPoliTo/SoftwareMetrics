#=================================================
#
#   bgnotifier.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::bgnotifier;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
BGNOTIFIER_submit
BGNOTIFIER_start
BGNOTIFIER_end
);
}




use glo::env;
use mod::gbscmd;




sub BGNOTIFIER_submit($$@);
sub BGNOTIFIER_start($$$$$);
sub BGNOTIFIER_end($$);

sub execute($$);




my $JOBNAME;
my $DATE_TIME;
my $BUILD;
my $ACTION;
my $LOGFILE;




sub BGNOTIFIER_submit($$@)
{
my ($jobname,
$datetime,
@build_action_refs
) = @_;

my $notifier_cmd = GBSCMD_bg_notifier();
if ($notifier_cmd)
{
my $nr_jobs = @build_action_refs;
my @build_actions = map { @{$_} } @build_action_refs;
my $data = "submit $jobname $datetime $nr_jobs @build_actions";
execute( $notifier_cmd, $data);
}
}




sub BGNOTIFIER_start($$$$$)
{
(	$JOBNAME,
$DATE_TIME,
$BUILD,
$ACTION,
$LOGFILE,
) = @_;


my $notifier_cmd = GBSCMD_bg_notifier();
if ($notifier_cmd)
{
my $data = "start $JOBNAME $DATE_TIME $$ $BUILD $ACTION $LOGFILE";
execute( $notifier_cmd, $data);
}
}




sub BGNOTIFIER_end($$)
{
my ($state,	    # NORMAL, FAILED, KILLED
$rc,
) = @_;


my $notifier_cmd = GBSCMD_bg_notifier();
if ($notifier_cmd)
{
my $data = "end $JOBNAME $DATE_TIME $$ $BUILD $ACTION $LOGFILE $state $rc";
execute( $notifier_cmd, $data);
}
}




sub execute($$)
{
my ($notifier_cmd,
$data,
) = @_;

ENV_say( 1, "Executing '$notifier_cmd' with:",
$data);
ENV_system( "$notifier_cmd $data", 0);
}

1;

