#=================================================
#
#   gbsswa.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSSWA @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::ask;
use glo::genopt;
use mod::gbsenv;
use mod::gbscmd;
use mod::gbsask;
use mod::run;
use mod::validate;
use mod::swset;








my $CANCELLED = 0;






$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( 'audit');













{
my @genopts = (
[ '<1>',    'audit',		'sso',  '', "Audit: '' == ASK, '-' == none, '.' == current" ],
[ 'new',    'create_new_audit', 'bso',   0, "Create a new Audit" ],
[ 'remove', 'remove_audit',     'bso',   0, "Remove a Audit from the Audits List" ],
);
my @genconflicts = (
[ [ new => 1 ], [ '=' => remove => 1] ],
);
GENOPT_set_optdefs( [ 'gbsswa', 'swa' ], \@genopts,
'Set and/or Create new Current Audit',
undef);
GENOPT_set_conflicts( \@genconflicts);
GENOPT_parse();
}
my $AUDIT = GENOPT_get( 'audit');
my $NEW = GENOPT_get( 'create_new_audit');
my $REMOVE = GENOPT_get( 'remove_audit');




VALIDATE_root();




if (!$NEW && @GBS::AUDITS == 0)
{
if (ASK_YN( "No Audit(s) defined. Define now?", 'Y') eq 'Y')
{
$NEW = 1;
}
}




if ($NEW)
{
$AUDIT = RUN_gbsnew( 'new_audit', $AUDIT);
if ($AUDIT eq '')
{
$AUDIT = '.';
$CANCELLED = 1;
} else
{
ENV_say( 1, "Current Audit is $AUDIT");
}
} elsif ($REMOVE)
{
my $removed_audit = RUN_gbsnew( 'rem_audit', $AUDIT);
if ($GBS::AUDIT eq $removed_audit)
{
ENV_say( 1, "Current Audit removed");
$AUDIT = '';	# No current
} else
{
ENV_say( 1, "Current Audit is $GBS::AUDIT");
$AUDIT = '.';	# Keep current
}
}

if (!$CANCELLED)
{



if ($AUDIT eq '')
{
$AUDIT = GBSASK_audit();
$AUDIT = '-'
if ($AUDIT eq '');
}
SWSET_audit( $AUDIT);








{
my @lines;
if (ENV_get_changed_envs())
{
push @lines, GBSENV_changed_setenv_commands( 0);
}
push @lines, GBSCMD_get_full_gbs_command( gbsshow => '--brief');

GBSENV_write_result_script( \@lines, 0);
}
}

ENV_exit( $RC);




END
{
ENV_print_end_msg( 0);
}


