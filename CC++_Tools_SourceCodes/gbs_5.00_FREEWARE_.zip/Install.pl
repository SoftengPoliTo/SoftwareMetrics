#=================================================
#
#   Install.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*INSTALL @ARGV") if ($ENV{GBSDEBUG_FILE});




use 5.016_003;
use strict;
use integer;

BEGIN
{



my $gbs_scripts_path = $ENV{GBS_SCRIPTS_PATH};
die( "INSTALL: *** FAIL: EnvVar GBS_SCRIPTS_PATH is not defined\n")
if (!$gbs_scripts_path);
}

use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::genopt;
use glo::file;
use glo::ask;
use glo::format;
use glo::version;
use mod::gbsenv;
use mod::profile;
use mod::setupglo;
use mod::settings;
use mod::bootstrap;




sub initialize();
sub selection_dialogue();
sub check_root_path($$$);
sub expand_and_show_selection();
sub clone_tree($$);
sub set_permissions($$$$);
sub read_profile_file();
sub write_profile_file();




my $IS_WIN32 = ENV_is_win32();
my $IS_ADMINISTRATOR = ENV_is_administrator();

my $CWD = ENV_cwd();


my $FROM_PATH;
my $VERSION_DIR;	# version (e.g.: 2.02) or 'beta'
my $VERSION;		# e.g. 2.02
my $BUILD;		# e.g. 2008-01-29
my $IS_BETA;
my $UNZIP_DIR;
my $IS_DEVELOPER_MODE = 0;
my $BATCH_DELETED = 0;

my $INSTALL_ROOT_PATH = '';	    # GBS_SCRIPTS_PATH

my $TO_PATH = '';	    # GBS_SCRIPTS_PATH
my $TOP_DIR;		    # version or 'beta'	Equal to $VERSION_DIR
my $TOP_BUILD_PATH;	    # "$TOP_DIR_$BUILD"

my $MUST_INSTALL_BUILD = 'Y';	    # (Y/N)
my $MUST_MAKE_REL_CURRENT = 'Y';    # (Y/N)

my @INSTALL_REFS;





























$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ 'q',     'quiet_mode', 'bso', 0,  "Run in Quiet-Mode (No prompts)" ],
[ 'site',  'site',       'sso', '', "Default for Site" ],
);
GENOPT_set_optdefs( 'Install', \@genopts,
"Install GBS.",
undef);
GENOPT_parse();
}
my $QUIET_MODE = GENOPT_get( 'quiet_mode');
my $SITE = GENOPT_get( 'site');

my $QUIETLY = $QUIET_MODE;




{



ENV_say( 1, "Running in --q (quiet) mode")
if ($QUIET_MODE);
if ($IS_ADMINISTRATOR)
{
ENV_say( 1, "Running as System Administrator");
} else
{
ENV_say( 1, "Running as User");
}
ENV_say( 2, "From $CWD");




BOOTSTRAP_install();    # Sets GBS::BASE_PATH




initialize();

ENV_say( 0, '');
ENV_say( 1, "This program will install GBS",
"Version $VERSION ($TOP_DIR), Build $BUILD.");
ENV_exit(0)
if (!$QUIETLY && ASK_YNQ( 'Continue?', 'Y', 1) eq 'N');

if ($IS_BETA)
{
$MUST_INSTALL_BUILD = 'N';
$MUST_MAKE_REL_CURRENT = 'N';
}




read_profile_file();

if ($INSTALL_ROOT_PATH ne '')
{
ENV_say( 1, "GBS has been installed before by this user",
"Path         = $INSTALL_ROOT_PATH",
"Site-Id      = '$SITE'",
"Make Current = '$MUST_MAKE_REL_CURRENT'");

$QUIETLY = 1
if ( !$QUIETLY && ASK_YNQ( "Run Quietly? (Accept all defaults)", 'Y', 1) eq 'Y');
}




if (!$QUIETLY)
{
if (-f "$CWD/Readme.txt")
{
ENV_say( 1, "Readme.txt file present");
my $default_ans = ($INSTALL_ROOT_PATH eq '') ? 'Y' : 'N';
if (ASK_YNQ( "Display the file?", $default_ans, 1) eq 'Y')
{
my $command = 'more Readme.txt';	# Same on Win32 & Lunix
ENV_system( $command, 0);
}
}
}




if ($QUIETLY)
{
ENV_sig( EE => 'Information missing (INSTALL_ROOT). Cannot run in quiet mode')
if ($INSTALL_ROOT_PATH eq '');
$TO_PATH = $INSTALL_ROOT_PATH;
@INSTALL_REFS = ( [ $TOP_BUILD_PATH ], [ $TOP_DIR ] );
$MUST_MAKE_REL_CURRENT = 'N'
if ($QUIET_MODE);
expand_and_show_selection();
} else
{
do
{
ENV_say( 0, '');
selection_dialogue();
expand_and_show_selection();
} while (ASK_YNQ( 'Ok?', 'Y', 1) eq 'N');
}

if (@INSTALL_REFS)
{



my $last_gbs_rel;
foreach my $ref (@INSTALL_REFS)
{
my ($top_dir, $spec, $exists, $type) = @{$ref};
$type = ($type eq 'S') ? 'Specific' : 'Current';
ENV_say( 0, '');
ENV_say( 1, "Installing $type Build ($top_dir)...");

clone_tree( $FROM_PATH, $spec);
$last_gbs_rel = $top_dir;
}




if (-f "$CWD/Readme.txt")
{
FILE_replicate( "$CWD/Readme.txt", "$TO_PATH/Readme.txt");
}




SETTINGS_set_check( $TO_PATH, $last_gbs_rel);
if ($MUST_MAKE_REL_CURRENT eq 'Y')
{
PROFILE_set( GBS_SCRIPTS_REL => $last_gbs_rel);
write_profile_file();
} else
{
write_profile_file();
}
} else
{
ENV_say( 1, "Nothing to Install!");
}




if ($UNZIP_DIR ne '')
{
ENV_say( 0, '');
ENV_say( 1, "Unzip Dir: $UNZIP_DIR");
if ($QUIETLY || ASK_YNQ( 'Cleanup (delete the whole unzip tree)?', 'Y', 1) eq 'Y')
{
ENV_say( 1, "Deleting $UNZIP_DIR...");
FILE_del_tree( W => $UNZIP_DIR, undef, 0);
$BATCH_DELETED = 1;
}
}
}




ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
if ($IS_WIN32)
{
ENV_say( 2, "Ignore possible 'The batch file cannot be found' message")
if ($BATCH_DELETED);
if (! GENOPT_only_help_executed())
{
ASK_pause( undef);
sleep(1);
}
}
}




sub initialize()
{



$VERSION_DIR = VERSION_get_version_dir();
$VERSION = VERSION_get_version();
$BUILD = VERSION_get_version_date();
$IS_BETA = ($VERSION_DIR eq 'beta') ? 1 : 0;


$FROM_PATH = $GBS::SCRIPTS_PATH;




$TOP_DIR = ENV_parent_dir( $FROM_PATH, -1);
$TOP_BUILD_PATH = "${TOP_DIR}_$BUILD";
if (-e "$GBS::SCRIPTS_PATH/Install")
{
ENV_say( 1, "Running in Developer Mode...");
$IS_DEVELOPER_MODE = 1;
$BUILD = '2008-01-01';
$UNZIP_DIR = '';
$MUST_MAKE_REL_CURRENT = 'N';
} else
{
ENV_sig( EE => "TOP_DIR ($TOP_DIR) not equal to VERSION_DIR ($VERSION_DIR)", 'Cannot continue')
if ($TOP_DIR ne $VERSION_DIR);
$UNZIP_DIR = ENV_parent_path( $FROM_PATH);
ENV_say( 1, "Unzip: $UNZIP_DIR");
}



}




sub selection_dialogue()
{



my $system_programs_is_writeable = 0;
{
my $system_programs_test_path = ENV_get_programs_path( 1) . 'gbs_test_' . ENV_unique_id();
mkdir $system_programs_test_path;
if (-d $system_programs_test_path)
{
$system_programs_is_writeable = 1
if (-r $system_programs_test_path);
}
rmdir $system_programs_test_path;
}




do
{



my $system_program_gbs_path = ENV_get_programs_path( 1) . '/RMC/GBS';	# 1 == System
my $user_program_gbs_path = ENV_get_programs_path( 0) . '/RMC/GBS';	# 0 == User
my @menu_refs;

push @menu_refs, [ '<Quit>', undef ];
push @menu_refs, [ "Current Location  ($INSTALL_ROOT_PATH)", $INSTALL_ROOT_PATH ]
if ($INSTALL_ROOT_PATH ne '');
push @menu_refs, [ "System Programs   ($system_program_gbs_path)", $system_program_gbs_path ]
if ($system_programs_is_writeable && $system_program_gbs_path ne $INSTALL_ROOT_PATH);
push @menu_refs, [ "User Programs     ($user_program_gbs_path)", $user_program_gbs_path ]
if ($user_program_gbs_path ne $INSTALL_ROOT_PATH);
push @menu_refs, [ 'Prompt me. I want to specify the Root Location', 'A' ];

my ($select_value) = ASK_value_from_menu( 'Select Install-Root Location:', 1 , undef, [ @menu_refs ]);
if ($select_value eq 'A')
{



if ($TO_PATH eq '')
{
ENV_say( 1, "Please enter your own Install-Root",
"Note: Install-Root must end with '/GBS'");
$TO_PATH = ASK_path( "Enter Install-Root:", '', -2, 0, [ \&check_root_path, undef ]); # 0 = may exist, -2 = min-length

}
} else
{
$TO_PATH = $select_value;
}

if (-d $TO_PATH)
{



my @root_files = VERSION_get_all_versions( $TO_PATH);
if (@root_files)
{
ENV_say( 1, "GBS versions already in Install-Root:");
ENV_say( 0, FORMAT_cols( 0, 2, ' ', 1, \@root_files ));
} else
{
ENV_say( 1, "Install-Root contains no GBS versions");
}
ENV_say( 0, '');
} else
{
if (ASK_YNQ( "Create Install-Root '$TO_PATH'?", 'Y', 1) eq 'Y')
{



ENV_mkpath( $TO_PATH);
} else
{
$TO_PATH = '';
ENV_say( 1, "- Oops. Try again...");
}
}
} while ($TO_PATH eq '');




@INSTALL_REFS = ();

push @INSTALL_REFS, [ $TOP_BUILD_PATH ]
if ($MUST_INSTALL_BUILD eq 'Y');
push @INSTALL_REFS, [ $TOP_DIR ];

$SITE = SETUPGLO_ask_site( $SITE);

if (@INSTALL_REFS && !$IS_BETA)
{
ENV_say( 0, '');
$MUST_MAKE_REL_CURRENT = ASK_YNQ( "Setup this Install (make this the Current GBS)?", $MUST_MAKE_REL_CURRENT, 1);
}
}





sub check_root_path($$$)
{
my ($values_ref,		# 1 value only
$default_ref,
$args_ref,		# undef
) = @_;
my $error_text = '';

my $install_path = $values_ref->[0];
if ($install_path ne '')
{
if ($install_path !~ m![\\/]GBS$!)
{
if ($install_path =~ m!([\\/]gbs)$!i)
{
$error_text = "The '$1'-part must be Uppercase";
$$default_ref = substr( $install_path, 0, -3) . 'GBS';
} else
{
$error_text = "Install-Root path must end with directory GBS";
$$default_ref = "$install_path/RMC/GBS";
}
}
}

return $error_text;
}




sub expand_and_show_selection()
{



my @show_refs = (undef, undef);	# 2 Entries!
foreach my $ref (@INSTALL_REFS)	# 0 - 2 Entries
{
my ($top_dir, $spec, $exists, $type) = @{$ref};
$spec = "$TO_PATH/$top_dir";
$ref->[1] = $spec;			    # $spec
$exists = -d $spec;
$ref->[2] = $exists;			    # $exists
$type = ($top_dir =~ /_/) ? 'S' : 'C';
$ref->[3] = $type;			    # $type
if ($type eq 'S')
{
$show_refs[0] = $ref;
} else
{
$show_refs[1] = $ref;
}
}




ENV_say( 0, '');
ENV_say( 1, '');
ENV_say( 0, "  Install-Root:     $TO_PATH");

my @names = ( 'Specific', ' Current');
foreach my $ref (@show_refs)    # 2 Entries
{
my $name = shift @names;
if (defined $ref)
{
my ($top_dir, $spec, $exists, $type) = @{$ref};
my $action = ($exists) ? 'overwrite' : 'new';
ENV_say( 0, "    As $name:    $top_dir ($action)");
} else
{
ENV_say( 0, "    As $name:    <None>");
}
}
ENV_say( 0, "  Must make this version Current = '$MUST_MAKE_REL_CURRENT'");
}




sub clone_tree($$)
{
my ($in_spec,
$out_spec,
) = @_;

ENV_say( 1, "In:  $in_spec",
"Out: $out_spec");

my ($dirs_created, $files_copied, $dirs_deleted, $files_deleted) =
FILE_replicate_tree( $in_spec, $out_spec, [ '^\.' ], 1);    # skip files starting with '.', Whisper Show dirs
FILE_parse_tree( $out_spec, \&set_permissions, undef, 0);

ENV_say( 1, "Directories/Files Created: $dirs_created/$files_copied");
ENV_say( 1, "Directories/Files Deleted: $dirs_deleted/$files_deleted");
}





sub set_permissions($$$$)
{
my ($level,
$is_dir,
$dir,
$file,
) = @_;
my $state = 0;			# 0 = continue, 1 = stop, 2 = stop this_dir (next)

my $filespec = "$dir/$file";
if ($is_dir)
{
chmod 0755, $filespec;		# ugo rwe: rwxr-xr-x
} else
{
if ($file =~ /.sh$/)
{

chmod 0555, $filespec;	# ugo rwe: r-xr-xr-x
} else
{
chmod 0444, $filespec;	# ugo rwe: r--r--r--
}
}

return $state;
}




sub read_profile_file()
{
my $exists = PROFILE_open( $GBS::BASE_PATH);

if ($exists)
{
$SITE = PROFILE_get( 'GBS_SITE')
if ($SITE eq '');

$INSTALL_ROOT_PATH = PROFILE_get( 'GBS_SCRIPTS_ROOT');
if ($IS_DEVELOPER_MODE)
{
ENV_say( 1, "Developer Mode:",
"Cur. Install: $INSTALL_ROOT_PATH");
$INSTALL_ROOT_PATH = ENV_get_programs_path( 0) . '/RMC/GBS';    # 0 == User
ENV_say( 2, "- Changed to: $INSTALL_ROOT_PATH");
ENV_mkpath( $INSTALL_ROOT_PATH)
if (!-e $INSTALL_ROOT_PATH);
}
if ($INSTALL_ROOT_PATH ne '' && ! -d $INSTALL_ROOT_PATH)
{
ENV_say( 1, "Install-Root '$INSTALL_ROOT_PATH' does not exist (anymore)",
"- Will have to specify");
$INSTALL_ROOT_PATH = '';
}
}
}




sub write_profile_file()
{
if ($IS_DEVELOPER_MODE)
{
ENV_say( 1, "Developer Mode: $GBS::BASE_PATH/profile NOT updated",
"GBS_SITE         => $SITE",
"GBS_SCRIPTS_ROOT => $TO_PATH");
} else
{
PROFILE_set( GBS_SITE => $SITE)
if ($SITE ne '');
PROFILE_set( GBS_SCRIPTS_ROOT => $TO_PATH);

ENV_say( 1, "$GBS::BASE_PATH/profile updated")
if (PROFILE_close( 1));	# 1 = Write file
}
}


