#=================================================
#
#   gbsedit.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbsedit;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSEDIT_edit_file
GBSEDIT_get_templates
GBSEDIT_create_file
);
}




use glo::env;
use glo::list;

use glo::ask;

use mod::gbsglo;
use mod::fcreate;
use mod::floc;
use glo::file;
use mod::run;

use mod::templates;
use mod::audit;
use mod::build;
use mod::tool;
use mod::flincs;
use mod::export;
use mod::owners;
use mod::sca;
use mod::scope;
use mod::ssprop;
use mod::steps;
use mod::pluginmaint;	# for switch.gbs
use mod::sys;
use mod::system;




sub GBSEDIT_edit_file($$$;$);
sub GBSEDIT_get_templates($$$);
sub GBSEDIT_create_file($$$$$);

sub get_gbs_gen_type($$);

sub post_abt($);
sub post_simple($;@);
sub post_export();
sub post_script();
sub post_plain($);
sub post_scope();
sub post_ssprop();
sub post_switch();




my $IS_GUI = ENV_is_gui();

my $FILE_SPEC;
my $FILE_PATH;
my $FILE_NAME;
my $FILE_TYPE;
my $FILE;		    # name + type

my $GENERIC_FILE_NAME;	    # audit, sysflags, sysincs, export, flags, gbsall, gbssub, incs, owners, makefile, etc
my $SUBSYS = '';
my $COMPONENT = '';
my $SUBDIR = '';
my $BUILD = '';
my $AUDIT = '';
my $TOOL  = '';
my $ABT_NAME = '';

my $EXTRA_DATA;








my %FILE_DEFS = (


audit   => [
sub { FCREATE_abt_file( $FILE, $GBS::ROOT_PATH, $ABT_NAME, $EXTRA_DATA) },
sub { post_abt( \&AUDIT_read) } ],
sysflags   => [
sub { FCREATE_sysflinc( $FILE, $GBS::ROOT_PATH, $BUILD) },
sub { post_simple( \&FLINCS_read_flags_file, 1) } ],
sysincs   => [
sub { FCREATE_sysflinc( $FILE, $GBS::ROOT_PATH, $BUILD) },
sub { post_simple( \&FLINCS_read_incs_file, 1) } ],
build  => [
sub { FCREATE_abt_file( $FILE, $GBS::ROOT_PATH, $ABT_NAME, $EXTRA_DATA) },
sub { post_abt( \&BUILD_read) } ],
comment_chars   => [
sub { FCREATE_comment_chars( $GBS::ROOT_PATH)},
undef ],
flags   => [
sub { FCREATE_flinc( $FILE, $GBS::ROOT_PATH, $SUBSYS, $COMPONENT, $BUILD) },
sub { post_simple( \&FLINCS_read_flags_file, 1) } ],
incs    => [
sub { FCREATE_flinc( $FILE, $GBS::ROOT_PATH, $SUBSYS, $COMPONENT, $BUILD) },
sub { post_simple( \&FLINCS_read_incs_file, 1) } ],
export  => [
sub { FCREATE_export( $FILE, $GBS::ROOT_PATH, $SUBSYS, $COMPONENT) },
\&post_export ],
gbsall  => [
sub { FCREATE_gbsall( $FILE, $EXTRA_DATA) },
\&post_script ],
gbssub  => [
sub { FCREATE_subsys_script( $FILE, $GBS::ROOT_PATH, $SUBSYS, $GBS::SSTYPE) },
undef ],
makefile  => [
sub { FCREATE_makefile( $GBS::ROOT_PATH, $SUBSYS) },
undef ],
owners  => [
sub { FCREATE_owners( $FILE, $GBS::ROOT_PATH) },
sub { post_plain( \&OWNERS_read) } ],
sca    => [
sub { FCREATE_sca( $FILE, $GBS::ROOT_PATH, $SUBSYS, $AUDIT, $BUILD) },
sub { post_simple( \&SCA_read) } ],
scope   => [
sub { FCREATE_scope( $FILE, $GBS::ROOT_PATH, $SUBSYS, $COMPONENT, undef) },
\&post_scope ],
ssprop  => [
sub { FCREATE_ssprop( $GBS::ROOT_PATH, $SUBSYS) },
\&post_ssprop ],
steps   => [
sub { FCREATE_steps( $FILE, $GBS::ROOT_PATH, $GBS::SYSTEM_NAME)},
sub { post_plain( \&STEPS_read) } ],
switch  => [
sub { FCREATE_switch( $FILE, $GBS::ROOT_PATH, $GBS::SYSTEM_NAME) },
\&post_switch ],
sys	    => [
sub { FCREATE_sys( $FILE, $GBS::ROOT_PATH, $GBS::SYSTEM_NAME) },
sub { post_plain( \&SYS_read) } ],
system  => [
sub { FCREATE_system( $FILE, $GBS::ROOT_PATH) },
sub { post_plain( \&SYSTEM_read) } ],
tool    => [
sub { FCREATE_abt_file( $FILE, $GBS::ROOT_PATH, $ABT_NAME, $EXTRA_DATA) },
sub { post_abt( \&TOOL_read) } ],
unkgbs  => [
undef,
undef ],
any  => [
sub { FCREATE_any( $FILE_SPEC, $EXTRA_DATA, [ $SUBSYS, $COMPONENT ]) },
undef ],
);

my %NON_GBS_PATH_ALLOWED = (
gbsall  => 1,
any	    => 1,
);





sub GBSEDIT_edit_file($$$;$)
{
my ($filespec,
$editor_opts,			# May be undef
$file_is_in_current_gbs_path,	# bool
$post_edit_func,		# Optional. $file_is_ok = $post_edit_func->()
) = @_;

$FILE_SPEC = $filespec;

if ($file_is_in_current_gbs_path && !defined $post_edit_func)
{
my $file = ENV_split_spec_f( $filespec);
my (undef, $generic_file_name, undef, undef, undef) = FLOC_analyse_name( $file);
(undef, $post_edit_func) = @{$FILE_DEFS{ $generic_file_name}};
}
ENV_say( 1, "Editing '$filespec'");
ENV_say( 2, 'Please keep the editor window open until after the file is checked')
if (defined $post_edit_func);

my $editor_started = RUN_editor( $filespec, $editor_opts);




if ($editor_started && defined $post_edit_func)
{
ASK_pause( "When done...")
if (!$IS_GUI);
my $again;
do
{
$again = 0;
ENV_say( 1, 'Checking the file...');
my $file_is_ok = $post_edit_func->();	    # Validate the file
if (!$file_is_ok)
{
ENV_say( 1, 'Error(s) found');
if ($IS_GUI)
{
ENV_sig( W => 'File is unstable!');
} else
{
if (ASK_YNQ( 'Fix and try again?', 'Y', 1) eq 'Y')
{
$again = 1;
} else
{
ENV_sig( W => 'File is unstable!');
}
}
}
} while ($again);
}
}




sub GBSEDIT_get_templates($$$)
{
my ($builds_ref,
$subdir,
$file_type,
) = @_;
my @template_spec_refs;


my @any_filetypes = ($file_type);
foreach my $build (@{$builds_ref})
{
if ($subdir eq 'src')
{
my $src_filetype = '.' . get_gbs_gen_type( $build, $file_type);
push @any_filetypes, $src_filetype
unless ($src_filetype eq $file_type);
} elsif ($subdir eq 'inc' || $subdir eq 'loc')
{



foreach my $src_type (BUILD_get_src_types( $build))
{
my @inc_types = BUILD_get_src_items( $build, $src_type, 'INC_TYPES');
if (grep $_ eq $file_type, @inc_types)
{
push @any_filetypes, $src_type;
my $src_filetype = '.' . get_gbs_gen_type( $build, $src_type);
push @any_filetypes, $src_filetype;
last;
}
}
}
}
LIST_unique( \@any_filetypes);

@template_spec_refs = TEMPLATES_find_by_type( \@any_filetypes);

return @template_spec_refs;
}




sub get_gbs_gen_type($$)
{
my ($build,
$src_type,
) = @_;
my $gbs_src_type;

if (BUILD_is_src_type( $build, $src_type))
{
$gbs_src_type = BUILD_get_src_items( $build, $src_type, 'TYPE')->[0];	# $type e.g.: gen, asm, c, glb, ...
} else
{
$gbs_src_type = '';
}

return $gbs_src_type;
}




sub GBSEDIT_create_file($$$$$)
{
my ($file_path,	    # Must have been validated with FLOC_validate_filespec
$file,		    # Must have been validated with FLOC_validate_filespec
$file_is_in_current_gbs_path,	# bool
$environment_ref,   # [ $GENERIC_FILE_NAME, $SUBSYS, $COMPONENT, $SUBDIR, $AUDIT, $BUILD, $TOOL, $ABT_NAME ]
$extra_data,




) = @_;
my $file_created = 0;



$FILE = $file;
$FILE_PATH = $file_path;
($GENERIC_FILE_NAME, $SUBSYS, $COMPONENT, $SUBDIR, $AUDIT, $BUILD, $TOOL, $ABT_NAME) = @{$environment_ref};
$EXTRA_DATA = $extra_data;

($FILE_NAME, $FILE_TYPE) = ENV_split_spec_nt( $FILE);
$FILE_SPEC = "$FILE_PATH/$FILE";

my $non_gbs_path_allowed = (exists $NON_GBS_PATH_ALLOWED{$GENERIC_FILE_NAME}) ? 1 : 0;

if ($FILE_TYPE eq '.usr' && $GENERIC_FILE_NAME ne 'any')
{
my $gbs_file_spec = "$FILE_PATH/$FILE_NAME.gbs";
if (-e $gbs_file_spec)
{
ENV_say( 2, "Copy the original .gbs file...");
FILE_copy_translate( $gbs_file_spec, $FILE_SPEC,
( "$FILE_NAME.gbs" => "$FILE_NAME.usr",
uc "$FILE_NAME.gbs" => uc "$FILE_NAME.usr"));
}
} else
{
if ($file_is_in_current_gbs_path || $non_gbs_path_allowed)
{
my $create_func = $FILE_DEFS{ $GENERIC_FILE_NAME}->[0];

my $create_file_spec = $create_func->();
} else
{

ENV_touch_file( $FILE_SPEC);
}
}
$file_created = 1;




$FILE_SPEC = '';
$SUBSYS = '';
$COMPONENT = '';
$SUBDIR = '';
$BUILD = '';
$AUDIT = '';
$TOOL  = '';
$ABT_NAME = '';

return $file_created;
}





sub post_abt($)
{
my ($read_func,
) = @_;
my $file_is_ok = 0;

my $abt = ENV_parent_dir( $FILE_SPEC, -2);
$file_is_ok = ENV_try( undef, sub { $read_func->( $abt, 1) }, undef);

return $file_is_ok;
}





sub post_simple($;@)
{
my ($read_func,
@args
) = @_;
my $file_is_ok = 0;

$file_is_ok = ENV_try( undef, sub { $read_func->( $FILE_SPEC, @args) }, undef);

return $file_is_ok;
}




sub post_export()
{
my $file_is_ok = 0;

my $export_file_loc = ($COMPONENT ne '') ? 'CMP' : '$SUBSYS';	# SUBSYS or CMP

$file_is_ok = ENV_try( undef, sub { EXPORT_parse( $export_file_loc, $COMPONENT , $BUILD) }, undef);

return $file_is_ok;
}





sub post_script()
{
my $file_is_ok = 0;

$file_is_ok = ENV_try( undef, sub { ENV_system( $FILE_SPEC, 0) }, undef);

return $file_is_ok;
}




sub post_plain($)
{
my ($read_func,
) = @_;
my $file_is_ok = 0;

$file_is_ok = ENV_try( undef, sub { $read_func->() }, undef);

return $file_is_ok;
}




sub post_scope()
{
my $file_is_ok = 0;

my (undef, $subsys, $component, undef) = GBSGLO_split_gbs_spec( $FILE_SPEC);
$file_is_ok = ENV_try( undef, sub { SCOPE_read( $subsys, $component, 1) }, undef);

return $file_is_ok;
}




sub post_ssprop()
{
my $file_is_ok = 0;

my ($root_path, $subsys, undef, undef) = GBSGLO_split_gbs_spec( $FILE_SPEC);
$file_is_ok = ENV_try( undef, sub { SSPROP_read( $root_path, $subsys, 1) }, undef);

return $file_is_ok;
}




sub post_switch()
{
return PLUGINMAINT_check_switch();
}

1;


