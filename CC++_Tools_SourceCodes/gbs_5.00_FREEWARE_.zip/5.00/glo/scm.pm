#=================================================
#
#   scm.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
#   File states:
#    -2 => 'NO-FILE',
#    -1 => 'NOT-SCM',
#     0 => 'CHECKED-IN',
#     1 => 'CHECKED-OUT',
#=================================================
package glo::scm;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SCM_split_info
SCM_join_info
SCM_state2txt
SCM_preinfo
SCM_preset
SCM_get_current_id
SCM_connect
SCM_stop
SCM_cache_states
SCM_get_states
SCM_checkout
SCM_checkin
SCM_undo_checkout
SCM_add_dirs
SCM_add_txt_files
SCM_get_ignore
SCM_set_ignore
SCM_remove_names
SCM_move
SCM_assert_co_dir
SCM_assert_co_file
SCM_store_file
SCM_select
SCM_determine
SCM_get_names
);
}




use glo::env;
use glo::ask;
use glo::spit;
use glo::slurp;









sub SCM_split_info($);
sub SCM_join_info($);
sub SCM_state2txt($);
sub SCM_preinfo($$);
sub SCM_preset($$);
sub SCM_get_current_id();
sub SCM_connect();
sub SCM_stop();
sub SCM_cache_states($);
sub SCM_get_states($$);
sub SCM_checkout($);
sub SCM_checkin($);
sub SCM_undo_checkout($);
sub SCM_remove_names($);
sub SCM_add_dirs($$$$);
sub SCM_add_txt_files($$$);
sub SCM_move($$$);
sub SCM_get_ignore($);
sub SCM_set_ignore($$);
sub SCM_assert_co_dir($$);
sub SCM_assert_co_file($);
sub SCM_store_file($$);
sub SCM_select($$);
sub SCM_determine($);
sub SCM_get_names($);

sub convert_specs($$$);
sub find_exec_os($$);
sub get_scms_id($$);
sub validate_preset();
sub validate_init();
sub validate_connected();
sub import_cc();
sub import_ccm();
sub import_git();
sub import_svn();
sub import_noscms();




my $SCM_PRESET = 0;
my $SCM_INITIALIZED = 0;
my $SCM_CONNECTED = 0;

my $APP_NAME = '';	    # e.g.: GBS
my $VERBOSE;




















my $SCMS_NAME = 'No_SCMS';
my $SCMS_ID = 'no_scms';
my $IS_NO_SCMS = 0;
my $SCMS_REPOSITORY = '';

my $SCMS_DATA = '';		# SCMS_DATA
my $APP_ROOT_PATH = '';		# e.g. $GBS::ROOT_PATH
my $APP_ROOT_PATH_L = 0;	# e.g. $GBS::ROOT_PATH LENGTH
my $APP_ROOT_PATH_QM = '';	# QUOTEMETA
my $WA_PATH = '';		# WA_PATH
my $WA_PATH_L = 0;		# WA_PATH length

my $APP_ROOT_PATH_NAME;		# e.g.: '$GBS_ROOT_PATH'

my $EXEC_OS;	    # Command-line command to execute the tool. E.g.: C:\PROGRA~1\TORTOI~1\bin\svn.exe

my %EXECS = (

cc      => [ 'cleartool',	[ 'bin'	    ] ],
ccm     => [ 'ccm',		[ 'bin'	    ] ],
git     => [ 'git',		[ ''	    ] ],   # Not sure
svn     => [ 'svn',		[ '', 'bin' ] ],   # changed with CollabnetSVN (was bin)
no_scms => [ 'no_scms',	undef	      ],
);

my %IDS = (





git		     => [ 'git',	'Git',		    '*',	    \&import_git ],
subversion	     => [ 'svn',	'SubVersioN',	    '*',	    \&import_svn ],
no_scms	     => [ 'no_scms',	'No_SCMS',	    '*',	    \&import_noscms ],
);

my %PREINFO_DATA = (

cc		=> [ qw! \.keep\d+$ \.contrib$ \.unloaded$ ! ],
ccm		=> [],
git		=> [ qw! (^|/)\.git$ ! ],
svn		=> [ qw! (^|/)\.svn$ ! ],
no_scms	=> [],
);

my %INIT_SCM = (

cc		=> sub { SCMCC_init( $_[0], $_[1]) },
ccm		=> sub { SCMCCM_init( $_[0], $_[1]) },
git		=> sub { SCMGIT_init( $_[0], $_[1]) },
svn		=> sub { SCMSVN_init( $_[0], $_[1]) },
no_scms	=> sub { SCMNONE_init( $_[0], $_[1]) },
);

my %CONNECT_SCM = (

cc		=> sub { SCMCC_connect( $_[0], $_[1], $_[2]) },
ccm		=> sub { SCMCCM_connect( $_[0], $_[1], $_[2]) },
git		=> sub { SCMGIT_connect( $_[0], $_[1], $_[2]) },
svn		=> sub { SCMSVN_connect( $_[0], $_[1], $_[2]) },
no_scms	=> sub {},
);

my %STOP = (

cc		=> sub {},
ccm 	=> sub { SCMCCM_stop() },
git 	=> sub {},
svn 	=> sub {},
no_scms	=> sub {},
);

my %CACHE_STATE = (

cc		=> sub {},
ccm 	=> sub {},
git	 	=> sub { SCMGIT_cache_states( $_[0]) },
svn 	=> sub { SCMSVN_cache_states( $_[0]) },
no_scms	=> sub {},
);

my %FILE_STATE = (

cc		=> sub { SCMCC_get_states( $_[0]) },
ccm 	=> sub { SCMCCM_get_states( $_[0]) },
git 	=> sub { SCMGIT_get_states( $_[0]) },
svn 	=> sub { SCMSVN_get_states( $_[0]) },
no_scms	=> sub { SCMNONE_get_states( $_[0]) },
);

my %CHECKOUT = (

cc		=> sub { SCMCC_checkout( $_[0]) },
ccm 	=> sub { SCMCCM_checkout( $_[0]) },
git 	=> sub { SCMGIT_checkout( $_[0]) },
svn 	=> sub { SCMSVN_checkout( $_[0]) },
no_scms	=> sub { SCMNONE_checkout( $_[0]) },
);

my %CHECKIN = (

cc		=> sub { SCMCC_checkin( $_[0]) },
ccm 	=> sub { SCMCCM_checkin( $_[0]) },
git 	=> sub { SCMGIT_checkin( $_[0]) },
svn 	=> sub { SCMSVN_checkin( $_[0]) },
no_scms	=> sub { SCMNONE_checkin( $_[0]) },
);

my %UNCHECKOUT = (

cc		=> sub { SCMCC_uncheckout( $_[0]) },
ccm 	=> sub { SCMCCM_uncheckout( $_[0]) },
git 	=> sub { SCMGIT_uncheckout( $_[0]) },
svn 	=> sub { SCMSVN_uncheckout( $_[0]) },
no_scms	=> sub { SCMNONE_uncheckout( $_[0]) },
);

my %REMOVE = (

cc		=> sub { SCMCC_remove( $_[0]) },
ccm 	=> sub { SCMCCM_remove( $_[0]) },
git 	=> sub { SCMGIT_remove( $_[0]) },
svn 	=> sub { SCMSVN_remove( $_[0]) },
no_scms	=> sub { SCMNONE_remove( $_[0]) },
);

my %MOVE = (

cc		=> sub { SCMCC_move( $_[0]) },
ccm 	=> sub { SCMCCM_move( $_[0]) },
git 	=> sub { SCMGIT_move( $_[0]) },
svn 	=> sub { SCMSVN_move( $_[0]) },
no_scms	=> sub { SCMNONE_move( $_[0]) },
);

my %MKDIRS = (

cc		=> sub { SCMCC_add_dirs( $_[0]) },
ccm 	=> sub { SCMCCM_add_dirs( $_[0]) },
git 	=> sub { SCMGIT_add_dirs( $_[0]) },
svn 	=> sub { SCMSVN_add_dirs( $_[0]) },
no_scms	=> sub { SCMNONE_add_dirs( $_[0]) },
);

my %MKTXTS = (

cc		=> sub { SCMCC_add_files( $_[0]) },
ccm 	=> sub { SCMCCM_add_files( $_[0]) },
git 	=> sub { SCMGIT_add_files( $_[0]) },
svn 	=> sub { SCMSVN_add_files( $_[0]) },
no_scms	=> sub { SCMNONE_add_files( $_[0]) },
);

my %GET_IGNORES = (

cc		=> sub { },				# not possible
ccm 	=> sub { },				# not possible
git 	=> sub { SCMGIT_get_ignore( $_[0]) },
svn 	=> sub { SCMSVN_get_ignore( $_[0]) },
no_scms	=> undef,
);

my %SET_IGNORES = (

cc		=> sub { },				# not possible
ccm 	=> sub { },				# not possible
git 	=> sub { SCMGIT_set_ignore( $_[0], $_[1]) },
svn 	=> sub { SCMSVN_set_ignore( $_[0], $_[1]) },
no_scms	=> undef,
);

my %SELECT = (

cc		=> sub { SCMCC_setup( $_[0], $_[1], $_[2]) },
ccm 	=> sub { SCMCCM_setup( $_[0], $_[1], $_[2]) },
git 	=> sub { SCMGIT_setup( $_[0], $_[1], $_[2]) },
svn 	=> sub { SCMSVN_setup( $_[0], $_[1], $_[2]) },
no_scms	=> undef,
);


my %STATE_TXTS = (
-2 => 'NOT-EXIST',
-1 => 'NOT-SCM',
0 => 'CHECKED-IN',
1 => 'CHECKED-OUT',
);




sub SCM_split_info($)
{
my ($info_text_or_ref,  # $scm_info = "$scm_name [$scm_repository ($scm_data) ]"

) = @_;
my ($scms, $scms_repository, $scms_data) = ( '', '', '');

if (ref $info_text_or_ref)
{
($scms, $scms_repository, $scms_data) = @{$info_text_or_ref};
} else
{
if ($info_text_or_ref ne '')
{
($scms, my $rest) = split( ' ', $info_text_or_ref, 2);
my $lc_scms = lc $scms;

if ($lc_scms eq 'svn' || $lc_scms eq 'subversion' || $lc_scms eq 'git')
{
($scms_repository, $scms_data) = $rest =~ /\[\s*(.+)\s*\(\s*(.+)\s*\)\s*\]/;
} elsif ($lc_scms eq 'cmsynergy')
{
($scms_repository, $scms_data) = $rest =~ /\[\s*(.+)\s*\]/;
} elsif ($lc_scms eq 'clearcase' || $lc_scms eq 'no_scms')
{

} else
{
ENV_sig( F => "Unknown SCMS ($scms)");
}
}

}

return ($scms, $scms_repository, $scms_data);
}





sub SCM_join_info($)
{
my ($scm_info_ref,	# [ $scms, $scms_repository, $scms_data ] No undef values.
) = @_;


my ($scms, $scms_repository, $scms_data) = @{$scm_info_ref};

my $lc_scms = lc $scms;
if ($lc_scms eq 'subversion' || $lc_scms eq 'git')
{
return "$scms [ $scms_repository ($scms_data) ]";
} elsif ($lc_scms eq 'cmsynergy')
{
return "$scms [ $scms_repository ]";
} elsif ($lc_scms eq 'clearcase' || $lc_scms eq 'no_scms')
{
return "$scms";
} else
{
ENV_sig( F => "Unknown SCMS ($scms)");
}
}








sub SCM_state2txt($)
{
my ($state) = @_;	    # -2, -1, 0, 1
my $state_txts;

return $STATE_TXTS{$state};
}







sub SCM_preinfo($$)
{
my ($scms_name,	    # clearcase, cmsynergy, git, subversion, no_scms
$app_root_path,
) = @_;
my ($skiptypes_ref);

my $scms_id = get_scms_id( $scms_name, 0);




($skiptypes_ref) = $PREINFO_DATA{$scms_id};

return ($skiptypes_ref);
}









sub SCM_preset($$)
{
my ($app_root_path,
$scms_info_or_ref,  # $scm_info = "$scm_name [$scm_repository ($scm_data) ]"

) = @_;
my @old_values = ($APP_ROOT_PATH, $SCMS_NAME, $SCMS_REPOSITORY, $SCMS_DATA);

my ($scms_name, $scms_repository, $scms_data) = SCM_split_info( $scms_info_or_ref);

$APP_NAME = ENV_get_application_name();	# e.g.: GBS

$APP_ROOT_PATH = $app_root_path;
$APP_ROOT_PATH_L = length $APP_ROOT_PATH;
$APP_ROOT_PATH_QM = quotemeta( $APP_ROOT_PATH);

$APP_ROOT_PATH_NAME = "\$${APP_NAME}_ROOT_PATH";

$WA_PATH = ENV_parent_path( $APP_ROOT_PATH);
$WA_PATH_L = length $WA_PATH;

$VERBOSE = ENV_set_verbose();

$SCMS_NAME = $scms_name;
$SCMS_ID = get_scms_id( $scms_name, 1);
$IS_NO_SCMS = ($SCMS_ID eq 'no_scms') ? 1 : 0;
$SCMS_REPOSITORY = $scms_repository;
$SCMS_DATA = $scms_data;




$EXEC_OS = find_exec_os( $SCMS_ID, 1);	# $exit_on_error


$SCM_PRESET = 1;
$SCM_INITIALIZED = 0;
$SCM_CONNECTED = 0;

return @old_values;
}




sub SCM_get_current_id()
{
my $id;	# cc, ccm, svn, git or '' (no_scms)

validate_preset();

$id = $SCMS_ID;
$id = '' if ($id eq 'no_scms');

return $id;
}







sub SCM_connect()
{



validate_preset();
ENV_pushd( $APP_ROOT_PATH);

validate_init();
my ($actual_repos, $actual_data, $texts_ref) =
$CONNECT_SCM{$SCMS_ID}->( $SCMS_REPOSITORY, $APP_ROOT_PATH, $SCMS_DATA);
ENV_whisper( 1, $texts_ref)
if (defined $texts_ref);
if (defined $actual_repos)
{
$SCMS_REPOSITORY = $actual_repos;
}
if (defined $actual_data)
{
$SCMS_DATA = $actual_data;
}

$SCM_CONNECTED = 1;

ENV_popd();

return ( $SCMS_REPOSITORY, $SCMS_DATA );
}




sub SCM_stop()
{
validate_preset();
ENV_pushd( $APP_ROOT_PATH);

validate_connected();

$STOP{$SCMS_ID}->();

$SCM_CONNECTED = 0;

ENV_popd();
}




sub SCM_cache_states($)
{
my ($force_reread,	# bool
) = @_;

validate_preset();
ENV_pushd( $APP_ROOT_PATH);

validate_connected();

$CACHE_STATE{$SCMS_ID}->( $force_reread);

ENV_popd();
}








sub SCM_get_states($$)
{
my ($specs_ref_or_spec,
$pre_validated,
) = @_;
my @spec_refs;


validate_preset();
ENV_pushd( $APP_ROOT_PATH);

validate_connected();

foreach my $spec (convert_specs( $specs_ref_or_spec, $pre_validated, undef))
{
my $state = (-e $spec) ? undef : -2;	    # -2 = no such file
push @spec_refs, [ $spec, $state ];
}




$FILE_STATE{$SCMS_ID}->( \@spec_refs);

ENV_popd();

if (wantarray)
{
foreach my $ref (@spec_refs)
{
my $rel_spec = $ref->[0];
$ref->[0] = ($rel_spec eq '.') ? $APP_ROOT_PATH : "$APP_ROOT_PATH/$rel_spec";
}
return @spec_refs;
} else
{
$spec_refs[0]->[1];		    # $state
}
}




sub SCM_checkout($)
{
my ($specs_ref_or_spec) = @_;

validate_preset();
ENV_pushd( $APP_ROOT_PATH);

validate_connected();
my @rel_specs = convert_specs( $specs_ref_or_spec, 0, 'e');

if (@rel_specs)
{



$CHECKOUT{$SCMS_ID}->( \@rel_specs);




ENV_chmod( 'u+w', @rel_specs);
} else
{
ENV_whisper( 1, 'SCM: Nothing to CheckOut');
}

ENV_popd();
}





sub SCM_checkin($)
{
my ($specs_ref_or_spec) = @_;

validate_preset();
ENV_pushd( $APP_ROOT_PATH);

validate_connected();
my @rel_specs = convert_specs( $specs_ref_or_spec, 0, 'e');

if (@rel_specs)
{



$CHECKIN{$SCMS_ID}->( \@rel_specs);
} else
{
ENV_whisper( 1, 'SCM: Nothing to CheckIn');
}

ENV_popd();
}





sub SCM_undo_checkout($)
{
my ($specs_ref_or_spec) = @_;

validate_preset();
ENV_pushd( $APP_ROOT_PATH);

validate_connected();
my @rel_specs = convert_specs( $specs_ref_or_spec, 0, 'e');

if (@rel_specs)
{



$UNCHECKOUT{$SCMS_ID}->( \@rel_specs);
} else
{
ENV_whisper( 1, 'SCM: Nothing to UndoCheckout');
}

ENV_popd();
}





sub SCM_remove_names($)
{
my ($specs_ref_or_spec) = @_;

validate_preset();
ENV_pushd( $APP_ROOT_PATH);

validate_connected();

my @rel_specs = convert_specs( $specs_ref_or_spec, 0, 'e');




if (@rel_specs)
{
$REMOVE{$SCMS_ID}->( \@rel_specs);
} else
{
ENV_whisper( 1, "SCM: Nothing to Remove");
}

ENV_popd();
}




sub SCM_move($$$)
{
my ($pair_refs_ref,	    # [ [$old, $new], ... ] or [ $old, $new ]
$pre_validated,
$verbose_level,     # 0 = none, 1 = summary only, 2 = all
) = @_;

$verbose_level = 2
if ($VERBOSE);	# DBG: force verbose_level to max

validate_preset();
ENV_pushd( $APP_ROOT_PATH);

validate_connected();

$pair_refs_ref = [ $pair_refs_ref ]
if (@{$pair_refs_ref} && ! ref $pair_refs_ref->[0]);

my @rel_pair_refs;
foreach my $ref (@{$pair_refs_ref})
{
my ($old_spec, $new_spec) = @{$ref};
my $rel_old_spec = convert_specs( $old_spec, $pre_validated, 'e' );
my $rel_new_spec = convert_specs( $new_spec, $pre_validated, 'n' );
if (defined $rel_old_spec && defined $rel_new_spec)
{
push @rel_pair_refs, [ $rel_old_spec, $rel_new_spec ];
ENV_say( 1, "Moving '$APP_ROOT_PATH_NAME/$rel_old_spec' to '$rel_new_spec'...")
if ($verbose_level > 0);
}
}




if (@rel_pair_refs)
{
$MOVE{$SCMS_ID}->( \@rel_pair_refs);
} else
{
ENV_whisper( 1, "SCM: Nothing to Move");
}

ENV_popd();
}





sub SCM_add_dirs($$$$)
{
my ($dirs_ref_or_dir,
$get_ignore_func,	# $ignores_ref = function( $abs_dir)
$pre_validated,
$verbose_level,		# 0 = none, 1 = summary only, 2 = all
) = @_;

$verbose_level = 2
if ($VERBOSE);	# DBG: force verbose_level to max

validate_preset();
ENV_pushd( $APP_ROOT_PATH);

validate_connected();

my @dir_refs;
foreach my $dir (convert_specs( $dirs_ref_or_dir, $pre_validated, undef))
{

if (-d $dir)
{

my $state = SCM_get_states( $dir, 1);

if ($state == -1)	# not in SCM
{
my $ignores_ref = $get_ignore_func->( "$APP_ROOT_PATH/$dir");
my @ignores = (defined $ignores_ref) ? @{$ignores_ref} : '';
ENV_say( 1, "Adding Dir. '$dir' (@ignores)...")
if ($verbose_level == 2);
push @dir_refs, [ $dir, $ignores_ref ];
} elsif ($state == 0)   # checked-in
{
ENV_say( 1, "'$dir' already checked-in")
if ($verbose_level > 0);
} else		    # checked-out
{
ENV_say( 1, "'$dir' already checked-out")
if ($verbose_level > 0 && !$IS_NO_SCMS);
}
} else
{
my $ignores_ref = $get_ignore_func->( "$APP_ROOT_PATH/$dir");
my @ignores = (defined $ignores_ref) ? @{$ignores_ref} : '';
ENV_say( 1, "Creating Dir. '$dir' (@ignores)...")
if ($verbose_level == 2);
push @dir_refs, [ $dir, $ignores_ref ];
}
}
my $nr_create_add = @dir_refs;
ENV_say( 1, "Creating/Adding $nr_create_add Dir(s)...")
if ($verbose_level >= 1 && !$IS_NO_SCMS);

if (@dir_refs)
{



my $saved_mask = umask 0002;	# disable others:write
$MKDIRS{$SCMS_ID}->( \@dir_refs);
umask $saved_mask;
} else
{
ENV_whisper( 1, "SCM: Nothing to MkDir");
}

ENV_popd();
}





sub SCM_add_txt_files($$$)
{
my ($files_ref_or_file,
$pre_validated,
$verbose_level,        # 0 = none, 1 = summary only, 2 = all
) = @_;

$verbose_level = 2
if ($VERBOSE);		# DBG: force verbose_level to max

validate_preset();
ENV_pushd( $APP_ROOT_PATH);

validate_connected();

my @files;
foreach my $file (convert_specs( $files_ref_or_file, $pre_validated, undef))
{

if (-f $file)
{

my $state = SCM_get_states( $file, 1);

if ($state == -1)	    # not in SCM
{
ENV_say( 1, "Adding File '$file'...")
if ($verbose_level >= 1);
push @files, $file;
} elsif ($state == 0)   # checked-in
{
ENV_say( 1, "'$file' already checked-in")
if ($verbose_level > 0);
} else		    # checked-out
{
ENV_say( 1, "'$file' already checked-out")
if ($verbose_level > 0 && !$IS_NO_SCMS);
}
} else
{
ENV_say( 1, "Creating File $file...")
if ($verbose_level == 2);
push @files, $file;
}
}
my $nr_create_add = @files;
ENV_say( 1, "Creating/Adding $nr_create_add File(s)...")
if ($verbose_level >= 1 && !$IS_NO_SCMS);

if (@files)
{



my $saved_mask = umask 0002;	# disable others:write
$MKTXTS{$SCMS_ID}->( \@files);
umask $saved_mask;
} else
{
ENV_whisper( 1, "SCM: Nothing to MkFile");
}

ENV_popd();
}




sub SCM_get_ignore($)
{
my ($dir_spec,	    # 1 dir only
) = @_;
my @ignores;    # 	match: * = any string, ? = any single, [xx] = subset, [!xx] = non subset

validate_preset();
ENV_pushd( $APP_ROOT_PATH);

validate_connected();
my $rel_dir = convert_specs( $dir_spec, 0, 'd');

my $function_ref = $GET_IGNORES{$SCMS_ID};
if (defined $function_ref)
{
my $state = SCM_get_states( $rel_dir, 1);
if ($state >= 0)
{



@ignores = $function_ref->( $rel_dir);
} else
{
ENV_sig( E => "Dir: '$APP_ROOT_PATH_NAME/$rel_dir' not SCM");
}
}

ENV_popd();

return @ignores;
}




sub SCM_set_ignore($$)
{
my ($dirs_ref_or_dir,
$ignores_ref,	    # [ wildcard, ... ]	    # match: * = any string, ? = any single, [xx] = subset, [!xx] = non subset
) = @_;

validate_preset();
ENV_pushd( $APP_ROOT_PATH);

validate_connected();
my @rel_dirs = convert_specs( $dirs_ref_or_dir, 0, 'd');

my $function_ref = $SET_IGNORES{$SCMS_ID};
if (defined $function_ref)
{
my @dirs;
foreach my $dir (@rel_dirs)
{
my $state = SCM_get_states( $dir, 1);
if ($state >= 0)
{
push @dirs, $dir;
} else
{
ENV_sig( E => "Dir: '$APP_ROOT_PATH_NAME/$dir' not SCM");
}
}
if (@dirs)
{



$function_ref->( \@dirs, $ignores_ref);
}
}

ENV_popd();
}






sub SCM_assert_co_dir($$)
{
my ($specs_ref_or_spec,
$get_ignore_func,   # $ignores_ref = function( $dir)
) = @_;

validate_preset();
ENV_pushd( $APP_ROOT_PATH);

validate_connected();




foreach my $spec (convert_specs( $specs_ref_or_spec, 0, undef))
{
my $state = SCM_get_states( $spec, 1);
if ($state == -2 || $state == -1)   #   -2 = no such file,  -1 = not in SCM
{
SCM_add_dirs( $spec, $get_ignore_func, 1, 0);
} elsif ($state == 0)		    #    0 = checked-in
{
ENV_say( 1, "Checkout '$spec'");
SCM_checkout( $spec);
} else				    #    1 = checked-out
{

}
}

ENV_popd();
}






sub SCM_assert_co_file($)
{
my ($specs_ref_or_spec) = @_;

validate_preset();
ENV_pushd( $APP_ROOT_PATH);

validate_connected();




foreach my $spec (convert_specs( $specs_ref_or_spec, 0, undef))
{
my $state = SCM_get_states( $spec, 1);
if ($state == -2 || $state == -1)   #   -2 = no such file,  -1 = not in SCM
{
SCM_add_txt_files( $spec, 1, 0);
} elsif ($state == 0)		    #    0 = checked-in
{
ENV_say( 1, "Checkout '$spec'");
SCM_checkout( $spec);
} else				    #    1 = checked-out
{

}
}

ENV_popd();
}





sub SCM_store_file($$)
{
my ($filespec,
$lines_ref,
) = @_;

validate_preset();
ENV_pushd( $APP_ROOT_PATH);

validate_connected();
if (-e $filespec)
{
SCM_checkout( $filespec)
if (!-w $filespec);
} else
{
SCM_add_txt_files( $filespec, 1, 0);
}
SPIT_file_nl( $filespec, $lines_ref);

ENV_popd();
}









sub convert_specs($$$)
{
my ($specs_ref_or_spec,
$pre_validated,	    # bool
$check,		    # undef = no_check, d = must be dir, f = must be file, e = must exist, n = must_not exist
) = @_;
my @rel_specs;

my $specs_ref = (ref $specs_ref_or_spec) ? $specs_ref_or_spec : [ $specs_ref_or_spec ];

foreach my $filespec (@{$specs_ref})
{
my $this_spec = ENV_perl_canon_paths( $filespec);
$this_spec = ENV_delink_spec( $this_spec)
if ($SCMS_ID eq 'cc');

if (!$pre_validated)
{
if (ENV_is_abs_path( $this_spec))
{
if ($this_spec ne $WA_PATH)
{
my $this_spec_path = substr( $this_spec, 0, $APP_ROOT_PATH_L);


if ($this_spec_path ne $APP_ROOT_PATH)
{
ENV_sig( EE => 'File/dir not in WA-scope',
"File/dir      : $filespec",
"     ==>      : $this_spec",
"FILE_ROOT     : $this_spec_path",
"APP_ROOT_PATH : $APP_ROOT_PATH",
"WA_PATH       : $WA_PATH",
"SCMS_DATA     : $SCMS_DATA");
}
}
}
}




if (ENV_is_abs_path( $this_spec))
{
if ($this_spec ne $APP_ROOT_PATH)
{
$this_spec = substr( $this_spec, $APP_ROOT_PATH_L + 1);	# relative path
} else
{
$this_spec = '.';	# relative path
}

} else
{

}




if (!$pre_validated && defined $check)
{

my $error = '';
if ($check eq 'e')
{
$error = "Dir/File '$APP_ROOT_PATH_NAME/$this_spec' does not exist"
if (! -e $this_spec);
} elsif ($check eq 'd')
{
$error = "Dir '$APP_ROOT_PATH_NAME/$this_spec' does not exist"
if (! -d $this_spec);
} elsif ($check eq 'f')
{
$error = "File '$APP_ROOT_PATH_NAME/$this_spec' does not exist"
if (! -f $this_spec);
} elsif ($check eq 'n')
{
$error = "Dir/File $APP_ROOT_PATH_NAME/$this_spec' already exist"
if ( -e $this_spec);
} else
{
ENV_sig( F => "Invalid value for check ($check)");
}
if ($error ne '')
{
ENV_sig( E => $error);
} else
{
push @rel_specs, $this_spec;
}
} else
{
push @rel_specs, $this_spec;
}
}

return wantarray ? (@rel_specs) : $rel_specs[0];
}




sub SCM_select($$)
{
my ($default_scm_info_or_ref,   # $scm_info = "$scm_name [$scm_repository ($scm_data) ]" or

$app_root_path,
) = @_;
my ($full_scm_name, $scms_repository, $scms_data) = ('', '', '');






my ($default_scm_name,	    # if undef: Only get the repository and data values. No switch of SCMS!
$default_repository,
$default_data,
) = SCM_split_info( $default_scm_info_or_ref);




if (defined $default_scm_name && $default_scm_name ne '')
{



}

$APP_NAME = ENV_get_application_name()
if ($APP_NAME eq '');

my $scms_id;
if (defined $default_scm_name)
{



my @scm_supported_refs;
foreach my $full_scm_name (SCM_get_names( '.'))	# Current OS
{
my $scms_id = $IDS{ lc $full_scm_name}->[0];   # $id
my $is_available = (defined find_exec_os( $scms_id, 0)) ? 1 : 0;
push @scm_supported_refs, [ $full_scm_name, $scms_id, $is_available ];
}
ENV_say( 1, "The following SCMSs are available on this computer:");
foreach my $ref (@scm_supported_refs)
{
my ($full_scm_name, $scms_id, $is_available) = @{$ref};
my $envvar = uc "${APP_NAME}EXT_${scms_id}_PATH";
my $available_text = ($is_available) ? "Available     (command found in PATH or via $envvar)" :
"Not Available (command not found in PATH or via $envvar)";
$available_text = 'Available     (always)'
if ($scms_id eq 'no_scms');
ENV_say( 0, sprintf( "  %-*s : $available_text", 16, $full_scm_name));
}
ENV_say( 0, "");




my $default_scm_id;
if ($default_scm_name eq '')
{
$default_scm_id = 'no_scms';
} else
{
$default_scm_id = $IDS{ lc $default_scm_name }->[0];	# $scm_id
ENV_sig( F => "Invalid default_scm_name ($default_scm_name)")
if (!defined $default_scm_id);
}

@scm_supported_refs = ( [ '<Quit>' ], grep $_->[2], @scm_supported_refs);	    # $is_avaiable
my $index = ASK_index_from_menu( "Select SW Configuration Management System",
\$default_scm_id, undef, [ @scm_supported_refs ]);
$full_scm_name = $scm_supported_refs[ $index]->[0];

$scms_id = $scm_supported_refs[ $index]->[1];
if ($full_scm_name ne $default_scm_name)
{
$default_repository = '';
$default_data = '';
}
} else
{
$scms_id = $SCMS_ID;
$full_scm_name = $SCMS_NAME;
}




ENV_say( 1, "Current SCMS: " . SCM_join_info( [ $full_scm_name, $default_repository, $default_data ]));




my $select_function_ref = $SELECT{$scms_id};	    # *_setup
if (defined $select_function_ref)
{



my ($old_app_root_path,
$old_scms_name,
$old_repository,
$old_scms_data) = SCM_preset( $app_root_path, [ $full_scm_name, $default_repository, $default_data ]);
validate_init();




ENV_pushd( $app_root_path);
($scms_repository, $scms_data) = $select_function_ref->( $app_root_path, $default_repository, $default_data);

ENV_popd();




SCM_preset( $old_app_root_path, [ $old_scms_name, $old_repository, $old_scms_data ]);
}

if (wantarray)
{
return ( $full_scm_name, $scms_repository, $scms_data );
} else
{
return SCM_join_info( [ $full_scm_name, $scms_repository, $scms_data ]);
}
}




sub find_exec_os($$)
{
my ($scms_id,	    # cc, ccm, svn, git, no_scm
$exit_on_error,	    # 0 = no warn/error-messages and no exit
) = @_;
my $exec_os;

my ($exec_command, $exec_rel_path_ref) = @{$EXECS{$scms_id}};
if ($exec_command eq 'no_scms')
{
$exec_os = $exec_command;
} else
{



my $command_dir_env = uc "${APP_NAME}EXT_${scms_id}_PATH";
my $scms_path = ENV_getenv_perl_path( $command_dir_env);
if ($scms_path ne '' && $scms_path ne 'PATH')
{




if (-d $scms_path)
{
my @paths = map { "$scms_path/$_" } @{$exec_rel_path_ref};
foreach my $path (@paths)
{
$path =~ s/\/$//g;		# remove trailing /
}
my $exec = ENV_which_path( $exec_command, @paths);
if (defined $exec)
{
$exec_os = $exec;
} else
{
ENV_sig( E => "Cannot find $exec_command in (@paths)")
if ($exit_on_error);
}
} else
{
my $signal_code = ($exit_on_error) ? 'EE' : 'E';
ENV_sig( $signal_code => "$command_dir_env ($scms_path)", "not set to an existing directory or to PATH");
}
} else
{



if (!$scms_path)
{
if ($exit_on_error)
{
ENV_sig( W => "'$command_dir_env' not defined - Using PATH ($exec_command)",
"To implicitly use PATH: define '$command_dir_env=PATH'");
ENV_setenv( $command_dir_env => 'PATH');
}
}

my $exec = ENV_which( $exec_command, ($exit_on_error) ? 'EE': '');
if (defined $exec)
{
$exec_os = $exec;
} else
{
ENV_sig( E => "Cannot find $exec_command in PATH")
if ($exit_on_error);
}
}
}
if (defined $exec_os)
{
$exec_os = ENV_enquote( ENV_os_paths( $exec_os));
} else
{
ENV_sig( EE => "Cannot find the '$scms_id' executable ($exec_command). Terminating...")
if ($exit_on_error);
}


return $exec_os;
}





sub SCM_determine($)
{
my ($path,
) = @_;
my ($scms_name, $scms_repository, $scms_data) = ( '', '', '');

if (-e "$path/.svn")
{
$scms_name = 'SubVersioN';
} elsif (-e "$path/.git")
{
$scms_name = 'Git';
} else
{
if (ENV_is_development() && ENV_is_win32())
{
if (-e "$path/.myscm")
{
($scms_repository, $scms_name) = SLURP_file( "$path/.myscm");
} else
{
$scms_name = ASK_value_from_menu( 'Select SCMS name', -1, undef, [ qw( CMSynergy ClearCase No_SCMS) ]);
}
} else
{
if (ENV_getenv( 'CCM_ADDR'))
{
$scms_name = 'CMSynergy';
} else
{
$scms_name = 'No_SCMS';
}
}
}
ENV_say( 1, "SCMS assumed/selected: $scms_name ($scms_repository)");

return ($scms_name, $scms_repository, $scms_data);
}






sub SCM_get_names($)
{
my ($wanted_os) = @_;		# '.' = current OS, '!' = other OS, '*' = all OS
my @scm_supported = ( 'No_SCMS' );	# Always the first, the rest in alphabetical order

if (wantarray)
{
my @names = grep( $_ ne 'No_SCMS', sort( map { $_->[1] } values( %IDS)));    # $full_name
if ($wanted_os eq '*')
{
push @scm_supported, @names;
} else
{
my $sup_os;
if ($wanted_os eq '.')
{
$sup_os = ($^O eq 'MSWin32') ? 'W' : 'X';
} else  # $wanted_os eq '!'
{
$sup_os = ($^O eq 'MSWin32') ? 'X' : 'W';
}
foreach my $name (@names)
{
my $os_supported = $IDS{lc $name}->[2];
push @scm_supported, $name
if ($os_supported eq '*' || $os_supported eq $sup_os);
}
}

return @scm_supported;
} else
{
return $scm_supported[0];	# 'No_SCMS'
}
}





sub get_scms_id($$)
{
my ($scms_name,
$must_import_package,
) = @_;
my $scms_id;

my $scms_id_ref = $IDS{lc $scms_name};
if (defined $scms_id_ref)
{
$scms_id = $scms_id_ref->[0]	    # $ids
} else
{
my @names = sort keys %IDS;
ENV_sig( E => "Unable to determine SCMS ($scms_name).",
"Possible values are: '@names'",
"Assuming no_scms...");
$scms_name = 'no_scms';
$scms_id = 'no_scms';
}

if ($must_import_package)
{
my $import_func = $IDS{lc $scms_name}->[3];	# $import_func
&$import_func();				# setup require and import
}

return $scms_id;
}




sub validate_preset()
{
ENV_sig( F => "SCM not preset")
if (!$SCM_PRESET);
}




sub validate_init()
{
if (!$SCM_INITIALIZED)
{
$INIT_SCM{$SCMS_ID}->( $APP_NAME, $EXEC_OS);
$SCM_INITIALIZED = 1;
}
}




sub validate_connected()
{
SCM_connect()
if (!$SCM_CONNECTED);
}




sub import_cc()
{
require glo::scmcc;
import  glo::scmcc;
}




sub import_ccm()
{
require glo::scmccm;
import  glo::scmccm;
}




sub import_git()
{
require glo::scmgit;
import  glo::scmgit;
}




sub import_svn()
{
require glo::scmsvn;
import  glo::scmsvn;
}




sub import_noscms()
{
require glo::scmnone;
import  glo::scmnone;
}

1;


