#=================================================
#
#   parse_c.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::parse_c;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
PARSE_C_new
PARSE_C_get_lines
PARSE_C_get_nr_lines
PARSE_C_get_includes
PARSE_C_get_nr_clean_lines
PARSE_C_get_nr_distinct_chars
PARSE_C_get_nr_distinct_words
PARSE_C_get_functions
PARSE_C_get_classes
PARSE_C_cleanup
);
}




use glo::env;
use glo::slurp;




sub PARSE_C_new($);
sub PARSE_C_get_lines($;$);
sub PARSE_C_get_nr_lines($;$);
sub PARSE_C_get_includes($;$);
sub PARSE_C_get_nr_clean_lines($;$);
sub PARSE_C_get_nr_distinct_chars($$;$);
sub PARSE_C_get_nr_distinct_words($$;$);
sub PARSE_C_get_functions($;$);
sub PARSE_C_get_classes($;$);
sub PARSE_C_cleanup($);

sub reduce_file($);









my $NC_KEEP_RE = qr!/\*[^*]*\*+([^/*][^*]*\*+)*/|//[^\n]*|("(\\.|[^"\\])*"|'(\\.|[^'\\])*'|.[^/"'\\]*)!s;





















my %FILE_REFS;








sub PARSE_C_new($)
{
my ($filespec_or_ref,	# [ $filespec, $lines_ref ] file must exist
) = @_;
my $this_ref;

my $filespec;
my $lines_ref;
if (ref $filespec_or_ref)
{
($filespec, $lines_ref) = @{$filespec_or_ref};
} else
{
$filespec = $filespec_or_ref;
}

$this_ref = $FILE_REFS{$filespec};
if (defined $this_ref)
{

} else
{





$this_ref = [ $filespec ];
$FILE_REFS{$filespec} = $this_ref;




my $lines;
if (defined $lines_ref)
{
$lines = $$lines_ref;
} else
{
$lines = SLURP_file( $filespec);
}




$lines =~ s/[ \t]+$//gm;    # global, multi-line




my $nr_lines = $lines =~ tr/\n//;




$this_ref->[1] = $nr_lines;		# $nr_lines
$this_ref->[2] = \$lines;		# $original_lines_ref
}

return $this_ref;
}





sub PARSE_C_get_lines($;$)
{
my ($this_ref,
$cleanup_when_done,	# bool, optional
) = @_;
my $lines;

my $lines_ref = $this_ref->[2];	# $original_lines_ref
if ($cleanup_when_done)
{
$lines = $$lines_ref;
PARSE_C_cleanup( $this_ref);
return (wantarray) ? split( "\n", $lines) : $lines;
} else
{
return (wantarray) ? split( "\n", $$lines_ref) : $$lines_ref;
}
}




sub PARSE_C_get_nr_lines($;$)
{
my ($this_ref,
$cleanup_when_done,	# bool, optional
) = @_;
my $nr_lines = $this_ref->[1];	# $nr_lines


PARSE_C_cleanup( $this_ref)
if ($cleanup_when_done);

return $nr_lines;
}




sub PARSE_C_get_includes($;$)
{
my ($this_ref,
$cleanup_when_done,	# bool, optional
) = @_;
my $include_refs_ref = $this_ref->[6];


if (!defined $include_refs_ref)
{
my $lines = ${$this_ref->[2]};		    # $original_lines_ref
{



my $line_nr = 1;
$lines =~ s/^/$line_nr++ . "\t"/gme;    # global, multi-line, expression
my $nr_lines = $line_nr - 1;





no warnings;    # Use of uninitialized value $2 in substitution iterator at ...
$lines =~ s!$NC_KEEP_RE!$2!gs;
use warnings FATAL => 'all';
}




{
my @include_refs;

my @include_lines = $lines =~ /^(\d+\t\s*#\s*include\s+.*[>"])/gm;    # global, multi-line


foreach my $include_line (@include_lines)
{
my ($line_nr, $quote_or_chevron, $inc_spec) = $include_line =~ /^(\d+)\t.*([<"])\s*(.*)\s*[>"]/;
push @include_refs, [ $line_nr, $quote_or_chevron, $inc_spec ];

}
$include_refs_ref = [ @include_refs ];
$this_ref->[6] = $include_refs_ref;	# $include_refs_ref
}
}

PARSE_C_cleanup( $this_ref)
if ($cleanup_when_done);

return (wantarray) ? @{$include_refs_ref} : $include_refs_ref;
}




sub PARSE_C_get_nr_clean_lines($;$)
{
my ($this_ref,
$cleanup_when_done,	# bool, optional
) = @_;
my $nr_reduced_lines = $this_ref->[5];    # $nr_reduced_lines

if (!defined $nr_reduced_lines)
{
reduce_file( $this_ref);
$nr_reduced_lines = $this_ref->[5];    # $nr_reduced_lines
}


PARSE_C_cleanup( $this_ref)
if ($cleanup_when_done);

return $nr_reduced_lines;
}




sub PARSE_C_get_nr_distinct_chars($$;$)
{
my ($this_ref,
$chars_or_ref,
$cleanup_when_done,	# bool, optional
) = @_;
my $nr_distinct_chars;

my @chars = (ref $chars_or_ref) ? @{$chars_or_ref} : ($chars_or_ref);
foreach my $char (@chars)
{
$char = quotemeta( $char);
}
my $chars_re = join( '|', @chars);

reduce_file( $this_ref);
my $reduced_lines_ref = $this_ref->[4];	# $reduced_lines_ref

$nr_distinct_chars = () = $$reduced_lines_ref =~ /($chars_re)/g;

PARSE_C_cleanup( $this_ref)
if ($cleanup_when_done);

return $nr_distinct_chars;
}




sub PARSE_C_get_nr_distinct_words($$;$)
{
my ($this_ref,
$word_or_ref,
$cleanup_when_done,	# bool, optional
) = @_;
my $nr_distinct_words;

my @words = (ref $word_or_ref) ? @{$word_or_ref} : ($word_or_ref);
foreach my $word (@words)
{
$word = quotemeta( $word);
}
my $word_re = join( '|', @words);

reduce_file( $this_ref);
my $reduced_lines_ref = $this_ref->[4];	# $reduced_lines_ref

$nr_distinct_words = () = $$reduced_lines_ref =~ /\b($word_re)\b/g;

PARSE_C_cleanup( $this_ref)
if ($cleanup_when_done);

return $nr_distinct_words;
}




sub PARSE_C_get_functions($;$)
{
my ($this_ref,
$cleanup_when_done,	# bool, optional
) = @_;
my $function_refs_ref = $this_ref->[7];


if (!defined $function_refs_ref)
{
reduce_file( $this_ref);

my $reduced_lines_ref = $this_ref->[4];	# $reduced_lines_ref
my @functions = "$$reduced_lines_ref" =~ /
[;\}]		    # end of previous statement
\s*		    # optional whitespace
(			    # capture begin
[:\s\w\*\[\]]+	    # return-types and function-name
\(			    # (
[\s\w\(\)\*\,\[\]!\.]* # optional arguments
\)			    # )
)			    # capture end
\s*		    # optional whitespace
\{			    # {
/gxs;




my @func_refs;

foreach my $function (@functions)
{
if ($function !~ /^(if|while|switch|for)\s?\(/)
{
$function =~ s/\s+/ /g;	    # replace all whitespace by 1 space

my ($ftype, $fname, $args) = $function =~ /^(.*\s+\W?)([\w:]+)\s?\(\s?(.*)\s?\)/;	# <type> <name> ( <args> )
if (!defined $args)
{
($fname, $args) = $function =~ /^([\w:]+)\s?\(\s?(.*)\s?\)/;			# <name ( <args> )
if (defined $args)
{

$ftype = '';
} else
{
ENV_whisper( 1, "'$function'", "- is not recognised as a function definition");
}
}
if (defined $args)
{
$args =~ s/\s+$//;				# remove trailing whitespace
my @args = split( /\s?,\s?/, $args);
$ftype =~ s/\s+$//;				# remove trailing whitespace
push @func_refs, [ $ftype, $fname, [ @args ] ];
}
} else
{

}
}

$function_refs_ref = \@func_refs;
$this_ref->[7] = $function_refs_ref;
}

PARSE_C_cleanup( $this_ref)
if ($cleanup_when_done);

return (wantarray) ? @{$function_refs_ref} : $function_refs_ref;
}




sub PARSE_C_get_classes($;$)
{
my ($this_ref,
$cleanup_when_done,	# bool, optional
) = @_;
my $class_refs_ref = $this_ref->[8];


if (!defined $class_refs_ref)
{
reduce_file( $this_ref);

my $reduced_lines_ref = $this_ref->[4];	# $reduced_lines_ref

my @classes = "$$reduced_lines_ref" =~ /
[;\}]		    # end of previous statement
\s*		    # optional whitespace
(			    # capture begin
[<>\s\w]*		    # optional 'template, etc
class		    # class
\s*		    # optional whitespace
[:\s\w<>]+		    # class specification
)			    # capture end
\s*		    # optional whitespace
\{			    # {
/gxs;

my @class_refs;
foreach my $class (@classes)
{
$class =~ s/\s+/ /g;	    # replace all whitespace by 1 space


my ($ctype, $cattrs) = $class =~ /(<.*?>)\s*class\*(.*)/;
$ctype = ''
if (!defined $ctype);
my ($cname) = $class =~ /class (\w*)/;


push @class_refs, [ $ctype, $cname ];
}
$class_refs_ref = \@class_refs;
$this_ref->[8] = $class_refs_ref;
}

PARSE_C_cleanup( $this_ref)
if ($cleanup_when_done);

return (wantarray) ? @{$class_refs_ref} : $class_refs_ref;
}




sub PARSE_C_cleanup($)
{
my ($this_ref,
) = @_;

my $filespec = $this_ref->[0];
if (exists $FILE_REFS{$filespec})
{
delete $FILE_REFS{$filespec};
} else
{
ENV_sig( F => "File '$filespec' not in PARSE_C cache");
}
}




sub reduce_file($)
{
my ($this_ref,
) = @_;

if (!defined $this_ref->[4])		# $reduced_lines_ref
{
my $lines = ${$this_ref->[2]};		# $original_lines_ref





no warnings;    # Use of uninitialized value $2 in substitution iterator at ...
$lines =~ s!$NC_KEEP_RE!$2!gs;
use warnings FATAL => 'all';




$lines =~ s/[ \t\r]+/ /g;




$lines =~ s/^[ \t\r]*#[^\n]*\n/\n/gm;




$lines =~ s/(["'])(?:\\?+.)*?\1/$1$1/g;




$lines =~ s/^\s*\n//;
$lines =~ s/\n\s*\n/\n/g;




my $nr_reduced_lines = $lines =~ tr/\n//;
$this_ref->[5] = $nr_reduced_lines;	    # nr_reduced_lines




$lines = ";\n" . $lines;




$this_ref->[4] = \$lines;	    # reduced_lines_ref



}
}

1;


