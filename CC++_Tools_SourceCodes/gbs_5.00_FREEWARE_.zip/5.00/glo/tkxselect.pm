#=================================================
#
#  tkxselect.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::tkxselect;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
TKXSELECT_list
);
}




use Tkx;


use glo::tkx;
use glo::tkxfont;
use glo::tkxevent;
use glo::tkxafter;
use glo::tkxdirtree;




sub TKXSELECT_list($$$$$$@);

sub double_left_click($$$$$);
sub do_ok($$$);
















sub TKXSELECT_list($$$$$$@)
{
my ($parent,
$prompt,
$help_ref,
$formats_ref,		# [ L, R, C ]
$heads_ref,		# [ <head>, ... ]
$row_refs_ref,
$default_row,		# index
$select_mode,		# 0 = None, 1 == single, 2 = multiple
$select_func,		# select_func->( $selection_ref)
@treeview_args
) = @_;




{
my $this_label = TKX_new_label( $parent, $prompt, -anchor => 'nw');
$this_label->g_pack( -side => 'top', -fill => 'both', -expand => 1);

my $font = $this_label->cget( '-font') || 'TkTextFont';
my $this_font = TKXFONT_actual( $font, $this_label);
$this_font =~ s/-weight \S+/-weight bold/;
$this_label->configure( -font => $this_font);
}




if (defined $help_ref)
{
my $help_line = (ref $help_ref) ? join( "\n", @{$help_ref}) : $help_ref;
TKX_new_label( $parent, $help_line, -anchor => 'nw')->
g_pack( -side => 'top', -fill => 'both', -expand => 1);
}




my ($dirtree_frame, $dt) = TKXDIRTREE_new( $parent, $select_mode, undef);
$dirtree_frame->g_pack( -side => 'top', -fill => 'both', -expand => 1);
TKXEVENT_bind_mouse_left_click_2( $dt, \&double_left_click, $parent, $select_func);




TKXDIRTREE_show_flat( $dt, $formats_ref, $heads_ref, $row_refs_ref, $default_row);




TKX_new_button( $parent, 'Cancel', sub { $parent->g_destroy(); })->
g_pack( -side => 'right');
TKX_new_button( $parent, 'Select', sub { do_ok( $dt, $parent, $select_func); })->
g_pack( -side => 'right');

TKXEVENT_bind_key_return( $parent, sub { do_ok( $dt, $parent, $select_func); });
}




sub double_left_click($$$$$)
{
my ($dt,
$x,
$y,
$parent,
$select_func,
) = @_;

my $selection_ref = TKXDIRTREE_get_selection( $dt);
$select_func->( $selection_ref);
TKXAFTER_idle( sub { $parent->g_destroy() });		# OK!
}




sub do_ok($$$)
{
my ($dt,
$parent,
$select_func,
) = @_;

my $selection_ref = TKXDIRTREE_get_selection( $dt);
$select_func->( $selection_ref);
$parent->g_destroy();
}

1;
