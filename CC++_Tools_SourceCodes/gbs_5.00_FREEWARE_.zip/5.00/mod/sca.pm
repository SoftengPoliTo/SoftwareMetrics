#=================================================
#
#   sca.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::sca;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SCA_read
SCA_init
SCA_read_msgs
SCA_add_msg
SCA_get_filespec
SCA_get_enabled_msgs
SCA_msg_is_enabled
SCA_get_format_name
SCA_get_quiet_paths
SCA_get_threshold_refs
);
}




use glo::env;
use mod::gbsfile;
use mod::gbsfileglo;
use mod::gbsfilecom;
use mod::scamet;
use mod::scadef;




sub SCA_read($);
sub SCA_init($$$);
sub SCA_read_msgs($);
sub SCA_add_msg($);
sub SCA_get_filespec();
sub SCA_get_enabled_msgs();
sub SCA_msg_is_enabled($);
sub SCA_get_format_name();
sub SCA_get_quiet_paths();
sub SCA_get_threshold_refs();

sub read_sca($);
sub read_file($);
sub do_msg_id($$$);
sub do_format($$$);
sub do_quiet($$$);
sub do_metrics_threshold($$$);




my $CUR_SCA_SYSLEVEL = -1;		# 0 = System, 1 = SubSys
my $CUR_SCA_REF;

my @ALL_MSG_IDS;		    # All possible msg_ids
my @SPECIAL_MSG_IDS;		    # @fatal_msg_ids, @specw_msg_ids

my @SCAS = ();











my %SPECIAL_MSG_IDS;	    # used only during read_sca





my @FORMAT_VALUES = qw( NONE DEFAULT PCLINT VISUAL_C GNU_C ECLIPSE);
my %FORMAT_VALUES = map { $_ => 1 } @FORMAT_VALUES;







my %SCA_DEF = (

E	=> [ 1,  0, \&do_msg_id  ],
F	=> [ 0,  1, \&do_format],
Q	=> [ 0,  1, \&do_quiet ],
T   => [ 0,  1, \&do_metrics_threshold ],
);
my @TYPES = sort keys %SCA_DEF;

my @ALL_ENABLED_MSGS;




sub SCA_read($)
{
my ($filespec,
) = @_;

read_file( $filespec);
}




sub SCA_init($$$)
{
my ($all_msg_ids_ref,	    # All possible msg_ids
$fatal_msg_ids_ref,
$specw_msg_ids_ref,
) = @_;





$CUR_SCA_SYSLEVEL = -1;
$CUR_SCA_REF = undef;

$SCAS[0] = [];	# System
$SCAS[1] = [];	# SubSys

@ALL_MSG_IDS = @{$all_msg_ids_ref};
foreach my $msg_id (@ALL_MSG_IDS)
{
$msg_id =~ s/^\s+//;	# Remove leading ws
}
@ALL_MSG_IDS = sort @ALL_MSG_IDS;

@SPECIAL_MSG_IDS = (@{$fatal_msg_ids_ref}, @{$specw_msg_ids_ref});
foreach my $msg_id (@SPECIAL_MSG_IDS)
{
$msg_id =~ s/^\s+//;	# Remove leading ws
}
}




sub SCA_read_msgs($)
{
my ($subsys,
) = @_;

ENV_sig( F => 'SCA_init not executed')
if ($GBS::AUDIT eq '');

read_sca( $subsys);


}





sub SCA_add_msg($)
{
my ($msg_id) = @_;

$msg_id =~ s/^\s+//;
if (!exists $CUR_SCA_REF->[1]->{$msg_id})
{
$CUR_SCA_REF->[1]->{$msg_id} = 1;	# enable
}
}





sub SCA_get_filespec()
{
my @dependencies = @{$CUR_SCA_REF->[6]};
return wantarray ? (@dependencies) : $dependencies[0];	#  @dependencies, $filespec
}




sub SCA_get_enabled_msgs()
{
return @ALL_ENABLED_MSGS;
}




sub SCA_msg_is_enabled($)
{
my ($msg_id,
) = @_;
my $enabled;

$msg_id =~ s/^\s+//;
$enabled = $CUR_SCA_REF->[1]->{$msg_id};

if (!defined $enabled)
{
ENV_sig( E => "Msg $msg_id in $GBS::AUDIT: $GBS::BUILD is not defined in sca_*.gbs");
$enabled = 0;
}

return $enabled;
}




sub SCA_get_format_name()
{
return $CUR_SCA_REF->[2];	    # $wanted_format
}




sub SCA_get_quiet_paths()
{
return @{$CUR_SCA_REF->[3]};    # @quiet_paths
}




sub SCA_get_threshold_refs()
{
return @{$CUR_SCA_REF->[4]};    # @metric_threshold_refs

}




sub read_sca($)
{
my ($subsys,
) = @_;

my $filespec = "$GBS::ROOT_PATH/dev/$subsys/audit/$GBS::AUDIT/sca_$GBS::BUILD";


my $cur_filespec = GBSFILEGLO_select_usr_gbs( $filespec);
if (defined $cur_filespec)
{
$CUR_SCA_SYSLEVEL = 1;	    # Found in SubSystem
} else
{
$filespec = "$GBS::SYSAUDIT_PATH/$GBS::AUDIT/sca_$GBS::BUILD";


$cur_filespec = GBSFILEGLO_select_usr_gbs( $filespec);
if (defined $cur_filespec)
{
$CUR_SCA_SYSLEVEL = 0;  # Found in System
} else
{
$CUR_SCA_SYSLEVEL = 0;  # Assume found in System
}
}

$CUR_SCA_REF = $SCAS[$CUR_SCA_SYSLEVEL];
if ($CUR_SCA_SYSLEVEL == 0 && @{$CUR_SCA_REF})
{

} else
{





$CUR_SCA_REF->[0] = undef;	# Not used anymore
$CUR_SCA_REF->[1] = {};		# $msg_ids
$CUR_SCA_REF->[2] = 'DEFAULT';	# $wanted_format
$CUR_SCA_REF->[3] = [];		# @quiet_list
$CUR_SCA_REF->[4] = [];		# @metric_threshold_refs
$CUR_SCA_REF->[5] = undef;	# Not used anymore
$CUR_SCA_REF->[6] = [];		# @dependencies. First is filespec




map { $CUR_SCA_REF->[1]->{$_} = 1 } @ALL_MSG_IDS;




if (defined $cur_filespec)
{



%SPECIAL_MSG_IDS = map { $_ => 1 } @SPECIAL_MSG_IDS;




foreach my $ref (read_file( $cur_filespec))
{
my ( $do_func_ref, $enable, $type, $values_string ) = @{$ref};



$do_func_ref->( $enable, $type, $values_string);    # do_msg_id, do_format, do_quiet, do_metrics_threshold
}

$CUR_SCA_REF->[6] = [ GBSFILE_get_dependencies() ];

ENV_sig( W => "No Msgs enabled for $GBS::AUDIT: $GBS::BUILD")
if (keys %{$CUR_SCA_REF->[1]} == 0);

%SPECIAL_MSG_IDS = ();	    # cleanup
} else
{
ENV_say( 1, "No SCA file. All messages enabled for $GBS::AUDIT: $GBS::BUILD");
}
@ALL_ENABLED_MSGS = grep $CUR_SCA_REF->[1]->{$_} == 1, @ALL_MSG_IDS;

}
}




sub read_file($)
{
my ($filespec,
) = @_;
my @line_refs;





my $file_path = ENV_split_spec_p( $filespec);
my @inc_path = ($file_path);
my $sysaudit_path = "$GBS::SYSAUDIT_PATH/$GBS::AUDIT";
push @inc_path, $sysaudit_path
if ($file_path ne $sysaudit_path);






GBSFILE_open( $filespec, 0, \@inc_path, undef);	    # $must_exist, $allow_build_line_selection
my $line = GBSFILE_get_line();
while ($line)
{




my ($valid_line, $comment) = split( /\s+[^\\]#/, $line, 2);




my ($op, $values_string) = split( / /, $valid_line, 2);

GBSFILE_sig( EE => "Line syntax = +|-<type> <value(s)>")
if (length( $op) != 2 || !defined $values_string);
my $plus_minus = substr( $op, 0, 1);
my $type = substr( $op, 1, 1);
my $enable = ($plus_minus eq '+') ? 1 : ($plus_minus eq '-') ? 0 : undef;
GBSFILE_sig( EE => "Line syntax = +|-<type> <value(s)>")
if (!defined $enable);




my $sca_ref = $SCA_DEF{$type};
GBSFILE_sig( EE => "Invalid type ($type). Must be one of (@TYPES)")
if (!defined $sca_ref);
my ($spaces_allowed, $enable_only, $do_func_ref) = @{$sca_ref};
GBSFILE_sig( EE => "No whitespace allowed in argument '$values_string'")
if (!$spaces_allowed && $values_string =~ /\s/);
GBSFILE_sig( EE => "Only enable (+) allowed for '$type'")
if ($enable_only && !$enable);




push @line_refs, [ $do_func_ref, $enable, $type, $values_string ];

$line = GBSFILE_get_line();
}

return @line_refs;
}




sub do_msg_id($$$)
{
my ($enable,	# bool: 0 or 1
$type,		# 'E'
$values_string,	# @msg_ids or 'ALL' or wildcard
) = @_;

my @msg_ids = split( / /, $values_string);

foreach my $msg_id (@msg_ids)
{
if ($msg_id eq 'ALL')
{
map { $CUR_SCA_REF->[1]->{$_} = $enable } @ALL_MSG_IDS;
if (!$enable)
{
map { $CUR_SCA_REF->[1]->{$_} = 1 } @SPECIAL_MSG_IDS;	# Allways enable the special messages
}
} else
{
my @these_msg_ids;
if (ENV_is_wildcard( $msg_id))
{
@these_msg_ids = ENV_wildcard( $msg_id, \@ALL_MSG_IDS);
if (@these_msg_ids == 0)
{
GBSFILE_sig( W => "No match for Wild Msg_id $msg_id in $GBS::AUDIT: $GBS::BUILD");
}
} else
{
if (!exists $CUR_SCA_REF->[1]->{$msg_id})
{
GBSFILE_sig( W => "Unknown Msg_id $msg_id in $GBS::AUDIT: $GBS::BUILD");
}
@these_msg_ids = ($msg_id);
}

map { $CUR_SCA_REF->[1]->{$_} = $enable } @these_msg_ids;
if (!$enable)
{
foreach my $this_msg_id (@these_msg_ids)
{
if (exists $SPECIAL_MSG_IDS{$this_msg_id})
{
GBSFILE_sig( I => "Implicit disable of fatal or special message ($this_msg_id)");
}
}
}
}
}

}




sub do_format($$$)
{
my ($enable,	# bool: allways 1
$type,		# 'F'
$value,		# $format
) = @_;

GBSFILE_sig( EE => "Invalid FORMAT value '$value' (@FORMAT_VALUES)")
if (!exists $FORMAT_VALUES{$value});

$CUR_SCA_REF->[2] = $value;			# $wanted_format
}




sub do_quiet($$$)
{
my ($enable,	# bool: allways 1
$type,		# 'Q'
$value,		# $quiet
) = @_;

my $path = GBSFILECOM_validate_path( $value);

push @{$CUR_SCA_REF->[3]}, $path;		# $quiet_paths
}




sub do_metrics_threshold($$$)
{
my ($enable,	# bool: allways 1
$type,		# 'T'
$value,		# $threshold
) = @_;

my ($metric_name, $min_value, $max_value, $msg_id) = uc( $value) =~ /^([A-Z0-9]+)=([\d.]+|)(,[\d.]+|)(:\d+|)$/;

if (defined $metric_name)
{
$max_value = substr( $max_value, 1)	    # remove leading ','
if ($max_value ne '');
$msg_id = substr( $msg_id, 1)	    	    # remove leading ':'
if ($msg_id ne '');
GBSFILE_sig( EE => "At least one Threshold Limit (min and/or max) must be specified")
if ($min_value eq '' && $max_value eq '');

if (SCADEF_metric_is_enabled( $GBS::AUDIT_PLUGIN, $metric_name))
{

push @{$CUR_SCA_REF->[4]}, [ $metric_name, $min_value, $max_value, $msg_id ];	# @metric_threshold_refs
} else
{
if (SCAMET_name_is_valid( $metric_name))
{
GBSFILE_sig( EE => "Metric mnemonic '$metric_name' not enabled")
} else
{
GBSFILE_sig( EE => "Unknown metric: '$metric_name'");
}
}
} else
{
GBSFILE_sig( EE => "Threshold value syntax is: <metric_name>=[<min_value>][,<max_value>][:<msg_id>]");
}
}

1;


