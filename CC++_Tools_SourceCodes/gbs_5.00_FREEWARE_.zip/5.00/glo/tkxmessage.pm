#=================================================
#
#   tkxmessage.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::tkxmessage;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
TKXMESSAGE_ok
TKXMESSAGE_yesno
TKXMESSAGE_about
);
}




use Tkx;
use glo::env;
use glo::tkx;
use glo::tkxglo;
use glo::tkxtext;
use glo::tkxtoplevel;
use glo::tkxevent;




sub TKXMESSAGE_ok($$$);
sub TKXMESSAGE_yesno($$$$);
sub TKXMESSAGE_about($$);

sub message_box($$$$$);
sub do_button($$$);
sub get_icons_data();








my %ICON_REFS = (

info	=> [ undef, 0 ],
warning	=> [ undef, 1 ],
error	=> [ undef, 1 ],
question	=> [ undef, 0 ],
);
my @ALL_ICONS;








sub TKXMESSAGE_ok($$$)
{
my ($title,
$icon,		# error, info (default), question, warning
$text_or_ref,	# can contain '\n'
) = @_;

message_box( $title, $icon, $text_or_ref, [ 'Ok' ], 0);

return;

my $text = (ref $text_or_ref) ? join( "\n", @{$text_or_ref}) : $text_or_ref;
Tkx::tk___messageBox( -type => 'ok',	# abortretryignore, ok, okcancel, retrycancel, yesno, yesnocancel
-title => $title,
-message => $text,
-icon => $icon,
);
}




sub TKXMESSAGE_yesno($$$$)
{
my ($title,
$icon,		# error, info (default), question, warning
$text_or_ref,	# can contain '\n'
$default,	# 'yes' or 'no'
) = @_;
my $ans;		# 'yes' or 'no'

my $button = message_box( $title, 'info', $text_or_ref, [ qw( Yes No ) ], 0);

return;

my $text = (ref $text_or_ref) ? join( "\n", @{$text_or_ref}) : $text_or_ref;
$ans = Tkx::tk___messageBox( -type => 'yesno',	# abortretryignore, ok, okcancel, retrycancel, yesno, yesnocancel
-title => $title,
-message => $text,
-icon => $icon,
-default => $default,
);
return $ans;
}




sub TKXMESSAGE_about($$)
{
my ($title,
$text_or_ref,	# can contain '\n'
) = @_;

my $button = message_box( $title, 'info', $text_or_ref, [ 'Ok' ], 0);

return;

my $text = (ref $text_or_ref) ? join( "\n", @{$text_or_ref}) : $text_or_ref;
Tkx::tk___messageBox( -type => 'ok',	# abortretryignore, ok, okcancel, retrycancel, yesno, yesnocancel
-title => $title,
-message => $text,
-icon => 'info');
}




sub message_box($$$$$)
{
my ($title,
$icon,			# error, info (default), question, warning
$text_or_ref,		# can contain '\n'
$buttons_ref,		# [ button1, $button2, ... ] From right to left
$default_button_index,	# button in $buttons_ref
) = @_;
my $button = '';		# Lowercase! '' if the window is X-ed

my $widget = Tkx::focus();




get_icons_data()
if (!@ALL_ICONS);
my $icon_ref = $ICON_REFS{$icon};
ENV_sig( F => "Invalid icon '$icon'. Allowed (@ALL_ICONS)")
if (!defined $icon_ref);




if (@{$buttons_ref} == 1)
{
$button = $buttons_ref->[0];
} else
{
foreach my $this_button (@{$buttons_ref})
{
if (grep( $_ eq lc $this_button, qw(no quit cancel)))
{
$button = $this_button;
last;
}
}
}




my @geo = TKXGLO_geo_center_window( $TKX::MW, [ 470, 220, undef, undef ] );   # (width, height, x, y)




my $this_tl = TKXTOPLEVEL_new( $TKX::MW,
$title,	# Title
[ @geo ],	# geometry (width, height, x, y)
1,		# transient
undef,	# sub { $button = $default_for_x  },	# delete_window_command
);




my $sound = $icon_ref->[1];
if ($sound)
{
TKX_bell();
}




my $bf = $this_tl->new_ttk__frame( -padding => 10 );
$bf->g_pack( -side => 'bottom', -fill => 'both');




my $text_frame = $this_tl->new_ttk__frame();
$text_frame->g_pack( -side => 'top', -fill => 'both');




my $icon_image = TKXGLO_photo( $icon);
my $icon_label = TKX_new_label( $text_frame, 'Icon', -image => $icon_image, -anchor => 'n',
-padding => 20, -background => 'white');
$icon_label->g_grid( -row => 0, -column => 0, -sticky => 'news');




my $tw = TKXTEXT_new( $text_frame, -relief => 'flat', -padx => 2, -pady => 10);
$tw->g_grid( -row => 0, -column => 1, -sticky => 'news');
$text_frame->g_grid_columnconfigure( 1, -weight => 1);	    # make sure the text frame resizes
TKXTEXT_insert_end( $tw, TkTextFont => $text_or_ref);




foreach my $this_button (@{$buttons_ref})
{
my $bw = TKX_new_button( $bf, $this_button, [ \&do_button, $this_tl, $this_button, \$button ]);
$bw->g_pack( -side => 'right');
}
if (defined $default_button_index)
{
my $default_button = $buttons_ref->[$default_button_index];
TKXEVENT_bind_key_return( $this_tl, sub { do_button( $this_tl, $default_button, \$button) });
}

TKXTOPLEVEL_show( $this_tl);




TKX_wait_window_destroyed( $this_tl);
$button = lc $button;


return $button;
}




sub do_button($$$)
{
my ($this_tl,
$button_name,
$button_ref,
) = @_;

$$button_ref = $button_name;

$this_tl->g_destroy();
}




sub get_icons_data()
{
my $application_scripts_path = ENV_get_application_scripts_path();
while (my ($icon, $value_ref) = each %ICON_REFS)
{
my $icon_photo = TKXGLO_photo( $icon => "$application_scripts_path/glo/msg_$icon.gif");
$ICON_REFS{$icon}->[0] = $icon_photo;
}
@ALL_ICONS = sort keys %ICON_REFS;
}

1;

