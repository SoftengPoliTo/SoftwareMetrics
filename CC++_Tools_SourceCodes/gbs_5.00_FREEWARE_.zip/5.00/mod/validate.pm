#=================================================
#
#   validate.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::validate;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
VALIDATE_gbs
VALIDATE_root
VALIDATE_subsys
VALIDATE_subsys_full_gbs
VALIDATE_subsys_audit
VALIDATE_component
VALIDATE_build
VALIDATE_build_no_subsys
VALIDATE_builds
VALIDATE_audit
VALIDATE_audit_no_subsys
VALIDATE_audits
VALIDATE_tool
VALIDATE_tool_no_subsys
VALIDATE_tools
VALIDATE_integrator
VALIDATE_administrator
);
}




use glo::env;
use glo::list;
use glo::ask;
use mod::gbsenv;
use mod::gbsglo;




sub VALIDATE_gbs();
sub VALIDATE_root();
sub VALIDATE_subsys();
sub VALIDATE_subsys_full_gbs();
sub VALIDATE_subsys_audit();
sub VALIDATE_component();
sub VALIDATE_build();
sub VALIDATE_build_no_subsys();
sub VALIDATE_builds($);
sub VALIDATE_audit($);
sub VALIDATE_audit_no_subsys($);
sub VALIDATE_audits($);
sub VALIDATE_tool($);
sub VALIDATE_tool_no_subsys($);
sub VALIDATE_tools($);
sub VALIDATE_integrator();
sub VALIDATE_administrator();

sub validate_user($$);




my $ROOT_VALIDATED = 0;




sub VALIDATE_gbs()
{
ENV_sig( EE => "Unable to continue: GBS is not active")
if (!GBSENV_gbs_is_active());
}




sub VALIDATE_root()
{
if (!$ROOT_VALIDATED)
{
VALIDATE_gbs();
ENV_sig( EE => "Unable to continue: No current Root")
if ($GBS::ROOT_PATH eq "");
ENV_sig( EE => "Root '$GBS::ROOT_PATH' does not exist (anymore)")
if (! -e $GBS::ROOT_PATH);
$ROOT_VALIDATED = 1;
}
}




sub VALIDATE_subsys()
{
VALIDATE_root();
ENV_sig( EE => "Unable to continue: No current SubSystem")
if ($GBS::SUBSYS eq "");
ENV_sig( EE => "SubSys '$GBS::SUBSYS' does not exist (anymore)")
if (! -e $GBS::SUBSYS_PATH);
}




sub VALIDATE_subsys_full_gbs()
{
VALIDATE_subsys();

ENV_sig( EE => "This command is only possible for full GBS Subsystems")
if (! GBSGLO_subsystem_is_full_gbs( $GBS::SUBSYS));
}




sub VALIDATE_subsys_audit()
{
VALIDATE_subsys_full_gbs();

ENV_sig( EE => "No Audit(s) defined for SubSystem '$GBS::SUBSYS'")
if (!scalar ENV_glob "$GBS::SUBSYS_PATH/audit/*");
}




sub VALIDATE_component()
{
my $component;

VALIDATE_subsys_full_gbs();

ENV_sig( EE => "Unable to continue: No current Component")
if ($GBS::COMPONENT eq "");
ENV_sig( EE => "Component '$GBS::COMPONENT' does not exist (anymore)")
if (! -e $GBS::COMPONENT_PATH);
}




sub VALIDATE_build()
{
VALIDATE_build_no_subsys();

if ($GBS::SUBSYS ne '')
{
ENV_sig( EE => "SubSystem ($GBS::SUBSYS) does not generate for Build '$GBS::BUILD'")
if (! GBSGLO_subsystem_does_build( $GBS::SUBSYS, $GBS::BUILD));
}
}




sub VALIDATE_build_no_subsys()
{
ENV_sig( EE => "Unable to continue: No current Build")
if ($GBS::BUILD eq "");
ENV_sig( EE => "No such Build '$GBS::BUILD' (@GBS::BUILDS)")
if (! -d "$GBS::ROOT_PATH/sysbuild/$GBS::BUILD");
}






sub VALIDATE_builds($)
{
my ($in_builds_ref) = @_;		# (possibly wild) Builds, '.' == current, '-' = None
my @out_builds;

$in_builds_ref = [ $in_builds_ref ]
if (! ref $in_builds_ref);

ENV_sig( EE => "No Builds defined")
if (!@GBS::ALL_BUILDS);
ENV_sig( EE => "No Builds defined for this Platform ($^O)")
if (!@GBS::BUILDS);


foreach my $build (@{$in_builds_ref})
{
if ($build eq '.')
{
ENV_sig( EE => "No current Build")
if ($GBS::BUILD eq '');
push @out_builds, $GBS::BUILD;
} elsif ($build eq '-')
{
push @out_builds, $build;
} else
{
my @exp_builds = ENV_wildcard( $build, [ @GBS::BUILDS ]);
if (!@exp_builds)
{
@exp_builds = ENV_wildcard( $build, [ @GBS::ALL_BUILDS ]);
if (@exp_builds)
{
ENV_sig( EE => "No such Build '$build' for this Platform ($^O)");
} else
{
ENV_sig( EE => "No such Build '$build' (@GBS::BUILDS)");
}
}
push @out_builds, @exp_builds;
}
}

if (@out_builds)
{
LIST_unique( \@out_builds);
} else
{
ENV_sig( EE => "No current Build")
if ($GBS::BUILD eq '');
@out_builds = ($GBS::BUILD);
}

if (wantarray)
{
return @out_builds;
} else
{
if (@out_builds == 1)
{
return $out_builds[0];
} else
{
ENV_sig( EE => "Cannot specify multiple Builds (@out_builds)");
}
}
}




sub VALIDATE_audit($)
{
my ($audit) = @_;

VALIDATE_audit_no_subsys( $audit);
ENV_sig( EE => "SubSystem ($GBS::SUBSYS) does not audit for Audit '$audit' and Build '$GBS::BUILD'")
if (! GBSGLO_subsystem_does_audit( $GBS::SUBSYS, $audit, $GBS::BUILD));
}






sub VALIDATE_audit_no_subsys($)
{
my ($audit) = @_;

ENV_sig( EE => "No such Audit '$audit' (@GBS::ALL_AUDITS)")
if (! -d "$GBS::ROOT_PATH/sysaudit/$audit");
}






sub VALIDATE_audits($)
{
my ($in_audits_ref) = @_;		# (possibly wild) Audits, '.' == current, '-' = None
my @out_audits;

$in_audits_ref = [ $in_audits_ref ]
if (! ref $in_audits_ref);

ENV_sig( EE => "No Audits defined")
if (!@GBS::ALL_AUDITS);
ENV_sig( EE => "No Audits defined for this Platform ($^O)")
if (!@GBS::AUDITS);

foreach my $audit (@{$in_audits_ref})
{
if ($audit eq '.')
{
ENV_sig( EE => 'No current Audit')
if ($GBS::AUDIT eq '');
push @out_audits, $GBS::AUDIT;
} elsif ($audit eq '-')
{
push @out_audits, $audit;
} else
{
my @exp_audits = ENV_wildcard( $audit, \@GBS::ALL_AUDITS );
ENV_sig( EE => "No such Audit '$audit' (@GBS::ALL_AUDITS)")
if (!@exp_audits);
push @out_audits, @exp_audits;
}
}

if (@out_audits)
{
LIST_unique( \@out_audits);
}

if (wantarray)
{
return @out_audits;
} else
{
if (@out_audits == 1)
{
return $out_audits[0];
} else
{
ENV_sig( EE => "Cannot specify multiple Audits (@out_audits)");
}
}
}






sub VALIDATE_tool($)
{
my ($tool) = @_;

VALIDATE_tool_no_subsys( $tool);
ENV_sig( EE => "SubSystem ($GBS::SUBSYS) does not execute Tool '$tool'")
if (! GBSGLO_subsystem_does_tool( $GBS::SUBSYS, $tool));
}






sub VALIDATE_tool_no_subsys($)
{
my ($tool) = @_;

ENV_sig( EE => "No such TOOL '$tool' (@GBS::ALL_TOOLS)")
if (! -d "$GBS::ROOT_PATH/systool/$tool");
}






sub VALIDATE_tools($)
{
my ($in_tools_ref) = @_;		# (possibly wild) Tools, '.' == current, '-' = None
my @out_tools;

$in_tools_ref = [ $in_tools_ref ]
if (! ref $in_tools_ref);

ENV_sig( EE => "No Tools defined")
if (!@GBS::ALL_TOOLS);
ENV_sig( EE => "No Tools defined for this Platform ($^O)")
if (!@GBS::TOOLS);

foreach my $tool (@{$in_tools_ref})
{
if ($tool eq '.')
{
ENV_sig( EE => 'No current Tool')
if ($GBS::TOOL eq '');
push @out_tools, $GBS::TOOL;
} elsif ($tool eq '-')
{
push @out_tools, $tool;
} else
{
my @exp_tools = ENV_wildcard( $tool, \@GBS::ALL_TOOLS );
ENV_sig( EE => "No such Tool '$tool' (@GBS::ALL_TOOLS)")
if (!@exp_tools);
push @out_tools, @exp_tools;
}
}

if (@out_tools)
{
LIST_unique( \@out_tools);
}

if (wantarray)
{
return @out_tools;
} else
{
if (@out_tools == 1)
{
return $out_tools[0];
} else
{
ENV_sig( EE => "Cannot specify multiple Tools (@out_tools)");
}
}
}




sub VALIDATE_integrator()
{
return validate_user( GBSENV_is_integrator(), 'Integrator');
}




sub VALIDATE_administrator()
{
return validate_user( GBSENV_is_administrator(), 'Administrator');
}




sub validate_user($$)
{
my ($is_ok,
$user_type, 	# 'Administrator', 'Integrator'
) = @_;


if (!$is_ok)
{
ENV_beep();
ENV_say( 1, "**");
ENV_say( 1, "** Warning: You are not an $user_type for this System");
ENV_say( 1, "**");
$is_ok = (ASK_YN( "Continue anyway?", 'N') eq 'Y');

ENV_sig( WE =>) if (!$is_ok && !defined wantarray)
}

return $is_ok;
}

1;

