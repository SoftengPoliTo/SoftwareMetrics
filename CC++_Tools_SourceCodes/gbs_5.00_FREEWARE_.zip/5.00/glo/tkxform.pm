#=================================================
#
#  tkxform.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::tkxform;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
TKXFORM_dialogue
TKXFORM_get_value
TKXFORM_store_value
TKXFORM_store_combo_values
TKXFORM_set_state
TKXFORM_get_changed_values
TKXFORM_destroy
);
}




use Tkx;

use glo::env;
use glo::types;
use glo::format;
use glo::tkx;
use glo::tkxmessage;
use glo::tkxtoplevel;
use glo::tkxentry;
use glo::tkxevent;




sub TKXFORM_dialogue($$$$;$$$);
sub TKXFORM_get_value($$);
sub TKXFORM_store_value($$$;$);
sub TKXFORM_store_combo_values($$$;$$);
sub TKXFORM_set_state($$$);
sub TKXFORM_get_changed_values($);
sub TKXFORM_destroy($);

sub do_form_post_checkbutton($$$);
sub do_form_post_entry($$$$);
sub do_ok($);
sub do_cancel($);
sub do_reset($);








my %DEFAULT_WIDTHS = (

s	=>  40,
i	=>  6,
t	=>  8,
);

my %STATES = (
''		=> '',		# normal
0		=> 'disable',
1		=> '',		# normal
2		=> 'readonly',
disable	=> 'disable',
normal	=> '',		# normal
readonly	=> 'readonly',
);




my %FORM_REFS;




















END
{
ENV_dump( FORM_REFS => \%FORM_REFS, 3)
if (%FORM_REFS);
}




sub TKXFORM_dialogue($$$$;$$$)
{
my ($parent,
$form_name,
$mnem_refs_ref,	    # [ $mnem_value_ref, $mnem, $opt_name, $type_spec_or_ref, $default, $item_help_or_ref, $enabled, $post_func_or_ref, $this_widget ]





























$action_func,	    # OK function for non-blocking (non-modal) dialogue. undef == blocking (modal) dialogue
$validate_func,	    # Optional: Function to call for <OK>. my $is_ok = $func->( $form_name );
$help_text_ref,	    # Optional. May be undef
$extra_text_ref,    # Optional. May be undef
) = @_;
my $form_ref;	    # if (!$action_func) [ $this_tl, $form_name, $mnem_refs_ref, $mnem_hash_ref, $validate_func, $action_func, $ok_or_cancel];
my @values;		    # if ($action_func)



my $this_tl;
my %mnem_hash;


my @help_text = ENV_deref( $help_text_ref);




my ($width, $height, $x, $y) = TKX_geometry( $parent);
my $tlw_x = $x + ($width / 3);
my $tlw_y = $y + 40;
$this_tl = TKXTOPLEVEL_new( $parent,
"GBSGUI: $form_name",			# Title
[ undef, undef, $tlw_x, $tlw_y ],	# geometry
1,					# transient
sub { TKXFORM_destroy( $form_name) },	# delete_window_command
);

my $ok_or_cancel = undef;
$form_ref = [ $this_tl, $form_name, $mnem_refs_ref, \%mnem_hash, $validate_func, $action_func, $ok_or_cancel ];
$FORM_REFS{$form_name} = $form_ref;

my $mnems_frame = $this_tl->new_ttk__frame( -relief => 'sunken', -borderwidth => 3);
$mnems_frame->g_pack( -side => 'top', -fill => 'x');




my $row = 0;
TKX_new_label( $mnems_frame, join( "\n", @help_text), -anchor => 'nw')->
g_grid( -row => $row, -column => 0, -sticky => 'ew', -columnspan => 4);
$row++;
$mnems_frame->new_ttk__separator( -orient => 'horizontal')->
g_grid( -row => $row, -column => 0, -sticky => 'ew', -columnspan => 4);
$row++;





my $mnem_index = 0;
foreach my $ref (@{$mnem_refs_ref})
{
my ($mnem_value_ref, $mnem, $opt_name, $type_spec_or_ref, $default, $item_help_or_ref, $enabled, $post_func_or_ref) = @{$ref};
if (!defined $mnem_value_ref)
{
my $this_mnem_value;
$mnem_value_ref = \$this_mnem_value;
$ref->[0] = $mnem_value_ref;
}
$mnem = $mnem_index
if ($mnem eq '');
$opt_name = $mnem
if ($opt_name eq '');
my $type_spec_ref = TYPES_split( $type_spec_or_ref);
$ref->[3] = TYPES_split_and_validate( $type_spec_or_ref)  # $type_spec_or_ref
if (!ref $ref->[3]);
if (!defined $enabled)
{
$enabled = 1;
$ref->[6] = $enabled;
}

my ($type, $occur, $manda, $constr, $constr_values_ref) = @{$type_spec_ref};
my ($ask_func, $post_func) = (ref $post_func_or_ref eq 'ARRAY') ? @{$post_func_or_ref} : (undef, $post_func_or_ref);
$mnem_hash{$mnem} = $ref;




TKX_new_label( $mnems_frame, $opt_name, -anchor => 'nw')->
g_grid( -row => $row, -column => 0, -sticky => 'ew')
if ($opt_name ne $mnem);
TKX_new_label( $mnems_frame, "  $mnem :  ", -anchor => 'ne')->
g_grid( -row => $row, -column => 1, -sticky => 'ew');




if (!defined $mnem_value_ref)
{
my $mnem_value;
$mnem_value_ref = \$mnem_value;
}
$$mnem_value_ref = $default
if (!defined $$mnem_value_ref);
my @entry_args = ($enabled) ? () : ( -state => 'disabled');
my $this_entry;
if (defined $ask_func)
{
ENV_sig( F => "$mnem: 'ask_func' not implemented yet");
} else
{
if ($type eq 'b')   # bool
{
my $post_func_ref = [ \&do_form_post_checkbutton, $post_func, $mnem, $form_ref ];
$this_entry = TKX_new_checkbutton( $mnems_frame, $mnem_value_ref, $post_func_ref, @entry_args);
} else # type eq 's', 'i' or 't'
{
my $post_func_ref = [ \&do_form_post_entry, $post_func, $mnem, $form_ref ];
my $default_width = $DEFAULT_WIDTHS{$type};
$this_entry = TKXENTRY_new( $mnems_frame, $mnem_value_ref, $default_width, $default,
$opt_name, $type_spec_ref, $post_func_ref, @entry_args);
}
}
$ref->[8] = $this_entry;		# $this_widget
$this_entry->g_grid( -row => $row, -column => 2, -sticky => 'w');




{
my $help_frame = $mnems_frame->new_ttk__frame( -relief => 'sunken', -borderwidth => 1);
$help_frame->g_grid( -row => $row, -column => 3, -sticky => 'ew');
my @item_help = ENV_deref( $item_help_or_ref);
my $qmark = (@item_help) ? ' ? ' : '   ';
TKX_new_label( $help_frame, $qmark, -anchor => 'nw')->g_pack();
TKX_tooltip( $help_frame, $item_help_or_ref)
if (@item_help);
}
$row++;
$mnem_index++;
}




if (defined $extra_text_ref)
{
my @extra_text = ENV_deref( $extra_text_ref);
$mnems_frame->new_ttk__separator( -orient => 'horizontal')->
g_grid( -row => $row, -column => 0, -sticky => 'ew', -columnspan => 4);
$row++;
TKX_new_label( $mnems_frame, join( "\n", @extra_text), -anchor => 'nw')->
g_grid( -row => $row, -column => 0, -sticky => 'ew', -columnspan => 4);
$row++;
}

$mnems_frame->new_ttk__separator( -orient => 'horizontal')->
g_grid( -row => $row, -column => 0, -sticky => 'ew', -columnspan => 4);
$row++;




TKX_new_button( $this_tl, 'Cancel', [ \&do_cancel, $form_name ])->
g_pack( -side => 'right');
TKX_new_button( $this_tl, 'Ok',     [ \&do_ok, $form_name ])->
g_pack( -side => 'right');
TKX_new_button( $this_tl, 'Reset',  [ \&do_reset, $form_name ])->
g_pack( -side => 'left');

TKXEVENT_bind_key_return( $this_tl, sub { do_ok( $form_name) });

TKXTOPLEVEL_show( $this_tl);




my $first_widget = $mnem_refs_ref->[0]->[8];    # $this_widget
$first_widget->g_focus;

if (defined $action_func)
{




return $form_ref;
} elseS
{




TKX_wait_window_destroyed( $this_tl);	# (OK or Cancel)

my $ok_or_cancel = $form_ref->[6];
if ($ok_or_cancel eq 'OK')
{
@values = map { ${$_->[0]} } @{$mnem_refs_ref};   # $mnem_value_ref
}
delete $FORM_REFS{$form_name};

return (wantarray ? @values : $values[0]);
}
}




sub do_form_post_checkbutton($$$)
{
my ($this_widget,
$newer_value,
@post_func_args	    	# ( $post_func, $mnem, $form_ref )
) = @_;
my ($is_ok, $error_text, $newest_value) = ( 1, undef, undef );



my ($post_func, $mnem, $form_ref) = @post_func_args;
if (defined $post_func)
{
($is_ok, $error_text) = $post_func->( $this_widget, $newer_value, $mnem, $form_ref);
}




return ($is_ok, $error_text);
}




sub do_form_post_entry($$$$)
{
my ($this_widget,
$validate_action,
$newer_value,
@post_func_args,	# ( $post_func, $mnem, $form_ref )
) = @_;
my ($is_ok, $error_text, $newest_value) = ( 1, undef, undef );



my ($post_func, $mnem, $form_ref) = @post_func_args;
if (defined $post_func)
{
($is_ok, $error_text, $newest_value) = $post_func->( $this_widget, $validate_action, $newer_value, $mnem, $form_ref);
}




return ($is_ok, $error_text, $newest_value);
}




sub TKXFORM_get_value($$)
{
my ($form_name_or_ref,
$mnem,
) = @_;
my ($value, $type, $occur);

my $form_ref = (ref $form_name_or_ref) ? $form_name_or_ref : $FORM_REFS{$form_name_or_ref};


my $mnem_hash_ref = $form_ref->[3];
my $mnem_ref = $mnem_hash_ref->{$mnem};

my ($mnem_value_ref, undef, undef, $type_spec_ref) = @{$mnem_ref};

$value = $$mnem_value_ref;

if (wantarray)
{
($type, $occur) = @{$type_spec_ref};
return ($value, $type, $occur);
} else
{
return $value;
}
}




sub TKXFORM_store_value($$$;$)
{
my ($form_name_or_ref,
$mnem,
$value,
$state,			# Optional, Undef == no change. 0 == 'disable', 1 == 'normal', 2 = 'readonly'
) = @_;
my $old_value;

my $form_ref = (ref $form_name_or_ref) ? $form_name_or_ref : $FORM_REFS{$form_name_or_ref};


my $mnem_hash_ref = $form_ref->[3];
my $mnem_ref = $mnem_hash_ref->{$mnem};

my ($mnem_value_ref, undef, undef, $type_spec_ref) = @{$mnem_ref};


$old_value = $$mnem_value_ref;
$$mnem_value_ref = $value;

if (defined $state)
{
my $new_state = $STATES{$state};
ENV_sig( F => "Invalid state '$state'")
if (!defined $new_state);
my $this_widget = $mnem_ref->[8];
$this_widget->configure( -state => $new_state);
}

return $old_value;
}




sub TKXFORM_store_combo_values($$$;$$)
{
my ($form_name_or_ref,
$mnem,
$combo_values_ref,
$value,			# Optional. Undef == no change
$state,			# Optional, Undef == no change. 0 == 'disable', 1 == 'normal', 2 = 'readonly'
) = @_;
my $old_value;

my $form_ref = (ref $form_name_or_ref) ? $form_name_or_ref : $FORM_REFS{$form_name_or_ref};


my $mnem_hash_ref = $form_ref->[3];
my $mnem_ref = $mnem_hash_ref->{$mnem};

my ($mnem_value_ref, undef, undef, $type_spec_ref) = @{$mnem_ref};
my (undef, undef, undef, $constr, $constr_values_ref) = TYPES_split( $type_spec_ref);
@{$constr_values_ref} = @{$combo_values_ref};
my $this_widget = $mnem_ref->[8];

$this_widget->configure( -values => $combo_values_ref);

$old_value = $$mnem_value_ref;




if (defined $value)
{
$$mnem_value_ref = $value;
}




if (defined $state)
{
my $new_state = $STATES{$state};
ENV_sig( F => "Invalid state '$state'")
if (!defined $new_state);
$this_widget->configure( -state => $new_state);
}

return $old_value;
}



sub TKXFORM_set_state($$$)
{
my ($form_name_or_ref,
$mnem,
$state,			# Optional, Undef == no change. 0 == 'disable', 1 == 'normal', 2 = 'readonly'
) = @_;
my $old_state;

my $form_ref = (ref $form_name_or_ref) ? $form_name_or_ref : $FORM_REFS{$form_name_or_ref};


my $mnem_hash_ref = $form_ref->[3];
my $mnem_ref = $mnem_hash_ref->{$mnem};

my $this_widget = $mnem_ref->[8];

$old_state = $this_widget->configure( -state)
if (defined wantarray);




if (defined $state)
{
my $new_state = $STATES{$state};
ENV_sig( F => "Invalid state '$state'")
if (!defined $new_state);
$this_widget->configure( -state => $new_state);
}

return $old_state;
}





sub TKXFORM_get_changed_values($)
{
my ($form_name_or_ref,
) = @_;
my @changed_value_refs;


my $form_ref = (ref $form_name_or_ref) ? $form_name_or_ref : $FORM_REFS{$form_name_or_ref};


my ( $this_tl, $form_name, $mnem_refs_ref ) = @{$form_ref};
foreach my $mnem_ref (@{$mnem_refs_ref})
{

my ($mnem_value_ref, $mnem, $opt_name, $type_spec_ref, $default) = @{$mnem_ref};
if ($$mnem_value_ref ne $default)
{
push @changed_value_refs, [ $$mnem_value_ref, $mnem, $opt_name, $type_spec_ref, $default ];
}
}

return @changed_value_refs;
}




sub TKXFORM_destroy($)
{
my ($form_name_or_ref,
) = @_;


my $form_name;
my $form_ref;
if (ref $form_name_or_ref)
{
$form_ref = $form_name_or_ref;
$form_name = $form_ref->[1];
} else
{
$form_ref = $FORM_REFS{$form_name_or_ref};
$form_name = $form_name_or_ref;
}

my $this_tl = $form_ref->[0];

$this_tl->g_destroy();
delete $FORM_REFS{$form_name};

return; # Needed to prevent 'Use of uninitialized value in subroutine entry at C:/MyPrograms/Perl64/v5.16/lib/Tkx.pm line 347."
}




sub do_ok($)
{
my ($form_name,
) = @_;




{
my $form_ref = $FORM_REFS{$form_name};
my ($this_tl, $form_name, $mnem_refs_ref, $mnem_hash_ref, $validate_func, $action_func, $ok_or_cancel) = @{$form_ref};

my $all_ok = 1;
my $first_error_mnem;



{
my @error_rows;
foreach my $ref (@{$mnem_refs_ref})
{
my ($mnem_value_ref, $mnem, $opt_name, $type_spec_ref, $default, $item_help_or_ref, $enabled, $post_func_or_ref, $this_widget) = @{$ref};
if ($type_spec_ref->[0] eq 'b')   # $type
{

} else
{
my $mnem_value = $$mnem_value_ref;
if ($mnem_value ne '')
{



my $error_text;
TYPES_get_values( $opt_name, $$mnem_value_ref, $type_spec_ref, \$error_text);
if (!defined $error_text)
{
if (defined $post_func_or_ref)
{




(undef, $error_text, undef) = ENV_call( $post_func_or_ref,
[ $this_widget, 'focusout', $mnem_value, $mnem, $form_ref ]);
}
}
if (defined $error_text)
{
if ($opt_name eq $mnem)
{
push @error_rows, [ "- [b]$opt_name:[/b] ", $error_text ];
} else
{
push @error_rows, [ "- [b]$opt_name", "$mnem:[/b] ", $error_text ];
}
$first_error_mnem = $mnem
if (!defined $first_error_mnem);
}
}
}
}
if (@error_rows)
{
TKX_update();
TKXMESSAGE_ok( 'Values check', 'error', [ 'The following error(s) were found:',
FORMAT_table( 0, 0, ' ', undef, @error_rows) ]);
$all_ok = 0;
}
}




if ($all_ok)
{
my @error_rows;
foreach my $ref (@{$mnem_refs_ref})
{
my ($mnem_value_ref, $mnem, $opt_name, $type_spec_ref) = @{$ref};
if ($$mnem_value_ref eq '')
{
if ($type_spec_ref->[2] eq 'm')	# $manda
{
if ($opt_name eq $mnem)
{
push @error_rows, [ "- [b]$opt_name:[/b]" ];
} else
{
push @error_rows, [ "- [b]$opt_name", "$mnem:[/b]" ];
}
$first_error_mnem = $mnem
if (!defined $first_error_mnem);
}
}
}
if (@error_rows)
{
TKXMESSAGE_ok( 'Mandatories', 'error', [ 'The following mandatory item(s) have no value:',
FORMAT_table( 0, 0, ' ', undef, @error_rows) ]);
$all_ok = 0;
}
}




if ($all_ok && defined $validate_func)
{

$all_ok = $validate_func->( $form_ref);
}





if ($all_ok)
{
TKXTOPLEVEL_hide( $this_tl);


if (defined $action_func)
{




$action_func->( $form_name);
$this_tl->g_destroy();
delete $FORM_REFS{$form_name};
} else
{




$this_tl->g_destroy();
$this_tl = undef;
$FORM_REFS{$form_name}->[0] = $this_tl;

$form_ref->[6] = 'OK';		    # $ok_or_cancel
}
} else
{
my $first_error_widget = $mnem_hash_ref->{$first_error_mnem}->[8];    # $this_widget
$first_error_widget->g_focus;
}
}

return;	# Needed to prevent 'Use of uninitialized value in subroutine entry at C:/MyPrograms/Perl64/v5.16/lib/Tkx.pm line 347."
}




sub do_cancel($)
{
my ($form_name,
) = @_;



{
my $form_ref = $FORM_REFS{$form_name};
my ($this_tl, $form_name, $mnem_refs_ref, $mnem_hash_ref, $validate_func, $action_func, $ok_or_cancel) = @{$form_ref};

if (defined $action_func)
{




$this_tl->g_destroy();
delete $FORM_REFS{$form_name};
} else
{




$this_tl->g_destroy();
$this_tl = undef;
$FORM_REFS{$form_name}->[0] = $this_tl;

$form_ref->[6] = 'CANCEL';		    # $dialog_result = cancel
}
}
return;	# Needed to prevent 'Use of uninitialized value in subroutine entry at C:/MyPrograms/Perl64/v5.16/lib/Tkx.pm line 347."
}




sub do_reset($)
{
my ($form_name,
) = @_;

if (!defined TKXENTRY_get_invalid())
{






ENV_say( 1, 'Reset not implemented yet');
}
}

1;
