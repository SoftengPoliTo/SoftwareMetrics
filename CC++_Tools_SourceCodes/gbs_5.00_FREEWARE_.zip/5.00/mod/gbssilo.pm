#=================================================
#
#   gbssilo.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbssilo;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSSILO_create_index
GBSSILO_view_index
);
}




use glo::env;
use glo::html;
use glo::spit;
use glo::slurp;
use glo::time;
use glo::file;
use mod::gbshtml;
use mod::run;




sub GBSSILO_create_index();
sub GBSSILO_view_index();

sub do_topdir($);




my $INDEX_FILE_SPEC = "$GBS::SILO_PATH/index.html";

my $NOW_DATETIME = TIME_time2num();	# YYYYY-MM-DD-HH:MM:SS

my @SECTION_REFS;





sub GBSSILO_create_index()
{
ENV_say( 1, 'Creating Index...');




{
my @types_refs = (

[ gbssysbuild   => '.log' ],
[ gbssysaudit   => '.log & .html' ],
[ gbssystool    => '.log' ],
[ gbsaudit	    => '.html' ],
);
my @section = ('GBS Log Overviews');

foreach my $ref (@types_refs)
{
my ($name, $types) = @{$ref};
my $filespec = "$GBS::SILO_PATH/.gbs/gbssum/$name.html";
if (-e $filespec)
{
push @section, [ $filespec, "$name ($types)" ];
}
}
push @SECTION_REFS, [ @section ];




map { unlink( "$GBS::SILO_PATH/.gbs/gbssum/$_.html") } (qw( build audit tool gen));
}




foreach my $dir (SLURP_dir_dirs( $GBS::SILO_PATH, 0))
{
do_topdir( $dir);
}




my @lines;




my $head_title = "Silo - $GBS::SYSTEM_NAME [$GBS::ROOT_PARENT]";

push @lines, GBSHTML_doc_start( $INDEX_FILE_SPEC, $head_title, 0, '', undef); # $want_scripts, $body_class, $target_frame_name
push @lines, GBSHTML_doc_top( [ $head_title,  HTML_link( $GBS::LOG_PATH, HTML_bold( 'GBS Log Directory'))],
( [ "Date: $NOW_DATETIME", '', '' ],
));

my $section = 1;




my $nr_sections = @SECTION_REFS;
if ($nr_sections > 0)
{
foreach my $ref (@SECTION_REFS)
{
my ($section_name, @item_refs) = @{$ref};
my $next_section = ($section < $nr_sections) ? $section++ : undef;
push @lines, GBSHTML_h( 1, undef, $section_name, $next_section);
if (@item_refs)
{
my @li_lines;
foreach my $item_ref (@item_refs)
{
my ($filespec, $title) = @{$item_ref};
if (-d $filespec)
{
push @li_lines, HTML_li( HTML_link( $filespec, $title));
} else
{
my $datetime = TIME_time2num( FILE_mtime( $filespec));
push @li_lines, HTML_li( HTML_link( $filespec, $title), HTML_text( '   '), HTML_italic( $datetime));
}
}
push @lines, HTML_ul( @li_lines);
} else
{
push @lines, "No Files";
}
}
} else
{
push @lines, "No Data";
}




push @lines, GBSHTML_doc_bottom();
push @lines, GBSHTML_doc_end();

SPIT_file_nl( $INDEX_FILE_SPEC, \@lines);
ENV_say( 1, "Created Silo index");
}




sub do_topdir($)
{
my ($dir) = @_;


my @section_name_parts = split( '_', $dir);
foreach my $part (@section_name_parts)
{
$part = ucfirst $part;
}
my $section_name = join( ' ', @section_name_parts);
ENV_whisper( 2, "TopDir $dir ($section_name)...");

my @section = ($section_name);
my $this_path = "$GBS::SILO_PATH/$dir";

if (-f "$this_path/index.html")
{
push @section, [ "$this_path/index.html", "index.html" ];
} else
{
my @subdirs = SLURP_dir_dirs( $this_path, 0);
if (@subdirs)
{
foreach my $subdir (@subdirs)
{

if (-f "$this_path/$subdir/index.html")
{
push @section, [ "$this_path/$subdir/index.html", "$subdir / index.html" ];
} else
{
push @section, [ "$this_path/$subdir", $subdir ];
}
}
} else
{
push @section, [ $this_path, 'Directory' ];
}
}
push @SECTION_REFS, [ @section ];
}




sub GBSSILO_view_index()
{
return RUN_browser( $INDEX_FILE_SPEC);
}

1;


