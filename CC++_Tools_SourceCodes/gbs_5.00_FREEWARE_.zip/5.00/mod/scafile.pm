#=================================================
#
#   scafile.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::scafile;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SCAFILE_init
SCAFILE_delete_files
SCAFILE_write_stdout
SCAFILE_garg_write
SCAFILE_garg_read
SCAFILE_gerr_write
SCAFILE_gerr_read
SCAFILE_gmet_reset
SCAFILE_gmet_put_total
SCAFILE_gmet_put_count
SCAFILE_gmet_put_specw
SCAFILE_gmet_put_stat
SCAFILE_gmet_write
SCAFILE_gmet_read
SCAFILE_gmet_get_totals
SCAFILE_gmet_get_counts
SCAFILE_gmet_get_specws
SCAFILE_gmet_get_stats
);
}




use glo::env;
use glo::spit;
use glo::slurp;
use mod::scadef;




sub SCAFILE_init($$$);
sub SCAFILE_delete_files();
sub SCAFILE_write_stdout($$$);
sub SCAFILE_garg_write($@);
sub SCAFILE_garg_read();
sub SCAFILE_gerr_write($);
sub SCAFILE_gerr_read();
sub SCAFILE_gmet_reset();
sub SCAFILE_gmet_put_total($$$);
sub SCAFILE_gmet_put_count($$$$);
sub SCAFILE_gmet_put_specw($$);
sub SCAFILE_gmet_put_stat($$$$);
sub SCAFILE_gmet_write($);
sub SCAFILE_gmet_read($);
sub SCAFILE_gmet_get_totals();
sub SCAFILE_gmet_get_counts();
sub SCAFILE_gmet_get_specws();
sub SCAFILE_gmet_get_stats();








my @SCA_TYPES = qw/.garg .gerr .gmet .gout .html .p/;




my $SUBSYS;
my $COMPONENT;
my $SRC_FILE;

my $AUD_FILE_PATH;
my $AUD_FILE_BASE;

my $GARG_FILESPEC;
my $GERR_FILESPEC;
my $GMET_FILESPEC;













my @FSPEC;
my @TOTAL_REFS;
my @M_COUNT_REFS;
my @SPECW_REFS;
my @STAT_REFS;




my @TOTAL_KEYS = qw(
NR_LINES
NR_FUNCS
NR_CLASS
NR_CONSTS
);
my %TOTAL_KEYS = map { $TOTAL_KEYS[$_] => $_ } (0 .. $#TOTAL_KEYS);





my %LEVELS_BY_LEVEL;






sub SCAFILE_init($$$)
{
( $SUBSYS,
$COMPONENT,
$SRC_FILE,
) = @_;

%LEVELS_BY_LEVEL = SCADEF_get_levels_by_level( $GBS::AUDIT_PLUGIN)
if (!%LEVELS_BY_LEVEL);

$AUD_FILE_PATH = "$GBS::ROOT_PATH/dev/$SUBSYS/comp/$COMPONENT/aud/$GBS::AUDIT/$GBS::BUILD";
$AUD_FILE_BASE = "$AUD_FILE_PATH/$SRC_FILE";

$GARG_FILESPEC = "$AUD_FILE_BASE.garg";
$GERR_FILESPEC = "$AUD_FILE_BASE.gerr";
$GMET_FILESPEC = "$AUD_FILE_BASE.gmet";

SCAFILE_gmet_reset();
}




sub SCAFILE_delete_files()
{
foreach my $type (@SCA_TYPES)
{
unlink "$AUD_FILE_BASE$type";
}
}





sub SCAFILE_write_stdout($$$)
{
my ($source_filespec,   # In
$stdout_format_name,# NONE, PCLINT, VISUAL_C, ECLIPSE, GNU_C, etc
$warning_refs_ref,  # [ $src_line_nr, $col_nr, $filespec, $line_nr, $msg_level, $level_text, $msg_id, $msg_text, $help_file_url, @extra_src_lines ]
) = @_;


ENV_say( 0, "<==>");
if (@{$warning_refs_ref})
{
my @src_lines = ( '', SLURP_file( $source_filespec), '');  # $line_nr indexes from 1

my $cur_inc_spec = '';
my @cur_inc_lines;
foreach my $ref (@{$warning_refs_ref})
{
my ($src_line_nr, $col_nr, $filespec, $line_nr, $msg_level, $level_text, $msg_id, $msg_text, $help_file_url, @extra_src_lines) = @{$ref};

my $this_filespec;
my $this_line_nr;




if ($filespec eq '-')
{



$this_filespec = $source_filespec;
$this_line_nr = $src_line_nr;
$this_line_nr = $#src_lines
if ($this_line_nr > $#src_lines);	# Beware of #line fucking up the linecount!
ENV_say( 0, "$src_lines[$this_line_nr]")
if ($col_nr >= 0);
} else
{



$this_filespec = $filespec;
$this_line_nr = $line_nr;
if ($col_nr >= 0)
{
if ($filespec ne $cur_inc_spec)
{
@cur_inc_lines = ( '', SLURP_file( $filespec), '');
$cur_inc_spec = $filespec;
}
$this_line_nr = $#cur_inc_lines
if ($this_line_nr > $#cur_inc_lines);	# Beware of #line fucking up the linecount!
ENV_say( 0, "$cur_inc_lines[$this_line_nr]");
}
}




if ($col_nr >= 0)
{
ENV_say( 0, @extra_src_lines)
if (@extra_src_lines);
ENV_say( 0, (' ' x $col_nr) . '^');
}




if ($stdout_format_name eq 'PCLINT')
{
ENV_say( 0, "$this_filespec $this_line_nr $level_text $msg_id: $msg_text");
} elsif ($stdout_format_name eq 'PRQA' ||
$stdout_format_name eq 'QAC' ||
$stdout_format_name eq 'QACPP')
{
ENV_say( 0, "$this_filespec($this_line_nr)");
my $severity_text = uc SCADEF_get_severity_text( $LEVELS_BY_LEVEL{$msg_level}->[3]);	    # $severity_index
ENV_say( 0, "++$severity_text++: <=$msg_level=($msg_id) $msg_text");
} elsif  ($stdout_format_name eq 'VISUAL_C')
{
my $lc_level_text = lc $level_text;
ENV_say( 0, "$this_filespec:$this_line_nr: error $lc_level_text $msg_id -- $msg_text");
} elsif ($stdout_format_name eq 'GNU_C')
{
ENV_say( 0, "$this_filespec($this_line_nr) : $level_text $msg_id -- $msg_text");
} elsif ($stdout_format_name eq 'ECLIPSE')
{
my $lc_level_text = lc $level_text;
if ($lc_level_text eq 'info')
{
$lc_level_text = 'warning info';
} elsif ($lc_level_text eq 'note')
{
$lc_level_text = 'warning note';
}
ENV_say( 0, "$this_filespec($this_line_nr) : $lc_level_text $msg_id -- $msg_text");
} else
{

ENV_say( 0, "$this_filespec($this_line_nr) $level_text $msg_id:", "  $msg_text");
}
}
} else
{
ENV_say( 0, "No-Msgs");
}

ENV_say( 0, "<==>");
}





sub SCAFILE_garg_write($@)
{
my ($comment_prefix,    # 2 chars: e.g.: '//' or '**'
@settings_refs,	    # [0] == GBS_DEFAULTS, [1] = COMPILER_OPTS, [2] = GBS_SETTINGS
) = @_;


my @arg_refs = (
[ 'GBS defaults'		=> undef ],		    # @GBS_DEFAULTS
[ 'Compiler settings'		=> undef ],		    # @COMPILER_OPTS
[ 'GBS Flags'			=> 'GBS_FLAGS' ],	    # FILE	TBS
[ 'GBS Sys-Flags'		=> 'GBS_SYSFLAGS' ],	    # FILE	TBS
[ 'GBS Include Directories'	=> 'GBS_INCS' ],	    # FILE	TBS
[ 'GBS Sys-Include Directories'	=> 'GBS_SYSINCS' ],	    # FILE	TBS
[ 'GBS Audit Flags'		=> 'GBS_AUDIT_FLAGS' ],
[ 'Command-line Flags'		=> 'GBS_COMMAND_FLAGS' ],
[ 'GBS settings'		=> undef ],		    # GBS_SETTINGS
);
my @lines;

foreach my $ref (@arg_refs)
{
my ($caption, $envvar_name) = @{$ref};
my @values;
if (defined $envvar_name)
{


foreach my $value (ENV_split_quoted_space( ENV_getenv( $envvar_name)))
{

if ($value ne '')
{
if (substr( $value, 0, 1) eq '-')
{
push @values, $value;
} else
{
$values[-1] .= " $value";
}
}
}

} else
{
@values = @{shift @settings_refs};
}
push @lines, $comment_prefix;
push @lines, "$comment_prefix   $caption";
push @lines, $comment_prefix;
push @lines, (@values) ? @values : "$comment_prefix (None)";
}
SPIT_file_nl( $GARG_FILESPEC, \@lines);

return $GARG_FILESPEC;
}




sub SCAFILE_garg_read()
{
my @lines;

if (-e $GARG_FILESPEC)
{
@lines = SLURP_file( $GARG_FILESPEC);
}

return @lines;
}






sub SCAFILE_gerr_write($)
{
my ($warning_refs_ref,

) = @_;


my @warning_refs = sort { $a->[0] <=> $b->[0] } @{$warning_refs_ref};
my @lines;

push @lines, '#';
push @lines, "#   $GERR_FILESPEC";
push @lines, '#';
foreach my $ref (@warning_refs)
{
my @items = @{$ref};
foreach my $i (7, 9..$#items)    # $msg_text, @extra_src_lines
{
$items[$i] = ENV_detab( $items[$i]);
}
push @lines, join( "\t", @items);
}
SPIT_file_nl( $GERR_FILESPEC, \@lines);

return $GERR_FILESPEC;
}




sub SCAFILE_gerr_read()
{
my @warning_refs;


foreach my $line (SLURP_file( $GERR_FILESPEC))
{
next if ($line eq '' || substr($line, 0, 1) eq '#');
push @warning_refs, [ split( "\t", $line) ];
}

return @warning_refs;
}




sub SCAFILE_gmet_reset()
{
@TOTAL_REFS = ();
@M_COUNT_REFS = ();
@SPECW_REFS = ();
@STAT_REFS = ();
}




sub SCAFILE_gmet_put_total($$$)
{
my ($index,			# 0 = nr_files, 1=nr_funcs, 2=nr_class, 3=nr_consts
$s_count,		# source
$t_count,		# total
) = @_;

my $total_name;
if (ref $index)
{
$total_name = $$index;
$index = $TOTAL_KEYS{$total_name};		    # index is ref to index_name
ENV_sig( F => "Invalid Totals Key '$total_name'")
if (!defined $index);
} else
{
$total_name = $TOTAL_KEYS[$index];
}

push @TOTAL_REFS, [ $index, $total_name, $s_count, $t_count ];
}




sub SCAFILE_gmet_put_count($$$$)
{
my ($level,
$msg_id,
$s_msg_count,	    # source
$t_msg_count,	    # total
) = @_;


push @M_COUNT_REFS, [ $level, $msg_id, $s_msg_count, $t_msg_count ];
}




sub SCAFILE_gmet_put_specw($$)
{
my ($warning,
$item,
) = @_;

$warning =~ s/ /\\_/g;	# save the spaces
push @SPECW_REFS, [ $warning, $item ];
}




sub SCAFILE_gmet_put_stat($$$$)
{
my ($metric_name,
$min,		    # (all equal for file-base metrics)
$max,		    # (all equal for file-base metrics)
$total,		    # (all equal for file-base metrics)
) = @_;

push @STAT_REFS, [ $metric_name, $min, $max, $total ];
}





sub SCAFILE_gmet_write($)
{
my ($worst_severity_index,
) = @_;


my @lines;
push @lines, '#';
push @lines, "#   $GMET_FILESPEC";
push @lines, '#';
push @lines, "FSPEC $COMPONENT $SRC_FILE $worst_severity_index";
push @lines, map { shift @{$_}; "@{$_}" } @TOTAL_REFS;
push @lines, map { "M_COUNT @{$_}" } @M_COUNT_REFS;
push @lines, map { "SPECW @{$_}" } @SPECW_REFS;
push @lines, map { "STAT @{$_}" } @STAT_REFS;
SPIT_file_nl( $GMET_FILESPEC, \@lines);

SCAFILE_gmet_reset();

return $GMET_FILESPEC;
}
















sub SCAFILE_gmet_read($)
{
my ($undef_or_lines_ref) = @_;  # undef == read for cur gmet file. ref == read from memory
my $data_available = 1;

SCAFILE_gmet_reset();

my $file_spec_txt;
my @lines;
if (ref $undef_or_lines_ref)
{
$file_spec_txt = 'from memory';
@lines = @{$undef_or_lines_ref};
} else
{
if (-e $GMET_FILESPEC)
{
$file_spec_txt = $GMET_FILESPEC;
@lines = SLURP_file( $GMET_FILESPEC);
} else
{
$data_available = 0;
}
}

if ($data_available)
{
foreach my $line (@lines)
{
next if ($line eq '' || substr($line, 0, 1) eq '#');
my ($key, @rest) = split( ' ', $line);
if ($key eq 'FSPEC')
{
my ($component, $source_file, $worst_severity_index) = @rest;
@FSPEC = ($component, $source_file, $worst_severity_index);
} elsif (exists $TOTAL_KEYS{$key})	# NR_LINES, NR_FUNCS, NR_CLASS, NR_CONSTS
{

my $index = $TOTAL_KEYS{$key};
push @TOTAL_REFS, [ $index, $key, @rest ];
} elsif ($key eq 'M_COUNT')
{

my $msg_id = $rest[1];
$rest[1] = substr( "    $msg_id", -4)	# leading spaces
if (length $msg_id < 4);
push @M_COUNT_REFS, [ @rest ];
} elsif ($key eq 'SPECW')
{

$rest[0] =~ s/\\_/ /g;		# get spaces back
$rest[1] = ''
if (!defined $rest[1]);
push @SPECW_REFS, [ @rest ];
} elsif ($key eq 'STAT')
{

push @STAT_REFS, [ @rest ];
} else
{
ENV_sig( E => "Unknown key '$key' in GMET-file '$file_spec_txt'");
}
}
}

return $data_available;
}





sub SCAFILE_gmet_get_totals()
{
return @TOTAL_REFS;
}





sub SCAFILE_gmet_get_counts()
{
return @M_COUNT_REFS;
}





sub SCAFILE_gmet_get_specws()
{
return @SPECW_REFS;
}





sub SCAFILE_gmet_get_stats()
{
return @STAT_REFS;
}

1;

