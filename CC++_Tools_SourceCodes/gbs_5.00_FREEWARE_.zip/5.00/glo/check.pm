#=================================================
#
#   check.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::check;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;    our @ISA = qw(Exporter);
our @EXPORT = qw(
CHECK_convert_int
CHECK_convert_bool
CHECK_convert_opt_bool
CHECK_convert_time
CHECK_convert_date
CHECK_word
CHECK_int_range
CHECK_string_range
CHECK_string_choice
CHECK_path
CHECK_other_path
CHECK_dir
CHECK_dirs
CHECK_file
CHECK_filespec
);
}




use glo::env;
use glo::list;




sub CHECK_convert_int($$);
sub CHECK_convert_bool($$);
sub CHECK_convert_opt_bool($$);
sub CHECK_convert_time($$);
sub CHECK_convert_date($$);
sub CHECK_word($$$);
sub CHECK_int_range($$$);
sub CHECK_string_range($$$);
sub CHECK_string_choice($$$);
sub CHECK_path($$$);
sub CHECK_other_path($$);
sub CHECK_dir($$$$);
sub CHECK_dirs($$$$);
sub CHECK_file($$$$);
sub CHECK_filespec($$$);

sub check_path($$$);
sub check_not_chars($$$);




my $IS_WIN32 = (ENV_is_win32());

my $NOT_PATH_CHARS = ':&()<>^;|,*?';
my $NOT_DIR_CHARS  = ':&()<>^;|,*? ./\\';
my $NOT_DIRS_CHARS = ':&()<>^;|,*? .';
my $NOT_FILE_CHARS = ':&()<>^;|,*? /\\';

my %BOOL_VALUES = (
0	    => 0,
1	    => 1,
N	    => 0,
NO	    => 0,
Y	    => 1,
YES	    => 1,
ON	    => 0,
OFF	    => 1,
TRUE    => 0,
FALSE   => 1,
);

my %OPT_BOOL_VALUES = (
''	    => 1,
'-'	    => 0,
'+'	    => 1,
);




sub CHECK_convert_int($$)
{
my ($item_name,		    # undef == 'Value'
$value_or_ref,		    # IN&OUT:
) = @_;
my @error_texts;		    # empty == OK



$item_name = 'Value'
if (!defined $item_name);

my @values = ENV_deref( $value_or_ref);
foreach my $value (@values)
{
next
if (!defined $value || $value eq '');

if ($value =~ /^[-+]?\d+$/)
{
$value *= 1;
} else
{
push @error_texts, "$item_name '$value' must be an integer";
$value = '';
last
if (!wantarray);
}
}




ENV_store( $value_or_ref, \@values)
if (ref $value_or_ref);
return (wantarray) ? @error_texts : $error_texts[0];
}




sub CHECK_convert_bool($$)
{
my ($item_name,		    # undef == 'Value'
$value_or_ref,		    # IN&OUT:
) = @_;
my @error_texts;		    # empty == OK



$item_name = 'Value'
if (!defined $item_name);

my @values = ENV_deref( $value_or_ref);
foreach my $value (@values)
{
next
if (!defined $value || $value eq '');

my $new_value = $BOOL_VALUES{ uc $value};
if (defined $new_value)
{
$value = $new_value;
} else
{
my @valid_bool_values = sort keys %BOOL_VALUES;
push @error_texts, "$item_name '$value' must be one of the Bool values '@valid_bool_values'";
$value = '';
last
if (!wantarray);
}
}




ENV_store( $value_or_ref, \@values)
if (ref $value_or_ref);
return (wantarray) ? @error_texts : $error_texts[0];
}




sub CHECK_convert_opt_bool($$)
{
my ($item_name,		    # undef == 'Value'
$value_or_ref,		    # IN&OUT:
) = @_;
my @error_texts;		    # empty == OK



$item_name = 'Value'
if (!defined $item_name);   # '' is a valid value and becomes '+'

my @values = ENV_deref( $value_or_ref);
foreach my $value (@values)
{
next
if (!defined $value);   # '' is a valid value and becomes '+'

my $new_value = $OPT_BOOL_VALUES{$value};
if (defined $new_value)
{
$value = $new_value;
} else
{
my @valid_bool_values = sort keys %OPT_BOOL_VALUES;
push @error_texts, "$item_name '$value' must be one of the Bool values '@valid_bool_values'";
$value = '';
last
if (!wantarray);
}
}




ENV_store( $value_or_ref, \@values)
if (ref $value_or_ref);
return (wantarray) ? @error_texts : $error_texts[0];
}




sub CHECK_convert_time($$)
{
my ($item_name,		    # undef == 'Value'
$value_or_ref,		    # IN&OUT:
) = @_;
my @error_texts;		    # empty == OK



$item_name = 'Value'
if (!defined $item_name);

my @values = ENV_deref( $value_or_ref);
foreach my $time (@values)
{
next
if (!defined $time || $time eq '');

my $new_time = '';
if ($time eq 'now')
{
$new_time = 'now';
} elsif ($time =~ /^([=\+]?)(\d\d?)(:\d\d?)?$/)
{
my $error_text;
my $delta = $1;
$delta = ''
if (! defined $delta);
my $hours = $2;
$hours = ''
if (! defined $hours);
my $minutes = $3;
$minutes = ''
if (! defined $minutes);

$delta = '='
if ($delta eq '');
if ($minutes eq '')
{
$minutes = $hours;
$hours = 0;
} else
{
$minutes = substr( $minutes, 1);
}
push @error_texts, "$item_name ($time): nr of minutes ($minutes) > 60"
if ($minutes > 60);

$new_time = "$delta$hours:$minutes"
if (!defined $error_text);
} else
{
push @error_texts, "$item_name ($time) must have time format '[+=]hh:mm' or '[+=]mm' or 'now'";
}
$time = $new_time;

last
if (!wantarray);
}




ENV_store( $value_or_ref, \@values)
if (ref $value_or_ref);
return (wantarray) ? @error_texts : $error_texts[0];
}




sub CHECK_convert_date($$)
{
my ($item_name,		    # undef == 'date'
$value_or_ref,		    # YYYY-MM-DD
) = @_;
my @error_texts;		    # empty == OK


$item_name = 'Date'
if (!defined $item_name);

my @numdates = ENV_deref( $value_or_ref);
foreach my $numdate (@numdates)
{
next
if (!defined $numdate || $numdate eq '');

my ($YYYY, $MM, $DD) = $numdate =~ /^(\d{2,4})-(\d\d?)-(\d\d?)$/;
if (defined $YYYY)
{
$YYYY += 2000
if ($YYYY <= 999);
$numdate = sprintf( '%4d-%02d-%02d', $YYYY, $MM, $DD);

if ($MM > 12)
{
push @error_texts, "$item_name ($numdate): Invalid Month '$MM'";
} elsif ($MM eq '02')
{
if ($DD > 29)
{
push @error_texts, "$item_name ($numdate): February never has more than 29 days";
} elsif ($DD == 29)
{




my $is_leap_year = (($YYYY % 4 == 0 and $YYYY % 100 != 0) || $YYYY % 400 == 0) ? 1 : 0;
push @error_texts, "$item_name ($numdate): Not a leap year"
if (!$is_leap_year);
}
} elsif (grep( $MM eq $_, qw( 04 06 09 11)) >= 0)
{
push @error_texts, "$item_name ($numdate): This month only has 30 days"
if ($DD > 30);
} else
{
push @error_texts, "$item_name ($numdate): No month has more than 31 days"
if ($DD > 31);
}
push @error_texts, "$item_name ($numdate): Perl dates are limited to 1970-01-01 till 2038-01-19"
if ($numdate lt '1970-01-01' || $numdate gt '2038-01-19');
} else
{
push @error_texts, "$item_name ($numdate): Format must be YYYY-MM-DD";
}
last
if (!wantarray && @error_texts)
}




ENV_store( $value_or_ref, \@numdates)
if (ref $value_or_ref);
return (wantarray) ? @error_texts : $error_texts[0];
}




sub CHECK_word($$$)
{
my ($item_name,			# undef == 'value'
$value_or_ref,			#
$allowed_values_or_refs_ref,    # undef
) = @_;
my @error_texts;			# empty == OK


foreach my $value (ENV_deref( $value_or_ref))
{
next
if (!defined $value || $value eq '');

if ($value !~ /^\W$/)
{
push @error_texts, "Word may only contain 'A-Z a-z 0-9 _' ($value)";
last
if (!wantarray);
}
}

return (wantarray) ? @error_texts : $error_texts[0];
}




sub CHECK_int_range($$$)
{
my ($item_name,			# undef == 'value'
$value_or_ref,			#
$allowed_values_or_refs_ref,    # ( $value or [$min, $max] ...)
) = @_;
my @error_texts;			# empty == OK


foreach my $value (ENV_deref( $value_or_ref))
{
next
if (!defined $value || $value eq '');

my $value_ok = 0;
foreach my $allowed_value_or_ref (@{$allowed_values_or_refs_ref})
{
if (ref $allowed_value_or_ref)
{
my ($min, $max) = @{$allowed_value_or_ref};
if (defined $min && defined $max)
{
if ($value >= $min && $value <= $max)
{
$value_ok = 1;
last;
}
} elsif (defined $min)
{
if ($value >= $min)
{
$value_ok = 1;
last;
}
} elsif (defined $max)
{
if ($value <= $max)
{
$value_ok = 1;
last;
}
} else
{

}
} else
{
if ($value == $allowed_value_or_ref)
{
$value_ok = 1;
last;
}
}
}

if (!$value_ok)
{



my @allowed_values;
foreach my $allowed_value_or_ref (@{$allowed_values_or_refs_ref})
{
if (ref $allowed_value_or_ref)
{
my ($min, $max) = @{$allowed_value_or_ref};
if (defined $min && defined $max)
{
push @allowed_values, "$min - $max";
} elsif (defined $min)
{
push @allowed_values, ">= $min";
} elsif (defined $max)
{
push @allowed_values, "<= $max";
} else
{

}
} else
{
push @allowed_values, $allowed_value_or_ref;
}
}
my $allowed_values = join( ',', @allowed_values);
$item_name = (defined $item_name) ? ucfirst $item_name : 'Value';
push @error_texts, "$item_name must be $allowed_values";
last
if (!wantarray);
}
}


return (wantarray) ? @error_texts : $error_texts[0];
}




sub CHECK_string_range($$$)
{
my ($item_name,			# undef == 'value'
$value_or_ref,			#
$allowed_values_or_refs_ref,    # ( $value or [$min, $max] ...)
) = @_;
my @error_texts;			# empty == OK


foreach my $value (ENV_deref( $value_or_ref))
{
next
if (!defined $value || $value eq '');

my $value_ok = 0;
foreach my $allowed_value_or_ref (@{$allowed_values_or_refs_ref})
{
if (ref $allowed_value_or_ref)
{
my ($min, $max) = @{$allowed_value_or_ref};
if (defined $min && defined $max)
{
if ($value ge $min && $value le $max)
{
$value_ok = 1;
last;
}
} elsif (defined $min)
{
if ($value ge $min)
{
$value_ok = 1;
last;
}
} elsif (defined $max)
{
if ($value le $max)
{
$value_ok = 1;
last;
}
} else
{

}
} else
{
if ($value eq $allowed_value_or_ref)
{
$value_ok = 1;
last;
}
}
}

if (!$value_ok)
{



my @allowed_values;
foreach my $allowed_value_or_ref (@{$allowed_values_or_refs_ref})
{
if (ref $allowed_value_or_ref)
{
my ($min, $max) = @{$allowed_value_or_ref};
if (defined $min && defined $max)
{
push @allowed_values, "$min - $max";
} elsif (defined $min)
{
push @allowed_values, ">= $min";
} elsif (defined $max)
{
push @allowed_values, "<= $max";
} else
{

}
} else
{
push @allowed_values, $allowed_value_or_ref;
}
}
my $allowed_values = join( ',', @allowed_values);
$item_name = (defined $item_name) ? ucfirst $item_name : 'Value';
push @error_texts, "$item_name must be $allowed_values";
last
if (!wantarray);
}
}

return (wantarray) ? @error_texts : $error_texts[0];
}




sub CHECK_string_choice($$$)
{
my ($item_name,		    # undef == 'value'
$value_or_ref,		    # Wildcards are honoured
$allowed_values_ref,	    #
) = @_;
my @error_texts;		    # empty == OK


my @new_values;
foreach my $value (ENV_deref( $value_or_ref))
{
next
if (!defined $value || $value eq '');

my @found_values;
if ($value eq '*')
{
@found_values = grep( $_ ne '.', @{$allowed_values_ref});
} else
{
@found_values = ENV_wildcard( $value, $allowed_values_ref);
}
if (@found_values)
{
push @new_values, @found_values;
} else
{
push @error_texts, "$item_name '$value': no match in (@{$allowed_values_ref})";

}
last
if (!wantarray && @error_texts);
}
LIST_unique( \@new_values);





ENV_store( $value_or_ref, \@new_values)
if (ref $value_or_ref);
return (wantarray) ? @error_texts : $error_texts[0];
}




sub CHECK_path($$$)
{
my ($item_name,	    # undef == 'path'
$perl_path_or_ref,  # abs_path
$must_exist,	    # -1 == may not exist, 0 == syntax check only, 1 == must exist
) = @_;
my @error_texts;	    # empty == OK

$item_name = 'Path'
if (!defined $item_name);

foreach my $perl_path (ENV_deref( $perl_path_or_ref))
{
next
if (!defined $perl_path || $perl_path eq '');




my $error_text = check_path( $item_name, $perl_path, 0);   # $other_os = 0




if (!defined $error_text)
{
if (-e $perl_path)
{
if (-d _)
{
if ($must_exist == -1)	    # may not exist
{
$error_text = "$item_name '$perl_path' already exists";
}
} else
{
if ($must_exist == 1 || $must_exist == 0) # must or may exist
{
if (-f _)
{
$error_text = "'$perl_path' is a file";
} else
{
$error_text = "'$perl_path' is not a path or file";
}
}
}
} else
{
if ($must_exist == 1)	    # must exists
{
$error_text = "$item_name '$perl_path' does not exist";
}
}
}
push @error_texts, $error_text
if (defined $error_text);
last
if (!wantarray && @error_texts);
}

return (wantarray) ? @error_texts : $error_texts[0];
}




sub CHECK_other_path($$)
{
my ($item_name,	    # undef == 'path'
$perl_path_or_ref,  # abs_path
) = @_;
my @error_texts;    # empty == OK

$item_name = 'Path'
if (!defined $item_name);

foreach my $perl_path (ENV_deref( $perl_path_or_ref))
{
next
if (!defined $perl_path || $perl_path eq '');




my $error_text = check_path( $item_name, $perl_path, 1);   # $other_os = 0
push @error_texts, $error_text
if (defined $error_text);
last
if (!wantarray && @error_texts);
}

return (wantarray) ? @error_texts : $error_texts[0];
}




sub check_path($$$)
{
my ($item_name,	    # undef == 'path'
$perl_path,	    # abs_path
$other_os,	    # 0 or 1 (bool)
) = @_;
my $error_text;	    # undef = OK

my $for_win32 = $IS_WIN32 ^ $other_os;

if ($for_win32)
{



if ($perl_path !~ m!^(//.+|[A-Za-z]:(/|$))!)
{
$error_text = "Abs path on Windows must start with '//' or '<letter>:/'";
} else
{
my $test_path = substr( $perl_path, 2);	#remove 'X:' or '//' for further tests
$error_text = check_not_chars( $item_name, $test_path, $NOT_PATH_CHARS);
}
} else
{



if ($perl_path !~ m!^(/|~/)!)
{
$error_text = "Abs path on Lunix must start with '/' or '~/'";
} else
{
$error_text = check_not_chars( $item_name, $perl_path, $NOT_PATH_CHARS);
}
}

return $error_text;
}




sub CHECK_dir($$$$)
{
my ($item_name,	    # undef == 'Directory'
$dir_or_ref,
$perl_path,	    # abs_path. May be ''
$must_exist,	    # -1 == may not exist, 0 == syntax check only, 1 == must exist
) = @_;
my @error_texts;	    # empty == OK

$item_name = 'Directory'
if (!defined $item_name);

$perl_path = ENV_cwd()
if ($perl_path eq '');

foreach my $dir (ENV_deref( $dir_or_ref))
{
next
if (!defined $dir || $dir eq '');




my $error_text = check_not_chars( $item_name, $dir, $NOT_DIR_CHARS);




if (!defined $error_text && $perl_path ne '')
{
my $new_path = "$perl_path/$dir";

if (-e $new_path)
{
if (-d _)
{
if ($must_exist == -1)	    # may not exist
{
$error_text = "$item_name '$new_path' already exists";
}
} else
{
if ($must_exist == 1 || $must_exist == 0) # must or may exist
{
if (-f _)
{
$error_text = "'$new_path' is a file";
} else
{
$error_text = "'$new_path' is not a path or file";
}
}
}
} else
{
if ($must_exist == 1)	    # must exists
{
$error_text = "$item_name '$new_path' does not exist";
}
}
}
push @error_texts, $error_text
if (defined $error_text);
last
if (!wantarray && @error_texts);
}

return (wantarray) ? @error_texts : $error_texts[0];
}




sub CHECK_dirs($$$$)
{
my ($item_name,	    # undef == 'Directories'
$dirs_or_ref,
$perl_path,	    # abs_path. May be ''
$must_exist,	    # -1 == may not exist, 0 == syntax check only, 1 == must exist
) = @_;
my @error_texts;    # empty == OK

$item_name = 'Directories'
if (!defined $item_name);

foreach my $dirs (ENV_deref( $dirs_or_ref))
{
next
if (!defined $dirs || $dirs eq '');




my $error_text = check_not_chars( $item_name, $dirs, $NOT_DIRS_CHARS);
if (@error_texts eq '')
{
my $fc = substr( $dirs, 0, 1);
if ($fc eq '/' || $fc eq '\\')
{
$error_text = "$item_name '$dirs' may not start with '$fc'";
}
}




if (!defined $error_text && $perl_path ne '')
{
my $new_path = "$perl_path/$dirs";
if (-e $new_path)
{
if (-d _)
{
if ($must_exist == -1)	    # may not exist
{
$error_text = "$item_name '$new_path' already exists";
}
} else
{
if ($must_exist == 1 || $must_exist == 0) # must or may exist
{
if (-f _)
{
$error_text = "'$new_path' is a file";
} else
{
$error_text = "'$new_path' is not a path or file";
}
}
}
} else
{
if ($must_exist == 1)	    # must exists
{
$error_text = "$item_name '$new_path' does not exist";
}
}
}
push @error_texts, $error_text
if (defined $error_text);
last
if (!wantarray && @error_texts);
}

return (wantarray) ? @error_texts : $error_texts[0];
}




sub CHECK_file($$$$)
{
my ($item_name,	    # undef == 'file'
$file_or_ref,	    #
$perl_path,	    # abs_path. May be '' (CWD)
$must_exist,	    # -1 == may not exist, 0 == syntax check only, 1 == must exist
) = @_;
my @error_texts;    # empty == OK

$item_name = 'File'
if (!defined $item_name);

$perl_path = ENV_cwd()
if ($perl_path eq '');

foreach my $file (ENV_deref( $file_or_ref))
{
next
if (!defined $file || $file eq '');




my $error_text = check_not_chars( $item_name, $file, $NOT_FILE_CHARS);




if (!defined $error_text && $perl_path ne '')
{
my $filespec = "$perl_path/$file";
if (-e $filespec)
{
if (-f _)
{
if ($must_exist == -1)	    # may not exist
{
$error_text = "$item_name '$filespec' already exists";
}
} else
{
if ($must_exist == 1 || $must_exist == 0) # must or may exist
{
if (-d _)
{
$error_text = "'$filespec' is a directory";
} else
{
$error_text = "'$filespec' is not a path or file";
}
}
}
} else
{
if ($must_exist == 1)	    # must exists
{
$error_text = "$item_name '$filespec' does not exist";
}
}
}
push @error_texts, $error_text
if (defined $error_text);
last
if (!wantarray && @error_texts);
}

return (wantarray) ? @error_texts : $error_texts[0];
}




sub CHECK_filespec($$$)
{
my ($item_name,	    # undef == 'filespec'
$filespec_or_ref,   #
$must_exist,	    # -1 == may not exist, 0 == syntax check only, 1 == must exist
) = @_;
my @error_texts;    # empty == OK


$item_name = 'Filespec'
if (!defined $item_name);

foreach my $filespec (ENV_deref( $filespec_or_ref))
{
next
if (!defined $filespec || $filespec eq '');

my $error_text;
if (-d $filespec)
{
$error_text = "$item_name '$filespec' is a Directory";
} else
{
my ($path, $file) = ENV_split_spec_pf( $filespec);

if ($path eq '')
{
$error_text = "No path specifed in $filespec";
} elsif ($file eq '')
{
$error_text = "No file specified in $filespec";
}

if (!defined $error_text)
{
$error_text = CHECK_path( $item_name, $path, $must_exist);
}
if (!defined $error_text)
{
$error_text = CHECK_file( $item_name, $file, $path, $must_exist);
}
}
push @error_texts, $error_text
if (defined $error_text);
last
if (!wantarray && @error_texts);
}

return (wantarray) ? @error_texts : $error_texts[0];
}




sub check_not_chars($$$)
{
my ($item_name,	    # undef == 'value'
$value,
$invalid_chars,
) = @_;
my $error_text;	    # undef = OK

my $not_mask = quotemeta $invalid_chars;

if ($value =~ /[$not_mask]/)
{
$item_name = (defined $item_name) ? ucfirst $item_name : 'Value';
$error_text = "$item_name ($value) may not contain '$invalid_chars'";
}

return $error_text;
}

1;


