#=================================================
#
#   gbsoptenv.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbsoptenv;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSOPTENV_set
GBSOPTENV_print
);
}




use glo::env;
use glo::format;
use mod::sys;
use mod::build;




sub GBSOPTENV_set($$);
sub GBSOPTENV_print();

sub init();
sub register_env($);
sub handle_env($$);
sub validate_value($$$$);
sub validate_dir($$);




my %GBSENV_NAMES = (

GBS_LOG_PATH    => [ 0, \&validate_dir,		],
GBS_DEBUGGER    => [ 0, \&BUILD_validate_option,	],
GBS_MODE	    => [ 0, \&BUILD_validate_option,	],
GBS_OPT	    => [ 0, \&BUILD_validate_option,	],
GBS_MAP	    => [ 0, \&BUILD_validate_option,	],
'GBS_APP_*'     => [ 0, \&SYS_validate_option,	],
'GBS_FLAGS_*'   => [ 1, undef,			],
);
my @GBSENV_NAMES = sort keys %GBSENV_NAMES;

my %SAVED_ENVS;

my @SAVED_ENVS_ORDER;

my %ENABLED_NAMES;

my @ENABLED_NAMES_ORDER;

init();




sub init()
{



my @gbs_envs = grep( $_ =~ /^GBS_(APP|FLAGS)_/, keys %ENV);
@gbs_envs = grep( $_ ne 'GBS_APP_PATH', @gbs_envs);

foreach my $key (@GBSENV_NAMES)
{
my @names;
if (substr($key, -1, 1) eq '*')
{
@names = ENV_wildcard( $key, \@gbs_envs);
if ($key eq 'GBS_APP_*')
{

@names = grep $_ !~ /_(VALUE|VALUES|DEFAULT)$/, @names;
}
} else
{
@names = ($key);
}
foreach my $name ( @names)
{
my $value;
if (substr( $name, -5) eq '_PATH')
{
$value = ENV_getenv_perl_path( $name);	# GBS_LOG_PATH
} else
{
$value = ENV_getenv( $name);
}
$SAVED_ENVS{$name} = $value if ($value ne '');
}
}
@SAVED_ENVS_ORDER = sort keys %SAVED_ENVS;


}






sub GBSOPTENV_set($$)
{
my ($name,	# prefixed or not-prefixed
$value, # undef == register only
) = @_;
my $result; # undef == error

if (!defined $value)
{
register_env( $name);
$result = undef;
} else
{
$result = handle_env( $name, $value);
}
return $result;
}




sub register_env($)
{
my ($envkey) = @_; # not-prefixed, may be wildcard

my $prefixed_envkey = "GBS_$envkey";
ENV_sig( F => "Unknown Envvar '(GBS_)$envkey'. (@GBSENV_NAMES)")
if (!exists $GBSENV_NAMES{$prefixed_envkey});
$ENABLED_NAMES{$prefixed_envkey} = 1;
push @ENABLED_NAMES_ORDER, $prefixed_envkey;

foreach my $name (ENV_wildcard( $prefixed_envkey, \@SAVED_ENVS_ORDER))
{
my $value = $SAVED_ENVS{$name};
my $new_value = validate_value( $name, $prefixed_envkey, $value, 'Preset');
if (defined $new_value)
{
$SAVED_ENVS{$name} = $new_value;
}
}

return;
}




sub handle_env($$)
{
my ($name,			# prefixed or not-prefixed
$value,
) = @_;
my $result = undef;

my $prefixed_name = (substr( $name, 0, 4) eq 'GBS_') ? $name : "GBS_$name";

my $envkey;
if ($prefixed_name =~ /^GBS_FLAGS_[A-Z0-9_]+/)
{
$envkey = 'GBS_FLAGS_*';
} elsif ($prefixed_name =~ /^GBS_APP_[A-Z0-9_]+/)
{
$envkey = 'GBS_APP_*';
} else
{
$envkey = $prefixed_name;
}






if ($ENABLED_NAMES{$envkey})
{
my $new_value = validate_value( $prefixed_name, $envkey, $value, 'Set');
my $old_value = ENV_getenv( $prefixed_name);
if ($old_value)
{
if ($GBSENV_NAMES{$envkey}->[0] )  # $aditive
{
$new_value = "$old_value $new_value";
}
ENV_say( 1, "Set: $prefixed_name => $old_value => $new_value");
} else
{
ENV_say( 1, "Set: $prefixed_name => $new_value")
}
$result = $new_value;
$ENV{$prefixed_name} = $result;
} else
{
ENV_sig( E => "Unknown or unmodifiable Environment Variable: $name",
"(@ENABLED_NAMES_ORDER)");
}

return $result;
}




sub validate_value($$$$)
{
my ($prefixed_name,
$envkey,	    # generic name
$value,
$mode,		    # 'Set' or 'Preset'
) = @_;
my $result;

my (undef, $validate_func) = @{$GBSENV_NAMES{$envkey}};
if (defined $validate_func)
{
my ($is_ok, $new_value) = &$validate_func( $prefixed_name, $value);
if ($is_ok)
{
$result = $new_value;
} else
{

$result = undef;
if ($mode eq 'Set')
{
ENV_sig( EE => "$prefixed_name: $new_value");
} else	# $mode eq 'Preset'
{
ENV_sig( F => "Environment Variable $prefixed_name: $new_value");
}
}
} else
{
$result = $value;
}

return $result;
}




sub validate_dir($$)
{
my ($name,
$value,
) = @_;
my ($is_ok, $new_value) = ( 1, $value);

if (!-d $value)
{
$is_ok = 0;
$new_value = "No such directory '$value'";
}

return ($is_ok, $new_value);
}




sub GBSOPTENV_print()
{
ENV_say( 0, "Environment Variables:");

my @names;
foreach my $name (@ENABLED_NAMES_ORDER)
{
push @names, '(GBS_)' . substr( $name, 4);
}
ENV_say( 0, FORMAT_cols( 0, 2, ' ', 0, \@names));
}

1;
