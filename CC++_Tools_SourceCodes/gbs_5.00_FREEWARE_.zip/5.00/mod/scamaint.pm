#=================================================
#
#   scamaint.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::scamaint;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SCAMAINT_init
SCAMAINT_show_help
SCAMAINT_convert_settings
);
}




use glo::env;
use glo::ask;
use glo::slurp;
use glo::spit;
use glo::scm;
use mod::gbsglo;
use mod::run;
use mod::gbsscm;
use mod::scahelp;




sub SCAMAINT_init();
sub SCAMAINT_show_help($$$);
sub SCAMAINT_convert_settings($$$);

sub write_file($$);








my %DEFAULT_SETTING_FILES = (

qac	    => "D:/Work/Test/GBSEXT/qac_pdsl/8.1-R/TOTAL_NOMSG.p_s",
qacpp   => "D:/Work/Test/GBSEXT/qacpp_pdsl/3.0-R/TOTAL_NOMSG.p_s",
pclint  => "D:/Work/Test/GBSEXT/pclint/8.00x/TOTAL_NOMSG.lnt",
);




sub SCAMAINT_init()
{
ENV_say( 1, "$GBS::AUDIT [ $GBS::AUDIT_PLUGIN ]");
}





sub SCAMAINT_show_help($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref,
) = @_;

my $help_filespec = SCAHELP_get_filespec();
if (-e $help_filespec)
{
RUN_browser( $help_filespec);
} else
{
ENV_sig( W => 'Msg Help file does not exist', "- $help_filespec");
}
}









sub SCAMAINT_convert_settings($$$)
{
my ($default_infiles_ref,	# undef or scalar == OK
$line_func_ref,		# (@out_lines) = $line_func_ref->( $line, $line_nr)
$comment_chars,		# E.g.: '*' or '//' or '#'
) = @_;

$default_infiles_ref = []
if (!defined $default_infiles_ref);
my @default_infiles = (ref $default_infiles_ref) ? @{$default_infiles_ref} : ($default_infiles_ref);

GBSSCM_preset( 0);





my $infile_spec;
{
my $prompt = "Enter file-spec of the $GBS::AUDIT_PLUGIN settings file";
my $test_default_filespec = $DEFAULT_SETTING_FILES{$GBS::AUDIT_PLUGIN};
push @default_infiles, $test_default_filespec
if (defined $test_default_filespec && -e $test_default_filespec);
push @default_infiles, [ '<Specify>', sub { ASK_filespec( $prompt, '', 0, 1 ) } ];	# $length, $must_exist
$infile_spec = ASK_value_from_menu( $prompt, 0, undef, \@default_infiles);
}

if ($infile_spec eq '')
{
ENV_say( 1, 'No inputfile selected');
} else
{



ENV_say( 1, "The output will be written to \$GBS_SYSAUDIT_PATH/<audit>/sca_ALL.gbs",
"Additionally sca_<build>.gbs files can be created for every valid",
"Audit/Build combination",
"These files will contain a .include to the sca_ALL.gbs file");
my $default_outfile = "$GBS::SYSAUDIT_PATH/$GBS::AUDIT/sca_ALL.gbs";
my $outfile_spec = ASK_filespec( "Out File spec:", $default_outfile, 0, 0);	# $length, $must_exist
if ($outfile_spec eq '')
{
ENV_say( 1, 'No outputfile selected');
} else
{











my $saved_nr_errors = ENV_get_nr_errors();
my $line_nr = 0;
my @outlines = (
'#',
"#   Generated from $infile_spec",
'#',
);
my $comment_chars_l = length( $comment_chars);
foreach my $inline (SLURP_file( $infile_spec))
{

$line_nr++;
if ($inline eq '')
{
push @outlines, $inline;
} elsif (substr( $inline, 0, $comment_chars_l) eq $comment_chars)
{
push @outlines, '#' . substr( $inline, $comment_chars_l);
} else
{
push @outlines, $line_func_ref->( $inline, $line_nr);
}
}


my $write_text = (-e $outfile_spec) ? 'Overwrite the existing' : 'Write the';
my $default_yn = (-e $outfile_spec) ? 'N' : 'Y';
if (ENV_get_nr_errors() > $saved_nr_errors)
{
ENV_say( 1, 'Errors found');
$default_yn = 'N';
}
if (ASK_YN( "$write_text $GBS::AUDIT sca_ALL.gbs?", $default_yn) eq 'Y')
{
write_file( $outfile_spec, \@outlines);
}
}
}




{
my @reference_file_builds;
my @builds;
foreach my $build (@GBS::ALL_BUILDS)
{
if (GBSGLO_subsystems_for_audit( $GBS::AUDIT, $build))
{
push @builds, $build;
my $sca_build_filespec = "$GBS::SYSAUDIT_PATH/$GBS::AUDIT/sca_$build.gbs";
push @reference_file_builds, $build
if (!-e $sca_build_filespec);
}
}
if (@reference_file_builds)
{
if (ASK_YN( "Create reference files (@reference_file_builds)?", 'Y') eq 'Y')
{
foreach my $build (@reference_file_builds)
{
my $sca_build_filespec = "$GBS::SYSAUDIT_PATH/$GBS::AUDIT/sca_$build.gbs";
if (ASK_YN( "Create $GBS::AUDIT sca_$build.gbs with reference to sca_ALL.gbs?", 'N') eq 'Y')
{
my @lines = (
'',
'.include sca_ALL.gbs',
);
write_file( $sca_build_filespec, \@lines);
}
}
}
} else
{
ENV_say( 1, "All reference files (@builds) present");
}
}
}




sub write_file($$)
{
my ($filespec,
$lines_ref,
) = @_;

ENV_backup_file( $filespec, '.sav', 'F')	# exit on error
if (-e $filespec);
SCM_assert_co_file( $filespec);

my $file = ENV_split_spec_f( $filespec);
my ($build) = $file =~ /sca_(.*)\./;
my @head = (
'#========================================================',
"#   [SYSAUDIT:${GBS::AUDIT}[$build] sca_$build.gbs",
'#========================================================',
);
my @tail = (
'',
'###EOF###',
);

SPIT_file_nl( $filespec, [ \@head, $lines_ref, \@tail ]);
ENV_say( 2, "Created $filespec");
}

1;


