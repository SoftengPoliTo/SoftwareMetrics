#=================================================
#
#   dirstruct.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::dirstruct;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
DIRSTRUCT_reset
DIRSTRUCT_dir_attrib
DIRSTRUCT_file_attrib
DIRSTRUCT_get_ignore_spec
DIRSTRUCT_mandatory_dirs
DIRSTRUCT_all
DIRSTRUCT_nice_attribs
);
}




use glo::env;
use glo::slurp;
use mod::gbsglo;




sub DIRSTRUCT_reset();
sub DIRSTRUCT_dir_attrib($);
sub DIRSTRUCT_file_attrib($);
sub DIRSTRUCT_get_ignore_spec($);
sub DIRSTRUCT_mandatory_dirs($$);
sub DIRSTRUCT_all();
sub DIRSTRUCT_nice_attribs($$$);

sub get_attrib($$);
sub match_name($$);
sub mandatory_dirs($$);
sub all_files_node($$);
sub dummy_check_mandatory($$);
sub get_ignore($);
sub get_subsys_key($);

sub get_member_names($$);
sub get_node_members($);
sub node_is_dir($);
sub node_data($);
sub node_recurse($$$);




my %PLUGIN_ITEMS = (
'<A>'    => [ @GBS::ALL_AUDITS ],   # Audit
'<B>'    => [ @GBS::ALL_BUILDS ],	# Build
'<T>'    => [ @GBS::ALL_TOOLS ],    # Tool
);

my ($THIS_CMD_EXT, $OTHR_CMD_EXT) = ENV_shell_filetype();

my $DIR_ENTRIES_LEVEL;
my @DIR_ENTRIES;








my %NICE_ATTRIB_NAMES = (
scm_1	=> 'yes',
scm_0	=> 'no',
'scm_-1'	=> 'optional',
avail_M	=> 'mandatory',
avail_O	=> 'optional',
type_D	=> 'directory',
type_F	=> 'file',
type_U	=> 'unknown',
);

my %TOPLEVELS = (

GBS	    => 'SUBSYS_GBS',
MSVS    => 'SUBSYS_MSVS',
make    => 'SUBSYS_MAKE',
Other   => 'SUBSYS_OTHER',
UNK	    => 'SUBSYS_UNK',
);

my @SUBSYS_ALL = (







'ssprop.gbs'    => [ 'M', 1 ],
'.*.lck'	    => [ 'O', 0 ],			    # ignore
'.gbsrc'	    => [ 'O', 0 ],			    # ignore
audit =>
{
'.'	  => [ 'M', 1, 0, 1, 0, 0 ],
'<A>' => # Audits
{
'.'   => [ 'O', 1, 0, 0, 1, 1 ],
'<B>' => # Builds
{
'.' => [ 'O', 1, 0, 0, 1, 1 ],
},
},
},
build =>
{
'.'	      => [ 'M', 1, 0, 0, 0, 0 ],
'incs_*.gbs'  => [ 'O', 1 ],
'flags_*.gbs' => [ 'O', 1 ],
'export.gbs'  => [ 'O', 1 ],
'*.mk'	      => [ 'O', 0 ],
'*.usr'	      => [ 'O', 0 ],
'<B>' => #Builds
{
'.' => [ 'O', 1, 0, 0, 1, 1 ],
}
},
export =>
{
'.'	=> [ 'O', 1, 1, 0, 1, 0 ],
},
import =>
{
'.'	=> [ 'O', 1, 1, 1, 1, 1 ],
},
tool =>
{
'.'	=> [ 'M', 1, 1, 1, 0, 0 ],
'<T>' =>  # Tools
{
'.' => [ 'O', 1, 1, -1, 1, -1 ],
},
},

);
my %DIRS = (







SYSTEM =>
{
'.'		 => [ 'M', 1, 1, -1, 1, -1 ],
'system.gbs'		    => [ 'M', 1 ],
"switch.gbs$THIS_CMD_EXT"   => [ 'M', 1 ],
"switch.gbs$OTHR_CMD_EXT"   => [ 'O', 1 ],
'switch.usr.*'		    => [ 'O', 0 ],	# ignore
'*.sav'			    => [ 'O', 0 ],	# ignore
dev =>
{
'.'	     => [ 'M', 1, 1, 1, 0, 0 ],
'.gbsrc' => [ 'O', 0 ],			# ignore
'*'      =>			    # SubSystems
{
'.'	=> [ 'O', 1, 1, 1, 1, 1 ],
},
},
ext =>
{
'.'	=> [ 'M', 1, 1, 1, 1, 1 ],
},
MOCKS =>
{
'.'	=> [ 'O', 1, 1, 1, 1, 1 ],
},
res =>
{
'.'	     => [ 'M', 1, 1, 1, 0, 0 ],
'.*.lck' => [ 'O', 0 ],
'*'      =>			    # SubSystems
{
'.' => [ 'O', 1, 1, 0, 1, 0 ],
},
},
silo =>
{
'.'	    => [ 'M', 1, 1, 0, 1, 0 ],
'.gbs'  =>
{
'.'	=> [ 'M', 1, 1, 0, 1, 0 ],
cache   =>
{
'.'		=> [ 'M', 1, 1, 0, 1, 0 ],
html  =>
{
'.'	=> [ 'M', 1, 1, 0, 1, 0 ],
},
'*'      =>			    # Audit Plugins
{
'.' => [ 'O', 1, 1, 0, 1, 0 ],
'*'      =>			    # Audit Releases
{
'.' => [ 'O', 0, 1, 0, 1, 0 ],
},
},
},
gbssum	=>
{
'.'	=> [ 'M', 1, 1, 0, 1, 0 ],
},
},
},
sys =>
{
'.'		  => [ 'M', 1, 1, 1, 1, 1 ],
'owners.gbs'  => [ 'O', 1 ],
'steps.gbs'   => [ 'O', 1 ],
'sys.gbs'     => [ 'M', 1 ],
templates	  =>
{
'.'		    => [ 'M', 1, 0, 0, 1, 1 ],
'comment_chars.gbs' => [ 'O', 1 ],
},
'.*.lck'	  => [ 'O', 0 ],		# ignore
'*.usr'	  => [ 'O', 0 ],		# ignore
'*' =>
{
'.' => [ 'O', 1, 1, 1, 1, 1 ],
}
},
sysaudit =>
{
'.'		  => [ 'M', 1, 1, 1, 1, 1 ],
'<A>' =>  # Audits
{
'.'		 => [ 'M', 1, 1, 1, 1, 1 ],
'audit.gbs'      => [ 'O', 1 ],
'*.usr'	         => [ 'O', 0 ],
},
'*' =>
{
'.' => [ 'O', 1, 1, 1, 1, 1 ],
}
},
sysbuild =>
{
'.'		    => [ 'M', 1, 1, 1, 1, 1 ],
'incs_*.gbs'    => [ 'O', 1 ],
'flags_*.gbs'   => [ 'O', 1 ],
'*.usr'	    => [ 'O', 0 ],		    # ignore
makemake_stubs  =>
{
'.'	=> [ 'M', 1, 1, 1, 1, 1 ],
'ALL'	=>
{
'.'	=> [ 'M', 1, 1, 1, 1, 1 ],
},
'<B>' =>  # Builds
{
'.'	=> [ 'M', 1, 1, 1, 1, 1 ],
},
},
'<B>'	=>  # Builds
{
'.'		 => [ 'M', 1, 1, 1, 1, 1 ],
'incs_*.gbs'     => [ 'O', 1 ],
'flags_*.gbs'	 => [ 'O', 1 ],
'sysincs_*.gbs' => [ 'O', 1 ],
'sysflags_*.gbs'=> [ 'O', 1 ],
'build.gbs'      => [ 'O', 1 ],
'*.usr'	         => [ 'O', 0 ],		    # ignore
},
'*'		    =>
{
'.' => [ 'O', 1, 1, 1, 1, 1 ],
}
},
systool =>
{
'.'	  => [ 'M', 1, 1, 1, 1, 1 ],
'<T>' => # Tools
{
'.'		=> [ 'M', 1, 1, 1, 1, 1 ],
'tool.gbs'      => [ 'M', 1 ],
'*.usr'		=> [ 'O', 0 ],		    # ignore
},
'*' =>
{
'.' => [ 'O', 1, 1, 1, 1, 1 ],
}
},
tmp =>
{
'.'	  => [ 'M', 1, 1, 0, 1, 0 ],
'<A>' => # Audits
{
'.' => [ 'M', 1, 1, 0, 1, 0 ],
},
'<B>' => # Builds
{
'.' => [ 'M', 1, 1, 0, 1, 0 ],
},
'<T>' => # Tools
{
'.' => [ 'M', 1, 1, 0, 1, 0 ],
},
},
},








SUBSYS_GBS =>
{
'.'		=> [ 'M', 1, 1, 1, 1, 1 ],
@SUBSYS_ALL,
comp =>
{
'.'	     => [ 'M', 1, 1, 1, 0, 0 ],
},
},
















SUBSYS_MSVS =>
{
'.'        => [ 'M', 1, 1, -1, 1, -1 ],
@SUBSYS_ALL,
app =>
{
'.'		=> [ 'M', 1, 1, 1, 1, -1 ],
'*.sln'	=> [ 'O', 1 ],
'*.vcxproj'	=> [ 'O', 1 ],
'*.sdf'	=> [ 'O', 0 ],			# ignore
'*.suo'	=> [ 'O', 0 ],			# ignore
'*.user'	=> [ 'O', 0 ],			# ignore
Debug =>
{
'.'	=> [ 'O', 1, 1, -1, 1, 0 ],
},
Release =>
{
'.'	=> [ 'O', 1, 1, -1, 1, 0 ],
},
Testresults =>
{
'.'	=> [ 'O', 1, 1, -1, 1, 0 ],
},
'*'	=>
{
'.'	    => [ 'O', 1, 1, 1, 1, -1 ],
'ReadMe.txt'	=> [ 'O', 1 ],
'*.sln'		=> [ 'O', 1 ],
'*.vcxproj'	=> [ 'O', 1 ],
'*.sdf'		=> [ 'O', 0 ],		# ignore
'*.suo'		=> [ 'O', 0 ],		# ignore
'*.user'	=> [ 'O', 0 ],		# ignore
Debug =>
{
'.'	=> [ 'O', 1, 1, -1, 1, 0 ],
},
Release =>
{
'.'	=> [ 'O', 1, 1, -1, 1, 0 ],
},
},
},
opts =>
{
'.'	=> [ 'M', 1, 0, 0, 1, 0 ],
'aud'	=>
{
'.' => [ 'M', 1, 1, 0, 1, 0 ],
},
'bld'	=>
{
'.' => [ 'M', 1, 1, 0, 1, 0 ],
}
},
},








SUBSYS_MAKE =>
{
'.'        => [ 'M', 1, 1, -1, 1, -1 ],
@SUBSYS_ALL,
app =>
{
'.'	    => [ 'M', 1, 1, -1, 1, -1 ],
'*.mk'  => [ 'O', 1 ],
},
opts =>
{
'.'	=> [ 'M', 1, 0, 0, 1, 0 ],
'aud'	=>
{
'.' => [ 'M', 1, 1, 0, 1, 0 ],
},
'bld'	=>
{
'.' => [ 'M', 1, 1, 0, 1, 0 ],
}
},
},








SUBSYS_OTHER =>
{
'.'        => [ 'M', 1, 1, -1, 1, -1 ],
@SUBSYS_ALL,
app =>
{
'.'	=> [ 'M', 1, 1, -1, 1, -1 ],
},
opts =>
{
'.'	=> [ 'M', 1, 0, 0, 1, 0 ],
'aud'	=>
{
'.' => [ 'M', 1, 1, 0, 1, 0 ],
},
'bld'	=>
{
'.' => [ 'M', 1, 1, 0, 1, 0 ],
}
},
},

SUBSYS_UNK =>
{
'.'        => [ 'M', 1, 1, -1, 1, -1 ],
@SUBSYS_ALL,
},








COMPONENT =>
{
'.'          => [ 'M',  1, 0, 0, 0, 0 ],
'export.gbs' => [ 'O',  1, ],
'export.usr' => [ 'O',  0, ],			# ignore
'scope.gbs'  => [ 'O',  1, ],
'scope.usr'  => [ 'O',  0, ],			# ignore
'*.dsp'      => [ 'O', -1, ],	# Microsoft Visual Studio 6
'*.dsw'      => [ 'O', -1, ],	# Microsoft Visual Studio 6
'*.sln'      => [ 'O', -1, ],	# Microsoft Visual Studio 8
'*.mcp'      => [ 'O', -1, ],	# Code Warrior
aud =>
{
'.'	=> [ 'M', 1, 0, 0, 0, 0 ],
'<A>' => #audits
{
'.'   => [ 'O', 1, 1, -1, 1, -1 ],
'<B>' => #Builds
{
'.' => [ 'O', 1, 1, 0, 1, 0 ],
},
'ALL' => #All-Builds
{
'.' => [ 'O', 1, 1, 0, 1, 0 ],
}
}
},
bld =>
{
'.'	    => [ 'M', 1, 0, 0, 0, 0 ],
'*.mk'  => [ 'O', 0 ],	    		# ignore
'*.ref' => [ 'O', 0 ],	    		# ignore
'<B>' => #Builds
{
'.' => [ 'O', 1, 0, 0, 1, 0 ],
}
},
dat =>
{
'.'	=> [ 'M', 1, 1, 1, 1, 1 ],
},
inc =>
{
'.'	=> [ 'M', 1, 0, 0, 1, 1 ],
},
loc =>
{
'.'	=> [ 'M', 1, 0, 0, 1, 1 ],
},
opt =>
{
'.'	=> [ 'M', 1, 0, 0, 0, 0 ],
'incs_*.gbs'  => [ 'O', 1 ],
'flags_*.gbs' => [ 'O', 1 ],
'*.usr'	  => [ 'O', 0 ],	    		# ignore
'<B>' =>  # Builds
{
'.'	=> [ 'O', 1, 0, 0, 0, 0 ],
'incs_*.gbs'  => [ 'O', 1 ],
'flags_*.gbs' => [ 'O', 1 ],
'*.usr'	      => [ 'O', 0 ],	    		# ignore
}
},
sav =>
{
'.'	=> [ 'M', 1, 1, -1, 1, -1 ],
},
src =>
{
'.'	=> [ 'M', 1, 0, 0, 1, 1 ],
},
},
);





sub DIRSTRUCT_reset()
{
%PLUGIN_ITEMS = (
'<A>'    => [ @GBS::ALL_AUDITS ],   # Audit
'<B>'    => [ @GBS::ALL_BUILDS ],   # Build
'<T>'    => [ @GBS::ALL_TOOLS ],    # Tool
);
}




sub DIRSTRUCT_dir_attrib($)
{
my ($spec,		# dir
) = @_;




return get_attrib( $spec, 1);
}




sub DIRSTRUCT_file_attrib($)
{
my ($spec,		# file
) = @_;




return get_attrib( $spec, 0);
}




sub DIRSTRUCT_get_ignore_spec($)
{
my ($spec,		#  dir
) = @_;
my $ignores_ref;	# [ @ignores ]	(may be wildcards)

$ignores_ref = get_attrib( $spec, 1);

return $ignores_ref;
}




sub get_attrib($$)
{
my ($spec, 	    # $file_or_dir
$is_dir,
) = @_;
my ($ignores_ref, $scm, $avail, $type);
$ignores_ref = [];




ENV_sig( F => "'$spec' not in '$GBS::ROOT_PATH")
if (! ENV_is_in_path( $spec, $GBS::ROOT_PATH));




my $top_level;
my (undef, $subsys, $component, $remain) = GBSGLO_split_gbs_spec( $spec);
if ($subsys eq '')
{
$top_level = 'SYSTEM';
} else
{
if ($component eq '')
{
$top_level = get_subsys_key( $subsys);  #SUBSYS_MSVS, SUBSYS_MAKE, SUBSYS_OTHER, SUBSYS_UNK
} else
{
$top_level = 'COMPONENT';
}
}









my $members_ref = $DIRS{$top_level};
my $found_name = '.';
my $ref_type;
foreach my $name (split( '/', $remain))
{
$found_name = match_name( $name, $members_ref);
my $next_ref = $members_ref->{$found_name};
$ref_type = ref $next_ref;
if ($ref_type eq 'HASH')
{
$members_ref = $next_ref;
} elsif ($ref_type eq 'ARRAY')
{
$members_ref = $next_ref;
last;
} else
{
ENV_sig( F => "Invalid ref for '$found_name' ($ref_type)");
}
}

if (ref $members_ref eq 'HASH')
{
($avail, $scm, my ($extra_dirs, $scm_extra_dirs, $extra_files, $scm_extra_files)) = @{$members_ref->{'.'}};


if ($found_name eq '.')
{
if ($is_dir)
{
$type = ($extra_dirs) ? 'D' : 'U';
$scm = $scm_extra_dirs;
} else
{
$avail = 'O';
$type = ($extra_files) ? 'F' : 'U';
$scm = $scm_extra_files;
}
} else
{
$type = 'D';

}
} else
{
if ($found_name eq '.')
{
($avail, $scm, my ($extra_dirs, $scm_extra_dirs, $extra_files, $scm_extra_files)) = @{$members_ref};

if ($is_dir)
{
$type = ($extra_dirs) ? 'D' : 'U';
$scm = $scm_extra_dirs;
} else
{
$avail = 'O';
$type = ($extra_files) ? 'F' : 'U';
$scm = $scm_extra_files;
}
} else
{
$type = 'F';
($avail, $scm) = @{$members_ref};

}
}

if ($is_dir)
{
$ignores_ref = get_ignore( $members_ref);

return (wantarray) ? ($ignores_ref, $scm, $avail, $type) : $ignores_ref;
} else
{
return (wantarray) ? ($scm, $avail, $type) : $scm;
}
}




sub match_name($$)
{
my ($search_name,
$members_ref,
) = @_;
my $found_name;


if (exists $members_ref->{$search_name})
{

$found_name = $search_name;
} else
{


if (exists( $members_ref->{'<B>'}) && exists( $GBS::ALL_BUILDS{$search_name}))
{

$found_name = '<B>';
} elsif (exists( $members_ref->{'<A>'}) && exists( $GBS::ALL_AUDITS{$search_name}))
{

$found_name = '<A>';
} elsif (exists ($members_ref->{'<T>'}) && exists( $GBS::ALL_TOOLS{$search_name}))
{

$found_name = '<T>';
} else
{




foreach my $member_name (get_member_names( $members_ref, 1))    # 1 == $wild_names_only
{
my $member_name_re = ENV_wild_2_re( $member_name);
if ($search_name =~ /$member_name_re/)
{
$found_name = $member_name;
last;
}
}
if (!defined $found_name)
{





$found_name = '.';
}
}
}


return $found_name;
}






sub get_member_names($$)
{
my ($members_ref,
$wild_names_only,   # bool
) = @_;
my (@plain_member_names, @wild_member_names, @wildest_member_name);

foreach my $member_name (sort( keys( %{$members_ref})))
{
if ($member_name eq '.')
{

} elsif ($member_name eq '*')
{
@wildest_member_name = ($member_name);
} elsif (ENV_is_wildcard( $member_name))
{
push @wild_member_names, $member_name;
} else
{
push @plain_member_names, $member_name
unless ($wild_names_only);
}
}


return (@plain_member_names, @wild_member_names, @wildest_member_name);
}




sub DIRSTRUCT_mandatory_dirs($$)
{
my ($level_path,
$top_level,	  # SYSTEM, SUBSYS or COMPONENT
) = @_;
my @dirs;

if ($top_level eq 'SUBSYS')
{
my $subsys = ENV_parent_dir( $level_path, -1);
$top_level = get_subsys_key( $subsys);	    # SUBSYS_GBS, SUBSYS_MSVS, etc
}

$DIR_ENTRIES_LEVEL = 0;
@DIR_ENTRIES = ($level_path);
my $top_ref = [ \%DIRS, $top_level , $DIRS{$top_level} ];
node_recurse( $top_ref, \&mandatory_dirs, \@dirs);

return @dirs;
}




sub mandatory_dirs($$)
{
my ($dirs_ref,  # $data
$node_ref,  # [ $hash_ref, $name, $members_ref ]
) = @_;

if (node_is_dir( $node_ref))
{
my $dir_name = $node_ref->[1];
my (undef, $avail) = node_data( $node_ref);


if ($avail eq 'M')
{
if ($dir_name =~ /<.>/)	# <B>, <A>, <T>
{
my @plugin_items = @{$PLUGIN_ITEMS{$dir_name}};
push @{$dirs_ref}, map { join( '/', @DIR_ENTRIES, $_) } @plugin_items;
} else
{
push @{$dirs_ref}, join( '/', @DIR_ENTRIES, $dir_name);
}
}
}
}










sub DIRSTRUCT_all()
{
my @line_refs;

my $node_ref = [ \%DIRS, undef, undef ];




$node_ref->[1] = 'SYSTEM';
$node_ref->[2] = $DIRS{'SYSTEM'};
@line_refs = all_files_node( $node_ref, '');





foreach my $subsys (@GBS::ALL_SUBSYSTEMS)
{
my $top_level = get_subsys_key( $subsys);	    # SUBSYS_GBS, SUBSYS_MSVS, etc
$node_ref->[1] = $top_level;
$node_ref->[2] = $DIRS{$top_level};
push @line_refs, all_files_node( $node_ref, "dev/$subsys");
if ($top_level eq 'SUBSYS_GBS')
{



foreach my $component (GBSGLO_components( $subsys))
{
$node_ref->[1] = 'COMPONENT';
$node_ref->[2] = $DIRS{'COMPONENT'};
push @line_refs, all_files_node( $node_ref, "dev/$subsys/comp/$component");
}
}
}




my %line_refs;

foreach my $ref (@line_refs)
{
my ($type, $avail, $scm, $spec) = @{$ref};
my $prev_ref = $line_refs{$spec};
if (defined $prev_ref)
{
$prev_ref->[0] = $type;
$prev_ref->[1] = $avail;
$prev_ref->[2] = $scm;
$ref = undef;

} else
{
$line_refs{$spec} = $ref;
}
}

return grep( defined ,@line_refs);
}












sub all_files_node($$)
{
my ($node_ref,	# [ $hash_ref, $name, $members_ref ]
$sub_path,
) = @_;
my @line_refs;	#   ( [ $type, $avail, $scm, $spec ], ... )

my $this_root_path = ($sub_path eq '') ? $GBS::ROOT_PATH : "$GBS::ROOT_PATH/$sub_path";





my %this_dir_entries;


if (-d $this_root_path)
{
map { $this_dir_entries{ $_} = 'D' } GBSGLO_select_specs( SLURP_dir_dirs( $this_root_path, 0));
map { $this_dir_entries{ $_} = 'F' } GBSGLO_select_specs( SLURP_dir_files( $this_root_path, 0));




foreach my $file ('.gbsrc', '.gbs')
{
if (-e "$this_root_path/$file")
{
$this_dir_entries{$file} = 'F';

}
}
}






my @next_refs;


foreach my $member_ref (get_node_members( $node_ref))

{
my $name = $member_ref->[1];

my $member_is_dir = node_is_dir( $member_ref);
my $member_is_wild = ENV_is_wildcard( $name);

my ($type, $avail, $scm) = node_data( $member_ref);
my @found;
my @missing;
if ($name =~ /<.>/)	    	# <B>, <A>, <T>
{
foreach my $build_or_audit (@{$PLUGIN_ITEMS{$name}})
{
if (exists $this_dir_entries{$build_or_audit})
{
push @found, $build_or_audit;
} else
{
push @missing, $build_or_audit;
}
}
} elsif ($member_is_wild)
{
@found = ENV_wildcard( $name, [ keys %this_dir_entries ]);
@missing = ($name) if (!@found);
} else
{
if (exists $this_dir_entries{$name})
{
@found = ($name);
} else
{
@missing = ($name);
}
}

if (@found)
{

foreach my $this_entry (@found)
{
my $member_sub_path = ($sub_path eq '') ? $this_entry : "$sub_path/$this_entry";
my $entry_type = $type;
if ($name eq '*')
{
$entry_type = (-d "$GBS::ROOT_PATH/$member_sub_path") ? 'D' : 'F';
}

if ($entry_type eq 'D')
{
if (-d "$GBS::ROOT_PATH/$member_sub_path")
{
push @next_refs, [ $member_sub_path, $member_ref ]
if ($member_is_dir);
} else
{
$avail = 'i';
}
delete $this_dir_entries{$this_entry};
} else # $entry_type eq 'F'
{
if (-d "$GBS::ROOT_PATH/$member_sub_path")
{
$avail = 'i';
} else
{
delete $this_dir_entries{$this_entry};
}
}
push @line_refs, [ $entry_type, $avail, $scm, $member_sub_path ];
}
}
if (@missing)	# actual file/dir not found
{
foreach my $name (@missing)
{
my $member_sub_path = ($sub_path eq '') ? $name : "$sub_path/$name";
if ($avail eq 'M')
{
push @line_refs, [ $type, 'm', $scm, $member_sub_path ];
}
push @next_refs, [ $member_sub_path, $member_ref ]
if ($member_is_dir);
}
}
}





if (%this_dir_entries)
{




my (undef, undef, undef, $extra_dirs, $scm_extra_dirs, $extra_files, $scm_extra_files) = node_data( $node_ref);
foreach my $entry (keys %this_dir_entries)
{
my ($type, $avail, $scm, $member_sub_path) = ( undef, 'I', 0, ($sub_path eq '') ? $entry : "$sub_path/$entry" );
$type = $this_dir_entries{ $entry};
if ($type eq 'D')
{
if ($extra_dirs)
{
$avail = 'O';
$scm = $scm_extra_dirs;
}
} else
{
if ($extra_files)
{
$avail = 'O';
$scm = $scm_extra_files;
}
}
push @line_refs, [ $type, $avail, $scm, $member_sub_path ];

}
}




foreach my $ref (@next_refs)
{

push @line_refs, all_files_node( $ref->[1], $ref->[0]);		# $member_ref $member_sub_path
}

return @line_refs;
}





sub dummy_check_mandatory($$)
{
my ($base_path,
$parent,
) = @_;
my $ok = 1;


my $top_ref = [ \%DIRS, $parent, $DIRS{$parent} ];
foreach my $member_ref (get_node_members( $top_ref ))
{
my (undef, $avail) = node_data( $member_ref);
if ($avail eq 'M')
{

if (!-e "$base_path/$member_ref->[1]")
{
$ok = 0;
last;
}
}
}

return $ok;
}




sub get_ignore($)
{
my ($members_ref,
) = @_;
my @ignores;



if (ref $members_ref eq 'HASH')
{
foreach my $member_name (get_member_names( $members_ref, 0))	# 0 = all members - except '.'
{
my $member_ref = $members_ref->{$member_name};
my $scm;
if (ref $member_ref eq 'HASH')
{
(undef, $scm) = @{$member_ref->{'.'}};
} else
{
(undef, $scm) = @{$member_ref};
}
push @ignores, $member_name
if ($scm == 0);
}
if (!@ignores)
{
my (undef, undef, undef, $scm_extra_dirs, undef, $scm_extra_files) = @{$members_ref->{'.'}};
@ignores = ('*')
if ($scm_extra_dirs == 0 && $scm_extra_files == 0);
}
} else
{
my (undef, undef, undef, $scm_extra_dirs, undef, $scm_extra_files) = @{$members_ref};
@ignores = ('*')
if ($scm_extra_dirs == 0 && $scm_extra_files == 0);
}


return [ @ignores ];
}




sub get_subsys_key($)
{
my ($subsys) = @_;
my $key;	    #   SUBSYS_MSVS, SUBSYS_MAKE, SUBSYS_OTHER, SUBSYS_UNK


my $sstype = GBSGLO_subsystem_type( $subsys);
$key = $TOPLEVELS{ $sstype};
ENV_sig( F => "Invalid sstype '$sstype' for SubSys '$subsys'")
if (!defined $key);
ENV_sig( E => "No sstype for SubSys '$subsys'")
if ($key eq '');

return $key;
}





sub get_node_members($)
{
my ($node_ref) = @_;    # [ $hash_ref, $name, $members_ref ]
my (@member_refs);


my $members_ref = $node_ref->[2];
my @member_names = sort( keys( %{$members_ref}));
my (@plain_member_names, @wild_member_names, @wildest_member_name);
foreach my $member_name (@member_names)
{
if ($member_name eq '.')
{

} elsif ($member_name eq '*')
{
@wildest_member_name = ($member_name);
} elsif (ENV_is_wildcard( $member_name))
{
push @wild_member_names, $member_name;
} else
{
push @plain_member_names, $member_name;
}
}

foreach my $member_name (@plain_member_names, @wild_member_names, @wildest_member_name)
{
push @member_refs, [ $members_ref, $member_name, $members_ref->{$member_name} ];
}

return @member_refs;
}






sub node_is_dir($)
{
my ($node_ref) = @_;    # [ $hash_ref, $name, $members_ref ]


return (ref $node_ref->[2] eq 'HASH') ? 1 : 0;  # $members_ref
}




sub node_data($)
{
my ($node_ref) = @_;    # [ $hash_ref, $name, $members_ref ]


my ($type);

my $attrs_ref;
if (node_is_dir( $node_ref))
{
$type = 'D';
$attrs_ref = $node_ref->[2]->{'.'};	# $members_ref
} else
{
$type = 'F';
$attrs_ref = $node_ref->[2];	    	# $members_ref
}

return ($type, @{$attrs_ref});
}





sub node_recurse($$$)
{
my ($node_ref,  # [ $hash_ref, $name, $members_ref ]
$func_ref,  # $func_ref->( $data, $member_ref)
$data,
) = @_;

$DIR_ENTRIES_LEVEL++;
foreach my $member_ref (get_node_members( $node_ref))
{
my $name = $member_ref->[1];

$func_ref->( $data, $member_ref);
if (node_is_dir( $member_ref))
{
push @DIR_ENTRIES, $name;
node_recurse( $member_ref, $func_ref, $data);
pop @DIR_ENTRIES;
}
}
$DIR_ENTRIES_LEVEL--;
}




sub DIRSTRUCT_nice_attribs($$$)
{
my ($scm,	    # 1  = yes, 0  = no, -1  = don't know
$avail,	    # 'M' = mandatory, 'O' = optional
$type,	    # 'F' = File, 'D' = Dir, 'U' = unknown
) = @_;
my @nice;

foreach my $ref ( [ scm => $scm ], [ avail => $avail ], [ type => $type] )
{
my ($name, $value) = @{$ref};
my $key = "${name}_$value";
my $nice = $NICE_ATTRIB_NAMES{$key};
ENV_sig( F => "Invalid attribute for '$key'")
if (!defined $nice);
push @nice, "$name=$value($nice)";
}

return (wantarray) ? @nice : "@nice";
}

1;
