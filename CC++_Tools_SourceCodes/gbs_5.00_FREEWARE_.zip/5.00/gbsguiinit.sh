#!must_be_sourced
#
#   gbsguiinit.sh
#
GBS_RC=0
let GBS_SCRIPT_LEVEL+=1

#
#	Set GBS_PID
#
\export GBS_PID=$$

#
#	Run gbsguiinit
#
source $GBS_SCRIPTS_PATH/gbssource.sh gbsguiinit.pl $*

\set --
\bash -c "exit $GBS_RC" # set $?

## EOF ##
