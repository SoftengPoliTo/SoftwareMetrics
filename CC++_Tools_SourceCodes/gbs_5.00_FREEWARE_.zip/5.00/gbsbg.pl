#=================================================
#
#   gbsbg.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSBG @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::genopt;
use glo::ask;
use glo::flock;
use glo::format;
use glo::proc;
use glo::time;
use mod::gbsenv;
use mod::gbsres;
use mod::logsum;
use mod::gbssyssum;
use mod::run;




sub ask_cur_view();
sub ask_cur_tail();
sub ask_kill();
sub do_show();
sub do_cleanup();
sub ask_view();
sub select_job($);
sub get_jobs($);




my $GBSSUM_PATH = "$GBS::SILO_PATH/.gbs/gbssum";

my $THIS_PLATFORM = ENV_this_osname();
my $OTHER_PLATFORM = ENV_other_osname();




my $MAX_NR_LOGFILES = 50;
my @MAIN_MENU_ITEMS = (
[ 'Show Jobs'			=> \&do_show ],
[ 'View Cur Logfile (Snapshot)'	=> \&ask_cur_view ],
[ 'Tail Cur Logfile (Continous)'    => \&ask_cur_tail ],
[ 'Cleanup List'			=> \&do_cleanup ],
[ 'View Logfile'			=> \&ask_view ],
[ 'Not used'			=> undef ],
[ 'Not used'			=> undef ],
[ 'Not used'			=> undef ],
[ 'Kill Job'			=> \&ask_kill ],
);

my @JOB_FORMAT = qw( L L L L L R L );
my @HEADS = qw( Platform Jobname Build/Tool Audit Date-Time Pid State);


my $NOW_DATETIME = TIME_time2num();	    # YYYY-MM-DD HH:MM:SS
my $TODAY = substr( $NOW_DATETIME, 0, 10);  # YYYY-MM-DD




my %PLATFORMS;

{
foreach my $att (@GBS::ALL_AUDITS, @GBS::ALL_BUILDS, @GBS::ALL_TOOLS)
{
$PLATFORMS{$att} = $OTHER_PLATFORM;
}
foreach my $att (@GBS::AUDITS, @GBS::BUILDS, @GBS::TOOLS)
{
$PLATFORMS{$att} = $THIS_PLATFORM;
}

}






my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ '<1>', 'menu_entry_1', "isor1..9", 0, "Primary menu entry for single immediate execution" ],
);
GENOPT_set_optdefs( 'gbsbg', \@genopts,
[ "Allow user to handle Background Jobs",
' 1. Show Jobs',
' 2. View Cur Logfile',
' 3, Tail Cur Logfile',
' 4. Cleanup List',
' 5. View Logfile',
'    ...',
' 9. Kill Job',
],
undef,
);
GENOPT_parse();
}
my @MENU_ENTRIES = grep( $_ != 0, map { scalar GENOPT_get( "menu_entry_$_") } 1..1);




{
ENV_say( 1, "GBS Background Jobs Handling");
if ( get_jobs( 1) > 0)
{
ASK_menu( 'Select function to perform', \@MAIN_MENU_ITEMS, [ @MENU_ENTRIES ]);
} else
{
ENV_say( 1, 'No Background Jobs data availbale');
}
}




ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
}




sub ask_cur_view()
{
my ($platform, $jobname, $build_or_tool, $audit, $nicetime, $pid, $state) = select_job( 1);

if (defined $jobname)
{
my $numtime = TIME_pack( $nicetime);
my $logfile_spec = GBSRES_join_logfile_spec( $jobname, $build_or_tool, $audit, $numtime);
if (-e $logfile_spec)
{
RUN_viewer( $logfile_spec);
} else
{
ENV_sig( E => "Logfile does not exist", $logfile_spec);
}
}
}




sub ask_cur_tail()
{
my ($platform, $jobname, $build_or_tool, $audit, $nicetime, $pid, $state) = select_job( 1);

if (defined $jobname)
{
my $numtime = TIME_pack( $nicetime);
my $logfile_spec = GBSRES_join_logfile_spec( $jobname, $build_or_tool, $audit, $numtime);
if (-e $logfile_spec)
{
RUN_tail( $logfile_spec, qw( -f -n 100));
} else
{
ENV_sig( E => "Logfile does not exist", $logfile_spec);
}
}
}




sub do_cleanup()
{
GBSSYSSUM_read();
do_show();
}




sub ask_view()
{



my @file_items_refs = sort { $b->[3] cmp $a->[3] } map { [ GBSRES_split_logfile_spec( $_) ] } ENV_glob( "$GBS::LOG_PATH/*.log");

my $nr_files = @file_items_refs;

if ($nr_files == 0)
{
ENV_say( 1, 'No Logfiles found');
} else
{
my $file_items_ref;
if ($nr_files == 1)
{
ENV_say( 1, '1 Logfile found');
$file_items_ref = $file_items_refs[0];
} else
{



if (@file_items_refs > $MAX_NR_LOGFILES)
{
ENV_say( 1, "Nr of files choice ($nr_files) will be reduced to the last $MAX_NR_LOGFILES");
splice( @file_items_refs, $MAX_NR_LOGFILES);
$nr_files = @file_items_refs;
} else
{
ENV_say( 1, "$nr_files Logfiles found");
}





foreach my $file_items_ref (@file_items_refs)
{
my ($jobname, $build_or_tool, $audit, $numtime) = @{$file_items_ref};
my $nicetime = TIME_unpack( $file_items_ref->[3]);  # $numtime
$file_items_ref->[3] = $nicetime;
my $today = (substr( $nicetime, 0, 10) eq $TODAY) ? '*' : ' ';
my $size = -s GBSRES_join_logfile_spec( $jobname, $build_or_tool, $audit, $numtime);

push (@{$file_items_ref}, $today, $size);
$file_items_ref = [ $file_items_ref ];
}
unshift @file_items_refs, '<None>';
my @log_format = qw( L L L L L R );
my $index = ASK_index_from_menu( 'Select Logfile', -1, \@log_format, \@file_items_refs);
if ($index > 0)
{
$file_items_ref = $file_items_refs[$index]->[0];
$file_items_ref->[3] = TIME_pack( $file_items_ref->[3]);  # $numtime
}
}
if (defined $file_items_ref)
{
my ($jobname, $build_or_tool, $audit, $numtime, $today, $size) = @{$file_items_ref};
my $logfile_spec = GBSRES_join_logfile_spec( $jobname, $build_or_tool, $audit, $numtime);

if (-e $logfile_spec)
{
RUN_viewer( $logfile_spec);
} else
{
ENV_sig( E => "Logfile does not exist (anymore)", $logfile_spec);
}
}
}
}




sub ask_kill()
{
my ($platform, $jobname, $build_or_tool, $audit, $nicetime, $pid, $state) = select_job( 0);

if (defined $jobname)
{



my $killed = PROC_kill( $pid);
if ($killed)
{
ENV_say( 1, "Process killed ($pid)");

} else
{
ENV_sig( W => "Failed to kill process ($pid)");
}




if ($killed)
{
my $sum_filespec = "$GBSSUM_PATH/" . join( '_', ($jobname, $build_or_tool, $audit, $nicetime)) . '.log.sum';
if (-e $sum_filespec)
{
sleep( 1);
}
if (-e $sum_filespec)
{




my @sum_items;



if (ENV_try( W => sub { @sum_items = LOGSUM_read( $sum_filespec) }, undef))
{
my $state = $sum_items[9];
if ($state eq 'START')
{

my $now = time();
my $time_start = $sum_items[5];
my $start_time = TIME_num2time( $time_start);
my $time_diff = TIME_deltatime2num( $now - $start_time );

$sum_items[6] = TIME_time2num( time());	# $pid_or_time_end
$sum_items[7] = $time_diff;		# $time_diff
$sum_items[9] = 'KILLED';		# $state
$sum_items[10] = -1;			# $rc

GBSSYSSUM_update( \@sum_items);
}
}

}
}
}
}




sub do_show()
{
my $nr_jobs_running;

my @running_filespec_refs = get_jobs( 1);
$nr_jobs_running = @running_filespec_refs;
if ($nr_jobs_running > 0)
{
ENV_say( 1, 'Running GBS Background Jobs:');
unshift @running_filespec_refs, [@HEADS ];
my @lines =  FORMAT_table( 0, 2, '  ', \@JOB_FORMAT, @running_filespec_refs);

ENV_say( 0, \@lines);
} else
{
ENV_say( 1, 'No Running or Crashed GBS Background Jobs');
}

return $nr_jobs_running;
}




sub select_job($)
{
my ($show_all) = @_;	# Bool. False is show only Running on this platform
my @job_items;


my @running_filespec_refs = get_jobs( $show_all);
if (@running_filespec_refs)
{
foreach my $running_job_ref (@running_filespec_refs)
{

$running_job_ref = [ $running_job_ref ];
}
unshift @running_filespec_refs, '<None>';
my $index = ASK_index_from_menu( 'Select Job', -1, \@JOB_FORMAT, \@running_filespec_refs);
if ($index > 0)
{
@job_items = @{$running_filespec_refs[$index]->[0]};
}
} else
{
if ($show_all)
{
ENV_say( 1, 'No Running or Crashed Jobs');
} else
{
ENV_say( 1, 'No Running Jobs on this Platform');
}
}

return @job_items;
}




sub get_jobs($)
{
my ($all_jobs,	# Bool. False is show only Running
) = @_;
my @running_filespec_refs;	    # sorted by $nicetime


foreach my $sum_filespec (ENV_glob( "$GBSSUM_PATH/*.log.sum"))
{

my ($filename) = $sum_filespec =~ m!.*/(.*)\.log.sum$!;
my $fh = FLOCK_ex_nowait( "$sum_filespec.lck");
my $state;
if (defined $fh)
{
FLOCK_unlock( $fh, 1);
$state = 'Crashed';
next if (!$all_jobs);
} else
{

$state = 'Running';
}
my @sum_items;



if (ENV_try( W => sub { @sum_items = LOGSUM_read( $sum_filespec) }, undef))
{
my $pid_or_time_end = $sum_items[6];
if ($pid_or_time_end =~ /^\d+$/)	    # d+ or dddddddd-dddddd
{
my ($jobname, $build_or_tool, $audit, $numtime) = GBSRES_split_logfile_spec( $sum_filespec);
my $att_name = ($jobname eq 'sysaudit') ? $audit : $build_or_tool;
my $platform = $PLATFORMS{$att_name};
$state = '?'
if ($platform ne $THIS_PLATFORM);
my $nicetime = TIME_unpack( $numtime);
if ($all_jobs || $platform eq $THIS_PLATFORM)
{
push @running_filespec_refs, [ $platform, $jobname, $build_or_tool, $audit, $nicetime, $pid_or_time_end, $state ];
}
}
}
}
@running_filespec_refs = sort { $b->[4] cmp $a->[4] } @running_filespec_refs;	# $nicetime

return @running_filespec_refs;
}


