#=================================================
#
#   gbscleanup.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbscleanup;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSCLEANUP_main
);
}




use glo::env;
use glo::ask;
use mod::cleanup;




sub GBSCLEANUP_main($$$);

sub cleanup_most($$$);
sub cleanup_all($$$);
sub do_cleanup_most();
sub cleanup_bld($$$);
sub cleanup_aud($$$);
sub cleanup_make($$$);
sub cleanup_export($$$);
sub cleanup_res($$$);
sub cleanup_tmp_directory($$$);
sub cleanup_obsolete_bld_files($$$);
sub cleanup_silo_user_directory($$$);
sub cleanup_silo_cache_directory($$$);
sub cleanup_usr_files($$$);
sub cleanup_currencies($$$);
sub cleanup_plugin_cache($$$);
sub select_builds();
sub select_audits();




my $ALL = '* (ALL)';




sub GBSCLEANUP_main($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;

my @menu_items;
if ($GBS::ROOT_PATH eq '')
{
ENV_say( 1, "No current Root");
push @menu_items,
[ "Cleanup User currency file (.gbsrc) (immediate)",
\&CLEANUP_currencies ];
} else
{
ENV_say( 1, "Root: $GBS::ROOT_PATH");
push @menu_items, (
[ "Cleanup MOST (*)                                 (immediate)",
\&cleanup_most ],
[ "*Cleanup Build <build> directories",
\&cleanup_bld ],
[ "*Cleanup Audit <audit>/<build> directories",
\&cleanup_aud ],
[ "*Cleanup Make-files",
\&cleanup_make ],
[ "*Cleanup EXPORT directories                      (immediate)",
\&cleanup_export ],
[ "*Cleanup RES directories                         (immediate)",
\&cleanup_res ],
[ "*Cleanup TMP directories                         (immediate)",
\&cleanup_tmp_directory ],
[ "*Cleanup obsolete BLD files                      (immediate)",
\&cleanup_obsolete_bld_files ],
[ " Cleanup SILO user directories (e.g.: doxygen)   (immediate)",
\&cleanup_silo_user_directory ],
[ " Cleanup SILO cache directories                  (immediate)",
\&cleanup_silo_cache_directory ],
[ " Cleanup .usr files                              (immediate)",
\&cleanup_usr_files ],
[ " Cleanup currency files (.gbsrc)                 (immediate)",
\&cleanup_currencies ],
[ "\nCleanup ALL                                      (immediate - sure?)",
\&cleanup_all ],
[ "\nCleanup Plugin cache directories                 (immediate)",
\&cleanup_plugin_cache ],
);
}
ASK_menu( 'Select Cleanup function to perform',
\@menu_items,
$entries_ref);
}




sub cleanup_most($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref
) = @_;

ENV_say( 1, "** Cleanup MOST derived files and directories **");

do_cleanup_most();

ENV_say( 1, "** Cleanup of MOST completed **");
}




sub cleanup_all($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref
) = @_;
ENV_say( 1, "** Cleanup ALL derived files and directories **");

do_cleanup_most();

CLEANUP_silo_user_directory();
CLEANUP_silo_cache_directory();
CLEANUP_usr_files();
CLEANUP_currencies();

ENV_say( 1, "** Cleanup of ALL completed **");
}




sub do_cleanup_most()
{
foreach my $build (@GBS::ALL_BUILDS)
{
CLEANUP_system_bld( $build);
CLEANUP_system_make_files( $build);
foreach my $audit (@GBS::AUDITS)
{
CLEANUP_system_aud( $audit, $build);
}
}

CLEANUP_export( '*');
CLEANUP_res( '*');
CLEANUP_tmp_directory();

CLEANUP_small_stuff();
}




sub cleanup_bld($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref
) = @_;

my @builds = select_builds();
if (@builds)
{
my @entries = ('');	    # <None>
push @entries,         [ "Cleanup current All       Build directories ($GBS::ROOT_PATH)",
sub { CLEANUP_system_bld( $_[0]) } ];
if ($GBS::SUBSYS ne '')
{
push @entries,     [ "Cleanup current SubSystem Build directories ($GBS::SUBSYS)",
sub { CLEANUP_subsys_bld( $GBS::SUBSYS, $_[0]) } ];
if ($GBS::COMPONENT ne '')
{
push @entries, [ "Cleanup current Component Build directories ($GBS::COMPONENT)",
sub { CLEANUP_comp_bld( $_[0]) } ];
}
}
my $index = ASK_index_from_menu( "Select Deletion Level for Build(s)", 0, undef, [ @entries ]);
if ($index > 0)
{
my $cleanup_func = $entries[$index]->[1];
foreach my $build (@builds)
{
$cleanup_func->( $build);
}
}
}
}




sub cleanup_aud($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref
) = @_;

my @audits = select_audits();
if (@audits)
{
my @builds = select_builds();
if (@builds)
{
my @entries = ('');	    # <None>
push @entries,         [ "Cleanup current All       Audit directories ($GBS::ROOT_PATH)",
sub { CLEANUP_system_aud( $_[0], $_[1]) } ];
if ($GBS::SUBSYS ne '')
{
push @entries,     [ "Cleanup current SubSystem Audit directories ($GBS::SUBSYS)",
sub { CLEANUP_subsys_aud( $GBS::SUBSYS, $_[0], $_[1]) } ];
if ($GBS::COMPONENT ne '')
{
push @entries, [ "Cleanup current Component Audit directories ($GBS::COMPONENT)",
sub { CLEANUP_comp_aud( $_[0], $_[1]) } ];
}
}
my $index = ASK_index_from_menu( "Select Deletion Level for Audit(s)/Build(s) ", 0, undef, [ @entries ]);
if ($index > 0)
{
my $cleanup_func = $entries[$index]->[1];
foreach my $audit (@audits)
{
foreach my $build (@builds)
{
$cleanup_func->( $audit, $build);
}
}
}
}
}
}




sub cleanup_make($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref
) = @_;

my @builds = select_builds();
if (@builds)
{
my @entries = ('');	    # <None>
push @entries,         [ "Cleanup current System    Make files ($GBS::ROOT_PATH)",
sub { CLEANUP_system_make_files( $_[0]) } ];
if ($GBS::SUBSYS ne '')
{
push @entries,     [ "Cleanup current SubSystem Make files ($GBS::SUBSYS)",
sub { CLEANUP_subsys_make_files( $_[0]) } ];
}
my $index = ASK_index_from_menu( "Select Deletion Level for Build(s) ", 0, undef, [ @entries ]);
if ($index > 0)
{
my $cleanup_func = $entries[$index]->[1];
foreach my $build (@builds)
{
$cleanup_func->( $build);
}
}
}
}




sub cleanup_export($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref
) = @_;

CLEANUP_export( '*');
}




sub cleanup_res($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref
) = @_;

CLEANUP_res( '*');
}




sub cleanup_tmp_directory($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref
) = @_;

CLEANUP_tmp_directory();
}




sub cleanup_obsolete_bld_files($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref
) = @_;

CLEANUP_obsolete_bld_files();
}




sub cleanup_silo_user_directory($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref
) = @_;

CLEANUP_silo_user_directory();
}




sub cleanup_silo_cache_directory($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref
) = @_;

CLEANUP_silo_cache_directory();
}




sub cleanup_usr_files($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref
) = @_;

CLEANUP_usr_files();
}




sub cleanup_currencies($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref
) = @_;

CLEANUP_currencies();
}




sub cleanup_plugin_cache($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref
) = @_;

CLEANUP_plugin_cache_directories();
}




sub select_builds()
{
my @builds;

if (@GBS::ALL_BUILDS == 0)
{
ENV_say( 1, "No Builds");
} elsif( @GBS::ALL_BUILDS == 1)
{
@builds = @GBS::ALL_BUILDS;
ENV_say( 1, "Single Build '@builds'");
} else
{
my @list = ('', $ALL, @GBS::ALL_BUILDS);	# '' == <None>
my $build = ASK_value_from_menu( "Select Build ('*' == ALL)", \$GBS::BUILD, undef, [ @list ]);
@builds = ($build eq '') ? () : ($build eq $ALL) ? @GBS::ALL_BUILDS : ($build);
}

return @builds;
}




sub select_audits()
{
my @audits;

if (@GBS::AUDITS == 0)
{
ENV_say( 1, "No Audits");
} elsif( @GBS::AUDITS == 1)
{
@audits = @GBS::AUDITS;
ENV_say( 1, "Single Audit '@audits'");
} else
{
my @list = ('', $ALL, @GBS::AUDITS);	# '' == <None>
my $audit = ASK_value_from_menu( "Select Audit ('*' == ALL)", \$GBS::AUDIT, undef, [ @list ]);
@audits = ($audit eq '') ? () : ($audit eq $ALL) ? @GBS::AUDITS : ($audit);
}

return @audits;
}

1;

