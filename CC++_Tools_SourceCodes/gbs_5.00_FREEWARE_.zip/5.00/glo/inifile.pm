#=================================================
#
#   inifile.pm
#
#=================================================
#   This FILE is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright © 2010-2020 - Randy Marques - All rights reserved
#=================================================
package glo::inifile;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
INIFILE_load
INIFILE_sections
INIFILE_properties
INIFILE_set_sect
INIFILE_get_prop
INIFILE_update_prop
INIFILE_replace_prop
INIFILE_save
INIFILE_dump
INIFILE_close
);
}




use glo::env;
use glo::slurp;
use glo::spit;




sub INIFILE_load($$);
sub INIFILE_sections();
sub INIFILE_properties($);
sub INIFILE_set_sect($);
sub INIFILE_get_prop($$$);
sub INIFILE_update_prop($$$);
sub INIFILE_replace_prop($$$$);
sub INIFILE_save();
sub INIFILE_dump($);
sub INIFILE_close();




my $FILESPEC;
my @LINES;
my %FILE;

my $CURRENT_SECTION;
my $CUR_SECTION_REF;
my $FILE_CHANGED;






sub INIFILE_load($$)
{
my ($filespec,		    # file must exist!
$section_properties_ref,    # [ $section => ($prop => $value_or_ref), ...], ...
) = @_;
my @parse_errors;



$FILESPEC = $filespec;
$CURRENT_SECTION = '';
%FILE = ();
$FILE_CHANGED = 0;

my $file_created = 0;
if (defined $section_properties_ref && !-e $FILESPEC)
{



my %items;
my @keys_order;
foreach my $section_ref (@{$section_properties_ref})
{
my ($section_name, @property_pairs) = @{$section_ref};
while (@property_pairs)
{
my $prop_name = shift @property_pairs;
my $prop_value = ENV_deref( shift @property_pairs);
my $key = "$section_name]$prop_name";
push @keys_order, $key
if (!exists $items{$key});
$items{$key} = $prop_value;
}
}

my $file = ENV_split_spec_f( $FILESPEC);
my @lines;
push @lines, '#';
push @lines, "#   $file";
push @lines, '#';
$CURRENT_SECTION = '';
foreach my $key (@keys_order)
{
my ($section_name, $prop_name) = split (']', $key);
my $prop_value = $items{$key};
if ($section_name ne $CURRENT_SECTION)
{
push @lines, "[$section_name]";
$CURRENT_SECTION = $section_name;
}
push @lines, "  $prop_name = $prop_value";
}
SPIT_file_nl( $FILESPEC, \@lines);
$file_created = 1;
}




@LINES = SLURP_file( $FILESPEC);




my $line_nr = 0;
foreach my $line (@LINES)
{
$line_nr++;
next if ($line eq '' || $line =~ /^\s*#/);

if ($line =~ /^\s*\[\s*(.+)\s*\]/)
{
$CURRENT_SECTION = $1;

} elsif ($line =~ /^(\s*)(.+?)(\s*=\s*)(.*)/)
{
my $indent = $1;
my $key = $2;
my $equals = $3;
my $value = $4;
my $key_part = "$indent$key$equals";
$FILE{$CURRENT_SECTION}->{$key} = [ $key_part, $value, \$line ];

} else
{
push @parse_errors, sprintf( "- Invalid line %4d: %s", $line_nr, ENV_detab( $line));
}
}

if (@parse_errors)
{
ENV_sig( F => "Initialisation error", $FILESPEC)
if ($file_created);
unshift @parse_errors, $FILESPEC;
} else
{



foreach my $section_ref (@{$section_properties_ref})
{
my ($section_name, @property_pairs) = @{$section_ref};
while (@property_pairs)
{
my $prop_name = shift @property_pairs;
my $prop_value = ENV_deref( shift @property_pairs);
if (!exists $FILE{$section_name}->{$prop_name})
{

my $key_part = "  $prop_name = ";
my $line = "$key_part$prop_value";
my $line_ref;
if (!exists $FILE{$section_name})
{
push @LINES, "[$section_name]";
push @LINES, $line;
$line_ref = \$LINES[-1];
} else
{
my $i = 0;
while ($LINES[$i] !~ /^\s*\[\s*$section_name\s*\]/)
{
$i++;
}
$i++;   # Skip " [ $section_name ]"

while (defined $LINES[$i] && $LINES[$i] !~ /^\s*\[.+\]/)
{
$i++;
}
if (defined $LINES[$i])
{




splice @LINES, $i, 0, $line;
$line_ref = \$LINES[$i];
} else
{



push @LINES, $line;
$line_ref = \$LINES[-1];
}
}
$FILE{$section_name}->{$prop_name} = [ $key_part, $prop_value, $line_ref ];
$FILE_CHANGED = 1;
}
}
}
INIFILE_save();

}


return @parse_errors;
}







sub INIFILE_sections()
{
return keys %FILE;
}







sub INIFILE_properties($)
{
my ($section,
) = @_;

if (exists( $FILE{$section}))
{
return keys( %{$FILE{$section}});
} else
{
return (wantarray) ? () : undef;
}
}






sub INIFILE_set_sect($)
{
my ($section,
) = @_;
my $found = 0;

if (exists( $FILE{$section}))
{
$CURRENT_SECTION = $section;
$CUR_SECTION_REF = $FILE{$section};
$found = 1;
}

return $found;
}





sub INIFILE_get_prop($$$)
{
my ($section,	    # undef takes CURRENT
$prop_key,
$sig_on_error,	    # '', 'E', 'EE', etc
) = @_;
my $prop_value;

my $key_ref;
if (defined $section)
{
$key_ref = $FILE{$section}->{$prop_key}
if (exists( $FILE{$section}));
} else
{
$key_ref = $CUR_SECTION_REF->{$prop_key};
}
if (defined $key_ref)
{
$prop_value = $key_ref->[1];
} else
{
if ($sig_on_error ne '')
{
$section = "*$CURRENT_SECTION*"	# for the error-message
if (!defined $section);
ENV_sig( $sig_on_error => "'[$section]$prop_key' key not found",
"- in '$FILESPEC'");
}
}

return $prop_value;
}






sub INIFILE_update_prop($$$)
{
my ($section,	    # undef takes CURRENT
$prop_key,
$prop_value_or_ref,
) = @_;
my $changed = 0;



my $prop_value = ENV_deref( $prop_value_or_ref);

my $key_ref;
if (defined $section)
{
$key_ref = $FILE{ $section}->{$prop_key};
} else
{
$section = "*$CURRENT_SECTION*";	# for the error-message
$key_ref = $CUR_SECTION_REF->{$prop_key};
}
ENV_sig( EE => "'[$section]$prop_key' key not found in", "- '$FILESPEC'")
if (!defined $key_ref);

my ($key_part, $value, $line_ref) = @{$key_ref};
if ($value ne $prop_value)
{
$key_ref->[1] = $prop_value;			# $prop_value

$$line_ref = "$key_part$prop_value";

$FILE_CHANGED = 1;
$changed = 1;
}

return $changed;
}






sub INIFILE_replace_prop($$$$)
{
my ($section,	    # undef takes CURRENT
$old_prop_key,
$prop_key,
$prop_value,
) = @_;
my $changed = 0;

my $key_ref;
if (defined $section)
{
$key_ref = $FILE{ $section}->{$prop_key};
ENV_sig( EE => "'[$section]$old_prop_key' key not found in", "- '$FILESPEC'")
if (!defined $key_ref);
} else
{
$key_ref = $CUR_SECTION_REF->{$old_prop_key};
ENV_sig( EE => "'[*$CURRENT_SECTION*]$old_prop_key' key not found in", "- '$FILESPEC'")
if (!defined $key_ref);
}

my ($key_part, $value, $line_ref) = @{$key_ref};

if ($old_prop_key ne $prop_key)
{
$key_part =~ s/$old_prop_key/$prop_key/;
$key_ref->[0] = $key_part;			# $key_part
if (defined $section)
{
$FILE{ $section}->{$prop_key} = $key_ref;
delete( $FILE{ $section}->{$old_prop_key});
} else
{
$CUR_SECTION_REF->{$prop_key} = $key_ref;
delete( $CUR_SECTION_REF->{$old_prop_key});
}
$changed = 1;
$FILE_CHANGED = 1;
}
if ($value ne $prop_value)
{
$key_ref->[1] = $prop_value;			# $prop_value

$$line_ref = "$key_part$prop_value";

$FILE_CHANGED = 1;
$changed = 1;
}

return $changed;
}





sub INIFILE_save()
{
my $written = 0;




if ($FILE_CHANGED)
{
$FILE_CHANGED = 0;
SPIT_file_nl( $FILESPEC, \@LINES);
$written = 1;
}



return $written;
}




sub INIFILE_dump($)
{
my ($section,		# undef == all sections
) = @_;

ENV_say( 1, "Dump '$FILESPEC'");
my @keys = (defined $section) ? $section : keys( %FILE);

foreach my $section (@keys)
{
ENV_say( 0, "[$section]");
my $max_key_length = 0;
foreach my $key (keys( %{$FILE{$section}}))
{
$max_key_length = length( $key)
if (length( $key) > $max_key_length);
}
while (my ($key, $value_ref) = each( %{$FILE{$section}}))
{
my ($key_part, $value, $line_ref) = @{$value_ref};
ENV_say( 0, sprintf( "%-*s => %s", $max_key_length, $key,  $key_part));
ENV_say( 0, sprintf( "%-*s    %s", $max_key_length, '',    $value));
ENV_say( 0, sprintf( "%-*s    %s", $max_key_length, '',    $$line_ref));
}
}
}





sub INIFILE_close()
{
$FILESPEC = undef;
@LINES = ();
%FILE = ();
$CURRENT_SECTION = undef;
$FILE_CHANGED = undef;
}

1;

