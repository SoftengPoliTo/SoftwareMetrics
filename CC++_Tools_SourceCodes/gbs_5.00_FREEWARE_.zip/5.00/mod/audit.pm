#=================================================
#
#   audit.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::audit;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
AUDIT_read
AUDIT_get_section_items
AUDIT_get_src_types
AUDIT_get_src_items
AUDIT_get_primary_out_type
AUDIT_get_src_command_data_refs
AUDIT_get_src_command_data_refs_exp
AUDIT_get_section_commands_data_refs
AUDIT_get_summary_command_data_refs_exp
AUDIT_get_maint_command_ref
AUDIT_get_plugin
);
}




use glo::env;
use mod::gbssfile;
use mod::gbsfilecom;
use mod::gbsfileglo;




sub AUDIT_read($;$);
sub AUDIT_get_section_items($$@);
sub AUDIT_get_src_types($);
sub AUDIT_get_src_items($$@);
sub AUDIT_get_primary_out_type($$);
sub AUDIT_get_src_command_data_refs($$);
sub AUDIT_get_src_command_data_refs_exp($$$$);
sub AUDIT_get_section_commands_data_refs($$);
sub AUDIT_get_summary_command_data_refs_exp($$);
sub AUDIT_get_maint_command_ref($);
sub AUDIT_get_plugin($);

sub read_audit($);
sub do_src_entry($$);
sub do_src_out_types($$$$$);
sub do_src_format($$$$$);
sub do_src_multi_src($$$$$);
sub do_maint_command($$$$$);








my @MULTI_SRC_TYPES = qw( NO YES COMMA_LIST);
my %MULTI_SRC_TYPES = map { $_ => 1 } @MULTI_SRC_TYPES;







my %DUP_OUT_TYPES;





my $CUR_AUDIT = '';
my $CUR_AUDIT_REF;







my %AUDITS = ();












































my %SETUP_DEFS = (
NICE_NAME	    => [ 'ss' , undef,     0, 1,     1,			 undef, undef ],
VIA_FORMAT	    => [ 'av' , ['',''],   0, 2,     undef,		 undef, undef ],
REQUIRE	    => [ 'ps' , [],	   0, 3,     1,			 undef, undef ],
);

my %CONFIG_DEFS = (
NAME	    => [ 'ss' , undef,     0, 1,     1,			 undef, undef ],
);

my %INIT_DEFS = (
SET_W	    => [ 'pa' , [],	   0, 1,     1,			 undef,	undef ],
SET_X	    => [ 'pa' , [],	   0, 1,     1,			 undef,	undef ],
SET		    => [ 'pa' , [],	   0, 2,     1,			 undef,	undef ],
SETPATH	    => [ 'pa' , [],	   0, 3,   [1],			 undef,	undef ],
BIN_DIR	    => [ 'ss' , '',	   0, 3,     1,			 undef,	undef ],
COMMAND	    => [ 'pc' , [],	   0, 4, undef,			 undef, undef ],    # $command_data_ref
);

my %SRC_DEFS = (
OUT_TYPES	    => [ 'ast', [],        1, 1,   [1],	    \&do_src_out_types, undef ],
OUT_FILES	    => [ 'ast', [],	   0, 1,   [1],			 undef,	undef ],
INC_FORMAT	    => [ 'af' , ['',''],   0, 1, undef,	       \&do_src_format,	undef ],
SYSINC_FORMAT   => [ 'af' , ['',''],   0, 1, undef,	       \&do_src_format,	undef ],
FLAG_FORMAT	    => [ 'af' , ['',''],   0, 1, undef,	       \&do_src_format,	undef ],
SYSFLAG_FORMAT  => [ 'af' , ['',''],   0, 1, undef,	       \&do_src_format,	undef ],
MULTI_SRC	    => [ 'as' , ['NO', ''], 0, 2, [1],	    \&do_src_multi_src, undef ],
COMMAND	    => [ 'pc' , [],	   1, 3, undef,			 undef, undef ],    # $command_data_refs
);

my %SUM_DEFS = (
COMMAND	    => [ 'ac' , [],	   1, 2, undef,			 undef, undef ],    # $command_data_ref
);

my %MAINT_DEFS = (
COMMAND	    => [ 'ac' , [],	   1, 2, undef,	    \&do_maint_command, undef ],    # $command_data_ref
);










my %SECTION_DEFS = (
SETUP   => [ 'N', 0, 1, 0,   \%SETUP_DEFS,  undef,		undef ],
CONFIG  => [ 'N', 0, 0, 0,   \%CONFIG_DEFS, undef,		undef ],
INIT    => [ 'N', 0, 0, 0,   \%INIT_DEFS,   undef,  	undef ],
SRC	    => [ 'S', 1, 0, [1], \%SRC_DEFS,    \&do_src_entry, undef ],
SUMMARY => [ 'N', 0, 2, 0,   \%SUM_DEFS,    undef,		undef ],
MAINT   => [ 'N', 0, 1, 0,   \%MAINT_DEFS,  undef,		undef ],
);




sub AUDIT_read($;$)
{
my ($audit,
$force_read,	    # Optional
) = @_;
my $struct_id;

read_audit( $audit)
if ($audit ne $CUR_AUDIT || $force_read);

$struct_id = "sysaudit/$audit";

return $struct_id;
}




sub AUDIT_get_section_items($$@)
{
my ($audit,
$section,
@items,
) = @_;
my @values = ();

read_audit( $audit)
if ($audit ne $CUR_AUDIT);

return GBSSFILE_get_section_items( $CUR_AUDIT_REF, $section, @items);
}




sub AUDIT_get_src_types($)
{
my ($audit,
) = @_;


read_audit( $audit)
if ($audit ne $CUR_AUDIT);

return @{$CUR_AUDIT_REF->{SRC}->{'.'}->{ORDER}};
}




sub AUDIT_get_src_items($$@)
{
my ($audit,
$src_type,
@items,
) = @_;
my @values = ();


read_audit( $audit)
if ($audit ne $CUR_AUDIT);

return GBSSFILE_get_subsection_items( $CUR_AUDIT_REF, 'SRC', $src_type, @items);
}




sub AUDIT_get_primary_out_type($$)
{
my ($audit,
$src_type,
) = @_;
my $out_type;

read_audit( $audit)
if ($audit ne $CUR_AUDIT);

ENV_sig( F => "Unknown src-type '$src_type' for Audit '$CUR_AUDIT'")
if (! exists $CUR_AUDIT_REF->{SRC}->{$src_type});

$out_type = $CUR_AUDIT_REF->{SRC}->{$src_type}->{OUT_TYPES}->[0];


return $out_type;
}




sub AUDIT_get_src_command_data_refs($$)
{
my ($audit,
$src_type,
) = @_;
my $command_data_refs_ref;	# or @command_data_refs



read_audit( $audit)
if ($audit ne $CUR_AUDIT);

$command_data_refs_ref = $CUR_AUDIT_REF->{SRC}->{$src_type}->{COMMAND};

return (wantarray) ? @{$command_data_refs_ref} : $command_data_refs_ref;
}




sub AUDIT_get_src_command_data_refs_exp($$$$)
{
my ($audit,
$src_type,
$pos_args_ref,		    # 1=$file_name, 2=$in_filespec, 3=$out_filespec, 4=$out_file_dir, 5=$out_filetype
$command_line_flags_ref,    # *
) = @_;
my @command_data_refs;



my $nr_pos_args = @{$pos_args_ref};
ENV_sig( F => "Nr pos_args ($nr_pos_args) must be 5")
if ($nr_pos_args != 5);

read_audit( $audit)
if ($audit ne $CUR_AUDIT);

my $command_data_refs_ref = AUDIT_get_src_command_data_refs( $audit, $src_type);
@command_data_refs = GBSFILECOM_expand_command_data_refs( $command_data_refs_ref, $pos_args_ref, $command_line_flags_ref);

return (wantarray) ? @command_data_refs : \@command_data_refs;
}




sub AUDIT_get_section_commands_data_refs($$)
{
my ($audit,
$section,   # SUMMARY or MAINT
) = @_;
my $command_data_refs_ref;	# or @command_data_refs



read_audit( $audit)
if ($audit ne $CUR_AUDIT);

$command_data_refs_ref = $CUR_AUDIT_REF->{$section}->{COMMAND};

return (wantarray) ? @{$command_data_refs_ref} : $command_data_refs_ref;
}




sub AUDIT_get_summary_command_data_refs_exp($$)
{
my ($audit,
$pos_args_ref,	    # 1=$sum_filespec
) = @_;
my @command_data_refs;  # may be empty



my $nr_pos_args = @{$pos_args_ref};
ENV_sig( F => "Nr pos_args ($nr_pos_args) must be 1")
if ($nr_pos_args != 1);

read_audit( $audit)
if ($audit ne $CUR_AUDIT);

my $command_data_refs_ref = AUDIT_get_section_commands_data_refs( $audit, 'SUMMARY');
@command_data_refs = GBSFILECOM_expand_command_data_refs( $command_data_refs_ref, $pos_args_ref, undef)
if (defined $command_data_refs_ref);

return (wantarray) ? @command_data_refs : \@command_data_refs;
}





sub AUDIT_get_maint_command_ref($)
{
my ($audit) = @_;
my $command_items_ref;	    # May be undef

read_audit( $audit)
if ($audit ne $CUR_AUDIT);

my $command_data_refs_ref = AUDIT_get_section_commands_data_refs( $audit, 'MAINT');

if (@{$command_data_refs_ref})
{
my ($command_data_ref) = GBSFILECOM_expand_command_data_refs( $command_data_refs_ref, undef, undef);
$command_items_ref = $command_data_ref->[1];   # $command_items_ref
}

return $command_items_ref;
}




sub AUDIT_get_plugin($)
{
my ($audit) = @_;


read_audit( $audit)
if ($audit ne $CUR_AUDIT);

return $CUR_AUDIT_REF->{'.'}->{PLUGIN_NAME};
}




sub read_audit($)
{
my ($audit) = @_;

$CUR_AUDIT = $audit;
$CUR_AUDIT_REF = $AUDITS{$CUR_AUDIT};
if (!defined $CUR_AUDIT_REF)
{

$AUDITS{$CUR_AUDIT} = {};
$CUR_AUDIT_REF = $AUDITS{$CUR_AUDIT};




my $gbs_sysaudit_path = "$GBS::ROOT_PATH/sysaudit";	    # GBS::SYSAUDIT_PATH may not have been set yet (gbsswr)
my $audit_file = "$gbs_sysaudit_path/$CUR_AUDIT/audit";
my @inc_path = ( "$gbs_sysaudit_path/$CUR_AUDIT",
$gbs_sysaudit_path);
GBSSFILE_parse( $CUR_AUDIT_REF, $audit_file, \@inc_path, \%SECTION_DEFS);




%DUP_OUT_TYPES = ();


}
}




sub do_src_entry($$)
{
my ($section,	    # SRC
$args_ref,	    # $src_types
) = @_;






foreach my $src_type (@{$args_ref})
{
GBSFILEGLO_sig( EE => "SRC '$src_type' must start with a . (dot), followed by at least one character")
if ($src_type !~ /\../);
GBSFILEGLO_sig( EE => "SRC '.glkb' is reserved for internal use")
if ($src_type eq '.glkb');
}

return @{$args_ref};
}




sub do_src_out_types($$$$$)
{
my ($section,	# SRC
$subsection,	# .c .cpp, etc
$item,		# OUT_TYPES
$values_ref,	# [@values]
$constr_arg,
) = @_;

my @values = @{$values_ref};

my $primary_type = $values[0];
GBSFILEGLO_sig( EE => "Primary Output-type ($primary_type) must start with '.'")
if (substr( $primary_type, 0, 1) ne '.');

foreach my $value (@values)
{

if (!$DUP_OUT_TYPES{$value})
{

push @{$CUR_AUDIT_REF->{'.'}->{OUT_TYPES}}, $value;
$DUP_OUT_TYPES{$value} = 1;
}
}

return @values;
}




sub do_src_format($$$$$)
{
my ($section,	# SRC
$subsection,	# e.g. .c .cpp .glk
$item,		# INC_FORMAT SYSINC_FORMAT FLAG_FORMAT SYSFLAG_FORMAT
$values_ref,	# ($env_type, $printf_format)
$constr_arg,
) = @_;
my ($env_type, $printf_format) = @{$values_ref};


return ( $env_type, $printf_format );
}




sub do_src_multi_src($$$$$)
{
my ($section,	# SRC
$subsection,	# e.g. .c, .cpp
$item,		# MULTI_SRC
$values_ref,	# ($multi_src_type, @printf_format_values)	(NO YES COMMA_LIST)
$constr_arg,
) = @_;
my ($multi_src_type, $printf_format);

($multi_src_type, my @printf_format_values) = @{$values_ref};
$printf_format = "@printf_format_values";


GBSFILEGLO_sig( EE => "Unknown MULTI_SRC type: $multi_src_type",
"Allowed values are: (@MULTI_SRC_TYPES)")
if (!exists $MULTI_SRC_TYPES{$multi_src_type});
GBSFILEGLO_sig( EE => "Cannot specify printf_format ($printf_format) with MULTI_SRC type 'No")
if ($multi_src_type eq 'NO' && $printf_format ne '');
GBSFILEGLO_sig( EE => "MULTI_SRC printf_format ($printf_format) must contain '%s'")
if ($printf_format ne '' && $printf_format !~ /%s/);

return ( $multi_src_type, $printf_format ); # MULTI_SRC
}




sub do_maint_command($$$$$)
{
my ($section,	    # MAINT
$subsection,	    # undef
$item,		    # COMMAND
$values_ref,	    # [$command_type, $command_items_ref, $ok_values, $exec_condition, $pos_arg_tokens];

$constr_arg,	    # undef
) = @_;


my $command_data_refs_ref = $CUR_AUDIT_REF->{MAINT}->{COMMAND};
GBSFILEGLO_sig( E => "Can only have one Command for MAINT")
if (@{$command_data_refs_ref} == 1);

return @{$values_ref};
}

1;


