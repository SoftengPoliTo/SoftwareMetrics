#=================================================
#
#  genopt_parse.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::genopt_parse;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GENOPT_PARSE_file
);
}




use glo::env;
use glo::slurp;




sub GENOPT_PARSE_file($$);

















sub GENOPT_PARSE_file($$)
{
my ($filespec,
$is_run_environment,	# bool. 0 == non-run environment (genhelp). Controls GBS::BUILDS, etc,
) = @_;
my ($flag_prefix,		# default = '--'
$prog_names_ref,	# this is the name of the program, with aliasses

$help_text_ref,		# this is the general help-text. NOT optional
$extra_text_ref,	# this is the (optional) aditional help-text


);
my @items_refs;
my @conf_item_refs;
my @env_items;

$flag_prefix = '--';


























ENV_whisper( 1, "Parse $filespec");
my $lines = SLURP_file( $filespec);
my @items = $lines =~ /^.*?							# lead
my\s+\@genopts\s+=\s+(\(.*?\n\s+\);).*?\n		#
\s*							# skip
(?:my\s+\@genconflicts\s+=\s+(\(.*?\n\s+\);).*?\n)?	# optional
\s*							# skip
(?:my\s+\@genenvs\s+=\s+(.*?\;).*?\n)?		# optional
\s*							# skip
(?:GENOPT_set_flag_prefix\((.*?)\);.*?\n)?		# optional
\s*							# skip
GENOPT_set_optdefs\((.*?)\);\s*\n			#
/xs;
if (@items)
{

my ($genopts_part, $genconflicts_part, $genenvs_part, $set_flag_prefix_part, $set_optdefs_part) = @items;
{




my $app = ENV_get_application_name();	# 'GBS';
if (!$is_run_environment && $genopts_part =~ /\$${app}::/)
{

$genopts_part =~ s/\$${app}::/\\\$${app}::/g;

}
my $max_menu='$max_menu';		#predefine fot eval
@items_refs = eval( $genopts_part);					    ## no critic
ENV_sig( F => "'eval' failed", $@, $genopts_part)
if ($@);

}
if ($genconflicts_part)
{




@conf_item_refs = eval( $genconflicts_part);			    ## no critic
ENV_sig( F => "'eval' failed", $@, $genconflicts_part)
if ($@);

}
if ($genenvs_part)
{




@env_items = eval( $genenvs_part);					    ## no critic
ENV_sig( F => "'eval' failed", $@, $genenvs_part)
if ($@);

}
if ($set_flag_prefix_part)
{




$flag_prefix = eval( $set_flag_prefix_part);			    ## no critic
ENV_sig( F => "'eval' failed", $@, $set_flag_prefix_part)
if ($@);

}
{




$set_optdefs_part =~ s/\\\@genopts\s*,//;

my @opt_defs = eval( $set_optdefs_part);				    ## no critic
ENV_sig( F => "'eval' failed", $@, $set_optdefs_part)
if ($@);

($prog_names_ref, $help_text_ref, $extra_text_ref) = @opt_defs;
$prog_names_ref = [ $prog_names_ref ]
if (defined $prog_names_ref && !ref $prog_names_ref);
$help_text_ref = [ $help_text_ref ]
if (defined $help_text_ref && !ref $help_text_ref);
$extra_text_ref = [ $extra_text_ref ]
if (defined $extra_text_ref && !ref $extra_text_ref);
}



return ($flag_prefix, $prog_names_ref, \@items_refs, $help_text_ref, $extra_text_ref, \@conf_item_refs, \@env_items);
} else
{
ENV_sig( E => "'genopts' and/or 'GENOPT_set_optdefs' not found in $filespec");

return ();
}
}

1;
