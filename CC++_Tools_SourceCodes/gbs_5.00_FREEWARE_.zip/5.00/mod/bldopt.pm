#=================================================
#
#   bldopt.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::bldopt;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
BLDOPT_init
BLDOPT_get_options_flags
BLDOPT_get_envs_settings
);
}




use glo::env;
use glo::spit;
use mod::gbsenv;
use mod::build;
use mod::audit;
use mod::flincs;




sub BLDOPT_init();
sub BLDOPT_get_options_flags($$);
sub BLDOPT_get_envs_settings($$$);

sub get_incs($$$);
sub format_incs($$);
sub get_flags($$$);
sub format_flags($$);
sub get_format($$);




my $FOR_AUDIT;	# bool

my $VIA_FORMAT;
my $VIA_FILE_TYPE;

my @OPTION_REFS;    #  MODE OPT DEBUGGER MAP


my %FORMAT_CACHE;


my %OPTIONS_CACHE;





my $SUBS_TOKEN_1 = (ENV_is_win32()) ? '%1' : '\\$1';	    # %1 or $1

my @FLAGS_INCS_ORDER = qw( sysflags flags incs sysincs);





sub BLDOPT_init()
{
$FOR_AUDIT = GBSENV_doing_audit();

my $banner;

if ($FOR_AUDIT)
{
($VIA_FORMAT, $VIA_FILE_TYPE) = AUDIT_get_section_items( $GBS::AUDIT, SETUP => 'VIA_FORMAT');
} else
{
($VIA_FORMAT, $VIA_FILE_TYPE) = BUILD_get_section_items( $GBS::BUILD, SETUP => 'VIA_FORMAT');
}




@OPTION_REFS = BUILD_get_options( $GBS::BUILD, $FOR_AUDIT);    #  MODE OPT DEBUGGER MAP

my @banner;
foreach my $opt_ref (@OPTION_REFS)    #  MODE OPT DEBUGGER MAP
{
my ($opt_name, $default_value_name, undef, $choice) = @{$opt_ref};
my $banner = "$opt_name=$choice";
$banner .= " ($default_value_name)"
if ($choice ne $default_value_name);
push @banner, $banner;
}
$banner = join( ', ', @banner);

return $banner;
}






sub BLDOPT_get_options_flags($$)
{
my ($src_type,
$map_filespec,	    # undef if gentype != glkb
) = @_;
my @options_flags;




ENV_sig( F => 'BLDOP_init was not called')
if (!defined $FOR_AUDIT);





my $map_option_index;
my $options_flags_ref = $OPTIONS_CACHE{$src_type};
if (defined $options_flags_ref)
{
( $map_option_index,  @options_flags ) = @{$options_flags_ref};
} else
{
$map_option_index = -1;
foreach my $opt_ref (@OPTION_REFS)
{
my ($opt_name, $default_value_name, undef, $choice) = @{$opt_ref};    #  MODE OPT DEBUGGER MAP
my @values = BUILD_get_src_subitems( $GBS::BUILD, $src_type, $opt_name, $choice);
if ($opt_name eq 'MAP')
{
foreach my $value (@values)
{
push @options_flags, $value;
$map_option_index = $#options_flags
if ($value =~ /$SUBS_TOKEN_1/);	    # $SUBS_TOKEN_1 = (ENV_is_win32()) ? '%1' : '\\$1';
}
} else
{
push @options_flags, @values;
}
}




@options_flags = grep( /^"?-D/, @options_flags)
if ($FOR_AUDIT);

my (undef, $flag_format) = get_format( flags => $src_type);


format_flags( \@options_flags, $flag_format);

$OPTIONS_CACHE{$src_type} = [ $map_option_index, @options_flags ];
}




if (defined $map_filespec && $map_option_index >= 0)
{




$options_flags[$map_option_index] =~ s/$SUBS_TOKEN_1/$map_filespec/g;	# $SUBS_TOKEN_1 = (ENV_is_win32()) ? '%1' : '\\$1';
}


return @options_flags;
}






sub BLDOPT_get_envs_settings($$$)
{
my ($subsys,
$component,	    # '' if non-gbs subsys
$src_type,
) = @_;
my @env_def_refs;	    # ( [ $envvar_name => @envvar_values ], ... )




ENV_sig( F => 'BLDOPT_init was not called')
if (!defined $FOR_AUDIT);




my $env_name_postfix = '';
if ($component eq '')
{
$env_name_postfix = '_' . uc( substr( $src_type, 1));
}
my $out_file_path;
if ($component)
{



if ($FOR_AUDIT)
{
$out_file_path = "../aud/$GBS::AUDIT/$GBS::BUILD";
} else
{
$out_file_path = "../bld/$GBS::BUILD";
}
} else
{



if ($FOR_AUDIT)
{
$out_file_path = "$GBS::ROOT_PATH/dev/$subsys/opts/aud/$GBS::AUDIT/$GBS::BUILD";
} else
{
$out_file_path = "$GBS::ROOT_PATH/dev/$subsys/opts/bld/$GBS::BUILD";
}
ENV_mkpath( $out_file_path);
}




my @flinc_filespecs;
my $flincs_filetype = ($VIA_FILE_TYPE) ? $VIA_FILE_TYPE : '.gbs';
foreach my $flinc (@FLAGS_INCS_ORDER)   # = qw( sysflags flags incs sysincs)
{
push @flinc_filespecs, "$out_file_path/$flinc$src_type$flincs_filetype";
}

unlink @flinc_filespecs;




my @flincs;

push @flincs, get_flags( $subsys, $component, $src_type);
push @flincs, get_incs( $subsys, $component, $src_type);

for (my $i = 0; $i < @FLAGS_INCS_ORDER; $i++) # = qw( sysflags flags incs sysincs)
{
my $flinc_type = $flincs[$i*2];
my $flincs_ref = $flincs[$i*2+1];


my @envvar_values;
if ($flinc_type eq 'FILE')
{




my $flinc_filespec = $flinc_filespecs[$i];
SPIT_file_nl( $flinc_filespec, $flincs_ref);


@envvar_values = (sprintf( $VIA_FORMAT, $flinc_filespec));
} else	#$flincs_type eq 'LIST'
{
@envvar_values = @{$flincs_ref};
}
my $env_name = $FLAGS_INCS_ORDER[$i];	# = qw( sysflags flags incs sysincs)
my $flinc_uc = uc $env_name;
push @env_def_refs, [ "GBS_$flinc_uc$env_name_postfix" => @envvar_values ];

}




if ($FOR_AUDIT)
{
my $audit_flags = ENV_getenv( 'GBS_FLAGS_'. uc $GBS::AUDIT);
push @env_def_refs, [ 'GBS_AUDIT_FLAGS', $audit_flags];
}

return @env_def_refs;
}




sub get_incs($$$)
{
my ($subsys,
$component,	    # '' if non-gbs subsys
$src_type,
) = @_;
my ( $incs_type, $incs_ref, $sysincs_type, $sysincs_ref );
my ( @sysincs, @incs );




my ($inc_format, $sysinc_format, $inc_abs_path);
($incs_type, $inc_format) = get_format( incs => $src_type);
($sysincs_type, $sysinc_format) = get_format( sysincs => $src_type);
if ($FOR_AUDIT)
{
$inc_abs_path = 0;
} else
{
$inc_abs_path = BUILD_get_src_items( $GBS::BUILD, $src_type, qw( INC_ABS_PATH));
}
my $src_dir = "$GBS::ROOT_PATH/dev/$subsys/comp/$component/src";




if ($sysinc_format)
{
@sysincs = FLINCS_get_sysincs( $src_type);
@sysincs = ($inc_abs_path) ?
ENV_abs_paths( $src_dir, [ @sysincs ]) :
ENV_shortest_paths( $src_dir, [ @sysincs ]);
format_incs( \@sysincs, $sysinc_format);
}
if ($inc_format)
{
@incs = FLINCS_get_incs( $src_type, $component);
@incs = ($inc_abs_path) ?
ENV_abs_paths( $src_dir, [ @incs ]) :
ENV_shortest_paths( $src_dir, [ @incs ]);
format_incs( \@incs, $inc_format);
}

$sysincs_ref = [ @sysincs ];
$incs_ref    = [ @incs ];
return ( $incs_type, $incs_ref, $sysincs_type, $sysincs_ref );
}




sub get_flags($$$)
{
my ($subsys,
$component,
$src_type,
) = @_;
my ( $sysflags_type, $sysflags_ref, $flags_type, $flags_ref );
my ( @sysflags, @flags );




my ($flag_format, $sysflag_format);
($flags_type, $flag_format) = get_format( flags => $src_type);
($sysflags_type, $sysflag_format) = get_format( sysflags => $src_type);




if ($sysflag_format)
{
@sysflags = FLINCS_get_sysflags( $src_type);




@sysflags = grep( /^"?-D/, @sysflags)
if ($FOR_AUDIT);
}




{



push @flags, FLINCS_get_flags( $src_type, $component);




{
my $src_type_name = substr( $src_type, 1);
my $key = 'GBS_FLAGS_'. uc $src_type_name;
my $gbs_flags = ENV_getenv( $key);
push @flags, $gbs_flags
if ($gbs_flags);
}




@flags = grep( /^"?-D/, @flags)
if ($FOR_AUDIT);
}




format_flags( \@sysflags, $sysflag_format);
format_flags( \@flags, $flag_format);

$sysflags_ref = [ @sysflags ];
$flags_ref = [ @flags ];
return ( $sysflags_type, $sysflags_ref, $flags_type, $flags_ref);
}





sub format_flags($$)
{
my ($flags_ref,	# In/OUT
$flag_format,
) = @_;

my $quoted_format;
if ($flag_format =~ / /)
{
$quoted_format = $flag_format;
$quoted_format =~ s/(.*?) (.*)/$1 "$2"/;
} else
{
$quoted_format = "\"$flag_format\"";
}

foreach my $flag (@{$flags_ref})
{

if (substr( $flag, 0, 2) eq '-D')
{

if ($flag =~ / / && $flag !~ /"/)
{
$flag = sprintf( $quoted_format, substr( $flag, 2));
} else
{
$flag = sprintf( $flag_format, substr( $flag, 2));
}
} elsif (substr( $flag, 0, 3) eq '"-D')
{

$flag = '"' . sprintf( $flag_format, substr( $flag, 3));
} else
{

}

}
}





sub format_incs($$)
{
my ($incs_ref,	# In/OUT
$inc_format,
) = @_;

my $quoted_format;
if ($inc_format =~ / /)
{
$quoted_format = $inc_format;
$quoted_format =~ s/(.*?) (.*)/$1 "$2"/;
} else
{
$quoted_format =  "\"$inc_format\"";
}

foreach my $inc (@{$incs_ref})
{
if ($inc =~ / / && $inc !~ /"/)
{
$inc = sprintf( $quoted_format, $inc);
} else
{
$inc = sprintf( $inc_format, $inc);
}

}
}





sub get_format($$)
{
my ($envvar,    #  sysflags flags incs sysincs
$src_type,
) = @_;
my ($flags_type, $flag_format);

my $key = "$envvar$src_type";
my $ref = $FORMAT_CACHE{$key};
if (!defined $ref)
{
my @envvars = map { uc substr( $_, 0, -1) . '_FORMAT' } @FLAGS_INCS_ORDER;  # (sysflags flags incs sysincs)
my @format_refs;
if ($FOR_AUDIT)
{
@format_refs = AUDIT_get_src_items( $GBS::AUDIT, $src_type, @envvars);
} else
{
@format_refs = BUILD_get_src_items( $GBS::BUILD, $src_type, @envvars);
}
foreach my $envvar (@FLAGS_INCS_ORDER)
{
my $format_ref = shift @format_refs;
my ($flags_type, $flag_format) = ENV_undef2empty( @{$format_ref});
my $key = "$envvar$src_type";
$FORMAT_CACHE{$key} = [ $flags_type, $flag_format ];
}


$ref = $FORMAT_CACHE{$key};
}
($flags_type, $flag_format) = @{$ref};

return ($flags_type, $flag_format);
}

1;

