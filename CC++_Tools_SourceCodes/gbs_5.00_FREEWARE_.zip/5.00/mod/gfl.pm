#=================================================
#
#   gfl.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gfl;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GFL_filespec
GFL_new
GFL_put_subsys
GFL_put_component
GFL_put_files
GFL_write
GFL_read
GFL_read_head
);
}




use glo::env;
use glo::slurp;
use glo::spit;




sub GFL_filespec($);
sub GFL_new($$);
sub GFL_put_subsys($$$);
sub GFL_put_component($$$);
sub GFL_put_files($$);
sub GFL_write($);
sub GFL_read($);
sub GFL_read_head($);








sub GFL_filespec($)
{
my ($app,		    # e.g.: $GBS_AUDIT
) = @_;
my $gfl_filespec;	    # contains the exec-id

$gfl_filespec = join( '_', "$GBS::TMP_PATH/$app", "$GBS::EXEC_ID.gfl");


return $gfl_filespec;
}




sub GFL_new($$)
{
my ($app,		# e.g.: $GBS_AUDIT
$app_data_ref,
) = @_;
my $this_ref;

my @record = ('-A', $app);

my ($cur_app, undef) = GFL_read_head( $app);
if (!defined $cur_app)
{
push @record, join( "\t", @{$app_data_ref})
if ($app_data_ref);
}

$this_ref = [ "@record" ];

return $this_ref;
}




sub GFL_put_subsys($$$)
{
my ($this_ref,
$subsys,
$subsys_data_ref,
) = @_;

my @record = ('-S', $subsys);
push @record, join( "\t", @{$subsys_data_ref})
if ($subsys_data_ref);

push @{$this_ref}, "@record";
}




sub GFL_put_component($$$)
{
my ($this_ref,
$component,
$component_data_ref,
) = @_;

my @record = ('-C', $component);
push @record, join( "\t", @{$component_data_ref})
if ($component_data_ref);

push @{$this_ref}, "@record";
}




sub GFL_put_files($$)
{
my ($this_ref,
$files_ref,
) = @_;

push @{$this_ref}, @{$files_ref};
}




sub GFL_write($)
{
my ($this_ref) = @_;

my ($type, $app) = split( ' ', $this_ref->[0]);
my $gfl_filespec = GFL_filespec( $app);
my $gfl_file = ENV_split_spec_f( $gfl_filespec);
if (-f $gfl_filespec)
{

shift @{$this_ref};
SPIT_append_file_nl( $gfl_filespec, $this_ref );
} else
{

SPIT_file_nl( $gfl_filespec, $this_ref );
}
}




sub GFL_read($)
{
my ($wanted_app) = @_;
my ($app, $app_data_ref, @subsys_refs);


my $gfl_filespec = GFL_filespec( $wanted_app);
my $gfl_file = ENV_split_spec_f( $gfl_filespec);


foreach my $line (SLURP_file( $gfl_filespec))
{
if (substr( $line, 0, 1) eq '-')
{
my ($type, $name, $data) = split( ' ', $line, 3);
my $data_ref;
$data_ref = [ split( "\t", $data) ]
if ($data);
if ($type eq '-C')
{
push @{$subsys_refs[-1]}, [ $name, $data_ref ];
} elsif ($type eq '-S')
{
push @subsys_refs, [ $name, $data_ref ];
} elsif ($type eq '-A')
{
ENV_sig( F => "'-A' specified more than once")
if (defined $app);
$app = $name;
$app_data_ref = $data_ref;

} else
{
ENV_sig( F => "Invalid GFL-type '$type' in line '$line'");
}
} else
{
push @{$subsys_refs[-1]->[-1]}, $line;
}
}


return ($app, $app_data_ref, @subsys_refs);
}




sub GFL_read_head($)
{
my ($wanted_app) = @_;	# e.g. $GBS_AUDIT
my ($app, $app_data_ref);	# $app == undef if file does not exist

my $gfl_filespec = GFL_filespec( $wanted_app);
my $gfl_file = ENV_split_spec_f( $gfl_filespec);
if (-f $gfl_filespec)
{

my ($line) = SLURP_file_head( $gfl_filespec, 1);
(my $type, $app, my $data) = split( ' ', $line, 3);
$app_data_ref = [ split( "\t", $data) ]
if ($data);
}

return (wantarray) ? ($app, $app_data_ref) : $app;
}
1;

