#=================================================
#
#   winreg.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::winreg;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
WINREG_get_userenv_names
WINREG_get_userenv
WINREG_put_userenv
WINREG_del_userenv
WINREG_flush
);
}




use Win32::TieRegistry;

use glo::env;




sub WINREG_get_userenv_names();
sub WINREG_get_userenv($);
sub WINREG_put_userenv($$);
sub WINREG_del_userenv($);
sub WINREG_flush();








$Registry->Delimiter("/");
my $USERENV_KEY = 'HKEY_CURRENT_USER/Environment/';
my $USERENV = $Registry->{$USERENV_KEY};




sub WINREG_get_userenv_names()
{
my @names;

@names = $USERENV->ValueNames;


return @names;
}




sub WINREG_get_userenv($)
{
my ($name) = @_;






return $USERENV->GetValue($name);
}




sub WINREG_put_userenv($$)
{
my ($name,
$value_or_value_ref,	# $value or [ $value, $type ]

) = @_;

my $value_ref = (ref $value_or_value_ref) ? $value_or_value_ref : [ $value_or_value_ref, 'REG_SZ' ];
my ($value, $type) = @{$value_ref};

$USERENV->{$name} = $value_or_value_ref;

{



my $app_scripts_path = ENV_get_application_scripts_path();
my $setenv_command = ENV_os_paths( "$app_scripts_path/win32utils/setenv.exe");
$value = "\"$value\""
if ($value =~ /\s/);
my $setenv_value = $value;
if ($type eq 'REG_EXPAND_SZ')
{
$setenv_value =~ s/%/"%"/g;
$setenv_value =~ s/\\"/\\\\"/g;
}
my $command_line = "$setenv_command -u $name $setenv_value";

ENV_say( 1, "Updating Registry: $name -> $value ...");
my $rc = ENV_system( $command_line, undef);
ENV_sig( E => "setenv returned $rc")
if ($rc != 0);
}
}




sub WINREG_del_userenv($)
{
my ($name) = @_;


return delete $USERENV->{$name};
}




sub WINREG_flush()
{
$Registry->Flush;
}

1;

