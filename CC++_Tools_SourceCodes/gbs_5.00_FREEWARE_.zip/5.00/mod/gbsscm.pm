#=================================================
#
#   gbsscm.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbsscm;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSSCM_preset
GBSSCM_setenv
GBSSCM_connect
GBSSCM_suspend
GBSSCM_resume
);
}




use glo::env;
use glo::scm;
use mod::gbsenv;




sub GBSSCM_preset($);
sub GBSSCM_setenv($);
sub GBSSCM_connect();
sub GBSSCM_suspend();
sub GBSSCM_resume();








my @SCM_ENVS = qw( GBS_SCMS GBS_SCMS_REPOSITORY GBS_SCMS_DATA);




my @SCMS_ITEMS;


my @SUSPEND_ITEMS;







sub GBSSCM_preset($)
{
my ($must_force_new) = @_;


if (@SCMS_ITEMS == 0 || $must_force_new)
{
my $root_path = $GBS::ROOT_PATH;
@SCMS_ITEMS = map { scalar ENV_getenv( $_) } @SCM_ENVS;


if ($SCMS_ITEMS[0] eq '')	# GBS_SCMS
{
ENV_sig( W => "EnvVar GBS_SCMS not set. Try to determine SCMS...");
$root_path = ENV_cwd()
if ($root_path eq '');
@SCMS_ITEMS = SCM_determine( $root_path);
ENV_sig( EE => "Cannot determine SCMS")
if ($SCMS_ITEMS[0] eq '');
}

SCM_preset( $root_path, [ @SCMS_ITEMS ]);
}

return (wantarray) ? @SCMS_ITEMS : $SCMS_ITEMS[0];
}





sub GBSSCM_setenv($)
{
my ($scms_items_ref,	# [ $scms_name, $scms_repository, $scms_data ]
) = @_;

my @scms_items = @{$scms_items_ref};    # make a copy because we are going to shift
map { GBSENV_setenv( $_ => shift @scms_items, 1) } @SCM_ENVS;
}




sub GBSSCM_connect()
{
my ($repository, $scms_data) = SCM_connect();

if (defined $repository)
{
if ($repository ne $GBS::SCMS_REPOSITORY)
{
ENV_say( 1, "** SCMS-Repository definition mismatch. You should update with gbsmaint 7 4 1 **",
"Actual    : $repository",
"system.gbs: $GBS::SCMS_REPOSITORY");
GBSENV_setenv( GBS_SCMS_REPOSITORY => $repository);
}
}

if (defined $scms_data)
{
if ($scms_data ne $GBS::SCMS_DATA)
{
ENV_say( 1, "** SCMS-data definition mismatch. You should update with gbsmaint 7 4 1 **",
"Actual    : $scms_data",
"system.gbs: $GBS::SCMS_DATA");
GBSENV_setenv( GBS_SCMS_DATA => $scms_data);
}
}
}




sub GBSSCM_suspend()
{
ENV_sig( F => "Nested suspend")
if (@SUSPEND_ITEMS);

push @SUSPEND_ITEMS, $GBS::ROOT_PATH;
map { push @SUSPEND_ITEMS, ENV_getenv( $_) } @SCM_ENVS;
}




sub GBSSCM_resume()
{
ENV_sig( F => "No suspend data")
if (!@SUSPEND_ITEMS);

my $root_path = shift @SUSPEND_ITEMS;
SCM_preset( $root_path, [ @SUSPEND_ITEMS ]);
@SUSPEND_ITEMS = ();
}

1;


