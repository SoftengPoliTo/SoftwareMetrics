#=================================================
#
#   swc.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::swc;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SWC_set
);
}




use glo::env;
use mod::gbsenvs;
use mod::gbsenv;
use mod::gbsrc;
use mod::gbsglo;




sub SWC_set($$$);







sub SWC_set($$$)
{
my ($subsys,
$component,
$must_write,
) = @_;
my $old_component = $GBS::COMPONENT;

ENV_debug( 1, "Set $GBS::ROOT_PATH, $subsys: $component");




if ($component eq '')
{



GBSENVS_set_component( 1);
} else
{



ENV_sig( F => "Cannot specify Component ($component) for empty-named SubSys")
if ($subsys eq '');
ENV_sig( F => "Cannot specify Component ($component) for Non-GBS SubSys ($subsys)")
if (!GBSGLO_subsystem_is_full_gbs( $subsys));




my $component_path = "$GBS::ROOT_PATH/dev/$subsys/comp/$component";

GBSENVS_set_component( 1, $component_path,
[ COMPONENT		=> $component,
COMPONENT_PATH    => $component_path,
]);
}




GBSRC_write_subsys( $subsys, component => $component)
if ($must_write && $subsys ne '' &&
GBSENV_mode_is_interactive());

return $old_component;
}

1;


