#=================================================
#
#   csv.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::csv;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
CSV_join
CSV_split
CSV_titles
);
}








sub CSV_join($$);
sub CSV_split($);
sub CSV_titles($$);








sub CSV_join($$)
{
my ($values_ref,
$must_quote_all,
) = @_;
my $line;

my @values;
if ($must_quote_all)
{
foreach (@{$values_ref})
{
if (defined $_)
{
my $value = $_;
$value =~ s/\"/""/g;
push @values, qq{"$value"};
}
}
} else
{
foreach (@{$values_ref})
{
if (defined $_)
{
my $value = $_;
if ($value =~ /[\"\n,]/)
{
$value =~ s/\"/""/g;
push @values, qq{"$value"};
} else
{
push @values, $value;
}
}
}
}
$line = join( ',', @values);

return $line;
}





sub CSV_split($)
{
my ($line) = @_;
my @values;

if ($line ne '')
{
my $expecting;
while ($line =~ m!(?=.)((?:"((?:""|[^"]+)*)")?([^,]*))(,?)!sg)
{
$expecting = $4;
if (defined($2) && !length($3))
{
(my $t = $2) =~ s/""/\"/g;
push( @values, $t);
} else
{
push( @values, $1);
}
}
push( @values, '') if ($expecting);
}

return @values;
}




sub CSV_titles($$)
{
my ($values_ref,
$no_lt_ws,		# no leading and trailing whitespace
) = @_;
my @titles;

my $i = 0;
foreach (@{$values_ref})
{
my $title = $_; 	# do not change the actual value (ref!)
if ($no_lt_ws)
{
$title =~ s/^\s+//;
$title =~ s/\s+$//;
}
push @titles, ($title, $i++);
}
return @titles;
}

1;


