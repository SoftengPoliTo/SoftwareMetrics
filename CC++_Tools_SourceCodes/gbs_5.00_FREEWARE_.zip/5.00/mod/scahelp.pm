#=================================================
#
#   scahelp.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::scahelp;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SCAHELP_get_filespec
SCAHELP_init_help_file
SCAHELP_add_msg_text
SCAHELP_add_general_text
SCAHELP_write_help_file
);
}




use glo::env;
use glo::spit;
use glo::flock;
use glo::html;
use mod::gbshtml;
use mod::scadef;




sub SCAHELP_get_filespec();
sub SCAHELP_init_help_file($$$);
sub SCAHELP_add_msg_text($$$$$);
sub SCAHELP_add_general_text($$$);
sub SCAHELP_write_help_file();








my $PLUGIN_NAME;
my $PLUGIN_REL;
my $PLUGIN_NICE_NAME;

my $HELP_FILESPEC;	    # E.g.: $GBS_PLUGIN_PATH/msg_help.html

my $TITLE;
my @HEADING_LINES;
my @HTML_LINES;
my @HTML_HEADINGS;
my $NEXT_SECTION;




sub SCAHELP_get_filespec()
{
my $help_filespec;

my ($helpfile_path, $helpfile_main_file) = SCADEF_get_section_items( $GBS::AUDIT_PLUGIN, 'HELPFILES', qw( PATH MAIN_FILE));
$help_filespec = "$helpfile_path/$helpfile_main_file";

return $help_filespec;
}




sub SCAHELP_init_help_file($$$)
{
($PLUGIN_NAME,
$PLUGIN_REL,
$PLUGIN_NICE_NAME,
) = @_;

$HELP_FILESPEC = SCAHELP_get_filespec();

$TITLE = "$PLUGIN_NICE_NAME ($PLUGIN_REL) Warnings Helpfile";

GBSHTML_init( 'plugin');	    # Use PLUGIN_ROOT




@HEADING_LINES = ();
@HTML_LINES = ();
@HTML_HEADINGS = ();
$NEXT_SECTION = 0;

my $title = "$TITLE - Created by GBS";
push @HEADING_LINES, GBSHTML_doc_start( $HELP_FILESPEC, $title, 0, '', undef); # $want_scripts, $body_class, $target_frame_name
push @HEADING_LINES, GBSHTML_doc_top( $TITLE, ());
$NEXT_SECTION = 2;	    # Section 1 == Index
push @HEADING_LINES, GBSHTML_h( 1, undef, 'Contents', $NEXT_SECTION);
}




sub SCAHELP_add_msg_text($$$$$)
{
my ($helpfile_url,	# $helpfile_msgid_spec or $helpfile_spec#msg_id
$msg_id,
$level_text,
$heading,	# May be '' or undef
$lines_ref,	# undef, scalar or refarray
) = @_;

$heading = $msg_id
if (!defined $heading);

my $text = "$msg_id ($level_text)";
$text .= "-- $heading"
if (defined $heading && $heading ne '');

my (undef, $id) = split( '#', $helpfile_url);
if (defined $id)
{
push @HTML_LINES, GBSHTML_h( 2, { id => $id }, $text, $NEXT_SECTION);
push @HTML_LINES, HTML_pre_s();
if (defined $lines_ref)
{
my $line = (ref $lines_ref) ? join( "\n", @{$lines_ref}) : $lines_ref;
push @HTML_LINES, HTML_pre_txt( $line);
}
push @HTML_LINES, HTML_pre_e();
} else
{
if ($helpfile_url eq '-')
{
push @HTML_LINES, HTML_li( HTML_link( 'NotDefined.html', $text));
} else
{
push @HTML_LINES, HTML_li( HTML_link( $helpfile_url, $text));
}
}
}




sub SCAHELP_add_general_text($$$)
{
my ($heading,
$href,
$lines_ref,
) = @_;

if (defined $heading)
{
push @HTML_HEADINGS, $heading;
$NEXT_SECTION++;
push @HTML_LINES, GBSHTML_h( 1, undef, $heading, $NEXT_SECTION);
}

if (defined $href)
{

}

if (defined $lines_ref)
{
push @HTML_LINES, HTML_pre_s();
my $line = join( "\n", @{$lines_ref});
push @HTML_LINES, HTML_pre_txt( $line);
push @HTML_LINES, HTML_pre_e();
}
}




sub SCAHELP_write_help_file()
{



push @HEADING_LINES, GBSHTML_get_toc( 1);    # $deepest_level




my @tailing_lines;
push @tailing_lines, GBSHTML_doc_bottom();
push @tailing_lines, GBSHTML_doc_end();




ENV_say( 1, "Writing SCA Help file...");
my $fh = FLOCK_ex_wait( "$HELP_FILESPEC.lck");
SPIT_file_nl( $HELP_FILESPEC, [ \@HEADING_LINES, \@HTML_LINES, \@tailing_lines ]);
FLOCK_unlock( $fh);

@HTML_HEADINGS = ();
@HTML_LINES = ();
$TITLE = undef;

return $HELP_FILESPEC;
}

1;

