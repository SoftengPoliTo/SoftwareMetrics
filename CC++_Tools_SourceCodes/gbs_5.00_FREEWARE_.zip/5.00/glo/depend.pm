#=================================================
#
#   depend.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::depend;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
DEPEND_c
DEPEND_line
);
}




use glo::env;
use glo::list;
use glo::slurp;
use glo::parse_c;
use glo::path;




sub DEPEND_c($$$$$);
sub DEPEND_line($$$$$$);

sub parse_c_file($);
sub parse_line_file($);
sub parse_recurse($$);
sub init($$$);
sub cleanup();
sub search($$$);




my @INCLUDE_PATHS;	# ABS paths
my @STUBS_PATHS;	# ABS paths
my $CUR_PATH_ID = 0;	# Increments when @INCLUDE_PATHS changes

my %FILES_CACHE;





my $PARSE_FILE_FUNC;		    # per source
my $UNIX_STYLE_SEARCH;		    # per source (start with current location if include is quoted style)
my %INC_FILE_ALREADY_INCLUDED;	    # per source

my $NR_ERRORS;			    # not used ... yet
my $NR_WARNINGS;		    # number of not-determinable file dependencies (incl not found)

my $COMMENT_RE;
my $INCLUDE_RE;





sub DEPEND_c($$$$$)
{
my ($src_filespec,
$unix_style_search,	    # start with current location if include is quoted style
$include_paths_ref,	    # -I Abs paths
$stubs_paths_ref,	    # Abs paths
$defines_ref,		    # -D not used yet
) = @_;
my ($nr_errors, $nr_warnings, @path_refs);





$UNIX_STYLE_SEARCH = $unix_style_search;
init( $include_paths_ref, $stubs_paths_ref,	$defines_ref);




$PARSE_FILE_FUNC = \&parse_c_file;
push @path_refs, parse_recurse( 0, $src_filespec);






cleanup();

$nr_errors = $NR_ERRORS;
$nr_warnings = $NR_WARNINGS;
return ($nr_errors, $nr_warnings, @path_refs);
}




sub parse_c_file($)
{
my ($including_filespec,		    # must exist
) = @_;
my @include_refs;


@include_refs = PARSE_C_get_includes( PARSE_C_new( $including_filespec), 0);	# do not cleanup

return @include_refs;
}




sub DEPEND_line($$$$$$)
{
my ($comment_re,
$include_re,
$src_filespec,
$include_paths_ref,	    # -I Abs paths
$stubs_paths_ref,	    # Abs paths
$defines_ref,		    # -D not used yet
) = @_;
my ($nr_errors, $nr_warnings, @path_refs);





$UNIX_STYLE_SEARCH = 0;

$COMMENT_RE = $comment_re;
$INCLUDE_RE = $include_re;

init( $include_paths_ref, $stubs_paths_ref,	$defines_ref);




$PARSE_FILE_FUNC = \&parse_line_file;
push @path_refs, parse_recurse( 0, $src_filespec);




cleanup();

$nr_warnings = $NR_WARNINGS;
$nr_errors = $NR_ERRORS;
return ($nr_errors, $nr_warnings, @path_refs);
}




sub parse_line_file($)
{
my ( $including_filespec,		    # must exist
) = @_;
my @include_refs;


my @lines = SLURP_file( $including_filespec);




foreach my $line (@lines)
{
$line =~ s/$COMMENT_RE//;
}




my $line_nr = 0;
foreach my $line (@lines)
{
$line_nr++;





next if ($line eq '');




if ($line =~ $INCLUDE_RE)
{

my $inc_type = $1;
my $inc_name = $2;
push @include_refs, [ $line_nr, $inc_type, $inc_name ];
}
}

return @include_refs;
}




sub parse_recurse($$)
{
my ( $level,			    # 0 = source-file
$including_filespec,		    # must exist
) = @_;
my @path_refs;


my $found_refs_ref = $FILES_CACHE{ $including_filespec };
if (defined $found_refs_ref)
{




} else
{




my @include_refs = $PARSE_FILE_FUNC->( $including_filespec);





my @found_refs;

foreach my $ref (@include_refs)
{
my ($line_nr, $inc_type, $inc_name) = @{$ref};
my ($found, $inc_filespec) = search( $including_filespec, $inc_type, $inc_name);
push @found_refs, [ $found, $line_nr, $inc_type, $inc_name, $CUR_PATH_ID, $inc_filespec ];
}

$found_refs_ref = [ @found_refs ];
if ($level > 0)	    # no need to remember src_file
{
$FILES_CACHE{ $including_filespec } = $found_refs_ref;

}
}




$level++;

foreach my $ref (@{$found_refs_ref})
{
my ($found, $line_nr, $inc_type, $inc_name, $path_id, $inc_filespec) = @{$ref};
if ($path_id != $CUR_PATH_ID)
{

($found, $inc_filespec) = search( $including_filespec, $inc_type, $inc_name);
$ref = [ $found, $line_nr, $inc_type, $inc_name, $CUR_PATH_ID, $inc_filespec ];	# Update found_refs
}

my $allready_included_key = ($found eq 'N') ? "$including_filespec|$line_nr|$inc_name" : $inc_filespec;

if (!defined $INC_FILE_ALREADY_INCLUDED{ $allready_included_key} )
{
push @path_refs, [ $level, $found, $line_nr, $inc_type, $inc_name, $inc_filespec ];
$INC_FILE_ALREADY_INCLUDED{ $allready_included_key} = 1;
if ($found eq 'F')
{
push @path_refs, parse_recurse( $level, $inc_filespec);
} elsif ($found eq 'N')
{
$NR_WARNINGS++;
}
}
}

return @path_refs;
}




sub init($$$)
{
my ($include_paths_ref,	    # -I Abs paths
$stubs_paths_ref,	    # Abs paths
$defines_ref,		    # -D not used yet
) = @_;

$NR_ERRORS = 0;
$NR_WARNINGS = 0;

if (!LIST_is_eq_str( $include_paths_ref, \@INCLUDE_PATHS) ||
!LIST_is_eq_str( $stubs_paths_ref, \@STUBS_PATHS))
{







@INCLUDE_PATHS = @{$include_paths_ref};
@STUBS_PATHS = @{$stubs_paths_ref};
$CUR_PATH_ID++;

}
}




sub cleanup()
{
%INC_FILE_ALREADY_INCLUDED = ();
}




sub search($$$)
{
my ($including_filespec,
$inc_type,		# '"' or '<'
$inc_name,
) = @_;
my ( $found, $inc_filespec ) = ( 'N', '');	    # if not found: $inc_filespec contains the calling filespec



if (ENV_is_abs_path_perl( $inc_name))
{
if (PATH_file_exists( $inc_name))	# cached
{
$found = 'F';
$inc_filespec = $inc_name;
}
} else
{
if ($UNIX_STYLE_SEARCH && $inc_type eq '"')
{
my $including_path_spec = ENV_split_spec_p( $including_filespec) . "/$inc_name";
if (PATH_file_exists( $including_path_spec))	# cached
{
$found = 'F';
$inc_filespec = $including_path_spec;
}
}
if ($found eq 'N')
{
$inc_filespec = PATH_search_file( $inc_name, \@INCLUDE_PATHS);	    # Uses PATH_file_exist (cached)
if ($inc_filespec ne '')
{
$found = 'F';
} else
{
$inc_filespec = PATH_search_file( $inc_name, \@STUBS_PATHS);   # Uses PATH_file_exist (cached)
if ($inc_filespec ne '')
{
$found = 'S';
}
}
}
}

$inc_filespec = "$including_filespec"
if ($found eq 'N');

return ( $found, $inc_filespec );
}

1;


