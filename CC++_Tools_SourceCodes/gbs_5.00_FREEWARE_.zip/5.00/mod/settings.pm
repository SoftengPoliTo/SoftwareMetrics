#=================================================
#
#   settings.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::settings;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SETTINGS_set_check
SETTINGS_uninstall_version
SETTINGS_uninstall_gbs
SETTINGS_get_setup_files
);
}




BEGIN
{
if ($^O eq 'MSWin32')
{
require glo::winreg;
import  glo::winreg;
} else
{
require glo::bash;
import  glo::bash;
}
}
use glo::bash;
use glo::env;
use glo::file;
use glo::shortcut;
use mod::gbsenv;
use mod::gbscmd;




sub SETTINGS_set_check($$);
sub SETTINGS_uninstall_version($);
sub SETTINGS_uninstall_gbs();
sub SETTINGS_get_setup_files($);

sub win32_check_registry();
sub linux_check_login_files();
sub check_predefined_envvar($$$);
sub copy_setup_files($);




my $IS_WIN32 = ENV_is_win32();
my $IS_LINUX = ! $IS_WIN32;
my $IS_DEVELOPMENT = ENV_is_development();




my @LINUX_ALIAS_REFS = (

[ gbs	    => qq{. "$GBS::BOOT_PATH/gbsinit.sh" \$*} ],
[ gbshelp	    => qq{$GBS::BOOT_PATH/define.sh cur perl gbshelp.pl \$*} ],
[ gbssetup	    => qq{$GBS::BOOT_PATH/define.sh cur source gbssetup.sh \$*} ],
[ gbsuninstall  => qq{$GBS::BOOT_PATH/define.sh cur perl gbsuninstall.pl \$*} ],
);

my @LINUX_BASHRC_LINES = (
qq{if [[ -e "\$HOME/tmp/gbs_pre_define_\$PPID.sh" ]]},
qq{then},
qq{    \\source "\$HOME/tmp/gbs_pre_define_\$PPID.sh"},
qq{    \\rm "\$HOME/tmp/gbs_pre_define_\$PPID.sh"},
qq{fi},
);


my $STARTMENU_PATH = ENV_get_startmenu_path( 0);    # user_path



my @SHORTCUT_REFS = (

[ 'Startup',    [ 'DESKTOP', 'STARTMENU/GBS' ], 'Startup a GBS Command Window [%s]' ],
[ 'Help',	    [ 'DESKTOP', 'STARTMENU/GBS' ], 'Startup the GBS Help [%s]' ],
[ 'Setup',	    'STARTMENU/GBS',		    'Startup the GBS Setup function [%s]' ],
[ 'Uninstall',  'STARTMENU/GBS',		    'Startup the GBS Uninstall function [%s]' ],
);




my $gbs_scripts_path;




sub SETTINGS_set_check($$)
{
my ($gbs_scripts_root,
$gbs_scripts_rel,
) = @_;

ENV_say( 1, "Set/Check Startup Settings...");

$gbs_scripts_path = "$gbs_scripts_root/$gbs_scripts_rel";





copy_setup_files( $gbs_scripts_path);




if ($IS_WIN32)
{



win32_check_registry();
} else  # LINUX
{
linux_check_login_files();
}




if (ENV_get_desktop_path( 0) ne '')		# user_path
{




ENV_say( 1, "Checking Shortcuts...");
my $update_count = 0;
my $init_file_spec = "$gbs_scripts_path/setup/shortcut";

my @shortcut_rels;
push @shortcut_rels, ($gbs_scripts_rel =~ /beta/) ? 'beta' : 'cur';
push @shortcut_rels, 'cur'
if ($IS_DEVELOPMENT);

foreach my $shortcut_rel (@shortcut_rels)	# 'beta' and/or 'cur'
{

my $icon_name = ($shortcut_rel eq 'beta') ? 'gbs_test' : 'gbs';
my $icon_spec = "$GBS::BOOT_PATH/$icon_name";
foreach my $ref (@SHORTCUT_REFS)
{
my ($shortcut_name, $locations_ref, $comment_format) = @{$ref};
my ($shortcut_title, $shortcut_type, $command_spec, $command_args) = GBSCMD_get_shortcut_command( $shortcut_name, $gbs_scripts_path, $shortcut_rel);

my $comment = sprintf( $comment_format, $shortcut_rel);
$update_count += SHORTCUT_update( $locations_ref,	    # 'STARTMENU/GBS' or [ 'DESKTOP', 'STARTMENU/GBS' ]
$init_file_spec,	    # without type
$shortcut_title,
$shortcut_type,	    # $type: Application or Link
$comment,		    # $description,
$icon_spec,		    # $icon_spec
$command_spec,	    # $command_spec
$command_args,	    # $command_args
undef,		    # $working_directory
undef);		    # show: 0 = NORMAL, 1 = Maximised, -1 = Minimised
}
}




if ($update_count > 0)
{
ENV_sig( I => "$update_count standard GBS Shortcut(s) on the DeskTop and StartMenu were updated.",
"If you have your own GBS Shortcuts, please update them accordingly.");
}
} else
{
my $dtp = ENV_get_desktop_path( 0);
ENV_say( 1, "Desktop directory ( $dtp) not found.",
"No checking or creation of Shortcuts");
}
}








sub SETTINGS_uninstall_version($)
{
my ($version,
) = @_;




if ($version eq $GBS::SCRIPTS_REL || $version =~ /^beta/)
{
ENV_say( 2, 'Removing Desktop and Startmenu shortcuts...');

my $shortcut_rel = ($version =~ /^beta/) ? 'beta' : 'cur';
foreach my $ref (@SHORTCUT_REFS)
{

my ($shortcut_name, $locations_ref, undef) = @{$ref};
my $shortcut_title = GBSCMD_get_shortcut_command( $shortcut_name, $version, $shortcut_rel);

SHORTCUT_delete( $locations_ref, $shortcut_title);
}
}
}




sub SETTINGS_uninstall_gbs()
{



{
ENV_say( 2, 'Removing Startmenu directory...');
my $gbs_startmenu_path = "$STARTMENU_PATH/GBS";
if ($IS_DEVELOPMENT)
{
ENV_say( 2, "- Simulate Removing $gbs_startmenu_path");
} else
{
ENV_rmtree( $gbs_startmenu_path, 1, 1, 'E');
}
}




ENV_say( 2, 'Removing .gbs/base directory...');
ENV_say( 3, "Removing $GBS::BASE_PATH");
if ($IS_DEVELOPMENT)
{
ENV_say( 3, "- Simulate Removing $GBS::BASE_PATH");
} else
{
ENV_rmtree( $GBS::BASE_PATH, 1, 1, 'E');
}




ENV_say( 2, 'Removing .gbs directory...');
ENV_say( 3, "Removing $GBS::BOOT_PATH");
if ($IS_DEVELOPMENT)
{
ENV_say( 3, "- Simulate Removing $GBS::BOOT_PATH");
} else
{
ENV_rmtree( $GBS::BOOT_PATH, 1, 1, 'E');
}




if ($IS_LINUX)
{
ENV_say( 2, 'Removing GBS alias entries...');

my $login_filespec = BASH_parse( 'EE');

my %env_file_specs;
foreach my $ref (@LINUX_ALIAS_REFS)
{
my ($alias) = @{$ref};
my ($value, $filespec, $is_login, $line_nr) = BASH_get_alias( $alias);
$env_file_specs{$filespec} = 1
if (defined $value);
}
foreach my $filespec (keys %env_file_specs)
{
BASH_remove_aliases( $filespec, 1, 'GBS', @LINUX_ALIAS_REFS);
}

ENV_say( 2, 'Removing GBS startup Script...');
BASH_replace_lines( $login_filespec, 1, 'GBS Startup', undef);

BASH_cleanup();
}
}




sub win32_check_registry()
{



ENV_say( 1, "Checking Registry...");
foreach my $envvar_name (WINREG_get_userenv_names())
{
if (substr( uc $envvar_name, 0, 3) eq 'GBS')
{
my $value = WINREG_get_userenv( $envvar_name);
$value = '' if (!defined $value);
check_predefined_envvar( $envvar_name, $value, 'Registry')
}
}
}




sub linux_check_login_files()
{



ENV_say( 1, "Checking Login-files...");

my $login_filespec = BASH_parse( 'EE');

foreach my $envvar_name (BASH_get_envvar_names( 1))  # export_variables only
{
my ($value, $is_export, $is_login, $filespec, $line_nr) = BASH_get_envvar( $envvar_name);

ENV_sig( W => "- It is unnecessary and unwise to set EnvVars in '$filespec($line_nr)'")
if (!$is_login);
if (substr( $envvar_name, 0, 3) eq 'GBS')
{
check_predefined_envvar( $envvar_name, $value, "$filespec($line_nr)");
}
}




BASH_replace_lines( $login_filespec, 1, 'GBS Startup', \@LINUX_BASHRC_LINES);




my %env_file_specs;
foreach my $ref (@LINUX_ALIAS_REFS)
{
my ($alias) = @{$ref};
my ($value, $filespec, $is_login, $line_nr) = BASH_get_alias( $alias);
$env_file_specs{$filespec} = 1
if (defined $value);
}
if (%env_file_specs)
{
ENV_say( 2, 'Removing GBS alias entries...');

foreach my $filespec (keys %env_file_specs)
{
BASH_remove_aliases( $filespec, 1, 'GBS', @LINUX_ALIAS_REFS);
}
}

BASH_cleanup();
}






sub check_predefined_envvar($$$)
{
my ($name,		    # Must start with 'GBS'. Mixed case ok.
$value,
$source,	    # For errormessage. Win32: 'Registry. Linux: "$filespec($line_nr)"
) = @_;

my $warn_line;
my $uc_name = uc $name;
if (substr( $uc_name, 0, 4) eq 'GBS_')
{
if (!GBSENV_is_predefined_env( $uc_name))	# E.g: GBS_PERL_PATH, GBS_BASE_PATH
{
$warn_line = "** This GBS EnvVar may not be defined here! **";
}
} elsif (substr( $uc_name, 0, 7) eq 'GBSEXT_')
{
$warn_line = "** GBSEXT_ EnvVars must be defined in the switch.gbs$GBS::SHELL_FILETYPE file! **";
} elsif (substr( $uc_name, 0, 7) eq 'GBSALL_')
{
$warn_line = "** GBSALL_ EnvVars must be defined in the gbsall$GBS::SHELL_FILETYPE file! **";
}

if ($warn_line)
{
ENV_sig( W => "User EnvVar $name=$value",
$warn_line,
"- $source");
}
}





sub copy_setup_files($)
{
my ($gbs_scripts_path,
) = @_;
my $nr_copied = 0;

my $from_path = "$gbs_scripts_path/setup";

ENV_say( 1, "Checking Setup Files...");
foreach my $file (SETTINGS_get_setup_files( $from_path))
{
my $filespec = "$from_path/$file";
my $replicated = FILE_replicate( $filespec, "$GBS::BOOT_PATH/$file");
if ($replicated == 1)
{
ENV_say( 2, "Copied $file to $GBS::BOOT_PATH");
if ($IS_LINUX && $file =~ /\.sh$/)
{
ENV_say( 3, "- chmod u+x");
ENV_chmod( 'u+x', "$GBS::BOOT_PATH/$file");
}
$nr_copied++;
}
}

return $nr_copied;
}




sub SETTINGS_get_setup_files($)
{
my ($setup_path,		# e.g.: $GBS::SCRIPTS_PATH/setup
) = @_;
my @files;


my @wild_files = ($IS_WIN32) ? ( '*.bat', '*.ico') : ( '*.sh', '*.png');	# scripts and icons
foreach my $wild_file (@wild_files)
{
foreach my $filespec (ENV_glob( "$setup_path/$wild_file"))
{
push @files, ENV_split_spec_f( $filespec);
}
}

return @files;
}

1;

