#=================================================
#
#   gbsrc.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbsrc;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSRC_disable_write
GBSRC_get_base
GBSRC_write_base
GBSRC_get_root
GBSRC_write_root
GBSRC_get_subsys
GBSRC_write_subsys
);
}




use glo::env;
use glo::slurp;
use glo::spit;




sub GBSRC_disable_write($);
sub GBSRC_get_base($);
sub GBSRC_write_base(@);
sub GBSRC_get_root($$);
sub GBSRC_write_root(@);
sub GBSRC_get_subsys($$$);
sub GBSRC_write_subsys($;@);

sub setup($);
sub do_read($$);
sub do_write($$);
sub read_file($);
sub get_item($);
sub put_items($);
sub write_file();








my %BASE = (
SPEC => ''
);
my %BASE_DEF = (
DATA    => \%BASE,
ID	    => 'root',
ITEMS   => [ qw( id root ) ],
OSITEMS => [ qw( root) ],
HIDE    => 0,
);

my %ROOT = (
SPEC => ''
);
my %ROOT_DEF = (
DATA    => \%ROOT,
ID	    => 'subsys',
ITEMS   => [ qw( id subsys build audit tool ) ],
OSITEMS => [ qw( build audit tool ) ],
HIDE    => 1,
);

my %SUBSYS = (
SPEC => ''
);
my %SUBSYS_DEF = (
DATA    => \%SUBSYS,
ID	    => 'component',
ITEMS   => [ qw( id component build audit ) ],
OSITEMS => [ qw( build audit ) ],
HIDE    => 1,
);

my %old_item_names = (
targets	=> 'builds',
);





my $WRITE_ENABLED = 1;

my $CUR_DATA_REF;
my $CUR_ID;
my @CUR_ITEMS;
my %CUR_ITEMS;
my %CUR_OSITEMS;
my $CUR_HIDE;





sub GBSRC_disable_write($)
{
my ($diable,
) = @_;
my $was_disabled = !$WRITE_ENABLED;

$WRITE_ENABLED = !$diable;

return $was_disabled;
}




sub GBSRC_get_base($)
{
my ($wanted_item) = @_;  # root

my $filespec = "$GBS::BASE_PATH/.gbsrc";

setup( \%BASE_DEF);
return do_read( $filespec, $wanted_item);
}




sub GBSRC_write_base(@)
{
my (@item_value_pairs) = @_;     # ($wanted_item => $value, ...). Emply list forces write

my $filespec = "$GBS::BASE_PATH/.gbsrc";

setup( \%BASE_DEF);
do_write( $filespec, \@item_value_pairs);
}




sub GBSRC_get_root($$)
{
my ($root_path,
$wanted_item,	# subsys build audit tool
) = @_;

my $filespec = "$root_path/dev/.gbsrc";

setup( \%ROOT_DEF);
return do_read( $filespec, $wanted_item);
}





sub GBSRC_write_root(@)
{
my (@item_value_pairs    # ($wanted_item => $value, ...). Emply list forces write
) = @_;

my $filespec = "$GBS::ROOT_PATH/dev/.gbsrc";

setup( \%ROOT_DEF);
do_write( $filespec, \@item_value_pairs);
}




sub GBSRC_get_subsys($$$)
{
my ($root_path,
$subsys,
$wanted_item,	# component
) = @_;

ENV_sig( F => "GBSRC_get_subsys: No current SubSys")
if ($subsys eq '');
my $filespec = "$root_path/dev/$subsys/.gbsrc";

setup( \%SUBSYS_DEF);
return do_read( $filespec, $wanted_item);
}





sub GBSRC_write_subsys($;@)
{
my ($subsys,
@item_value_pairs    # ($wanted_item => $value, ...). Emply list forces write
) = @_;

ENV_sig( F => "GBSRC_write_subsys: No current SubSys")
if ($subsys eq '');
my $filespec = "$GBS::ROOT_PATH/dev/$subsys/.gbsrc";

setup( \%SUBSYS_DEF);
do_write( $filespec, \@item_value_pairs);
}




sub setup($)
{
my ($def_ref) = @_;

$CUR_DATA_REF = $def_ref->{DATA};
$CUR_ID = $def_ref->{ID};
@CUR_ITEMS = @{$def_ref->{ITEMS}};
%CUR_ITEMS = map { $_ => 1 } @CUR_ITEMS;
%CUR_OSITEMS = map { $_ => 1 } @{$def_ref->{OSITEMS}};
$CUR_HIDE = $def_ref->{HIDE};
}




sub do_read($$)
{
my ($filespec,
$wanted_item,
) = @_;

read_file( $filespec);

return get_item( $wanted_item);
}




sub do_write($$)
{
my ($filespec,
$item_value_pairs_ref,    # ($wanted_item => $value, ...)
) = @_;

read_file( $filespec);
if (@{$item_value_pairs_ref} == 0 || put_items( $item_value_pairs_ref))
{
ENV_debug( 1, "Writing GBSRC ($CUR_ID)...");
write_file()
if ($WRITE_ENABLED);
}
}




sub read_file($)
{
my ($filespec) = @_;

my $current_file = $CUR_DATA_REF->{SPEC};
if ($filespec ne $current_file)
{



%{$CUR_DATA_REF} = ();
foreach my $item (@CUR_ITEMS)
{
if ($CUR_OSITEMS{$item})
{
$CUR_DATA_REF->{$item}->{$^O} = '';
} else
{
$CUR_DATA_REF->{$item} = '';
}
}


my @lines;
if (-e $filespec &&
ENV_try( 'W', sub { @lines = SLURP_file( $filespec) }, undef))
{

foreach my $line (@lines)
{
$line =~ s/\s+$//;			# remove trailing white space
next if ($line eq "");			# skip empty lines
next if (substr( $line, 0, 1) eq "#");	# skip comments

my ($name, $value) = split( /=/, $line, 2);
my ($item, $osname) = split( /-/, $name, 2);
$value = ''
if (! defined $value);
{
my $new_item_name = $old_item_names{$item};
$item = $new_item_name
if (defined $new_item_name);
}

if ($CUR_ITEMS{$item})
{
if (defined $osname)
{
$CUR_DATA_REF->{$item}->{$osname} = $value;
} else
{
$CUR_DATA_REF->{$item} = $value;
}
} else
{
ENV_sig( W => "Invalid item-key '$name' in file $filespec");
}
}
} else
{

}
$CUR_DATA_REF->{SPEC} = $filespec;
$CUR_DATA_REF->{id} = $CUR_ID;

}
}




sub get_item($)
{
my ($wanted_item) = @_;
my $value;

my ($item, $osname) = split( /-/, $wanted_item, 2);
ENV_sig( F => "$CUR_ID: No such item-key '$item'")
if (!$CUR_ITEMS{$item});
if ($CUR_OSITEMS{$item})
{
$osname = $^O
if (!defined $osname);
$value = $CUR_DATA_REF->{$item}->{$osname};
} else
{
$value = $CUR_DATA_REF->{$item};
}

return $value;
}





sub put_items($)
{
my ($item_value_pairs_ref) = @_;    # ($wanted_item => $value, ...)
my $file_modified = 0;

my @item_value_pairs = @{$item_value_pairs_ref};
while (@item_value_pairs)
{
my $wanted_item = shift @item_value_pairs;
my $value = shift @item_value_pairs;

my ($item, $osname) = split( /-/, $wanted_item, 2);
ENV_sig( F => "$CUR_ID: No such item-key '$item'")
if (!$CUR_ITEMS{$item});
if ($CUR_OSITEMS{$item})
{
$osname = $^O
if (!defined $osname);
my $old_value = $CUR_DATA_REF->{$item}->{$osname};
if ($value ne $old_value)
{
$CUR_DATA_REF->{$item}->{$osname} = $value;
$file_modified = 1;
}
} else
{
my $old_value = $CUR_DATA_REF->{$item};
if ($value ne $old_value)
{
$CUR_DATA_REF->{$item} = $value;
$file_modified = 1;
}
}
}

return $file_modified;
}





sub write_file()
{
my @lines;
foreach my $item (@CUR_ITEMS)
{
if ($CUR_OSITEMS{$item})
{
foreach my $os_name (sort keys %{$CUR_DATA_REF->{$item}})
{
push @lines, "$item-$os_name=$CUR_DATA_REF->{$item}->{$os_name}";
}
} else
{
push @lines, "$item=$CUR_DATA_REF->{$item}";
}
}
my $current_file = $CUR_DATA_REF->{SPEC};

ENV_hide_file( $current_file, 0)
if (-e $current_file);	# unhide
unlink $current_file;					# On linux we HAVE to delete the DOT-file first!
if (ENV_try( undef, sub { SPIT_file_nl( $current_file, \@lines) }, undef))
{
ENV_hide_file( $current_file, 1)			# hide the file
if ($CUR_HIDE);
} else
{
ENV_sig( W => "$CUR_ID: Unable to create '$current_file'",
"- Values will not be remembered!",
"- $!");
}
}

1;
