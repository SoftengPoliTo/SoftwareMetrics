#=================================================
#
#  user.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::user;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
USER_main
);
}




use glo::ask;
use mod::log;




sub USER_main($$$);








sub USER_main($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;

my @main_menu_items = (
[ 'Fix Log Files & Directories',		    \&LOG_main ],
);

ASK_menu( 'Select function to perform', \@main_menu_items, $entries_ref);
}

1;
