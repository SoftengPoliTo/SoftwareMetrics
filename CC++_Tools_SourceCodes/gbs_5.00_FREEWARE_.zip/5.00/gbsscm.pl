#=================================================
#
#   gbsscm.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
#   File states:
#    -2 => 'NO-FILE',
#    -1 => 'NOT-SCM',
#     0 => 'CHECKED-IN',
#     1 => 'CHECKED-OUT',
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSSCM @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::genopt;
use glo::ask;
use glo::slurp;
use glo::file;
use glo::scm;
use mod::gbsenv;
use mod::gbsglo;
use mod::gbsscm;
use mod::dirstruct;





sub do_info();
sub do_state($);
sub do_co($);
sub do_ci($);
sub do_unco($);
sub do_mkdir($);
sub do_mktxt($);
sub do_add($);
sub do_move($);
sub do_get_ignore($);
sub do_set_ignore($);
sub do_import($);
sub do_remove($);
sub do_connect();
sub do_stop();
sub do_select();
sub collect_files_dirs($);
sub print_files($$);




my $CWD = ENV_cwd();

my %COMMANDS = (

info	=> [ 1, 0,  0,  0, 0, 0, 0, \&do_info ],
state	=> [ 1, 1, -1, -1, 0, 1, 1, \&do_state ],
co		=> [ 1, 1, -1, -1, 1, 1, 1, \&do_co ],
ci		=> [ 1, 1, -1, -1, 1, 1, 1, \&do_ci ],
unco	=> [ 1, 1, -1, -1, 1, 1, 1, \&do_unco ],
mkdir	=> [ 1, 1, -1, -1, 0, 0, 1, \&do_mkdir ],
mktxt	=> [ 1, 1, -1, -1, 0, 0, 1, \&do_mktxt ],
add		=> [ 1, 1, -1, -1, 1, 1, 1, \&do_add ],
move	=> [ 1, 2,  2, -1, 0, 0, 1, \&do_move ],
get_ignore  => [ 1, 1,  1,  1, 0, 0, 1, \&do_get_ignore ],
set_ignore  => [ 1, 2, -1,  1, 0, 0, 1, \&do_set_ignore ],
remove	=> [ 1, 1, -1, -1, 1, 1, 1, \&do_remove ],
import	=> [ 1, 1,  2, -1, 1, 0, 1, \&do_import ],
connect	=> [ 1, 0,  0,  0, 0, 0, 0, \&do_connect ],
stop	=> [ 1, 0,  0,  0, 0, 0, 0, \&do_stop ],
select	=> [ 0, 0,  0,  0, 0, 0, 0, \&do_select ],
);




my $RC = 0;
$| = 1;           # $OUTPUT_AUTOFLUSH
GBSENV_init( undef);













{
my @genopts = (
[ '<1>',    'command',	    'ssms?,info,state,co,ci,unco,mkdir,mktxt,add,move,get_ignore,set_ignore,remove,import,connect,stop,select',  '', "Basic SCM Command" ],
[ '<*>',    'files',	    'sao',  '', 'File / Directory  List' ],
[ 'r',	    'recursive',    'bso',   0, 'Add whole directory tree' ],
[ 'c',	    'use_cache',    'bso',   0, 'Use cache' ],
);
GENOPT_set_optdefs( [ 'gbsscm', 'scm' ], \@genopts,
"Execute basic SCM commands using the current SCMS",
[ 'info',
'state   <file-dir>...',
'co      <file-dir>...',
'ci      <file-dir>...',
'unco    <file-dir>...',
'mkdir   <dir>...',
'mktxt   <file>...',
'add	    <file-dir>...',
'get_ignore  <dir>',
'set_ignore  <dir> <ignore_list>...',
'remove  <file-dir>...',
'import  <from-dir> [<to-dir>]',
'connect',
'stop',
'select' ]
);
GENOPT_parse();
}
my $COMMAND = GENOPT_get( 'command');
my @FILES = GENOPT_get( 'files');
my $RECURSIVE = GENOPT_get( 'recursive');
my $USE_CACHE = GENOPT_get( 'use_cache');




if ($COMMAND eq '?')
{
ENV_say( 1, 'Commands:',
'info state co ci unco mkdir mktxt add move get_ignore set_ignore remove import connect stop select');
} else
{
if ($GBS::ROOT_PATH eq '')
{
$GBS::ROOT_PATH = $CWD;
ENV_say( 1, "GBS_ROOT_PATH' not set. Assuming CWD",
$CWD);
}

my $func_ref = $COMMANDS{ $COMMAND };
if (defined $func_ref)
{
my ($init_scm, $min_arg, $max_arg, $nr_of_file_args, $files_must_exist, $recurse_ok, $can_use_cache, $function) = @{$func_ref};




ENV_sig( EE => "$COMMAND: Must specify at least $min_arg arguments")
if (@FILES < $min_arg);
ENV_sig( EE => "$COMMAND: Maximum of $max_arg arguments allowed")
if ($max_arg >= 0 && @FILES > $max_arg);

if ($USE_CACHE && !$can_use_cache)
{
ENV_sig( W => "Combination of '--c' with '$COMMAND' not allowed");
$USE_CACHE = 0;
}
ENV_sig( EE => "Combination of '--r' with '$COMMAND' not allowed")
if ($RECURSIVE && !$recurse_ok);




if ($init_scm)
{
($GBS::SCMS, $GBS::SCMS_REPOSITORY, $GBS::SCMS_DATA) = GBSSCM_preset( 0);
ENV_say( 1, SCM_join_info( [ $GBS::SCMS, $GBS::SCMS_REPOSITORY, $GBS::SCMS_DATA ]));
}

if ($USE_CACHE)
{
ENV_say( 1, "Caching file_states...");
SCM_cache_states( 1);	    # 1 == force reread
}




if ($max_arg != 0)
{
$nr_of_file_args = @FILES
if ($nr_of_file_args == -1);
foreach my $i (0 .. $nr_of_file_args - 1)
{
my $file = $FILES[$i];
if ($file eq '.')
{
$file = $CWD;
} else
{
$file = "$CWD/$file"
if (!ENV_is_abs_path( $file));
$file = ENV_perl_canon_paths( $file);
}
if ($files_must_exist)
{





}
$FILES[$i] = $file;
}
my @files;
if ($COMMAND eq 'add')
{



foreach my $file (@FILES)
{



my $state;
my $parent = $file;
do
{
$parent = substr( $parent, 0, rindex( $parent, '/'));
$state = SCM_get_states( $parent, 0);
push @files, $parent if ($state == -1);	# NOT_SCM
} while ($state == -1);
}
@files = reverse @files if (@files);
}

if ($RECURSIVE)
{

map { push @files, collect_files_dirs( $_) } @FILES;
} else
{
@files = @FILES;
}




$function->( \@files);
} else
{



$function->();
}
} else
{
ENV_sig( F => "Invalid command '$COMMAND'");
}
}

ENV_exit( $RC);




END
{
ENV_print_end_msg(1);
}




sub do_info()
{
my $old_verbose_state = ENV_set_verbose(1);
SCM_connect();
ENV_set_verbose( $old_verbose_state);
}




sub do_state($)
{
my ($files_ref) = @_;

print_files( state => $files_ref);

my @spec_refs = SCM_get_states( $files_ref, 0);
foreach my $ref (@spec_refs)
{
my ($file, $state) = @{$ref};
my $short_name = GBSGLO_short_filespecs( $file);
my $state_text = SCM_state2txt( $state);
ENV_say( 1, "state: $short_name: $state_text ($state)");
}
}




sub do_co($)
{
my ($files_ref) = @_;

print_files( co => $files_ref);

SCM_checkout( $files_ref);
}




sub do_ci($)
{
my ($files_ref) = @_;

print_files( ci => $files_ref);

SCM_checkin( $files_ref);
}




sub do_unco($)
{
my ($files_ref) = @_;

print_files( unco => $files_ref);

SCM_undo_checkout( $files_ref);
}




sub do_mkdir($)
{
my ($files_ref) = @_;

print_files( mkdir => $files_ref);

SCM_add_dirs( $files_ref, \&DIRSTRUCT_get_ignore_spec, 0, 0);	    # $pre_validated, $verbose
}




sub do_mktxt($)
{
my ($files_ref) = @_;

print_files( mktxt => $files_ref);

SCM_add_txt_files( $files_ref, 0, 0);			   # $prevalidated, $verbose
}




sub do_add($)
{
my ($files_ref) = @_;

print_files( add => $files_ref);

my @dirs = grep( -d $_, @{$files_ref});
ENV_say( 1, "Adding " . scalar @dirs . " directories...");
SCM_add_dirs( \@dirs, \&DIRSTRUCT_get_ignore_spec, 0, 0);	    # $pre_validated, $verbose
@dirs = ();

my @files = grep( -f $_, @{$files_ref});
ENV_say( 1, "Adding " . scalar @files . " files...");
SCM_add_txt_files( \@files, 0, 0);				    # $prevalidated, $verbose
}




sub do_move($)
{
my ($files_ref) = @_;

print_files( move => $files_ref);
my ($spec_old, $spec_new) = @{$files_ref};





ENV_say( 1, "Moving $spec_old",
"    to $spec_new");
SCM_move( $files_ref, 0, 0);	    # $pre_validated, $verbose
}




sub do_get_ignore($)
{
my ($files_ref) = @_;

my $dir = $files_ref->[0];

ENV_sig( EE => "No such directory: '$dir'")
if (!-e $dir);

ENV_say( 1, "ignore values for $dir:");
my @ignores = SCM_get_ignore( $dir);
ENV_say( 3, "[ @ignores ]");
}




sub do_set_ignore($)
{
my ($files_ref) = @_;

my ($dir,
@ignore_list) = @{$files_ref};

ENV_sig( EE => "No such directory: '$dir'")
if (!-e $dir);

ENV_say( 1, "ignore $dir @ignore_list");

SCM_set_ignore( $dir, [ @ignore_list ]);
}




sub do_import($)
{
my ($files_ref) = @_;

my ($from_dir,
$to_dir,
) = @{$files_ref};

$to_dir = $CWD
if (!defined $to_dir);
ENV_sig( EE => "No such directory '$from_dir'")
if (!-d $from_dir);
ENV_sig( EE => "No such directory '$to_dir'")
if (!-d $to_dir);

ENV_say( 1, "import From: $from_dir",
"       To  : $to_dir");

ENV_say( 1, "Collecting $from_dir...");
my @from_entry_refs = FILE_recurse_tree( $from_dir, \@GBS::SKIPTYPES, 0);
my $from_dir_l = length( $from_dir) + 1;
map { $_->[1] = substr( $_->[1], $from_dir_l) } @from_entry_refs;

my $nr_from_entries = @from_entry_refs;
ENV_say( 1, "  Found $nr_from_entries directories and/or files");

ENV_say( 1, "Caching file_states...");
SCM_cache_states( 1);	    # 1 == force reread




{
ENV_say( 1, "Collecting $to_dir...");
my @to_entry_refs = FILE_recurse_tree( $to_dir, \@GBS::SKIPTYPES, 0);
my $to_dir_l = length( $to_dir) + 1;
map { $_->[1] = substr( $_->[1], $to_dir_l) } @to_entry_refs;

my $nr_to_entries = @to_entry_refs;
ENV_say( 1, "  Found $nr_to_entries directories and/or files");

my %from_entries = map { $_->[1] => $_->[0] } @from_entry_refs;




{
ENV_say( 1, "Checking obsolete stuff...");
foreach my $ref (@to_entry_refs)
{
my ($type, $rel_entry) = @{$ref};
my $from_type = $from_entries{$rel_entry};
if ((!defined $from_type || $from_type ne $type) &&
SCM_get_states( "$to_dir/$rel_entry", 0) >= 0)
{
$ref->[2] = 1;			    # must_delete
} else
{
$ref->[2] = 0;			    # must_delete
}
}
map { ENV_say( 0, "  $_->[0] $_->[1]") if ($_->[2] == 1) } @to_entry_refs;

my $ans = '';
for (my $i = 0; $i < @to_entry_refs; $i++)
{
my $ref = $to_entry_refs[$i];
my ($type, $rel_entry, $must_delete) = @{$ref};

if ($must_delete == 1)
{
$ans = ASK_YNAE( "- Delete $rel_entry?", 'Y')
if ($ans ne 'A' && $ans ne 'E');
if ($ans eq 'A' || $ans eq 'Y')
{
map { $_->[2] = -1 if ($_->[1] =~ /^$rel_entry\//) } @to_entry_refs;
} else  # 'E' or 'N'
{
$ref->[2] = 0;		    # must_delete => no
}
}
}
my @del_file_refs = grep( $_->[0] eq 'F' && $_->[2] != 0, @to_entry_refs);
if (@del_file_refs)
{
ENV_say( 1, "Removing files...");
my @files = map { "$to_dir/$_->[1]" } @del_file_refs;
map { ENV_say( 0, "=>DEL $_") } @files;
SCM_remove_names( \@files);
}
my @del_dir_refs = grep( $_->[0] eq 'D' && $_->[2] != 0, @to_entry_refs);
if (@del_dir_refs)
{
ENV_say( 1, "Removing directories...");
my @dirs = map { "$to_dir/$_->[1]" } @del_dir_refs;
@dirs = reverse @dirs;
map { ENV_say( 0, "=>DEL $_") } @dirs;
SCM_remove_names( \@dirs);
}
}
}

if (ASK_YN( 'Start Import?', 'Y') eq 'Y')
{



{
ENV_say( 1, "Creating Directories...");
my @new_dirs;
my $dir_count = 0;
my $create_count = 0;
foreach my $ref (@from_entry_refs)
{
if ($ref->[0] eq 'D')
{
$dir_count++;
my $rel_filespec = $ref->[1];
my $filespec = "$to_dir/$rel_filespec";
my $state = SCM_get_states( $filespec, 0);
$create_count++
if ($state == -2);		# NO-FILE
push @new_dirs, $filespec
if ($state < 0);
}
}
ENV_say( 1, "  $create_count/$dir_count directories created");

SCM_add_dirs( \@new_dirs, \&DIRSTRUCT_get_ignore_spec, 1, 0);	    # $pre_validated, $verbose
}




{
ENV_say( 1, "Copy files...");
my @new_files;
my $copy_count = 0;
foreach my $ref (@from_entry_refs)
{
if ($ref->[0] eq 'F')
{
my $rel_filespec = $ref->[1];
my $from_filespec = "$from_dir/$rel_filespec";
my $to_filespec = "$to_dir/$rel_filespec";
my $state = SCM_get_states( $to_filespec, 0);
SCM_checkout( $to_filespec)
if ($state == 0);	# Checked in
ENV_copy_file( $from_filespec, $to_filespec, 'F');
$copy_count++;

push @new_files, $to_filespec
if ($state < 0);
}
}
ENV_say( 1, "  $copy_count files copied");

SCM_add_txt_files( \@new_files, 1, 0);	    # $pre_validated, $verbose
}
}
}




sub do_remove($)
{
my ($files_ref) = @_;

print_files( remove => $files_ref);

my @all;

my $ans = "";
foreach my $file (@{$files_ref})
{
if ($ans eq "A")
{
push @all, $file;
} else
{
my $short_file = GBSGLO_short_filespecs( $file);
$ans = ASK_YNAEQ( "Remove $short_file?", "A", 0);
if ($ans eq "Y")
{
push @all, $file;
} elsif ($ans eq "N")
{
;
} elsif ($ans eq "A")
{
push @all, $file;
} elsif ($ans eq "E")
{
last;
} elsif ($ans eq "Q")
{
@all = ();
last;
}
}
}

if (scalar @all > 0)
{
SCM_remove_names( \@all);
} else
{
ENV_say( 1, "remove: Nothing to remove");
}
}




sub do_connect()
{
ENV_say( 1, "Performing connect explicitly...");
GBSSCM_connect();
}




sub do_stop()
{
ENV_say( 1, "Performing stop...");
SCM_stop();
}




sub do_select()
{
ENV_say( 1, "Performing select...");

($GBS::SCMS, $GBS::SCMS_REPOSITORY, $GBS::SCMS_DATA ) =
SCM_select( [ $GBS::SCMS, $GBS::SCMS_REPOSITORY, $GBS::SCMS_DATA ], $GBS::ROOT_PATH);
ENV_say( 1, "Selected: '$GBS::SCMS', '$GBS::SCMS_REPOSITORY', '$GBS::SCMS_DATA'");
}





sub collect_files_dirs($)
{
my ($filespec) = @_;
my @filespecs;

my ($name) = ENV_split_spec_f( $filespec);
if (grep( $name =~ $_, @GBS::SKIPTYPES))
{
ENV_say( 1, "Skipped $filespec");
} else
{
if (-l $filespec)
{
ENV_sig( E => "add: Symbolic links not supported",
"'$filespec'");
} else
{
push @filespecs, $filespec;
if (-d $filespec)
{
my @files = SLURP_dir_all( $filespec, 0);
foreach my $file_or_dir (@files)
{
push @filespecs, collect_files_dirs( "$filespec/$file_or_dir");
}
}
}
}

return @filespecs;
}




sub print_files($$)
{
my ($command,
$files_ref) = @_;

ENV_whisper( 1, "Performing '$command' for: ");
if (@{$files_ref} > 8)
{
my @files = GBSGLO_short_filespecs( @{$files_ref});
map { ENV_whisper( 0, "  $_") } @files[0..3];
ENV_whisper( 0, "  ...");
map { ENV_whisper( 0, "  $_") } @files[-4..-1];
ENV_whisper( 0, "  Total of " . scalar @files . " entries...");
} else
{
map { ENV_whisper( 0, "  $_") } GBSGLO_short_filespecs( @{$files_ref});
}
}


