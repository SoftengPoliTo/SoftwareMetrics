#=================================================
#
#   gbsinit.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbsinit;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSINIT_setup
);
}




use glo::env;
use glo::shell;
use glo::version;
use glo::check;
use glo::time;
use glo::banner;
use glo::ask;
use mod::gbsenv;
use mod::gbsenvs;
use mod::gbsres;
use mod::gbscmd;
use mod::setupglo;
use mod::profile;




sub GBSINIT_setup($$);




my $IS_WIN32 = ENV_is_win32();
my $IS_DEVELOPMENT = ENV_is_development();





sub GBSINIT_setup($$)
{
my ($wanted_rel,	    # '' or wanted rel
$full_setup,	    # gbsinit.pl and gbsguiinit.pl
) = @_;
my @lines;

if ($wanted_rel eq '')
{
ENV_say( 1, "Initializing GBS...");
} else
{
ENV_say( 1, "Initializing GBS [$wanted_rel]...");
}




if ($wanted_rel ne '')
{



my $new_gbs_scripts_path = ENV_delink_spec( "$GBS::SCRIPTS_ROOT/$wanted_rel");
ENV_sig( EE => "No such GBS_SCRIPTS_REL ($wanted_rel) in $GBS::SCRIPTS_ROOT ($new_gbs_scripts_path)")
if (!-d $new_gbs_scripts_path);
if ($new_gbs_scripts_path eq $GBS::SCRIPTS_PATH)
{
ENV_say( 1, "GBS_SCRIPTS_REL '$wanted_rel' was already current")
unless ($wanted_rel eq 'beta');
} else
{
GBSENV_setenv( GBS_SCRIPTS_REL => $wanted_rel, 1);
GBSENV_setenv( GBS_SCRIPTS_PATH => $new_gbs_scripts_path, 1);
ENV_update_application_scripts_path( $new_gbs_scripts_path);   # only update scripts
ENV_say( 1, "GBS_SCRIPTS_REL set to '$wanted_rel'");
GBSCMD_scripts_path_changed();
}
}




my $gbs_version = VERSION_get_version();
my $gbs_build = VERSION_version_2_full_version( $gbs_version, VERSION_get_version_date());
my $gbs_gui;
my $gbs_exec_mode;









$gbs_exec_mode = ($GBS::EXEC_MODE eq '') ? 'INTERACTIVE' : $GBS::EXEC_MODE;   # Initial




if ($gbs_exec_mode eq 'INTERACTIVE')
{
eval { require Tkx; };
if ($@)
{
ENV_say( 1, "Perl GUI Package 'Tkx' not found");
$gbs_gui = 'None';
} else
{
$gbs_gui = 'Tkx';
}
} else
{
$gbs_gui = 'None';
}

GBSENVS_set_gbs( 1, '',
[ VERSION		=> $gbs_version,
FULL_VERSION	=> $gbs_build,
GUI		=> $gbs_gui,
EXEC_MODE	=> $gbs_exec_mode,
]);









if ($IS_WIN32 && $IS_DEVELOPMENT)
{
my $path = ENV_getenv( 'PATH');
my $scm_path = ENV_os_paths( "$GBS::SCRIPTS_PATH/STUBS/SCM/bin");
if ($path !~ quotemeta( ";$scm_path"))
{
my $new_path = "$path;$scm_path";
$new_path =~ s/;;/;/;
ENV_setenv( PATH => $new_path);
}
}




{
my $site_gbsall_file = ENV_command_filespec( "$GBS::SCRIPTS_ROOT/gbsall");
if (-f $site_gbsall_file)
{
push @lines, SHELL_echo( 1, 'Executing <GBS_SCRIPTS_ROOT>/gbsall..');
push @lines, SHELL_source( $site_gbsall_file);
}

my $base_gbsall_file = ENV_command_filespec( "$GBS::BASE_PATH/gbsall");
if (-f $base_gbsall_file)
{
push @lines, SHELL_echo( 1, 'Executing <GBS_BASE_PATH>/gbsall..');
push @lines, SHELL_source( $base_gbsall_file);
}
}

if ($full_setup)
{



my $gbs_log_root = ENV_getenv_perl_path( 'GBS_LOG_ROOT');
my $gbs_log_path = ENV_getenv_perl_path( 'GBS_LOG_PATH');
if ($gbs_log_root eq '' and $gbs_log_path ne '')
{
ENV_say( 1, "Converting GBS_LOG_PATH to GBS_LOG_ROOT...");
PROFILE_open( undef);
ENV_setenv( GBS_LOG_ROOT => $gbs_log_path);
PROFILE_set( GBS_LOG_ROOT => $gbs_log_path);
$gbs_log_root = $gbs_log_path;
PROFILE_close( 1);	# $must write
ENV_say( 2, '*',
'* You must use gbsmaint 5 1 1 (Log Files) => Fix Log Root',
'* To move your logfiles to the proper directories',
'*');
}
ENV_setenv( GBS_LOG_PATH => '');




SETUPGLO_check_first_invocation();
}










{



my $error_text = CHECK_path( 'Path', $GBS::LOG_ROOT, 1);
if (!defined $error_text)
{
$error_text = "Path $GBS::LOG_ROOT is not writable!"
if (! -w $GBS::LOG_ROOT);
}
if (defined $error_text)
{
ENV_sig( W => "GBS_LOG_ROOT ($GBS::LOG_ROOT)", "- $error_text");
}




ENV_sig( W => "'GBS_SITE' not set")
if ($GBS::SITE eq '');
}





GBSENV_setenv (GBS_LOG_PATH => '', 1);

if ($full_setup)
{



{
my $TITLE = GBSRES_title();
my $gbs_show_version = VERSION_get_show_version();
my ($LICS, $LICN, $LICE, $LICD) = VERSION_get_lic();
my $TIME_START = TIME_time2num( time);
my $UNAME;
{
my ($os, $host, @rest) = ENV_uname();
$UNAME = "$host ($os [@rest])";
}



my @lines;

push @lines,  [ '',      $TITLE ];
push @lines,  undef;						# prints a separator line
push @lines,  [ 'VERSION:', $gbs_show_version ];
push @lines,  [ '',	    $GBS::SCRIPTS_ROOT ];
push @lines,  [ 'LICENSE:', "$LICN ($LICS)" ];
push @lines,  [ '',         "Expires:  $LICE. Number of days left: $LICD" ];
push @lines,  [ '',	        "*** Expired ***" ]
if ($LICD < 0);
push @lines,  [ 'START:',   "$TIME_START" ];
push @lines,  [ 'HOST:',    $UNAME ];

BANNER_print( 'JOB', [ @lines ]);

if ($LICD < 0)
{
ENV_sig( W => "This license of GBS has expired.",
"Please contact Randy Marques Consultancy for a new license.",
"You may keep using it free of change for MAINTENANCE purposes for old, finished projects.",
"- Some functionality will be disabled.");
my $rand = time % 10000;
if (ASK_int( "Please enter '$rand'", '0', 0, undef) != $rand)
{
ENV_sig( EE => "Invalid", "Cannot continue - GBS not started");
}
}
}
}









push @lines, GBSENV_changed_setenv_commands( 0);



if ($GBS::EXEC_MODE eq 'INTERACTIVE')
{



my @aliasdef_paths = (
"$GBS::SCRIPTS_PATH",
"$GBS::SCRIPTS_PATH/StandAlone",
);
push @aliasdef_paths, "$GBS::SCRIPTS_PATH/Tools"
if ($IS_DEVELOPMENT);
foreach my $path (@aliasdef_paths)
{
if ($IS_WIN32)
{
my $macro_filespec = ENV_enquote( ENV_os_paths( "$path/aliasdef.doskey"));
push @lines, "doskey /insert /macrofile=$macro_filespec";
} else
{
push @lines, SHELL_source( ENV_enquote( "$path/aliasdef.sh"));
}
}
}


return @lines;
}

1;


