#=================================================
#
#   scametrics.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
#
#   Call:
#	arg_1	= file_name	(without type)
#	arg_2	= in_filespec	(relative file spec - file_name + type
#	arg_3	= out_file_base (relative file spec - with in file type)
#	arg_4	= out_file_dir	(relative file spec - directory only)
#	arg_5	= out_filetype
#	arg_6-N = command_flags (from command line)
#   Environment:
#	General:
#	    GBS_INCS		Include paths ( -I<dir> ... )
#	    GBS_SYSINCS 	System include paths ( -SI<dir> ... )
#	    GBS_AUDIT_FLAGS	Passed from session
#	    GBS_FLAGS		From flags_<type> files
#	    GBS_SYSFLAGS	From sysflags_<type> file
#	    GBS_AUDIT_OPTIONS	($MUST_SHOW_STDOUT)
#	Application:
#	    GBS_BUILD
#	    GBS_AUDIT
#	    GBSEXT_SCAMETRICS_REL
#	    GBSEXT_SCAMETRICS_PATH
#	    GBS_COMPONENT
#=================================================
package mod::scametrics;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SCAMETRICS_get
);
}





use glo::parse_c;




sub SCAMETRICS_get($$$);
















sub SCAMETRICS_get($$$)
{
my ($source_filespec,
$pp_filespec,		# may be undef
$is_cpp,		# bool
) = @_;

my @total_refs;


my @metric_refs;





my $src_ref = PARSE_C_new( $source_filespec);
{
my $index = 0;
@total_refs = (


[ 0	    => -1, -1 ],	# Lines
[ 1	    => -1, -1 ],	# Funcs
[ 2	    => -1, -1 ],	# Class
[ 3	    => -1, -1 ],	# Const
);
my @this_refs = ($src_ref);
push @this_refs, PARSE_C_new( $pp_filespec)
if (defined $pp_filespec);
foreach my $this_ref (@this_refs)	    # ($source_filespec, $pp_filespec)
{
if ($index == 0)
{
$total_refs[0]->[1 + $index] = PARSE_C_get_nr_lines( $src_ref);
} else
{
$total_refs[0]->[1 + $index] = PARSE_C_get_nr_clean_lines( $src_ref);
}
$total_refs[1]->[1 + $index] = @{PARSE_C_get_functions( $this_ref)};
$total_refs[2]->[1 + $index] = ($is_cpp) ? @{PARSE_C_get_classes( $this_ref)} : -1;
$total_refs[3]->[1 + $index] = PARSE_C_get_nr_distinct_words( $this_ref, 'const');
PARSE_C_cleanup( $this_ref)
if ($index == 0);
$index++;
}


my (undef, $s_nr_lines, $t_nr_lines) = @{$total_refs[0]};
push @metric_refs, [ TPP => $s_nr_lines, $s_nr_lines, $s_nr_lines ];	# Total source lines before pre-processing
push @metric_refs, [ TLN => $t_nr_lines, $t_nr_lines, $t_nr_lines ],	# Total source lines after pre-processing
if (defined $pp_filespec);
}




{
my $count = PARSE_C_get_nr_distinct_words( $src_ref, 'goto');
push @metric_refs, [ GTO => $count, $count, $count ];			# Number of GOTOs
}
{
my $count = PARSE_C_get_nr_distinct_chars( $src_ref, [ qw( && ||) ]);
push @metric_refs, [ LOP => $count, $count, $count ];			# Number of Logical Operators
}
{
my @func_refs = PARSE_C_get_functions( $src_ref);


my ($min, $max, $total) = (0, 0, 0);
if (@func_refs)
{
($min, $max, $total) = (-1, 0, 0);
foreach my $func_ref (@func_refs)
{
my $func_args_ref = $func_ref->[2];
my $args_count = @{$func_args_ref};
if ($args_count >= 1)
{
$args_count--
if ($func_args_ref->[0] eq 'void');
$args_count--
if ($func_args_ref->[$#{$func_args_ref}] eq '...');
}

$min = $args_count
if ($min == -1 || $args_count < $min);
$max = $args_count
if ($args_count > $max);
$total += $args_count;

}
}

push @metric_refs, [ PAR => $min, $max, $total ];			# Number of Function Parameters
}

return (\@total_refs, \@metric_refs);
}

1;



