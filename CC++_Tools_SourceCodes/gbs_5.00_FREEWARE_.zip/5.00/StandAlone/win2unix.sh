for name in "$@"
do
    echo $name
    tr -d "\r" < $name > trtemp.tmp~
    mv trtemp.tmp~ $name
done
