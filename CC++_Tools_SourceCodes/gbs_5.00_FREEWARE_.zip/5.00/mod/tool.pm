#=================================================
#
#   tool.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::tool;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
TOOL_read
TOOL_get_action
TOOL_get_section_commands_data_refs
TOOL_get_command_data_refs_exp
TOOL_get_section_items
TOOL_get_plugin
);
}




use glo::env;
use mod::gbssfile;
use mod::gbsfilecom;
use mod::gbsfileglo;




sub TOOL_read($;$);
sub TOOL_get_action($);
sub TOOL_get_section_commands_data_refs($$);
sub TOOL_get_command_data_refs_exp($$$);
sub TOOL_get_section_items($$@);
sub TOOL_get_plugin($);

sub read_tool($);
sub do_action_values($$$$$);
sub do_default_values($$$$$);




my $CUR_TOOL = '';
my $CUR_TOOL_REF;

my %TOOLS = ();


































my %SETUP_DEFS = (
NICE_NAME	    => [ 'ss' , undef,	   0, undef, 1,			 undef, undef ],
VIA_FORMAT	    => [ 'av' , ['%s',''], 0, undef, undef,		 undef, undef ],
REQUIRE	    => [ 'ps' , [],	   0, 3,     1,			 undef, undef ],
);

my %INIT_DEFS = (
SET_W	    => [ 'pa' , [],	0, 1,     1,			 undef,	undef ],
SET_X	    => [ 'pa' , [],	0, 1,     1,			 undef,	undef ],
SET		    => [ 'pa' , [],	0, 2,     1,			 undef,	undef ],
SETPATH	    => [ 'pa' , [],	0, 3,   [1],			 undef,	undef ],
BIN_DIR	    => [ 'ss' , '',	0, 3,     1,			 undef,	undef ],
COMMAND	    => [ 'pc' , [],	0, 4, undef,			 undef, undef ],    # $command_data_ref
);

my %DFT_DEFS = (    # DEFAULTS
ACTION	    => [ 'ss', '',	0, undef, undef,   \&do_default_values, undef, undef ],
);

my %RUN_DEFS = (
ACTION	    => [ 'ha' , {},	0, 1,   [0],	    \&do_action_values, undef ],
COMMAND	    => [ 'pc' , [],	1, 1, undef,			 undef,	undef ],	    # $command_data_refs
);










my %SECTION_DEFS = (
SETUP	=> [ 'N', 0, 1, 0,   \%SETUP_DEFS,  undef,	undef ],
INIT	=> [ 'N', 0, 0, 0,   \%INIT_DEFS,   undef,	undef ],
DEFAULTS	=> [ 'N', 0, 0, 0,   \%DFT_DEFS,    undef,      undef ],
RUN		=> [ 'N', 1, 1, 0,   \%RUN_DEFS,    undef,	undef ],
);




sub TOOL_read($;$)
{
my ($tool,
$force_read,	    # Optional
) = @_;
my $struct_id;

read_tool( $tool)
if ($tool ne $CUR_TOOL || $force_read);

$struct_id = "systool/$tool";

return $struct_id;
}




sub TOOL_get_action($)
{
my ($tool,
) = @_;
my ($value_name, @values);

read_tool( $tool)
if ($tool ne $CUR_TOOL);

$value_name = $CUR_TOOL_REF->{DEFAULTS}->{ACTION};
@values = @{$CUR_TOOL_REF->{RUN}->{ACTION}->{$value_name}};

return ($value_name, @values);
}




sub TOOL_get_section_commands_data_refs($$)
{
my ($tool,
$section,
) = @_;
my $command_data_refs_ref;	# or @command_data_refs




read_tool( $tool)
if ($tool ne $CUR_TOOL);

$command_data_refs_ref = $CUR_TOOL_REF->{$section}->{COMMAND};


return (wantarray) ? @{$command_data_refs_ref} : $command_data_refs_ref;
}




sub TOOL_get_command_data_refs_exp($$$)
{
my ($tool,
$pos_args_ref,		    # 1=$action, $2=$subsys_def_list, 3=$out_filespec, 4=$out_file_path
$command_line_flags_ref,    # *
) = @_;
my @command_data_refs;



my $nr_pos_args = @{$pos_args_ref};
ENV_sig( F => "Nr pos_args ($nr_pos_args) must be 4")
if ($nr_pos_args != 4);

read_tool( $tool)
if ($tool ne $CUR_TOOL);

my $command_data_refs_ref = TOOL_get_section_commands_data_refs( $tool, 'RUN');
@command_data_refs = GBSFILECOM_expand_command_data_refs( $command_data_refs_ref, $pos_args_ref, $command_line_flags_ref);

return (wantarray) ? @command_data_refs : \@command_data_refs;
}




sub TOOL_get_section_items($$@)
{
my ($tool,
$section,
@items,
) = @_;
my @values = ();

read_tool( $tool)
if ($tool ne $CUR_TOOL);

return GBSSFILE_get_section_items( $CUR_TOOL_REF, $section, @items);
}




sub TOOL_get_plugin($)
{
my ($tool) = @_;


read_tool( $tool)
if ($tool ne $CUR_TOOL);

return $CUR_TOOL_REF->{'.'}->{PLUGIN_NAME};
}




sub read_tool($)
{
my ($tool) = @_;	    # undef = use current, '' = use EnvVar GBS_TOOL

$CUR_TOOL = $tool;
$CUR_TOOL_REF = $TOOLS{$CUR_TOOL};
if (!defined $CUR_TOOL_REF)
{
$TOOLS{$CUR_TOOL} = {};
$CUR_TOOL_REF = $TOOLS{$CUR_TOOL};




my $tool_file = "$GBS::SYSTOOL_PATH/$CUR_TOOL/tool";
my @inc_path = ( "$GBS::SYSTOOL_PATH/$CUR_TOOL",
$GBS::SYSTOOL_PATH);
GBSSFILE_parse( $CUR_TOOL_REF, $tool_file, \@inc_path, \%SECTION_DEFS);


}
}




sub do_action_values($$$$$)
{
my ($section,	# RUN
$subsection,	# ''
$item,		# ACTION
$values_ref,	# ([ $sub_key, @sub_values ], ...)
$constr_arg,
) = @_;
my @new_value_refs; # ( [ $sub_key, @sub_values ], ...)

my @value_refs = @{$values_ref};
foreach my $ref (@value_refs)
{
my ($sub_key, @sub_values) = @{$ref};

push @new_value_refs, $ref;
}

if ($CUR_TOOL_REF->{DEFAULTS}->{ACTION} eq '')
{



my $first_item_key = $values_ref->[0]->[0];

$CUR_TOOL_REF->{DEFAULTS}->{ACTION} = $first_item_key;
}

return @new_value_refs;
}




sub do_default_values($$$$$)
{
my ($section,	# DEFAULTS
$subsection,	# ''
$item,		# ACTION
$values_ref,	# [ @_values ]
$constr_arg,
) = @_;

my $value = $values_ref->[0];
if (!exists $CUR_TOOL_REF->{RUN}->{$item}->{$value})
{
my @allowed_values = sort keys %{$CUR_TOOL_REF->{RUN}->{$item}};
GBSFILEGLO_sig( EE => "No such $item defined: $value. Allowed ${item}S are:", "@allowed_values");
}

return $value;
}

1;

