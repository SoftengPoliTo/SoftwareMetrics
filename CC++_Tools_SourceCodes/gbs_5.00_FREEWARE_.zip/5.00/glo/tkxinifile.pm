#=================================================
#
#   tkxinifile.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::tkxinifile;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
TKXINIFILE_prep
TKXINIFILE_get_gui
TKXINIFILE_store_gui
);
}




use glo::env;
use glo::flock;
use glo::inifile;




sub TKXINIFILE_prep($);
sub TKXINIFILE_get_gui(@);
sub TKXINIFILE_store_gui(@);








my @DEFAULT_GEOMETRY = ( 120, 80, 20, 20);

my $STATE = 'normal';




my $INI_FILESPEC;	    # "$app_base_path/$app_name.ini";




sub TKXINIFILE_prep($)
{
my ($section_properties_ref,    # [ $section => ($prop => $value_or_ref), ...], ...

) = @_;

my $app_base_path = ENV_get_application_base_path();
my $app_name = lc ENV_get_main_name();
$INI_FILESPEC = "$app_base_path/$app_name.ini";

my $fh = FLOCK_ex_wait( "$INI_FILESPEC.lck");

my @section_properties = (
[ GUI => (geometry  => \@DEFAULT_GEOMETRY) ],
[ GUI => (state	    => \$STATE) ],
);
push @section_properties, @{$section_properties_ref}
if (defined $section_properties_ref);


my @parse_errors = INIFILE_load( $INI_FILESPEC, \@section_properties);
if (@parse_errors)
{
ENV_sig( W => @parse_errors, 'File will be recreated');
ENV_unlink( $INI_FILESPEC);
INIFILE_load( $INI_FILESPEC, \@section_properties);
} else
{



my @geometry = split( ' ', INIFILE_get_prop( GUI => 'geometry', 'EE'));
foreach my $i (0..3)
{
my $geo = $geometry[$i];
if (!defined $geo || $geo !~ /^\d+$/)
{
ENV_sig( W => 'Initial Geometry file corrupt: assuming defaults',
"Values: '@geometry'",
$INI_FILESPEC);
INIFILE_update_prop( GUI => 'geometry', "@DEFAULT_GEOMETRY");
INIFILE_save();
last;
}
}
INIFILE_close();
}

FLOCK_unlock( $fh);
}




sub TKXINIFILE_get_gui(@)
{
my (@property_names,	    # geometry, state
) = @_;
my @values;

my $fh = FLOCK_ex_wait( "$INI_FILESPEC.lck");

my @parse_errors = INIFILE_load( $INI_FILESPEC, undef);
if (@parse_errors)
{
ENV_sig( E => @parse_errors);
} else
{
@values = map { INIFILE_get_prop( GUI => $_, 'F') } @property_names;
}

INIFILE_close();

FLOCK_unlock( $fh);

return (wantarray) ? @values : $values[0];
}




sub TKXINIFILE_store_gui(@)
{
my (@property_value_refs,	    # ( [ $property => $value_or_ref ], ...)
) = @_;



my $fh = FLOCK_ex_wait( "$INI_FILESPEC.lck");

my @parse_errors = INIFILE_load( $INI_FILESPEC, undef);
if (@parse_errors)
{
ENV_sig( E => @parse_errors);
} else
{
map { INIFILE_update_prop( GUI => $_->[0],  $_->[1]) } @property_value_refs;
INIFILE_save();
INIFILE_close();
}

FLOCK_unlock( $fh);
}

1;

