#=================================================
#
#   os_win.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
#   Documentation:
#	http://search.cpan.org/~jdb/Win32-0.47/Win32.pm					(Win32 functions)
#	http://search.cpan.org/~rgarcia/perl-5.6.2/lib/Win32.pod			(Win32 functions)
#	http://msdn.microsoft.com/en-us/library/windows/desktop/bb762494(v=vs.85).aspx	(CSIDL)
#=================================================
package glo::os_win;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
OS_beep
OS_get_terminal_size
OS_get_os_name
OS_get_hostname
OS_get_uname
OS_get_userid
OS_get_cwd
OS_long_path_name
OS_copy_file
OS_hide_file
OS_get_desktop_path
OS_get_startmenu_path
OS_get_programs_path
OS_get_user_path
OS_is_administrator
);
}




use Win32;
use Win32::Console;
use Win32::File;
use Win32::Sound;

use glo::env;




sub OS_beep();
sub OS_get_terminal_size();
sub OS_get_os_name();
sub OS_get_hostname();
sub OS_get_uname();
sub OS_get_userid();
sub OS_get_cwd();
sub OS_long_path_name($);
sub OS_copy_file($$);
sub OS_hide_file($$);
sub OS_get_desktop_path($);
sub OS_get_startmenu_path($);
sub OS_get_programs_path($);
sub OS_get_user_path($);
sub OS_is_administrator();

sub get_system_info();
sub win32_set_hidden_attribute($$);
sub get_folder_path($);












my $HOSTNAME;
my $USERID;

my $OS_NAME;
my $UNAME_OS;
my @UNAME_REST;

my   $USER_DESKTOP_PATH;
my $SYSTEM_DESKTOP_PATH;
my   $USER_STARTMENU_PATH;
my $SYSTEM_STARTMENU_PATH;
my   $USER_PROGRAMS_PATH;
my $SYSTEM_PROGRAMS_PATH;
my   $USER_USER_PATH;
my $SYSTEM_USER_PATH;






sub OS_beep()
{
my $result;

my ($here) = __FILE__ =~ m^(.*)(/|\\)^;
my $filespec = "$here/beep.wav";


if (-e $filespec)
{

Win32::Sound::Play( $filespec);
$result = 1;
} else
{

}

return $result;
}




sub OS_get_terminal_size()
{
my ($width, $height);

($width, $height) = Win32::Console->new()->Size();

return (wantarray) ? ($width, $height) : $width;
}





















sub OS_get_os_name()
{
get_system_info()
if (! defined $OS_NAME);

return $OS_NAME;
}




sub OS_get_hostname()
{
if (! defined $HOSTNAME)
{
chomp( $HOSTNAME = `hostname 2> NUL`);
$HOSTNAME = $^O
if (!$HOSTNAME);
}

return $HOSTNAME;
}





sub OS_get_uname()
{
get_system_info()
if (! defined $UNAME_OS);
OS_get_hostname();


return ($UNAME_OS, $HOSTNAME, @UNAME_REST);
}





sub OS_get_userid()
{
$USERID = Win32::LoginName()
if (!defined $USERID);

return $USERID;
}




sub get_system_info()
{
my $env_name = ENV_get_application_name() . '_OS_UNAME';
my $env_value = $ENV{$env_name};
if ($env_value)
{
($OS_NAME, $UNAME_OS) = split( ',', $env_value, 2);
@UNAME_REST = ( $ENV{PROCESSOR_IDENTIFIER} );
} else
{
my $caption;
my $service_pack;
my %selection_refs = (
caption			=> \$caption,		    # \$OS_NAME,
ServicePackMajorVersion	=> \$service_pack,
);
my $selections = join( ', ', keys %selection_refs);
my $time = time;
my $stdout_file = "$ENV{LOCALAPPDATA}\\Temp\\system_info_stdout_${time}_${$}.tmp";
my $ps_command = qq{"gwmi win32_operatingsystem | select $selections | fl | out-file -encoding ASCII \"\"$stdout_file\"\""};

system( "start /min /wait powershell -Command $ps_command");
my @lines = ENV_slurp_file( $stdout_file);





unlink $stdout_file;

foreach my $line (@lines)
{
$line =~ s/\s+$//;
next
if ($line eq '');

my ($key, $value) = split( /\s*:\s*/, $line, 2);
if (exists $selection_refs{$key})
{
${$selection_refs{$key}} = $value;
}
}

($OS_NAME) = $caption =~ /^Microsoft\s*(\S+\s+\S+)/;
$OS_NAME =~ s/^Windows /Win/;
$service_pack = ($service_pack eq '0') ? 'No SP' : "SP $service_pack";
$UNAME_OS = "$OS_NAME ($service_pack)";
@UNAME_REST = ( $ENV{PROCESSOR_IDENTIFIER} );
$ENV{$env_name} = "$OS_NAME,$UNAME_OS";
}
}




sub OS_get_cwd()
{
my $pwd;

$pwd = Win32::GetCwd();
$pwd =~ s!\\!/!g;		# Perl path

return $pwd;
}

my %FOUND_SHORT_PATHS;






sub OS_long_path_name($)
{
my ($path,
) = @_;
my $perl_long_path;

my $perl_path = $path;
$perl_path =~ tr!\\!/!;

if ($path =~ m!~!)
{




$perl_long_path = $FOUND_SHORT_PATHS{ $path}->[0];
if (defined $perl_long_path)
{

} else
{
my $os_long_path = Win32::GetLongPathName( $path);
if (defined $os_long_path)
{
$perl_long_path = $os_long_path;
$perl_long_path =~ tr!\\!/!;	    # perl path

$FOUND_SHORT_PATHS{ $path}->[0] = $perl_long_path;
} else
{
ENV_trace( 'LONG', $path, "8.3 is may be disabled");




my @perl_long_path;
my $failed = 0;
foreach my $item (split( '/', $perl_path))
{
my $test_path = join( '/', @perl_long_path, $item);
if (-e $test_path)
{
push @perl_long_path, $item;
} elsif (exists $FOUND_SHORT_PATHS{ $test_path}->[1])
{
push @perl_long_path, $FOUND_SHORT_PATHS{ $test_path}->[1];
} else
{

my $parent_path = join( '/', @perl_long_path);

push @perl_long_path, $item;
if (opendir( my $dir_fh, $parent_path))
{
my @entries = grep( / /, readdir ($dir_fh));
closedir $dir_fh;

my $item_re = $item;
$item_re =~ s/~\d+$/\.*/;
$item_re = "^$item_re\$";

my @matched_entries;
foreach my $entry (@entries)
{
my $this_entry = uc $entry;
$this_entry =~ s/ //;

if ($this_entry =~ $item_re)
{
push @matched_entries, $entry;
}
}
if (@matched_entries == 1)
{
$perl_long_path[-1] = $matched_entries[0];
$FOUND_SHORT_PATHS{ $test_path}->[1] = $matched_entries[0];
} else
{
$failed = 1;
last;
}
}
}
}
$perl_long_path = ($failed) ? $perl_path : join( '/', @perl_long_path);
$FOUND_SHORT_PATHS{ $path}->[0] = $perl_long_path;




}
}
} else
{



$perl_long_path = $perl_path;

}

return $perl_long_path;
}




sub OS_copy_file($$)
{
my ($in_file,
$out_file,
) = @_;
my ($rc, $command, $fail_reason);




my $copied = Win32::CopyFile( $in_file, $out_file, 1);	    # 1 == OVERWRITE
if (!$copied && -f $out_file)
{
chmod oct(777), $out_file;
$copied = Win32::CopyFile( $in_file, $out_file, 1);	    # 1 == OVERWRITE
}
if ($copied)
{
$rc = 0;
} else
{
$rc = 1;
$command = "Win32::CopyFile( $in_file, $out_file, 1);";
$fail_reason = $!;
}

return ($rc, $command, $fail_reason);
}




sub OS_hide_file($$)
{
my ($filespec,
$must_hide	    # 0 = unhide, 1 = hide, undef = test-only
) = @_;
my $old_state;

$old_state = win32_set_hidden_attribute( $filespec, $must_hide);

return $old_state;
}





















sub win32_set_hidden_attribute($$)
{
my ($file,
$on_or_off) = @_;	# 0 = unhide, 1 = hide, undef = test_only
my $was_hidden;

my $old_attrib;
Win32::File::GetAttributes( $file, $old_attrib) || die( "Unable to GetAttributes $file\n- $!");
if (defined $on_or_off)
{
my $new_attrib;
if ($on_or_off)
{
$new_attrib = $old_attrib | Win32::File::HIDDEN;
} else
{
$new_attrib = $old_attrib & ~Win32::File::HIDDEN;
}
if ($new_attrib != $old_attrib)
{
Win32::File::SetAttributes( $file, $new_attrib) || die( "Unable to SetAttributes $file\n- $!");
}
}
$was_hidden = ($old_attrib & Win32::File::HIDDEN) ? 1 : 0;


return $was_hidden;
}




sub OS_get_desktop_path($)
{
my ($system_item) = (@_);

if ($system_item)
{
if (!defined $SYSTEM_DESKTOP_PATH)
{
$SYSTEM_DESKTOP_PATH = get_folder_path( Win32::CSIDL_COMMON_DESKTOPDIRECTORY);
}
return $SYSTEM_DESKTOP_PATH;
} else
{
if (!defined $USER_DESKTOP_PATH)
{
$USER_DESKTOP_PATH = get_folder_path( Win32::CSIDL_DESKTOP);

}
return $USER_DESKTOP_PATH;
}
}




sub OS_get_startmenu_path($)
{
my ($system_item) = (@_);

if ($system_item)
{
if (!defined $SYSTEM_STARTMENU_PATH)
{
$SYSTEM_STARTMENU_PATH = get_folder_path( Win32::CSIDL_COMMON_PROGRAMS);
}
return $SYSTEM_STARTMENU_PATH;
} else
{
if (! defined $USER_STARTMENU_PATH)
{
$USER_STARTMENU_PATH = get_folder_path( Win32::CSIDL_PROGRAMS);

}
return $USER_STARTMENU_PATH;
}
}






sub OS_get_programs_path($)
{
my ($system_item) = (@_);

if ($system_item)
{
if (!defined $SYSTEM_PROGRAMS_PATH)
{

$SYSTEM_PROGRAMS_PATH = get_folder_path( Win32::CSIDL_PROGRAM_FILES)
if (!defined $SYSTEM_PROGRAMS_PATH);

}
return $SYSTEM_PROGRAMS_PATH;
} else
{
if (!defined $USER_PROGRAMS_PATH)
{
$USER_PROGRAMS_PATH = OS_get_user_path( 0) . '/MyPrograms';
}
return $USER_PROGRAMS_PATH;
}
}






sub OS_get_user_path($)
{
my ($system_item) = (@_);

if ($system_item)
{
if (!defined $SYSTEM_USER_PATH)
{
$SYSTEM_USER_PATH = get_folder_path( Win32::CSIDL_APPDATA);	# e.g.: C:\Users\Randy\AppData\Roaming
}
return $SYSTEM_USER_PATH;
} else
{
if (!defined $USER_USER_PATH)
{
$USER_USER_PATH = get_folder_path( Win32::CSIDL_PERSONAL);	# MyDocuments
}
return $USER_USER_PATH;
}
}




sub get_folder_path($)
{
my ($csidl) = @_;
my $path;

$path = Win32::GetFolderPath( $csidl);

if (defined $path)
{
$path =~ tr!\\!/!;
}

return $path;
}




sub OS_is_administrator()
{
return Win32::IsAdminUser();
}

1;

