#=================================================
#
#   gbsguiinit.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSGUIINIT @ARGV") if ($ENV{GBSDEBUG_FILE});




use 5.016_003;
use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::ask;
use glo::genopt;
use mod::gbsenv;
use mod::gbscmd;
use mod::roots;
use mod::gbsinit;















$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ 'rel',    'rel',    'sso', '.' , "Specific GBS release. You can also specify 'cur', 'current' or '?'" ],
);
GENOPT_set_optdefs( [ 'gbsguiinit', 'gbsgui' ], \@genopts,
'Startup GBSGUI',
"Alias for this command is 'gbsgui'");
GENOPT_parse();
}
my $REL = GENOPT_get( 'rel');

$REL = ''
if ($REL eq '.' || $REL eq 'cur' || $REL eq 'current');




{



if ($REL eq '?')
{
my @rels = ENV_glob( "$GBS::SCRIPTS_ROOT/*/gbsswr.pl");
my @gbs_rels = map { ENV_parent_dir( $_, -2) } @rels;
my $gbs_scripts_rel = ENV_getenv( 'GBS_SCRIPTS_REL');
$REL = ASK_value_from_menu( 'Select a GBS Version', \$gbs_scripts_rel, undef, [ @gbs_rels ]);
}




my @lines = GBSINIT_setup( $REL, 1);	# $full_setup




if (ROOTS_get_nr() > 0)
{



push @lines, GBSCMD_get_full_gbs_command( gbsswr => [ '.', '--exec=gbsgui.pl' ]);
} else
{
ENV_say( 1, "No Roots/Systems defined for this user",
"- Type 'swr --add' to use an existing Root/System",
"- or   'swr --new' to define a new Root/System",
"- or   'gbshelp'   to get extensive help on how to proceed");
}




GBSENV_write_result_script( \@lines, 0);
}

ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);

}


