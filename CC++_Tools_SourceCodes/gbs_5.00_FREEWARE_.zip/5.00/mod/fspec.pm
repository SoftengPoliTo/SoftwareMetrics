#=================================================
#
#   fspec.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::fspec;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
FSPEC_flinc
FSPEC_sysflinc
FSPEC_sca
FSPEC_export
FSPEC_abt_file
FSPEC_scope
FSPEC_owners
FSPEC_system
FSPEC_steps
FSPEC_switch
FSPEC_sys
FSPEC_comment_chars
FSPEC_subsys_script
FSPEC_makefile
FSPEC_ssprop
FSPEC_scadef
FSPEC_gbsdb
FSPEC_gbsall
FSPEC_gbsmake_file
);
}




use glo::env;




sub FSPEC_flinc($$$$$);
sub FSPEC_sysflinc($$$);
sub FSPEC_sca($$$$$);
sub FSPEC_export($$$$);
sub FSPEC_abt_file($$$);
sub FSPEC_scope($$$$);
sub FSPEC_owners($$);
sub FSPEC_system($$);
sub FSPEC_steps($$);
sub FSPEC_switch($$);
sub FSPEC_sys($$);
sub FSPEC_comment_chars($);
sub FSPEC_subsys_script($$$);
sub FSPEC_makefile($$);
sub FSPEC_ssprop($$);
sub FSPEC_scadef($);
sub FSPEC_gbsdb();
sub FSPEC_gbsall($$);
sub FSPEC_gbsmake_file($$);

sub set_gbs_filetype($$);










sub FSPEC_flinc($$$$$)
{
my ($file,		    # incs_<type>.gbs, incs_<type>.usr, etc. see above
$root_path,
$subsys,	    # may be ''
$component,	    # may be ''
$build,		    # may be ''
) = @_;



my $path = $root_path;
if ($subsys ne '')
{
$path .= "/dev/$subsys";
if ($component ne '')
{
$path .= "/comp/$component/opt";
} else
{
$path .= '/build';
}
} else
{
$path .= '/sysbuild';
}
if ($build ne '')
{
$path .= "/$build";
}


return (wantarray) ? ($path, $file) : "$path/$file";
}






sub FSPEC_sysflinc($$$)
{
my ($file,		    # sysincs_<type>.gbs, sysincs_<type>.usr, etc. see above
$root_path,
$build,
) = @_;



my $path = "$root_path/sysbuild/$build";


return (wantarray) ? ($path, $file) : "$path/$file";
}






sub FSPEC_sca($$$$$)
{
my ($file,		    # sca_<build>, etc. see above
$root_path,
$subsys,	    # may be ''
$audit,
$build_or_name,	    # may also be <uppercase_name> (not used)
) = @_;



my $path;
if ($subsys ne '')
{
$path = "$root_path/dev/$subsys/audit/$audit";
} else
{
$path = "$root_path/sysaudit/$audit";
}

return (wantarray) ? ($path, $file) : "$path/$file";
}





sub FSPEC_export($$$$)
{
my ($file,		    # with or without .gbs or .usr
$root_path,
$subsys,
$component,
) = @_;



my $path;
if ($component ne '')
{
$path = "$root_path/dev/$subsys/comp/$component";
} else
{
$path = "$root_path/dev/$subsys";
}
$file = set_gbs_filetype( $path, $file);

return (wantarray) ? ($path, $file) : "$path/$file";
}







sub FSPEC_abt_file($$$)
{
my ($file,			# e.g. build.gbs, audit.usr, build
$root_path,
$audit_build_tool,	# e.g. $GBS_BUILD
) = @_;



my $path;
{
my $file_name = ENV_split_spec_n( $file);
if ($file_name eq 'build')
{
$path = "$root_path/sysbuild/$audit_build_tool";
} elsif ($file_name eq 'audit')
{
$path = "$root_path/sysaudit/$audit_build_tool";
} elsif ($file_name eq 'tool')
{
$path = "$root_path/systool/$audit_build_tool";
} else
{
ENV_sig( F => "Invalid att_file '$file', '$root_path', '$audit_build_tool'");
}
}
$file = set_gbs_filetype( $path, $file);

return (wantarray) ? ($path, $file) : "$path/$file";
}





sub FSPEC_scope($$$$)
{
my ($file,		    # 'scope' with or without .gbs or .usr
$root_path,
$subsys,
$component,
) = @_;



my $path = "$root_path/dev/$subsys/comp/$component";
$file = set_gbs_filetype( $path, $file);

return (wantarray) ? ($path, $file) : "$path/$file";
}




sub FSPEC_owners($$)
{
my ($file,		    #  'owners' with or without .gbs or .usr
$root_path,
) = @_;



my $path = "$root_path/sys";
$file = set_gbs_filetype( $path, $file);

return (wantarray) ? ($path, $file) : "$path/$file";
}




sub FSPEC_system($$)
{
my ($file,		    # 'system', with or without .gbs or .usr
$root_path,
) = @_;



my $path = $root_path;
$file = set_gbs_filetype( $path, $file);

return (wantarray) ? ($path, $file) : "$path/$file";
}





sub FSPEC_steps($$)
{
my ($file,		    # 'steps', with or without .gbs or .usr
$root_path,
) = @_;



my $path = "$root_path/sys";
$file = set_gbs_filetype( $path, $file);

return (wantarray) ? ($path, $file) : "$path/$file";
}






sub FSPEC_switch($$)
{
my ($file,			# switch or


$root_path,
) = @_;



my $path = $root_path;
$file .= (-e "$path/$file.usr") ? '.usr' : '.gbs'
if ($file eq 'switch');
$file .= $GBS::SHELL_FILETYPE			    # .bat or .sh
if ($file !~ /(\.sh$)|(\.bat$)/);

return (wantarray) ? ($path, $file) : "$path/$file";
}





sub FSPEC_sys($$)
{
my ($file,		    # 'sys', with or without .gbs or .usr
$root_path,
) = @_;



my $path = "$root_path/sys";
$file = set_gbs_filetype( $path, $file);

return (wantarray) ? ($path, $file) : "$path/$file";
}





sub FSPEC_comment_chars($)
{
my ($root_path,
) = @_;



my $path = "$root_path/sys/templates";
my $file = 'comment_chars.gbs';

return (wantarray) ? ($path, $file) : "$path/$file";
}






sub FSPEC_subsys_script($$$)
{
my ($file,		   # 'gbssub' with or without .sh or .bat
$root_path,
$subsys,
) = @_;



my $subsys_path = "$root_path/dev/$subsys";
$file .= $GBS::SHELL_FILETYPE			# .bat or .sh
if ($file !~ /(\.sh$)|(\.bat$)/);

return (wantarray) ? ($subsys_path, $file) : "$subsys_path/$file";
}




sub FSPEC_makefile($$)
{
my ($root_path,
$subsys,
) = @_;



my $path = "$root_path/dev/$subsys";
my $file = 'Makefile.mk';

return (wantarray) ? ($path, $file) : "$path/$file";
}





sub FSPEC_ssprop($$)
{
my ($root_path,
$subsys,
) = @_;



my $path = "$root_path/dev/$subsys";
my $file = 'ssprop.gbs';

return (wantarray) ? ($path, $file) : "$path/$file";
}





sub FSPEC_scadef($)
{
my ($plugin_name,
) = @_;


return "$GBS::SCRIPTS_PATH/plugins/audit/$plugin_name/scadef.gbs";
}




sub FSPEC_gbsdb()
{



my $file = 'gbsdb.dat';

return (wantarray) ? ($GBS::BASE_PATH, $file) : "$GBS::BASE_PATH/$file";
}




sub FSPEC_gbsall($$)
{
my ($filetype,	    # full_name+type or .sh or .bat or ''
$in_install,	    # In GBS_SCRIPTS_ROOT else in GBS_BASE_PATH
) = @_;



my $path = ($in_install) ? $GBS::SCRIPTS_ROOT : $GBS::BASE_PATH;
my $file;

my ($name, $type) = ENV_split_spec_nt( $filetype);
ENV_sig( F => "Filename in '$filetype' must be 'gbsall'")
if ($name ne '' && $name ne 'gbsall');
if ($type eq '')
{
$file = "gbsall$GBS::SHELL_FILETYPE";		    # .bat or .sh
} else
{
ENV_sig( F => "Filetype in '$filetype' must be .bat or .sh")
if ($type ne '.bat' && $type ne '.sh');
$file = "gbsall$type";
}

return (wantarray) ? ($path, $file) : "$path/$file";
}




sub FSPEC_gbsmake_file($$)
{
my ($gbs_build_path,
$gbsbuild,
) = @_;

return "$gbs_build_path/$gbsbuild.mk";
}




sub set_gbs_filetype($$)
{
my ($path,
$file,	    # type == .gbs or .usr or ''
) = @_;

$file .= (-e "$path/$file.usr") ? '.usr' : '.gbs'
if (index( $file, '.') == -1);

return $file;
}

1;

