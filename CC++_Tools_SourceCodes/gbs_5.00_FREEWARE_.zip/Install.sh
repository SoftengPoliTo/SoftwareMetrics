#!/bin/bash
#
#   Install.sh
#       Must NOT be sourced
#	--q-
#      --site=<site>
#      --verbose-
#	--help
#

if [[ ${BASH_SOURCE[0]} != "" ]]
then
    # on bash this will work even if the script is sourced
    #\echo "BASH_SOURCE[0]=${BASH_SOURCE[0]}"
    \pushd `dirname ${BASH_SOURCE[0]}` > /dev/null
else
    #\echo "No BASH_SOURCE"
    \pushd `dirname $0` > /dev/null
fi

#
#   Sanity Check: Assert TMPDIR
#
[[ "$TMPDIR"=="" ]] && \export TMPDIR=$HOME/tmp
\mkdir $HOME/tmp 2>/dev/null

#
#   Sanity Check: Assert Install Dir
#
if [[ ! -e ./Install.bat || ! -e ./Install.sh || ! -e ./Install.pl || ! -e ./Readme.txt ]]
then
    \echo "INSTALL_: Fatal Error: You are not in the proper Install directory"
else
    #
    #	set GBS_BOOT_PATH
    #
    \export GBS_BOOT_PATH=$HOME/.gbs

    #
    #	Create the ~/.gbs directory if it does not exist
    #
    if [[ ! -e $GBS_BOOT_PATH ]]
    then
	mkdir $GBS_BOOT_PATH
    fi

    #
    #   Define GBS_SCRIPTS_PATH
    #
    #	If we are in the unzipped directory then the only directory is the toplevel directory
    #	and its name is its version name
    #	If we are in the development Install directory there will be no toplevel directory
    \unset GBS_SCRIPTS_PATH
    \unset GBS_SCRIPTS_ROOT
    \unset GBS_SCRIPTS_REL
    for direntry in *; do
	if [ -d "$direntry" ]; then
	    SUBDIR="$direntry"
	fi
    done
    if [[ "$SUBDIR" != "" ]]
    then
	\echo "INSTALL_: GBS version: $SUBDIR"
	\export GBS_SCRIPTS_PATH="$PWD/$SUBDIR"
	\export GBS_SCRIPTS_ROOT="$PWD"
	\export GBS_SCRIPTS_REL="$SUBDIR"
    else
	echo "INSTALL_: *** In Development Environment ***"
	\export GBS_SCRIPTS_PATH="$(dirname "$PWD")"
	\export GBS_SCRIPTS_ROOT="$(dirname "$GBS_SCRIPTS_PATH")"
	\export GBS_SCRIPTS_REL="${GBS_SCRIPTS_PATH##*/}"		# get the parent directory name
    fi
    echo "INSTALL_: GBS_SCRIPTS_ROOT set to $GBS_SCRIPTS_ROOT"
    echo "INSTALL_: GBS_SCRIPTS_REL  set to $GBS_SCRIPTS_REL"
    echo "INSTALL_: GBS_SCRIPTS_PATH set to $GBS_SCRIPTS_PATH"

    #
    #  Set GBS_BOOT_PATH, GBS_BASE_PATH and GBS_PERL_CMD and XDG_DESKTOP_DIR
    #
    source  $GBS_SCRIPTS_PATH/setup/boot.sh

    #
    #   Run Install
    #       --q
    #       --site=<site>
    #       --verbose-
    #       --help
    #
    $GBS_PERL_CMD Install.pl $*
fi

#
#   Exit
#
read -p "INSTALL_: Hit <Enter> to finish (and maybe close window): "

###EOF###

