#=================================================
#
#   spit.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::spit;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SPIT_file
SPIT_append_file
SPIT_file_nl
SPIT_append_file_nl
SPIT_tmp_file_nl
SPIT_script_file_nl
SPIT_tmp_script_file_nl
);
}




use glo::env;
use glo::shell;




sub SPIT_file($$);
sub SPIT_append_file($$);
sub SPIT_file_nl($$);
sub SPIT_append_file_nl($$);
sub SPIT_tmp_file_nl($$);
sub SPIT_script_file_nl($$);
sub SPIT_tmp_script_file_nl($$);









sub SPIT_file($$)
{
my ($filespec,
$line_or_ref,		# recursive
) = @_;

ENV_spit_file( $filespec, $line_or_ref, 0, F => '>');	    # 0 == !$must_add_nl
}





sub SPIT_append_file($$)
{
my ($filespec,
$line_or_ref,		# recursive
) = @_;

ENV_spit_file( $filespec, $line_or_ref, 0, F => '>>');	    # 0 == !$must_add_nl
}





sub SPIT_file_nl($$)
{
my ($filespec,
$line_or_ref,		# recursive
) = @_;

ENV_spit_file( $filespec, $line_or_ref, 1, F => '>');	    # 1 == $must_add_nl
}





sub SPIT_append_file_nl($$)
{
my ($filespec,
$line_or_ref,		# recursive
) = @_;

ENV_spit_file( $filespec, $line_or_ref, 1, F => '>>');	    # 1 == $must_add_nl
}





sub SPIT_tmp_file_nl($$)
{
my ($tmp_file,
$line_or_ref,		# recursive
) = @_;

my $filespec = ENV_get_tmp_spec( $tmp_file);

ENV_spit_file( $filespec, $line_or_ref, 1, F => '>');	    # 1 == $must_add_nl

return $filespec;
}





sub SPIT_script_file_nl($$)
{
my ($filespec,
$line_or_ref,		# recursive
) = @_;



my @header = SHELL_batch_header();
ENV_spit_file( $filespec, [ \@header, $line_or_ref ], 1, F => '>');	    # 1 == $must_add_nl
chmod 0755, $filespec;	# set file to 'x'
}






sub SPIT_tmp_script_file_nl($$)
{
my ($tmp_file,	# without .type
$line_or_ref,	# recursive
) = @_;

my $filespec = ENV_get_tmp_spec( $tmp_file) . ENV_shell_filetype();

my @header = SHELL_batch_header();
my @tail = SHELL_exit_rc( 0);
ENV_spit_file( $filespec, [ \@header, $line_or_ref, \@tail ], 1, F => '>');	    # 1 == $must_add_nl
chmod 0755, $filespec;	# set file to 'x'

return $filespec;
}

1;
