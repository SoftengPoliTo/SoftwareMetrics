#!/bin/bash
#=================================================
#  pre_define.sh <rel> <command> [<command_arg> ...]
#   Called by GBS shortcut
#
#   - Assert TMPDIR
#   - Create a $TMPDIR/gbs_pre_define_$PPID.sh file that will call define.sh
#     The pre_define file will later be called by the bash login script (e.g. .profile)
#
#   - Args:
#     <rel>:     'cur', 'beta' or actual version
#     <command>: 'gbs', 'perl', 'source' or 'exec'
#
#   GBS Startup:    gbs $*
#   GBS Setup:	    source gbssetup.sh $*
#   GBS Uninstall:  perl gbsuninstall.pl $*
#   GBS Help:	    ** Direct, does not use define.sh
#=================================================

#
#   Assert TMPDIR
#
[[ "$TMPDIR"=="" ]] && \export TMPDIR=$HOME/tmp
\mkdir $HOME/tmp 2>/dev/null

#
#   Create the call for .profile
#
\echo "\\source $HOME/.gbs/define.sh $*" > "$TMPDIR/gbs_pre_define_$PPID.sh"

#  **EOF**
