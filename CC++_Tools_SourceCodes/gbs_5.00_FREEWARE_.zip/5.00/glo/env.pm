#=================================================
#
#   env.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::env;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
ENV_set_application
ENV_update_application_scripts_path
ENV_get_application_name
ENV_get_application_scripts_path
ENV_get_application_data_path
ENV_get_application_base_path
ENV_get_perl_cmd
ENV_get_main_name
ENV_is_development
ENV_is_linux
ENV_is_win32
ENV_this_osname
ENV_other_osname
ENV_is_interactive
ENV_is_gui
ENV_print_separator_line
ENV_enable_beeps
ENV_beeps_are_enabled
ENV_beep
ENV_reap_beeps
ENV_set_verbose
ENV_set_say_func
ENV_say
ENV_say_stderr
ENV_whisper
ENV_trace
ENV_print
ENV_get_prefix
ENV_sig
ENV_file_sig
ENV_try
ENV_exit
ENV_get_nr_errors
ENV_stackdump
ENV_debug
ENV_is_debug
ENV_print_end_msg
ENV_printable
ENV_clone
ENV_get_package_keys
ENV_dump
ENV_dump_package
ENV_dump_env
ENV_deref
ENV_store
ENV_eval_empty
ENV_eval_undef
ENV_undef2empty
ENV_call
ENV_getenv
ENV_getenv_bool
ENV_getenv_perl_path
ENV_setenv
ENV_setenv_os_path
ENV_get_changed_envs
ENV_get_delta_envs
ENV_command_filespec
ENV_command_types
ENV_is_command_type
ENV_shell_filetype
ENV_is_shell_file
ENV_chmod
ENV_get_hostname
ENV_uname
ENV_unique_id
ENV_get_userid
ENV_glob
ENV_glob_files
ENV_wild_2_re
ENV_is_wildcard
ENV_wildcard
ENV_wildcards
ENV_not_wildcards
ENV_get_term_size
ENV_get_term_size_default
ENV_set_background_term_size
ENV_is_abs_path
ENV_is_abs_path_perl
ENV_is_option
ENV_is_in_path
ENV_chop_path
ENV_parent_path
ENV_parent_dir
ENV_set_tmpdir_path
ENV_get_tmpdir_path
ENV_get_os_tmpdir_path
ENV_get_tmp_spec
ENV_get_tmp_path
ENV_os_paths
ENV_perl_paths
ENV_perl_canon_paths
ENV_perl_paths_noquotes
ENV_perl_paths_long
ENV_canonicalize_paths
ENV_which
ENV_which_path
ENV_paths_equal
ENV_expand_envs
ENV_expand_arg
ENV_delink_spec
ENV_rel_spec
ENV_abs_paths
ENV_rel_paths
ENV_strip_path
ENV_shortest_paths
ENV_split_spec_pnt
ENV_split_spec_pf
ENV_split_spec_p
ENV_split_spec_f
ENV_split_spec_nt
ENV_split_spec_n
ENV_split_spec_t
ENV_split_path
ENV_join_path
ENV_chdir
ENV_cwd
ENV_pushd
ENV_popd
ENV_file_is_newer
ENV_file_is_same
ENV_mkdir
ENV_mkpath
ENV_rmdir
ENV_rmtree
ENV_readdir
ENV_rename
ENV_dir_count
ENV_unlink
ENV_copy_file
ENV_backup_file
ENV_touch_file
ENV_slurp_file
ENV_spit_file
ENV_hide_file
ENV_max_command_line
ENV_prepare_command
ENV_find_in_perl_inc
ENV_system
ENV_backtick
ENV_run3
ENV_exec
ENV_rc_status
ENV_detab
ENV_retab
ENV_encode
ENV_decode
ENV_split_quoted_space
ENV_join_quoted_space
ENV_enquote
ENV_dequote
ENV_split_lines
ENV_redirect_stdouterr
ENV_restore_stdouterr
ENV_get_desktop_path
ENV_get_startmenu_path
ENV_get_programs_path
ENV_get_user_path
ENV_is_administrator
ENV_set_global_variables
);
}




BEGIN
{


if ($^O eq 'MSWin32')
{
require glo::os_win;
import  glo::os_win;
} else
{
require glo::os_linux;
import  glo::os_linux;
}
}

use File::Glob ':bsd_glob';      # Override glob built-in




sub ENV_set_application($$;$$$$);
sub ENV_update_application_scripts_path($);
sub ENV_get_application_name();
sub ENV_get_application_scripts_path();
sub ENV_get_application_base_path();
sub ENV_get_perl_cmd();
sub ENV_get_main_name();
sub ENV_is_development();
sub ENV_is_linux();
sub ENV_is_win32();
sub ENV_this_osname();
sub ENV_other_osname();
sub ENV_is_interactive();
sub ENV_is_gui(;$);
sub ENV_print_separator_line();
sub ENV_enable_beeps($);
sub ENV_beeps_are_enabled();
sub ENV_beep();
sub ENV_reap_beeps();
sub ENV_set_verbose(;$);
sub ENV_set_say_func($$);
sub ENV_say($@);
sub ENV_say_stderr($@);
sub ENV_whisper($@);
sub ENV_trace(@);
sub ENV_print($@);
sub ENV_get_prefix($);
sub ENV_sig($@);
sub ENV_file_sig($$@);
sub ENV_try($$$);
sub ENV_exit(;$);
sub ENV_get_nr_errors();
sub ENV_stackdump();
sub ENV_debug($@);
sub ENV_is_debug(;$);
sub ENV_print_end_msg($);
sub ENV_printable($);
sub ENV_clone($);
sub ENV_get_package_keys($);
sub ENV_dump($$;$$);
sub ENV_dump_package($$;$$);
sub ENV_dump_env(;$$);
sub ENV_deref($);
sub ENV_store($$);
sub ENV_eval_empty($);
sub ENV_eval_undef($);
sub ENV_undef2empty(@);
sub ENV_call($;$$);
sub ENV_getenv($);
sub ENV_getenv_bool($);
sub ENV_getenv_perl_path($);
sub ENV_setenv($$);
sub ENV_setenv_os_path($$);
sub ENV_get_changed_envs();
sub ENV_get_delta_envs($);
sub ENV_command_filespec($);
sub ENV_command_types();
sub ENV_is_command_type($);
sub ENV_shell_filetype();
sub ENV_is_shell_file($);
sub ENV_chmod($@);
sub ENV_get_hostname();
sub ENV_uname();
sub ENV_unique_id();
sub ENV_get_userid();
sub ENV_glob(@);
sub ENV_glob_files(@);
sub ENV_wild_2_re(@);
sub ENV_is_wildcard($);
sub ENV_wildcard($$);
sub ENV_wildcards($$$);
sub ENV_not_wildcards($$);
sub ENV_get_term_size();
sub ENV_get_term_size_default();
sub ENV_set_background_term_size();
sub ENV_is_abs_path($);
sub ENV_is_abs_path_perl($);
sub ENV_is_option($);
sub ENV_is_in_path($$);
sub ENV_chop_path($$);
sub ENV_parent_path($);
sub ENV_parent_dir($$);
sub ENV_get_application_data_path();
sub ENV_set_tmpdir_path($);
sub ENV_get_tmpdir_path();
sub ENV_get_os_tmpdir_path();
sub ENV_get_tmp_spec($);
sub ENV_get_tmp_path($);
sub ENV_os_paths(@);
sub ENV_perl_paths(@);
sub ENV_perl_canon_paths(@);
sub ENV_perl_paths_noquotes(@);
sub ENV_perl_paths_long(@);
sub ENV_canonicalize_paths(@);
sub ENV_which($$);
sub ENV_which_path($@);
sub ENV_paths_equal($$);
sub ENV_expand_envs($);
sub ENV_expand_arg($);
sub ENV_delink_spec($);
sub ENV_rel_spec($$);
sub ENV_abs_paths($$);
sub ENV_rel_paths($$);
sub ENV_strip_path($$);
sub ENV_shortest_paths($$);
sub ENV_split_spec_pnt($);
sub ENV_split_spec_pf($);
sub ENV_split_spec_p($);
sub ENV_split_spec_f($);
sub ENV_split_spec_nt($);
sub ENV_split_spec_n($);
sub ENV_split_spec_t($);
sub ENV_split_path($);
sub ENV_join_path($);
sub ENV_chdir($);
sub ENV_cwd();
sub ENV_pushd($);
sub ENV_popd();
sub ENV_file_is_newer($$);
sub ENV_file_is_same($$);
sub ENV_mkdir($;$$);
sub ENV_mkpath($;$$);
sub ENV_rmdir($;$$);
sub ENV_rmtree($$;$$);
sub ENV_readdir($$;$);
sub ENV_rename($$;$);
sub ENV_dir_count($;$);
sub ENV_unlink($;$$);
sub ENV_copy_file($$$);
sub ENV_backup_file($$$);
sub ENV_touch_file($;$);
sub ENV_slurp_file($;$$$);
sub ENV_spit_file($$$;$$);
sub ENV_hide_file($$);
sub ENV_max_command_line();
sub ENV_prepare_command($);
sub ENV_find_in_perl_inc($$);
sub ENV_system($$);
sub ENV_backtick($$$);
sub ENV_run3($$$$$);
sub ENV_exec($$);
sub ENV_rc_status($$);
sub ENV_detab($);
sub ENV_retab($);
sub ENV_split_quoted_space($);
sub ENV_join_quoted_space(@);
sub ENV_encode(@);
sub ENV_decode(@);
sub ENV_enquote(@);
sub ENV_dequote(@);
sub ENV_split_lines($@);
sub ENV_redirect_stdouterr($);
sub ENV_restore_stdouterr();
sub ENV_get_desktop_path($);
sub ENV_get_startmenu_path($);
sub ENV_get_programs_path($);
sub ENV_get_user_path($);
sub ENV_is_administrator();
sub ENV_set_global_variables($;$);

sub set_app_value($$);
sub set_app_name($);
sub set_app_perl_cmd($);
sub match_type($);
sub stackdump($);
sub handle_rc($$$;$);
sub deref_lines($$);
sub format_lines($@);
sub exec_beep();
sub handle_sig($$$);
sub get_debug_name();
sub dump_item($$$$$);
sub de_ref($$);
sub my_print($@);
sub my_say($$@);
sub my_die(@);




my $MAIN_PATH;
my $MAIN_NAME;
my $MAIN_NAME_UC;
my $MAIN_NAME_UC_;
my $IS_WIN32;
my $IS_LINUX;
my $IS_INTERACTIVE;	    # connected to keyboard and window

BEGIN
{
my $program_name = $0;	# May or may not include the path
$program_name =~ tr!\\!/!;	# perl path
if (index( $program_name, '/') >= 0)
{
($MAIN_PATH, $MAIN_NAME) = $program_name =~ m!(.*)/(.+)\.!;
} else
{
$MAIN_PATH = OS_get_cwd();
($MAIN_NAME) = $program_name =~ m!(.+)\.!;
}

$MAIN_NAME_UC = uc $MAIN_NAME;
$MAIN_NAME_UC_ = ' ' x ((length $MAIN_NAME_UC) + 1);

$IS_WIN32 = ($^O eq 'MSWin32');
$IS_LINUX = !$IS_WIN32;


$IS_INTERACTIVE = (-t STDIN && -t STDOUT) ? 1 : 0;	    # connected to keyboard and window
}

my $PREFIX = $MAIN_NAME_UC . '/ENV';

my $IS_GUI = 0;

my $XTERM_DEFAULT_WIDTH = 100;
my $XTERM_DEFAULT_HEIGHT = 50;
my $XTERM_BACKGROUND_WIDTH = 130;
my $XTERM_WIDTH;
my $XTERM_HEIGHT;

my $PATH_SEPARATOR = ($IS_WIN32) ? ';' : ':';
my @SHELL_FILETYPES = ($IS_WIN32) ? qw( .bat .sh) : qw( .sh .bat);

my $IS_DEVELOPMENT;	    # Do not initialize!

my $APP_NAME = $MAIN_NAME_UC;		# e.g.: GBS
my $APP_LONGNAME = $MAIN_NAME_UC;	# e.g.: Generic Build Support
my $APP_SCRIPTS_PATH = $MAIN_PATH;	# e.g.: GBS_SCRIPTS_PATH or $MAIN_PATH
my $APP_DATA_PATH;			# Do not initialize!	e.g.:
my $APP_BASE_PATH;			# Do not initialize!	e.g.: GBS_BASE_PATH
my $APP_PERL_CMD = 'perl';

my %APP_REFS = (

APP_NAME		=> [ \$APP_NAME,	    0, \&set_app_name, ],
APP_LONGNAME	=> [ \$APP_LONGNAME,	    0, undef, ],
APP_SCRIPTS_PATH	=> [ \$APP_SCRIPTS_PATH,    1, undef, ],
APP_DATA_PATH	=> [ \$APP_DATA_PATH,	    1, undef, ],
APP_BASE_PATH	=> [ \$APP_BASE_PATH,	    1, undef, ],
APP_PERL_CMD	=> [ \$APP_PERL_CMD,	    0, \&set_app_perl_cmd, ],
);

my $DEBUG_ALL;					    # bool
my %DEBUG_NAMES;

my $DEBUG_ACTIVE = 0;

my $OS_TMPDIR_PATH;	    # Do not initialize!
my $TMPDIR_PATH;	    # Do not initialize!


my $MAX_COMMAND_LINE = ($IS_WIN32) ? (8175 - 1) : (32000 - 1);



my @COMMAND_TYPES;	    # Do not initialize!    Lower-Case!

my $VERBOSE;		    # bool

my $BEEPS_ENABLED = 1;
my $NR_BEEPS = 0;
my $NR_WARNINGS = 0;
my $NR_ERRORS = 0;

my $UNIQUE_COUNT = 0;

my $RUNNING_IN_EXEC = 0;

my @SAVED_ENVS = %ENV;


my $SAVED_STDOUT;
my $SAVED_STDERR;

my $SAY_FUNC;
my $PRINT_FUNC;

my $IS_IN_TRY = 0;











sub ENV_set_application($$;$$$$)
{
my ($app_name,		    # no spaces				    e.g.: GBS
$app_longname,		    # spaces allowed			    e.g.: Generic Build Support
$app_scripts_path,	    # must be canonicalised root_path!	    e.g.: GBS_SCRIPTS_PATH
$app_data_path,		    # must be verified existing directory   e.g.: GBS_HOME_PATH
$app_base_path,		    # must be verified existing directory   e.g.: GBS_BASE_PATH
$perl_cmd,		    # must exist			    e.g.: GBS_PERL_CMD
) = @_;



set_app_value( APP_NAME => $app_name);
set_app_value( APP_LONGNAME => $app_longname);
set_app_value( APP_SCRIPTS_PATH => $app_scripts_path);
set_app_value( APP_DATA_PATH => $app_data_path);
set_app_value( APP_BASE_PATH => $app_base_path,);
set_app_value( APP_PERL_CMD => $perl_cmd);
}





sub ENV_update_application_scripts_path($)
{
my ($app_scripts_path,	    # must be canonicalised root_path!	    e.g.: GBS_SCRIPTS_PATH
) = @_;

set_app_value( APP_SCRIPTS_PATH => $app_scripts_path);
}




sub set_app_value($$)
{
my ($name,		    #
$value,		    # undef, 'value' or '<value_envvar>'
) = @_;

my ( $value_ref, $is_path, $post_func ) = @{$APP_REFS{$name}};
my $old_value = $$value_ref;
my $new_value;		    # value or undef
my $envvar_name = '';
if (defined $value)
{

my $error_prefix;
if (substr( $value, 0, 1) eq '<' && substr( $value, -1, 1) eq '>')
{
$envvar_name = substr( $value, 1, -1);
$new_value = ENV_eval_undef(  $ENV{$envvar_name});
ENV_sig( F => "EnvVar '$envvar_name' was not set")
if (!defined $new_value);
$error_prefix = "$name: $envvar_name =>";
} else
{
$new_value = $value;
$error_prefix = "$name:";
}
if ($is_path)
{
$new_value = ENV_perl_paths( $new_value);
ENV_sig( W => "$error_prefix => '$new_value': no such path")
if (! -d $new_value);
}

$$value_ref = $new_value;
}

if (defined $new_value)
{
$$value_ref = $new_value;
ENV_debug( 1, "$name ($old_value) changed to '$new_value'")
if (defined $old_value && $new_value ne $old_value);
}

$post_func->( $envvar_name)
if (defined $$value_ref && defined $post_func);
}




sub set_app_name($)
{
my ($envvar_name,
) = @_;

if (defined $APP_NAME)
{



my $app_debug_prefix = "${APP_NAME}DEBUG_";

foreach my $env_name (grep /^$app_debug_prefix/, keys %ENV)
{
my $env_value = ENV_getenv( $env_name);
if ($env_value eq '1')
{
my $debug_name = substr( $env_name, length( $app_debug_prefix));
$DEBUG_NAMES{$debug_name} = 1;
ENV_whisper( 1, "DBG: $env_name=$env_value");
$DEBUG_ACTIVE = 1;
}
}
$DEBUG_ALL = $DEBUG_NAMES{ALL};
$VERBOSE = ENV_getenv_bool( "${APP_NAME}DEBUG_VERBOSE");	    # E.g.: GBSDEBUG_VERBOSE
}
}




sub set_app_perl_cmd($)
{
my ($envvar_name,
) = @_;

if ($APP_PERL_CMD eq 'perl')
{
$APP_PERL_CMD = ENV_which( 'perl', 'F');	# Fail if not found
ENV_setenv( $envvar_name => ENV_os_paths( $APP_PERL_CMD))
if ($envvar_name ne '');
} else
{
if (! -f $APP_PERL_CMD)
{
if ($envvar_name ne '')
{
ENV_sig( F => "APP_PERL_CMD: $envvar_name => '$APP_PERL_CMD': no such file");
} else
{
ENV_sig( F => "APP_PERL_CMD: '$APP_PERL_CMD': no such file");
}
}
}
}





sub ENV_get_application_name()
{
return wantarray ? ($APP_NAME, $APP_LONGNAME) : $APP_NAME;
}





sub ENV_get_application_scripts_path()
{
return $APP_SCRIPTS_PATH;
}





sub ENV_get_application_data_path()
{
if (!defined $APP_DATA_PATH)
{
my $app_data_path = OS_get_user_path( 0) . "/$APP_NAME";	# %MYDOCUMENTS% or ~
set_app_value( APP_DATA_PATH => $app_data_path);
ENV_whisper( 1, "APP_DATA_PATH set to",
$APP_DATA_PATH);
}

return $APP_DATA_PATH;
}






sub ENV_get_application_base_path()
{
if (!defined $APP_BASE_PATH)
{
my $application_name_lc = lc $APP_NAME;
my $app_base_path = OS_get_user_path( 0) . "/.$application_name_lc/base";	# %MYDOCUMENTS% or ~
set_app_value( APP_BASE_PATH => $app_base_path);
ENV_whisper( 1, "APP_BASE_PATH set to",
$APP_BASE_PATH);
}

return $APP_BASE_PATH;
}





sub ENV_get_perl_cmd()
{
if ($APP_PERL_CMD eq 'perl')
{
set_app_perl_cmd( '');
}

return $APP_PERL_CMD;
}





sub ENV_get_main_name()
{
return $MAIN_NAME_UC;
}




sub ENV_is_development()
{
$IS_DEVELOPMENT = -d "$APP_SCRIPTS_PATH/Tools"
if (!defined $IS_DEVELOPMENT);
return $IS_DEVELOPMENT;
}




sub ENV_is_linux()
{
return $IS_LINUX;
}




sub ENV_is_win32()
{
return $IS_WIN32;
}




sub ENV_this_osname()
{
return $^O;	    # MSWin32 or linux
}




sub ENV_other_osname()
{
return ($IS_WIN32) ? 'linux' : 'MSWin32';
}




sub ENV_is_interactive()
{
return $IS_INTERACTIVE;
}




sub ENV_is_gui(;$)
{
my ($is_gui,	# Bool. Optional
) = @_;
my $old_value = $IS_GUI;

$IS_GUI = $is_gui
if (defined $is_gui);

return $old_value;
}




sub ENV_print_separator_line()
{
ENV_get_term_size();
ENV_say( 0, '=' x ($XTERM_WIDTH - 5) . '');
}




sub ENV_enable_beeps($)
{
$BEEPS_ENABLED = $_[0];
}




sub ENV_beeps_are_enabled()
{
return $BEEPS_ENABLED;
}




sub ENV_beep()
{
$NR_BEEPS++;
}




sub ENV_reap_beeps()
{
exec_beep() if ($NR_BEEPS != 0);
$NR_BEEPS = 0;
}




sub exec_beep()
{
if ($BEEPS_ENABLED && $IS_INTERACTIVE)
{

if (!defined OS_beep())
{
CORE::print "\a";
}
}
}




sub ENV_set_verbose(;$)
{
my ($new_verbose) = @_;	    # bool. Just return cur value if undef.
my $old_verbose = $VERBOSE;

if (defined $new_verbose)
{
$VERBOSE = $new_verbose;
ENV_setenv( "${APP_NAME}DEBUG_VERBOSE" => $VERBOSE);	# E.g.: GBSDEBUG_VERBOSE

}

return $old_verbose;
}




sub ENV_set_say_func($$)
{
($SAY_FUNC,			# func->( $text_type, $lines_ref)
$PRINT_FUNC,		# func->( $text_type, $lines_ref)
) = @_;
}




sub ENV_say($@)
{
my ($indent,    # 0 = no prefix, 1 = $prefix, 2 = $prefix_ - Negative = prefix_level - 1, 3+ = indent
@lines_and_or_refs
) = @_;

ENV_sig( F => "Invalid indent ($indent)")
if ($indent !~ /^-?\d+$/);

my_say( N => 0, format_lines( $indent, deref_lines( 0, \@lines_and_or_refs)));
}






sub ENV_say_stderr($@)
{
my ($indent,    # 0 = no prefix, 1 = $prefix, 2 = $prefix_ - Negative = prefix_level - 1
@lines_and_or_refs
) = @_;

ENV_sig( F => "Invalid indent ($indent)")
if ($indent !~ /^-?[012]$/);

map { CORE::say( STDERR $_) } format_lines( $indent, deref_lines( 0, \@lines_and_or_refs));
}




sub ENV_whisper($@)
{
my ($indent,    # 0 = no prefix, 1 = $prefix, 2 = $prefix_ - Negative = prefix_level - 1, 3+ = indent
@lines_and_or_refs
) = @_;

ENV_say( $indent, @lines_and_or_refs)
if ($VERBOSE);
}







sub ENV_trace(@)
{
my (@lines_and_or_refs) = @_;

my @lines = deref_lines( 0, \@lines_and_or_refs);
chomp( @lines);	# remove trailing whitespace, including \n

my $prefix = ENV_get_prefix( 0);
my $line_nr = (caller(0))[2];
$prefix .= ":$line_nr";

if (@lines == 1)
{
my_say( N => 0, "=>$prefix: $lines[0]");
} else
{
my_say( N => 0, "=>$prefix:");
my_say( N => 2, shift @lines);
my_say( N => 4, @lines)
if (@lines);
}
}




sub ENV_debug($@)
{
my ($indent,    # 0 = no prefix, 1 = $prefix, 2 = $prefix_ - Negative = prefix_level - 1, 3+ = indent
@lines_and_or_refs
) = @_;
my $debug = 0;

if ($DEBUG_ACTIVE)
{
my $debug_name = get_debug_name();
if (defined $debug_name)
{
if ($indent <= 1)
{
ENV_say( $indent, "DBG: $debug_name", @lines_and_or_refs);
} else
{
ENV_say( $indent, @lines_and_or_refs);
}
$debug = 1;
}
}

return $debug;
}





sub ENV_print($@)
{
my ($indent,    # 0 = no prefix, 1 = $prefix, 2 = $prefix_ - Negative = prefix_level - 1
@lines_and_or_refs
) = @_;

ENV_sig( F => "Invalid indent ($indent)")
if ($indent !~ /^-?[012]$/);

map { my_print( N => $_) } format_lines( $indent, deref_lines( 0, \@lines_and_or_refs));
}






sub deref_lines($$)
{
my ($recurse_level,
$line_or_ref,
) = @_;
my @lines;

$recurse_level++;
my_die( "Max Recurse level exceeded ($recurse_level)")
if ($recurse_level > 20);

if (!defined $line_or_ref)
{
push @lines, '<undef>';
} elsif (ref $line_or_ref)	# REF
{
my $ref_type = ref $line_or_ref;
if ($ref_type eq 'SCALAR')
{
push @lines, deref_lines( $recurse_level, $$line_or_ref);
} elsif ($ref_type eq "ARRAY")
{
push @lines, map { deref_lines( $recurse_level, $_) } @{$line_or_ref};
} elsif ($ref_type eq "HASH")
{

push @lines, "HASH: $line_or_ref";
} else
{
push @lines, "$ref_type: $line_or_ref";
}
} else			# SCALAR
{
push @lines, $line_or_ref;
}

return @lines;
}




sub format_lines($@)
{
my ($indent,
@lines
) = @_;
my @formatted_lines;

ENV_get_term_size()
if (!defined $XTERM_WIDTH);

if ($indent == 0)
{
push @formatted_lines, ENV_split_lines( $XTERM_WIDTH, @lines);
} else
{
my $call_level = 1;
if ($indent < 0)
{
$call_level = 2;
$indent *= -1;
}


if ($indent == 1)
{
my $first_line = shift @lines;
my ($prefix, $prefix_) = ENV_get_prefix( $call_level);
my $text_length = $XTERM_WIDTH - length( $prefix) - 1;
my @lines = ENV_split_lines( $text_length, $first_line);
push @formatted_lines, "$prefix: $first_line";
}
if (@lines)
{
my $text_length = $XTERM_WIDTH - length( $MAIN_NAME_UC) - 1;
@lines = ENV_split_lines( $text_length, @lines);
my $indents = ($indent < 2) ? '' : '  ' x ($indent - 2);
push @formatted_lines, map { "$MAIN_NAME_UC_ $indents$_" } @lines;
}
}

return @formatted_lines;
}





sub ENV_get_prefix($)
{
my ($top_level,	    	    # > 0. 0 forces full prefix
) = @_;
my ($prefix, $prefix_);

if ($top_level == 0 || $DEBUG_ACTIVE && defined $DEBUG_NAMES{PREFIX})
{



my $prev_package = caller(0);	# Caller of ENV_print or ENV_say
my @packages;
my $at_end = 0;
for (my $i = 1; !$at_end; $i++)
{
my $this_package = caller( $i);
if (defined $this_package)
{
if ($this_package eq 'main')
{
unshift @packages, $MAIN_NAME_UC;
$at_end = 1;
} else
{

if ($this_package ne $prev_package || $this_package eq 'glo::env')
{
unshift @packages, $this_package;
$prev_package = $this_package;
}
}
} else
{
unshift @packages, "$MAIN_NAME_UC---";	# BEGIN- or END-block
$at_end = 1;
}
}

if ($top_level > 0)
{
for (my $i=1; $i < $top_level; $i++)
{
pop @packages;
}
}

foreach my $package (@packages)
{
$package =~ s/.*:://;
}
$prefix = uc join( '/', @packages);

$prefix_ = $MAIN_NAME_UC_;

} else
{



($prefix, $prefix_) = ($MAIN_NAME_UC, $MAIN_NAME_UC_);

}

return (wantarray) ? ($prefix, $prefix_) : $prefix;
}






sub ENV_sig($@)
{
my ($sig,		# <severity><action> IWEF  EC. undef or '' == just return, do nothing

@lines_or_refs
) = @_;

if (defined $sig && $sig ne '')
{
handle_sig( undef, $sig, \@lines_or_refs);
}
}









sub ENV_file_sig($$@)
{
my ($sig,		# <severity><action> IWEF  EC. undef or '' == just return, do nothing

$file_info_ref,	# [ $prefix, $src, $file, $line_nr, $line, $line2 ]
@lines_or_refs
) = @_;

if (defined $sig && $sig ne '')
{
my ($prefix, $src, $file, $line_nr, $line, $line2) = @{$file_info_ref};

my @lines;
if ($src)
{
if (defined $file && $file ne $src)
{
my $file_part = (defined $line_nr) ? "$file ($line_nr)" : $file;
push @lines, "File: $src";
push @lines, "Incl: $file_part";
} else
{
my $src_part = (defined $line_nr) ? "$src ($line_nr)" : $src;
push @lines, "File: $src_part";
}
}

if ($line)
{
if (defined $line_nr)
{
push @lines, sprintf( "%6d: %s", $line_nr, $line);
push @lines, sprintf( "%6s: %s", ' ',      $line2)
if (defined $line2);
} else
{
push @lines, "Line: $line";
push @lines, "    : $line2"
if (defined $line2);
}
}
push @lines, \@lines_or_refs;

handle_sig( $prefix, $sig, \@lines);
}
}




sub handle_sig($$$)
{
my ($prefix,
$sig,		# <severity><action> IWEF  EC.

$lines_ref,	# may be recurse
) = @_;

my ($severity, $action) = split( '', $sig);

$action = ($severity eq 'F') ? 'E' : 'C'
if ($action eq '');
my $sev = index( 'IWEF', $severity);
my $sig_text = qw( INFO WARNING ERROR INTERNAL-ERROR)[$sev];
$prefix = ENV_get_prefix( 1)
if (!defined $prefix);




{
my $err;
$err = "Invalid Signal Severity '$severity' ($sig)"
if (!defined $sig_text);
$err = "Invalid Signal Action '$action' ($sig)"
if (index( 'EC', $action) < 0);
if (defined $err)
{
my_say( F => 0, "$prefix: ** FATAL**",
"    $err");
my_say( F => 2, deref_lines( 0, $lines_ref));
my_say( F => 0, stackdump( 2));
exit 9;
}
}




my_say( $severity => 0, "$prefix: ** $sig_text **");
my_say( $severity => 2, deref_lines( 0, $lines_ref));




if ($sev > 0)	# WEF
{
$NR_BEEPS++;
${(undef, \$NR_WARNINGS, \$NR_ERRORS, \$NR_ERRORS)[$sev]}++;	# increment depending on severity
}





if ($action eq 'E')	    # Exit
{
my $exit_code = substr( '0129', $sev, 1);
if (defined $^S && $^S == 1)
{



if ($IS_IN_TRY)
{
die;	# Terminate the eval
} else
{
if ($severity eq 'F')
{
my_say( F => 0, stackdump( 2));
die;
} else
{
my_say( I => 0, stackdump( 2));	# DEBUG!
die;
}
}
} else
{
if ($severity eq 'F')
{
my_say( F => 0, stackdump( 2));
exit $exit_code;	    # 9
} else
{
ENV_exit( $exit_code);
}
}
} else  # $action == 'C'
{
my_say( F => 0, stackdump( 2))
if ($severity eq 'F');
}
}




sub ENV_try($$$)
{
my ($sig_on_error,	    # optional (undef). '', 'EE', etc. Default == 'F'
$func_or_ref,	    # func or [ func, @args ]
$result_ref,	    # result of func (void, SCALAR or ARRAY)
) = @_;
my ($is_ok, $nr_errors_suppressed, $nr_warnings_suppressed);



my $saved_nr_errors = $NR_ERRORS;
my $saved_nr_warnings = $NR_WARNINGS;
if (defined $result_ref)
{
if (ref $result_ref eq 'ARRAY')
{
@{$result_ref} = eval { ENV_call( $func_or_ref) };
} else
{
$$result_ref = eval { ENV_call( $func_or_ref) };
}
} else
{
$IS_IN_TRY = 1;
eval { ENV_call( $func_or_ref) };
$IS_IN_TRY = 0;
}
$is_ok = ($@ eq '') ? 1 : 0;	# $@ contains the possibly generated text of syntax-error(s) or die.

$nr_errors_suppressed = $NR_ERRORS - $saved_nr_errors;
$nr_warnings_suppressed = $NR_WARNINGS - $saved_nr_warnings;
$NR_ERRORS = $saved_nr_errors;
$NR_WARNINGS = $saved_nr_warnings;
$is_ok = 0
if (($nr_errors_suppressed + $nr_warnings_suppressed) > 0);

if (defined $sig_on_error && ($nr_errors_suppressed > 0 || !$is_ok))
{
ENV_sig( $sig_on_error => "$nr_errors_suppressed Application Errors suppresssed");
my_say( N => 0, "---",
"$@---")
if ($@ ne '');
}

return (wantarray) ? ($is_ok, $nr_errors_suppressed, $nr_warnings_suppressed, $@) : $is_ok ;
}




sub ENV_exit(;$)
{
my ($rc) = @_;

$rc = 0 if (!defined $rc);
$rc = 2 if ($rc < 2 && $NR_ERRORS > 0);
exit $rc;
}




sub ENV_get_nr_errors()
{
return $NR_ERRORS;
}




sub ENV_stackdump()
{
my_say( N => 0, stackdump( 1));
}




sub stackdump($)
{
my ($level,
) = @_;
my @lines;







my @call_info = caller( $level);
push @lines, "** at: @call_info[1..2]";
for (my $i = $level + 1; @call_info; $i++)
{
@call_info = caller( $i);
if (@call_info)
{
push @lines, "** called by: @call_info[1..3]";
}
}

return @lines;
}




sub ENV_is_debug(;$)
{
my ($debug_names_ref,	# optional. Default is caller's package name	    TBS!
) = @_;


if ($DEBUG_ACTIVE)
{
return (defined get_debug_name()) ? 1 : 0;
} else
{
return 0;
}
}




sub get_debug_name()
{
my $debug_name;		    # undef if debug not active for this context

if ($DEBUG_ALL)
{
$debug_name = 'ALL';
} else
{
my ($caller_package, undef) = caller( 1);
if ($caller_package eq 'main')
{
$debug_name = $MAIN_NAME_UC;
} else
{
my @caller_package = split( '::', $caller_package);
$debug_name = uc $caller_package[-1];
}
if (!exists $DEBUG_NAMES{$debug_name})
{
$debug_name = undef;
}
}


return $debug_name;
}




sub ENV_print_end_msg($)
{
my ($always) = @_;		# Bool

if (!$RUNNING_IN_EXEC)
{
my $rc = $?;

$rc = 1 if ($rc == 0 && $NR_ERRORS > 0);
$always = 1 if ($NR_WARNINGS > 0);
ENV_beep() if ($rc != 0);

if ($rc != 0 || $always)
{
my $text = "$MAIN_NAME_UC: ";

if ($rc == 0)
{
$text .= 'Done';
} else
{
$text .= "Failed (rc=$rc)";
}
if ($NR_ERRORS > 0 || $NR_WARNINGS > 0)
{
$text .= ' with ';
my @texts;
push @texts, "$NR_ERRORS error(s)" if ($NR_ERRORS > 0);
push @texts, "$NR_WARNINGS warning(s)" if ($NR_WARNINGS > 0);
$text .= join( ' and ', @texts);
}

ENV_reap_beeps();
ENV_say( 0, $text);
}
}
}




sub ENV_printable($)
{
my ($var,
) = @_;
my $text;

if (!defined $var)
{
$text = 'undef';
} else
{
my $reftype = ref $var;
if (!defined $reftype)
{
$text = "\"$var\"";
} elsif ($reftype eq 'ARRAY')
{
my @items = @{$var};
foreach my $item (@items)
{
if (!defined $item)
{
$item = 'undef';
} elsif (ref $item)
{
$item = 'REF ' . ref $item;
} else
{
$item = $var;
}
}
$text = '[' . join( ',', @items) . ']';
} elsif ($reftype eq 'HASH')
{
my @keys = keys %{$var};
$text = '{' . join( ',', @keys) . '}';
} else
{
$text = $reftype;
}
}
return $text;
}




sub ENV_clone($)
{
my ($this) = @_;

if (not ref $this)
{
$this;
} elsif (ref $this eq 'ARRAY')
{
[ map ENV_clone($_), @$this ];
} elsif (ref $this eq 'HASH')
{
scalar { map { $_ => ENV_clone($this->{$_}) } keys %$this };
} else
{
ENV_sig( F => "clone: What type is $this?");
}
}




sub ENV_get_package_keys($)
{
my ($package_name,	    # Without trailing ::
) = @_;
my @keys;		    # sorted

no strict "refs";			    ## no critic

@keys = sort( keys %{*{"${package_name}::"}});

return @keys;
}




sub ENV_dump($$;$$)
{
my ($name,
$item,		# undef, scalar or ref
$max_level,
$unsorted_hash,
) = @_;

my $prefix = ENV_get_prefix( 0);
my $line_nr = (caller(0))[2];
$prefix .= ":$line_nr";

my_say( N => 0, "---$prefix: $name");
$max_level = 100
if (!defined $max_level);
dump_item( 0, $max_level, $item, 1, $unsorted_hash);
my_say( N => 0, "---");
}




sub ENV_dump_package($$;$$)
{
my ($name,
$package_name,	    # Without trailing ::
$max_level,	    # may be undef. default = 100
$unsorted_hash,	    # bool.
) = @_;

$max_level = 100
if (!defined $max_level);

my $prefix = ENV_get_prefix( 0);
my $line_nr = (caller(0))[2];
$prefix .= ":$line_nr";

my_say( N => 0, "---$prefix: $name\::",
'->{');

no strict "refs";			    ## no critic

while (my ($key, $value) = each %{*{"${package_name}::"}})
{
if (defined *{"$package_name\::$key"}{SCALAR})
{
my_print( N => "    {$key}");
my $item = ${ *{"$package_name\::$key"}{SCALAR} };
dump_item( 1, $max_level, $item, 0, $unsorted_hash);    # recurse
}
if (defined *{"$package_name\::$key"}{ARRAY})
{
my_print( N => "    {$key}");
my $item_ref = [ @{ *{"$package_name\::$key"}{ARRAY} } ];
dump_item( 1, $max_level, $item_ref, 0, $unsorted_hash);    # recurse
}
if (defined *{"$package_name\::$key"}{HASH})
{
my_print( N => "    {$key}");
my $item_ref = { %{ *{"$package_name\::$key"}{HASH} } };
dump_item( 1, $max_level, $item_ref, 0, $unsorted_hash);    # recurse
}
}
my_say( N => 0, '  }',
'---');
}




sub dump_item($$$$$)
{
my ($level,
$max_level,
$item,
$must_indent,
$unsorted_hash,	    # bool.
) = @_;

my $indent = '  ' x $level;
$level++;
ENV_sig( F => "maxlevel reached") if ($level > 1000);

my_print( N => $indent)
if ($must_indent);
if ($level > $max_level)
{
my_say( N => 0, '***');
} else
{
if (defined $item)
{

if (ref $item)
{
if (ref $item eq 'SCALAR')
{
my $scalar = $$item;
$scalar = 'undef'
if (!defined $scalar);
my_say( N => 0, "->  '$scalar'");
} elsif (ref $item eq "ARRAY")
{
if (@{$item})
{
my_say( N => 0, '->[');
foreach my $value (@{$item})
{
dump_item( $level + 1, $max_level, $value, 1, $unsorted_hash);
}
my_say( N => 0, $indent . '  ]');
} else
{
my_say( N => 0, '->[]');
}
} elsif (ref $item eq "HASH")
{
if (keys %{$item})
{
my_say( N => 0, '->{');
if ($unsorted_hash)
{
while (my ($key, $value) = each %{$item})
{
my_print( N => $indent . "    {$key}");
dump_item( $level + 1, $max_level, $value, 0, $unsorted_hash);
}
} else
{
foreach my $key (sort(keys %{$item}))
{
my_print( N => $indent . "    {$key}");
dump_item( $level + 1, $max_level, $item->{$key}, 0, $unsorted_hash);
}
}
my_say( N => 0, $indent . "  }");
} else
{
my_say( N => 0, '->{}');
}
} else
{
my_say( N => 0, '->' . ref $item);
}
} else
{
my_print( N => '  ') if (!$must_indent);
my_say( N => 0, "'$item'");
}
} else
{
my_print( N => '=') if (!$must_indent);
my_say( N => 0, 'undef');
}
}
$level--;
}




sub ENV_dump_env(;$$)
{
my ($name,		    # Optional. Default ENV
$wildcard,	    # Optional
) = @_;

$name = 'ENV'
if (!defined $name);

my $prefix = ENV_get_prefix( 0);
my $line_nr = (caller(0))[2];
$prefix .= ":$line_nr";

my_say( N => 0, "---$prefix: $name:");

if (defined $wildcard)
{
my $wild_re = ENV_wild_2_re( $wildcard);
foreach my $key (sort keys %ENV)
{
my_say( N => 2, "$key = $ENV{$key}")
if ($key =~ $wild_re );
}
} else
{
map { my_say( N => 2, "$_ = $ENV{$_}") } sort keys %ENV;
}

my_say( N => 0, '---');
}






sub ENV_deref($)
{




if (wantarray)
{
if (defined $_[0])
{
if (ref $_[0])
{
return (ref $_[0] eq 'ARRAY') ? @{$_[0]} : (${$_[0]});	# ref ARRAY or ref SCALAR
} else
{
return ($_[0]);
}
} else
{
return ();
}
} else
{
if (defined $_[0])
{
if (ref $_[0])
{
return (ref $_[0] eq 'ARRAY') ? "@{$_[0]}" : ${$_[0]};	# ref ARRAY or ref SCALAR
} else
{
return $_[0];
}
} else
{
return '';
}
}
}




sub ENV_store($$)
{
my ($to_ref,
$from_ref,
) = @_;

if (ref $to_ref eq 'ARRAY')
{
@{$to_ref} = (ref $from_ref eq 'ARRAY') ? @{$from_ref} : ($from_ref);
} else
{
$$to_ref = (ref $from_ref eq 'ARRAY') ? $from_ref->[0] : $from_ref;
}

}






sub ENV_eval_empty($)
{

return (defined $_[0] && $_[0] ne '""' && $_[0] ne "''") ? $_[0] : '';
}






sub ENV_eval_undef($)
{

return (defined $_[0] && $_[0] ne '' && $_[0] ne '""' && $_[0] ne "''") ? $_[0] : undef;
}






sub ENV_undef2empty(@)
{



return (wantarray) ? map { (defined $_) ? $_ : '' } @_ : (defined $_[0]) ? $_[0] : '';
}




sub ENV_call($;$$)
{
my ($func_or_ref,	    # \&func or [ \&func, @func_args) ]
$first_args_ref,    # Optional
$last_args_ref,	    # Optional
) = @_;

my ($func, @func_args) = (ref $func_or_ref eq 'CODE') ? ($func_or_ref) : @{$func_or_ref};
my @first_args = (defined $first_args_ref) ? @{$first_args_ref} : ();
my @last_args = (defined $last_args_ref) ? @{$last_args_ref} : ();

return $func->( @first_args, @func_args, @last_args);
}







sub ENV_getenv($)
{

my $env = ENV_eval_empty( $ENV{$_[0]});

return (wantarray) ? split( ',', $env) : $env;
}







sub ENV_getenv_bool($)
{

my $env = ENV_eval_empty( $ENV{$_[0]});

return ($env =~ /^(1|Y|YES|ON|TRUE$)/i) ? 1 : 0;
}







sub ENV_getenv_perl_path($)
{
my ($name) = @_;
my $env;

$env = ENV_eval_empty( $ENV{$name});
if ($env ne '')
{

$env = ENV_perl_paths_noquotes( $env)
if ($IS_WIN32);

}

return $env;
}




sub ENV_setenv($$)
{
my ($name,
$value_or_ref,	    # if ref then values will be joined with ','
) = @_;
my $value;

if (ref $value_or_ref)
{
$value = join ',', @{$value_or_ref};
} else
{
$value = $value_or_ref;
}

ENV_sig( F => "ENV_setenv: Invalid item <undef> = $value")
if (!defined $name);

if (defined $value)
{
$value = '""'
if ($value eq '');
$ENV{$name} = $value;
$value = ''
if ($value eq '""');

} else
{
$ENV{$name} = $value;

}

return $value;
}





sub ENV_setenv_os_path($$)
{
my ($name,
$value_or_ref
) = @_;
my $value = (ref $value_or_ref) ? join( ',', @{$value_or_ref}) : $value_or_ref;

$value =~ tr!/!\\!
if ($IS_WIN32);

return ENV_setenv( $name => $value);
}




sub ENV_get_changed_envs()
{
my @changed_env_refs;	    # ( [ $name, $value ], ... )

my %old_envs = @SAVED_ENVS;

while (my ($cur_name, $cur_value) = each (%ENV))
{
if (defined $cur_value)
{
my $old_value = $old_envs{$cur_name};
if (defined $old_value)
{
if ($cur_value ne $old_value)
{



push @changed_env_refs, [ $cur_name, $cur_value ];
}
} else
{



push @changed_env_refs, [ $cur_name, $cur_value ];
}
delete $old_envs{$cur_name};
} else
{
push @changed_env_refs, [ $cur_name, undef ];
}
}




push @changed_env_refs, map { [ $_, undef ] } keys %old_envs;


return @changed_env_refs;
}




sub ENV_get_delta_envs($)
{
my ($new_env_pairs,	    # ( [ $name, $value ], ... )
) = @_;
my @delta_env_refs;	    # ( [ $name, $value ], ... )




my %old_envs = %ENV;

foreach my $ref (@{$new_env_pairs})
{
my ($new_name, $new_value) = @{$ref};
my $old_value = $old_envs{$new_name};
if (defined $old_value)
{
if ($new_value ne $old_value)
{
push @delta_env_refs, [ $new_name, $new_value ];
}
} else
{
push @delta_env_refs, [ $new_name, $new_value ];
}
delete $old_envs{$new_name};
}

push @delta_env_refs, map { [ $_, undef ] } keys %old_envs;


return @delta_env_refs;
}





sub ENV_command_filespec($)
{
my ($spec) = @_;

$spec .= ENV_shell_filetype();
$spec =~ tr!/!\\!
if ($IS_WIN32);

return $spec;	# os format
}





sub ENV_command_types()
{
if (!@COMMAND_TYPES)
{
if ($IS_WIN32)
{
my $pathext = lc $ENV{PATHEXT};
my @pathext = ($pathext) ? ENV_split_path( $pathext) : qw( .com .exe .bat .cmd );
@COMMAND_TYPES = ( @pathext );
} else
{
@COMMAND_TYPES = ( '', qw( .sh .e ) );
}
}

return @COMMAND_TYPES;
}




sub ENV_is_command_type($)
{
my ($type,
) = @_;

$type = lc $type
if ($IS_WIN32);
ENV_command_types()
if (!@COMMAND_TYPES);

return (grep( $type eq $_, @COMMAND_TYPES)) ? 1 : 0;
}






sub ENV_shell_filetype()
{
return (wantarray) ? @SHELL_FILETYPES : $SHELL_FILETYPES[0];
}




sub ENV_is_shell_file($)
{
my ($file) = @_;	    # file or filespec

my ($type) = $file =~ /(\.*)/;		# greedy!

return ($type eq '.bat' || $type eq '.sh') ? 1 : 0;
}






sub ENV_chmod($@)
{
my ($symbolic,	# ugoa +-= rwx e.g.:  'ugo-wx'
@files
) = @_;
my $count = 0;

my %bits = ( u => 0, g => 1, o => 2,
r => 4, w => 2, x => 1 );

my ($who, $op, $perms) = $symbolic =~ /^([ugoa]+)([+-=])([rwx]+)$/;
ENV_sig( F => "chmod: Invalid symbolic '$symbolic'") if (!defined $who);
$who = 'ugo' if ($who =~ /a/);

my @ugos;
map { push @ugos, $bits{$_} } split //, $who;

my $value = 0;
map { $value |= $bits{$_} } split //, $perms;

foreach my $file (@files)
{
my $org_mode = (stat $file)[2];
if (!defined $org_mode)
{
ENV_sig( E => "chmod $symbolic: No such file/dir: $file");
next;
}
my @values = (($org_mode & oct(700)) >> 6, ($org_mode & oct(70)) >> 3, $org_mode & oct(7));

if ($op eq '+')
{
map { $values[$_] |=  $value } @ugos;
} elsif ($op eq '-')
{
map { $values[$_] &= ~$value } @ugos;
} else	# ($op eq '=')
{
map { $values[$_]  = $value } @ugos;
}
my $mode = ($values[0] << 6) | ($values[1] << 3) | $values[2];
my $new_mode = $org_mode & ~oct(777) | $mode;
if ($new_mode != $org_mode)
{

$count += chmod $new_mode, $file;
} else
{
$count++;
}
}

return $count;
}





sub ENV_get_hostname()
{
return OS_get_hostname();
}





sub ENV_uname()
{
return OS_get_uname();
}





sub ENV_unique_id()
{
my $unique_id;

my $hostname = ENV_get_hostname();
my $time = time;

$unique_id = "${hostname}_${time}_${$}_${UNIQUE_COUNT}";
$UNIQUE_COUNT++;


return $unique_id;
}





sub ENV_get_userid()
{
return OS_get_userid();
}





sub ENV_is_wildcard($)
{

return ($_[0] =~ /[*?]/) ? 1 : 0;
}





sub ENV_glob(@)
{

my @specs = map { glob $_ } @_;

return (wantarray) ? @specs : $specs[0];	    # undef if scalar context and empty
}





sub ENV_glob_files(@)
{

my @files;

@files = map { $_ =~ m!.*/(.*)! } map { glob $_ } @_;

return (wantarray) ? @files : $files[0];
}




sub ENV_wild_2_re(@)
{

my @reg_exps;

foreach my $wildcard (@_)
{
my $re = quotemeta $wildcard;
$re =~ s/\\\*/.*/g;
$re =~ s/\\\?/./g;
$re = "^$re\$";
push @reg_exps, $re;
}

return (wantarray) ? @reg_exps : $reg_exps[0];
}









sub ENV_wildcard($$)
{
my ($find,		# this is the wildcard
$list_ref,	# single or ref-list
) = @_;
my @found_items;

$list_ref = [$list_ref] unless( ref $list_ref);

if ($find eq '*')
{
@found_items = @{$list_ref};
} else
{
my $find_re = ENV_wild_2_re( $find);
@found_items = grep( /$find_re/, @{$list_ref});
}


return (wantarray) ? @found_items : $found_items[0];
}








sub ENV_wildcards($$$)
{
my ($finds_ref,	    # this is the wildcards list
$list_ref,	    # single or ref-list
$no_matches_ref,    # may be undef
) = @_;
my @found_items;

$finds_ref = [$finds_ref] unless( ref $finds_ref);
$list_ref = [$list_ref] unless( ref $list_ref);

my %dups;


foreach my $find (@{$finds_ref})
{
my $find_re = ENV_wild_2_re( $find);
my @these_found_items = grep( /$find_re/, @{$list_ref});
if (@these_found_items)
{
foreach my $found_item (@these_found_items)
{
if (!defined $dups{$found_item})
{
push @found_items, $found_item;
$dups{$found_item} = 1;
}
}
} else
{
push @{$no_matches_ref}, $find
if (defined $no_matches_ref);
}
}


return @found_items;
}








sub ENV_not_wildcards($$)
{
my ($finds_ref,	# this are the wildcards
$list_ref,	# single or ref
) = @_;
my @found_items;

$list_ref = [$list_ref] unless( ref $list_ref);
if (ref $finds_ref)
{
my @find_res = ENV_wild_2_re( @{$finds_ref});
foreach my $item (@{$list_ref})
{
my $found = 0;
foreach my $find_re (@find_res)
{
if ($item =~ $find_re)
{
$found = 1;
last;
}
}
push @found_items, $item
if (!$found);
}
} else
{
if ($finds_ref eq '*')
{
@found_items = ();
} else
{
my $find_re = ENV_wild_2_re( $finds_ref);
@found_items = grep( !/$find_re/, @$list_ref);
}
}

return @found_items;
}








sub ENV_get_term_size()
{
if (!defined $XTERM_WIDTH)
{
if (-t STDOUT)
{
($XTERM_WIDTH, $XTERM_HEIGHT) = OS_get_terminal_size();
}
$XTERM_WIDTH = $XTERM_DEFAULT_WIDTH
if (!defined $XTERM_WIDTH);
$XTERM_WIDTH--;    				# half characters may cause empty lines
$XTERM_HEIGHT = $XTERM_DEFAULT_HEIGHT
if (!defined $XTERM_HEIGHT);

}

return (wantarray) ? ($XTERM_WIDTH, $XTERM_HEIGHT) : $XTERM_WIDTH;
}







sub ENV_get_term_size_default()
{
return (wantarray) ? ($XTERM_DEFAULT_WIDTH, $XTERM_DEFAULT_HEIGHT) : $XTERM_DEFAULT_WIDTH;
}




sub ENV_set_background_term_size()
{
ENV_get_term_size();

$XTERM_WIDTH = $XTERM_BACKGROUND_WIDTH;

return (wantarray) ? ($XTERM_WIDTH, $XTERM_HEIGHT) : $XTERM_WIDTH;
}




sub ENV_is_abs_path($)
{
my ($path) = @_;



if ($IS_WIN32)
{
return $path =~ m!^"?([A-Za-z]:(/|\\)|//.+|\\\\.+)!;
} else
{
return $path =~ m!^"?(/|~/)!;
}
}




sub ENV_is_abs_path_perl($)
{
my ($path) = @_;



if ($IS_WIN32)
{
return $path =~ m!^(//.+|[A-Za-z]:/)!;
} else
{
return $path =~ m!^(/|~/)!;
}
}




sub ENV_is_option($)
{
my ($spec) = @_;

my $fc = substr( $spec, 0, 1);
if ($IS_WIN32)
{
return ($fc eq '-' || $fc eq '/');
} else
{
return ($fc eq '-');
}
}




sub ENV_is_in_path($$)
{
my ($path,			# perl path
$starts_with_path,	# perl path
) = @_;

$starts_with_path = quotemeta $starts_with_path;

return ( $path =~ m!^$starts_with_path($|/)! ) ? 1 : 0;
}




sub ENV_chop_path($$)
{
my ($path,			# perl path
$leading_path,		# perl path
) = @_;
my $relative_path;

$leading_path = quotemeta $leading_path;
$relative_path = $path;
$relative_path =~ s!^$leading_path($|/)!!;

return $relative_path;
}




sub ENV_parent_path($)
{
my ($path) = @_;
my $parent_path;

$parent_path = $path;
$parent_path =~ s!/[^/]+$!!;
$parent_path = ''
if ($parent_path eq $path);


return $parent_path;
}




sub ENV_parent_dir($$)
{
my ($path,
$index	    # -1 == last, 0 == first
) = @_;
my $parent_name;

my @dirs = split( '/', $path);
$parent_name = $dirs[$index];
$parent_name = '' if (!defined $parent_name);


return $parent_name;
}




sub ENV_set_tmpdir_path($)
{
my ($tmpdir_path) = @_;		    # undef: restore to OS tmp path
my $old_tmpdir_path = $TMPDIR_PATH;

$TMPDIR_PATH = $tmpdir_path;
if (defined $tmpdir_path)
{
ENV_setenv( "${APP_NAME}_TMPDIR_PATH" => $tmpdir_path);		    # used only by this package

} else
{
ENV_setenv( "${APP_NAME}_TMPDIR_PATH" => '');			    # used only by this package
}

return $old_tmpdir_path;
}




sub ENV_get_tmpdir_path()
{
if (!defined $TMPDIR_PATH)
{
my $tmpdir_path = ENV_getenv_perl_path( "${APP_NAME}_TMPDIR_PATH"); # used only by this package
$tmpdir_path = ENV_get_os_tmpdir_path()
if ($tmpdir_path eq '');
$TMPDIR_PATH = $tmpdir_path;
}

if (-d $TMPDIR_PATH)
{

return $TMPDIR_PATH;
} else
{
ENV_sig( I => 'Unknown path:', "- $TMPDIR_PATH", 'Reverting to OS_TMPDIR_PATH');
return ENV_get_os_tmpdir_path();
}
}




sub ENV_get_os_tmpdir_path()
{
if (!defined $OS_TMPDIR_PATH)
{
my @tmp_envs = ($IS_WIN32) ? qw(TEMP TMP TMPDIR) : qw(TMPDIR);
my $tmpdir_path;
foreach my $tmp_env (@tmp_envs)
{
my $test_path = ENV_getenv_perl_path( $tmp_env);
$test_path = ENV_perl_paths_long( $test_path);
if (-e $test_path)
{
$tmpdir_path = $test_path;
last;
}
}
if (!defined $tmpdir_path)
{
if ($IS_LINUX)
{
$tmpdir_path = "$ENV{HOME}/tmp";
mkdir $tmpdir_path;
ENV_setenv( TMPDIR => $tmpdir_path);
} else
{
ENV_sig( EE => "No valid Temp. directory found in (@tmp_envs)");
}
}
$OS_TMPDIR_PATH = $tmpdir_path;
}

return $OS_TMPDIR_PATH;
}




sub ENV_get_tmp_spec($)
{
my ($file) = @_;
my $spec;

my $temp_path = ENV_get_tmpdir_path();

my $dotloc = rindex( $file, '.');
my $name;
my $type;
if ($dotloc == 0)	    # starts with '.'
{
$name = "";
$type = $file;
} elsif ($dotloc > 0)   # has '.'
{
$name = substr( $file, 0, $dotloc);
$type = substr( $file, $dotloc);
} else  	    	    # no '.'
{
$name = $file;
$type = '.tmp';
}

my $unique_id = ENV_unique_id();

$spec = "$temp_path/${name}_${unique_id}$type";


return $spec;
}




sub ENV_get_tmp_path($)
{
my ($dir) = @_;
my $path;

my $temp_path = ENV_get_tmpdir_path();
my $unique_id = ENV_unique_id();
$path = "$temp_path/${dir}_${unique_id}";


return $path;
}




sub ENV_os_paths(@)
{
my @paths = @_;	# Perl path

if ($IS_WIN32)
{
foreach my $path (@paths)
{
$path =~ tr!/!\\!;		    # os path
}
}

return (wantarray) ? @paths : $paths[0];
}




sub ENV_perl_paths(@)
{
my @paths = @_;


foreach my $path (@paths)
{
$path =~ tr!\\!/!;	    # perl path

}

return (wantarray) ? @paths : $paths[0];
}





sub ENV_perl_canon_paths(@)
{
my @paths = @_;
my @perl_paths;

@perl_paths = ENV_perl_paths( ENV_canonicalize_paths( @paths));

return (wantarray) ? @perl_paths : $perl_paths[0];
}





sub ENV_perl_paths_noquotes(@)
{
my @paths = @_;
my @perl_paths;

foreach my $path (@paths)
{
ENV_sig( F => "Path '$path'", "- contains '$PATH_SEPARATOR'")    # ';' or ':'
if ($path =~ /$PATH_SEPARATOR/);

if (substr( $path, 0, 1) eq '"')
{



$path =~ s/"//g;
}
my $perl_path;
if ($IS_WIN32)
{

$perl_path = $path
if (!defined $perl_path);
$perl_path =~ tr!\\!/!;	    # perl path
} else
{
$perl_path = $path;
}
$perl_path = ENV_canonicalize_paths( $perl_path);
push @perl_paths, $perl_path;
}

return (wantarray) ? @perl_paths : $perl_paths[0];
}





sub ENV_perl_paths_long(@)
{
my @paths = @_;
my @perl_paths;

push @perl_paths, map { OS_long_path_name( $_) } @paths;

return (wantarray) ? @perl_paths : $perl_paths[0];
}





sub ENV_canonicalize_paths(@)
{
my (@filespecs) = @_;	# Perl path!

foreach my $filespec (@filespecs)
{





my $device;
my $dir_file;
if ($filespec =~ m!^(/+)(.*)!)
{



$device = $1;
$dir_file = $2;
} elsif ($filespec =~ m!^([a-zA-Z]:/?)(.*)!)
{



$device = ucfirst $1;
$dir_file = $2;
} else
{



$device = '';
$dir_file = $filespec;
}



$dir_file =~ s!/+!/!g;				    # xx////yy	 -> xx/yy
$dir_file =~ s!(/\.)+/!/!g; 			    # xx/././yy  -> xx/yy
while ($dir_file =~ s!/[^/]+/\.\.(/|$)!/!) {};	    # /xx/yy/../ -> /xx
$dir_file =~ s!/\.$!!;				    # xx/.	 -> xx
$dir_file =~ s!/$!!;				    # xx/	 -> xx

$filespec = "$device$dir_file";


}

return (wantarray) ? @filespecs : $filespecs[0];
}

my @PATH;  	    	# do not initialize!	from EnvVar PATH
my %SAVED_WHICH_COMMANDS;





sub ENV_which($$)
{
my ($command,
$sig_on_error,		    # undef, '', 'EE', 'F', etc
) = @_;
my $filespec;		    # undef if not found

$filespec = $SAVED_WHICH_COMMANDS{ $command};
if (!defined $filespec)
{
if (ENV_is_abs_path( $command))
{
$filespec = match_type( $command);
ENV_sig( $sig_on_error => "'$command' Not found")
if (!defined $filespec);
} else
{
my $cwd = ENV_cwd();
if ($command =~ m!/!)
{
$filespec = match_type( "$cwd/$command");
ENV_sig( $sig_on_error => "'$command' not found in CWD ($cwd)")
if (!defined $filespec);
} else
{
if (!@PATH)
{
foreach my $path (split( ($IS_WIN32) ? ';' : ':', $ENV{PATH}))
{
next if ($path eq '');
if (ENV_is_abs_path( $path))
{
if (-e $path)
{
if (-d $path)
{
push @PATH, ENV_perl_paths_noquotes( "\"$path\"");
} else
{
ENV_sig( W => "PATH contains non-Directory entry: '$path' - Skipped");
}
} else
{
ENV_sig( W => "PATH contains non-Existing entry: '$path' - Skipped");
}
} else
{
ENV_sig( W => "PATH contains non-AbsPath entry: '$path' - Skipped");
}
}
}

foreach my $dir_spec (@PATH)
{

my $this_dir_spec = (ENV_is_abs_path( $dir_spec)) ? $dir_spec : "$cwd/$dir_spec";
$filespec = match_type( "$this_dir_spec/$command");
last if (defined $filespec);
}
if (!defined $filespec)
{
my @command_types = ENV_command_types();
ENV_sig( $sig_on_error => "'$command' (@command_types) not found in PATH:", @PATH);
}
}
}
if (defined $filespec)
{
$filespec = ENV_canonicalize_paths( $filespec);
$SAVED_WHICH_COMMANDS{$command} = $filespec;	# save it
}
}

return $filespec;
}




sub ENV_which_path($@)
{
my ($command,
@paths,		    # abs paths
) = @_;
my $filespec;	    # undef if not found

foreach my $dir_spec (@paths)
{

$filespec = match_type( "$dir_spec/$command");
last if (defined $filespec);
}

return $filespec;
}




sub match_type($)
{
my ($filespec) = @_;
my $full_filespec;     # undef = not found

foreach my $type (ENV_command_types())
{
my $ffs = "$filespec$type";
if (-f $ffs)
{
$full_filespec = $ffs;
last;
}
}

return $full_filespec;
}





sub ENV_paths_equal($$)
{
my ($l_path,
$r_path,
) = @_;
my $are_equal = 0;

if ($IS_WIN32)
{
if (lc $l_path eq lc $r_path)
{
my @l_stat = stat $l_path;
my @r_stat = stat $r_path;
$are_equal = 1
if ("@l_stat" eq "@r_stat");
}
} else
{
$are_equal = 1
if ($l_path eq $r_path);
}

return $are_equal;
}






sub ENV_expand_envs($)
{
my ($line) = @_;





$line =~ s/\$(\w+)/$ENV{$1} ? $ENV{$1} : "\$$1"/eg;





$line =~ s/\$\{([^\}]+)\}/$ENV{$1} ? $ENV{$1} : "\${$1}"/eg;


if ($IS_WIN32)
{





$line =~ s/\%(\w+)\%/$ENV{$1} ? $ENV{$1} : "%$1%"/eg;
} else
{




$line = ENV_glob( $line)
if (substr( $line, 0, 1) eq '~');
}


return $line;
}





sub ENV_expand_arg($)
{
my ($arg) = @_;
my $args;

$args = "\\\$$arg\(\\W|\$)|\\\$\\\{$arg\\\}";
$args .= "|\\\%$arg\\\%"
if ($IS_WIN32);

return qr($args);
}





sub ENV_delink_spec($)
{
my ($spec) = @_;
my $new_spec;


$new_spec = $spec;
if ($IS_LINUX)
{
my $link_replaced;
my $count = 0;
my @spec = split '/', $spec;
do
{
$count++;
ENV_sig( EE => "More than $count nested links in '$spec'") if ($count > 10);
$link_replaced = 0;
my @new_spec;
while (@spec)
{
my $part = shift @spec;

my $part_spec = join( '/', @new_spec, $part);

if (-l $part_spec)
{
my $link = readlink $part_spec;
if (substr( $link, 0, 1) eq '/')
{
@new_spec = ($link);
} else
{
push @new_spec, $link;
}
$link_replaced = 1;
} else
{
push @new_spec, $part
}
}
if ($link_replaced)
{
$new_spec = join( '/', @new_spec);

$new_spec = ENV_canonicalize_paths( $new_spec);

@spec = split '/', $new_spec;
}
} while ($link_replaced);
}

return $new_spec;
}




sub ENV_rel_spec($$)
{
my ($from_path,	# Absolute
$to_file	# Absolute
) = @_;
my $result;



my @from_path = split '/', $from_path;
my @to_file = split '/', $to_file;
my $org_nr_from = @from_path;
$org_nr_from -= 1 if (substr( $from_path, 0, 1) eq '/');

if ($from_path[0] eq $to_file[0])
{
while (@from_path && ($from_path[0] eq $to_file[0]))
{
shift @from_path;
shift @to_file;
}
my $nr_from = scalar @from_path;

if ($nr_from < $org_nr_from)
{
$result = '../' x $nr_from . join( '/', @to_file);
} else
{
$result = $to_file;
}
} else
{
$result = $to_file;
}


return $result;
}




sub ENV_abs_paths($$)
{
my ($cwd,
$paths_ref	    # ref or scalar
) = @_;
my @paths;

$paths_ref = [ $paths_ref ] if (!ref $paths_ref);

$cwd = ENV_cwd() if (!defined $cwd || $cwd eq '.');


foreach my $path (@{$paths_ref})
{

if (ENV_is_abs_path_perl( $path))
{
push @paths, $path;
} else
{
push @paths, ENV_canonicalize_paths( "$cwd/$path");
}
}


return (wantarray) ? @paths : $paths[0];
}




sub ENV_rel_paths($$)
{
my ($cwd,
$paths_ref	    # ref or scalar
) = @_;
my @paths;

$paths_ref = [ $paths_ref ] if (!ref $paths_ref);

$cwd = ENV_cwd() if (!$cwd || $cwd eq '.');


foreach my $path (@{$paths_ref})
{

if (ENV_is_abs_path_perl( $path))
{
push @paths, ENV_rel_spec( $cwd, $path);
} else
{
push @paths, $path;
}
}

return (wantarray) ? @paths : $paths[0];
}




sub ENV_strip_path($$)
{
my ($path_to_strip,
$full_paths_ref	    # ref or scalar
) = @_;
my @rel_paths;

$full_paths_ref = [ $full_paths_ref ] if (!ref $full_paths_ref);

my $path_to_strip_l = length $path_to_strip;
foreach my $path (@{$full_paths_ref})
{
my $rel_path = (length $path == $path_to_strip_l) ? $path : substr( $path, $path_to_strip_l + 1);
push @rel_paths, $rel_path;
}


return (wantarray) ? @rel_paths : $rel_paths[0];
}




sub ENV_shortest_paths($$)
{
my ($cwd,
$paths_ref	    # ref or scalar
) = @_;
my @paths;

$paths_ref = [ $paths_ref ] if (!ref $paths_ref);

$cwd = ENV_cwd() if (!$cwd || $cwd eq '.');


foreach my $path (@{$paths_ref})
{

my $abs_path;
my $rel_path;
if (ENV_is_abs_path_perl( $path))
{
$abs_path = $path;
$rel_path = ENV_rel_spec( $cwd, $path);
} else
{
$abs_path = ENV_canonicalize_paths( "$cwd/$path");
$rel_path = $path;
}
if (length( $abs_path) < length( $rel_path))
{
push @paths, $abs_path;
} else
{
push @paths, $rel_path;
}
}


return (wantarray) ? @paths : $paths[0];
}






sub ENV_split_spec_pnt($)
{
my ($filespec) = @_;
my ($dir_path, $name, $type);

my $i = rindex( $filespec, '/');
my $file;
if ($i >= 0)
{
$dir_path = substr( $filespec, 0, $i);
$file = substr( $filespec, $i + 1);
} else
{
$dir_path = '';
$file = $filespec;
}

$i = rindex ($file, '.');
if ($i >= 0)
{
$name = substr( $file, 0, $i);
$type = substr( $file, $i);
} else
{
$name = $file;
$type = '';
}


return ($dir_path, $name, $type);
}






sub ENV_split_spec_pf($)
{
my ($filespec) = @_;
my ($dir_path, $file);

my $i = rindex( $filespec, '/');
if ($i >= 0)
{
$dir_path = substr( $filespec, 0, $i);
$file = substr( $filespec, $i + 1);
} else
{
$dir_path = '';
$file = $filespec;
}


return ($dir_path, $file);
}






sub ENV_split_spec_p($)
{
my ($filespec) = @_;
my $dir_path = '';

my $i = rindex( $filespec, '/');
$dir_path = substr( $filespec, 0, $i) if ($i >= 0);


return $dir_path;
}






sub ENV_split_spec_f($)
{
my ($filespec) = @_;
my $file;

my $i = rindex( $filespec, '/');
if ($i >= 0)
{
$file = substr( $filespec, $i + 1) ;
} else
{
$file = $filespec;
}


return $file;
}






sub ENV_split_spec_nt($)
{
my ($filespec) = @_;
my ($name, $type);

my $i = rindex( $filespec, '/');
$filespec = substr( $filespec, $i + 1) if ($i >= 0);
$i = rindex( $filespec, '.');
if ($i >= 0)
{
$name = substr( $filespec, 0, $i);
$type = substr( $filespec, $i);
} else
{
$name = $filespec;
$type = '';
}

return ($name, $type);
}






sub ENV_split_spec_n($)
{
my ($filespec) = @_;
my $name;

my $i = rindex( $filespec, '/');
$filespec = substr( $filespec, $i + 1) if ($i >= 0);

$i = rindex( $filespec, '.');
if ($i >= 0)
{
$name = substr( $filespec, 0, $i);
} else
{
$name = $filespec;
}
return $name;
}






sub ENV_split_spec_t($)
{
my ($filespec) = @_;
my $type = '';

ENV_stackdump()
if (!defined $filespec);
my $i = rindex( $filespec, '/');
$filespec = substr( $filespec, $i + 1) if ($i >= 0);

$i = rindex( $filespec, '.');
$type = substr( $filespec, $i) if ($i >= 0);

return $type;
}





sub ENV_split_path($)
{
my ($path) = @_;


return split( $PATH_SEPARATOR, $path);
}





sub ENV_join_path($)
{
my ($path_ref) = @_;


return join( $PATH_SEPARATOR, @{$path_ref});
}





sub ENV_chdir($)
{
my ($path) = @_;

chdir( $path) || ENV_sig( F => "Unable to chdir( $path)", "- $!");
$ENV{PWD} = $path;

return $path;
}





sub ENV_cwd()
{
my $pwd = OS_get_cwd();

$ENV{PWD} = $pwd;

return $pwd;
}

{
my @PUSHD_STACK;




sub ENV_pushd($)
{
my ($path) = @_;	    # if undef: do not cddir to $path

push @PUSHD_STACK, OS_get_cwd();

if (defined $path)
{
ENV_stackdump() if ($path eq '');	# chdir( '') is deprecated
chdir( $path) || ENV_sig( F => "Unable to chdir( $path) in pushd", "- $!");
$ENV{PWD} = $path;
}

return $path;
}





sub ENV_popd()
{
ENV_sig( F => 'PUSHD-stack exhaused')
if (@PUSHD_STACK == 0);

my $path = pop @PUSHD_STACK;

chdir( $path) || ENV_sig( F => "Unable to chdir( $path) in popd", "- $!");
$ENV{PWD} = $path;

return $path;
}
}







sub ENV_file_is_newer($$)
{
my ($file1,
$file2,
) = @_;
my $is_newer;

no integer;
my $dmtp1 = -M $file1;	    # date modified to present
if (defined $dmtp1)
{
my $dmtp2 = -M $file2;


if (defined $dmtp2)
{
$is_newer = ($dmtp1 < $dmtp2) ? 1 : 0;		# produce printable result
} else
{
$is_newer = 1;
}
} else
{
$is_newer = 0;
}
use integer;

return $is_newer;
}






sub ENV_file_is_same($$)
{
my ($file1,
$file2,
) = @_;
my $is_same = 0;

no integer;
my $dmtp1 = -M $file1;	    # date modified to present
if (defined $dmtp1)
{
my $size1 = -s _;
my $dmtp2 = -M $file2;

if (defined $dmtp2)
{
my $size2 = -s _;

$is_same = ($dmtp1 == $dmtp2 && $size1 == $size2) ? 1 : 0;	# produce prinatble result
}
}
use integer;

return $is_same;
}





sub ENV_mkdir($;$$)
{
my ($path,
$mask,		    # may be undef, ugo=rwx. default is 0777
$sig_on_error,	    # opt. '', 'EE', etc. Default == 'EE'
) = @_;
my $created = 0;

$mask = oct(777)
if (!$mask);	    # ugo=rwx

$sig_on_error = 'EE'
if (!defined $sig_on_error);

if (!mkdir( $path, $mask))
{




my $errno_text = $!;
if (!-d $path)
{
my $omask = sprintf( "0%o", $mask);
ENV_sig( $sig_on_error => "Unable to mkdir '$path' ($omask)", "- $errno_text");
}
}

if (-d $path)
{
$created = 1;
} else
{
ENV_sig( $sig_on_error => "Failed to mkdir '$path' for unclear reason");
}


return $created;
}





sub ENV_mkpath($;$$)
{
my ($full_path,
$mode,		    # undef = OK
$sig_on_error,	    # opt. '', 'EE', etc. Default == 'EE'
) = @_;
my $created_count = 0;

if (!-d $full_path)
{
my @dirs = split( '/', $full_path);
my $path = shift @dirs;
foreach my $dir (@dirs)
{
$path = "$path/$dir";
$created_count += ENV_mkdir( $path, $mode, $sig_on_error)
if (! -d $path);
}
}


return $created_count;
}




sub ENV_rmdir($;$$)
{
my ($path,
$force,		    # opt. bool
$sig_on_error,	    # opt. '', 'EE', etc. Default == 'F'
) = @_;
my $deleted = 0;

$deleted = rmdir $path;
if (!$deleted)
{
if (defined $force && $force)
{
chmod oct(777), $path;	# ugo+rwx
$deleted = rmdir $path;
}
if (!$deleted)
{
$sig_on_error = 'F'
if (!defined $sig_on_error);
ENV_sig( $sig_on_error => "Unable to rmdir( $path)",
"- $!");
}
}


return $deleted;
}






sub ENV_rmtree($$;$$)
{
my ($top_path,	    # must exist
$also_remove_top,   # bool
$force,		    # opt. bool
$sig_on_error,	    # opt. '', 'EE', etc. Default == 'F'
) = @_;
my $deleted = 1;

chmod oct(777), $top_path;	# ugo+rwx
foreach my $dir_entry (ENV_readdir( $top_path, 1, $sig_on_error))	    # 1 = $include_dot_files
{
my $entry_spec = "$top_path/$dir_entry";
if (-d $entry_spec)
{
if (-l $entry_spec)    # do not follow symbolic links
{
$deleted = ENV_rmdir( $entry_spec, $force, $sig_on_error)
} else
{
$deleted = ENV_rmtree( $entry_spec, 1, $force, $sig_on_error);
}
} else	# -f
{
$deleted = ENV_unlink( $entry_spec, $force, $sig_on_error);
}
last
if (!$deleted);
}

$deleted = ENV_rmdir( $top_path, $force, $sig_on_error)
if ($deleted && $also_remove_top);


return $deleted;
}







sub ENV_readdir($$;$)
{
my ($path,
$include_dot_files, # Bool: Files starting with '.' but not '.' and '..'
$sig_on_error,	    # opt. '', 'EE', etc. Default == 'F'
) = @_;
my @all_entries;

if (opendir( my $dir_fh, $path))
{
if ($include_dot_files)
{
@all_entries = grep( ! /^\.\.?$/, readdir ($dir_fh));	# skip . and ..
} else
{
@all_entries = grep( ! /^\./, readdir( $dir_fh));		# Skip all files startiing with .
}
closedir $dir_fh;
} else
{
$sig_on_error = 'F'
if (!defined $sig_on_error);
ENV_sig( $sig_on_error => "Unable to opendir '$path'", "- $!");
}


return @all_entries;
}





sub ENV_rename($$;$)
{
my ($oldname,
$newname,
$sig_on_error,	    # opt. '', 'EE', etc. Default == 'F'
) = @_;
my $renamed = 0;

if (rename( $oldname, $newname))
{
$renamed = 1;
} else
{
$sig_on_error = 'F'
if (!defined $sig_on_error);
ENV_sig( $sig_on_error => "Unable to rename '$oldname'",
"              -> '$newname'",
"- $!");
}


return $renamed;
}




sub ENV_dir_count($;$)
{
my ($path,
$sig_on_error,	    # opt. '', 'EE', etc. Default == 'F'
) = @_;
my $nr_of_entries;	    # undef if path could not be read

if (opendir( my $dir_fh, $path))
{
$nr_of_entries = grep( ! /^\.\.?$/, readdir $dir_fh); # skip . and ..
closedir $dir_fh;
} else
{
$sig_on_error = 'F'
if (!defined $sig_on_error);
ENV_sig( $sig_on_error => "Unable to opendir '$path'", "- $!");
}

return $nr_of_entries;
}




sub ENV_unlink($;$$)
{
my ($filespec,
$force,		    # opt. bool
$sig_on_error,	    # opt. '', 'EE', etc. Default == 'F'
) = @_;
my $deleted = 0;

$deleted = unlink $filespec;
if (!$deleted)
{
if (defined $force && $force)
{
chmod oct(777), $filespec;	# ugo+rwx
$deleted = unlink $filespec;
}
if (!$deleted)
{



sleep( 1);
chmod oct(777), $filespec;	# ugo+rwx
$deleted = unlink  $filespec;
if ($deleted)
{
ENV_sig( I => "Delete of '$filespec' succeeded after delay");
} else
{
$sig_on_error = 'F'
if (!defined $sig_on_error);
ENV_sig( $sig_on_error => "Cannot delete '$filespec'", "- $!");
}
}
}


return $deleted;
}




sub ENV_copy_file($$$)
{
my ($in_file,
$out_file,
$sig_on_error,	    # undef, '', 'EE', 'F', etc
) = @_;
my $replicated = 1;    	    # 1 = replicated, 0 == error

my ($rc, $command, $fail_reason) = OS_copy_file( $in_file, $out_file);
if ($rc != 0)
{
ENV_sig( $sig_on_error => "Copy (replicate) command failed. rc = $rc",
"Command: $command",
"- $fail_reason");
$replicated = 0;
}

return $replicated;
}




sub ENV_backup_file($$$)
{
my ($filespec,
$backup_type,	    # e.g.: .sav
$sig_on_error,	    # undef, '', 'EE', etc
) = @_;
my $backup_filespec;   # undef if failed


my $backup_file_format = "$filespec.%04d$backup_type";
my $i = 1;
do
{
$backup_filespec = sprintf( $backup_file_format, $i++);
} while ( -e $backup_filespec);

ENV_spit_file( $backup_filespec, ENV_slurp_file( $filespec, $sig_on_error), 0);



return $backup_filespec;
}




sub ENV_touch_file($;$)
{
my ($filespec,
$sig_on_error,	    # opt. '', 'EE', etc. Default == 'F'
) = @_;
my $touched = 1;

if (open( my $touch_fh, '>>', $filespec))
{
close( $touch_fh);
} else
{
$sig_on_error = 'F'
if (!defined $sig_on_error);
ENV_sig( $sig_on_error => "Unable to touch (append) file '$filespec'", "- $!");
$touched = 0;
}

return $touched;
}




sub ENV_slurp_file($;$$$)
{
my ($filespec,
$sig_on_error,	    # Optional: undef, '', 'EE', etc. Default = 'F'
$mode,		    # Optional: One of '<', ... . Default is '<'
$max_lines,	    # Optional: undef == 0 == all
) = @_;



$sig_on_error = 'F'
if (!defined $sig_on_error);
$mode = '<'
if (!defined $mode);
$max_lines = 0
if (!defined $max_lines);

if (open( my $in_fh, $mode, $filespec))
{
if (wantarray)
{



my @lines;
if ($max_lines == 0)
{
@lines = <$in_fh>;
} else
{
while (<$in_fh>)
{
push @lines, $_;
last
if ($max_lines-- == 1);
}
}
if (!close( $in_fh))
{
ENV_sig( $sig_on_error => "Unable to close file '$filespec'", "- $!");
@lines = (undef);
}
return @lines;
} else
{



my $lines;
if ($max_lines == 0)
{
local $/ = undef;	    # Change the $RS ($INPUT_RECORD_SEPARATOR) to full file
$lines = <$in_fh>;
} else
{
while ($max_lines-- > 0 && <$in_fh>)
{
$lines .= $_;
}
}
if (!close( $in_fh))
{
ENV_sig( $sig_on_error => "Unable to close file '$filespec'", "- $!");
$lines = undef;
}
return $lines;
}
} else
{
ENV_sig( $sig_on_error => "Unable to open file '$filespec'", "- $!");
}

return (wantarray) ? (undef) : undef;
}




sub ENV_spit_file($$$;$$)
{
my ($filespec,
$line_or_ref,
$must_add_nl,		    # Bool
$sig_on_error,		    # Optional: undef, '', 'EE', etc. Default = 'F'
$mode,			    # Optional: One of '>', '>>', ... . Default is '>'
) = @_;
my $result_ok = 1;



$sig_on_error = 'F'
if (!defined $sig_on_error);
$mode = '>'
if (!defined $mode);


if (open( my $out_fh, $mode, $filespec))
{
if ($must_add_nl)
{
map { CORE::say( $out_fh $_) } deref_lines( 0, $line_or_ref);
} else
{
if (ref $line_or_ref)
{



map { CORE::print( $out_fh $_) } deref_lines( 0, $line_or_ref);
} else
{



CORE::print( $out_fh $line_or_ref);
}
}
if (!close( $out_fh))
{
ENV_sig( $sig_on_error => "Unable to close file '$filespec'", "- $!");
$result_ok = 0;
}
} else
{
my $action = ($mode eq '>>') ? 'append' : 'create';
ENV_sig( $sig_on_error => "Unable to $action file '$filespec'", "- $!");
$result_ok = 0;
}

return $result_ok;
}




sub ENV_hide_file($$)
{
my ($filespec,
$must_hide	    # 0 = unhide, 1 = hide, undef = test-only
) = @_;


return OS_hide_file( $filespec, $must_hide);
}




sub ENV_max_command_line()
{
return $MAX_COMMAND_LINE;
}






sub ENV_prepare_command($)
{
my ($command_items_ref,	# ref array
) = @_;
my @command_items;		# ENV_join_quoted_space if scalar



ENV_sig( F => "Error Calling ENV_prepare_command - not a ref")
if (!ref $command_items_ref);

@command_items = @{$command_items_ref};
my $lc_first_item = lc $command_items[0];
if ($lc_first_item eq 'perl')
{
$command_items[0] = ENV_os_paths( $APP_PERL_CMD);
$command_items[1] = ENV_os_paths( $command_items[1]);
} else
{
my ($type) = $lc_first_item =~ m!.*(\..+)$!;   # lc
$type = ''
if (!defined $type);
if ($type eq '.pl')
{
$command_items[0] = ENV_os_paths( $command_items[0]);
unshift @command_items, ENV_os_paths( $APP_PERL_CMD);
} else
{
if ($IS_WIN32)
{
if ($type eq '')	# e.g.: call $command or start $command
{
$command_items[1] = ENV_os_paths( $command_items[1])
if (defined $command_items[1]);
} else
{
$command_items[0] = ENV_os_paths( $command_items[0]);
if ($type eq '.bat')
{
unshift @command_items, 'call';
} elsif ($type eq '.exe' || $type eq '.com')
{
; # do nothing
} else
{
unshift @command_items, 'call';
}
}
} else	# Linux
{
;   # no change
}
}
}




return (wantarray) ? @command_items : ENV_join_quoted_space( @command_items);
}





sub ENV_find_in_perl_inc($$)
{
my ($file,			# relative file_path
$must_find,
) = @_;
my $filespec = '';

foreach my $path (@INC)
{
if (-f "$path/$file")
{
$filespec = "$path/$file";
last;
}
}
ENV_sig( F => "Could not find '$file' in (@INC)")
if ($filespec eq '' && $must_find);

return $filespec;
}






sub ENV_system($$)
{
my ($command_or_ref,    # if ref: ENV_prepare_command will be called first
$oks_ref,	    # allowed return-codes (undef == nocheck)
) = @_;
my $rc;

my $command = (ref $command_or_ref) ? ENV_prepare_command( $command_or_ref): $command_or_ref;


if (length( $command) > $MAX_COMMAND_LINE)
{
my $command_length = length( $command);
ENV_sig( F => "system(): commandline length ($command_length) > $MAX_COMMAND_LINE.",
"First part is:",
substr( $command, 0, 80) . '...',
"Last part is:",
substr( $command, -80) . '...');
}

my $full_rc = system( $command );			# execute the command
$rc = handle_rc( $full_rc, $oks_ref, $command);


return $rc;
}







sub ENV_backtick($$$)
{
my ($command_or_ref,    # command or $command_items_ref
$oks_ref,	    # allowed return-codes (undef == nocheck)
$include_stderr,    # bool
) = @_;
my ($rc, $stdout);

my $command = (ref $command_or_ref) ? ENV_prepare_command( $command_or_ref): $command_or_ref;



$command = "$command 2>&1"
if ($include_stderr);


if (length( $command) > $MAX_COMMAND_LINE)
{
my $command_length = length( $command);
ENV_sig( F => "system(): commandline length ($command_length) > $MAX_COMMAND_LINE.",
"First part is:",
substr( $command, 0, 80),
"Last part is:",
substr( $command, -80));
}

$stdout = qx{ $command };		# backtick
my $full_rc = $?;

$rc = handle_rc( $full_rc, $oks_ref, $command);


return (wantarray) ? ($rc, $stdout) : $stdout;
}




sub handle_rc($$$;$)
{
my ($full_rc,
$oks_ref,	# allowed return-codes (undef == nocheck)
$command,	# for error reporting
$signal,	# Default = 'F'
) = @_;
my $rc;

$signal = 'F'
if (!defined $signal);

if ($full_rc == 0)
{
$rc = 0;
} else
{
if ($full_rc == -1)
{
ENV_sig( $signal => "system: Cannot execute '$command'",
"- $!");
} else
{
$rc = ENV_rc_status( $full_rc, "system $command");
}
}
if (defined $oks_ref)
{
my @oks = (ref $oks_ref) ? @{$oks_ref} : ($oks_ref);
my $rc_ok = grep( $_ == $rc, @oks);
if (!$rc_ok)
{
ENV_sig( $signal => "Unable to execute '$command' (rc=$rc)");
}
}

return $rc;
}




sub ENV_run3($$$$$)
{
my ($command_or_ref,    # command or $command_items_ref
$multipart_ref,	    # undef = ok. Entries with whitespace will be quoted
$oks_ref,	    # allowed return-codes (undef == nocheck)
$stdout_ref,	    # 1 (non-ref==discard)		 can be REF ARRAY or REF SCALAR
$stderr_ref,	    # 2 (undef==print, non-ref==discard) can be REF ARRAY or REF SCALAR
) = @_;
my $rc;



my $command = (ref $command_or_ref) ? ENV_prepare_command( $command_or_ref): $command_or_ref;

my $stdout_file = ENV_get_tmp_spec( 'run3_stdout');
my $stderr_file = ENV_get_tmp_spec( 'run3_stderr');
my $command_tail = qq(2> "$stderr_file" > "$stdout_file");
my @commands;
if (defined $multipart_ref)
{
my @multiparts = ENV_enquote( @{$multipart_ref});

my $full_command = "$command @multiparts $command_tail";
if (length( $full_command) <= $MAX_COMMAND_LINE)
{
@commands = ($full_command);
} else
{

my $command_tail_l = length( $command_tail);
my $full_command = $command;
foreach my $multipart (@multiparts)
{
if (length( $full_command) + 1 + length( $multipart) + 1 + $command_tail_l < $MAX_COMMAND_LINE - 5)
{
$full_command .= ' ' . $multipart;
} else
{
push @commands, $full_command . ' '. $command_tail;
$full_command = "$command $multipart";
}
}
push @commands, $full_command . ' '. $command_tail
if (length( $full_command) != length( $command));
}
} else
{
@commands = ("$command $command_tail");
}




my $full_stdout;
my $full_stderr;
my $count = 0;
foreach my $command_line (@commands)
{
$count++;
{
my $command_length = length $command_line;

}
$rc = ENV_system( $command_line, undef);
my $stdout = ENV_slurp_file( $stdout_file);
my $stderr = ENV_slurp_file( $stderr_file);
unlink( $stdout_file, $stderr_file);
if (defined $oks_ref)
{
my @oks = (ref $oks_ref) ? @{$oks_ref} : ($oks_ref);
my $rc_ok = grep( $_ == $rc, @oks);
if (!$rc_ok)
{
ENV_say(   1, "### ENV_run3 failed (rc=$rc) ###");
ENV_say(   0, "COMMAND:",
"  $command_line",
"STDOUT:");
ENV_print( 0, $stdout);
ENV_say(   0, "STDERR:");
ENV_print( 0, $stderr);
ENV_say(   0, "***");
ENV_sig( F => "Unable to execute command (rc=$rc)");
} else
{
if (!defined $stderr_ref && $stderr ne '')
{
exec_beep();
ENV_say( 0, $command);
ENV_print( 0, $stderr);
}
}
}



$full_stdout .= $stdout;
$full_stderr .= $stderr;
}

de_ref( $stdout_ref, $full_stdout);
de_ref( $stderr_ref, $full_stderr);

return $rc;
}






sub ENV_exec($$)
{
my ($command_or_ref,	    # command or $command_items_ref (ADT) # [ $type, $prefix, $os_exec, @args ]
$log_file,		    # undef = no redirection
) = @_;

my $command = (ref $command_or_ref) ? ENV_prepare_command( $command_or_ref): $command_or_ref;

if (defined $log_file)
{
$log_file = ENV_enquote( $log_file);
$command = "$command > $log_file 2>&1";
}

$RUNNING_IN_EXEC = 1;
exec( $command);

die( "$PREFIX: exec '$command' failed\n - $!");	# perl will not accept anything other than 'die' after 'exec'
}




sub ENV_rc_status($$)
{
my ($full_rc,
$msg,
) = @_;
my $rc;

my $rc16 = $full_rc & 0xffff;
$rc = $rc16 >> 8;
my $sig = $rc16 & 127;
my $core = $rc16 & 128;



if ($sig != 0)
{
ENV_sig( E => "Command '$msg' failed with signal $sig (rc=$rc)");
}
if ($core != 0)
{
ENV_sig( E => "Command '$msg' failed with coredump (sig=$sig rc=$rc)");
}

return $rc;
}




sub de_ref($$)
{
my ($value_ref,	# undef: do nothing. ref to scalar or list
$string,
) = @_;

my $ref = ref $value_ref;
if ($ref eq 'ARRAY')
{
@{$value_ref} = split( /\s*\n/, $string);
} elsif ($ref eq 'SCALAR')
{
$$value_ref = $string;
}
}





sub ENV_detab($)
{
my ($line) = @_;

my $tab_pos = index( $line, "\t");
while ($tab_pos >= 0)
{

my $wanted_out_pos = (($tab_pos + 8) / 8) * 8;
my $nr_spaces = $wanted_out_pos - $tab_pos;
my $spaces = ' ' x $nr_spaces;
$line = substr( $line, 0, $tab_pos) .
$spaces .
substr( $line, $tab_pos + 1);

$tab_pos = index( $line, "\t");
}

return $line;
}





sub ENV_retab($)
{
my ($line,
) = @_;
my $new_line = '';


while (substr( $line, 0, 8) eq '        ')
{
$new_line .= "\t";
$line = substr( $line, 8);
}
$new_line .= $line;

return $new_line;
}




sub ENV_encode(@)
{
my @list = (@_);


my $enc_space = ($IS_WIN32) ? '$20' : '%20';
my $enc_quote = ($IS_WIN32) ? '$22' : '%22';
foreach my $word (@list)
{
$word =~ s/ /$enc_space/g;
$word =~ s/"/$enc_quote/g;
}


return wantarray ? @list : $list[0];
}




sub ENV_decode(@)
{
my @list = (@_);


my $enc_space = ($IS_WIN32) ? '\$20' : '%20';
my $enc_quote = ($IS_WIN32) ? '\$22' : '%22';
foreach my $word (@list)
{
$word =~ s/%20/ /g;
$word =~ s/$enc_space/ /g;
$word =~ s/$enc_quote/"/g;
}





if (0)
{
if ("@_" ne "@list")
{


}
}

return wantarray ? @list : $list[0];
}






sub ENV_split_quoted_space($)
{
my ($line) = @_;
my @list;

if (index( $line, '"') >= 0)

{



my $i = 0;
my $last_i = length( $line) + 1;
$line .= '  ';				    # add 2 dummy trailing space
my $next_char = substr( $line, $i++, 1);
do
{




if ($i < $last_i)
{
while ($next_char eq ' ' || $next_char eq "\t")
{
$next_char = substr( $line, $i++, 1);
}
}
if ($i < $last_i)
{
my $word = '';
if ($next_char eq '"')
{



$next_char = substr( $line, $i++, 1);	# skip opening quote
while ($next_char ne '"' && $i < $last_i)
{
$word .= $next_char;
if ($next_char eq '\\')
{
$next_char = substr( $line, $i++, 1);
$word .= $next_char;
}
$next_char = substr( $line, $i++, 1);
}
$next_char = substr( $line, $i++, 1);	#skip closing quote
} else
{



while ($next_char ne ' ' && $next_char ne "\t")
{
$word .= $next_char;
$next_char = substr( $line, $i++, 1);
if ($next_char eq '"')			# internal '"'
{
$word .= $next_char;		# add opening quote
$next_char = substr( $line, $i++, 1);
while ($next_char ne '"' && $i < $last_i)
{
$word .= $next_char;
if ($next_char eq '\\')
{
$next_char = substr( $line, $i++, 1);
$word .= $next_char;
}
$next_char = substr( $line, $i++, 1);
}
$word .= $next_char; 		# add closing quote
$next_char = substr( $line, $i++, 1);
}
}
}
push @list, $word;
}
} while ($i < $last_i);
} else
{



@list = split( ' ', $line);	    # split on any whitespaces
}

return (wantarray) ? @list : [ @list ];
}




sub ENV_join_quoted_space(@)
{
my @list = @_;


foreach my $word (@list)
{
my_say( F => 0, stackdump( 1))
if (!defined $word);
if ($word eq '')
{
$word = '""';
} elsif (index( $word, ' ') >= 0 && index( $word, '"') < 0)
{



$word =~ s/"/\\"/g;
$word = "\"$word\"";
}
}

return "@list";
}





sub ENV_enquote(@)
{
my @list = (@_);


foreach my $word (@list)
{
if ($word eq '')
{
$word = '""'
} elsif (substr( $word, 0, 1) ne '"' && $word =~ /"|\s/)    # does not start with " and contains (" or space)
{
$word =~ s/"/\\"/g;
$word = "\"$word\"";
}
}


return wantarray ? @list : $list[0];
}




sub ENV_dequote(@)
{
my @list = (@_);


foreach my $word (@list)
{
if (substr( $word, 0, 1) eq '"')
{
$word =~ s/\\"/"/g;
$word = substr( $word, 1, -1);
}
}


return wantarray ? @list : $list[0];
}




sub ENV_split_lines($@)
{
my ($max_length,
@lines
) = @_;
my @split_lines;



foreach my $line (@lines)
{
my $line_length = length $line;
if ($line_length <= $max_length)
{
push @split_lines, $line;
} else
{
my $indent = '';
my $max_sub_length = $max_length;
if ($line =~ /^(- |  )\S+/)			# starts with '- ' or 2 spaces
{

$indent = ' ' x length( $1);		# get indent
} else
{
while ($line =~ /^\ {$max_length,}/)
{
ENV_say( 0, '');
$line = substr( $line, $max_length);
$line_length = length $line;
}

}
my $start_index = 0;
my $i = 0;
do
{

my $remaining_length = $line_length - $start_index;

my $part;
if ($remaining_length > $max_sub_length)
{

my $ri = rindex( substr( $line, $start_index, $max_sub_length), ' ');
$ri = rindex( substr( $line, $start_index, $max_sub_length), ',')
if ($ri < 0);

if ($ri >= 0)
{



if (substr( $line, $start_index + $ri, 1) eq ',')
{
$part = substr( $line, $start_index, $ri + 1);
$start_index = $start_index + $ri + 1;	# next $start_index
} else	# ' '
{
$part = substr( $line, $start_index, $ri);
$start_index = $start_index + $ri + 1;	# next $start_index
}
} else
{



$part = substr( $line, $start_index, $max_sub_length - 1);
$start_index = $start_index + $max_sub_length - 1;	# next $start_index
$start_index++
if ($start_index < $line_length && substr( $line, $start_index, 1) eq ' '); # exact fit
}
} else
{



$part = substr( $line, $start_index);
$start_index = $line_length;	# next $start_index (end)
}
if ($i == 0)
{
$max_sub_length = $max_length - length( $indent);
} else
{
$part = "$indent$part";
}

push @split_lines, $part;
$i++;
} while ($start_index < $line_length && $i < 32000);
}
}

return @split_lines;
}




sub ENV_redirect_stdouterr($)
{
my ($log_file) = @_;

open( $SAVED_STDOUT, '>&', STDOUT) || my_die( "$PREFIX: Cannot save STDOUT\n- $!");
open( $SAVED_STDERR, '>&', STDERR) || my_die( "$PREFIX: Cannot save STDERR\n- $!");
open( STDOUT, '>>', $log_file) || my_die( "$PREFIX: Cannot redirect STDOUT to $log_file\n- $!");
open( STDERR, '>&', STDOUT) || my_die( "$PREFIX: Cannot duplicate STDERR to STDOUT\n- $!");

my $saved_handle = select STDERR;
$| = 1;           # $OUTPUT_AUTOFLUSH
select STDOUT;
$| = 1;           # $OUTPUT_AUTOFLUSH
select $saved_handle;
}




sub ENV_restore_stdouterr()
{
close( STDOUT) || my_die( "$PREFIX: Cannot close STDOUT\n- $!");
close( STDERR) || my_die( "$PREFIX: Cannot close STDERR\n- $!");
open( STDOUT, '>&', $SAVED_STDOUT) || my_die( "$PREFIX: Cannot restore STDOUT\n- $!");
open( STDERR, '>&', $SAVED_STDERR) || my_die( "$PREFIX: Cannot restore STDERR\n- $!");
}




sub ENV_get_desktop_path($)
{
my ($system_item) = (@_);

return OS_get_desktop_path( $system_item);
}




sub ENV_get_startmenu_path($)
{
my ($system_item) = (@_);

return OS_get_startmenu_path( $system_item);
}






sub ENV_get_programs_path($)
{
my ($system_item) = (@_);

return OS_get_programs_path( $system_item);
}






sub ENV_get_user_path($)
{
my ($system_item) = (@_);

return OS_get_user_path( $system_item);
}




sub ENV_is_administrator()
{
return OS_is_administrator();
}




sub ENV_set_global_variables($;$)
{
my ($pairs_ref,	    # or Variable Name
$value,		    # only is $pairs_ref is variable name
) = @_;

$pairs_ref = [ $pairs_ref => $value ]
if (!ref $pairs_ref);


our @VALUES;
our %VALUES;
my @perl_lines;
while (@{$pairs_ref})
{
my $name = shift @{$pairs_ref};
my $value_or_ref = shift @{$pairs_ref};
$name = "${APP_NAME}::$name"
if ($name !~ /::/);
if (ref $value_or_ref)
{
my $perl_line;
if (ref $value_or_ref eq 'ARRAY')
{
@VALUES = @{$value_or_ref};
$perl_line = "\@$name=\@VALUES; # (@VALUES)";
} else # (ref $value_or_ref eq 'HASH')
{
%VALUES = @{$value_or_ref};
$perl_line = "\%$name=\%VALUES;";
}

eval $perl_line;			## no critic
if ($@)
{
ENV_say( 0, $perl_line);
ENV_sig( F => "eval error:", $@);
}
}  else
{
push @perl_lines, "\$$name='$value_or_ref';";
}
}

if (@perl_lines)
{

eval "@perl_lines";			## no critic
if ($@)
{
ENV_say( 0, @perl_lines);
ENV_sig( F => "eval error:", $@);
}
}

}




sub my_print($@)
{
my ($text_type,	    # NIWEF (NORMAL, INFO, WARNING, ERROR, FATAL)
@lines
) = @_;

if (defined $PRINT_FUNC)
{
$PRINT_FUNC->( $text_type, @lines);
} else
{
map { CORE::print( $_) } @lines;
}
}




sub my_say($$@)
{
my ($text_type,	    # NIWEF (NORMAL, INFO, WARNING, ERROR, FATAL)
$indent,
@lines
) = @_;

my $spaces = ' ' x $indent;
if (defined $SAY_FUNC)
{
$SAY_FUNC->( $text_type, map { "$spaces$_" } @lines);
} else
{
map { CORE::say( "$spaces$_") } @lines;
}
}




sub my_die(@)
{
my_say( F => 0, stackdump( 1));
die @_;
}

1;
