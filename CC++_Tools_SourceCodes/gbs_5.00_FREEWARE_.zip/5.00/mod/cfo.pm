#=================================================
#
#   cfo.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::cfo;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
CFO_parse_build
CFO_parse_make
CFO_parse_audit
CFO_get_pre_options
CFO_get_items
CFO_get_components
);
}




use glo::env;
use glo::list;
use glo::format;
use mod::gbsglo;
use mod::build;
use mod::audit;




sub CFO_parse_build($);
sub CFO_parse_make($$);
sub CFO_parse_audit($);
sub CFO_get_pre_options();
sub CFO_get_items();
sub CFO_get_components();

sub pre_parse($);
sub cfo_parse();
sub expand_component($$$);
sub expand_make_component($);
sub wild_components($);
sub select_src_files($$@);
sub select_build_files($$@);
sub store_cfo();
sub validate_component($);
sub validate_type($$);
sub get_sources($$$);
sub is_option($);




my @ALLOWED_COMPS;
my %COMPONENTS;		# per parse


my %SRCTYPES;


my %ALLOWED_TYPES;


my @ALLOWED_TYPES;

my $FUNCTION_TEXT;	# 'Audit', 'Build' or 'Make'
my $FOR_AUDIT = 0;
my $FOR_BUILD = 0;
my $FOR_MAKE = 0;

my $REVERSE_TYPE = 0;	# make only

my @PRE_OPTIONS;
my @PARSED_REFS;


my %TMP_CFO_REFS;


my @CFO_REFS;






sub CFO_parse_build($)
{
my ($comp_file_opts_ref,	    # positional parameters
) = @_;





$FUNCTION_TEXT = 'Build';
$FOR_BUILD = 1;
@ALLOWED_TYPES = BUILD_get_src_types( $GBS::BUILD);
map { $ALLOWED_TYPES{$_} = 1 } @ALLOWED_TYPES;

pre_parse( $comp_file_opts_ref);

return cfo_parse();
}




sub CFO_parse_make($$)
{
my ($comp_file_opts_ref,	    # positional parameters
$reverse_type) = @_;	    # Specify source-types instead of build-types





$FUNCTION_TEXT = 'Make';
$FOR_MAKE = 1;
$REVERSE_TYPE = $reverse_type;
@ALLOWED_TYPES = ($REVERSE_TYPE) ? BUILD_get_src_types( $GBS::BUILD) : BUILD_get_bld_types( $GBS::BUILD);
map { $ALLOWED_TYPES{$_} = 1 } @ALLOWED_TYPES;

pre_parse( $comp_file_opts_ref);

return cfo_parse();
}




sub CFO_parse_audit($)
{
my ($comp_file_opts_ref,	    # positional parameters
) = @_;





$FUNCTION_TEXT = 'Audit';
$FOR_AUDIT = 1;
my %build_types = map { $_ => 1 } BUILD_get_src_types( $GBS::BUILD);
my @audit_src_types = AUDIT_get_src_types( $GBS::AUDIT);
@ALLOWED_TYPES = ();
%ALLOWED_TYPES = ();
foreach my $audit_src_type (@audit_src_types)
{
if (exists $build_types{$audit_src_type})
{
push @ALLOWED_TYPES, $audit_src_type;
}
}
ENV_sig( EE => "No Audits defined")
if (!@ALLOWED_TYPES);
map { $ALLOWED_TYPES{$_} = 1 } @ALLOWED_TYPES;


pre_parse( $comp_file_opts_ref);

return cfo_parse();
}





sub pre_parse($)
{
my ($comp_file_opts_ref,	    # positional parameters
) = @_;






map { $SRCTYPES{$_} = BUILD_get_primary_bld_type( $GBS::BUILD, $_) } BUILD_get_src_types( $GBS::BUILD);
ENV_sig( EE => "No Builders defined for this Build '$GBS::BUILD'")
if (!%SRCTYPES);

my @comp_file_opts = @{$comp_file_opts_ref};





while (@comp_file_opts && is_option( $comp_file_opts[0]))
{
push @PRE_OPTIONS, shift @comp_file_opts;
}




my $wild_component = '.';
my @wild_files;
my @options;
foreach my $item (@comp_file_opts)
{

if (is_option( $item))
{
if ($FOR_MAKE)
{
push @PRE_OPTIONS, $item;
} else
{
push @options, $item;
}
} else
{
$item = ".:*.*"
if ($item eq '.');
$item = "*:*.*"
if ($item eq 'ALL');
my $contains_colon = $item =~ /\:/;
my $plain_name = ($FOR_MAKE) ? $item !~ /[:.]/ : 0;     # no colon or dot
if (scalar @options || $contains_colon || $plain_name)
{
push @PARSED_REFS, [ $wild_component, [@wild_files], [@options] ]
if (@wild_files);
@wild_files = ();
@options = ();
}
if ($plain_name)	    # make only
{
push @PARSED_REFS, [ $item, undef, undef ]
} elsif ($contains_colon)
{
my ($this_comp, $wild_files) = split ':', $item;

$wild_component = $this_comp
if ($this_comp ne '.' && $this_comp ne '');
if ($FOR_MAKE)
{
if ($wild_files eq '' || $wild_files eq '*.*' || $wild_files eq '*')
{
push @PARSED_REFS, [ $wild_component, undef, undef ]
} else
{
@wild_files = split ',', $wild_files;
}
} else
{
@wild_files = split ',', $wild_files;
@wild_files = ('*.*') if (!@wild_files);
}
} else
{

push @wild_files, split ',', $item;
}
}
}
push @PARSED_REFS, [ $wild_component, [@wild_files], [@options] ]
if (@wild_files);

}




sub cfo_parse()
{
my $nr_cfo = 0;

@ALLOWED_COMPS = ();




my %sel_orders;
if ($FOR_BUILD)
{
my $sel_order = 1;
foreach my $order_ref (BUILD_get_rule_gen_order( $GBS::BUILD)) # per order

{
map { $sel_orders{$_} = $sel_order } @{$order_ref};
$sel_order++;
}
}


foreach my $ref (@PARSED_REFS)
{
my ($wild_component, $wild_files_ref, $options_ref) = @{$ref};
my @cfo_refs;

if (defined $wild_files_ref)
{
@cfo_refs = expand_component( $wild_component, $wild_files_ref, $options_ref);
} else
{
@cfo_refs = expand_make_component( $wild_component);	    # or $item
}

my $sel_order = ($FOR_AUDIT) ? 1 : 0;
foreach my $cfo_ref (@cfo_refs)
{
my ($component, $files_ref, $opts_ref) = @{$cfo_ref};
if (defined $files_ref)
{
foreach my $file (@{$files_ref})
{
my $file_type = ENV_split_spec_t( $file);
my $must_store_file = 1;
if ($FOR_BUILD)
{
$sel_order = $sel_orders{$file_type};

} elsif ($FOR_AUDIT)
{
$must_store_file = 0
if (!exists $ALLOWED_TYPES{$file_type});
}
if ($must_store_file)
{
my $comp_key = "$component:@{$opts_ref}";
my $tmp_cfo_ref = $TMP_CFO_REFS{$sel_order}->{$comp_key};
if (defined $tmp_cfo_ref)
{
push @{$tmp_cfo_ref}, $file;
} else
{
$TMP_CFO_REFS{$sel_order}->{$comp_key} = [ $component, $opts_ref, $file ];
}
}
}
} else
{
$TMP_CFO_REFS{0}->{$component} = [ $component, undef ];
}
}
}





@CFO_REFS = ();
store_cfo();
%TMP_CFO_REFS = ();






{
ENV_say( 1, "Selected:");
if (@CFO_REFS > 0)
{
my @row_refs;
push @row_refs, [ 0, "ALL: @PRE_OPTIONS" ]
if (@PRE_OPTIONS);
my $sel_order = ($FOR_MAKE) ? 0 : 1;
foreach my $order_ref (@CFO_REFS)
{

foreach my $comp_ref (@{$order_ref})
{
my ($component, $files_ref, $opts_ref) = @{$comp_ref};
$COMPONENTS{$component} = 1;
push @row_refs, [ 0, "$sel_order:$component:" ];
push @row_refs, [ 3, "@{$files_ref}" ];
push @row_refs, [ 5, "(@{$opts_ref})" ]
if (@{$opts_ref});
}
$sel_order++;
}
ENV_say( 2, FORMAT_indent( -10, 0, @row_refs));
} else
{
ENV_say( 2, 'None');
}
}

$nr_cfo = @CFO_REFS;
return $nr_cfo;
}




sub expand_component($$$)
{
my ($wild_component,
$wild_files_ref,
$options_ref,
) = @_;
my @cfo_refs;


my @file_refs;
foreach my $file (@{$wild_files_ref})
{
if (GBSGLO_validate_spec( $file))
{
my ($name, $type) = ENV_split_spec_nt( $file);
$type = '.*'
if ($type eq '');
if (validate_type( $file, $type))
{
push @file_refs, [ $file, $name, $type ];
}
} else
{
ENV_say( 1, "File '$wild_component:$file' skipped");
}
}
my @components;
my $is_multi_component;
if (ENV_is_wildcard( $wild_component))
{
@components = wild_components( $wild_component);
$is_multi_component = 1;
} else
{
@components = validate_component( $wild_component);
$is_multi_component = 0;
}

my $select_files_func = ($FOR_MAKE && !$REVERSE_TYPE) ? \&select_build_files : \&select_src_files;
foreach my $comp (@components)
{
my $this_files_ref = $select_files_func->( $is_multi_component, $comp, @file_refs);
push @cfo_refs, [ $comp, $this_files_ref, $options_ref ];
}

return @cfo_refs;
}




sub expand_make_component($)
{
my ($wild_component,
) = @_;
my @cfo_refs;


$wild_component = 'ALL' if ($wild_component eq '*');

my @components;
if ($wild_component eq 'ALL')
{
@components = ( 'ALL' );
} else
{
if (ENV_is_wildcard( $wild_component))
{
@components = wild_components( $wild_component);
} else
{
@components = validate_component( $wild_component);
}
}
@cfo_refs = map { [ $_, undef, undef ] } @components;

return @cfo_refs;
}




sub wild_components($)
{
my ($wild_component) = @_;
my @components;

if (!@ALLOWED_COMPS)
{
if ($FOR_AUDIT)
{
@ALLOWED_COMPS = GBSGLO_components_for_audit( $GBS::SUBSYS, $GBS::AUDIT, $GBS::BUILD);
} else
{
@ALLOWED_COMPS = GBSGLO_components_for_build( $GBS::SUBSYS, $GBS::BUILD);
}
}
@components = ENV_wildcard( $wild_component, [ @ALLOWED_COMPS ]);

if (!@components)
{
if ($FOR_AUDIT)
{
ENV_sig( W => "No valid wild Component '$wild_component' for Audit '$GBS::AUDIT' and Build '$GBS::BUILD'");
} else
{
ENV_sig( W => "No valid Wild Component '$wild_component' Build '$GBS::BUILD'");
}
}

return @components;
}




sub select_src_files($$@)
{
my ($is_wild_component,
$component,
@generic_file_refs	     # [ $file, $name, $type ]
) = @_;
my @files;


foreach my $generic_file_ref (@generic_file_refs)
{


my $generic_file = $generic_file_ref->[0];
push @files, get_sources( $is_wild_component, $component, $generic_file);
}

if ($REVERSE_TYPE)
{
foreach my $file (@files)
{
my ($name,$type) = ENV_split_spec_nt( $file);
my $bld_type = $SRCTYPES{$type};
$file = "$name$bld_type";
}
}

return [ @files ];
}





sub select_build_files($$@)
{
my ($is_wild_component,
$component,
@generic_file_refs	     # [ $file, $name, $type ]
) = @_;
my @files;


foreach my $generic_file_ref (@generic_file_refs)
{

my ($generic_file, $generic_name, $generic_type) = @{$generic_file_ref};
$generic_name = '*'
if ($generic_name eq '');
$generic_type = '.*'
if ($generic_type eq '');
$generic_file = "$generic_name$generic_type";
my @src_files = get_sources( $is_wild_component, $component, "$generic_name.*");
my $is_wild_file = ENV_is_wildcard( $generic_file);
if (@src_files)
{
if ($is_wild_file)
{
foreach my $src_filespec (@src_files)
{
my ($src_name, $src_type) = ENV_split_spec_nt( $src_filespec);
my $bld_type = $SRCTYPES{$src_type};

if (defined $bld_type &&
ENV_wildcard( $generic_type, [ $bld_type ]))
{

push @files, "$src_name$bld_type";
}
}
} else
{
my $bld_file;
foreach my $src_file (@src_files)
{
my $src_type = ENV_split_spec_t( $src_file);
my $bld_type = $SRCTYPES{$src_type};
if (defined $bld_type &&
$bld_type eq $generic_type)
{
$bld_file = $generic_file;
last;
}
}
if (defined $bld_file)
{
push @files, $bld_file;
} else
{
ENV_sig( EE => "No src-file for $generic_file found")
if (!$is_wild_component);
}
}
} else
{
ENV_sig( EE => "No src-file for $generic_file found")
if ((!$is_wild_file) && (!$is_wild_component));
}
}

return [ @files ];
}




sub store_cfo()
{







if ($FOR_MAKE)
{
my $sel_order_ref = $TMP_CFO_REFS{0};
my $comp_index = 0;
foreach my $comp_key (sort keys %{$sel_order_ref})
{
my ($component, undef, @files) = @{$sel_order_ref->{$comp_key}};
if (@files)
{
$CFO_REFS[0]->[$comp_index] = [ $component, [ LIST_unique( \@files) ], [] ];
} else
{
$CFO_REFS[0]->[$comp_index] = [ $component, [], [] ];
}
$comp_index++;
}
} else
{
my $order_index = 0;
foreach my $sel_order (sort keys %TMP_CFO_REFS)
{
my $sel_order_ref = $TMP_CFO_REFS{$sel_order};
my $comp_index = 0;
foreach my $comp_key (sort keys %{$sel_order_ref})
{
my ($component, $opts_ref, @files) = @{$sel_order_ref->{$comp_key}};
$CFO_REFS[$order_index]->[$comp_index] = [ $component, [ LIST_unique( \@files) ], $opts_ref ];
$comp_index++;
}
$order_index++;
}
}

}




sub validate_component($)
{
my ($component,
) = @_;


if ($component eq '.')
{
ENV_sig( EE => "No current Component")
if ($GBS::COMPONENT eq '');
$component = $GBS::COMPONENT;
}

ENV_sig( EE => "No such Component '$component'")
if (! defined $GBS::ALL_COMPONENTS{$component});

if ($FOR_AUDIT)
{
ENV_sig( EE => "Component '$component' does not Audit '$GBS::AUDIT' for Build '$GBS::BUILD'")
if (! GBSGLO_component_does_audit( $GBS::SUBSYS, $component, $GBS::AUDIT, $GBS::BUILD));
} else
{
ENV_sig( EE => "Component '$component' does not generate for Build '$GBS::BUILD'")
if (! GBSGLO_component_does_build( $GBS::SUBSYS, $component, $GBS::BUILD));
}

return $component;
}





sub validate_type($$)
{
my ($file,
$type,
) = @_;
my $is_ok = 1;


if (!exists $ALLOWED_TYPES{$type})
{
if (ENV_is_wildcard( $type) &&
ENV_wildcard( $type, [@ALLOWED_TYPES]))
{

$ALLOWED_TYPES{$type} = 1;
} else
{
$is_ok = 0;
if ($FOR_AUDIT)
{
ENV_sig( E => "File '$file':",
"Type '$type' not allowed in this $FUNCTION_TEXT context ($GBS::AUDIT) for Build '$GBS::BUILD'");
} else
{
ENV_sig( E => "File '$file':",
"Type '$type' not allowed in this $FUNCTION_TEXT context for Build '$GBS::BUILD'");
}
}
}

return $is_ok;
}




sub get_sources($$$)
{
my ($is_wild_component,
$component,
$wild_file,
) = @_;
my @files;






my @all_files;
{
my $src_dir = "$GBS::COMP_PATH/$component/src";
if (ENV_is_wildcard( $wild_file))
{
my $src_dir_l = length( $src_dir) + 1;
@all_files = map { substr( $_, $src_dir_l) } GBSGLO_glob( "$src_dir/$wild_file");
} else
{
if (-f "$src_dir/$wild_file")
{
@all_files = ($wild_file);
} else
{
ENV_sig( EE => "No File '$wild_file' in Component '$component'")
if (!$is_wild_component);
}
}
}




foreach my $file (@all_files)
{
if ($file !~ /\s/)
{
my $type = ENV_split_spec_t( $file);
if (exists $ALLOWED_TYPES{$type})
{
push @files, $file;
} else
{
if ($FOR_AUDIT)
{
ENV_whisper( 1, "File '$component:$file':",
"Type '$type' skipped in this $FUNCTION_TEXT context ($GBS::AUDIT) for Build '$GBS::BUILD'");
} else
{
ENV_whisper( 1 => "File '$component:$file':",
"Type '$type' skipped in this $FUNCTION_TEXT context for Build '$GBS::BUILD'");
}
}
} else
{
ENV_sig( W => "File: '$component:$file': No spaces allowed. File Skipped");
}
}

return @files;
}




sub CFO_get_pre_options()
{
return @PRE_OPTIONS;
}







sub CFO_get_items()
{
return @CFO_REFS;
}




sub CFO_get_components()
{
return (wantarray) ? sort( keys %COMPONENTS ) : join( ',', keys %COMPONENTS);
}




sub is_option($)
{
my ($arg) = @_;
my $is_option;

$is_option = ENV_is_option( $arg) || $arg =~ /^["']/ || $arg =~ /["']$/;

return $is_option;
}

1;

