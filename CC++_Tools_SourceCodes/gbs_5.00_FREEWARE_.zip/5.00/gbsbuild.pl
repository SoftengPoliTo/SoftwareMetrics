#=================================================
#
#   gbsbuild.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSBUILD @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::genopt;
use mod::gbsenv;
use mod::gbsoptenv;
use mod::validate;
use mod::swb;
use mod::sys;
use mod::plugin;
use mod::cfo;
use mod::gbsbgjob;
use mod::gbsexec;
use mod::gbscmd;




sub get_post_build_refs();










$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( 'build');













{
my @genopts = (
[ '<*>',    'comp_file_opts',   'sam', "", "src files to generate with 'generate' options. ALL = *:*.*" ],
[ 'i' ,     'ignore_errors',    'bso',  0, "Continue generation regardless of error(s)" ],
[ 'build',  'build_name',	"ssos.,$GBS::BUILDS", '.', "Build to run" ],
[ 'export', 'run_gbsexport',    'bso',  0, "Run 'gbsexport' on completion" ],
[ 'mm',     'run_makemake',	'bso',  0, "Run 'makemake' on completion" ],
[ 'jobs',   'jobs',	        'isor1..9',  2, 'Max nr parallel jobs' ],
);
my @genenvs = qw( DEBUGGER MODE OPT MAP FLAGS_* APP_* );
GENOPT_set_optdefs( 'gbsbuild', \@genopts,
'Generate one or more files',
undef);
GENOPT_set_envdefs( \&GBSOPTENV_set, \&GBSOPTENV_print, \@genenvs);
GENOPT_parse();
}
my @COMP_FILE_OPTS = GENOPT_get( 'comp_file_opts');
my $IGNORE_ERRORS = GENOPT_get( 'ignore_errors');
my $BUILD_NAME = GENOPT_get( 'build_name');
my $RUN_GBSEXPORT = GENOPT_get( 'run_gbsexport');
my $RUN_MAKEMAKE = GENOPT_get( 'run_makemake');
my $JOBS = GENOPT_get( 'jobs');

my $GEN_ALL = (scalar @COMP_FILE_OPTS && $COMP_FILE_OPTS[0] eq '*:*.*');




ENV_setenv( GBS_IGNORE_ERRORS => $IGNORE_ERRORS);




VALIDATE_subsys_full_gbs();	# Also validates: GBS, Root and SubSys

$BUILD_NAME = VALIDATE_builds( $BUILD_NAME);
if (GBSENV_mode_is_interactive())
{



if ($BUILD_NAME ne $GBS::BUILD)
{
SWB_set( $BUILD_NAME, 1);
}




SYS_set_envs();
PLUGIN_setup( 'build');
}

VALIDATE_build();

{



GBSBGJOB_batch_init( $JOBS);




my $nr_cfo = CFO_parse_build( \@COMP_FILE_OPTS);
if ($nr_cfo > 0)
{
ENV_whisper( 1, "Executing 'Gen'...");




$RC = GBSEXEC_gen( $nr_cfo, $IGNORE_ERRORS);




if (($RC == 0 || $IGNORE_ERRORS) &&
($RUN_MAKEMAKE || $RUN_GBSEXPORT))
{
my @bgjob_refs = get_post_build_refs();
if (@bgjob_refs)
{
ENV_whisper( 1, "Run gbsgen_post");
my $rc = GBSBGJOB_batch_run( 'gbsgen_post', '-', \@bgjob_refs);
$RC = $rc
if ($rc > $RC);
}
}
} else
{
ENV_sig( W => "Nothing to do");
}




GBSBGJOB_batch_finish();
}



ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
}





sub get_post_build_refs()
{
my @bgjob_refs;

my @all_comps = CFO_get_components();




if ($RUN_MAKEMAKE)
{
if ($GEN_ALL)
{
push @bgjob_refs, GBSBGJOB_banner( 'gbsmakemake ALL');
} else
{
push @bgjob_refs, GBSBGJOB_banner( "gbsmakemake for Component(s): @all_comps");
}

my @makemake_opts;
push @makemake_opts, @all_comps
if (!$GEN_ALL);
push @makemake_opts, '--i'
if ($IGNORE_ERRORS);

my $command_items_ref = GBSCMD_get_gbs_command( gbsmakemake => \@makemake_opts);
push @bgjob_refs, GBSBGJOB_exec_short( 'gbsmakemake', 0, undef, $command_items_ref);
}




if ($RUN_GBSEXPORT)
{
my @texts = ("Explicit: gbsexport");
if ($GEN_ALL)
{
push @bgjob_refs, GBSBGJOB_banner( 'gbsexport ALL');
} else
{
push @bgjob_refs, GBSBGJOB_banner( "gbsexport for Component(s): @all_comps");
}

my @gbsexport_opts;
push @gbsexport_opts, grep( -e "$GBS::COMP_PATH/$_/export.gbs", @all_comps)
if (!$GEN_ALL);
push @gbsexport_opts, '--i'
if ($IGNORE_ERRORS);

my $command_items_ref = GBSCMD_get_gbs_command( gbsexport => \@gbsexport_opts);
push @bgjob_refs, GBSBGJOB_exec_short( 'gbsexport', 0, undef, $command_items_ref);
}


return @bgjob_refs;
}


