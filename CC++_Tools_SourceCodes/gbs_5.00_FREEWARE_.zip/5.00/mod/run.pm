#=================================================
#
#   run.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::run;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
RUN_gbsnew
RUN_gbssub_script
RUN_browser
RUN_editor
RUN_viewer
RUN_navigator
RUN_more
RUN_tail
RUN_terminal
RUN_gbs
RUN_tkx
);
}




use glo::env;
use glo::slurp;
use glo::proc;
use glo::flock;
use mod::gbsenv;
use mod::gbsenvs;
use mod::gbsglo;
use mod::gbscmd;
use mod::fspec;
use mod::system;




sub RUN_gbsnew($$);
sub RUN_gbssub_script($);
sub RUN_browser($);
sub RUN_editor($$);
sub RUN_viewer($);
sub RUN_navigator($);
sub RUN_more($;@);
sub RUN_tail($;@);
sub RUN_terminal($$);
sub RUN_gbs($);
sub RUN_tkx($$$);

sub run_env_command($$;$);




my @XTERM_COMMANDS = qw( less more type tail cat);
my %XTERM_COMMANDS = map { $_ => 1 } @XTERM_COMMANDS;	    # we may want to make this more generic in the future...

my $IS_WIN32 = ENV_is_win32();




sub RUN_gbsnew($$)
{
my ($command_arg,	    # new_root, new_other_root, new_subsys, new_component,

$arg) = @_;
my $result;		    # $root, $subsys, $component, $build, $audit




my $gbs_new_result_file = ENV_get_tmp_spec( 'GBSNEW_RESULT');
$ENV{GBS_NEW_FILE} = $gbs_new_result_file;

my @args = ($command_arg);
push @args, $arg
if (defined $arg && $arg ne '-');

SYSTEM_close();




my $rc = ENV_system( GBSCMD_get_gbs_command( gbsnew => \@args), undef);




if (-e $gbs_new_result_file)
{
($result, my @setenv_pairs) = SLURP_file( $gbs_new_result_file);
foreach my $setenv_pair (@setenv_pairs)   # EnvVar assignments: GBS_ADMINISTRATOR, GBS_ALL_SUBSYSTEMS, etc
{
my ($env_name, $value) = split( /=/, $setenv_pair);
GBSENVS_update( 1, $env_name => $value);
}
} else
{
$result = '';
if ($rc == 0)
{
ENV_sig( W => "'gbsnew' quitted ($rc)");
} else
{
my $sig_on_error = ($rc == 1) ? 'W' : 'E';
ENV_sig( $sig_on_error => "'gbsnew' failed ($rc)");
}
}
unlink $gbs_new_result_file;

return $result;
}




sub RUN_gbssub_script($)
{
my ($action,
) = @_;


ENV_sig( F => "'GBS_SUBSYS' Not defined")
if ($GBS::SUBSYS eq '');

my $command_spec = FSPEC_subsys_script( 'gbssub', $GBS::ROOT_PATH, $GBS::SUBSYS);

if (! -f $command_spec)
{
$command_spec = GBSGLO_short_filespecs( $command_spec);
ENV_sig( EE => "SubSystem '$GBS::SUBSYS' (non-GBS):",
"- No 'gbssub' command ($command_spec)");
}

my $full_command =  ENV_enquote( ENV_expand_envs( $command_spec));

return ENV_system( [ $full_command, $action ], undef);
}




sub RUN_browser($)
{
my ($filespec,
) = @_;
my $started;

my $fh = FLOCK_ex_wait( "$GBS::BASE_PATH/.browser.lck");
$started = run_env_command( GBS_BROWSER => $filespec);
sleep 1;		# give browser time to startup
FLOCK_unlock( $fh);

return $started;
}




sub RUN_editor($$)
{
my ($filespec,
$editor_opt,
) = @_;
my $started;


$started = run_env_command( GBS_EDITOR => $filespec, $editor_opt);

return $started;
}





sub RUN_viewer($)
{
my ($filespec,
) = @_;
my $started;


$started = run_env_command( GBS_VIEWER => $filespec);

return $started;
}





sub RUN_navigator($)
{
my ($start_location,
) = @_;
my $started;


$started = run_env_command( GBS_NAVIGATOR => $start_location);

return $started;
}




sub run_env_command($$;$)
{
my ($env_name,	    # GBS_BROWSER, GBS_EDITOR, GBS_NAVIGATOR, GBS_VIEWER
$filespec,
$options_or_ref,    # may be undef or ''
) = @_;
my $started = 1;


my @command_items = GBSCMD_get_env_command( $env_name, $filespec, $options_or_ref);
my $command = $command_items[0];
if ($XTERM_COMMANDS{$command})
{
PROC_spawn_detached_xterm( \@command_items, $filespec, 0, 130);   # no pause
} else
{
my $rc = ENV_system( "@command_items", [ 0, 1 ]);
if ($rc != 0)
{
ENV_sig( E => 'Unable to execute:', "  @command_items");
$started = 0;
}
}

return $started;
}




sub RUN_more($;@)
{
my ($filespec,
@options,
) = @_;

my $xtitle = ENV_split_spec_f( $filespec);

my $command = GBSCMD_get_os_command( 'more');

$filespec =~ s!/!\\!g
if ($IS_WIN32);

my $command_items_ref = [ $command, $filespec, @options ];
PROC_spawn_detached_xterm( $command_items_ref, $xtitle, 1, 120);    # pause
}




sub RUN_tail($;@)
{
my ($filespec,
@options,
) = @_;

my $xtitle = ENV_split_spec_f( $filespec);

my $command = GBSCMD_get_os_command( 'tail');

$filespec =~ s!/!\\!g
if ($IS_WIN32);

my $command_items_ref = [ $command, $filespec, @options ];
PROC_spawn_detached_xterm( $command_items_ref, $xtitle, 1, 120);	    # pause
}




sub RUN_terminal($$)
{
my ($path,
$title,
) = @_;

ENV_pushd( $path)
if (defined $path);

PROC_spawn_terminal( $title);

ENV_popd()
if (defined $path);
}




sub RUN_gbs($)
{
my ($start_path,
) = @_;

ENV_pushd( $start_path);
my ($shortcut_title, undef, $command_spec, $command_args) = GBSCMD_get_shortcut_command( 'Startup');
my $command = "$command_spec $command_args";
my $full_command;
if ($IS_WIN32)
{
$full_command = "start \"$shortcut_title\" $command";
} else
{
$full_command = $command;
}
ENV_system( $full_command, 0);
ENV_popd();
}




sub RUN_tkx($$$)
{
my ($name,		    # e.g.: gbsgui_tkx
$test_mode,
$args_ref,
) = @_;

if (GBSENV_gui_available())
{
my $command_items_ref = GBSCMD_get_gbs_command( $name => $args_ref);
my $rc;
if ($test_mode)
{
$rc = ENV_system( $command_items_ref, undef);
} else
{
$rc = PROC_spawn_detached( $command_items_ref, undef);
}
if ($rc == 0)
{
ENV_say( 1, "Launched")
if (!$test_mode);
} else
{
ENV_sig( E => "Could not startup '$name'. rc=$rc", "@{$command_items_ref}");
}
} else
{
ENV_sig( E => "Cannot proceed. Perl Tkx Package is not available");
}
}

1;


