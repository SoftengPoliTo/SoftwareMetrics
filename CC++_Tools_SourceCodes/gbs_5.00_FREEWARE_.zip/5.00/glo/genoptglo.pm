#=================================================
#
#   genoptglo.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::genoptglo;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GENOPTGLO_set_flag_prefix
GENOPTGLO_set_optdefs
GENOPTGLO_get_init_values
GENOPTGLO_get_mandatory_opt_names
GENOPTGLO_get_all_mnems
GENOPTGLO_opt_exists
GENOPTGLO_get_opt
GENOPTGLO_get_opt_item
GENOPTGLO_get_full_name
GENOPTGLO_get_full_spec
GENOPTGLO_make_opt
GENOPTGLO_conflicts
);
}




use glo::env;
use glo::types;




sub GENOPTGLO_set_flag_prefix($);
sub GENOPTGLO_set_optdefs($);
sub GENOPTGLO_get_init_values();
sub GENOPTGLO_get_mandatory_opt_names();
sub GENOPTGLO_get_all_mnems();
sub GENOPTGLO_opt_exists($);
sub GENOPTGLO_get_opt($);
sub GENOPTGLO_get_opt_item($$);
sub GENOPTGLO_get_full_name($);
sub GENOPTGLO_get_full_spec($);
sub GENOPTGLO_make_opt($$);
sub GENOPTGLO_conflicts($);












my @MNEMS_ORDER;    # mnems
my %ITEMS;





my @INIT_VALUES;

my @MANDATORY_OPT_NAMES;	    # mandatory items


my $FLAG_PREFIX = '--';









sub GENOPTGLO_set_flag_prefix($)
{
my ($prefix) = @_;

$FLAG_PREFIX = $prefix;
}




sub GENOPTGLO_set_optdefs($)
{
my ($items_refs_ref,	    # [ [ $mnem, $opt_name, $type_spec_or_ref, $default, $item_help_or_ref ], ... ]
) = @_;
my $highest_pos_par = 0;




























@MNEMS_ORDER = ();
%ITEMS = ();
@INIT_VALUES = ();
@MANDATORY_OPT_NAMES = ();




my @added_items_ref;
if ($FLAG_PREFIX ne '')
{
my $app_name = uc ENV_get_application_name();
my $default = ENV_getenv( "${app_name}DEBUG_VERBOSE");  # e.g.: GBSDEBUG_VERBOSE
$default = (defined $default && $default eq '1') ? 1 : 0;
push @added_items_ref, [ 'verbose', 'verbose', 'bso', $default, 'Extensive logging messages if 1. Always 1 in BATCH' ];
}




foreach my $item_ref (@{$items_refs_ref}, @added_items_ref)
{
my ($mnem, $opt_name, $type_spec_or_ref, $default, $item_help_or_ref) = @{$item_ref};

my ($type, $occur, $manda, $constr, $constr_values_ref) = TYPES_split_and_validate( $type_spec_or_ref);
my $type_spec_ref = [$type, $occur, $manda, $constr, $constr_values_ref];

{
my ($init_value_or_ref);
if ($occur eq 'a')	    # array
{
if ($default eq '')
{
$init_value_or_ref = [];
} else
{
$init_value_or_ref = [ split( /,/, $default) ];
}
} else  # $occur eq 's'
{
$init_value_or_ref = $default;
}
push @INIT_VALUES, ($opt_name, $init_value_or_ref);
}

push @MANDATORY_OPT_NAMES, $opt_name
if ($manda eq 'm');

if (substr( $mnem, 0, 1) eq '<')
{
ENV_sig( F => "Invalid positional mnemonic '$mnem' (Must be <n> or <*>")
if ($mnem !~ /^<(\d+|\*)>$/);	# <n>, <*>
my $pos_par = $1;
$highest_pos_par = $pos_par
if ($pos_par ne '*' && $pos_par > $highest_pos_par);
}

my $item_help_ref;
$item_help_ref = (ref $item_help_or_ref) ? $item_help_or_ref : [ $item_help_or_ref ]
if (defined $item_help_or_ref);
my $items_refs_ref = [ $mnem, $opt_name, $type_spec_ref, $default, $item_help_ref ];


ENV_sig( F => "ITEMS: opt_name '$opt_name' already exists")
if (exists $ITEMS{$opt_name});
$ITEMS{$opt_name} = $items_refs_ref;
if ($mnem ne $opt_name)
{
ENV_sig( F => "ITEMS: mnem '$mnem' already exists")
if (exists $ITEMS{$mnem});
$ITEMS{$mnem} = $items_refs_ref;
}

push @MNEMS_ORDER, $mnem;
}



return $highest_pos_par;
}




sub GENOPTGLO_get_init_values()
{
return @INIT_VALUES;

}




sub GENOPTGLO_get_mandatory_opt_names()
{

return @MANDATORY_OPT_NAMES;
}




sub GENOPTGLO_get_all_mnems()
{

return @MNEMS_ORDER;
}




sub GENOPTGLO_opt_exists($)
{
my ($mnem_or_name,	    # <n>, <*> or $opt_name
) = @_;


my $opt_items_ref = $ITEMS{$mnem_or_name};

return (defined $opt_items_ref) ? 1 : 0;
}




sub GENOPTGLO_get_opt($)
{
my ($mnem_or_name,	    # <n>, <*> or $opt_name
) = @_;


my $opt_items_ref = $ITEMS{$mnem_or_name};
ENV_sig( F => "Option '$mnem_or_name' does not exist")
if (!defined $opt_items_ref);

ENV_stackdump()
if (!ref $opt_items_ref);


return @{$opt_items_ref};
}




sub GENOPTGLO_get_opt_item($$)
{
my ($mnem_or_name,	    # <n>, <*> or $opt_name
$item_index,
) = @_;


my $opt_items_ref = $ITEMS{$mnem_or_name};
ENV_sig( F => "Option '$mnem_or_name' does not exist")
if (!defined $opt_items_ref);
my $item_or_ref = $opt_items_ref->[$item_index];

return (ref $item_or_ref) ? @{$item_or_ref} : $item_or_ref;
}




sub GENOPTGLO_get_full_name($)
{
my ($mnem_or_name,	    # <n>, <*> or $opt_name
) = @_;
my $full_name;

my ($mnem, $opt_name) = @{$ITEMS{$mnem_or_name}};
$full_name = ($mnem =~ /^</) ? "<$opt_name>" : "$FLAG_PREFIX$mnem";	    # <n>, <*> or $opt_name

return $full_name;
}




sub GENOPTGLO_get_full_spec($)
{
my ($mnem_or_name,	    # <n>, <*> or $opt_name
) = @_;



my $items_ref = $ITEMS{$mnem_or_name};
ENV_sig( F => "Unknown mnem_or_name '$mnem_or_name'")
if (!defined $items_ref);
my ($mnem, $opt_name, $type_spec_ref) = @{$items_ref};
if (wantarray)
{
my ($type, $occur, $man, $constr, $constr_values_ref) = @{$type_spec_ref};

my $full_spec;
if ($mnem =~ /^</)	# <n>, <*>
{
$full_spec = $mnem;
} else
{
$full_spec = "$FLAG_PREFIX$mnem" . (($type eq 'b') ? '[+|-]' : "=<$opt_name>");
}
my $full_type = TYPES_type_text( $type);
my $full_occur = TYPES_occur_text( $occur);
my $full_man = TYPES_manda_text( $man);
my $full_constr = TYPES_constr_text( $constr, $constr_values_ref);
my $default = $items_ref->[3];
my $item_help_ref = $items_ref->[4];
my @help_lines = (defined $item_help_ref) ? @{$item_help_ref} : ();

return ( $full_spec, $opt_name, $mnem, $full_type, $full_occur, $full_man, $full_constr, $default, @help_lines );
} else
{
my ($type, $occur, $man) = @{$type_spec_ref};

my $full_spec;
if ($mnem =~ /^</)	# <n>, <*>
{
$full_spec = "<$opt_name>";
$full_spec = "$full_spec..."
if ($occur eq 'a');
} else
{
$full_spec = "$FLAG_PREFIX$mnem" . (($type eq 'b') ? '[+|-]' : "=<$opt_name>");
$full_spec = "$full_spec,..."
if ($occur eq 'a');
}
$full_spec = "[$full_spec]"
if ($man eq 'o');

return $full_spec;
}
}




sub GENOPTGLO_make_opt($$)
{
my ($mnem_or_name,
$value_or_ref,
) = @_;
my $opt;

my ($mnem, $opt_name, $type_spec_ref) = @{$ITEMS{$mnem_or_name}};
my $type = $type_spec_ref->[0];     # $type_spec->$type


my $value = (defined $value_or_ref && ref $value_or_ref) ? join( ',', @{$value_or_ref}) : $value_or_ref;
if (substr( $mnem, 0, 1) eq '<')
{
$opt = $mnem;
if ($value)
{
$opt .= "=$value";
}
} else
{
$opt = "$FLAG_PREFIX$mnem";
if ($type eq 'b')
{
if (!defined $value)
{
$value = '';
} elsif ($value eq '' || $value eq '+' || $value eq '1')
{
$value = '+';
} else
{
$value = '-';
}
$opt .= $value;
} else
{
if (defined $value)
{
$opt .= "=$value";
}
}
}


return $opt;


}




sub GENOPTGLO_conflicts($)
{
my ($con_refs_ref,	# [ [ $mnem, @values ], @r_args_or_refs ], ... ]



) = @_;
my @conflict_refs;






foreach my $con_ref (@{$con_refs_ref})
{
my ($l_arg_ref, @r_args_or_refs) = @{$con_ref};	    # [ $mnem, @values ], @r_args_or_refs
ENV_sig( F => "'l_arg' must be defined")
if (!defined $l_arg_ref);
$l_arg_ref = [ $l_arg_ref ] unless (ref $l_arg_ref);

my $l_arg = $l_arg_ref->[0];
ENV_sig( F => "No such mnem '$l_arg'")
if (!exists $ITEMS{$l_arg});

my @conflicts = ($l_arg_ref);
while (@r_args_or_refs)
{
my $r_arg_refs = shift @r_args_or_refs;	# $operator or [ $operator, $mnem, @values ]
if (!ref $r_arg_refs)
{
my $r_arg = shift @r_args_or_refs;	# $mnem
$r_arg_refs = [ $r_arg_refs, $r_arg ];
}

my ($operator, $mnem) = @{$r_arg_refs};
ENV_sig( F => "'operator' must be '=' or '!'")
if ($operator ne '=' && $operator ne '!');
ENV_sig( F => "'mnem' must be defined")
if (!defined $mnem);
ENV_sig( F => "No such mnem '$mnem'")
if (!exists $ITEMS{$mnem});
push @conflicts, $r_arg_refs;
}
push @conflict_refs, [ @conflicts ];
}


return @conflict_refs;
}

1;
