#=================================================
#
#   gbsbgscasub.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbsbgscasub;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSBGSCASUB_init
GBSBGSCASUB_file_store
);
}




use glo::env;
use glo::depend;
use mod::gbsglo;
use mod::flincs;
use mod::scaglo;
use mod::scadef;
use mod::scamsg;
use mod::scafile;
use mod::sca;




sub GBSBGSCASUB_init($$$);
sub GBSBGSCASUB_file_store($$$$$);

sub path_is_not_quieted($);
sub find_hash_include_line($$);
sub parse_source($);




my ($MUST_SHOW_STDOUT) = ENV_getenv( 'GBS_AUDIT_OPTIONS');	# from gbsaudit-option: --stdout (show_stdout)








my $PLUGIN_NAME_UC;
my $COMPONENT;
my $SRC_PATH;




my %SPECWS;






my %LEVELS_BY_LEVEL;



my %SPECIAL_MSG_IDS;	    # Fatal and SPECWS


my $STDOUT_FORMAT_NAME;	    # from sca_<audit>.gbs (PCLINT, PRQA, VISUAL_C, ECLIPSE, GNU_C, etc)

my @QUIET_PATHS;	    # Perl paths
my %QUIET_FILE_SPECS;	    # cache





my $SOURCE_FILE_SPEC;
my $SRC_TYPE;
my %INCLUDE_SRC_LINE;





sub GBSBGSCASUB_init($$$)
{
my ($plugin_name,
$component,
undef,
) = @_;

$PLUGIN_NAME_UC = uc $plugin_name;
$COMPONENT = $component;

$SRC_PATH = ENV_cwd();




%SPECWS = map { @{$_} } @{SCADEF_get_section_items( $GBS::AUDIT_PLUGIN, MESSAGES => 'SPECIAL')};
%LEVELS_BY_LEVEL = SCADEF_get_levels_by_level( $GBS::AUDIT_PLUGIN);




SCAMSG_read_file();
{
my @all_msg_ids;
my @fatal_msg_ids;
foreach my $ref (SCAMSG_get_msgs_and_levels())
{
my ($msg_id, $level) = @{$ref};

push @all_msg_ids, $msg_id;
push @fatal_msg_ids, $msg_id
if ($LEVELS_BY_LEVEL{$level}->[3] == 2);	    # $severity_index == Fatal Error
}
SCA_init( \@all_msg_ids, \@fatal_msg_ids, [ keys %SPECWS ]);
%SPECIAL_MSG_IDS = map { $_ => 1 } (@fatal_msg_ids, keys %SPECWS);
SCA_read_msgs( $GBS::SUBSYS);
}




{







my $build_plugin_path = ENV_getenv_perl_path( "GBSEXT_${GBS::BUILD_PLUGIN}_PATH");
ENV_sig( EE => "GBSEXT_${GBS::BUILD_PLUGIN}_PATH is not defined")
if ($build_plugin_path eq '');
@QUIET_PATHS = (
$build_plugin_path,
"$GBS::ROOT_PATH/res",
"$GBS::ROOT_PATH/ext",
SCA_get_quiet_paths(),
);

}




$STDOUT_FORMAT_NAME = SCA_get_format_name();
$STDOUT_FORMAT_NAME = $PLUGIN_NAME_UC
if ($STDOUT_FORMAT_NAME eq 'DEFAULT');

return @QUIET_PATHS;
}




sub GBSBGSCASUB_file_store($$$$$)
{
my ($src_file,
$unix_style_search,
$warning_refs_ref,





$total_refs_ref,


$metric_refs_ref,

) = @_;
my $rc = 0;	    # 1 = contains FATAL warnings, 2 = Execution error

$SOURCE_FILE_SPEC = "$SRC_PATH/$src_file";
$SRC_TYPE = ENV_split_spec_t( $src_file);
%INCLUDE_SRC_LINE = ();

SCAFILE_init( $GBS::SUBSYS, $COMPONENT, $src_file);

my $worst_severity_index = -1;	#   'IWF' (-1 = none, 0 = Info, 1 = Warnings, 2 = (Fatal) Error




{



my @warning_refs;
my @selected_warning_refs;
my @l_counts;			    # used for reporting only
my %m_counts;

foreach my $ref (@{$warning_refs_ref})
{

my ($src_line_nr, $col_nr, $os_filespec, $line_nr, $msg_level, $level_text, $msg_id, $msg_text,
$help_file_url, @extra_src_lines ) = @{$ref};


if (SCAMSG_msg_exists( $msg_id))
{

$msg_level = SCAMSG_get_msg_data_element( $msg_id, 1)	# $level
if ($msg_level eq '');
$level_text = SCAMSG_get_msg_data_element( $msg_id, 2)	# $level_text
if ($level_text eq '');
$help_file_url = SCAMSG_get_msg_data_element( $msg_id, 4);	# $help_file_url
} else
{



($msg_level, $level_text, $help_file_url) = SCAGLO_handle_unkn_msg( $msg_id, $msg_level, $level_text);
SCAMSG_add_msg( [$msg_id, $msg_level, $level_text, "*$msg_text", $help_file_url ]);
SCA_add_msg( $msg_id);  # Memory only
ENV_say( 1, "$PLUGIN_NAME_UC: *****");
ENV_say( 1, "$PLUGIN_NAME_UC: Message id: '$msg_id' added");
ENV_say( 1, "$PLUGIN_NAME_UC: $msg_level, $level_text, $help_file_url");
ENV_say( 1, "$PLUGIN_NAME_UC: '*$msg_text'");
ENV_say( 1, "$PLUGIN_NAME_UC: *****");
}
my $severity_index = $LEVELS_BY_LEVEL{$msg_level}->[3];   # 'IWF' (-1 = none, 0 = Info, 1 = Warnings, 2 = (Fatal) Error


if ( $severity_index == 2 || path_is_not_quieted( $os_filespec))
{
if (exists $SPECIAL_MSG_IDS{$msg_id})
{
ENV_sig( W => "Suppressed special message $msg_id in $os_filespec, line $line_nr");
} else
{

$src_line_nr = find_hash_include_line( $os_filespec, $unix_style_search)
if ($src_line_nr == -1);

my @warning_items = ( $src_line_nr, $col_nr, $os_filespec, $line_nr, $msg_level, $level_text, $msg_id, $msg_text,
$help_file_url, @extra_src_lines );
push @warning_refs, \@warning_items;
if (SCA_msg_is_enabled( $msg_id))
{
push @selected_warning_refs, \@warning_items;
$l_counts[$msg_level]++;


$worst_severity_index = $severity_index
if ($severity_index > $worst_severity_index);
} else
{
if (exists $SPECIAL_MSG_IDS{$msg_id})
{
ENV_sig( W => "Suppressed special message $msg_id in $os_filespec, line $line_nr");
}
}




$m_counts{$msg_id} = [ $msg_level, $msg_id, 0, 0 ]
if (!exists $m_counts{$msg_id});
if ($os_filespec eq '-')	    # in source
{
$m_counts{$msg_id}->[2]++;	    # $s_msg_count
}
$m_counts{$msg_id}->[3]++;	    # $t_msg_count




my $specw_text = $SPECWS{$msg_id};
if (defined $specw_text)
{
my ($arg) = $msg_text =~ /'(.*)'/;	    # e.g.: include file name
$arg = ''
if (!defined $arg);
SCAFILE_gmet_put_specw( $specw_text, $arg);
}
}
} else
{


}
}




SCAMSG_write_file( 0);		# $force_write == 0




SCAFILE_gerr_write( \@warning_refs);




foreach my $msg_id (sort( { $a cmp $b} keys( %m_counts)))
{
my ($level, $msg_id, $s_msg_count, $t_msg_count) = @{$m_counts{$msg_id}};
SCAFILE_gmet_put_count( $level, $msg_id, $s_msg_count, $t_msg_count);
}




if ($MUST_SHOW_STDOUT || $worst_severity_index == 2)
{
if ($STDOUT_FORMAT_NAME eq 'NONE')
{
if ($worst_severity_index == 2)	    # 2 == Fatal
{
my @fatal_warning_refs = grep $LEVELS_BY_LEVEL{$_->[4]}->[1] eq 'F', @selected_warning_refs;	    # $msg_level
SCAFILE_write_stdout( $SOURCE_FILE_SPEC, $PLUGIN_NAME_UC, \@fatal_warning_refs);
} else
{

}
} else
{
SCAFILE_write_stdout( $SOURCE_FILE_SPEC, $STDOUT_FORMAT_NAME, \@selected_warning_refs);
}
}




ENV_say( 1, "$PLUGIN_NAME_UC: $src_file");

my $nr_warnings = @warning_refs;
my $nr_selected_warnings = @selected_warning_refs;
ENV_say( 1, "$PLUGIN_NAME_UC:   Selected warnings: $nr_selected_warnings (Total warnings: $nr_warnings)");

if ($nr_selected_warnings > 0)
{
my @count_texts;
for (my $i = 0; $i < @l_counts; $i++)
{
push @count_texts, "$LEVELS_BY_LEVEL{$i}->[2]=$l_counts[$i]"
if (defined $l_counts[$i]);
}
ENV_say( 1, "$PLUGIN_NAME_UC:   - Nr Msgs: " . join( ', ', @count_texts) . "");
ENV_say( 1, "$PLUGIN_NAME_UC:   - Worst Severity: " . uc( SCADEF_get_severity_text( $worst_severity_index)) . "");
}
}
$rc = 1
if ($worst_severity_index >= 2);	    # FATALs




{



foreach my $ref (@{$total_refs_ref})
{
my ($id, $source_count, $total_count) = @{$ref};
SCAFILE_gmet_put_total( $id => $source_count, $total_count);
}




foreach my $ref (@{$metric_refs_ref})
{
my ($metric_name, $min, $max, $total) = @{$ref};
SCAFILE_gmet_put_stat( $metric_name => $min, $max, $total);
}




SCAFILE_gmet_write( $worst_severity_index);
}

return $rc;
}




sub path_is_not_quieted($)
{
my ($os_filespec) = @_;
my $is_ok = 1;

if ($QUIET_FILE_SPECS{$os_filespec})
{

$is_ok = 0;
} else
{
my $filespec = $os_filespec;
$filespec =~ tr!\\!/!;	    # perl path

foreach my $ignore_path (@QUIET_PATHS)
{

if (ENV_is_in_path( $filespec, $ignore_path))
{
$is_ok = 0;
$QUIET_FILE_SPECS{$os_filespec} = 1;

last;
}
}
}

return $is_ok;
}




sub find_hash_include_line($$)
{
my ($os_inc_filespec,
$unix_style_search,	# bool
) = @_;
my $src_line_nr;


if (!%INCLUDE_SRC_LINE)
{
parse_source( $unix_style_search);
}
my @file_elements = split( '/', ENV_perl_canon_paths( $os_inc_filespec));
my $file = pop @file_elements;
do
{
$src_line_nr = $INCLUDE_SRC_LINE{$file};
$file = pop( @file_elements) . "/$file";
} while (!defined $src_line_nr && @file_elements);

if (!defined $src_line_nr)
{
$src_line_nr = 0;
ENV_sig( W => "$PLUGIN_NAME_UC: Error: INCLUDE NOT FOUND:", "$file in", $os_inc_filespec);
}

return $src_line_nr;
}




sub parse_source($)
{
my ($unix_style_search,	# bool
) = @_;



my @inc_paths = ENV_abs_paths( $SRC_PATH, [ FLINCS_get_incs( $SRC_TYPE, $COMPONENT),    # inc
FLINCS_get_sysincs( $SRC_TYPE)]);	    # sysinc
my @stubs_paths = FLINCS_get_stubs_incs();

my $cur_src_line_nr = 0;
my ($nr_errors, $nr_warnings, @depend_refs) = DEPEND_c( $SOURCE_FILE_SPEC, $unix_style_search,
\@inc_paths, \@stubs_paths, undef);
ENV_sig( E => "$nr_errors error(s) found while parsing $SOURCE_FILE_SPEC")
if ($nr_errors > 0);
ENV_sig( W => "$nr_warnings warning(s) found while parsing $SOURCE_FILE_SPEC")
if ($nr_warnings > 0);

foreach my $ref (@depend_refs)
{
my ($level, $found, $line_nr, $inc_type, $inc_name, $inc_filespec) = @{$ref};

if ($found eq 'F')
{
$cur_src_line_nr = $line_nr
if ($level == 0);
$INCLUDE_SRC_LINE{$inc_name} = $cur_src_line_nr;
my $short_inc_filespec = GBSGLO_short_filespecs( $inc_filespec);

} elsif ($found eq 'S')
{
my $short_inc_filespec = GBSGLO_short_filespecs( $inc_filespec);

} else  # ($found eq 'N')
{

my $calling_filespec = $inc_filespec;
my $short_calling_filespec = GBSGLO_short_filespecs( $calling_filespec);
ENV_say( 1, "$PLUGIN_NAME_UC: ** $inc_name not found - ignored - $short_calling_filespec($line_nr)");
}
}

}

1;

