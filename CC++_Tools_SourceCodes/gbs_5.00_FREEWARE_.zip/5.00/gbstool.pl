#=================================================
#
#   gbstool.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSTOOL @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::genopt;
use mod::gbsenv;
use mod::gbsoptenv;
use mod::gbsfilecom;
use mod::gbsglo;
use mod::validate;
use mod::swt;
use mod::run;
use mod::fail;
use mod::tool;




sub do_tool();
sub do_view();




my $GBS_SILO_TOOLS_PATH = "$GBS::SILO_PATH/tools";

my $GBS_SILO_TOOL_PATH;
my $SUM_FILESPEC;






$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ '<1>',    'tool',		'ssm',  '', "tool" ],
[ 'i',      'ignore_errors',	'bso',   0, "Continue auditing after error(s)" ],
[ 'vs',     'view_sum',		'bso',   1, "View summary at completion" ],
[ 'jobs',   'jobs',	   'isor1..9',   2, 'Max. nr. parallel jobs' ],
);
my @genenvs = qw( LOG_PATH MODE FLAGS_* APP_* );
GENOPT_set_optdefs( 'gbstool', \@genopts,
'Run a TOOL on the whole System',
undef);
GENOPT_set_envdefs( \&GBSOPTENV_set, \&GBSOPTENV_print, \@genenvs);
GENOPT_parse();
}
my $TOOL = GENOPT_get( 'tool');
my $IGNORE_ERRORS = GENOPT_get( 'ignore_errors');
my $MUST_VIEW_SUM = GENOPT_get( 'view_sum');
my $JOBS = GENOPT_get( 'jobs');			    ## noperlcheck




ENV_setenv( GBS_IGNORE_ERRORS => $IGNORE_ERRORS);




VALIDATE_root();    # Also validates GBS

$GBS_SILO_TOOL_PATH = "$GBS_SILO_TOOLS_PATH/$TOOL";
$SUM_FILESPEC = "$GBS_SILO_TOOL_PATH/index.html";




{
do_tool();

if ($RC == 0 || $IGNORE_ERRORS)
{
do_view();
} else
{
ENV_say( 1, "View Summary not executed (rc=$RC)");
}
}




ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
}




sub do_tool()
{



if ($TOOL ne $GBS::TOOL)
{
SWT_set( $TOOL, 1);
}




my ($action_name, $action_value) = TOOL_get_action( $GBS::TOOL);




ENV_mkdir( $GBS_SILO_TOOLS_PATH);
ENV_mkdir( $GBS_SILO_TOOL_PATH);




my @subsystems;
foreach my $subsys (GBSGLO_subsystems_for_tool( $GBS::TOOL))
{
my $ss_type = GBSGLO_subsystem_type( $subsys);
push @subsystems, "$subsys:$ss_type";
}





ENV_say( 1, "** Running Tool $GBS::TOOL...",
"** ACTION=$action_name ($action_value)");





my $subsys_def_list = join( ',', @subsystems);
my @pos_args = ($action_value,
$subsys_def_list,
ENV_shortest_paths( '.', $SUM_FILESPEC),
ENV_shortest_paths( '.', $GBS_SILO_TOOL_PATH)
);
my $command_line_flags_ref = [];
my @command_data_refs = TOOL_get_command_data_refs_exp( $GBS::TOOL, \@pos_args, $command_line_flags_ref);







$RC = GBSFILECOM_exec( 1, \@command_data_refs);
if ($RC != 0)
{
FAIL_log( 'gbstool', $RC, '', '', '');
}
ENV_say( 0, '-');
}




sub do_view()
{
if (-e $SUM_FILESPEC)
{
if ($MUST_VIEW_SUM)
{
ENV_say( 1, "View Summary file");
ENV_say( 2, "Starting Browser...");
RUN_browser( $SUM_FILESPEC);
}
} else
{
ENV_say( 1, "No Summary generated (rc=$RC)...",
$SUM_FILESPEC);
}
}


