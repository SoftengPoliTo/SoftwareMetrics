#=================================================
#
#   scmcc.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
#   File states:
#    -2 => 'NO-FILE',
#    -1 => 'NOT-CCM',
#     0 => 'CHECKED-IN',
#     1 => 'CHECKED-OUT',
#=================================================
package glo::scmcc;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SCMCC_init
SCMCC_connect
SCMCC_get_states
SCMCC_checkout
SCMCC_uncheckout
SCMCC_checkin
SCMCC_remove
SCMCC_move
SCMCC_add_dirs
SCMCC_add_files
SCMCC_setup
);
}




use glo::env;
use glo::ask;
use glo::slurp;
use glo::file;

ENV_whisper( 1, "Loading ClearCase Plugin...");




sub SCMCC_init($$);
sub SCMCC_connect($$$);
sub SCMCC_get_states($);
sub SCMCC_checkout($);
sub SCMCC_uncheckout($);
sub SCMCC_checkin($);
sub SCMCC_remove($);
sub SCMCC_move($);
sub SCMCC_add_dirs($);
sub SCMCC_add_files($);
sub SCMCC_setup($$$);

sub checkout_parents($);
sub get_state($);
sub move_dir_contents($$);

sub exec_pwv();
sub exec_desc($);
sub exec_checkout($);
sub exec_checkin($);
sub exec_unco($);
sub exec_rmname($);
sub exec_mv($$);
sub exec_mkdir($);
sub exec_mkelem($);




my $APP_NAME;


my $EXEC_OS = 'cc';

my %FSTATES;





sub SCMCC_init($$)
{
($APP_NAME,
$EXEC_OS) = @_;
}





sub SCMCC_connect($$$)
{
(undef,		    # $REPOSITORY
undef,		    # $APP_ROOT_PATH
undef) = @_;	    # $DATA
my $connect_texts_ref;





$connect_texts_ref = exec_pwv();
%FSTATES = ();	    # clear previous file-states

return ( undef, undef, $connect_texts_ref );
}








sub SCMCC_get_states($)
{
my ($spec_refs_ref) = @_;

my @specs;
foreach my $spec_ref (@{$spec_refs_ref})
{
my ($spec, $state) = @{$spec_ref};
if (!defined $state)	    # $state may be -2 (no such file/dir)
{
push @specs, $spec
if (!defined $FSTATES{$spec});
}
}

exec_desc( \@specs)
if (@specs);

foreach my $spec_ref (@{$spec_refs_ref})
{
my ($spec, $state) = @{$spec_ref};
$spec_ref->[1] = $FSTATES{$spec}
if (!defined $state)
}
}




sub SCMCC_checkout($)
{
my ($specs_ref) = @_;

exec_checkout( $specs_ref);

map { $FSTATES{$_} = 1 } @{$specs_ref}; # checkout
}




sub SCMCC_checkin($)
{
my ($specs_ref) = @_;

exec_checkin( $specs_ref);

map { $FSTATES{$_} = 0 } @{$specs_ref}; # checkin
}




sub SCMCC_uncheckout($)
{
my ($specs_ref) = @_;

exec_unco( $specs_ref);

map { $FSTATES{$_} = 0 } @{$specs_ref}; # checkin
}




sub SCMCC_remove($)
{
my ($specs_ref) = @_;

checkout_parents( $specs_ref);
exec_rmname( $specs_ref);

map { $FSTATES{$_} = -1 } @{$specs_ref}; # notscm
}




sub SCMCC_move($)
{
my ($pair_refs_ref) = @_;
foreach my $ref (@{$pair_refs_ref})
{
my ($old_spec, $new_spec) = @{$ref};
ENV_chmod( 'u+w', $old_spec);
exec_mv( $old_spec, $new_spec);
$FSTATES{$old_spec} = -1;	# notscm
$FSTATES{$new_spec} = 1;    	# checkout
}

}




sub SCMCC_add_dirs($)
{
my ($dir_refs_ref) = @_;	#	[ $dir, $ignores_ref ]




my @dir_specs;
foreach my $ref (@{$dir_refs_ref})
{
my ($dir, undef) = @{$ref};
checkout_parents( [ $dir ]);
if (-d $dir)
{



my $temp_dir = "$dir.scm.tmp";
ENV_rename( $dir, $temp_dir);
exec_mkdir( $dir);
ENV_sig( F => "no dir $dir\n")
if (!-d $dir);
$FSTATES{$dir} = 1;
move_dir_contents( $temp_dir, $dir);
ENV_rmdir( $temp_dir);
} else
{
exec_mkdir( $dir);
$FSTATES{$dir} = 1;
}
push @dir_specs, $dir;
}


}




sub SCMCC_add_files($)
{
my ($files_ref) = @_;

checkout_parents( $files_ref);
exec_mkelem( $files_ref);

map { $FSTATES{$_} = 1 } @{$files_ref}; # checkout
}




sub SCMCC_setup($$$)
{
my (undef,				# $app_root_path
undef,				# $default_scms_repository,
undef,				# $default_scms_data
) = @_;
my ($scms_repository, $scms_data) = ( '', '' );

ENV_say( 1, 'You now have the opportunity to make sure that ClearCase is up and running,',
'the database is setup and the new root is mapped to it');
ENV_exit(0)
if (ASK_YNQ( 'Ready to continue? (No will cause a Quit)', 'Y', 1) eq 'N');

return ($scms_repository, $scms_data);
}




sub checkout_parents($)
{
my ($specs_ref) = @_;

my %parents;
foreach my $spec (@{$specs_ref})
{
my $parent = ENV_parent_path( $spec);
my $state = get_state( $parent);
if ($state != 1)    # checkedout
{
$parents{$parent} = 1;	# skip duplicates
}
}
if (%parents)
{
my @dirs = keys %parents;
SCMCC_checkout( \@dirs);
}
}




sub get_state($)
{
my ($spec) = @_;
my $state;

$state = $FSTATES{$spec};
if (!defined $state)
{
exec_desc( [ $spec ]);
$state = $FSTATES{$spec};
}
return $state;
}




sub move_dir_contents($$)
{
my ($from_dir,
$to_dir,
) = @_;




foreach my $file (SLURP_dir_all( $from_dir, 1))
{
FILE_move( "$from_dir/$file", "$to_dir/$file", 0);  # $verbose_level = 0
}
}







sub exec_pwv()
{
my @connect_texts;

my $stdout;
my $command = "$EXEC_OS pwv";
ENV_run3( $command, undef, [0], \$stdout, undef);
if ($stdout !~ qr/^Working directory view: [^*][^*]/)
{
ENV_print( 0, $stdout);
ENV_sig( F => "Failed to start ClearCase session");
}
@connect_texts = split( '\n', $stdout);

return [ @connect_texts ];
}








sub exec_desc($)
{
my ($specs_ref) = @_;

foreach my $spec (@{$specs_ref})
{
my $stdout;
my $command = "$EXEC_OS desc -s $spec";
ENV_run3( $command, undef, [0], \$stdout, undef);
$stdout =~ s/\s+//g;    #remove trailing white space	    ??????
if ($stdout =~ /^$spec($|@@)/)
{

my $state;
if ($stdout eq $spec)
{
$state = -1;	    # not SCM
} elsif ($stdout =~ /CHECKEDOUT$/)
{
$state = 1; 	    # checked_out
} else
{
$state = 0; 	    # checked_in
}
$FSTATES{$spec} = $state;
} else
{
ENV_print( 0, $stdout);
ENV_sig( EE => "Invalid descr reply");
}
}
}







sub exec_checkout($)
{
my ($specs_ref) = @_;

my $command = "$EXEC_OS co -c \"CheckOut by $APP_NAME\"";
ENV_run3( $command, $specs_ref, [0], undef, undef);
}







sub exec_checkin($)
{
my ($specs_ref) = @_;

my $command = "$EXEC_OS ci -c \"Checkin by $APP_NAME\"";
ENV_run3( $command, $specs_ref, [0], undef, undef);
}









sub exec_unco($)
{
my ($specs_ref) = @_;

my $command = "$EXEC_OS unco -rm";
ENV_run3( $command, $specs_ref, [0], undef, undef);
}








sub exec_rmname($)
{
my ($specs_ref) = @_;


my $command = "$EXEC_OS rmname -c \"Deleted by $APP_NAME\"";
ENV_run3( $command, $specs_ref, [0], undef, undef);
}








sub exec_mv($$)
{
my ($old_spec,
$new_spec,
) = @_;


my $command = "$EXEC_OS mv -c  \"Moved by $APP_NAME\" $old_spec $new_spec";
ENV_run3( $command, undef, [0], undef, undef);
}








sub exec_mkdir($)
{
my ($spec) = @_;

my $command = "$EXEC_OS mkdir -c \"Created by $APP_NAME\" $spec";
ENV_run3( $command, undef, [0], undef, undef);
}








sub exec_mkelem($)
{
my ($specs_ref) = @_;

my $command = "$EXEC_OS mkelem -c \"Created by $APP_NAME\"";
ENV_run3( $command, $specs_ref, [0], undef, undef);
}

1;

