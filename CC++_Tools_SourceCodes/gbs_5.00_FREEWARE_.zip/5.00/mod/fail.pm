#=================================================
#
#   fail.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::fail;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
FAIL_filespec
FAIL_log
FAIL_read
);
}




use glo::spit;
use glo::slurp;
use mod::gbsenv;




sub FAIL_filespec();
sub FAIL_log($$$$$);
sub FAIL_read();

sub get_filespec();




my $FAIL_FILE_SPEC;




sub FAIL_filespec()
{
get_filespec()
if (!defined $FAIL_FILE_SPEC);


return $FAIL_FILE_SPEC;
}




sub FAIL_log($$$$$)
{
my ($command_name,
$rc,
$subsys,
$component,
$file,
) = @_;

$subsys = '-'
if (!$subsys);
$component = '-'
if (!$component);
$file = '-'
if (!$file);

get_filespec()
if (!defined $FAIL_FILE_SPEC);

SPIT_append_file_nl( $FAIL_FILE_SPEC,
"**FAILED: $command_name ($rc): $subsys $component $file");
}




sub FAIL_read()
{
my @lines;

get_filespec()
if (!defined $FAIL_FILE_SPEC);

if (-f $FAIL_FILE_SPEC)
{
@lines = SLURP_file( $FAIL_FILE_SPEC);
}

return @lines;
}




sub get_filespec()
{
if (GBSENV_mode_is_background())
{
$FAIL_FILE_SPEC = "$ENV{GBS_LOGFILE}.err";
} else
{
$FAIL_FILE_SPEC = join( '_', "$GBS::TMP_PATH/fail", "$GBS::EXEC_ID.err");
}

}

1;



