#=================================================
#
#   gbsres.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbsres;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSRES_title
GBSRES_title_html
GBSRES_company_html
GBSRES_numtime_packed
GBSRES_logfile
GBSRES_split_logfile_spec
GBSRES_join_logfile_spec
GBSRES_get_logfile_numtime
GBSRES_skiptypes
);
}




use glo::env;
use glo::time;




sub GBSRES_title();
sub GBSRES_title_html();
sub GBSRES_company_html();
sub GBSRES_numtime_packed();
sub GBSRES_logfile($$$);
sub GBSRES_split_logfile_spec($;$);
sub GBSRES_join_logfile_spec($$$$);
sub GBSRES_get_logfile_numtime($);
sub GBSRES_skiptypes();




my $TIME;		    # Do not initialize!
my $NUMTIME_PACKED;	    # Do not initialize!

my $TITLE = "G E N E R I C    B U I L D    S U P P O R T";
my $COMPANY = "Randy Marques Consultancy";





sub GBSRES_title()
{
return "$TITLE  -  $COMPANY";
}




sub GBSRES_title_html()
{
my $title = $TITLE;
$title =~ s/   /&nbsp;&nbsp;&nbsp;/g;

return $title;
}




sub GBSRES_company_html()
{
my $company = $COMPANY;
$company =~ s/ /&nbsp;/g;

return $company;
}




sub GBSRES_numtime_packed()
{
if (!defined $NUMTIME_PACKED)
{
$TIME = time
if (!defined $TIME);
$NUMTIME_PACKED = TIME_time2num_packed( $TIME);
}
return $NUMTIME_PACKED;
}




sub GBSRES_logfile($$$)
{
my ($jobname,
$build_or_tool,
$audit,		    # May be '-'
) = @_;
my $logfile_spec;

$logfile_spec = GBSRES_join_logfile_spec( $jobname, $build_or_tool, $audit, $NUMTIME_PACKED);

return $logfile_spec;
}




sub GBSRES_join_logfile_spec($$$$)
{
my ($jobname,
$build_or_tool,
$audit,		    # May be '-'
$num_time,
) = @_;
my $logfile_spec;

my $log_name = join( '_', ($jobname, $build_or_tool, $audit, $num_time));
$logfile_spec = "$GBS::LOG_PATH/$log_name.log";

return $logfile_spec;
}




sub GBSRES_split_logfile_spec($;$)
{
my ($logfile_spec,
$sig_on_error,  # Optional: <severity><action> IWEF  EC. Default = 'F',
) = @_;
my ($jobname, $build_or_tool, $audit, $numtime);

my $logfile = ENV_split_spec_n( $logfile_spec);
( $jobname, $build_or_tool, $audit, $numtime ) = $logfile =~ /^([^_]+)_(.*)_(.*)_(\d{6,8}-\d{6})($|_|\.)/;
if (defined $numtime)
{
$numtime = substr( "20$numtime", -15, 15);  # Add leading '20' if length less than 15 (8+1+6) YY => 20YY
} else
{
ENV_sig( $sig_on_error => "Unknown logfile name format:", "'$logfile_spec'");
}


return ($jobname, $build_or_tool, $audit, $numtime);
}




sub GBSRES_get_logfile_numtime($)
{
my ($logfile_spec) = @_;
my $numtime;

($numtime) = $logfile_spec =~ /.*_(\d{6,8}-\d{6})($|\.|_)/;
if (defined $numtime)
{
$numtime = substr( "20$numtime", -15, 15);  # Add leading '20' if length less than 15 (8+1+6) YY => 20YY
} else
{
ENV_sig( E => "Unknown logfile name format: '$logfile_spec'");
}

return $numtime;
}




sub GBSRES_skiptypes()
{
return qw! (^|/)~ ~$ \.sav\d*$ \.bak$ \.bck$ \.old$ \.tmp$ \.\$+$ \.proto$ (^|/)Thumbs.db$ !;
}

1;
