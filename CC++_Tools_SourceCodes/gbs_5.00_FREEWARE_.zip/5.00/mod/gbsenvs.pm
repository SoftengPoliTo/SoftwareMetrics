#=================================================
#
#   gbsenvs.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbsenvs;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSENVS_init
GBSENVS_set_gbs
GBSENVS_set_root
GBSENVS_set_subsys
GBSENVS_set_component
GBSENVS_set_build
GBSENVS_set_audit
GBSENVS_set_tool
GBSENVS_update
);
}




use glo::env;




sub GBSENVS_init();
sub GBSENVS_set_gbs($;$$);
sub GBSENVS_set_root($;$$);
sub GBSENVS_set_subsys($;$$);
sub GBSENVS_set_component($;$$);
sub GBSENVS_set_build($;$$);
sub GBSENVS_set_audit($;$$);
sub GBSENVS_set_tool($;$$);
sub GBSENVS_update($$;$);

sub set_generic($$;$$);
sub set_and_store_envvar($$$$);








my @PREDEF_REFS = (


[ PLATFORM		=> 0, 0, undef,	\$GBS::PLATFORM, ],	    # Mswin32 or linux
[ SHELL_FILETYPE	=> 0, 0, undef,	\$GBS::SHELL_FILETYPE, ],   # .bat or .sh
[ PERL_CMD		=> 0, 1, undef, \$GBS::PERL_CMD, ],

[ BOOT_PATH		=> 0, 1, undef, \$GBS::BOOT_PATH, ],	    # %APPDATA%/.gbs or ~/.gbs
[ BASE_PATH		=> 0, 1, undef, \$GBS::BASE_PATH, ],	    # %APPDATA%/.gbs/base or ~/.gbs/base - or user-defined
);

my @PROFILE_REFS = (


[ SCRIPTS_ROOT	=> 0, 1, undef, \$GBS::SCRIPTS_ROOT, ],
[ SCRIPTS_REL	=> 0, 0, undef, \$GBS::SCRIPTS_REL, ],
[ SCRIPTS_PATH	=> 0, 1, undef, \$GBS::SCRIPTS_PATH, ],	# $GBS::SCRIPTS_ROOT/$GBS::SCRIPTS_PATH
[ SITE        	=> 0, 0, undef, \$GBS::SITE, ],
[ LOG_ROOT   	=> 0, 1, undef, \$GBS::LOG_ROOT, ],
[ EDITOR     	=> 0, 1, undef, \$GBS::EDITOR, ],
[ BROWSER     	=> 0, 1, undef, \$GBS::BROWSER, ],
[ VIEWER     	=> 0, 1, undef, \$GBS::VIEWER, ],
[ BEEPS     	=> 0, 0, undef, \$GBS::BEEPS, ],	# YES NO
[ ADMINISTRATOR	=> 1, 0, undef, \$GBS::ADMINISTRATOR, \@GBS::ADMINISTRATOR, undef],
[ INTEGRATOR	=> 1, 0, undef, \$GBS::INTEGRATOR,    \@GBS::INTEGRATOR, undef],
);

my @GBS_REFS = (


[ FULL_VERSION		=> 0, 0, 'v', \$GBS::FULL_VERSION, ],	    # RVVYYMMDD
[ VERSION			=> 0, 0, 'v', \$GBS::VERSION, ],	    # R.VV e.g.: 4.00
[ GUI			=> 0, 0, 'v', \$GBS::GUI, ],		    # Tkx None

[ EXEC_ID			=> 0, 0, 'v', \$GBS::EXEC_ID, ],	    # host_time_pid
[ EXEC_LEVEL		=> 0, 0, 'v', \$GBS::EXEC_LEVEL, ],	    # 0 == toplevel process
[ EXEC_MODE			=> 0, 0, 'v', \$GBS::EXEC_MODE, ],	    # INTERACTIVE FOREGROUD BACKGROUND
[ PROMPT_SEPARATOR_PRINTED	=> 0, 0, 'v', \$GBS::PROMPT_SEPARATOR_PRINTED, ], # bool. Set by GBSENV_init->BEGIN
[ ABT_NAME			=> 0, 0, 'v', \$GBS::ABT_NAME, ],	    # '', audit, build or tool. Set by GBSENV_init->BEGIN
);

my @ROOT_REFS = (



[ PLUGIN_ROOT	=> 0,  1, 'v', \$GBS::PLUGIN_ROOT, ],
[ ROOT_PATH		=> 0,  1, 'v', \$GBS::ROOT_PATH, ],
[ ROOT_PARENT       => 0,  0, 'v', \$GBS::ROOT_PARENT, ],
[ LOG_PATH		=> 0,  1, 'v', \$GBS::LOG_PATH, ],


[ EXT_PATH		=> 0,  1, 'p', \$GBS::EXT_PATH, ],
[ DEV_PATH		=> 0,  1, 'p', \$GBS::DEV_PATH, ],
[ RES_PATH		=> 0,  1, 'p', \$GBS::RES_PATH, ],
[ TMP_PATH		=> 0,  1, 'p', \$GBS::TMP_PATH, ],
[ SILO_PATH		=> 0,  1, 'p', \$GBS::SILO_PATH, ],
[ SYS_PATH		=> 0,  1, 'p', \$GBS::SYS_PATH, ],
[ SYSAUDIT_PATH	=> 0,  1, 'p', \$GBS::SYSAUDIT_PATH, ],
[ SYSBUILD_PATH	=> 0,  1, 'p', \$GBS::SYSBUILD_PATH, ],
[ SYSTOOL_PATH	=> 0,  1, 'p', \$GBS::SYSTOOL_PATH, ],


[ SYSTEM_NAME	=> 0,  0, 'v', \$GBS::SYSTEM_NAME, ],
[ SCMS		=> 0,  0, 'v', \$GBS::SCMS, ],
[ SCMS_DATA		=> 0,  0, 'v', \$GBS::SCMS_DATA, ],
[ SCMS_REPOSITORY   => 0,  0, 'v', \$GBS::SCMS_REPOSITORY, ],
[ SCM_SKIPTYPES	=> 1,  0, 'v', \$GBS::SCM_SKIPTYPES, \@GBS::SCM_SKIPTYPES, undef ],
[ ROOT_VERSION	=> 0,  0, 'v', \$GBS::ROOT_VERSION, ],
[ BUILDS		=> 1,  0, 'v', \$GBS::BUILDS, \@GBS::BUILDS, \%GBS::BUILDS ],
[ AUDITS		=> 1,  0, 'v', \$GBS::AUDITS, \@GBS::AUDITS, \%GBS::AUDITS ],
[ TOOLS		=> 1,  0, 'v', \$GBS::TOOLS,  \@GBS::TOOLS,  \%GBS::TOOLS ],


[ ALL_SUBSYSTEMS    => 1,  0, 'v', \$GBS::ALL_SUBSYSTEMS, \@GBS::ALL_SUBSYSTEMS, \%GBS::ALL_SUBSYSTEMS ],
[ ALL_BUILDS	=> 1,  0, 'v', \$GBS::ALL_BUILDS,    \@GBS::ALL_BUILDS,    \%GBS::ALL_BUILDS ],
[ ALL_AUDITS	=> 1,  0, 'v', \$GBS::ALL_AUDITS,    \@GBS::ALL_AUDITS,    \%GBS::ALL_AUDITS ],
[ ALL_TOOLS		=> 1,  0, 'v', \$GBS::ALL_TOOLS,     \@GBS::ALL_TOOLS,     \%GBS::ALL_TOOLS ],

[ PLATFORMS		=> 1,  0, 'v', \$GBS::PLATFORMS, \@GBS::PLATFORMS, undef ],
[ SKIPTYPES		=> 1,  0, 'v', \$GBS::SKIPTYPES, \@GBS::SKIPTYPES, undef ],
[ IS_INTEGRATOR	=> 0,  0, 'v', \$GBS::IS_INTEGRATOR, ],
[ IS_ADMINISTRATOR  => 0,  0, 'v', \$GBS::IS_ADMINISTRATOR, ],
);

my @SUBSYS_REFS = (


[ SUBSYS		=> 0,  0, 'v', \$GBS::SUBSYS, ],
[ SSTYPE		=> 0,  0, 'v', \$GBS::SSTYPE, ],    	# GBS MSVS make Other

[ SUBSYS_PATH	=> 0,  1, 'v', \$GBS::SUBSYS_PATH, ],
[ EXPORT_PATH	=> 0,  1, 'p', \$GBS::EXPORT_PATH, ],
[ IMPORT_PATH	=> 0,  1, 'p', \$GBS::IMPORT_PATH, ],
[ BUILD_PATH	=> 0,  1, 'p', \$GBS::BUILD_PATH, ],
[ AUDIT_PATH	=> 0,  1, 'p', \$GBS::AUDIT_PATH, ],
[ TOOL_PATH	=> 0,  1, 'p', \$GBS::TOOL_PATH, ],


[ COMP_PATH		=> 0,  1, 'v', \$GBS::COMP_PATH, ],	# Only for GBS Sussys
[ ALL_COMPONENTS	=> 1,  0, 'v', \$GBS::ALL_COMPONENTS, \@GBS::ALL_COMPONENTS, \%GBS::ALL_COMPONENTS],
[ COMPONENT_PATH	=> 0,  1, 'p', \$GBS::COMPONENT_PATH, ],


[ APP_PATH		=> 0,  1, 'v', \$GBS::APP_PATH, ],	# Only for non-GBS SusSys
);

my @COMPONENT_REFS = (


[ COMPONENT		=> 0,  0, 'v', \$GBS::COMPONENT, ],

[ COMPONENT_PATH    => 0,  1, 'v', \$GBS::COMPONENT_PATH, ],
[ AUD_PATH		=> 0,  1, 'p', \$GBS::AUD_PATH, ],
[ BLD_PATH		=> 0,  1, 'p', \$GBS::BLD_PATH, ],
[ DAT_PATH		=> 0,  1, 'p', \$GBS::DAT_PATH, ],
[ INC_PATH		=> 0,  1, 'p', \$GBS::INC_PATH, ],
[ LOC_PATH		=> 0,  1, 'p', \$GBS::LOC_PATH, ],
[ OPT_PATH		=> 0,  1, 'p', \$GBS::OPT_PATH, ],
[ SAV_PATH		=> 0,  1, 'p', \$GBS::SAV_PATH, ],
[ SRC_PATH		=> 0,  1, 'p', \$GBS::SRC_PATH, ],
);

my @BUILD_REFS = (


[ BUILD		=> 0,  0, 'v', \$GBS::BUILD, ],
[ BUILD_PLUGIN	=> 0,  0, 'v', \$GBS::BUILD_PLUGIN, ],
);

my @AUDIT_REFS = (


[ AUDIT		=> 0,  0, 'v', \$GBS::AUDIT, ],
[ AUDIT_PLUGIN	=> 0,  0, 'v', \$GBS::AUDIT_PLUGIN, ],
);

my @TOOL_REFS = (


[ TOOL		=> 0,  0, 'v', \$GBS::TOOL, ],
[ TOOL_PLUGIN	=> 0,  0, 'v', \$GBS::TOOL_PLUGIN, ],
);

my @ALL_DEF_REFS = (\@PREDEF_REFS, \@PROFILE_REFS, \@GBS_REFS,
\@ROOT_REFS, \@SUBSYS_REFS, \@COMPONENT_REFS, \@BUILD_REFS, \@AUDIT_REFS, \@TOOL_REFS);



my %ALL_REFS;		    # will be filled on the fly





sub GBSENVS_init()
{
foreach my $def_ref (@ALL_DEF_REFS)
{
foreach my $ref (@{$def_ref})
{
my ($name, $is_list, $is_path, undef, $scalar_ref, $array_ref, $hash_ref) = @{$ref};
my $envvar = "GBS_$name";
my $value = ($is_path) ? ENV_getenv_perl_path( $envvar) : ENV_getenv( $envvar);

$$scalar_ref = $value
if (defined $scalar_ref);
if ($is_list)
{
my @values = split( ',', $value);
@{$array_ref} = @values
if (defined $array_ref);
%{$hash_ref} = map { $_ => 1 } @values
if (defined $hash_ref);
}
}
}




$GBS::PLATFORM = $^O;				# Mswin32 or linux
$GBS::SHELL_FILETYPE = ENV_shell_filetype();	# .bat or .sh

ENV_setenv( GBS_PLATFORM => $GBS::PLATFORM);
ENV_setenv( GBS_SHELL_FILETYPE => $GBS::SHELL_FILETYPE);


}




sub GBSENVS_set_gbs($;$$)
{
my ($must_set_global_variables,	    # Bool
$root_path,			    # undef == cleanup
$new_values_pairs_ref,
) = @_;

set_generic( \@GBS_REFS, $must_set_global_variables, $root_path, $new_values_pairs_ref);

map { set_generic( $_, 0 ) } (\@ROOT_REFS, \@SUBSYS_REFS, \@COMPONENT_REFS, \@BUILD_REFS, \@AUDIT_REFS, \@TOOL_REFS);
}




sub GBSENVS_set_root($;$$)
{
my ($must_set_global_variables,	    # Bool
$root_path,			    # undef == cleanup
$new_values_pairs_ref,
) = @_;

set_generic( \@ROOT_REFS, $must_set_global_variables, $root_path, $new_values_pairs_ref);

map { set_generic( $_, 0 ) } (\@SUBSYS_REFS, \@COMPONENT_REFS, \@BUILD_REFS, \@AUDIT_REFS, \@TOOL_REFS);
}




sub GBSENVS_set_subsys($;$$)
{
my ($must_set_global_variables,	    # Bool
$root_path,			    # undef == cleanup
$new_values_pairs_ref,
) = @_;

set_generic( \@SUBSYS_REFS, $must_set_global_variables, $root_path, $new_values_pairs_ref);

map { set_generic( $_, 0 ) } ( \@COMPONENT_REFS);
}




sub GBSENVS_set_component($;$$)
{
my ($must_set_global_variables,	    # Bool
$root_path,			    # undef == cleanup
$new_values_pairs_ref,
) = @_;

set_generic( \@COMPONENT_REFS, $must_set_global_variables, $root_path, $new_values_pairs_ref);
}




sub GBSENVS_set_build($;$$)
{
my ($must_set_global_variables,	    # Bool
$root_path,			    # undef == cleanup
$new_values_pairs_ref,
) = @_;

set_generic( \@BUILD_REFS, $must_set_global_variables, $root_path, $new_values_pairs_ref);
}




sub GBSENVS_set_audit($;$$)
{
my ($must_set_global_variables,	    # Bool
$root_path,			    # undef == cleanup
$new_values_pairs_ref,
) = @_;

set_generic( \@AUDIT_REFS, $must_set_global_variables, $root_path, $new_values_pairs_ref);
}




sub GBSENVS_set_tool($;$$)
{
my ($must_set_global_variables,	    # Bool
$root_path,			    # undef == cleanup
$new_values_pairs_ref,
) = @_;

set_generic( \@TOOL_REFS, $must_set_global_variables, $root_path, $new_values_pairs_ref);
}




sub set_generic($$;$$)
{
my ($envs_ref,
$must_set_global_variables,	    # Bool
$root_path,			    # undef == cleanup
$new_values_pairs_ref,
) = @_;

my @env_pairs;
if (defined $root_path)
{



my %new_values = @{$new_values_pairs_ref};

foreach my $ref (@{$envs_ref})
{
my ($name, $is_list, undef, $type) = @{$ref};
my $env_name = "GBS_$name";
my @values;
if ($type eq 'p')
{



my $path_part = lc( substr( $name, 0, -5));	# lowercase, minus "_PATH"
set_and_store_envvar( $must_set_global_variables, $env_name, "$root_path/$path_part", $ref);
} elsif ($type eq 'v')
{



if (exists $new_values{$name})
{
my $value_or_ref = $new_values{$name};		# in list
set_and_store_envvar( $must_set_global_variables, $env_name, $value_or_ref, $ref);
delete $new_values{$name};
}
} else
{
ENV_sig( F => "Invalid type '$type'");
}
}
if (%new_values)
{
my @unmached_names = keys %new_values;
ENV_sig( F => "Unmatched EnvVar names in new_values_pairs_ref: '@unmached_names'");
}
} else
{



foreach my $ref (@{$envs_ref})
{
my ($name, $is_list, undef, undef, $scalar_ref, $array_ref, $hash_ref) = @{$ref};
ENV_setenv( "GBS_$name", '');
if ($must_set_global_variables)
{
$$scalar_ref = ''
if (defined $scalar_ref);
@{$array_ref} = ()
if (defined $array_ref);
%{$hash_ref} = ()
if (defined $hash_ref);

}
}
}
}




sub GBSENVS_update($$;$)
{
my ($must_set_global_variables,	    # Bool
$new_values_pairs_ref,		    # or env_name
$value_or_ref,			    # may be undef if new_values_pairs_ref == name
) = @_;

$new_values_pairs_ref = [ $new_values_pairs_ref, $value_or_ref ]
if (!ref $new_values_pairs_ref);

while (@{$new_values_pairs_ref})
{
my $env_name = shift @{$new_values_pairs_ref};
my $value_or_ref = shift @{$new_values_pairs_ref};
my $wanted_def_ref = $ALL_REFS{$env_name};

if (!defined $wanted_def_ref)
{
OUTER: foreach my $def_ref (@ALL_DEF_REFS)
{
foreach my $ref (@{$def_ref})
{
my $name = 'GBS_' . $ref->[0];
$ALL_REFS{$name} = $ref;

if ($env_name eq $name)
{
$wanted_def_ref = $ref;
last OUTER;
}
}
}
ENV_sig (F => "Could not find EnvVar '$env_name'")
if (!defined $wanted_def_ref);
}
set_and_store_envvar( $must_set_global_variables, $env_name, $value_or_ref, $wanted_def_ref);
}
}




sub set_and_store_envvar($$$$)
{
my ($must_set_global_variables,	# Bool
$env_name,			# Starts with 'GBS_'
$value_or_ref,
$def_ref,
) = @_;

my (undef, $is_list, $is_path, undef, $scalar_ref, $array_ref, $hash_ref) = @{$def_ref};
my @values;
if ($is_list)
{
@values = (ref $value_or_ref) ? @{$value_or_ref} : split( ',', $value_or_ref);
} else
{
$values[0] = (ref $value_or_ref) ? join( ',', @{$value_or_ref}) : $value_or_ref;
}
if (@values)
{
ENV_sig( F => "undefined value in $env_name")
if (!defined $values[0]);

if ($is_list)
{
if ($is_path)
{
ENV_setenv_os_path( $env_name,  [ @values ]);
} else
{
ENV_setenv($env_name, [ @values ]);
}
} else
{
if ($is_path)
{
ENV_setenv_os_path( $env_name, $values[0]);
} else
{
ENV_setenv( $env_name, $values[0]);
}
}
if ($must_set_global_variables)
{
$$scalar_ref = join( ',', @values)
if (defined $scalar_ref);
@{$array_ref} = @values
if (defined $array_ref);
%{$hash_ref} = map { $_ => 1 } @values
if (defined $hash_ref);

}
} else
{



ENV_setenv( $env_name, '');
if ($must_set_global_variables)
{
$$scalar_ref = ''
if (defined $scalar_ref);
@{$array_ref} = ()
if (defined $array_ref);
%{$hash_ref} = ()
if (defined $hash_ref);

}
}
}




END
{
my @package_keys = ENV_get_package_keys( 'GBS');

my @valid_keys = map { map { $_->[0] } @{$_} } @ALL_DEF_REFS;

my %valid_keys = map { $_ => 1 } @valid_keys;
my %perl_keys = map { $_ => 1 } qw( CLONE CLONE_SKIP);
foreach my $key (@package_keys)
{
if (!exists $valid_keys{$key})
{
ENV_sig( E => "Invalid GBS global 'GBS::$key'")
unless (exists $perl_keys{$key});
}
}
}

1;


