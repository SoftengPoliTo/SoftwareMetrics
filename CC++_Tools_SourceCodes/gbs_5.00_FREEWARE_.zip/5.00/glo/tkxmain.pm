#=================================================
#
#   tkxmain.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::tkxmain;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
TKXMAIN_new_window
TKXMAIN_splash_screen
TKXMAIN_mainloop
TKXMAIN_exit
);
}




use Tkx;

use glo::env;
use glo::tkx;
use glo::tkxglo;
use glo::tkxfont;
use glo::tkxevent;
use glo::tkxinifile;




sub TKXMAIN_new_window($$$$$);
sub TKXMAIN_splash_screen($$$);
sub TKXMAIN_mainloop();
sub TKXMAIN_exit();

sub map_geometry($$);
sub local_delete_window($);








my @INITIAL_GEOMETRY = ( 800, 400, 20, 20);





my $SS;		    # SplashScreen

my $MUST_SET_GEOMETRY;
my @START_GEOMETRY;		#   ($width, $height, $x, $y)
my $WANTED_STATE = 'normal';	# normal, iconised, zoomed

my $DELETE_WINDOW_FUNC;




sub TKXMAIN_new_window($$$$$)
{
my ($title,
$icon_file_spec,	#
$initial_geometry_ref,	# [ $width, $height, $x, $y ]. May be undef
$start_geometry_ref,	# [ $width, $height, $x, $y ]. May be undef. Overrides initial_geometry
$delete_window_func,	# Called when the X is clicked func->($mw_widget)
) = @_;



$DELETE_WINDOW_FUNC = $delete_window_func;	# save
$MUST_SET_GEOMETRY = (defined $initial_geometry_ref || defined $start_geometry_ref) ? 1 : 0;




$TKX::MW->g_wm_withdraw();

$TKX::MW->g_wm_title( $title);
if (defined $icon_file_spec)
{
$TKX::MW->g_wm_iconphoto( TKXGLO_photo( icon => $icon_file_spec));
}










TKXFONT_create( My_stdout => -family => 'Courier', -size => 10);
TKXFONT_create( My_stdout_bold => -family => 'Courier', -size => 10, -weight => 'bold');




if ($MUST_SET_GEOMETRY)
{
if (defined $initial_geometry_ref)
{
map_geometry( \@INITIAL_GEOMETRY, $initial_geometry_ref);
}
TKXINIFILE_prep( [ [ GUI => (geometry => \@INITIAL_GEOMETRY) ] ]);

@START_GEOMETRY = split( ' ', TKXINIFILE_get_gui( 'geometry'));




if (defined $start_geometry_ref)
{
map_geometry( \@START_GEOMETRY, $start_geometry_ref);
}
$WANTED_STATE = TKXINIFILE_get_gui( 'state')
if (!defined $start_geometry_ref);



}

TKXEVENT_bind_delete_window( $TKX::MW, \&local_delete_window);
}




sub map_geometry($$)
{
my ($init_geometry_ref,
$new_geometry_ref,
) = @_;

my @new_geometry = @{$new_geometry_ref};	# make a copy
foreach my $geo (@{$init_geometry_ref})
{
my $new_geo = shift @new_geometry;
$geo = $new_geo
if (defined $new_geo && $new_geo ne '.' && $new_geo ne '');
}
}




sub TKXMAIN_splash_screen($$$)
{
my ($top_text,
$image,
$bottom_text,
) = @_;

$SS = $TKX::MW->new_toplevel();
$SS->g_wm_withdraw();

my $icon_photo = TKXGLO_photo( 'icon');
if (defined $icon_photo)
{
$SS->g_wm_iconphoto( $icon_photo);
}


if (defined $top_text)
{
TKX_new_label( $SS, $top_text)->g_pack();
}
if (defined $image)
{
TKX_new_label( $SS, '', -image => $image)->g_pack();
}
if (defined $bottom_text)
{
TKX_new_label( $SS, $bottom_text)->g_pack();
}
$SS->g_wm_overrideredirect(1);	    # Remove all decorations
$SS->g_wm_attributes( -topmost => 1);   #

if ($MUST_SET_GEOMETRY)
{
if (@START_GEOMETRY)
{
my @splash_geometry = TKXGLO_geo_center_window( \@START_GEOMETRY, $SS);
TKX_geometry( $SS, @splash_geometry);
}
}

$SS->g_wm_deiconify();

return $SS;
}




sub TKXMAIN_mainloop()
{





ENV_say( 1, 'Ready');

if ($MUST_SET_GEOMETRY)
{
if (@START_GEOMETRY)
{

TKX_geometry( $TKX::MW, @START_GEOMETRY);
@START_GEOMETRY = ();
}


}

if (defined $SS)
{
$SS->g_destroy();
}
$TKX::MW->g_wm_deiconify();

Tkx::MainLoop();
}




sub TKXMAIN_exit()
{
local_delete_window( $TKX::MW);
}




sub local_delete_window($)
{
my ($mw_widget,
) = @_;

if ($MUST_SET_GEOMETRY)
{



my @geometry = TKX_geometry( $TKX::MW);   # width, heigth, x, y
my $state = TKX_wm_state( $TKX::MW);

if ($state eq 'normal')
{
TKXINIFILE_store_gui( [ geometry => \@geometry ], [ state => $state ]);
} elsif ($state eq 'zoomed')
{
TKXINIFILE_store_gui([ state => $state ]);
} else
{
TKXINIFILE_store_gui( [ geometry => \@geometry ]);
}
}




$DELETE_WINDOW_FUNC->( $mw_widget)
if (defined $DELETE_WINDOW_FUNC);




$TKX::MW->g_destroy();
}

1;

