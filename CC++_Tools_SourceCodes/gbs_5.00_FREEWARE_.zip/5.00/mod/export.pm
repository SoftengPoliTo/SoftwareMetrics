#=================================================
#
#   export.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::export;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
EXPORT_parse
);
}




use glo::env;
use mod::gbsfile;
use mod::gbsfileglo;




sub EXPORT_parse($$$);
sub syntax_chmod($$);




my @DESTINATIONS = qw( RESSUB EXPORT ANY);
my %DESTINATIONS = map { $_ => 1 } @DESTINATIONS;

my @SOURCES = qw( CMP RES EXT SILO SUB INSTALL);
my %SOURCES = map { $_ => 1 } @SOURCES;
my %DEFAULT_SOURCES = (

SUBSYS  => 'SUB',
CMP	    => 'CMP',
);

my %ALLOWED_CMPS = (

aud	    => 3,
bld	    => 2,
dat	    => -1,
inc	    => 1,
loc     => 1,
opt	    => 2,
sav	    => 0,
src	    => 1,
);

my $EXPORT_DIR_EXISTS = -d "$GBS::ROOT_PATH/dev/$GBS::SUBSYS/export";
my $RESSUB_DIR_EXISTS = -d "$GBS::ROOT_PATH/res/$GBS::SUBSYS";












sub EXPORT_parse($$$)
{
my ($export_file_loc,	# CMP or SUBSYS
$component,		# Empty if export_file_loc ne CMP:
$gbs_build,
) = @_;
my @specs_refs;




my $export_file_path;
if ($export_file_loc eq 'SUBSYS')
{
ENV_whisper( 1, "Parsing 'SUBSYS:'...");
$export_file_path = "$GBS::ROOT_PATH/dev/$GBS::SUBSYS";
} else  #$export_file_loc eq 'CMP'
{
ENV_whisper( 1, "Parsing Component '$component'...");
$export_file_path = "$GBS::ROOT_PATH/dev/$GBS::SUBSYS/comp/$component";
}


if (GBSFILE_open( "$export_file_path/export", 0, undef, undef))
{
my $line = GBSFILE_get_line();
GBSFILE_sig( EE => "First line must be a Destination Line")
if (defined $line && $line =~ /^\s/);

my $dest;
my $specs_ref;			# current set
my $selected;
while ($line)
{

my $original_line = $line;
if ($line =~ /^\S/)
{



(my $application_part, $selected) = GBSFILEGLO_build_line_select( $line, $gbs_build);
$line = $application_part;
}
GBSFILE_sig( EE => "Wild-card not allowed")
if ($line =~ /\*/);
GBSFILE_sig( EE => "'../' not allowed")
if ($line =~ /\.\.(\/|$)/);

$line =~ s/%GBS_BUILD%/*/g;
$line =~ s/\$GBS_BUILD/*/g;


if ($line =~ /^\S/)
{





my ($to_dir_def, $rest) = split( ' ', $line, 2);
GBSFILE_sig( EE => "Syntax is: [<to_base>:]<to_path>[|<chmod>] [<build_line_selector>]")
if (defined $rest);
$to_dir_def = ENV_decode( $to_dir_def);
$to_dir_def = ENV_perl_canon_paths( ENV_expand_envs( $to_dir_def));
GBSFILE_sig( EE => "No absolute path allowed")
if (ENV_is_abs_path_perl( $to_dir_def));

($dest, my $to_dir) = split( ':', $to_dir_def, 2);
if (defined $to_dir)
{
GBSFILE_sig( EE => "Invalid <to_base>: '$dest:'. Must be one of '@DESTINATIONS'")
if (!$DESTINATIONS{$dest});
} else
{
$dest = 'ANY';
$to_dir = $to_dir_def;
}

($to_dir, my $chmod_dir) = syntax_chmod( $to_dir, 1);

if ($dest eq 'ANY')
{
GBSFILE_sig( EE => "No Export and no Res/Sub directory exist")
if (!$EXPORT_DIR_EXISTS && !$RESSUB_DIR_EXISTS);
$dest = 'EXPORT'
if (!$RESSUB_DIR_EXISTS);
$dest = 'RESSUB'
if (!$EXPORT_DIR_EXISTS);
} elsif ($dest eq 'EXPORT')
{
GBSFILE_sig( EE => "Export directory does not exist")
if (!$EXPORT_DIR_EXISTS);
} else	# $dest eq 'RESSUB'
{
GBSFILE_sig( EE => "Res/Sub directory does not exist")
if (!$RESSUB_DIR_EXISTS);
}




$specs_ref = [ $selected, $dest, $to_dir, $chmod_dir ];
push @specs_refs, $specs_ref;
} else
{








$line =~ s/\*/$gbs_build/g;



my @parts = ENV_decode( split( ' ', $line));	# %20 => space, %22 -> '"'
if (@parts > 2 && $parts[-2] =~ /^(=|!)/)
{
GBSFILE_sig( EE => "Cannot specify build-line-selection on source-lines");
}
(my $source, $parts[0]) = split( ':', $parts[0], 2);
my $source_type;
if (!defined $parts[0])
{
$parts[0] = $source;
$source = $DEFAULT_SOURCES{$export_file_loc};
$source_type = $source;
} else
{
if ($SOURCES{$source})  # CMP, EXT, INSTALL, RES, SILO, SUB
{
$source_type = $source;
} elsif ($source =~ /^GBSEXT_.*_PATH$/)
{
$source_type = 'GBSEXT';
} else
{
GBSFILE_sig( EE => "Invalid <from_base>: '$source:'. Must be one of '@SOURCES GBSEXT_<name>_PATH'");
}
}

GBSFILE_sig( EE => "In a Component export.gbs only 'CMP:' can be specified ($source:)")
if ($export_file_loc eq 'CMP' && $source ne 'CMP');

my $out_ref;
if ($source_type eq 'INSTALL')
{



GBSFILE_sig( EE => "Syntax is: INSTALL:<command> [<args>...] <to_file>")
if (@parts < 3);
GBSFILE_sig( EE => "You cannot specify 'INSTALL:' in a Component export.gbs")
if ( $export_file_loc eq 'CMP');
my $command = shift @parts;
$command = ENV_expand_envs( $command);
my $to_file = pop @parts;
($to_file, my $chmod_file) = syntax_chmod( $to_file, 0);
my @args = @parts;
GBSFILE_sig( EE => "Directory spec not allowed in '$to_file'")
if ($to_file =~ /\//);  # do not allow '/' in to-name;
$out_ref = [ 'INSTALL:', $to_file, $chmod_file, $command, @args ]
} else
{



GBSFILE_sig( EE => "Syntax is: [<from_base>:][<from_path>]<from_file> [<to_file>]")
if (@parts > 2);
my $gbsext_dir;
if ($source_type eq 'CMP')
{
GBSFILE_sig( EE => "You can specify 'CMP:' only in a Component export.gbs")
if ( $export_file_loc ne 'CMP');
} elsif ($source_type eq 'EXT')
{
GBSFILE_sig( EE => "Copy from EXT: to RESSUB: is not allowed")
if ($dest eq 'RESSUB');
} elsif ($source_type eq 'GBSEXT')
{
if ($selected)
{
$gbsext_dir = ENV_getenv_perl_path( $source);
GBSFILE_sig( EE => "EnvVar '$source' not defined")
if ($gbsext_dir eq '');
GBSFILE_sig( EE => "No such directory '$source' => ($gbsext_dir)")
if (!-d $gbsext_dir);
} else
{
$gbsext_dir = $source;
}
}

my ($from_dir_file, $to_file) = @parts;
$from_dir_file = ENV_perl_canon_paths( ENV_expand_envs( $from_dir_file));
my ($from_dir, $from_file) = ENV_split_spec_pf( $from_dir_file);
GBSFILE_sig( EE => "Must specify a file-name in '$from_dir_file'")
if ($from_file eq '');
my $chmod_file;
if (defined $to_file)
{
($to_file, $chmod_file) = syntax_chmod( $to_file, 0);
if ($to_file eq '.' || $to_file eq '')
{
$to_file = $from_file;
} else
{
$to_file = ENV_perl_canon_paths( ENV_expand_envs( $to_file));
GBSFILE_sig( EE => "Directory spec not allowed in '$to_file'")
if ($to_file =~ /\//);  # do not allow '/' in to-name;
}
} else
{
$to_file = $from_file;
$chmod_file = "";
}





my $from_filespec;
if ($source_type eq 'CMP')
{
$from_filespec = "$GBS::ROOT_PATH/dev/$GBS::SUBSYS/comp/$component/$from_dir_file";

GBSFILE_sig( EE => "Cannot specify Empty CMP:")
if ($from_dir eq '');
my @subdirs = split( '/', $from_dir);
my $subdir = $subdirs[0];
my $allowed_nesting = $ALLOWED_CMPS{$subdir};
GBSFILE_sig( EE => "Unkown SubDir '$subdir'")
if (! defined $allowed_nesting);
if ($allowed_nesting == 0)
{
GBSFILE_sig( EE => "Cannot specify SubDir '$subdir'");
} elsif ($allowed_nesting > 0)
{
GBSFILE_sig( EE => "Nesting (tbs) too deep for SubDir '$subdir' ($allowed_nesting)")
if (@subdirs > $allowed_nesting);
} else
{

}

if (@subdirs >= 2)
{
if ($subdir eq 'bld')
{
my $build_dir = $subdirs[1];
GBSFILE_sig( EE => "No such Build '$build_dir'")
if (!$GBS::ALL_BUILDS{$build_dir});
}
}
} elsif ($source_type eq 'EXT')
{

$from_filespec = "$GBS::ROOT_PATH/ext/$from_dir_file";
GBSFILE_sig( EE => "No such EXT: File '$from_filespec'")
if ($selected && !-f $from_filespec);
} elsif ($source_type eq 'RES')
{
$from_filespec = "$GBS::ROOT_PATH/res/$from_dir_file";
} elsif ($source_type eq 'SILO')
{
$from_filespec = "$GBS::ROOT_PATH/silo/$from_dir_file";
} elsif ($source_type eq 'SUB')
{
$from_filespec = "$GBS::ROOT_PATH/dev/$GBS::SUBSYS/$from_dir_file";
GBSFILE_sig( EE => "Cannot specify Empty SUB:")
if ($from_dir eq '');
} else  #GBSEXT
{
$from_filespec = "$gbsext_dir/$from_dir_file";
}
$out_ref = [ "$source:", $to_file, $chmod_file, $from_dir, $from_file, $from_filespec ];
}




push @{$specs_ref}, $out_ref;
} # Destination or source
$line = GBSFILE_get_line();
}
}

return @specs_refs;
}




sub syntax_chmod($$)
{
my ($to_part_raw,
$is_dir) = @_;
my ($to_part, $chmods);

($to_part, $chmods, my $rest) = split( '\|', $to_part_raw);
GBSFILE_sig( EE => "Syntax of 'to-part' is: <to_part[|<chmod>]")
if (defined $rest);
if (defined $chmods)
{
foreach my $chmod (split( ',', $chmods))
{
my ($who, $op, $perms) = $chmod =~ /^([ugoa]+)([+-=])([rwx]+)$/;
GBSFILE_sig( EE => "chmod: Invalid mode '$chmod'")
if (!defined $who);
}
} else
{
$to_part = ""
if (!defined $to_part);
$chmods = "";
}

return ($to_part, $chmods);
}

1;


