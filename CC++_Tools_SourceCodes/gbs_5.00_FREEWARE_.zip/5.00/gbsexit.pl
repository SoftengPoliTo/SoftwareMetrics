#=================================================
#
#   gbsexit.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSEXIT @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::genopt;
use glo::slurp;
use glo::shell;
use mod::gbsenv;
use mod::swr;
use mod::swglo;








my $IS_WIN32 = (ENV_is_win32());






$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
);
GENOPT_set_optdefs( 'gbsexit', \@genopts,
[ 'Exit and cleanup the GBS environment'],
undef);
GENOPT_parse();
}




{
my @lines;

ENV_say( 1, "Preparing exit...");
push @lines, SHELL_echo( 1, "Starting Cleanup...");





if ($GBS::ROOT_PATH ne '')
{



SWR_exit();
push @lines, SWR_cleanup();




push @lines, SWGLO_set_title( '-');
}





foreach my $envname (grep( /^GBS_/, keys %ENV))
{
if (GBSENV_is_predefined_env( $envname) || $envname eq 'GBS_SCRIPT_LEVEL')
{
ENV_whisper( 1, "SKIPPED: $envname");
} else
{
push @lines, SHELL_setenv( $envname, undef);
}
}







if ($IS_WIN32)
{

foreach my $line (grep( /GBS/i, SLURP_file( "$GBS::SCRIPTS_PATH/aliasdef.doskey")))  # lines containing GBS
{
my ($command_name) = $line =~ /^([^=]*)/;
push @lines, SHELL_setalias( $command_name, undef);
}
} else
{


foreach my $line (grep( /GBS/i, SLURP_file( "$GBS::SCRIPTS_PATH/aliasdef.sh")))  # lines containing GBS
{
next if (substr( $line, 0, 1) eq '#');	    # skip comments
my ($command, $command_name) = $line =~ /^(function|alias)\s+([^=\s{]*)/;
if (defined $command)
{
if ($command eq 'alias')
{
push @lines, SHELL_setalias( $command_name, undef);
} else
{
push @lines, SHELL_setfunction( $command_name, undef);
}
}
}
}





{
my $new_cwd = SWGLO_new_cwd( '', '', '');

push @lines, SHELL_echo( 1, "CWD set to $new_cwd");
push @lines, SHELL_cd( $new_cwd);
push @lines, SHELL_echo( 1, "Cleanup Done");

}




push @lines, SHELL_source( "$GBS::BOOT_PATH/define$GBS::SHELL_FILETYPE", 'cur');




GBSENV_write_result_script( \@lines, 0);
}




ENV_say( 1, "After the 'Done' message it may take some time for the prompt to return...");
ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
}


