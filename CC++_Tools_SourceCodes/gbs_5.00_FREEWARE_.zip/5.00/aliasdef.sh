#
#   gbsdef.sh
#   Define GBS functions
#   This file must be sourced with . (dot)
#
#   List all functions:		declare -f
#   List all function names:	declare -F
#   List function x:		declare -f x
#

unalias gbs 2>/dev/null

function gbs { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbsshow.pl $* ; }
function gbsaudit { $GBS_PERL_CMD  $GBS_SCRIPTS_PATH/gbsaudit.pl $* ; }
function gbsbg { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbsbg.pl $* ; }
function gbsbld { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbsbuild.pl $* ; }
function gbsbldaudit { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbsbldcheck.pl $* ; }
function gbsbldcheck { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbsbldcheck.pl $* ; }
function gbsbuild { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbsbuild.pl $* ; }
function gbsdebug { . $GBS_SCRIPTS_PATH/gbssource.sh gbsdebug.pl $* ; }
function gbsedit { . $GBS_SCRIPTS_PATH/gbssource.sh gbsedit.pl $* ; }
function gbsexit { . $GBS_SCRIPTS_PATH/gbssource.sh gbsexit.pl $* ; }
function gbsexport { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbsexport.pl $* ; }
function gbsgui { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbsgui.pl $* ; }
function gbshelp { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbshelp.pl $* ; }
function gbslocate { . $GBS_SCRIPTS_PATH/gbslocate.sh $* ; }
function gbsmaint { . $GBS_SCRIPTS_PATH/gbssource.sh gbsmaint.pl $* ; }
function gbsmake { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbsmake.pl $* ; }
function gbsmakemake { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbsmakemake.pl $* ; }
function gbsman { more $GBS_SCRIPTS_PATH/gbsman.txt; }
function gbsscm { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbsscm.pl $* ; }
function gbssetup { . $GBS_SCRIPTS_PATH/gbssource.sh gbssetup.pl $* ; }
function gbsshow { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbsshow.pl $* ; }
function gbssilo { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbssilo.pl $* ; }
function gbsstart { $GBS_SCRIPTS_PATH/gbsstart.sh $* ; }
function gbsstart_here { $GBS_SCRIPTS_PATH/gbsstart_here.sh $* ; }
function gbsstats { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbsstats.pl $* ; }
function gbsswa { . $GBS_SCRIPTS_PATH/gbssource.sh gbsswa.pl $* ; }
function gbsswb { . $GBS_SCRIPTS_PATH/gbssource.sh gbsswb.pl $* ; }
function gbsswc { . $GBS_SCRIPTS_PATH/gbssource.sh gbsswc.pl $* ; }
function gbsswr { . $GBS_SCRIPTS_PATH/gbssource.sh gbsswr.pl $* ; }
function gbssws { . $GBS_SCRIPTS_PATH/gbssource.sh gbssws.pl $* ; }
function gbsswt { . $GBS_SCRIPTS_PATH/gbssource.sh gbsswt.pl $* ; }
function gbssysall { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbssysall.pl $* ; }
function gbssysaudit { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbssysaudit.pl $* ; }
function gbssysbld { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbssysbuild.pl $* ; }
function gbssysbuild { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbssysbuild.pl $* ; }
function gbssysmake { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbssysmake.pl $* ; }
function gbssystool { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbssystool.pl $* ; }
function gbsuninstall { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbsuninstall.pl $* ; }
function gbswhich { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbswhich.pl $* ; }
function gbsxref { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbsxref.pl $* ; }

#
#   Aliases
#
function scm { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/gbsscm.pl $* ; }
function swa { . $GBS_SCRIPTS_PATH/gbssource.sh gbsswa.pl $* ; }
function swb { . $GBS_SCRIPTS_PATH/gbssource.sh gbsswb.pl $* ; }
function swc { . $GBS_SCRIPTS_PATH/gbssource.sh gbsswc.pl $* ; }
function swr { . $GBS_SCRIPTS_PATH/gbssource.sh gbsswr.pl $* ; }
function sws { . $GBS_SCRIPTS_PATH/gbssource.sh gbssws.pl $* ; }
function swt { . $GBS_SCRIPTS_PATH/gbssource.sh gbsswt.pl $* ; }

#
#   Directory Navigation Commands
#
alias cdgbs='cd $GBS_SCRIPTS_PATH/;pwd'
alias cdbase='cd "$GBS_BASE_PATH"/;pwd'
alias cdlog='cd "$GBS_LOG_PATH"/;pwd'

alias cdroot='cd "$GBS_ROOT_PATH"/;pwd'
alias cddev='cd "$GBS_ROOT_PATH"/dev/;pwd'
alias cddoc='cd "$GBS_ROOT_PATH"/doc/;pwd'
alias cdext='cd "$GBS_ROOT_PATH"/ext/;pwd'
alias cdres='cd "$GBS_ROOT_PATH"/res/;pwd'
alias cdtmp='cd "$GBS_ROOT_PATH"/tmp/;pwd'
alias cdsilo='cd "$GBS_ROOT_PATH"/silo/;pwd'
alias cdsys='cd "$GBS_ROOT_PATH"/sys/;pwd'
alias cdsysaudit='cd "$GBS_ROOT_PATH"/sysaudit/;pwd'
alias cdsysbuild='cd "$GBS_ROOT_PATH"/sysbuild/;pwd'
alias cdsystool='cd "$GBS_ROOT_PATH"/systool/;pwd'

alias cdsub='cd "$GBS_SUBSYS_PATH"/;pwd'
alias cdbuild='cd "$GBS_SUBSYS_PATH"/build/;pwd'
alias cdaudit='cd "$GBS_SUBSYS_PATH"/audit/;pwd'
alias cdtools='cd "$GBS_SUBSYS_PATH"/tools/;pwd'
alias cdcomp='cd "$GBS_SUBSYS_PATH"/comp/;pwd'
alias cdimport='cd "$GBS_SUBSYS_PATH"/import/;pwd'
alias cdexport='cd "$GBS_SUBSYS_PATH"/export/;pwd'

alias cdapp='cd "$GBS_SUBSYS_PATH"/app;pwd'

alias cdcomponent='cd "$GBS_SUBSYS_PATH"/comp/$GBS_COMPONENT;pwd'
alias cdsrc='cd "$GBS_SUBSYS_PATH"/comp/$GBS_COMPONENT/src/;pwd'
alias cdinc='cd "$GBS_SUBSYS_PATH"/comp/$GBS_COMPONENT/inc/;pwd'
alias cdloc='cd "$GBS_SUBSYS_PATH"/comp/$GBS_COMPONENT/loc/;pwd'
alias cdbld='cd "$GBS_SUBSYS_PATH"/comp/$GBS_COMPONENT/bld/;pwd'
alias cdaud='cd "$GBS_SUBSYS_PATH"/comp/$GBS_COMPONENT/aud/;pwd'
alias cddat='cd "$GBS_SUBSYS_PATH"/comp/$GBS_COMPONENT/dat/;pwd'
alias cdsav='cd "$GBS_SUBSYS_PATH"/comp/$GBS_COMPONENT/sav/;pwd'
alias cdopt='cd "$GBS_SUBSYS_PATH"/comp/$GBS_COMPONENT/opt/;pwd'
alias cdbuild='cd "$GBS_SUBSYS_PATH"/comp/$GBS_COMPONENT/bld/$GBS_BUILD/;pwd'

