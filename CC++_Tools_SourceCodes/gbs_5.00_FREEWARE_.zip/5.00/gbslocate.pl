#=================================================
#
#   gbslocate.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;









sub usage();




my $PREFIX = 'GBSLOCATE';






$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;

=optdoc
use glo::genopt;












{
my @genopts = (
[ '<1>', 'env_name',  'ssm', "", "Env Variable to contain the filespec" ],
[ '<2>', 'file',      'ssm', "", "The file to search" ],
[ '<3>', 'prefix',    'ssm', "", "prefix string preceding all path-list elements. e.g: -I" ],
[ '<*>', 'path-list', 'sam', "", "The directories to search preceded by <prefix>" ],
);
GENOPT_set_optdefs( 'gbslocate',\@genopts,
'Locate a file according to include-settings and assigns the location to a specified Environment Variable',
undef);
}
=cut




if (@ARGV == 1 && $ARGV[0] =~ /^--?(h|help)$/)
{
usage();
exit 0;
} else
{
if (@ARGV < 4)
{
CORE::say( "**SYNTAX-EROR**");
usage();
exit 9;
}
}
my $env_name = shift @ARGV;
my $file = shift @ARGV;
my $prefix = shift @ARGV;
my @paths = @ARGV;

if ($env_name !~ /^\w+$/)
{
CORE::say( STDERR "$PREFIX: <env_name> must consist of 'word' characters");
usage();
exit 1;
}






my $prefix_l = length $prefix;
my $filespec;
my $found = 0;
my $sep = ($^O eq 'MSWin32') ? '\\' : '/';
foreach my $dir_spec (@paths)
{
my $dir = substr( $dir_spec, $prefix_l);
$filespec = "${dir}${sep}$file";
if (-e $filespec)
{
$found = 1;
last;
}
}
if ($found)
{
CORE::say( "$filespec");
} else
{
CORE::say( STDERR "$PREFIX: File '$file' not found in @paths\a");
CORE::say( "**$file-NOTFOUND**");
}

exit $RC;




END
{
CORE::say( "$PREFIX: Failed ($?)") if ($?);
}




sub usage()
{



CORE::say( "$PREFIX: usage is: gbslocate <env_name> <file> <prefix> <prefix><dir> [ <prefix><dir> ]...");
}


