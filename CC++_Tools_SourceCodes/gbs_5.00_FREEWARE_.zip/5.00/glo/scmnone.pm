#=================================================
#
#   scmnone.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
#   File states:
#    -2 => 'NO-FILE',
#    -1 => 'NOT-CCM',
#     0 => 'CHECKED-IN',
#     1 => 'CHECKED-OUT',
#=================================================
package glo::scmnone;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SCMNONE_init
SCMNONE_get_states
SCMNONE_checkout
SCMNONE_uncheckout
SCMNONE_checkin
SCMNONE_remove
SCMNONE_move
SCMNONE_add_dirs
SCMNONE_add_files
);
}




use File::Path;
use glo::env;

ENV_whisper( 1, "Loading No_SCMS Plugin...");




sub SCMNONE_init($$);
sub SCMNONE_get_states($);
sub SCMNONE_checkout($);
sub SCMNONE_uncheckout($);
sub SCMNONE_checkin($);
sub SCMNONE_remove($);
sub SCMNONE_move($);
sub SCMNONE_add_dirs($);
sub SCMNONE_add_files($);






my %FSTATES;





sub SCMNONE_init($$)
{
(undef,
undef) = @_;
}








sub SCMNONE_get_states($)
{
my ($spec_refs_ref) = @_;

my @specs;
foreach my $spec_ref (@{$spec_refs_ref})
{
my ($spec, $state) = @{$spec_ref};
if (!defined $state)	    # $state may be -2 (no such file/dir)
{
$state = $FSTATES{$spec};
if (!defined $state)
{
$state = (-w $spec) ? 1 : 0;    # checkout / checkin
$FSTATES{$spec} = $state;
}
}
$spec_ref->[1] = $state;
}
}




sub SCMNONE_checkout($)
{
my ($specs_ref) = @_;

map { $FSTATES{$_} = 1 } @{$specs_ref}; # checkout
}




sub SCMNONE_checkin($)
{
my ($specs_ref) = @_;

ENV_chmod( 'ugo-w', @{$specs_ref});
map { $FSTATES{$_} = 0 } @{$specs_ref}; # checkin
}




sub SCMNONE_uncheckout($)
{
my ($specs_ref) = @_;

ENV_chmod( 'ugo-w', @{$specs_ref});
map { $FSTATES{$_} = 0 } @{$specs_ref}; # checkin
}




sub SCMNONE_remove($)
{
my ($specs_ref) = @_;

map { rmtree( $_, 0, 1) } @{$specs_ref};		    # From File::Path
map { $FSTATES{$_} = -1 } @{$specs_ref}; # notscm
}




sub SCMNONE_move($)
{
my ($pair_refs_ref) = @_;

foreach my $ref (@{$pair_refs_ref})
{
my ($old_spec, $new_spec) = @{$ref};
ENV_chmod( 'u+w', $old_spec);
ENV_rename( $old_spec, $new_spec);
$FSTATES{$old_spec} = -1;	# notscm
$FSTATES{$new_spec} = 1;    	# checkout
}
}




sub SCMNONE_add_dirs($)
{
my ($dir_refs_ref) = @_;


my @dir_specs;
foreach my $ref (@{$dir_refs_ref})
{
my ($dir, $ignore_list) = @{$ref};
ENV_mkdir( $dir, oct(777))
if (!-d $dir);
push @dir_specs, $dir;
}

map { $FSTATES{$_} = 1 } @dir_specs; # checkout
}




sub SCMNONE_add_files($)
{
my ($files_ref) = @_;

map { ENV_touch_file( $_) if (!-f $_) } @{$files_ref};
map { $FSTATES{$_} = 1 } @{$files_ref}; # checkout
}

1;

