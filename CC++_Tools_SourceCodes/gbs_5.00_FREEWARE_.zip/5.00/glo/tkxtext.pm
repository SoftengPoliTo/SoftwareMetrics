#=================================================
#
#   tkxtext.pm
#
#=================================================
package glo::tkxtext;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
TKXTEXT_new
TKXTEXT_insert_end
TKXTEXT_tag_init
TKXTEXT_tag_configure
);
}




use Tkx;
use glo::env;
use glo::tkxfont;




sub TKXTEXT_new($@);
sub TKXTEXT_insert_end($$$);
sub TKXTEXT_tag_init($$);
sub TKXTEXT_tag_configure($$@);

sub insert_markup($$$);
sub join_tagname($);
sub split_tagname($);








my @KEYWORDS = qw( -family -size -weight -slant -underline -overstrike -foreground -background );
my %TAG_DEF_REFS = (

-family	=> [ 0, 's' ],
-size	=> [ 1, 'i' ],
-weight	=> [ 2, [ qw( normal bold ) ] ],    # $off_value, $on_value
-slant	=> [ 3, [ qw( roman italic ) ] ],   # $off_value, $on_value
-underline	=> [ 4, [ 0, 1 ] ],		    # $off_value, $on_value
-overstrike	=> [ 5, [ 0, 1 ] ],		    # $off_value, $on_value
-foreground	=> [ 6, 's' ],
-background	=> [ 7, 's' ],
);

my %MARKUP_REFS = (

family  => [  1, -family	    => undef ],
size    => [  1, -size	    => undef ],
b	    => [  0, -weight	    => undef ],
i	    => [  0, -slant	    => undef ],
u	    => [  0, -underline	    => undef ],
o	    => [  0, -overstrike    => undef ],
fg	    => [  1, -foreground    => undef ],
bg	    => [  1, -background    => undef ],
noparse => [  0, undef, undef ],
);


















sub TKXTEXT_new($@)
{
my ($parent,
@args
) = @_;

return $parent->new_tk__text(@args);
}




sub TKXTEXT_insert_end($$$)
{
my ($widget,
$base_font,	    # use markup
$text_or_ref,
) = @_;

my $text = (ref $text_or_ref) ? join( "\n", @{$text_or_ref}) : $text_or_ref;
$text =~ s/[ \t]\n/\n/g;   # remove trailing whitespace

if (defined $base_font)
{
insert_markup( $widget, $base_font, $text);
} else
{
$widget->insert_end( $text);
}
}




sub insert_markup($$$)
{
my ($widget,
$base_font,
$text,
) = @_;

my $tdr = TKXTEXT_tag_init( $widget, $base_font);
my $plain_font_name = TKXTEXT_tag_configure( $widget, $tdr);

my @items = "${text}[x]" =~ /([^\[]*)(\[[^\]]+\])/g;


my @stack_refs;
foreach my $value (@{$tdr})
{
push @stack_refs, [ $value ];
}
my $current_tag = $plain_font_name;
my $noparse = 0;
foreach my $item (@items)
{
if (!$noparse && $item =~ m!\[(([a-z]+)|([a-z]+=.*)|/([a-z]+))]!)   # markup or markup=value or /markup
{

my $is_close = 0;
my $markup;
my $markup_value = '';
if (defined $2)
{
$markup = $2;
} elsif (defined $3)
{
($markup, $markup_value) = split( '=', $3);
} else # (defined $4)
{
$is_close = 1;
$markup = $4;
}

last
if ($markup eq 'x');
my $markup_ref = $MARKUP_REFS{$markup};
if (defined $markup_ref)
{
my ($value_is_required, $key, $extra) = @{$markup_ref};
ENV_sig( E => "Value required for '$markup'", $item)
if (!$is_close && $value_is_required && $markup_value eq '');
ENV_sig( E => "Value not allowed for '$markup'", $item)
if (!$value_is_required && $markup_value ne '');
if ($markup eq 'noparse')
{
$noparse = 1;
} else
{
my ($index, $type_or_ref) = @{$TAG_DEF_REFS{$key}};
my $new_value;
if (!$is_close)
{
if (ref $type_or_ref)
{
$new_value = $type_or_ref->[1];	# $off_value, $on_value
} elsif ($type_or_ref eq 'i')
{
ENV_sig( F => "Invalid value '$markup_value'. Not an integer")
if ($markup_value !~ /^(\+|-|)(\d+)$/);
my $plus_minus = $1;
my $this_value = $2;

if ($plus_minus eq '')
{
$new_value = $this_value;
} else
{
my $cur_value = $stack_refs[$index]->[0];
$new_value = $cur_value + $markup_value;
}
unshift @{$stack_refs[$index]}, $new_value;

} elsif ($type_or_ref eq 's')
{
$new_value = $markup_value;
} else
{
ENV_sig( F => "Invalid type '$type_or_ref'. Allowed (i s)")
}
} else  # $is_close
{
if (ref $type_or_ref)
{
$new_value = $type_or_ref->[0];	# $off_value, $on_value
} elsif ($type_or_ref eq 'i' || $type_or_ref eq 's')
{
if (@{$stack_refs[$index]} > 1)
{
$new_value = shift @{$stack_refs[$index]};
} else
{
$new_value = $stack_refs[$index]->[0];
}

} else
{
ENV_sig( F => "Invalid type '$type_or_ref'. Allowed (i s)")
}
}
$current_tag = TKXTEXT_tag_configure( $widget, $current_tag, $key => $new_value);
}
} else
{
ENV_sig( W => "Invalid markup '$markup' in '$item'", $text);

$widget->insert_end( $item, $current_tag);
}
} else
{

$widget->insert_end( $item, $current_tag);
}
}
}




sub TKXTEXT_tag_init($$)
{
my ($widget,
$base_font,
) = @_;
my $new_tag_description_ref;

my @full_actual = TKXFONT_actual( $base_font, $widget);
my @actual;
while (@full_actual)
{
my $keyword = shift @full_actual;
my $value = shift @full_actual;
my $index = $TAG_DEF_REFS{$keyword}->[0];
$actual[$index] = $value;
}
my $fg = $widget->cget( -foreground);
my $bg = $widget->cget( -background);

$new_tag_description_ref = [ @actual, $fg, $bg ];

return $new_tag_description_ref;
}




sub TKXTEXT_tag_configure($$@)
{
my ($widget,
$tdf_or_tag_name,	# [ $family, $size, $weight, $slant, $underline, $overstrike, $foreground, $background ] or $tag_name
@modifiers		# -family => $new_family, ...
) = @_;
my $new_tag_name;		# May not contain ' ', + or -

my @attributes;
if (ref $tdf_or_tag_name)
{
@attributes = @{$tdf_or_tag_name};
} else
{
@attributes = split_tagname( $tdf_or_tag_name);
}

while (@modifiers)
{
my $key = shift @modifiers;
my $value = shift @modifiers;
my $tag_def_ref = $TAG_DEF_REFS{$key};
ENV_sig( F => "Invalid key '$key'. Allowed (@KEYWORDS)")
if (!defined $tag_def_ref);
my ($index, $type_or_ref) = @{$tag_def_ref};
if (ref $type_or_ref)
{
my @allowed_values = @{$type_or_ref};
ENV_sig( F => "Invalid value '$value'. Not in list ()")
if (!grep( $value eq $_, @allowed_values));
} elsif ($type_or_ref eq 'i')
{
ENV_sig( F => "Invalid value '$value'. Not an integer")
if ($value !~ /^\d+$/);
} elsif ($type_or_ref eq 's')
{

} else
{
ENV_sig( F => "Invalid type '$type_or_ref'. Allowed (i s)")
}
$attributes[$index] = $value;
}

$new_tag_name = join_tagname( \@attributes);
my ($family, $size, $weight, $slant, $underline, $overstrike, $foreground, $background) = @attributes;
my @configure_attributes = (
-font => Tkx::list( $family, $size, $weight, $slant),
-underline => $underline,
-overstrike => $overstrike,
-foreground => $foreground,
-background => $background,
);

$widget->tag_configure( $new_tag_name, @configure_attributes);

return $new_tag_name;
}




sub join_tagname($)
{
my ($attributes_ref,
) = @_;
my $tagname;

$tagname = join( ',', @{$attributes_ref});
$tagname =~ s/ /_/g;			# tag_name may not contain ' '. Replaced by '_'

return $tagname;
}




sub split_tagname($)
{
my ($tagname,
) = @_;
my @attributes;

$tagname =~ s/_/ /g;			# tag_name may not contain ' '. Replaced by '_'
@attributes = split( ',', $tagname);

return @attributes;
}

1;

