#=================================================
#
#   plugin.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::plugin;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
PLUGIN_get_current_name
PLUGIN_get_current_plugin
PLUGIN_reset
PLUGIN_setup
PLUGIN_check_plugins
PLUGIN_get_gbs_path
PLUGIN_set_init_envs
PLUGIN_get_main_envs
PLUGIN_get_all_plugin_names
PLUGIN_get_abt_plugin_name
PLUGIN_get_abt_names
PLUGIN_get_all_abt_names
PLUGIN_get_platform
);
}




use glo::env;
use mod::gbsenv;
use mod::audit;
use mod::fspec;
use mod::build;
use mod::tool;
use mod::system;
use mod::gbssfile;




sub PLUGIN_get_current_name($);
sub PLUGIN_get_current_plugin($);
sub PLUGIN_reset();
sub PLUGIN_setup($);
sub PLUGIN_check_plugins($);
sub PLUGIN_get_gbs_path($);
sub PLUGIN_set_init_envs($);
sub PLUGIN_get_main_envs($);
sub PLUGIN_get_abt_plugin_name($);
sub PLUGIN_get_all_plugin_names($);
sub PLUGIN_get_abt_names($);
sub PLUGIN_get_all_abt_names($);
sub PLUGIN_get_platform($);

sub check_plugin_envs($$);
sub plugin_read($);
sub get_plugin_name_type($);
sub get_plugin_name_abt($);
sub init_from_system();








my %ABT_REFS = (

audit => [ \$GBS::AUDIT, \$GBS::AUDIT_PLUGIN, \@GBS::AUDITS, \&AUDIT_get_src_types, \&AUDIT_get_section_commands_data_refs ],
build => [ \$GBS::BUILD, \$GBS::BUILD_PLUGIN, \@GBS::BUILDS, \&BUILD_get_src_types, \&BUILD_get_section_commands_data_refs ],
tool  => [ \$GBS::TOOL,  \$GBS::TOOL_PLUGIN,  \@GBS::TOOLS,  undef,			undef ],
);

my %READ_FUNCS = (

audit   => \&AUDIT_read,
build   => \&BUILD_read,
tool    => \&TOOL_read,
);

my %SYSTEM2PLUGIN = (

audits  => 'audit',
builds  => 'build',
tools   => 'tool',
);
my @SYSTEM_TYPES = sort keys %SYSTEM2PLUGIN;




my %PLUGIN_ENVS;


my %ALL_PLUGIN_TYPES;


my %ALL_PLUGINS;


my %ALL_ABT_NAMES;


my %ALL_PLUGIN_NAMES_REFS;



my %ABT_NAMES_REFS;



my %ALL_ABT_NAMES_REFS;



my %ALL_ABT_PLATFORMS;






sub PLUGIN_get_current_name($)
{
my ($abt_type,	    # audit build or tool
) = @_;

return ${$ABT_REFS{$abt_type}->[0]};	    # $abt_ref
}





sub PLUGIN_get_current_plugin($)
{
my ($abt_type,	    # audit build or tool
) = @_;

return ${$ABT_REFS{$abt_type}->[1]};	    # $abt_plugin_ref
}





sub PLUGIN_reset()
{


%PLUGIN_ENVS = ();
%ALL_PLUGIN_TYPES = ();
%ALL_PLUGINS = ();
%ALL_ABT_NAMES = ();
%ALL_PLUGIN_NAMES_REFS = ();

%ABT_NAMES_REFS = ();
%ALL_ABT_NAMES_REFS = ();

%ALL_ABT_PLATFORMS = ();
}




sub PLUGIN_setup($)
{
my ($abt_type,	    # audit build or tool
) = @_;



my ($abt_ref, $abt_plugin_ref, $abts_ref, $get_src_types_func, $get_scd_refs_func) = @{$ABT_REFS{$abt_type}};
my $uc_abt_type = uc $abt_type;			# E.g.: BUILD
my $fuc_abt_type = ucfirst $abt_type;		# E.g.: Build
my $gbs_abt = $$abt_ref;				# E.g.: $GBS::BUILD
my @gbs_abts = @{$abts_ref};			# E.g.: @GBS::BUILDS



if (grep( $_ eq $gbs_abt, @gbs_abts))
{



PLUGIN_set_init_envs( $gbs_abt);




my $gbs_abt_plugin = ENV_getenv( "GBS_${uc_abt_type}_PLUGIN");	    # GBS_AUDIT_PLUGIN	# TBS!!
my $gbsext_plugin_build;
{
my $uc_gbs_abt_plugin = uc $gbs_abt_plugin;
my $plugin_path = ENV_getenv( "GBSEXT_${uc_gbs_abt_plugin}_PATH");
ENV_setenv_os_path( "GBS_${uc_abt_type}_PLUGIN_PATH" => $plugin_path);

my $plugin_bin_path = ENV_getenv( "GBSEXT_${uc_gbs_abt_plugin}_BIN_PATH");
ENV_setenv_os_path( "GBS_${uc_abt_type}_PLUGIN_BIN_PATH" => $plugin_bin_path);

$gbsext_plugin_build = ENV_getenv( "GBSEXT_${uc_gbs_abt_plugin}_BUILD");
}




{

my $plugin_rel = PLUGIN_get_main_envs( $gbs_abt_plugin);
my $build_text = ($gbsext_plugin_build eq '') ? '' : "($gbsext_plugin_build)";
my $sca_text = '';
my $src_types_text = '';
if (defined $get_src_types_func)	# audit & build
{

my @src_types = $get_src_types_func->( $gbs_abt);
$src_types_text = " (@src_types)";
$sca_text = ' SCA'
if ($abt_type eq 'audit' && -e FSPEC_scadef( $gbs_abt_plugin));
}
ENV_whisper( 1, "$gbs_abt [$gbs_abt_plugin ($plugin_rel$build_text)$sca_text]$src_types_text");
}




{
my @command_data_refs;

if (defined $get_scd_refs_func)
{

@command_data_refs = $get_scd_refs_func->( $gbs_abt, 'INIT');	# E.g.: cpptestinit.p
}
if (@command_data_refs)
{
ENV_say( 1, "Executing $fuc_abt_type INIT...");
foreach my $command_data_ref (@command_data_refs)
{

my $command_items_ref = $command_data_ref->[1];
my $rc = ENV_system( $command_items_ref, undef);    # no RC check, no logfile
ENV_sig( EE => "$gbs_abt INIT failed")
if ($rc != 0);
}
}
}
} else
{
ENV_say( 1, "$fuc_abt_type: '$gbs_abt' does not $fuc_abt_type for this platform");
}
}




sub PLUGIN_check_plugins($)
{
my ($must_reset,	# bool. 1 if called from gbsedit / pluginmaint
) = @_;
my $error_count = 0;

ENV_whisper( 1, "Checking PLUGINS ($must_reset)...");

%PLUGIN_ENVS = ()
if ($must_reset);

foreach my $plugin_type (qw( audit build tool ))
{
my %plugins_done;

foreach my $att_name (PLUGIN_get_abt_names( $plugin_type))
{

my $plugin = PLUGIN_get_abt_plugin_name( $att_name);
if (!$plugins_done{$plugin})
{

$error_count++
if (!check_plugin_envs( $plugin, 'W'));
$plugins_done{$plugin} = 1;
}
}
}

return $error_count;
}





sub PLUGIN_get_gbs_path($)
{
my ( $plugin_name,		    # E.g.: cpptest or GBS::AUDIT_PLUGIN
) = @_;
my $gbs_plugin_path;


my ($plugin_rel, $plugin_path) = PLUGIN_get_main_envs( $plugin_name);
$gbs_plugin_path = "$GBS::PLUGIN_ROOT/$GBS::ABT_NAME/$plugin_name/$plugin_rel";
ENV_mkpath( $gbs_plugin_path);

return $gbs_plugin_path;
}





sub PLUGIN_set_init_envs($)
{
my ($abt_name,
) = @_;

my $plugin_name = PLUGIN_get_abt_plugin_name( $abt_name);

my $plugin_type = $ALL_PLUGIN_TYPES{$plugin_name};
my $struct_id = $READ_FUNCS{$plugin_type}->($abt_name);

GBSSFILE_set_init_envs( $struct_id);
}




sub PLUGIN_get_main_envs($)
{
my ($plugin_name) = @_;
my ($plugin_rel, $plugin_path) = ();

ENV_stackdump()
if (!defined $plugin_name);
my $check_ok;
my $ref = $PLUGIN_ENVS{$plugin_name};
if (defined $ref)
{
($plugin_rel, $plugin_path, $check_ok) = @{$ref};
} else
{
($plugin_rel, $plugin_path) = GBSENV_get_plugin_envs( $plugin_name);
$check_ok = check_plugin_envs( $plugin_name, 'E');
$PLUGIN_ENVS{$plugin_name} = [ $plugin_rel, $plugin_path, $check_ok ];
}
ENV_sig( EE => "Essential EnvVars missing for Plugin $plugin_name")
if (!$check_ok);

if (wantarray)
{
return ($plugin_rel, $plugin_path);
} else
{
return $plugin_rel;
}
}




sub check_plugin_envs($$)
{
my ($plugin_name,
$sig_on_error,		# '', 'E', 'EE', etc
) = @_;
my $check_ok;



my $ref = $PLUGIN_ENVS{$plugin_name};
if (defined $ref )
{
(undef, undef, $check_ok) = @{$ref};

} else
{
$check_ok = 1;
my ($plugin_rel, $plugin_path) = GBSENV_get_plugin_envs( $plugin_name);




my $plugin_env_name = uc $plugin_name;
my @errors;
if ($plugin_rel eq '')
{
push @errors, "- 'GBSEXT_${plugin_env_name}_REL' not defined in switch.gbs"
}
if ($plugin_path eq '')
{
push @errors, "- 'GBSEXT_${plugin_env_name}_PATH' not defined in switch.gbs"
} else
{
push @errors, "- 'GBSEXT_${plugin_env_name}_PATH' ($plugin_path) does not exist"
if (! -e $plugin_path);
}




my $struct_id;
if (ENV_try( W => sub { $struct_id = plugin_read( $plugin_name) }, undef))
{
my @requires = GBSSFILE_get_section_items( $struct_id, SETUP => 'REQUIRE');
foreach my $envvar (@requires)
{
push @errors, "- '$envvar' not defined in switch.gbs"
if (ENV_getenv( $envvar) eq '');
}
}




if (@errors)
{
ENV_sig( $sig_on_error => "Plugin: $plugin_name:", @errors);
$check_ok = 0;
}
$PLUGIN_ENVS{$plugin_name} = [ $plugin_rel, $plugin_path, $check_ok ];
}

return $check_ok;
}




sub plugin_read($)
{
my ($plugin_name,	    # e.g.: cpptest
) = @_;
my $struct_id;

my $plugin_type = get_plugin_name_type( $plugin_name);	# e.g.: audit build tool
my $plugin_abt = $plugin_type;				# e.g.: audit bulld tool

my $cur_abt_name = ${$ABT_REFS{$plugin_abt}->[0]};		# $abt_ref. e.g.: GBS::AUDIT GBS::BUILD GBS::TOOL
my @abt_names = get_plugin_name_abt( $plugin_name);		# e.g.: (mingw, mingwd)

my $abt_name;
if (grep( $cur_abt_name eq $_, @abt_names))
{
$abt_name = $cur_abt_name;	# if listed: take current

} else
{
$abt_name = $abt_names[0];	# if ! listed: take first

}

$struct_id = $READ_FUNCS{$plugin_type}->($abt_name);

return $struct_id;
}




sub PLUGIN_get_all_plugin_names($)
{
my ($plugin_type,	# audit, build or tool
) = @_;
my @plugin_names;

init_from_system()
if (!%ALL_PLUGIN_NAMES_REFS);

return @{$ALL_PLUGIN_NAMES_REFS{$plugin_type}};
}




sub PLUGIN_get_platform($)
{
my ($abt_name,
) = @_;


init_from_system()
if (!%ALL_ABT_PLATFORMS);

return $ALL_ABT_PLATFORMS{$abt_name};
}




sub get_plugin_name_type($)
{
my ($plugin_name,
) = @_;
my $plugin_type;	# audit, build or tool

init_from_system()
if (!%ALL_PLUGIN_TYPES);

$plugin_type = $ALL_PLUGIN_TYPES{$plugin_name};
ENV_sig( F => "Invalid Plugin '$plugin_name'")
if (!defined $plugin_type);

return $plugin_type;
}




sub PLUGIN_get_abt_plugin_name($)
{
my ($abt_name,	# e.g. build_name
) = @_;
my $plugin_name;

init_from_system()
if (!%ALL_PLUGINS);


return $ALL_PLUGINS{$abt_name};
}




sub get_plugin_name_abt($)
{
my ($plugin_name,	    # e.g.: cpptest
) = @_;


init_from_system()
if (!%ALL_ABT_NAMES);

return @{$ALL_ABT_NAMES{$plugin_name}};
}





sub PLUGIN_get_abt_names($)
{
my ($plugin_type,	# audit, build or tool
) = @_;
my @abt_names;

if (!%ABT_NAMES_REFS)
{
foreach my $system_type (@SYSTEM_TYPES)	# (audits builds tool)
{
my @names = SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '.', $system_type);
my $plugin_type = $SYSTEM2PLUGIN{$system_type};
$ABT_NAMES_REFS{$plugin_type} = [ @names ];
}

}

return @{$ABT_NAMES_REFS{$plugin_type}};
}





sub PLUGIN_get_all_abt_names($)
{
my ($plugin_type,	# audit, build or tool
) = @_;
my @abt_names;

if (!%ALL_ABT_NAMES_REFS)
{
foreach my $system_type (@SYSTEM_TYPES)	# (audits builds tool)
{
my @names = SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '*', $system_type);
my $plugin_type = $SYSTEM2PLUGIN{$system_type};
$ALL_ABT_NAMES_REFS{$plugin_type} = [ @names ];
}

}

return @{$ALL_ABT_NAMES_REFS{$plugin_type}};
}




sub init_from_system()
{
my ($plugin_name,
) = @_;


foreach my $system_type (@SYSTEM_TYPES)	# (audits builds tool)
{
my %plugin_names;

foreach my $platform (SYSTEM_get_osnames( $GBS::ROOT_PATH, $system_type))
{
my @refs = SYSTEM_get_os_refs( $GBS::ROOT_PATH, $platform, $system_type);

foreach my $ref (@refs)
{
my ($abt_name, $plugin_name) = @{$ref};
$ALL_PLUGIN_TYPES{$plugin_name} = $SYSTEM2PLUGIN{$system_type};
$ALL_PLUGINS{$abt_name} = $plugin_name;
push @{$ALL_ABT_NAMES{$plugin_name}}, $abt_name
if (!grep( $_ eq $abt_name, @{$ALL_ABT_NAMES{$plugin_name}}));
$ALL_ABT_PLATFORMS{$abt_name} = $platform;
$plugin_names{$plugin_name} = 1;
}
}
my $abt_name = $SYSTEM2PLUGIN{$system_type};
$ALL_PLUGIN_NAMES_REFS{$abt_name} = [ sort keys %plugin_names ];
}





}

1;
