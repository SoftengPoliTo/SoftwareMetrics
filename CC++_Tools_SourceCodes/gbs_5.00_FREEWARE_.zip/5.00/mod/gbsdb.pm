#=================================================
#
#   gbsdb.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbsdb;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSDB_last_root_get
GBSDB_last_root_write
GBSDB_roots_get
GBSDB_roots_write
GBSDB_maps_get
GBSDB_maps_write
);
}




use glo::env;
use glo::spit;
use glo::slurp;
use mod::fspec;




sub GBSDB_last_root_get();
sub GBSDB_roots_get();
sub GBSDB_maps_get();
sub GBSDB_last_root_write($);
sub GBSDB_roots_write($);
sub GBSDB_maps_write($);

sub read_file($);
sub write_file();




my $THIS_OS = $^O;




my $GBSDB_FILESPEC = FSPEC_gbsdb();

my $CURRENT_FILE = '';
my %LAST_ROOT_PATH;	    # last_root-$os=$last_root_path

my %ROOT_PATH_REFS;	    # roots-$os=$root_path

my %MAP_REFS;		    # maps-$os=$win_drive,$unix_path





sub GBSDB_last_root_get()
{
my $last_root_path;

read_file( $GBSDB_FILESPEC);
$last_root_path = $LAST_ROOT_PATH{$THIS_OS};

return (defined $last_root_path) ? $last_root_path : '';
}




sub GBSDB_roots_get()
{
read_file( $GBSDB_FILESPEC);

return @{$ROOT_PATH_REFS{$THIS_OS}};
}





sub GBSDB_maps_get()
{
read_file( $GBSDB_FILESPEC);

return @{$MAP_REFS{$THIS_OS}};
}




sub GBSDB_last_root_write($)
{
my ($last_root_path) = @_;

if ($last_root_path ne '')
{
my $current_last_root_path = GBSDB_last_root_get();
if ($last_root_path ne $current_last_root_path)
{
$LAST_ROOT_PATH{$THIS_OS} = $last_root_path;
write_file();
}
}
}




sub GBSDB_roots_write($)
{
my ($root_paths_ref) = @_;

read_file( $GBSDB_FILESPEC);
$ROOT_PATH_REFS{$THIS_OS} = [ sort( @{$root_paths_ref}) ];
write_file();
}





sub GBSDB_maps_write($)
{
my ($map_refs_ref) = @_;

read_file( $GBSDB_FILESPEC);
$MAP_REFS{$THIS_OS} = @{$map_refs_ref};	# keep original order!
write_file();
}




sub read_file($)
{
my ($filespec) = @_;

if ($filespec ne $CURRENT_FILE)
{



%LAST_ROOT_PATH = ();
%ROOT_PATH_REFS = ();
$ROOT_PATH_REFS{$THIS_OS} = [];
%MAP_REFS = ();
$MAP_REFS{$THIS_OS} = [];


if (-e $filespec)
{
foreach my $line (SLURP_file( $filespec))
{
next if ($line eq "");			# skip empty lines
next if (substr( $line, 0, 1) eq "#");	# skip comments


my ($key, $value) = split( /=/, $line, 2);
$value = '' if (!defined $value);
if ($key eq 'id')
{
ENV_sig( W => "Invalid id '$value' in file $filespec")
if ($value ne 'gbsdb');
} else
{
my ($name, $os) = split( '-', $key);
$os = $THIS_OS
if (!defined $os);	# Cater for old notation without OS
if ($name eq 'roots')
{



push @{$ROOT_PATH_REFS{$os}}, ENV_perl_paths_long( $value);
} elsif ($name eq 'last_root')
{



$LAST_ROOT_PATH{$os} = ENV_perl_paths_long( $value);
} elsif ($name eq 'maps')
{



my ($win_drive, $unix_path) = split( ',', $value, 2);
push @{$MAP_REFS{$os}}, [ $win_drive, $unix_path ];
} else
{
ENV_sig( W => "Invalid key '$key' in file $filespec");
}
}
}
} else
{
ENV_whisper( 1, "($filespec) initialised...");
}
$CURRENT_FILE = $filespec;
}
}





sub write_file()
{
my @lines;
push @lines, "id=gbsdb";

foreach my $os (sort( keys (%LAST_ROOT_PATH)))
{
push @lines, "last_root-$os=$LAST_ROOT_PATH{$os}";
}

foreach my $os (sort( keys (%ROOT_PATH_REFS)))
{
push @lines, map { "roots-$os=$_" } @{$ROOT_PATH_REFS{$os}};
}

foreach my $os (sort( keys (%MAP_REFS)))
{
foreach my $ref (@{$MAP_REFS{$os}})
{
my ($drive, $dir) = @{$ref};
push @lines, "maps-$os=$drive,$dir";
}
}



SPIT_file_nl( $CURRENT_FILE, \@lines);
}

1;
