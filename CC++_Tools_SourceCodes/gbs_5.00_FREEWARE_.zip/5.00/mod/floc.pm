#=================================================
#
#   floc.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::floc;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
FLOC_analyse_path
FLOC_analyse_name
FLOC_get_locations
FLOC_validate_filespec
FLOC_get_all_gbs_filenames
);
}




use glo::env;
use mod::gbsglo;
use mod::build;




sub FLOC_analyse_path($);
sub FLOC_analyse_name($);
sub FLOC_get_locations($);
sub FLOC_validate_filespec($);
sub FLOC_get_all_gbs_filenames();

sub check_flincs_file();
sub check_sca_file();




my @GENERIC_FILE_NAMES_REFS = (



[ qr/^audit(\.gbs|\.usr)$/,			0,  'audit',		],
[ qr/^sysflags(_.*|)(\.gbs|\.usr)$/,	3,  'sysflags',	],  # $src_type
[ qr/^sysincs(_.*|)(\.gbs|\.usr)$/,	3,  'sysincs',		],  # $src_type
[ qr/^comment_chars(\.gbs|\.usr)$/,		0,  'comment_chars',	],  # No .usr file!
[ qr/^export(\.gbs|\.usr)$/,		0,  'export',		],
[ qr/^flags(_.*|)(\.gbs|\.usr)$/,		3,  'flags',		],  # $src_type
[ qr/^gbsall(\.bat|\.sh|)$/,		1,  'gbsall',		],  # batch-file
[ qr/^gbssub(\.bat|\.sh|)$/,		1,  'gbssub',		],  # batch-file
[ qr/^incs(_.*|)(\.gbs|\.usr)$/,		3,  'incs',		],  # $src_type
[ qr/^owners(\.gbs|\.usr)$/,		0,  'owners',		],
[ qr/^Makefile\.mk$/,			-1, 'makefile',		],
[ qr/^sca(_.*|)(\.gbs|\.usr)$/,		4,  'sca',		],  # $build or <uppercase_name>
[ qr/^scope(\.gbs|\.usr)$/,			0,  'scope',		],
[ qr/^ssprop(\.gbs|\.usr)$/,		0,  'ssprop',		],  # No .usr file!
[ qr/^steps(\.gbs|\.usr)$/,			0,  'steps',		],
[ qr/^switch(\.gbs|.usr|)(\.bat|\.sh|)$/,	2,  'switch',		],  # batch-file
[ qr/^sys(\.gbs|\.usr)$/,			0,  'sys',		],
[ qr/^system(\.gbs|\.usr)$/,		0,  'system',		],
[ qr/^build(\.gbs|\.usr)$/,			0,  'build',		],
[ qr/^tool(\.gbs|\.usr)$/,			0,  'tool',		],
[ qr/^.*(\.gbs|\.usr)$/,			-2, 'unkgbs',		],
[ qr/.*/,					-2, 'any',		],
);

my %FILE_DEFS = (





audit   => [
0, 1, 0, 0,
[ 'sysaudit/<A>' ],
],
sysflags   => [
0, 1, 0, 0,
[ 'sysbuild/<B>' ],
],
sysincs   => [
0, 1, 0, 0,
[ 'sysbuild/<B>' ],
],
build  => [
0, 1, 0, 0,
[ 'sysbuild/<B>' ],
],
comment_chars  => [
0, 1, 0, 2,
[ 'sys/templates' ],
],

flags   => [
0, 1, 0, 0,
[ qw( dev/<S>/comp/<C>/opt/<B>
dev/<S>/comp/<C>/opt
dev/<S>/build/<B>
dev/<S>/build
sysbuild/<B>
sysbuild ) ],
],
incs    => [
0, 1, 0, 0,
[ qw( dev/<S>/comp/<C>/opt/<B>
dev/<S>/comp/<C>/opt
dev/<S>/build/<B>
dev/<S>/build
sysbuild/<B>
sysbuild ) ],
],
export  => [
3, 2, 1, 0,
[ qw( dev/<S>
dev/<S>/comp/<C> ) ],
],
gbsall  => [
0, 0, 0, 0,
[ $GBS::SCRIPTS_ROOT, $GBS::BASE_PATH ],
],
gbssub  => [
1, 2, 0, 0,
[ 'dev/<S>' ],
],
makefile  => [
0, 2, 0, 0,
[ 'dev/<S>' ],
],
owners  => [
0, 1, 0, 1,
[ 'sys' ],
],
sca    => [
0, 1, 0, 0,
[ qw( dev/<S>/audit/<A>
sysaudit/<A> ) ],
],
scope   => [
3, 3, 0, 0,
[ 'dev/<S>/comp/<C>' ],
],
ssprop  => [
1, 2, 0, 2,
[ 'dev/<S>' ],
],
steps   => [
0, 1, 0, 0,
[ 'sys' ],
],
switch  => [
0, 1, 0, 0,
[ '' ],
],
sys	    => [
0, 1, 0, 0,
[ 'sys' ],
],
system  => [
0, 1, 0, 1,
[ '' ],
],
tool    => [
0, 1, 0, 0,
[ 'systool/<T>' ],
],
unkgbs  => [
0, 0, 0, 0,
[],
],
any  => [
0, 0, 1, 0,
[],
],
);




my $CUR_PATH = '';
my $TOP = '';
my $SUBSYS = '';
my $COMPONENT = '';
my $SUBDIR = '';
my $AUDIT = '';
my $BUILD = '';
my $TOOL = '';
my $ABT_NAME = '';

my %ABT_REFS = (

audit => [ \$AUDIT, \%GBS::ALL_AUDITS ],
build => [ \$BUILD, \%GBS::ALL_BUILDS ],
tool  => [ \$TOOL,  \%GBS::ALL_TOOLS  ],
);
my @ABT_NAMES = (sort keys %ABT_REFS);
my @ALL_SUBDIRS = qw( aud bld dat inc loc opt sav src);




my $CUR_FILE = '';
my $FILE = '';			# name.type
my $GENERIC_FILE_NAME;
my $IS_GBS_FILE;		# bool
my $GENERIC_FILE_NAME_VAR_PART;	# without leading '_'. May be undef
my $GBS_FILE_TYPE;		# .gbs, .usr or ''




sub FLOC_analyse_path($)
{
my ($path,		  # directory path
) = @_;


if ($path ne $CUR_PATH)
{
$CUR_PATH = '';
($TOP, $SUBSYS, $COMPONENT, $SUBDIR, $AUDIT, $BUILD, $TOOL, $ABT_NAME) = ( '', '', '', '', '', '', '', '');

my $root_path = GBSGLO_find_root_path( $path);
if ($root_path ne '')
{
my $gbs_path = substr( $path, length( $root_path));
$gbs_path = substr( $gbs_path, 1)
if (substr( $gbs_path, 0, 1) eq '/');

my @dirs = (split( '/', $gbs_path), '');
$TOP = shift @dirs;
if ($TOP eq 'dev')
{
$SUBSYS = shift @dirs;
if ($SUBSYS ne '')
{
my $level_3 = shift @dirs;
if ($level_3 eq 'comp' && GBSGLO_subsystem_is_full_gbs( $SUBSYS, $root_path))
{
$COMPONENT = shift @dirs;	# level 4
if ($COMPONENT ne '')
{
$SUBDIR = shift @dirs;	    # level 5
if ($SUBDIR ne '')
{
if (grep( $SUBDIR eq $_, @ALL_SUBDIRS))
{
my $level_6 = shift @dirs;
if ($level_6 ne '')
{
if ($SUBDIR eq 'bld')
{
$BUILD = $level_6;
} elsif ($SUBDIR eq 'aud')
{
$AUDIT = $level_6;
$BUILD = shift @dirs;   # level 7
} elsif ($SUBDIR eq 'opt')
{
if (exists $GBS::ALL_BUILDS{$level_6})
{
$BUILD = $level_6;
} elsif (exists $GBS::ALL_AUDITS{$level_6})
{
$AUDIT = $level_6;
}

}
}
} else
{
ENV_sig( E => "Invalid SubDir '$SUBDIR'. Must be one of (@ALL_SUBDIRS)");
$SUBDIR = '';
}
}
}
} elsif ($level_3 =~ /^(audit|build|tool)$/)
{
$ABT_NAME = $1;
my $abt = shift @dirs;
if ($abt ne '')
{
my $value_ref = $ABT_REFS{$ABT_NAME}->[0];
$$value_ref = $abt;			# Set $AUDIT, $BUILD or $TOOL
$BUILD = shift @dirs
if ($ABT_NAME eq 'audit');
}
}
}
} elsif ($TOP =~ /^sys(audit|build|tool)$/)
{
$ABT_NAME = $1;
my $abt = shift @dirs;
if ($abt ne '')
{
my $value_ref = $ABT_REFS{$ABT_NAME}->[0];
$$value_ref = $abt;			# Set $AUDIT, $BUILD or $TOOL
$BUILD = shift @dirs
if ($ABT_NAME eq 'sysaudit');
}
}
}
foreach my $abt_name (@ABT_NAMES)
{
my ($value_ref, $all_values_ref) = @{$ABT_REFS{$abt_name}};
my $value = $$value_ref;
if ($value ne '')
{
if (!exists $all_values_ref->{$value})
{
my @allowed_values = sort keys %{$all_values_ref};
ENV_sig( E => "Invalid $abt_name: '$value'", "- Allowed (@allowed_values)");
$$value_ref = '';
}
}
}
$CUR_PATH = $path;

} else
{

}


return ($TOP, $SUBSYS, $COMPONENT, $SUBDIR, $AUDIT, $BUILD, $TOOL, $ABT_NAME);
}




sub FLOC_analyse_name($)
{
my ($file,		    # name.type without Path
) = @_;


my ($file_name, $file_type) = ENV_split_spec_nt( $file);

if ($file ne $CUR_FILE && $file ne $FILE)
{
$CUR_FILE = '';
($FILE, $GENERIC_FILE_NAME, $IS_GBS_FILE, $GENERIC_FILE_NAME_VAR_PART, $GBS_FILE_TYPE) = ( '', '', 1, '', '');




my $found_ref;
my $arg1;
my $arg2;
foreach my $ref (@GENERIC_FILE_NAMES_REFS)
{
if ($file =~ $ref->[0])		# $re
{
$found_ref = $ref;
$arg1 = $1;
$arg2 = $2;
last;
}
}




my ($new_file_name, $new_file_type) = ENV_split_spec_nt( $file);
if (defined $found_ref)
{
(undef, my $type, $GENERIC_FILE_NAME) = @{$found_ref};



if ($type == 0)	    # scope.gbs scope.usr
{
$GBS_FILE_TYPE = $arg1;
} elsif ($type == 1)    # gbssub.bat gbssub.sh
{
my $file_type = $arg1;
if ($file_type eq '')
{
$new_file_type = $GBS::SHELL_FILETYPE;
$new_file_name = $file;
$FILE = "$new_file_name$new_file_type";
ENV_say( 1, "Assumed $FILE");
}

} elsif ($type == 2)    # switch.gbs.bat switch.gbs.sh switch.usr.bat switch.usr.sh
{
my $file_type_gbs = $arg1;
my $file_type = $arg2;
if ($file_type_gbs eq '')
{
$GBS_FILE_TYPE = '.gbs';
$new_file_name = "$new_file_name$GBS_FILE_TYPE";
$FILE = "$new_file_name$new_file_type";
} else
{
$GBS_FILE_TYPE = $file_type_gbs;
}
if ($file_type eq '')
{
$new_file_type = $GBS::SHELL_FILETYPE;
$new_file_name = $file;
$FILE = "$new_file_name$new_file_type";
}
ENV_say( 1, "Assumed $FILE")
if ($file_type_gbs eq '' || $file_type eq '');
} elsif ($type == 3)    # flags(_*).gbs flags(_*).usr
{
$GENERIC_FILE_NAME_VAR_PART = $arg1;
ENV_sig( EE => "Format of $GENERIC_FILE_NAME file name is '${GENERIC_FILE_NAME}_<src_type>' ($file)")
if ($GENERIC_FILE_NAME_VAR_PART !~ /^_\S/);
$GENERIC_FILE_NAME_VAR_PART = substr( $GENERIC_FILE_NAME_VAR_PART, 1);	# remove leading '_'
$GBS_FILE_TYPE = $arg2;
check_flincs_file();
} elsif ($type == 4)    # sca(_*).gbs sca(_*).usr
{
$GENERIC_FILE_NAME_VAR_PART = $arg1;
ENV_sig( EE => "Format of $GENERIC_FILE_NAME file name is 'sca_<build>' or sca_<UPPERCASE_NAME> ($file)")
if ($GENERIC_FILE_NAME_VAR_PART !~ /^_\S/);
$GENERIC_FILE_NAME_VAR_PART = substr( $GENERIC_FILE_NAME_VAR_PART, 1);	# remove leading '_'
$GBS_FILE_TYPE = $arg2;
check_sca_file();
} elsif ($type == -1)    # Makefile
{

} elsif ($type == -2)    # anygbs & any
{
$IS_GBS_FILE = 0;
if ($GENERIC_FILE_NAME eq 'unkgbs')
{
ENV_sig( W =>  "Non GBS file with type $new_file_type ($file)");
}
} else
{
ENV_sig( F => "Impossible type ($type)");
}
$FILE = "$new_file_name$new_file_type";
} else
{
ENV_sig( F => "No Pattern match for '$file'");
}
$CUR_FILE = $file;
} else
{

}



return (wantarray) ? ($FILE, $GENERIC_FILE_NAME, $IS_GBS_FILE, $GENERIC_FILE_NAME_VAR_PART, $GBS_FILE_TYPE) : $FILE;
}




sub check_flincs_file()
{








ENV_sig( EE => 'No Builds defined')
if (!@GBS::ALL_BUILDS);




my $src_type = ".$GENERIC_FILE_NAME_VAR_PART";
if (!BUILD_is_src_type( $GBS::BUILD, $src_type))
{
my @src_types = BUILD_get_src_types( $GBS::BUILD);
ENV_sig( W => "Unknown src type '$src_type' for file '$FILE' in this context ($BUILD)",
"- Allowed src_types: @src_types");
}
}




sub check_sca_file()
{








ENV_sig( EE => 'No Builds defined')
if (!@GBS::ALL_BUILDS);
ENV_sig( EE => "No Audits defined")
if (!@GBS::ALL_AUDITS);




if (!exists $GBS::ALL_BUILDS{$GENERIC_FILE_NAME_VAR_PART} &&
$GENERIC_FILE_NAME_VAR_PART ne uc $GENERIC_FILE_NAME_VAR_PART)
{
ENV_sig( EE => "Invalid postfix '$GENERIC_FILE_NAME_VAR_PART' for file '$FILE'",
'- Must be either a Build name or an uppercase name',
"- Allowed Build names: @GBS::ALL_BUILDS");
}
}




sub FLOC_get_locations($)
{
my ($file,
) = @_;

FLOC_analyse_name( $file);	# Sets GENERIC_FILE_NAME

my @locations = @{$FILE_DEFS{$GENERIC_FILE_NAME}->[4]};


return @locations;
}




sub FLOC_validate_filespec($)
{
my ($filespec,
) = @_;
my $errors_ref;    # ($errors_ref, $GENERIC_FILE_NAME, $SUBSYS, $COMPONENT, $SUBDIR, $AUDIT, $BUILD, $TOOL, $ABT_NAME)
my @errors;

my ($path, $file) = ENV_split_spec_pf( $filespec);

FLOC_analyse_name( $file);		# Sets GENERIC_FILE_NAME, etc
FLOC_analyse_path( $path);		# Sets SYSBSYS, COMPONENT, etc

if ($IS_GBS_FILE)
{



my @locations = @{$FILE_DEFS{$GENERIC_FILE_NAME}->[4]};


my %loc_refs = (
S   => \$SUBSYS,
C   => \$COMPONENT,
A   => \$AUDIT,
B   => \$BUILD,
T   => \$TOOL,
);

my $rel_path = ENV_chop_path( $path, $GBS::ROOT_PATH);

my $match_found = 0;
foreach my $location (@locations)
{

foreach my $scabt (keys %loc_refs)
{
my $scabt_value = ${$loc_refs{$scabt}};

$location =~ s/<$scabt>/$scabt_value/;
}
if ($rel_path eq $location)
{
$match_found = 1;
last;
}
}

if (!$match_found)
{
my @locations = @{$FILE_DEFS{$GENERIC_FILE_NAME}->[4]};
push @errors, 'Invalid GBS file location:', "- $path",
'Allowed locations are:', map { "  \$GBS_ROOT_PATH/$_" } @locations;
}





} else
{



if ($SUBDIR eq 'src' || $SUBDIR eq 'loc' || $SUBDIR eq 'inc')
{
my $allowed_path = "$GBS::ROOT_PATH/dev/$SUBSYS/comp/$COMPONENT/$SUBDIR";
if ($CUR_PATH ne $allowed_path)
{
my $sub_path = substr( $CUR_PATH, length( $allowed_path) + 1);
push @errors, "Cannot specify SubPath ($sub_path) in SubDir $SUBDIR";
}

my $file_type = ENV_split_spec_t( $FILE);
my @builds = GBSGLO_component_builds( $SUBSYS, $COMPONENT);
if ($SUBDIR eq 'src')
{
my @src_types = map { BUILD_get_src_types( $_) } @builds;
if (!grep $_ eq $file_type, @src_types)
{
push @errors, "Unknown src type '$file_type' in this context ($BUILD)";
}
} else # ($SUBDIR eq 'loc' || $SUBDIR eq 'inc')
{
my @inc_types = map { BUILD_get_inc_types( $_) } @builds;
if (!grep $_ eq $file_type, @inc_types)
{
push @errors, "Unknown $SUBDIR type '$file_type' in this context ($BUILD)";
}
}
}
}
$errors_ref = [ @errors ]
if (@errors);


return wantarray ? ($errors_ref, $GENERIC_FILE_NAME, $SUBSYS, $COMPONENT, $SUBDIR, $AUDIT, $BUILD, $TOOL, $ABT_NAME) : $errors_ref;
}





sub FLOC_get_all_gbs_filenames()
{
my @all_gbs_files = map { $_->[2] } grep( $_->[1] >= 0, @GENERIC_FILE_NAMES_REFS);

return @all_gbs_files;
}

1;

