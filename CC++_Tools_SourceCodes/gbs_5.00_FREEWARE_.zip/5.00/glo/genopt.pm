#=================================================
#
#   genopt.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::genopt;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GENOPT_set_flag_prefix
GENOPT_set_optdefs
GENOPT_set_conflicts
GENOPT_set_envdefs
GENOPT_parse
GENOPT_get
GENOPT_get_all
GENOPT_get_changed
GENOPT_only_help_executed
GENOPT_makeopt
GENOPT_print_help
);
}




use glo::env;
use glo::slurp;
use glo::format;
use glo::types;
use glo::genoptglo;




sub GENOPT_set_flag_prefix($);
sub GENOPT_set_optdefs($$$$);
sub GENOPT_set_conflicts($);
sub GENOPT_set_envdefs($$$);
sub GENOPT_parse();
sub GENOPT_get($);
sub GENOPT_get_all();
sub GENOPT_get_changed($);
sub GENOPT_only_help_executed();
sub GENOPT_makeopt($$@);
sub GENOPT_print_help($);

sub do_semantics();
sub handle_opt_bool($);
sub handle_opt_string($);
sub handle_positional($);
sub do_item($);
sub handle_envvar($);
sub handle_help($);
sub do_conflicts();
sub print_help($@);
sub store_par($$$@);
sub syntax_error($;@);
sub option_error($$$);
sub print_usage();
sub print_args_usage(@);
sub parse_args(@);
sub unix_glob(@);
sub get_opt_values($);
sub put_opt_values($@);




my $IS_WIN32 = ENV_is_win32();

my $PROG_NAME;
my @ALIASES;
my $LONG_HELP_REF;
my $EXTRA_HELP_REF;

my $HELP_EXECUTED = 0;




my @MNEMS_ORDER;    # mnems

my @CONFLICT_REFS;







my $FLAG_PREFIX = '--';
my $FLAG_PREFIX_QM = quotemeta $FLAG_PREFIX;

my $ENV_ALLOW = 0;
my $ENV_SET_HANDLER;	    # $result = $ref->( $name, $value);
my $ENV_PRINT_HANDLER;	    # $ref->()





my @ARGS_ORDER;
my @ARG_REFS;	    # does not contain key '<*>'
my %ARG_REFS;	    # may contain key '<*>'




my $HIGHEST_POS_PAR;

my %IN_ENVS;

my @IN_ENVS_ORDER;




my %DEFAULT_VALUES;


my %OPTS;



my @OPTS_TO_PRINT;
my $NR_ERRORS = 0;





sub GENOPT_set_flag_prefix($)
{
my ($prefix) = @_;

GENOPTGLO_set_flag_prefix( $prefix);

$FLAG_PREFIX = $prefix;
$FLAG_PREFIX_QM = quotemeta $FLAG_PREFIX;
}




sub GENOPT_set_optdefs($$$$)
{
my ($prog_name_or_ref,	# this is the name of the program, with aliasses
$items_refs_ref,	# [ [ $mnem, $opt_name, $type_spec_or_ref, $default, $item_help_or_ref ], ... ]
$help_text_or_ref,	# this is the general help-text. NOT optional
$extra_text_or_ref,	# this is the (optional) aditional help-text
) = @_;

























$HIGHEST_POS_PAR = GENOPTGLO_set_optdefs( $items_refs_ref);




if (ref $prog_name_or_ref)
{
($PROG_NAME, @ALIASES) = @{$prog_name_or_ref};
} else
{
$PROG_NAME = $prog_name_or_ref;
}
$LONG_HELP_REF = (ref $help_text_or_ref) ? $help_text_or_ref : [ $help_text_or_ref ];
$EXTRA_HELP_REF = (ref $extra_text_or_ref) ? $extra_text_or_ref : [ $extra_text_or_ref ]
if (defined $extra_text_or_ref);
}




sub GENOPT_set_conflicts($)
{
my ($con_refs_ref,	# [ [ $mnem, @values ], @r_args_or_refs ], ... ]



) = @_;

@CONFLICT_REFS = GENOPTGLO_conflicts( $con_refs_ref);


}




sub GENOPT_set_envdefs($$$)
{
(	$ENV_SET_HANDLER,   	    # $result = ref->( $name, $value);
$ENV_PRINT_HANDLER,	    # $ref->()
my $envvars_ref,
) = @_;

if (defined $envvars_ref)
{
foreach my $name (@{$envvars_ref})
{
$ENV_SET_HANDLER->( $name, undef);	# register only
}
$ENV_ALLOW = 1;
} else
{
$ENV_ALLOW = 0;
}
}




sub GENOPT_parse()
{
$NR_ERRORS = 0;
@OPTS_TO_PRINT = ();




%DEFAULT_VALUES = GENOPTGLO_get_init_values();
while ( my ($opt_name, $init_value_or_ref) = each %DEFAULT_VALUES )
{
$OPTS{$opt_name} = (ref $init_value_or_ref) ? [] : undef;
}
@MNEMS_ORDER = GENOPTGLO_get_all_mnems();




parse_args( @ARGV);




do_semantics();




if (exists $ARG_REFS{verbose})
{
my $verbose = $OPTS{verbose};
ENV_set_verbose( $verbose);

}

return;
}




sub GENOPT_get($)
{
my ($opt_name) = @_;

my $val_or_ref = $OPTS{$opt_name};
ENV_sig( F => "No such opt '$opt_name'")
if (!defined $val_or_ref);
if (wantarray)
{
ENV_sig( F => "Not list: $opt_name")
if (!ref $val_or_ref);
return @{$val_or_ref};
} else
{
ENV_sig( F => "Is list: $opt_name")
if (ref $val_or_ref);
return $val_or_ref;
}
}




sub GENOPT_get_all()
{
my @args = map { $_->[0] } @ARG_REFS;    # $original_arg

return @args;
}




sub GENOPT_get_changed($)
{
my ($excludes_ref) = @_;
my @opts;			    # items that do not have a default value

my @excludes = @{$excludes_ref};
my $remaining_pos_args_done = 0;

foreach my $arg (@ARGS_ORDER)
{
my $mnem = $arg;

if ($mnem =~ /^<\d+>$/ && !GENOPTGLO_opt_exists( $mnem))
{
next if ($remaining_pos_args_done);
$mnem = '<*>';
$remaining_pos_args_done = 1;
}
my (undef, $opt_name, undef, $default) = GENOPTGLO_get_opt( $mnem);


if (! grep( $opt_name eq $_, @excludes))
{
my $value = get_opt_values( $opt_name);
if ($value ne $default)   # default
{
my $opt = GENOPTGLO_make_opt( $mnem, $value);
$opt =~ s/^<.*>=//;
push @opts, $opt;
}
}
}

foreach my $name (@IN_ENVS_ORDER)
{
my $value = $IN_ENVS{$name};
push @opts, "$name=$value";
}


return @opts;
}




sub GENOPT_only_help_executed()
{
return $HELP_EXECUTED;
}





sub GENOPT_makeopt( $$@)
{
my ($force_make,	# Bool
$opt_name,
@values,
) = @_;

my $value = join( ',', @values);
if ($IS_WIN32)
{
$value =~ s/ /\$_/g;
} else
{
$value =~ s/ /\%_/g;
}

ENV_sig( F => "No such menmonic '$opt_name=$value'")
if (!GENOPTGLO_opt_exists( $opt_name));

if (!$force_make && $value eq GENOPTGLO_get_opt_item( $opt_name, 3))	#  $default
{
return ();
} else
{
return GENOPTGLO_make_opt( $opt_name, $value);
}
}




sub GENOPT_print_help($)
{
my ($key,
) = @_;

print_help( $key, ());
}




sub do_semantics()
{
foreach my $ref (@ARG_REFS)
{



my $arg_type = $ref->[1];

if ($arg_type eq 'b')		    # opt_bool
{
handle_opt_bool( $ref);
} elsif ($arg_type eq 's')	    # opt_string
{
handle_opt_string( $ref);
} elsif ($arg_type eq '*')	    # positional
{
handle_positional( $ref);
} elsif ($arg_type eq '=')	    # EnvVar
{
handle_envvar( $ref);
} elsif ($arg_type eq 'h')	    # opt_help
{
handle_help( $ref);
exit 0;
} else
{
ENV_sig( F => "Impossible else (arg_type=$arg_type)");
}
}




while (my ($opt_name, $value_or_ref) = each %OPTS)
{
if (ref $value_or_ref)
{
if (!@{$value_or_ref})
{
$OPTS{$opt_name} = $DEFAULT_VALUES{$opt_name};
}
} else
{
if (!defined $value_or_ref)
{
$OPTS{$opt_name} = $DEFAULT_VALUES{$opt_name};
}
}
}




foreach my $opt_name (GENOPTGLO_get_mandatory_opt_names())
{
my @values = get_opt_values( $opt_name);
if ((!@values) || (!defined $values[0]) || ($values[0] eq ''))
{
my $full_name = GENOPTGLO_get_full_name( $opt_name);
syntax_error( "Mandatory '$full_name' missing", $opt_name);
}
}




do_conflicts();




if ($NR_ERRORS > 0)
{
print_usage();
print_args_usage( @OPTS_TO_PRINT);
ENV_say( 1, "Command-line error(s)",
"$PROG_NAME @ARGV");
exit 1;
}
}




sub handle_opt_bool($)
{
my ($arg_ref,   # [ $original_arg, $arg_type, $key, $value ]
) = @_;

my ($original_arg, $arg_type, $key, $value) = @{$arg_ref};


if (GENOPTGLO_opt_exists( $key))
{
my $item_type = (GENOPTGLO_get_opt_item( $key, 2))[0];	#   $type_spec_ref -> $type
if ($item_type eq 'b')
{
do_item( $arg_ref);
} else
{
option_error( $original_arg, $key, "Not a bool-type option: =<value> required");
}
} else
{
syntax_error( "No such option '$original_arg'");
}
}




sub handle_opt_string($)
{
my ($arg_ref,   # [ $original_arg, $arg_type, $key, $value ]
) = @_;

my ($original_arg, $arg_type, $key, $value) = @{$arg_ref};


if (GENOPTGLO_opt_exists( $key))
{
my $item_type = (GENOPTGLO_get_opt_item( $key, 2))[0];	#   $type_spec_ref -> $type
if ($item_type ne 'b')	    # i, s, t
{
do_item( $arg_ref);
} else
{
option_error( $original_arg, $key, "Not a string-type option: + or - required");
}
} else
{
syntax_error( "No such option '$original_arg'");
}
}




sub handle_positional($)
{
my ($arg_ref,   # [ $original_arg, $arg_type, $key, $value ]
) = @_;

my ($original_arg, undef, $key, $value) = @{$arg_ref};


if ($key ne '<*>')
{
if (GENOPTGLO_opt_exists( $key))
{
do_item( $arg_ref);
} else
{
my $remainder_key = '<*>';
if (GENOPTGLO_opt_exists( $remainder_key))
{
$arg_ref->[2] = $remainder_key;	# $key
do_item( $arg_ref);
} else
{
syntax_error( "Invalid Positional Parameter $key with value '$original_arg'");
}
}
}
}




sub do_item($)
{
my ($arg_ref,   # [ $original_arg, $arg_type, $key, $value ]
) = @_;

my ($original_arg, undef, $key, $value) = @{$arg_ref};
my (undef, $opt_name, $type_spec_ref) = GENOPTGLO_get_opt( $key);
my ($item_type, $occur) = @{$type_spec_ref};




my @error_texts;
my @new_values = TYPES_get_values( value => $value, $type_spec_ref, \@error_texts);
map { option_error( $original_arg, $key, $_) } @error_texts;
store_par( $occur, $opt_name, $key, @new_values);
}




sub handle_envvar($)
{
my ($arg_ref,   # [ $original_arg, $arg_type, $key, $value ]
) = @_;

my ($original_arg, undef, $key, $value) = @{$arg_ref};


if ($ENV_ALLOW)
{
my $new_value = $ENV_SET_HANDLER->( $key, $value);
syntax_error( "'$original_arg' Not accepted")
if (!defined $new_value);
$IN_ENVS{ $key} = $value;
push @IN_ENVS_ORDER, $key;
} else
{
syntax_error( "Cannot specify EnvVar Arguments ($original_arg)");
}
}




sub handle_help($)
{
my ($arg_ref,   # [ $original_arg, $arg_type, $key, $value ]
) = @_;

my $key = $arg_ref->[2];
my @values = split( ' ', $arg_ref->[3]);	# $value


print_help( $key, @values);
}




sub do_conflicts()
{
foreach my $c_ref (@CONFLICT_REFS)
{
my ($l_arg_ref, @r_arg_refs) = @{$c_ref};
my ($l_mnem, @l_values) = @{$l_arg_ref};

my $select;
if (@l_values)
{
my $l_opt_name = GENOPTGLO_get_opt_item( $l_mnem, 1);
my $l_current_value = get_opt_values( $l_opt_name);
$select = grep( $_ eq $l_current_value, @l_values);
} else
{
$select = (exists $ARG_REFS{$l_mnem}) ? 1 : 0;
}
if ($select)
{
foreach my $r_arg_ref (@r_arg_refs)
{
my ($operator, $mnem, @values) = @{$r_arg_ref};

my $is_conflict;
if (@values)
{
my $opt_name = GENOPTGLO_get_opt_item( $mnem, 1);
my $current_value = get_opt_values( $opt_name);
$is_conflict = (grep( $_ eq $current_value, @values)) ? 1 : 0;
} else
{
$is_conflict = (exists $ARG_REFS{$mnem}) ? 1 : 0;
}
$is_conflict ^= 1		# flip the bit
if ($operator eq '!');
if ($is_conflict)
{
my $full_names = GENOPTGLO_make_opt( $l_mnem, \@l_values);
$full_names = "empty $full_names"
if ("@l_values" eq '');
my $conflict = GENOPTGLO_make_opt( $mnem, \@values);
syntax_error( "Combination of $full_names with $conflict is not possible",
($l_mnem, $mnem));
}
}
}
}
}




sub print_help($@)
{
my ($key,
@values
) = @_;

if ($key eq 'help')
{
if (@ALIASES)
{
ENV_say( 0, "$PROG_NAME (@ALIASES):");
} else
{
ENV_say( 0, "$PROG_NAME:");
}
map { ENV_say( 0, "  $_") } @{$LONG_HELP_REF};

print_usage();

my @usages = (@values) ? @values : @MNEMS_ORDER;
print_args_usage( @usages);

if ($ENV_ALLOW)
{
$ENV_PRINT_HANDLER->();
} else
{
ENV_say( 0, "Environment Variables:");
ENV_say( 0, "  None");
}

if ($EXTRA_HELP_REF)
{
ENV_say( 0, "Note:");
map { ENV_say( 0, "  $_") } @{$EXTRA_HELP_REF};
}

my $app_name_lc = lc ENV_get_application_name();
my $help_command = "${app_name_lc}help";
ENV_say( 0, "Help:");
ENV_say( 0, "  Short help: $PROG_NAME --h [ <item-list> ]");
ENV_say( 0, "  Long  help: $PROG_NAME --help [ <item-list> ]");
ENV_say( 0, "  Extensive help (html) can be obtained with command '$help_command'")
unless( $PROG_NAME eq $help_command);
} else  # $help eq '--h'
{
print_usage();
print_args_usage( @values);
}
$HELP_EXECUTED = 1;
}




sub store_par($$$@)
{
my ($occur,
$opt_name,
$opt,
@values
) = @_;


if ($occur eq 's')
{
my $prev_val = $OPTS{$opt_name};
ENV_say( 1, "$opt=$@values replaced $prev_val")
if (defined $prev_val);
}
put_opt_values( $opt_name, @values);
}




sub syntax_error($;@)
{
my ($texts_ref,
@opts,
) = @_;

my @texts = (ref $texts_ref) ? @{$texts_ref} : ($texts_ref);
ENV_sig( E => @texts);
foreach my $opt (@opts)
{
push @OPTS_TO_PRINT, $opt
if (!grep( $opt eq $_, @OPTS_TO_PRINT));
}
$NR_ERRORS++;
}




sub option_error($$$)
{
my ($original_arg,
$opt,
$text,
) = @_;

ENV_sig( E => "Option '$original_arg'", $text);
push @OPTS_TO_PRINT, $opt
if (!grep( $opt eq $_, @OPTS_TO_PRINT));
$NR_ERRORS++;
}




sub print_usage()
{
ENV_say( 0, "Usage:");
my @items;
foreach my $mnem (GENOPTGLO_get_all_mnems())
{
push @items, scalar GENOPTGLO_get_full_spec( $mnem);
}

ENV_say( 0, FORMAT_table( 0, 2, ' ', undef, [ $PROG_NAME, "@items" ]));
}




sub print_args_usage(@)
{
my @args = @_;

if (@args)
{
ENV_say( 0, 'Args:');

my @line_refs;
foreach my $mnem (@args)
{
if (GENOPTGLO_opt_exists( $mnem))
{
my ($full_spec, $opt_name, $mnem,
$full_type, $full_occur, $full_man, $full_constr, $default, @help_lines) = GENOPTGLO_get_full_spec( $mnem);
my @var_items = ( "($opt_name)", $full_man, $full_type, $full_occur );
push @var_items, $full_constr
if ($full_constr ne '');
push @line_refs, [ $full_spec, "@var_items" ];
push @line_refs, [ '',         "default=$default" ]
if ($default ne '');
push @line_refs, map { [ '', $_  ] } @help_lines;
} else
{
ENV_say( 1, "No such mnemonic '$mnem'",
"Available: @MNEMS_ORDER");
exit 9;
}
}
ENV_say( 0, FORMAT_table( 0, 2, '  ', undef, @line_refs));
}
}





sub parse_args(@)
{
my @args = @_;
my ($handle_args, $handle_flags) = (1 ,1);



$handle_flags = 0
if ($FLAG_PREFIX eq '');




@args = ENV_decode( @args);
if ($IS_WIN32)
{
foreach my $arg (@args)
{
$arg =~ s/\$_/ /g;
}
@args = unix_glob( @args);
} else
{
foreach my $arg (@args)
{
$arg =~ s/\%_/ /g;
}
}

@args = ()
if ("@args" eq '');

my $pos_arg_count = 0;
while ($handle_args && @args)
{
my $arg = shift @args;

if ($arg eq '---')	# '---' means: stop handling of arguments
{
$handle_args = 0;
} elsif ($arg eq '--')	# '--' means: stop handling of $FLAG_PREFIX arguments
{
$handle_flags = 0;
} else
{
my ( $original_arg, $arg_type, $key, $value );




$original_arg = $arg;
if ($handle_flags && $arg =~ /^$FLAG_PREFIX_QM(.*)/)	# --opt[+|-], --opt=<value>
{



my $opt = $1;	    # remainder
($key, $value) = $opt =~ /^([a-z]\w*)(.*)/;	# starts with lowercase alpha char followed by word characters
if (defined $key)
{
if ($value eq '' || $value eq '+' || $value eq '-')
{
$arg_type = 'b';
} elsif (substr( $value, 0, 1) eq '=')
{
$arg_type = 's';
$value = substr( $value, 1);
my $fc = substr( $value, 0, 1);
if ($fc eq '"' || $fc eq "'")
{
while (substr( $value, -1, 1) ne $fc && @args)
{
my $next_arg = shift @args;
$value .= ' ' . $next_arg;
$original_arg .= ' ' . $next_arg;
}
syntax_error( "Terminating quote ($fc) not found ($original_arg)")
if (substr( $value, -1, 1) ne $fc);
$value = substr( $value, 1, -1);	    # remove first and last quote

}
} else
{
syntax_error( [ "Invalid value syntax for option '$key' ($arg).",
"Must be either <empty>, - , + or =<value>" ]);
$arg_type = '?';
}
} else
{
syntax_error( "Invalid option name for '$arg'");
$arg_type = '?';
}
} elsif ($arg =~ /^([A-Za-z][A-Za-z0-9_]*)=(.*)/)	# EnvVar (starts with an alphabethical character and contains '=')
{



$arg_type = '=';
$key = $1;	# EnvVar name
$value = $2;	# EnvVar value
} else
{



$pos_arg_count++;
$arg_type = '*';
$key = "<$pos_arg_count>";
$value = $arg;
if ($pos_arg_count > $HIGHEST_POS_PAR)
{
my $arg_ref = $ARG_REFS{'<*>'};
if (defined $arg_ref)
{
my ($old_original_arg, $old_value) = @{$arg_ref}[0,3];
$arg_ref->[0] = "$old_original_arg $original_arg";	# $original_arg
$arg_ref->[3] = "$old_value,$value";			# $value
} else
{
$arg_ref = [ $original_arg, $arg_type, '<*>', $value ];
$ARG_REFS{'<*>'} = $arg_ref;
}
}
}

if ($arg_type eq 's' && $key eq 'inc')
{



my $file = $value;
ENV_sig( EE => "No such '${FLAG_PREFIX_QM}inc' file '$file'")
if (!-e $file);
my @lines = SLURP_file( $file);
@lines = grep !($_ eq '' || substr($_,0,1) eq '#'), @lines;	    # skip empty and comment lines
($handle_args, $handle_flags) = parse_args( @lines);		    # RECURSE! One item per line
} else
{
if (($key eq 'h' || $key eq 'help') && $arg_type eq 'b')
{
$arg_type = 'h';
my @values;
while (@args)
{
my $this_arg = shift @args;
$this_arg =~ s/^$FLAG_PREFIX_QM//;
push @values, $this_arg
if ($this_arg ne 'help' && $this_arg ne 'h');
}
$value = "@values";
}

if ($arg_type ne '?')
{
my $args_ref = [ $original_arg, $arg_type, $key, $value ];
push @ARGS_ORDER, $key;
push @ARG_REFS, $args_ref;
$ARG_REFS{$key} = $args_ref;
}
}
}
}


ENV_say( 1, "Ignored '@args' after '---'")
if (!$handle_args);

return ($handle_args, $handle_flags);
}




sub unix_glob(@)
{
my @args = @_;
my @new_args;

foreach my $arg (@args)
{
my @files = ENV_glob( $arg);

push @new_args, (@files) ? @files : $arg;
}
return @new_args;
}




sub get_opt_values($)
{
my ($opt_name) = @_;

ENV_sig( F => "No such option '$opt_name'")
if (!exists $OPTS{$opt_name});
my $value = $OPTS{$opt_name};
if (wantarray)
{
if (ref $value)
{
return @{$value};
} else
{
return ($value);
}
} else
{
if (ref $value)
{
return join( ',', @{$value});
} else
{
return $value;
}
}
}




sub put_opt_values($@)
{
my ($opt_name,
@values,
) = @_;

ENV_sig( F => "No such option '$opt_name'")
if (!exists $OPTS{$opt_name});
if (ref $OPTS{$opt_name})
{
push @{$OPTS{$opt_name}}, @values;

} else
{
$OPTS{$opt_name} = $values[0];

}
}

1;
