#=================================================
#
#   scmccm.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
#   File states:
#    -2 => 'NO-FILE',
#    -1 => 'NOT-CCM',
#     0 => 'CHECKED-IN',
#     1 => 'CHECKED-OUT',
#=================================================
package glo::scmccm;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SCMCCM_init
SCMCCM_connect
SCMCCM_stop
SCMCCM_get_states
SCMCCM_checkout
SCMCCM_uncheckout
SCMCCM_checkin
SCMCCM_remove
SCMCCM_move
SCMCCM_add_dirs
SCMCCM_add_files
SCMCCM_setup
);
}




use glo::env;
use glo::list;
use glo::slurp;
use glo::spit;
use glo::ask;

ENV_whisper( 1, "Loading CMSynergy Plugin...");




sub SCMCCM_init($$);
sub SCMCCM_connect($$$);
sub SCMCCM_stop();
sub SCMCCM_get_states($);
sub SCMCCM_checkout($);
sub SCMCCM_uncheckout($);
sub SCMCCM_checkin($);
sub SCMCCM_remove($);
sub SCMCCM_move($);
sub SCMCCM_add_dirs($);
sub SCMCCM_add_files($);
sub SCMCCM_setup($$$);

sub get_state($);
sub prepare_for_modify();
sub ccm_set_database();
sub get_db_list();
sub read_appccm($);
sub write_appccm($$$);
sub get_project_status();
sub get_tasks();
sub ccm_attr($);
sub dbg_ccm_query($$);
sub dbg_run3($$$$);




my $IS_WIN32 = (ENV_is_win32());
my $IS_LINUX = (ENV_is_linux());

my $APP_NAME;
my $APP_NAME_LC;
my $REPOSITORY;
my $APP_ROOT_PATH;


my $PROJECT_STATUS;
my $CURRENT_TASK_ID;
my $PREPARED_FOR_MODIFY = 0;
my $EXEC_OS = 'ccm';


my $APP_BASE_PATH = ENV_get_application_base_path();	# GBS_BASE_PATH
my %DATABASES;


my %FSTATES;





sub SCMCCM_init($$)
{
($APP_NAME,
$EXEC_OS) = @_;

$APP_NAME_LC = lc $APP_NAME;
}





sub SCMCCM_connect($$$)
{
($REPOSITORY,
$APP_ROOT_PATH,
undef			    # DATA
) = @_;
my $connect_texts_ref;


if ($IS_LINUX)
{
ENV_sig( F => "Unable to connect",
"No such Repository '$REPOSITORY'")
if (!-e $REPOSITORY);
}





ENV_say( 1, "Searching for CMSynergy session...");
my ($database_path, $ccm_addr) = read_appccm( $REPOSITORY);
my $session = '';
if ($database_path ne '')
{
ENV_setenv( CCM_ADDR => $ccm_addr);
if (ccm_set_database() eq $database_path)
{
$session = $ccm_addr;
ENV_say( 1, "Connected to: $ccm_addr");
}
} else
{
ENV_setenv( CCM_ADDR => $REPOSITORY);
}

if ($session eq '')
{
ENV_say( 1, "Starting CMSynergy...");
my $command = "$EXEC_OS start -d $REPOSITORY -m -nogui -q";
if ($IS_WIN32)
{
my $password_ok;
do
{
my $password = ASK_password( 'Startup CMSynergy Password', undef);

$password = '""'
if ($password eq '');
my $win_command = $command . " -pw $password";

my $stdout;
my $stderr;
my $rc = ENV_run3( $win_command, undef, [0, 1], \$stdout, \$stderr);
if ($rc == 0)
{
$password_ok = 1;
chomp $stdout;
$session = $stdout;
} else	# $rc == 1
{
$password_ok = 0;
ENV_print( 0, $stderr);
if ($stderr =~ 'Unable to validate the password')
{
$password_ok = 0;
} else
{
ENV_sig( EE => "Cannot startup CMSynergy", "rc=$rc");
}
}
} while (!$password_ok);
} else	# Unix
{
my $stdout;
ENV_run3( $command, undef, [0], \$stdout, undef);
chomp $stdout;
$session = $stdout;
}
if ($session ne '')
{
ENV_setenv( CCM_ADDR => $session);
write_appccm( $REPOSITORY, ccm_set_database(), $session);
}
}
ENV_setenv( CCM_ADDR => $session);
ENV_whisper( 1, "'CCM_ADDR' set to: $session");

%FSTATES = ();
return ( undef, undef, undef );
}




sub SCMCCM_stop()
{
ENV_run3( "$EXEC_OS stop", undef, 0, undef, undef);
ENV_setenv( CCM_ADDR => '');
ENV_whisper( 1, "'CCM_ADDR' set to: <empty>");
%FSTATES = ();
}








sub SCMCCM_get_states($)
{
my ($spec_refs_ref) = @_;

foreach my $spec_ref (@{$spec_refs_ref})
{
my ($spec, $state) = @{$spec_ref};
if (!defined $state)
{
$state = $FSTATES{$spec};
if (!defined $state)
{
$state = get_state( $spec);
$FSTATES{$spec} = $state;
}
$spec_ref->[1] = $state;
}
}
}




sub get_state($)
{
my ($filespec) = @_;
my $state;

my $stdout;
my $rc = ENV_run3( "$EXEC_OS attr -s status $filespec", undef, [ 0, 1], \$stdout, undef);
chomp $stdout;

if ($stdout =~ /^Referenced object/)
{
$state = -1;		# Not SCM
} elsif ($stdout eq 'working' ||
$stdout eq 'visible' ||
$stdout eq 'public')
{
$state = 1;		# checked-out
} elsif ($stdout =~ /^released/)
{
$state = 0;		# checked-in
} else
{
ENV_sig( W => "Unknown return '$stdout' from 'attr -s status $filespec'");
$state = 0; #do not break old code!
}
return $state;
}




sub SCMCCM_checkout($)
{
my ($specs_ref) = @_;

prepare_for_modify() if (!$PREPARED_FOR_MODIFY);

my $command = "$EXEC_OS co -c \"Checkout by $APP_NAME\""; # @filespecs";
my $rc = ENV_run3( $command, $specs_ref, [0, 1], undef, undef);
ENV_sig( E => 'Checkout completed with errors')
if ($rc != 0);
map { $FSTATES{$_} = 1 } @{$specs_ref}; # checkout
}




sub SCMCCM_checkin($)
{
my ($specs_ref) = @_;

prepare_for_modify() if (!$PREPARED_FOR_MODIFY);

my $command = "$EXEC_OS ci -c \"Checkin by $APP_NAME\""; # @filespecs";
my $rc = ENV_run3( $command, $specs_ref, [0, 1], undef, undef);
ENV_sig( E => 'Checkin completed with errors')
if ($rc != 0);
map { $FSTATES{$_} = 0 } @{$specs_ref}; # checkin
}




sub SCMCCM_uncheckout($)
{
my ($specs_ref) = @_;

prepare_for_modify() if (!$PREPARED_FOR_MODIFY);

my $command = "$EXEC_OS unuse -d -r"; # @filespecs";
ENV_run3( $command, $specs_ref, 0, undef, undef);
map { $FSTATES{$_} = 0 } @{$specs_ref}; # checkin
}




sub SCMCCM_remove($)
{
my ($specs_ref) = @_;

prepare_for_modify() if (!$PREPARED_FOR_MODIFY);

my $command = "$EXEC_OS unuse"; # @filespecs";
ENV_run3( $command, $specs_ref, 0, undef, undef);
map { $FSTATES{$_} = -1 } @{$specs_ref}; # notscm
}




sub SCMCCM_move($)
{
my ($pair_refs_ref) = @_;

foreach my $ref (@{$pair_refs_ref})
{
my ($old_spec, $new_spec) = @{$ref};
ENV_sig( F => "SCM_move not implemented yet!");		# TBS
$FSTATES{$old_spec} = -1;	# notscm
$FSTATES{$new_spec} = 1;    	# checkout
}
}




sub SCMCCM_add_dirs($)
{
my ($dir_refs_ref) = @_;	#   [ $dir, $ignores_ref ]

prepare_for_modify() if (!$PREPARED_FOR_MODIFY);

my @dir_specs = map { $_->[0] } @{$dir_refs_ref};
my $command = "$EXEC_OS create -type dir -c \"Created by $APP_NAME\""; # @dir_specs";
ENV_run3( $command, \@dir_specs, 0, undef, undef);
map { $FSTATES{$_} = 1 } @dir_specs; # checkout
}




sub SCMCCM_add_files($)
{
my ($files_ref) = @_;

prepare_for_modify() if (!$PREPARED_FOR_MODIFY);

my @afiles;
my @xfiles;
foreach my $file (@{$files_ref})
{
if (-x $file && -f $file && !-B $file)
{
my $type = ENV_split_spec_t( $file);
if ($type eq '' || $type eq '.sh')
{
push @xfiles, $file;
} else
{
push @afiles, $file;
}
} else
{
push @afiles, $file;
}
}


if (@afiles)
{
my $command = "$EXEC_OS create -c \"Created by $APP_NAME\""; # @filespecs";
ENV_run3( $command, \@afiles, 0, undef, undef);
}

if (@xfiles)
{
my $command = "$EXEC_OS create -type shsrc -c \"Created by $APP_NAME\""; # @filespecs";
ENV_run3( $command, \@xfiles, 0, undef, undef);
}
map { $FSTATES{$_} = 1 } @{$files_ref}; # checkout
}




sub prepare_for_modify()
{
get_project_status();




if ($PROJECT_STATUS eq 'prep')
{
my $rc = ENV_run3( "$EXEC_OS set role build_mgr", undef, 0, undef, undef);
}




my $toolwainf = "$APP_ROOT_PATH/.${APP_NAME_LC}ccm";
my ($current_task_id);
if (-f $toolwainf)
{
($current_task_id) = SLURP_file( $toolwainf);
} else
{
$current_task_id = '';
}
$CURRENT_TASK_ID = $current_task_id;

my $index;
do
{
my @task_refs = ( [ '- Try again after adding New Task via GUI', -1 ], get_tasks() );


my $default_index;
if (scalar @task_refs == 1)
{
$default_index = 0;
} elsif (scalar @task_refs == 2)
{
$default_index = 1;
} else
{
$default_index = LIST_firstidx_ref_str( $CURRENT_TASK_ID, \@task_refs, 1);
$default_index = (scalar @task_refs) - 1
if ($default_index == -1);
}
$index = ASK_index_from_menu( 'Enter Task', $default_index, undef, [ @task_refs ]);
if ($index != 0)
{
$CURRENT_TASK_ID = $task_refs[$index]->[1];
}
} while ($index == 0);
ENV_say( 1, "Task $CURRENT_TASK_ID selected");




ENV_run3( "$EXEC_OS task -default $CURRENT_TASK_ID", undef, 0, undef, undef);




if ($CURRENT_TASK_ID ne $current_task_id)
{
ENV_whisper( 1, "Writing $toolwainf...");
SPIT_file_nl( $toolwainf, [ $CURRENT_TASK_ID ]);
}

$PREPARED_FOR_MODIFY = 1;
}




sub SCMCCM_setup($$$)
{
my (undef,				# $app_root_path
$default_scms_repository,
undef,				# $default_scms_data
) = @_;
my ($scms_repository, $scms_data);

ENV_say( 1, 'You now have the opportunity to make sure that CMSynergy is up and running,',
'the database is setup and the new root is mapped to it');
ENV_exit(0)
if (ASK_YNQ( 'Ready to continue? (No will cause a Quit)', 'Y', 1) eq 'N');

my $default_repository = '';
{
my @databases = get_db_list();
$default_repository = $databases[0] if (defined $databases[0]);
}
$default_repository = $default_scms_repository if (!$default_repository);
$default_repository = '' if (!defined $default_repository);
if ($IS_WIN32)
{
$scms_repository = ASK_text( 'Enter Database', $default_repository, -1);
if (ENV_is_abs_path( $default_repository) && substr( $scms_repository, 0, 1) eq '.')
{
$scms_repository = ENV_perl_canon_paths( "$default_repository/$scms_repository");
}
} else
{
$scms_repository = ASK_path( 'Enter Database', $default_repository, -1, 1);
}

return ( $scms_repository, '' );
}




sub ccm_set_database()
{
my $database_path;

my $rc = ENV_run3( "$EXEC_OS set database", undef, [ 0, 1, 2 ], \$database_path, '');
if ($rc == 0)
{
chomp $database_path;
$database_path =~ s!/db/?$!!;	    #!
} else
{
$database_path = '';
}


return $database_path;
}




sub get_db_list()
{
my @databases;

read_appccm( '');
foreach my $ref (values( %DATABASES))
{
push @databases, $ref->[1] if ($ref->[0] eq $^O);
}

return (wantarray) ? sort( @databases) : join( ',', @databases);
}





sub read_appccm($)
{
my ($wanted_database) = @_;
my ($ret_database_path, $ret_ccm_addr) = ('', '');

my $appccm_filespec = "$APP_BASE_PATH/.${APP_NAME_LC}ccm";	# GBS_BASE_ROOT/.gbsccm
ENV_whisper( 1, "Reading '$appccm_filespec' if present...");
if (-f $appccm_filespec)
{
foreach my $line (SLURP_file( $appccm_filespec))
{
my ($os, $database, $database_path, $ccm_addr) = split( ' => ', $line);
$DATABASES{"$os $database"} = [ $os, $database, $database_path, $ccm_addr ];
if ($os eq $^O && $database eq $wanted_database)
{
$ret_database_path = $database_path;
$ret_ccm_addr = $ccm_addr;
}
}
}

return ($ret_database_path, $ret_ccm_addr);
}





sub write_appccm($$$)
{
my ($database,
$database_path,
$ccm_addr) = @_;

read_appccm( '') if (!%DATABASES);
$DATABASES{"$^O $database"} = [ $^O, $database, $database_path, $ccm_addr ];
my @lines;
foreach my $key (sort( keys( %DATABASES)))
{
push @lines, join( ' => ', @{$DATABASES{$key}});
}
my $appccm_filespec = "$APP_BASE_PATH/.${APP_NAME_LC}ccm";
SPIT_file_nl( $appccm_filespec, \@lines);
}




sub get_project_status()
{
my $ccmwaid = ($IS_WIN32) ? '_' : '.';
$ccmwaid .= 'ccmwaid.inf';
my ($db, $cvid, $projectid) = SLURP_file( "$APP_ROOT_PATH/$ccmwaid");

$PROJECT_STATUS = ccm_attr( "status @=$cvid");

}




sub get_tasks()
{
my @task_refs;

my $stdout;
my $rc = ENV_run3( "$EXEC_OS task -query -task_scope all_my_assigned", undef, 0,
\$stdout, undef);

if ($stdout !~ /^No Task/)
{
my @lines = split( /\s*\n/, $stdout);

foreach my $line (@lines)
{
my ($task_id, $text) = $line =~ /\d+\)\s+Task\s+([^:]+):\s+(.*)/;

push @task_refs, [ "Task $task_id: $text", $task_id ];
}
}

return @task_refs;
}




sub ccm_attr($)
{
my ($attr) = @_;
my @lines;

my $command = "$EXEC_OS attr -s $attr";
my $stdout;
ENV_run3( $command, undef, [0], \$stdout, undef);
@lines = split( /\s*\n/, $stdout);

return (wantarray) ? @lines : (defined $lines[0]) ? $lines[0] : '';
}




sub dbg_ccm_query($$)
{
my ($query,
$format,
) = @_;
my @lines;

my $command = "$EXEC_OS query \"$query\" -u";
$command .= " -f \"$format\"" if ($format);
my $stdout;
ENV_run3( $command, undef, [0,1], \$stdout, undef);
@lines = split( /\s*\n/, $stdout);

return (wantarray) ? @lines : (defined $lines[0]) ? $lines[0] : '';
}




sub dbg_run3($$$$)
{
my ($command,
$oks_ref,	# allowed return-codes (default = 0)
$stdout_ref,
$stderr_ref,
) = @_;

my $stdout;
my $stderr;
my $rc = ENV_run3( $command, undef, $oks_ref, \$stdout, \$stderr);
ENV_say( '===',
$stdout,
'---',
$stderr,
'===');

$$stdout_ref = $stdout if (ref $stdout_ref);
$$stderr_ref = $stderr if (ref $stderr_ref);
return $rc;
}

1;


