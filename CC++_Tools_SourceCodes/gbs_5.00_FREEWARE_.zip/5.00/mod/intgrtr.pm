#=================================================
#
#  intgrtr.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::intgrtr;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
INTGTR_main
);
}




use glo::env;
use glo::ask;
use glo::version;
use mod::gbsscm;
use mod::validate;
use mod::system;
use mod::scahist;




sub INTGTR_main($$$);
sub consolidate_audits($$$);
sub version_limits($$$);








sub INTGTR_main($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;

my @menu_items = (
[ "Consolidate (base) Audits",
\&consolidate_audits ],
[ "Set GBS Version Limits",
\&version_limits ],
);

if (VALIDATE_integrator())
{
ASK_menu( 'Select function to perform', \@menu_items, $entries_ref);
}
}




sub consolidate_audits($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref,
) = @_;

if (@GBS::AUDITS)
{
my @audits  = ASK_values_from_list( "Select Audit(s)", '*', 0, \@GBS::AUDITS);
if (@audits)
{
my @builds = ASK_values_from_list( "Select Build(s)", '*', 0, \@GBS::BUILDS);
if (@builds)
{




GBSSCM_preset( 0);
SCAHIST_commit( \@audits, \@builds);
}
}
} else
{
ENV_say( 1, "No Audits defined");
}
}




sub version_limits($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;

GBSSCM_preset( 0);




my $version_start_cur = SYSTEM_get( $GBS::ROOT_PATH, 'version_start');
my $version_end_cur   = SYSTEM_get( $GBS::ROOT_PATH, 'version_end');

my $version_start_new = $version_start_cur;
my $version_end_new   = $version_end_cur;




my $format1 = 'Build %-5.5s: %s';
my $format2 = 'Build %-5.5s: %-17.17s, was: %-17.17s';
ENV_say( 1, "Current Limits:");
ENV_say( 2, sprintf $format1, 'Start', scalar VERSION_full_version_2_version( $version_start_cur),
sprintf $format1, 'End',   scalar VERSION_full_version_2_version( $version_end_cur));




my @build_refs = ( [ '', '' ]);

my $default_value;
foreach my $spec (VERSION_get_all_file_specs( $GBS::SCRIPTS_PATH))
{
my $dir = ENV_split_spec_p( $spec);
my $full_version = VERSION_get_full_version( $dir);
my $version = VERSION_full_version_2_version( $full_version);
$version .= ' Cur'
if ($full_version eq $GBS::FULL_VERSION);
push @build_refs, [ $version, $full_version ];
}
if ($version_start_cur ne '' && !grep( $version_start_cur eq $_->[1], @build_refs))
{
my $version = VERSION_full_version_2_version( $version_start_cur) . ' Gone';
push @build_refs, [ $version , $version_start_cur ];
}
if ($version_end_cur ne '' && !grep( $version_end_cur eq $_->[1], @build_refs))
{
my $version = VERSION_full_version_2_version( $version_end_cur) . ' Gone';
push @build_refs, [ $version , $version_end_cur ];
}
@build_refs = sort( { $a->[1] cmp $b->[1] } @build_refs);




my $ans;
do
{
my $s_index = ASK_index_from_menu( 'Select Build Start', \$version_start_new, undef, [ @build_refs ]);
my $e_index = ASK_index_from_menu( 'Select Build End', \$version_end_new, undef, [ @build_refs ]);
$version_start_new = $build_refs[$s_index]->[1];
$version_end_new   = $build_refs[$e_index]->[1];

ENV_say( 1, "Limits:");
ENV_say( 2, sprintf $format2, 'Start', scalar VERSION_full_version_2_version( $version_start_new),
scalar VERSION_full_version_2_version( $version_start_cur));
ENV_say( 2, sprintf $format2, 'End',   scalar VERSION_full_version_2_version( $version_end_new),
scalar VERSION_full_version_2_version( $version_end_cur));
$ans = ASK_YNQ( 'OK?', 'N', 0);
} while ($ans eq 'N');




if ($ans eq 'Y' &&
($version_start_new ne $version_start_cur ||
$version_end_new   ne $version_end_cur))
{
ENV_say( 1, "Updating system.gbs...");
SYSTEM_put( $GBS::ROOT_PATH, version_start => $version_start_new);
SYSTEM_put( $GBS::ROOT_PATH, version_end   => $version_end_new);
SYSTEM_write();      # Includes backup and SCM_checkout
}
}


1;
