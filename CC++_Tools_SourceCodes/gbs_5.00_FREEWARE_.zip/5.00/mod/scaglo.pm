#=================================================
#
#   scaglo.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::scaglo;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SCAGLO_init
SCAGLO_validate
SCAGLO_create_msg_and_help_files
SCAGLO_handle_unkn_msg
);
}




use glo::env;
use mod::plugin;
use mod::scamsg;
use mod::scahelp;




sub SCAGLO_init($$$);
sub SCAGLO_validate(@);
sub SCAGLO_create_msg_and_help_files();
sub SCAGLO_handle_unkn_msg($$$);








my $PLUGIN_NAME;	    # $GBS::AUDIT_PLUGIN
my $PLUGIN_REL;
my $PLUGIN_NICE_NAME;

my $GBS_PLUGIN_PATH;	    # $GBS::PLUGIN_ROOT/$PLUGIN_NAME/$PLUGIN_REL
my $GBS_MSG_FILESPEC;	    # $GBS_PLUGIN_PATH/msg.txt




my $UNKN_MSG_FUNC;
my $PLUGIN_MSG_FILESPECS_REF;
my $PLUGIN_READ_MSG_FILE_FUNC;
my $MUST_CREATE_HELPFILE;	    	# Bool




sub SCAGLO_init($$$)
{
($PLUGIN_NAME,		# $GBS::AUDIT_PLUGIN
$PLUGIN_REL,
$PLUGIN_NICE_NAME,
) = @_;

$GBS_PLUGIN_PATH = PLUGIN_get_gbs_path( $GBS::AUDIT_PLUGIN);




$GBS_MSG_FILESPEC = SCAMSG_init( $GBS_PLUGIN_PATH);
}






sub SCAGLO_validate(@)
{
($UNKN_MSG_FUNC,
$PLUGIN_MSG_FILESPECS_REF,
$PLUGIN_READ_MSG_FILE_FUNC,
$MUST_CREATE_HELPFILE,		# Bool
) = @_;

my $must_create_all = 0;





if (! -e $GBS_PLUGIN_PATH)
{
ENV_say( 1, "Creating GBS Plugin dirs...");
ENV_mkpath( $GBS_PLUGIN_PATH);
$must_create_all = 1;
}

my $gbs_help_filespec = SCAHELP_get_filespec();




if (!$must_create_all)
{




foreach my $plugin_msg_filespec (@{$PLUGIN_MSG_FILESPECS_REF})
{

if ($plugin_msg_filespec eq '')
{
if (! -e $GBS_MSG_FILESPEC)
{
$must_create_all = 1;
last;
}
} else
{
if (ENV_file_is_newer( $plugin_msg_filespec, $GBS_MSG_FILESPEC))
{
$must_create_all = 1;
last;
}
}

if ($MUST_CREATE_HELPFILE && !$must_create_all)
{



if (ENV_file_is_newer( $plugin_msg_filespec, $gbs_help_filespec))
{
$must_create_all = 1;
last;
}
}
}
}

if ($must_create_all)
{
SCAGLO_create_msg_and_help_files();
}
}




sub SCAGLO_create_msg_and_help_files()
{



if ($MUST_CREATE_HELPFILE)
{
ENV_say( 1, "Creating msg and help files...");
} else
{
ENV_say( 1, "Creating msg file...");
}

SCAHELP_init_help_file( $PLUGIN_NAME, $PLUGIN_REL, $PLUGIN_NICE_NAME)
if ($MUST_CREATE_HELPFILE);

foreach my $msg_ref ($PLUGIN_READ_MSG_FILE_FUNC->( $MUST_CREATE_HELPFILE))	    # All info



{
if (defined $msg_ref->[0])
{



my ($msg_id, $level, $level_text, $msg_text, $help_file_url, $help_heading, $help_lines_ref) = @{$msg_ref};


SCAMSG_add_msg( [ $msg_id, $level, $level_text, $msg_text, $help_file_url ]);
SCAHELP_add_msg_text( $help_file_url, $msg_id, $level_text, $help_heading, $help_lines_ref )
if ($MUST_CREATE_HELPFILE);
} else
{



if ($MUST_CREATE_HELPFILE)
{
my (undef, $help_heading, $href, $help_lines_ref) = @{$msg_ref};
SCAHELP_add_general_text( $help_heading, $href, $help_lines_ref);
}
}
}




SCAMSG_write_file( 1);	# force_write
SCAHELP_write_help_file()
if ($MUST_CREATE_HELPFILE);
}




sub SCAGLO_handle_unkn_msg($$$)
{


return $UNKN_MSG_FUNC->( @_);
}


1;

