#=================================================
#
#   gbsjob.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbsjob;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSJOB_init
GBSJOB_sub
GBSJOB_run
GBSJOB_wait
);
}




use glo::env;
use glo::time;
use glo::spit;
use glo::format;
use glo::genopt;
use glo::proc;
use mod::gbscmd;
use mod::gbsres;
use mod::bgnotifier;
use mod::logsum;





sub GBSJOB_init($$);
sub GBSJOB_sub($$$);
sub GBSJOB_run();
sub GBSJOB_wait();

sub submit();
sub subwin();
sub determine_states();
sub display_jobs($);
sub create_job_file();
sub get_sum_state($);




my @JOB_REFS;



my (
$SUBMODE,			    # Fixed: 'SUBWIN' or 'SUBMIT'
$GBSSYS_COMMAND,		    # Fixed: gbssysbuild, gbssysmake, gbssysaudit, gbssystool
$BUILD_OR_TOOL,		    # Vary
$AUDIT,			    # Vary: may be '-'
$DATE_TIME,			    # Fixed
$OS_LOGFILE_SPEC,		    # Vary: '-' or logfile
$MUST_DISPLAY_NOTIFY_MSG,	    # Fixed
$OS_ROOT_PATH,		    # Fixed
$DISPLAY,			    # Fixed
$COMMAND_ARGS,		    # Fixed E.g.: --builds=test,mingw*
$COMMENT,			    # Fixed
@EXEC_ARGS,			    # Vary. E.g.: gbssysbuild begin bart superglo non_gbs copy_export --files=*:*.*
);

my $DELAY;
my $MUST_MAIL;

my $BG_RC;




sub GBSJOB_init($$)
{
my ($command_name,	    # gbssysbuild, gbssysmake, gbssysaudit
$submit_ref,        # undef == --fg+ (foreground)

) = @_;

if (defined $submit_ref)
{
$SUBMODE = 'SUBMIT';
($DELAY,
$MUST_MAIL,
$MUST_DISPLAY_NOTIFY_MSG,
$COMMENT) = @{$submit_ref};
$OS_LOGFILE_SPEC = undef;
$DISPLAY = ENV_getenv( 'DISPLAY');
} else
{
$SUBMODE = 'SUBWIN';
$DELAY = undef;
$MUST_MAIL = undef;
$MUST_DISPLAY_NOTIFY_MSG = 0;
$COMMENT = '';
$OS_LOGFILE_SPEC = '-';
$DISPLAY = '-';
}
$GBSSYS_COMMAND = $command_name;
$DATE_TIME = GBSRES_numtime_packed();
$OS_ROOT_PATH = ENV_os_paths( $GBS::ROOT_PATH);
my @command_args = grep( ! /^--c=/, GENOPT_get_all());
$COMMAND_ARGS = "@command_args";
}




sub GBSJOB_sub($$$)
{
my ($build_or_tool,
$audit,		    # May be '-'
$exec_args_ref,
) = @_;


push @JOB_REFS, [ $build_or_tool, $audit, $exec_args_ref, undef, undef ];
}




sub GBSJOB_run()
{
if (@JOB_REFS)
{
if ($SUBMODE eq 'SUBMIT')
{
my @build_action_refs;
foreach my $ref (@JOB_REFS)
{
my ($build_or_tool, $audit, $exec_args_ref) = @{$ref};
$BUILD_OR_TOOL = $build_or_tool;
$AUDIT = $audit;
@EXEC_ARGS = ( "${GBSSYS_COMMAND}bg", @{$exec_args_ref} );
$OS_LOGFILE_SPEC = ENV_os_paths( GBSRES_logfile( $GBSSYS_COMMAND, $build_or_tool, $audit));
$ref->[3] = $OS_LOGFILE_SPEC;
$ref->[4] = 'SUBMIT';
submit();
push @build_action_refs, [ $build_or_tool, $audit ];
}
BGNOTIFIER_submit( $GBSSYS_COMMAND, $DATE_TIME, @build_action_refs);

display_jobs( "Submitted $GBSSYS_COMMAND Jobs");

if (ENV_is_linux())
{
ENV_say( 1, "Jobs queue:");
PROC_at_show();
}
} else  # SUBWIN
{
foreach my $ref (@JOB_REFS)
{
my ($build_or_tool, $audit, $exec_args_ref) = @{$ref};
$BUILD_OR_TOOL = $build_or_tool;
$AUDIT = $audit;
@EXEC_ARGS = ( "${GBSSYS_COMMAND}bg", @{$exec_args_ref} );
subwin();
}
}
}
}




sub submit()
{
my $job_file_spec = create_job_file();
my $command_heading = "$GBSSYS_COMMAND ($BUILD_OR_TOOL / $AUDIT)";





my $submit_cmd_ref = GBSCMD_get_submit_command_ref( $command_heading, $job_file_spec, $OS_LOGFILE_SPEC);





PROC_at( $submit_cmd_ref, $command_heading, $DELAY, $MUST_MAIL, $OS_LOGFILE_SPEC);
}




sub subwin()
{
my $job_file_spec = create_job_file();
my $command_heading = "$GBSSYS_COMMAND ($BUILD_OR_TOOL / $AUDIT)";


ENV_say( 1, "Subwin $GBSSYS_COMMAND");




my $subwin_cmd_ref = GBSCMD_get_subwin_command_ref( $command_heading, $job_file_spec);





PROC_spawn_detached_xterm( $subwin_cmd_ref, $command_heading, 1);
}




sub GBSJOB_wait()
{

$BG_RC = 0;

if (@JOB_REFS)
{
ENV_say( 1, "Waiting...");
sleep( 2);
my $active_jobs;
do
{
$active_jobs = determine_states();
sleep( 10)
unless( $active_jobs == 0);
} while ($active_jobs > 0);
}

return $BG_RC;
}




sub determine_states()
{
my $active_jobs = 0;

my $changed = 0;
foreach my $ref (@JOB_REFS)
{
my ($build_or_tool, $audit, $exec_args_ref, $os_logfile_spec, $state) = @{$ref};
if ($state ne 'DONE' && $state ne 'FAILED')
{
if (-f "$os_logfile_spec.sum")
{
my ($sum_state, $sum_rc) = get_sum_state( "$os_logfile_spec.sum");
if ($sum_rc == 0)
{
$ref->[4] = 'DONE';
} else
{
$ref->[4] = 'FAILED';
$BG_RC = $sum_rc
if ($sum_rc > $BG_RC);
}
$changed = 1;
} else
{
$active_jobs++;
if ($state eq 'SUBMIT')
{
if (-f $os_logfile_spec)
{
$ref->[4] = 'RUNNING';
$changed = 1;
}
}
}
}
}
display_jobs( 'Changed ' . TIME_time2num())
if ($changed);

return $active_jobs;
}




sub display_jobs($)
{
my ($head_text) = @_;

ENV_say( 1, "$head_text:");

my @line_refs;
foreach my $ref (@JOB_REFS)
{
my ($build_or_tool, $audit, $exec_args_ref, $os_logfile_spec, $state) = @{$ref};
push @line_refs, [ $state, $build_or_tool, $audit, $os_logfile_spec ];
}
ENV_say( 0, FORMAT_table( undef, 4, ' ', undef, @line_refs));
}




sub create_job_file()
{
my $job_file_spec;

my @lines =
(
$SUBMODE,
$GBSSYS_COMMAND,
$BUILD_OR_TOOL,
$AUDIT,
$DATE_TIME,
$OS_LOGFILE_SPEC,
$MUST_DISPLAY_NOTIFY_MSG,
$OS_ROOT_PATH,
$DISPLAY,
$COMMAND_ARGS,
$COMMENT,
@EXEC_ARGS,
);


$job_file_spec = SPIT_tmp_file_nl( 'gbsjob', \@lines);

return $job_file_spec;
}




sub get_sum_state($)
{
my ($sum_file) = @_;


my ($jobname,
$build,
$uname,
$root_path,
$logfile,
$time_start,
$time_end,
$time_diff,
$timer_diff,
$state,
$rc,
$action,
$date_time) = LOGSUM_read( $sum_file);

return ($state, $rc);
}

1;


