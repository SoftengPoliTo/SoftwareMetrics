#!must_be_sourced
#
#   gbslocate.sh
#   Run the gbslocate perl script. Must be 'sourced' with . gbslocate.sh
#
GBS_RC=0
let GBS_SCRIPT_LEVEL+=1

new_value=`$GBS_PERL_CMD -w $GBS_SCRIPTS_PATH/gbslocate.pl $*`
GBS_RC=$?
if [[ $GBS_RC == 0 ]]
then
    if [[ $1 != -* ]]
    then
	\export $1="$new_value"
    fi
else
    echo $new_value
fi
#env | grep $1
unset new_value

#   End
let GBS_SCRIPT_LEVEL-=1
if (( $GBS_SCRIPT_LEVEL <= 0 ))
then
    unset GBS_PROMPT_SEPARATOR_PRINTED
    unset GBS_SCRIPT_LEVEL
fi
\set --
bash -c "exit $GBS_RC" # set $?

## EOF ##
