#=================================================
#
#   askform.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::askform;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
ASKFORM_new
);
}




use glo::env;
use glo::types;
use glo::ask;
use glo::format;




sub ASKFORM_new($$$$;$$$);

sub ask_bool($$$$);
sub ask_string($$$$);
sub ask_file($$$$);
sub ask_int($$$$);
sub ask_time($$$$);
sub ask_date($$$$);





my %ASK_REFS = (

bn	    => [ \&ask_bool, ],
sn	    => [ \&ask_string, ],
sw	    => [ \&ask_string, ],
sr	    => [ \&ask_string, ],
's>'    => [ \&ask_string, ],
's<'    => [ \&ask_string, ],
ss	    => [ \&ask_string, ],
se	    => [ \&ask_file, ],
sd	    => [ \&ask_file, ],
sf	    => [ \&ask_file, ],
sx	    => [ \&ask_file, ],
in	    => [ \&ask_int, ],
ir	    => [ \&ask_int, ],
'i>'    => [ \&ask_int, ],
'i<'    => [ \&ask_int, ],
is	    => [ \&ask_int, ],
tn	    => [ \&ask_time, ],
tr	    => [ \&ask_time, ],
dn	    => [ \&ask_date, ],
dr	    => [ \&ask_date, ],
);
















sub ASKFORM_new($$$$;$$$)
{
my ($title,
$preshow,	    # bool
$mnem_refs_ref,	    # [ $mnem_value_ref, $mnem, $opt_name, $type_spec_or_ref, $default, $item_help_or_ref, $enabled, $post_func_or_ref ]




























$help_text_ref,	    # Heading
$extra_text_ref,    # Optional. May be undef
$init_func,	    # Optional. Function to call before first prompt. $func->( $form_ref, $is_first_sequence );
$ok_func,	    # Optional. Function to call for <OK>. $ok = $func->( $form_ref );
) = @_;
my $form_ref;	    # [ $title, $mnem_refs_ref, \%mnem_hash, $init_func, $ok_func];

my %mnem_hash;

my $mnem_hash_ref = \%mnem_hash;




my $mnem_index = 0;
foreach my $ref (@{$mnem_refs_ref})
{
my ($mnem_value_ref, $mnem, $opt_name, $type_spec_or_ref, $default, $item_help_or_ref, $enabled, $post_func_or_ref) = @{$ref};
$mnem = $mnem_index
if ($mnem eq '');
$opt_name = $mnem
if ($opt_name eq '');
my $type_spec_ref = TYPES_split( $type_spec_or_ref);
$ref->[3] = TYPES_split_and_validate( $type_spec_or_ref)  # $type_spec_or_ref
if (!ref $ref->[3]);
if (!defined $enabled)
{
$enabled = 1;
$ref->[6] = $enabled;
}
$mnem_hash{$mnem} = $ref;
$mnem_index++;
}


$form_ref = [ $title, $mnem_refs_ref, $mnem_hash_ref, $ok_func];




ENV_say( 1, "Enter $title data");
ENV_say( 2, $help_text_ref)
if (defined $help_text_ref);
ENV_say( 2, $extra_text_ref)
if (defined $extra_text_ref);




if ($preshow)
{
ENV_say( 1, [ "Current values for $title:", "('*' == manadatory)" ]);
my @row_refs;
foreach my $ref (@{$mnem_refs_ref})
{
my ($mnem_value_ref, $mnem, undef, $type_spec_ref) = @{$ref};
my $manda = ($type_spec_ref->[2] eq 'm') ? '*' : ' ';
push @row_refs, [ "$manda $mnem", scalar ENV_deref( $mnem_value_ref) ];
}
ENV_say( 0, FORMAT_table( 0, 2, ': ', undef, @row_refs));
}
ENV_say( 0, '');




my $is_first_sequence = 1;
my $again;
do
{



$init_func->( $form_ref, $is_first_sequence)
if (defined $init_func);




foreach my $ref (@{$mnem_refs_ref})
{
my ($mnem_value_ref, $mnem, $opt_name, $type_spec_ref, $default, $item_help_or_ref, $enabled, $post_func_or_ref) = @{$ref};
my ($type, $occur, $manda, $constr, $constr_values_ref) = @{$type_spec_ref};
my ($ask_func, $post_func) = (ref $post_func_or_ref eq 'ARRAY') ? @{$post_func_or_ref} : (undef, $post_func_or_ref);




if ($enabled)
{
if (!defined $ask_func)
{
my $ask_ref = $ASK_REFS{"$type$constr"};

ENV_sig( F => "Type $type with Constr $constr is a not supported combination")
if (!defined $ask_ref);
($ask_func) = @{$ask_ref};
}
my $length = ($manda eq 'm') ? -1 : 0;
my $this_default = ($is_first_sequence) ? $default : ENV_deref( $mnem_value_ref);
if ($occur eq 's')
{
my $value = $ask_func->( $mnem_hash_ref, $mnem, $this_default, $length);
$$mnem_value_ref = $value;
} else
{
my @values = $ask_func->( $mnem_hash_ref, $mnem, $this_default, $length);
@{$mnem_value_ref} = @values;
}
}




$post_func->( $mnem_hash_ref, $mnem)
if (defined $post_func);
}




{
ENV_say( 0, '');
ENV_say( 1, "Summary for $title:");
my @row_refs;
foreach my $ref (@{$mnem_refs_ref})
{
my ($mnem_value_ref, $mnem, undef, $type_spec_ref, undef, undef, $enabled) = @{$ref};
my $manda = ($type_spec_ref->[2] eq 'm') ? '*' : ' ';
my $value;
if ($enabled)
{
$value = ENV_deref( $mnem_value_ref);
if ($type_spec_ref->[0] eq 'b')	    # $type == bool
{
$value =~ s/1/Y/g;
$value =~ s/0/N/g;
}
} else
{
$value = '';
}
push @row_refs, [ "$manda $mnem", $value ];
}
ENV_say( 0, FORMAT_table( 0, 2, ': ', undef, @row_refs));
}




my $ok = 1;
$ok = $ok_func->( $form_ref)
if (defined $ok_func);

if ($ok)
{
$again = (ASK_YNQ( 'OK?', 'Y', 1) eq 'N');
} else
{
$again = (ASK_YNQ( 'Retry?', 'Y', 1, 'No causes Quit') eq 'Y');
}
$is_first_sequence = 0;
} while ($again);

return $form_ref;
}




sub ask_bool($$$$)
{
my ($mnem_hash_ref,
$mnem,
$this_default,
$length,
) = @_;

my ($mnem_value_ref, undef, $opt_name, $type_spec_ref, undef, $item_help_or_ref) = @{$mnem_hash_ref->{$mnem}};
my ($type, $occur, $manda, $constr, $constr_values_ref) = @{$type_spec_ref};

if ($constr eq 'n')
{
return ASK_bool( "  $opt_name", $this_default, $length, undef, $item_help_or_ref);
} else
{
ENV_sig( F => "Invalid constr ($constr)");
}
}




sub ask_string($$$$)
{
my ($mnem_hash_ref,
$mnem,
$this_default,
$length,
) = @_;

my ($mnem_value_ref, undef, $opt_name, $type_spec_ref, undef, $item_help_or_ref) = @{$mnem_hash_ref->{$mnem}};
my ($type, $occur, $manda, $constr, $constr_values_ref) = @{$type_spec_ref};

if ($constr eq 'n')
{
return ASK_text( "  $opt_name", $this_default, $length, undef, $item_help_or_ref);
} elsif ($constr eq 'w')
{
return ASK_word( "  $opt_name", $this_default, $length, undef, $item_help_or_ref);
} elsif ($constr eq 'r')
{
return ASK_text( "  $opt_name", $this_default, $length, $constr_values_ref, $item_help_or_ref);
} elsif ($constr eq '>')
{
return ASK_text( "  $opt_name", $this_default, $length, $constr_values_ref, $item_help_or_ref);
} elsif ($constr eq '<')
{
return ASK_text( "  $opt_name", $this_default, $length, $constr_values_ref, $item_help_or_ref);
} elsif ($constr eq 's')
{
if (wantarray)
{
return ASK_values_from_list( "  $opt_name", $this_default, $length, $constr_values_ref, $item_help_or_ref);
} else
{
return ASK_value_from_menu( "$opt_name", \$this_default, undef, $constr_values_ref, $item_help_or_ref);
}
} else
{
ENV_sig( F => "Invalid constr ($constr)");
}
}




sub ask_file($$$$)
{
my ($mnem_hash_ref,
$mnem,
$this_default,
$length,
) = @_;

my ($mnem_value_ref, undef, $opt_name, $type_spec_ref, undef, $item_help_or_ref) = @{$mnem_hash_ref->{$mnem}};
my ($type, $occur, $manda, $constr, $constr_values_ref) = @{$type_spec_ref};

if ($constr eq 'e')
{
return ASK_filespec( "  $opt_name", $this_default, $length, 1, undef, $item_help_or_ref);
} elsif ($constr eq 'd')
{
return ASK_path( "  $opt_name", $this_default, $length, 1, undef, $item_help_or_ref);
} elsif ($constr eq 'f')
{
return ASK_file( "  $opt_name", $this_default, $length, 1, undef, $item_help_or_ref);
} elsif ($constr eq 'x')
{
return ASK_filespec( "  $opt_name", $this_default, $length, -1, undef, $item_help_or_ref);
} else
{
ENV_sig( F => "Invalid constr ($constr)");
}
}




sub ask_int($$$$)
{
my ($mnem_hash_ref,
$mnem,
$this_default,
$length,
) = @_;

my ($mnem_value_ref, undef, $opt_name, $type_spec_ref, undef, $item_help_or_ref) = @{$mnem_hash_ref->{$mnem}};
my ($type, $occur, $manda, $constr, $constr_values_ref) = @{$type_spec_ref};

if ($constr eq 'n')
{
return ASK_int( "  $opt_name", $this_default, $length, undef, $item_help_or_ref);
} elsif ($constr eq 'r')
{
return ASK_int( "  $opt_name", $this_default, $length, $constr_values_ref, $item_help_or_ref);
} elsif ($constr eq '>')
{
return ASK_int( "  $opt_name", $this_default, $length, $constr_values_ref, $item_help_or_ref);
} elsif ($constr eq '<')
{
return ASK_int( "  $opt_name", $this_default, $length, $constr_values_ref, $item_help_or_ref);
} elsif ($constr eq 's')
{
if (wantarray)
{
return ASK_values_from_list( "  $opt_name", $this_default, $length, $constr_values_ref, $item_help_or_ref);
} else
{
return ASK_value_from_menu( "$opt_name", \$this_default, undef, $constr_values_ref, $item_help_or_ref);
}
} else
{
ENV_sig( F => "Invalid constr ($constr)");
}
}




sub ask_time($$$$)
{
my ($mnem_hash_ref,
$mnem,
$this_default,
$length,
) = @_;

my ($mnem_value_ref, undef, $opt_name, $type_spec_ref, undef, $item_help_or_ref) = @{$mnem_hash_ref->{$mnem}};
my ($type, $occur, $manda, $constr, $constr_values_ref) = @{$type_spec_ref};

ENV_sig( F => "'ask_time' not implemented yet");
}




sub ask_date($$$$)
{
my ($mnem_hash_ref,
$mnem,
$this_default,
$length,
) = @_;

my ($mnem_value_ref, undef, $opt_name, $type_spec_ref, undef, $item_help_or_ref) = @{$mnem_hash_ref->{$mnem}};
my ($type, $occur, $manda, $constr, $constr_values_ref) = @{$type_spec_ref};

ENV_sig( F => "'ask_date' not implemented yet");
}

1;
