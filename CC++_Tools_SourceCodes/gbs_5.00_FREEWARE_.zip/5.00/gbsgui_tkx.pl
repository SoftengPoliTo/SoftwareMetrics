#=================================================
#
#   gbsgui_tkx.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;




eval { use Tkx };

use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::args;
use glo::tkxglo;
use glo::tkxmenu;
use glo::tkxmsg;
use glo::tkxevent;
use glo::tkxmain;
use glo::tkxmessage;
use mod::gbsenv;
use mod::validate;
use mod::gbsrc;
use gui::gbsguilf;
use gui::gbsguirf;
use gui::gbsguiswr;
use gui::gbsguiexec;




sub add_menus();
sub save();
sub save_and_exit($);
sub about($);
sub help($);
sub get_args();







my $TEST_MODE = 0;
my $GEO_REF;	# undef or [ Start Width, Heigth, x, y ]




my $IS_LINUX = ENV_is_linux();








my $LF;		    # Left Frame
my $RF;







$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);

GBSENV_setenv( GBS_EXEC_ID => '', 1);
GBSENV_setenv( GBS_PROMPT_SEPARATOR_PRINTED => 0, 1);




get_args();




VALIDATE_root();




{



my $title = "GBSGUI: Root/System: $GBS::ROOT_PATH";
$title .= ' - TestMode'
if ($TEST_MODE);
TKXMAIN_new_window( $title,					# Title
"$GBS::SCRIPTS_PATH/doc/images/gbs.gif",	# Icon
[ 1000, 800 ],				# Initial Width, Heigth, x, y
$GEO_REF,				    	# Start Width, Heigth, x, y
undef);					# Delete window func




my $splash_photo = TKXGLO_photo( gbslogo => "$GBS::SCRIPTS_PATH/doc/images/gbslogo.gif");
my $ss = TKXMAIN_splash_screen( 'Startup GBSGUI', $splash_photo, undef);




add_menus();




my $mf = $TKX::MW->new_ttk__frame( -relief => 'groove', -borderwidth => 3);
$mf->g_pack( -side => 'top', -fill => 'both' , -expand => 1);




my $mlf = $TKX::MW->new_ttk__frame( -relief => 'sunken', -borderwidth => 3);
$mlf->g_pack( -side => 'bottom', -fill => 'x');
TKXMSG_create( $mlf, 5, $TEST_MODE);

{



$LF = $mf->new_ttk__frame( -relief => 'groove', -borderwidth => 3);
$LF->g_pack( -side => 'left', -fill => 'y', -expand => 0);
GBSGUILF_create( $LF);




$RF = $mf->new_ttk__frame( -relief => 'groove', -borderwidth => 3);
$RF->g_pack( -side => 'right', -fill => 'both', -expand => 1);
GBSGUIRF_create( $RF);
}




GBSGUIEXEC_init( $RF);
}




TKXMAIN_mainloop();

ENV_exit( $RC);




END
{

}




sub add_menus()
{



TKXMENU_main_add( $TKX::MW, (
[ File	=>
[ 'Switch System'	    => undef, \&GBSGUISWR_popup, $TEST_MODE ],
[ 'Show Systems'	    => undef, \&GBSGUIEXEC_direct, 'gbsswr_', '--show' ],
[ undef ],
[ [ Save => 'Ctrl+s' ]  => undef, sub { save() } ],
[ 'Save and Exit'	    => undef, \&save_and_exit ],
[ 'Quit'		    => undef, sub { exit } ],
[ 'Exit'		    => undef, \&TKXMAIN_exit ],
],
[ Admin	=>
[ 'New System'	    => undef, \&GBSGUIEXEC_direct, 'gbsswr', '--new' ],
[ 'Add System'	    => undef, \&GBSGUIEXEC_direct, 'gbsswr', '--add' ],
[ 'Remove System'	    => undef, \&GBSGUIEXEC_direct, 'gbsswr', '--remove' ],
[ 'New SubSysstem'	    => undef, \&GBSGUIEXEC_direct, 'gbssws', '--new' ],
[ 'New Component'	    => undef, \&GBSGUIEXEC_direct, 'gbsswc', '--new' ],
[ 'New Build'	    => undef, \&GBSGUIEXEC_direct, 'gbsswb', '--new' ],
[ 'Remove Build'	    => undef, \&GBSGUIEXEC_direct, 'gbsswb', '--remove' ],
[ 'New Audit'	    => undef, \&GBSGUIEXEC_direct, 'gbsswa', '--new' ],
[ 'Remove Audit'	    => undef, \&GBSGUIEXEC_direct, 'gbsswa', '--remove' ],
[ 'New Tool'	    => undef, \&GBSGUIEXEC_direct, 'gbsswt', '--new' ],
[ 'Remove Tool'	    => undef, \&GBSGUIEXEC_direct, 'gbsswt', '--remove' ],
],
[ gbs	=>
[ 'gbsbuild *:*.*'	    => undef, \&GBSGUIEXEC_direct, 'gbsbuild', '*:*.*' ],
[ 'gbsbuild @ARGS'	    => undef, \&GBSGUIEXEC_prompt, 'gbsbuild', ],
[ 'gbsmake'		    => undef, \&GBSGUIEXEC_direct, 'gbsmake',  ],
[ 'gbsmake @ARGS'	    => undef, \&GBSGUIEXEC_prompt, 'gbsmake',  ],
[ 'gbsaudit *:*.*'	    => undef, \&GBSGUIEXEC_direct, 'gbsaudit', '*:*.*' ],
[ 'gbsaudit @ARGS'	    => undef, \&GBSGUIEXEC_prompt, 'gbsaudit', ],
[ undef ],
[ 'gbsmakemake'	    => undef, \&GBSGUIEXEC_direct, 'gbsmakemake', ],
[ 'gbsmakemake @ARGS'   => undef, \&GBSGUIEXEC_prompt, 'gbsmakemake', ],
],
[ gbssys	=>
[ 'gbssysbuild'	    => undef, \&GBSGUIEXEC_direct, 'gbssysbuild', ],
[ 'gbssysmake'	    => undef, \&GBSGUIEXEC_direct, 'gbssysmake',  ],
[ 'gbssysaudit'	    => undef, \&GBSGUIEXEC_direct, 'gbssysaudit', ],
[ 'gbssystool'	    => undef, \&GBSGUIEXEC_direct, 'gbssystool',  ],
[ 'gbssysbuild CUR'	    => undef, \&GBSGUIEXEC_prompt, 'gbssysbuild', [ qw( . --builds=. --i) ] ],
[ 'gbssysmake CUR'	    => undef, \&GBSGUIEXEC_prompt, 'gbssysmake',  [ qw( . --builds=. ) ] ],
[ 'gbssysaudit CUR'	    => undef, \&GBSGUIEXEC_prompt, 'gbssysaudit', [ qw( . --builds=. --audits=. ) ] ],
[ 'gbssystool CUR'	    => undef, \&GBSGUIEXEC_prompt, 'gbssystool',  [ qw( . --tools=. ) ] ],
[ 'gbssysbuild @ARG'    => undef, \&GBSGUIEXEC_prompt, 'gbssysbuild', ],
[ 'gbssysmake @ARG'	    => undef, \&GBSGUIEXEC_prompt, 'gbssysmake',  ],
[ 'gbssysaudit @ARG'    => undef, \&GBSGUIEXEC_prompt, 'gbssysaudit', ],
[ 'gbssystool @ARG'	    => undef, \&GBSGUIEXEC_prompt, 'gbssystool',  ],
[ undef ],
[ 'gbssysall'	    => undef, \&GBSGUIEXEC_direct, 'gbssysall', ],
[ 'gbssysall CUR'	    => undef, \&GBSGUIEXEC_prompt, 'gbssysall', [ qw( . --builds=. --audits=. --tools=. ) ] ],
[ 'gbssysall @ARG'	    => undef, \&GBSGUIEXEC_prompt, 'gbssysall', ],
[ undef ],
[ 'gbsbg'		    => undef, \&GBSGUIEXEC_direct, 'gbsbg', ],
],
[ 'GBS Tools'	=>
[ 'gbsshow'		    => undef, \&GBSGUIEXEC_direct, 'gbsshow',     ],
[ 'gbssilo'		    => undef, \&GBSGUIEXEC_direct, 'gbssilo',     ],
[ 'gbssilo @ARG'	    => undef, \&GBSGUIEXEC_prompt, 'gbssilo',     ],
[ 'gbsexport'	    => undef, \&GBSGUIEXEC_direct, 'gbsexport',   ],
[ 'gbsexport @ARG'	    => undef, \&GBSGUIEXEC_prompt, 'gbsexport',   ],
[ 'gbsbldcheck'	    => undef, \&GBSGUIEXEC_direct, 'gbsbldcheck', ],
[ 'gbsbldcheck @ARG'    => undef, \&GBSGUIEXEC_prompt, 'gbsbldcheck', ],
[ 'gbswhich'	    => undef, \&GBSGUIEXEC_direct, 'gbswhich',    ],
[ 'gbswhich @ARG'	    => undef, \&GBSGUIEXEC_prompt, 'gbswhich',    ],
[ 'gbsxref'		    => undef, \&GBSGUIEXEC_direct, 'gbsxref',     ],
[ 'gbsxref @ARG'	    => undef, \&GBSGUIEXEC_prompt, 'gbsxref',     ],

[ 'gbsedit @ARG'	    => undef, \&GBSGUIEXEC_prompt, 'gbsedit',     ],
[ 'More...'		    =>
[ 'gbssetup'	    => undef, \&GBSGUIEXEC_direct, 'gbssetup', ],
[ 'gbsmaint'	    => undef, \&GBSGUIEXEC_direct, 'gbsmaint', ],
[ 'gbsstats'	    => undef, \&GBSGUIEXEC_direct, 'gbsstats', ],
[ 'gbsstats @ARG'	    => undef, \&GBSGUIEXEC_prompt, 'gbsstats', ],
[ 'gbsscm'		    => undef, \&GBSGUIEXEC_direct, 'gbsscm', ],
[ 'gbsscm @ARG'	    => undef, \&GBSGUIEXEC_prompt, 'gbsscm', ],
],
],
[ 'Other Tools'	=>
[ 'pgrep'		    => undef, \&GBSGUIEXEC_prompt, 'pgrep', ],
[ 'wordrep'		    => undef, \&GBSGUIEXEC_prompt, 'wordrep', ],
[ 'filerep'		    => undef, \&GBSGUIEXEC_prompt, 'filerep', ],
[ 'proto'		    => undef, \&GBSGUIEXEC_prompt, 'proto', ],
[ 'detab'		    => undef, \&GBSGUIEXEC_prompt, 'detab', ],
[ 'bgpids (Linux only)' => undef, ($IS_LINUX) ? \&GBSGUIEXEC_prompt : undef, 'bgpids', ],
[ undef ],
[ 'GBS Terminal'	    => undef, \&GBSGUIEXEC_direct, 'GBS', ],
[ 'Terminal @ Root'	    => undef, \&GBSGUIEXEC_direct, 'terminal', $GBS::ROOT_PATH ],
],
[ Help	=>
[ 'About'		    => undef, \&about ],
[ undef ],
[ 'gbshelp'		    => undef, \&GBSGUIEXEC_direct, 'gbshelp', ],
[ 'Help'		    => undef, \&help ],
],
)
);




TKXEVENT_bind_key_ctrl( $TKX::MW, 's', sub { save() });
}




sub save()
{

if ($GBS::ROOT_PATH ne '')
{

GBSRC_write_base( root => $GBS::ROOT_PATH);
if ($GBS::SUBSYS ne '')
{

GBSRC_write_root( subsys => $GBS::SUBSYS, build => $GBS::BUILD, audit => $GBS::AUDIT, tool => $GBS::TOOL);
if ($GBS::SSTYPE ne '')
{

GBSRC_write_subsys( $GBS::SUBSYS, component => $GBS::COMPONENT, build => $GBS::BUILD, audit => $GBS::AUDIT);
}
}
}
}




sub save_and_exit($)
{
my ($menu_label,
) = @_;

save();

TKXMAIN_exit();
}




sub about($)
{
my ($menu_label,
) = @_;

TKXMESSAGE_about( "GBSGUI - $menu_label", <<ENDHERE

   [size=+2]This program is a part of the [u][b]GBS[/b] (Generic Build Support)[/u]
   package created by Randy Marques of Randy Marques Consultancy.
   For information: [i]http://www.genericbuildsupport.com[/i][/size]

   [b]Copyright � 2015-2025 - Randy Marques - All rights reserved[/b]


ENDHERE
);
}




sub help($)
{
my ($menu_label,
) = @_;

TKXMESSAGE_ok( "GBSGUI - $menu_label", 'question', <<ENDHERE
This is the GUI for GBS
All GBS commands can be called from this program
More to follow...
ENDHERE
);
}




sub get_args()
{
(my $verbose,
$TEST_MODE,
my $geo,
) = ARGS_get( 3, 'perl gbsgui_tkx.pl <verbose> <test_mode> [ <geo> ]', '- Must be called via perl gbsgui.pl');

ENV_set_verbose(1)
if ($verbose);

if ($geo ne '' && $geo ne '.')
{
$GEO_REF = [ split( ',', $geo) ];
}

}



