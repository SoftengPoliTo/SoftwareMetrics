#=================================================
#
#   gbsstart_here.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSSTART_HERE @ARGV") if ($ENV{GBSDEBUG_FILE});




use 5.016_003;
use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::spit;
use glo::genopt;
use mod::gbsenv;
use mod::gbscmd;
use mod::gbsinit;














$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ '<1>',	'gbs_command', 	    'ssm',  '', 'GBS command. e.g.: gbsbuild' ],
[ '<*>',	'gbs_command_args', 'sao',  '', 'GBS command args, including --options' ],
);
GENOPT_set_flag_prefix( '');	    # Disable flags (--xxx) processing. Consider all args positional args
GENOPT_set_optdefs( 'gbsstart_here', \@genopts,
[ 'Startup GBS and execute a (GBS) command, using the CWD.',
'To be used for integration of GBS in other Development Tools / Editors.',
"Replaces 'gbsstart' in most situations" ],
undef);
GENOPT_parse();
}
my $GBS_COMMAND = GENOPT_get( 'gbs_command');
my @GBS_COMMAND_ARGS = GENOPT_get( 'gbs_command_args');

if ($GBS_COMMAND =~ /^--h(elp|)$/)
{
my $key = substr( $GBS_COMMAND, 2);
GENOPT_print_help( $key);
} else
{







my @lines = GBSINIT_setup( '', 0);	# $wanted_release, $full_setup




my $level = GBSCMD_get_level($GBS_COMMAND);	# 0 = 0, 1 = root, 2 = subsys 3 = component 4 = any
my $root = '';
my $subsys = '';
my $component = '';
if ($level == 0)
{
$root = '-';
} elsif ($level == 1)
{
$subsys = '-';
} elsif ($level == 2)
{
$subsys = '.';
$component = '-';
}


if ($root eq '-')
{



push @lines, GBSCMD_get_full_gbs_command( $GBS_COMMAND, \@GBS_COMMAND_ARGS);
} else
{



my $exec = join( ' ', ($GBS_COMMAND, @GBS_COMMAND_ARGS));
$exec = ENV_encode( $exec);
my @args;
push @args, '!';
push @args, $subsys
if ($subsys ne '');
push @args, $component
if ($component ne '');
push @args, "--exec=$exec";
push @lines, GBSCMD_get_full_gbs_command( gbsswr => \@args);
}





my $filespec = SPIT_tmp_script_file_nl( 'gbsstart_exec', \@lines);

$RC =  ENV_system( [ $filespec ], undef);


unlink $filespec;
}

ENV_exit( $RC);




END
{
ENV_print_end_msg( 0);
}


