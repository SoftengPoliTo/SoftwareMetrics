#=================================================
#
#  tkxmsg.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::tkxmsg;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
TKXMSG_create
);
}




use Tkx;

use glo::env;
use glo::tkxevent;
use glo::tkxlistbox;




sub TKXMSG_create($$$);

sub my_say($@);
sub my_print($@);




my $MLB;	# Message List Box

my $NR_LINES_TO_KEEP = 100;

my $LINE = '';

my $TEST_MODE;




sub TKXMSG_create($$$)
{
my ($mlf,
$nr_rows,	    # may be undef or zero
$test_mode,	    # Bool
) = @_;

$TEST_MODE = $test_mode;




my @args = ( -font => 'My_stdout' );
push @args, ( -height => $nr_rows )
if (defined $nr_rows);
(my $rlbf, $MLB) = TKXLISTBOX_new( $mlf, undef, @args);
$rlbf->g_pack( -side => 'right', -fill => 'both' , -expand => 1);

ENV_set_say_func( \&my_say, \&my_print);

TKXEVENT_bind_destroy( $mlf, sub { ENV_set_say_func( undef, undef) });

ENV_say( 1, 'Starting...');
}




sub my_say($@)
{
my ($text_type,
@lines,
) = @_;

if ($LINE eq '')
{
TKXLISTBOX_say( $MLB, $NR_LINES_TO_KEEP, $text_type => \@lines);
} else
{
$lines[0] = $LINE . $lines[0];
TKXLISTBOX_say( $MLB, $NR_LINES_TO_KEEP, $text_type => \@lines);
$LINE = '';
}
map { CORE::say( $_) } @lines
if ($TEST_MODE);
}




sub my_print($@)
{
my ($text_type,
@lines,
) = @_;

map { $LINE .= $_ } @lines;
map { CORE::print( $_) } @lines
if ($TEST_MODE);
}

1;
