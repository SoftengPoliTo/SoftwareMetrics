#!/bin/bash
#=================================================
#   gbsstart.sh <root> [<subsys>] [<comp>] [<build>] --exec=<exec_command> [--rel=<rel>]
#   Generic invocation of GBS in a batch environment (e.g.: using gbsstart)
#   - Set GBS_BASE_PATH
#   - source ~/.gbs/setup.sh (which calls ~/.gbs/profile.sh)
#   - generic call GBS_SCRIPTS_PATH/gbsinit.sh
#=================================================

#set -v -x	# debuging

GBS_RC=0

#
#   Set GBS_BOOT_PATH, GBS_BASE_PATH and GBS_PERL_CMD
#
\source "$HOME/.gbs/boot.sh"

#
#   Run setup (& profile)
#
\source "$GBS_BOOT_PATH/setup.sh" cur

#
#   Execute Start
#
\source "$GBS_SCRIPTS_PATH/gbsstart.sh" $*
GBS_RC=$?

#   End
\set --
\bash -c "exit $GBS_RC" # set $?

###EOF###
