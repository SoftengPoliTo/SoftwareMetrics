#=================================================
#
#   make.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::make;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
MAKE_main
);
}




use glo::env;
use glo::slurp;




sub MAKE_main($$$);

sub parse_a_file($);
sub add_target_or_depend($$$$$);
sub make_a_target($$);
sub make_error($@);




my $ERRSIG;	# 'E' or 'EE'
my $NR_ERRORS;
my @DEPEND_REFS;

my %DEPEND_REFS;

my @MAKEFILES;
my $NR_TARGETS;
my $NR_DEPENDS;

my $DEPTH;
my $MAIN_TARGET;
my $NOW;




sub MAKE_main($$$)
{
my ($make_file,	    # must_exist
$ignore_errors,
$targets_ref,
) = @_;
my ($nr_errors, @stdout_lines);

$ERRSIG = ($ignore_errors) ? 'E' : 'EE';
$NR_ERRORS = 0;




$NR_TARGETS = 0;
$NOW = time();
parse_a_file( $make_file);	# recursive
$NR_DEPENDS = @DEPEND_REFS;





foreach my $target (@{$targets_ref})
{
ENV_say( 1, "Making Target '$target'...");
my $target_ref = $DEPEND_REFS[$DEPEND_REFS{$target}];

if (defined $target_ref)
{
$MAIN_TARGET = $target;
my $main_target_datetime = $target_ref->[2];
$DEPTH = 0;
my $saved_nr_commands = @stdout_lines;
push @stdout_lines, make_a_target( $target_ref, $main_target_datetime);	# recursive
ENV_say( 1, "Target '$target'",  'is up to date')
if (@stdout_lines == $saved_nr_commands);
} else
{
make_error( undef, "Do not know how to make '$target'");
}
}




ENV_say( 1, "'make': Nr Errors = $NR_ERRORS")
if ($NR_ERRORS > 0);
ENV_whisper( 1, 'Statistics:',
'Nr Dependencies & Targets = ' . scalar @DEPEND_REFS,
"Nr Targets = $NR_TARGETS",
'Nr Commands to execute = ' . scalar @stdout_lines,
'Files:',
'  ' . shift @MAKEFILES,		    # first is main file
map { "    $_" } @MAKEFILES,	    # included files
'Commands:',
map { "  $_" } @stdout_lines,
);




@DEPEND_REFS = ();
%DEPEND_REFS = ();
@MAKEFILES = ();


return ( $NR_ERRORS, @stdout_lines );
}





sub parse_a_file($)
{
my ($makefile,	# must exist
) = @_;

ENV_whisper( 1, "Parsing '$makefile'...");

push @MAKEFILES, $makefile;
my $makefile_ref = \$makefile;

my $i = 0;
my @lines = ( SLURP_file( $makefile), '.EOF' );
while (@lines)
{
my @line_items;
my $line_nr = $i + 1;




my $again;
do
{
$again = 0;
my $line = shift @lines;
$i++;
next
if ($line eq '' || substr( $line, 0, 1) eq '#');
if (substr( $line, -1, 1) eq '\\')
{
$line = substr( $line, 0, -1);
$again = 1;
}
$line =~ s/^ +//;	# remove leading spaces
$line =~ s/\s+$//;	# remove leading trailing whitespaces
push @line_items, $line;
} while ($again);





my $first_item = $line_items[0];
if ($first_item =~ /^include\s+(.*)$/)
{



my $include_file = $1;
$include_file =~ tr!\\!/!;		# perl path

if (-e $include_file)
{
if (grep( $include_file eq $_, @MAKEFILES))
{
ENV_sig( E => "Include file already parsed",
" - $first_item",
" - $makefile($line_nr)");
} else
{
parse_a_file( $include_file);    # recursive
}
} else
{
ENV_sig( E => "Include file does not exist",
" - $first_item",
" - $makefile($line_nr)");
}
} elsif ($first_item =~ /^(.+)\s+:$/)
{



my $target = $1;
shift @line_items;	# depends
my $command = '';
if ($lines[0] =~ /^\t(.*)$/)
{



$command = $1;
shift @lines;
$i++;
}

my $is_target = 1;
my $this_index = add_target_or_depend( $target, $is_target, $command, $makefile_ref, $line_nr);

$is_target = 0;
my @depend_indexes = map { add_target_or_depend( $_, $is_target, '', undef, '') } @line_items;
my $target_ref = $DEPEND_REFS[$this_index];

$target_ref->[4] = \@depend_indexes;    # $depend_indexes_ref
} elsif ($first_item eq '.EOF')
{
@lines = ();
} else
{
ENV_sig( $ERRSIG => "Syntax error: '$first_item'",
" - $makefile($line_nr)");
}
}
}




sub add_target_or_depend($$$$$)
{
my ($target_or_depend,
$is_target,
$command,
$makefile_ref,
$line_nr,
) = @_;
my $this_depend_index;

$target_or_depend =~ tr!\\!/!;		# perl path
$this_depend_index = $DEPEND_REFS{$target_or_depend};

$NR_TARGETS++
if ($is_target);
if (defined $this_depend_index)
{
if ($is_target)
{

my $target_ref = $DEPEND_REFS[$this_depend_index];

$target_ref->[1] = $is_target;
$target_ref->[5] = $command;
$target_ref->[6] = $makefile_ref;
$target_ref->[7] = $line_nr;
}
} else
{
my $this_depend_ref = [];
$this_depend_index = @DEPEND_REFS;
$DEPEND_REFS{$target_or_depend} = $this_depend_index;
push @DEPEND_REFS, $this_depend_ref;

my $datetime;
my $depend_is_out_of_date = undef;
my $depend_indexes_ref = [];
if ($target_or_depend =~ /\./)
{
if (-e $target_or_depend)
{
$datetime = (stat( $target_or_depend))[9];  # mtime
} else
{
$datetime = 0;				    # Does not exist
}
} else
{
$datetime = -1;				    # Dummy Target
}
@{$this_depend_ref} = ($target_or_depend, $is_target, $datetime, $depend_is_out_of_date, $depend_indexes_ref, $command, $makefile_ref, $line_nr);
}

return $this_depend_index;
}





sub make_a_target($$)
{
my ($target_ref,
$main_target_datetime,
) = @_;
my @stdout_lines;




$DEPTH++;
my $indent = ' ' x $DEPTH;

if ($DEPTH > $NR_TARGETS + 1)
{
make_error( $target_ref, 'Maximum recursion depth. Cyclic reference?');
} else
{
my $is_out_of_date = 0;
my $target_datetime = $target_ref->[2];

my $new_main_target_datetime = $main_target_datetime;
$new_main_target_datetime = $target_datetime
if ($new_main_target_datetime <= 0 && $target_datetime > 0);
$is_out_of_date = 1
if ($target_datetime <= 0 || $target_datetime > $new_main_target_datetime);

my $depend_indexes_ref = $target_ref->[4];
foreach my $index (@{$depend_indexes_ref})
{
my $depend_ref = $DEPEND_REFS[$index];
if ($depend_ref->[1])	# $is_target
{




my $depend_is_out_of_date = $depend_ref->[3];
if (defined $depend_is_out_of_date)
{
my $depend_datetime = $depend_ref->[2];
$is_out_of_date = 1
if ($depend_is_out_of_date || $depend_datetime > $new_main_target_datetime);
} else
{

push @stdout_lines, make_a_target( $depend_ref, $new_main_target_datetime);	# recursive!
$depend_is_out_of_date = $depend_ref->[3];

$is_out_of_date = 1
if ($depend_is_out_of_date);
}
} else
{



if (!$is_out_of_date)
{
my $depend_datetime = $depend_ref->[2];
if ($depend_datetime <= 0 || $depend_datetime > $target_datetime)
{
$is_out_of_date = 1;

}
}
}
}
if ($is_out_of_date)
{
my $command = $target_ref->[5];
push @stdout_lines, $command
if ($command ne '');
}
$target_ref->[3] = $is_out_of_date;  # $depend_is_out_of_date
}
$DEPTH--;

return @stdout_lines;
}




sub make_error($@)
{
my ($depend_ref,	# [ $target_or_depend, $is_target, $datetime, $depend_is_out_of_date, $depend_indexes_ref, $command, $makefile_ref, $line_nr ]
@error_text
) = @_;

push @error_text, "While making Target '$MAIN_TARGET'";
if (defined $depend_ref)
{
my $makefile_ref = $depend_ref->[6];
my $line_nr = $depend_ref->[7];
push @error_text, "- $$makefile_ref($line_nr)";
}
ENV_sig( $ERRSIG, \@error_text);
$NR_ERRORS++;
}

1;


