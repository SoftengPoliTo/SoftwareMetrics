#!/bin/bash
#
#   gbsstart_here.sh <gbscommand> [<gbs_command_args>...]
#
GBS_RC=0
let GBS_SCRIPT_LEVEL+=1

#
#	Run gbsstart_here
#
$GBS_PERL_CMD -w $GBS_SCRIPTS_PATH/gbsstart_here.pl $*
GBS_RC=$?

#   End
let GBS_SCRIPT_LEVEL-=1
if (( $GBS_SCRIPT_LEVEL <= 0 ))
then
    unset GBS_PROMPT_SEPARATOR_PRINTED
    unset GBS_SCRIPT_LEVEL
fi
\set --
\bash -c "exit $GBS_RC" # set $?

## EOF ##
