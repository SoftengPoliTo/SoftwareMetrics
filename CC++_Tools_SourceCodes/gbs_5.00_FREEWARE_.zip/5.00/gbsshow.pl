#=================================================
#
#   gbsshow.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSSHOW @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::genopt;
use glo::format;
use glo::version;
use glo::scm;
use glo::check;
use mod::gbsenv;
use mod::gbsglo;
use mod::system;




sub show_currencies();
sub sanity_check();




my $BRIEF;






$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ 'brief',  'brief', 'bso',   0, "Brief (short) listing" ],
);
GENOPT_set_optdefs( [ 'gbsshow', 'gbs' ], \@genopts,
'Show GBS currencies',
undef);
GENOPT_parse();
}
$BRIEF = GENOPT_get( 'brief');

{



ENV_say( 1, '');
ENV_say( 0, show_currencies());




sanity_check();
}




ENV_exit( $RC);




END
{
ENV_print_end_msg( 0);
}




sub show_currencies()
{
my @lines;




if (!$BRIEF)
{
push @lines, "  Settings:";
my @row_refs;




my $gbs_show_version = VERSION_get_show_version();
push @row_refs, [ 'GBS        ', ': ', "Version: $gbs_show_version on $GBS::PLATFORM" ];




my ($lics, $licn, $lice, $licd) = VERSION_get_lic();
push @row_refs, [ 'License', ': ', "$licn ($lics)" ];
push @row_refs, [ '',        ': ', "Expires: $lice. Remaining days: $licd" ];
if ($licd < 0)
{
push @row_refs, [ '',        ': ', "** Expired **" ];
ENV_sig( W => 'License expired!');
}




push @row_refs, [ 'Site', ': ', $GBS::SITE ];




my @roles;
push @roles, 'Integrator' if (GBSENV_is_integrator());
push @roles, 'Administrator' if (GBSENV_is_administrator());
push @row_refs, [ 'Role(s)', ': ', "@roles" ];




if ($GBS::ROOT_PATH ne '')
{
push @row_refs, [ 'SCMS', ': ', SCM_join_info( [ $GBS::SCMS, $GBS::SCMS_REPOSITORY, $GBS::SCMS_DATA ]) ];
}

push @lines, FORMAT_table( 0, 4, '', undef, @row_refs);
}




my @row_refs;
push @lines, "  Currencies:";

if ($GBS::ROOT_PATH ne '')
{



if ($BRIEF)
{
push @row_refs, [ 'System Name', ': ', "$GBS::SYSTEM_NAME" ];
} else
{
my $version_start = SYSTEM_get( $GBS::ROOT_PATH, 'version_start');
my $version_end = SYSTEM_get( $GBS::ROOT_PATH, 'version_end');
push @row_refs, [ 'System Name', ': ', "$GBS::SYSTEM_NAME [$version_start - $version_end]" ];
}




if ($BRIEF)
{
push @row_refs, [ 'Root', ': ', "$GBS::ROOT_PATH" ];
} else
{
push @row_refs, [ 'Root', ': ', "$GBS::ROOT_PATH [$GBS::ROOT_VERSION]" ];
}

{
my @item_refs;

my $longest_length = 0;




if ($GBS::SUBSYS ne '')
{
my $both_length = length( $GBS::SUBSYS) + length( $GBS::SSTYPE);
$longest_length = $both_length
if ($both_length > $longest_length);
push @item_refs, [ SubSystem => [ $GBS::SUBSYS, $GBS::SSTYPE, $both_length ] ];
} else
{
push @item_refs, [ SubSystem => '' ];
}




if ($GBS::SSTYPE eq 'GBS')
{
push @item_refs, [ Component => $GBS::COMPONENT ];
}




my @abt_refs = (
[ Build => $GBS::BUILD, $GBS::BUILD_PLUGIN, \@GBS::BUILDS, \&GBSGLO_subsystem_builds, \&GBSGLO_component_builds ],
[ Audit  => $GBS::AUDIT,  $GBS::AUDIT_PLUGIN,  \@GBS::AUDITS,  \&GBSGLO_subsystem_audits,  \&GBSGLO_component_audits  ],
[ Tool   => $GBS::TOOL,   $GBS::TOOL_PLUGIN,   \@GBS::TOOLS,   \&GBSGLO_system_tools,      \&GBSGLO_system_tools      ],
);
foreach my $abt_ref (@abt_refs)
{
my ($abt_name, $cur_abt, $cur_abt_plugin, $system_abts_ref, $subsys_abt_func, $component_abt_func) = @{$abt_ref};
my @data2;
if ($GBS::COMPONENT ne '')
{
@data2 = $component_abt_func->( $GBS::SUBSYS, $GBS::COMPONENT);
} elsif ($GBS::SUBSYS ne '')
{
@data2 = $subsys_abt_func->( $GBS::SUBSYS);
} else
{
@data2 = @{$system_abts_ref};
}
my $data2 = "  (@data2)";
if ($cur_abt ne '')
{
my $both_length = length( $cur_abt) + length( $cur_abt_plugin);
$longest_length = $both_length
if ($both_length > $longest_length);
push @item_refs, [ $abt_name => [ $cur_abt, $cur_abt_plugin, $both_length ], $data2 ];
} else
{
push @item_refs, [$abt_name => '', $data2 ]
if (!$BRIEF || $abt_name eq 'Build');
}
}




foreach my $ref (@item_refs)
{
my ($title, $data1_ref, $data2) = @{$ref};
my $string;
if (ref $data1_ref)
{
my ($name, $data, $both_length) = @{$data1_ref};
$string = "$name         " . (' ' x ($longest_length - $both_length)) . "[$data]";
} else
{
$string = $data1_ref;   # name
}
if (defined $data2)
{
push @row_refs, [ $title, ': ', $string, $data2 ];
} else
{
push @row_refs, [ $title, ': ', $string ];
}
}
}
} else
{



push @row_refs, [ 'System Name', ': ', '*** No Current Root ***' ];
}

push @lines, FORMAT_table( 0, 4, '', undef, @row_refs);




push @lines, '  Currenty in: ' . ENV_cwd();

return @lines;
}




sub sanity_check()
{
my $nr_errors_org = ENV_get_nr_errors();




{



my $error_text = CHECK_path( 'Path', $GBS::LOG_ROOT, 1);
if (!defined $error_text)
{
$error_text = "Path $GBS::LOG_ROOT is not writable!"
if (! -w $GBS::LOG_ROOT);
}
if (defined $error_text)
{
ENV_sig( E => "GBS_LOG_ROOT ($GBS::LOG_ROOT)", "- $error_text");
}




ENV_sig( E => "'GBS_SITE' not set")
if ($GBS::SITE eq '');
}

if (ENV_get_nr_errors() > $nr_errors_org)
{
ENV_say( 1, '***');
ENV_say( 1, '*** Before you proceed you MUST run gbssetup and correct these error(s) ***');
ENV_say( 1, '***');
}
}


