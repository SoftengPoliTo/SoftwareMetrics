#=================================================
#
#   gbssetup.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright © 2010-2020 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSSETUP @ARGV") if ($ENV{GBSDEBUG_FILE});




use 5.016_003;
use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::genopt;
use glo::ask;
use glo::askform;
use glo::list;
use glo::slurp;
use glo::file;
use glo::format;
use glo::shell;
use glo::types;
use mod::gbsenv;
use mod::profile;
use mod::settings;
use mod::setupglo;
use mod::gbscmd;
use mod::bootstrap;
use mod::rootsglo;




sub check_essentials();
sub main_profile($$$);
sub store_settings_and_exit();
sub do_settings($);
sub handle_scripts_root($$$);
sub handle_rel($$$);
sub handle_site($$$);
sub handle_log_root($$$);
sub handle_bool($$$);
sub handle_proc($$$);
sub handle_perms($$$);
sub show_changes($);
sub get_profile_values();
sub get_changed_profile_names();
sub store_changed_profile_values($);
sub check_gbs_root($$$);
sub find_gbs_rels($$);
sub get_default(@);
sub get_mandatory($);

sub menu_startup_settings($$$);
sub menu_move_base($$$);
sub check_base_path($$$);
sub write_setup_file();




my $IS_WIN32 = ENV_is_win32();
my $IS_LINUX = ENV_is_linux();
my $IS_DEVELOPMENT = ENV_is_development();
my $CWD = ENV_cwd();

my $GBS_INITIAL_SETUP = ENV_getenv_bool( 'GBS_INITIAL_SETUP');	# Called from _gbssetup.bat/sh
ENV_sig( F => "GBS_BASE_PATH not defined")
if ($GBS::BASE_PATH eq '');




my %ENV_DEFS = (


GBS_SCRIPTS_ROOT	=> [ 2, ],
GBS_SCRIPTS_REL	=> [ 2, ],
GBS_SITE        	=> [ 1, ],
GBS_LOG_ROOT   	=> [ 1, ],
GBS_EDITOR     	=> [ 0, ],
GBS_BROWSER     	=> [ 0, ],
GBS_VIEWER     	=> [ 0, ],
GBS_NAVIGATOR     	=> [ 0, ],
GBS_BEEPS     	=> [ 0, ],
GBS_ADMINISTRATOR   => [ 0, ],
GBS_INTEGRATOR      => [ 0, ],
);

my @ADVANCED_SETTINGS = qw( GBS_SCRIPTS_ROOT GBS_SCRIPTS_REL );
my @BASIC_SETTINGS = qw( GBS_SITE GBS_LOG_ROOT );
my @GENERAL_SETTINGS = qw( GBS_BEEPS GBS_EDITOR GBS_BROWSER GBS_VIEWER GBS_NAVIGATOR );
my @SPECIAL_SETTINGS = qw( GBS_ADMINISTRATOR GBS_INTEGRATOR );
my @SWITCH_SETTINGS = qw( GBS_SCRIPTS_REL );
my @ALL_SETTINGS = ( @ADVANCED_SETTINGS, @BASIC_SETTINGS, @GENERAL_SETTINGS, @SPECIAL_SETTINGS );

my $TBS_REF;
my $TBS_DEFAULT = '';
my %MNEM_REFS = (










GBS_SCRIPTS_ROOT	=>
[ $TBS_REF, '', 'ScriptsRoot',    'ssm', $TBS_DEFAULT, undef, 1, [ \&handle_scripts_root ] ],
GBS_SCRIPTS_REL	=>
[ $TBS_REF, '', 'Version',        'ssm', $TBS_DEFAULT, undef, 1, [ \&handle_rel ] ],
GBS_SITE        	=>
[ $TBS_REF, '', 'Site',           'ssm', $TBS_DEFAULT, undef, 1, [ \&handle_site ] ],
GBS_LOG_ROOT   	=>
[ $TBS_REF, '', 'LogRoot',        'ssm', $TBS_DEFAULT, undef, 1, [ \&handle_log_root ] ],
GBS_EDITOR     	=>
[ $TBS_REF, '', 'Editor',         'sso', $TBS_DEFAULT, undef, 1, [ \&handle_proc ] ],
GBS_BROWSER     	=>
[ $TBS_REF, '', 'Browser',        'sso', $TBS_DEFAULT, undef, 1, [ \&handle_proc ] ],
GBS_VIEWER     	=>
[ $TBS_REF, '', 'Viewer',         'sso', $TBS_DEFAULT, undef, 1, [ \&handle_proc ] ],
GBS_NAVIGATOR     	=>
[ $TBS_REF, '', 'Navigator',      'sso', $TBS_DEFAULT, undef, 1, [ \&handle_proc ] ],
GBS_BEEPS     	=>
[ $TBS_REF, '', 'Enabled Beeps',  'sso', $TBS_DEFAULT, undef, 1, [ \&handle_bool ] ],
GBS_ADMINISTRATOR   =>
[ $TBS_REF, '', 'Administrator',  'sso', $TBS_DEFAULT, undef, 1, [ \&handle_perms ] ],
GBS_INTEGRATOR       =>
[ $TBS_REF, '', 'Integrator',     'sso', $TBS_DEFAULT, undef, 1, [ \&handle_perms ] ],
);




my %ENV_DATA;

foreach my $env_name (@ALL_SETTINGS)
{



$ENV_DATA{$env_name} = [ undef, undef, 0 ] ;




my $mnem_ref = $MNEM_REFS{$env_name};
$mnem_ref->[0] = \$ENV_DATA{$env_name}->[1];    # $new_value
$mnem_ref->[1] = $env_name;			    # $mnem
$mnem_ref->[3] = TYPES_split( $mnem_ref->[3]);  # $type_spec_or_ref
}

my @NEW_SETUP_REFS;

my $HIGHEST_RESTART_LEVEL = 0;







$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ '<1>', 'menu_entry_1', "isor1..2", 0, "Primary Menu entry for immediate execution" ],
[ '<2>', 'menu_entry_2', "iso>0",    0, "Secondary Menu entry for single immediate execution" ],
);
GENOPT_set_optdefs( 'gbssetup', \@genopts,
"Setup/Maintain Basic GBS Profile settings (EnvVars).",
undef);
GENOPT_parse();
}
my @MENU_ENTRIES = grep( $_ != 0, map { scalar GENOPT_get( "menu_entry_$_") } 1..2);




{



SETUPGLO_check_first_invocation();	# check SITE and LOG_ROOT




get_profile_values();




check_essentials();	# ROOT, REL, SITE, LOG_ROOT

if ($GBS_INITIAL_SETUP)
{
store_settings_and_exit();
} else
{




my @main_menu_items = (
[ 'Change Profile Settings',			\&main_profile ],
[ "Fix Startup Settings (Shortcuts)",		\&menu_startup_settings ],
[ "Move GBS_BASE_PATH",				\&menu_move_base ],
);
ASK_menu( 'Select Primary function to perform', \@main_menu_items, [ @MENU_ENTRIES ]);

}

PROFILE_close( 0);	# $must_write
}




ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
}





sub check_essentials()
{
my @missing_essentials;
do
{
@missing_essentials = ();
foreach my $env_name (@ALL_SETTINGS)
{
my $man = get_mandatory( $env_name);
if ($man eq 'm')
{
my $new_value = $ENV_DATA{$env_name}->[1];
if ($new_value eq '')
{
push @missing_essentials, $env_name
if ($env_name eq 'GBS_SCRIPTS_REL' && ENV_getenv( 'GBS_SCRIPTS_REL' ne 'beta'));
}
}
}

if (@missing_essentials)
{
ENV_beep();
ENV_say( 1, "Some essential data is missing. You need to supply that first:",
'');
do_settings( \@missing_essentials);
store_changed_profile_values( [ get_changed_profile_names() ]);
}
} while (@missing_essentials);
}




sub main_profile($$$)
{
my ($entry_nr,	    ## noperlcheck
$args_ref,	    ## noperlcheck
$entries_ref,
) = @_;

my @profile_menu_items = (
[ 'Basic Settings (Site, LogDir)',		sub { do_settings( \@BASIC_SETTINGS) } ],
[ 'General Settings (Beeps, Editor, ...)',	sub { do_settings( \@GENERAL_SETTINGS) } ],
[ 'Special Settings (Admin, Intgrtr)',		sub { do_settings( \@SPECIAL_SETTINGS) } ],
[ 'Switch GBS Version',				sub { do_settings( \@SWITCH_SETTINGS) } ],
[ 'Advanced Settings (Scripts, Rel)',		sub { do_settings( \@ADVANCED_SETTINGS) } ],
[ 'All Settings',				sub { do_settings( \@ALL_SETTINGS) } ],
);
ASK_menu( 'Select function to perform', \@profile_menu_items, $entries_ref);

store_settings_and_exit();
}




sub store_settings_and_exit()
{



check_essentials();	# ROOT, REL, SITE, LOGROOT
my @changed_names = get_changed_profile_names();




if (@changed_names)
{
ENV_say( 1, @changed_names . ' item(s) changed');
show_changes( \@changed_names);
if (ASK_YN( '*** Implement Changes?', 'N') eq 'Y')
{
store_changed_profile_values( \@changed_names);
} else
{
@changed_names = ();
}
}

if (@changed_names)
{



if ($ENV_DATA{GBS_SCRIPTS_ROOT}->[1] ne $ENV_DATA{GBS_SCRIPTS_ROOT}->[0] ||	    # $new_value, $old_value
$ENV_DATA{GBS_SCRIPTS_REL}->[1]  ne $ENV_DATA{GBS_SCRIPTS_REL}->[0] )	    # $new_value, $old_value
{
SETTINGS_set_check( $ENV_DATA{GBS_SCRIPTS_ROOT}->[1], $ENV_DATA{GBS_SCRIPTS_REL}->[1]); # new_value
}




write_setup_file();
ENV_exit();
} else
{
ENV_say( 1, "Nothing changed");
}
}




sub do_settings($)
{
my ($envvar_names_ref) = @_;




my @mnem_refs;
foreach my $env_name (@{$envvar_names_ref})
{
push @mnem_refs, $MNEM_REFS{$env_name};
}
ASKFORM_new( 'Modify Profile', 1, \@mnem_refs, undef, undef, undef);
}




sub handle_scripts_root($$$)
{
my ($mnem_hash_ref,
$mnem,			    # $env_name
$this_default,
$length,
) = @_;
my $new_scripts_path;

my ($mnem_value_ref, undef, $opt_name, $type_spec_ref, undef, $item_help_or_ref) = @{$mnem_hash_ref->{$mnem}};


my $stored_value = $ENV_DATA{$mnem}->[0];

my $default = ENV_parent_path( $GBS::SCRIPTS_PATH);

$new_scripts_path = ASK_path( $opt_name, $default, -1, 1, [ \&check_gbs_root, undef ] );

if (!$stored_value || $new_scripts_path ne $stored_value)
{
my $rel_part = ($IS_WIN32) ? '%GBS_SCRIPTS_REL%' : '$GBS_SCRIPTS_REL';
my $gbs_scripts = "$new_scripts_path/$rel_part";
$ENV_DATA{GBS_SCRIPTS_PATH}->[0] = ''
if (!defined $ENV_DATA{GBS_SCRIPTS_PATH}->[0]);	    # $stored_value
$ENV_DATA{GBS_SCRIPTS_PATH}->[1] = $gbs_scripts;	    # $new_value
ENV_say( 1, "GBS_SCRIPTS_PATH will be set to '$gbs_scripts'");
}

return $new_scripts_path;
}




sub handle_rel($$$)
{
my ($mnem_hash_ref,
$mnem,			    # $env_name
$this_default,
$length,
) = @_;
my $new_rel;

my ($mnem_value_ref, undef, $opt_name, $type_spec_ref, undef, $item_help_or_ref) = @{$mnem_hash_ref->{$mnem}};


my ($stored_value, $new_value) = @{$ENV_DATA{$mnem}};

my $gbs_scripts_root = $ENV_DATA{GBS_SCRIPTS_ROOT}->[1];	# $new_value
my @gbs_rels = find_gbs_rels( $gbs_scripts_root, 0);	# $include_beta = 0;
if (@gbs_rels == 0)
{
ENV_sig( F => "No GBS Release directories found in $gbs_scripts_root");
} elsif (@gbs_rels == 1)
{
$new_rel = $gbs_rels[0];
ENV_say( 1, "Single GBS Release directory '$new_rel' taken");
} else
{
my $default_i = -1;
my $env_value = ENV_getenv( $mnem);
$default_i = LIST_firstidx_str( $new_value, \@gbs_rels) if ($new_value);
$default_i = LIST_firstidx_str( $env_value, \@gbs_rels) if ($env_value);
$default_i = LIST_firstidx_str( $stored_value, \@gbs_rels) if ($stored_value);
my $new_rel_i = ASK_index_from_menu( $opt_name, $default_i, undef, [ @gbs_rels ]);
$new_rel = $gbs_rels[$new_rel_i];
}

return $new_rel;
}




sub handle_site($$$)
{
my ($mnem_hash_ref,
$mnem,			    # $env_name
$this_default,
$length,
) = @_;
my $new_rel;




my ($stored_value, $new_value) = @{$ENV_DATA{$mnem}};

my $default = get_default( $new_value, $stored_value, ENV_getenv( $mnem));

return SETUPGLO_ask_site( $default);
}




sub handle_log_root($$$)
{
my ($mnem_hash_ref,
$mnem,			    # $env_name
$this_default,
$length,
) = @_;





my ($stored_value, $new_value) = @{$ENV_DATA{$mnem}};
my $default = get_default( $new_value, $stored_value, ENV_getenv( $mnem));

return SETUPGLO_ask_log_root( $default);
}




sub handle_bool($$$)
{
my ($mnem_hash_ref,
$mnem,			    # $env_name
$this_default,
$length,
) = @_;
my $newer_value;

my ($mnem_value_ref, undef, $opt_name, $type_spec_ref, undef, $item_help_or_ref) = @{$mnem_hash_ref->{$mnem}};


my ($stored_value, $new_value) = @{$ENV_DATA{$mnem}};

my $default = get_default( $new_value, $stored_value, ENV_getenv( $mnem), 'NO');
$default = uc $default;
$default = ($default eq 'YES' || $default eq 'ON') ? 'Y' : 'N';
my $ans = ASK_YN( $opt_name, $default);
$newer_value = ($ans eq 'Y') ? 'YES' : 'NO';

return $newer_value;
}




sub handle_proc($$$)
{
my ($mnem_hash_ref,
$mnem,			    # $env_name: GBS_EDITOR GBS_BROWSER GBS_NAVIGATOR GBS_VIEWER
$this_default,
$length,
) = @_;
my $newer_value;

my ($mnem_value_ref, undef, $opt_name, $type_spec_ref, undef, $item_help_or_ref) = @{$mnem_hash_ref->{$mnem}};


my ($stored_value, $new_value) = @{$ENV_DATA{$mnem}};

my $prompt_name = $opt_name;
my $default = get_default( $new_value, $stored_value, ENV_getenv( $mnem));

my $param = ($IS_WIN32) ? '%1%' : '$1';
ENV_say( 1, "Enter full command for $prompt_name",
'Mind spaces in filespec - use quotes',
"Use '$param' to specify the filespec - if not, '$param' will be appended at end");
ENV_say( 2, "Place a space before a possible '&' at the end")
if ($IS_LINUX);

my $command = ASK_text( 'Enter command', $default, 0);
if ($command ne '')
{
my $param_qm = quotemeta $param;
if ($command !~ /$param/)
{
if (substr( $command, -1, 1) eq '&')	# Linux only
{
$command =~ s/\s?&$/ $param &/;		# Insert $1 before '&'
} else
{
$command = "$command $param";
}
}
$newer_value = $command;
} else
{
$newer_value = '';
}

return $newer_value;
}




sub handle_perms($$$)
{
my ($mnem_hash_ref,
$mnem,			    # $env_name: GBS_INTEGRATOR or GBS_ADMINISTRATOR
$this_default,
$length,
) = @_;
my $newer_value;

my ($mnem_value_ref, undef, $opt_name, $type_spec_ref, undef, $item_help_or_ref) = @{$mnem_hash_ref->{$mnem}};


my ($stored_value, $new_value) = @{$ENV_DATA{$mnem}};

my $default = get_default( $new_value, $stored_value, ENV_getenv( $mnem));

my %perms = map { $_ => 1 } split( ',', $default);	    # also removes duplicates :-)




{
my %roots_by_name;

foreach my $ref (ROOTSGLO_get_root_path_refs( 0))
{
my ($fc, $root_path, $root_version, $system_name) = @{$ref};
push @{$roots_by_name{$system_name}}, [ $root_path, $fc, $root_version ];
}
my @row_refs;
my @missing_perms;
foreach my $perm (sort keys %perms)
{
my $roots_ref = $roots_by_name{$perm};
if (defined $roots_ref)
{
foreach my $ref (@{$roots_by_name{$perm}})
{
my ($root_path, $fc, $root_version) = @{$ref};
push @row_refs, [ "   $perm", $root_path, $fc, $root_version ];
}
} else
{
push @row_refs, [ "=> $perm", '<not found>' ];
push @missing_perms, $perm;
}
}
if (@missing_perms)
{
ENV_beep();
ENV_say( 1, 'Some cleanup is required');
my $nr_missing_perms = @missing_perms;
if ($nr_missing_perms == 1)
{
ENV_say( 2, "There is 1 nonexistent root in $mnem:");
} else
{
ENV_say( 2, "There are $nr_missing_perms nonexistent roots in $mnem:");
}
my @menu_texts = FORMAT_table( undef, 3, ' ', undef, @row_refs);
ENV_say( 0, @menu_texts);
if (ASK_YN( 'Cleanup?', 'Y') eq 'Y')
{
delete( @perms{@missing_perms});
ENV_say( 1, 'Deleted');
ENV_say( 1, '  Remaining: ' . join( ',', sort keys %perms));
}
ENV_say( 0, '');
}
}




my $prompt = $opt_name;
if (exists $perms{$GBS::SYSTEM_NAME})
{
ENV_say( 1, "You are already $prompt for $GBS::SYSTEM_NAME");
delete $perms{$GBS::SYSTEM_NAME}
if (ASK_YN( 'Disable?', 'N') eq 'Y');
} else
{
ENV_say( 1, "You are not $prompt for $GBS::SYSTEM_NAME");
$perms{$GBS::SYSTEM_NAME} = 1
if (ASK_YN( 'Enable?', 'N') eq 'Y');
}
$newer_value = join( ',', sort keys %perms);

return $newer_value;
}




sub show_changes($)
{
my ($changed_names_ref,
) = @_;

my @line_refs;
foreach my $name (@{$changed_names_ref})
{
push @line_refs, [ $name, $ENV_DATA{$name}->[1] ];	# $new_value
}

ENV_say( 1, "Changes: ");
ENV_say( 0, FORMAT_table( 0, 2, ' => ', undef, @line_refs));
}




sub get_profile_values()
{



ENV_say( 1, "Read Profile...");
PROFILE_open( $GBS::BASE_PATH);
foreach my $name (@ALL_SETTINGS)
{
my $value = PROFILE_get( $name);
$ENV_DATA{$name}->[0] = $value;     # $stored_value
$ENV_DATA{$name}->[1] = $value;     # $new_value

}




if ($GBS_INITIAL_SETUP)
{
GBSENV_setenv( GBS_SCRIPTS_PATH => $CWD, 1);
my $gbs_scripts_root = ENV_perl_paths_noquotes( ENV_parent_path( $CWD));
my $gbs_scripts_rel = ENV_parent_dir( $CWD, -1);
if ($ENV_DATA{GBS_SCRIPTS_ROOT}->[1] ne $gbs_scripts_root)
{
$ENV_DATA{GBS_SCRIPTS_ROOT}->[1] = $gbs_scripts_root;		# $new_value
ENV_say( 1, "GBS_SCRIPTS_ROOT set to $gbs_scripts_root");
}
if ($ENV_DATA{GBS_SCRIPTS_REL}->[1] ne $gbs_scripts_rel)
{
$ENV_DATA{GBS_SCRIPTS_REL}->[1] = $gbs_scripts_rel;			# $new_value
ENV_say( 1, "GBS_SCRIPTS_REL  set to $gbs_scripts_rel");
} else
{
ENV_say( 1, "GBS_SCRIPTS_REL already $gbs_scripts_rel");
}
}
}




sub get_changed_profile_names()
{
my @names;


foreach my $name (@ALL_SETTINGS)
{
push @names, $name
if ($ENV_DATA{$name}->[0] ne $ENV_DATA{$name}->[1]);    # $stored_value , $new_value;
}

return @names;
}




sub store_changed_profile_values($)
{
my ($changed_names_ref,
) = @_;

if (@{$changed_names_ref})
{
ENV_say( 1, "Store Profile Changes...");




foreach my $name (@{$changed_names_ref})
{
my $data_ref = $ENV_DATA{$name};
my ($stored_value, $new_value) = @{$data_ref};
PROFILE_set( $name => $new_value);
$data_ref->[1] = $new_value;	# $stored_value
my $restart_level = $ENV_DEFS{$name}->[0];
$HIGHEST_RESTART_LEVEL = $restart_level
if ($restart_level > $HIGHEST_RESTART_LEVEL);
push @NEW_SETUP_REFS, [ $name, $new_value ];
}

PROFILE_write();
}
}




sub check_gbs_root($$$)
{
my ($values_ref,
$default_ref,		## noperlcheck
$args_ref,		## noperlcheck
) = @_;
my $error_txt = '';

my $path = $values_ref->[0];

my @gbs_rels = find_gbs_rels( $path, 1);	# $include_beta = 1
$error_txt = "'$path' is not a valid GBS_SCRIPTS_PATH"
if (!@gbs_rels);

return $error_txt;
}




sub find_gbs_rels($$)
{
my ($gbs_scripts_root,
$include_beta,
) = @_;
my @gbs_rels;

my @rels = ENV_glob( "$gbs_scripts_root/*/gbsswr.pl");
@gbs_rels = map { ENV_parent_dir( $_, -2) } @rels;

my @beta_rels = grep( /^beta/, @gbs_rels);
if (@beta_rels)
{
if (!$include_beta && ! $IS_DEVELOPMENT)
{
ENV_say( 2, "@beta_rels ignored");
@gbs_rels = grep( $_ !~ /^beta/, @gbs_rels);
}
}

return @gbs_rels;
}





sub get_default(@)
{
my @values = @_;
my $default = '';

foreach my $value (@values)
{
if (defined $value && $value ne '')
{
$default = $value;
last;
}
}

return $default;
}




sub get_mandatory($)
{
my ($env_name,
) = @_;

return $MNEM_REFS{$env_name}->[3]->[2];  # $type_spec_or_ref -> $mandatory
}




sub menu_startup_settings($$$)
{
my ($entry_nr,		## noperlcheck
$args_ref,		## noperlcheck
$entries_ref,		## noperlcheck
) = @_;


SETTINGS_set_check( $ENV_DATA{GBS_SCRIPTS_ROOT}->[1], $ENV_DATA{GBS_SCRIPTS_REL}->[1]); # new_value
}




sub menu_move_base($$$)
{
my ($entry_nr,		## noperlcheck
$args_ref,	    	## noperlcheck
$entries_ref,	    	## noperlcheck
) = @_;

ENV_say( 1, "Current GBS_BASE_PATH: $GBS::BASE_PATH");




my $new_location;
if ($IS_WIN32)
{
my $mydocuments_path = ENV_get_user_path( 0);
my $short_mydocuments_path = ENV_perl_paths( $mydocuments_path);
if ("$short_mydocuments_path/.gbs/base" ne $GBS::BASE_PATH)
{
my @locations = (
"My Documents ($mydocuments_path/.gbs/base)",
'<Other>',
);
my $index = ASK_index_from_menu( 'Specify Location to move GBS_BASE_PATH to', -1, undef, [ @locations ]);
if ($index == 0)
{
$new_location = $short_mydocuments_path;
}
}
}
if (!defined $new_location)
{
$new_location = ASK_path( "Enter new location (without '/.gbs/base')", '', 0, 0, [ \&check_base_path ]);

}




if ($new_location ne '')
{
my $new_base_path = "$new_location/.gbs/base";
ENV_say( 1, "New GBS_BASE_PATH: $new_base_path");




if (!-e $new_base_path)
{
if (ASK_YNEQ( 'Location does not exist. Create?', 'Y', 1) eq 'Y')
{
ENV_say( 2, 'Created')
if (ENV_mkpath( $new_base_path, undef, 'EE'));
}
}




if (-e $new_base_path)
{




my %exclude_files = map { $_ => 1 } SETTINGS_get_setup_files( "$GBS::SCRIPTS_PATH/setup");
my $bootstrap_file = BOOTSTRAP_file();  # bootstrap.bat or bootstrap.sh
$exclude_files{$bootstrap_file} = 1;

my $nr_copied = 0;
my @from_filespecs;
foreach my $base_file (SLURP_dir_files( $GBS::BASE_PATH, 1))
{
if (!exists $exclude_files{$base_file})
{
push @from_filespecs, "$GBS::BASE_PATH/$base_file";
my $replicated = FILE_replicate( "$GBS::BASE_PATH/$base_file", "$new_base_path/$base_file");
if ($replicated == 1)
{
ENV_say( 2, "Copied $base_file");
$nr_copied++;
}
}
}
unlink @from_filespecs;
ENV_say( 1, "Moved $nr_copied files");




BOOTSTRAP_change( $new_base_path);		# Doe NOT change $GBS_BASE_PATH
push @NEW_SETUP_REFS, [ GBS_BASE_PATH => $new_base_path ];





if (SLURP_dir_all( $GBS::BASE_PATH, 0) == 0 &&
ASK_YN( "Delete original location ($GBS::BASE_PATH)", 'Y') eq 'Y')
{
FILE_del_tree( W => $GBS::BASE_PATH, undef, 5);	    # $verbose_level
if ($GBS::BASE_PATH =~ m!/\.gbs/base$!)
{
FILE_del_dirs( W => $GBS::BASE_PATH);	    # .../.gbs/base
ENV_say( 2, "Deleted $GBS::BASE_PATH");
my $gbs_top_path = $GBS::BASE_PATH;
$gbs_top_path =~ s!/base$!!;




if (!SLURP_dir_all( $gbs_top_path, 1))	    # $include_dot_files
{
FILE_del_dirs( W => $gbs_top_path);	    # .../.gbs
ENV_say( 2, "Deleted $gbs_top_path")
} else
{
ENV_say( 2, "$gbs_top_path not empty: not deleted")
}
}
}




GBSENV_setenv( GBS_BASE_PATH => $new_base_path, 1);




write_setup_file();
ENV_exit();
} else
{
ENV_say( 1, 'Nothing moved');
}
}
}




sub check_base_path($$$)
{
my ($values_ref,	# Value may be changed
$default_ref,				    	## noperlcheck
$app_data_ref,	# [ @display_texts_or_refs ]	## noperlcheck
) = @_;
my $error_txt = '';

$values_ref->[0] =~ s!/\.gbs/base$!!i;
$error_txt = '.gbs not allowed in path'
if ($values_ref->[0] =~ m!\.gbs!i);

return $error_txt;
}




sub write_setup_file()
{
ENV_say( 1, "Set Env. Changes...");



my @lines;
if ($HIGHEST_RESTART_LEVEL == 2)
{



if (GBSENV_gbs_is_active())
{
push @lines, SHELL_echo( 1, "*** GBS Exiting... ***");
push @lines, GBSCMD_get_full_gbs_command( gbsexit => undef);
push @lines, SHELL_echo( 1, "*** GBS Restarting... ***");
push @lines, GBSCMD_get_boot_command( 'boot');
push @lines, GBSCMD_get_base_command( 'gbsinit');
}
} else
{



foreach my $ref (@NEW_SETUP_REFS)
{
my ($name, $new_value) = @{$ref};
push @lines, SHELL_setenv( $name => $new_value);
ENV_say( 2, "$name => $new_value");
}
if ($HIGHEST_RESTART_LEVEL == 1)
{



if ($GBS::ROOT_PATH ne '') # rsw active?
{
push @lines, SHELL_echo( 1, "*** Restarting the current Root...");
push @lines, GBSCMD_get_full_gbs_command( gbsswr => '.');
}
}
}

GBSENV_write_result_script( \@lines, 0);	# $must_print
}


