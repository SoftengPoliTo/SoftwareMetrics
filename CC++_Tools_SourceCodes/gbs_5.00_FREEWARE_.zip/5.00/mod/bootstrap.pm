#=================================================
#
#   bootstrap.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::bootstrap;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
BOOTSTRAP_file
BOOTSTRAP_install
BOOTSTRAP_change
);
}




use glo::env;
use glo::slurp;
use glo::spit;
use glo::shell;
use mod::gbsenv;




sub BOOTSTRAP_file();
sub BOOTSTRAP_install();
sub BOOTSTRAP_change($);








my $BOOTSTRAP_FILE = "bootstrap$GBS::SHELL_FILETYPE";




my $IN_INSTALL = 0;




sub BOOTSTRAP_file()
{
return $BOOTSTRAP_FILE;
}





sub BOOTSTRAP_install()
{
$IN_INSTALL = 1;
my @boot_files = SLURP_dir_all( $GBS::BOOT_PATH, 0);
if (@boot_files == 1 && $boot_files[0] =~ /^bootstrap\.(bat|sh)$/)
{
my $mydocuments_path = ENV_get_user_path( 0);
my $base_path = "$mydocuments_path/.gbs/base";
GBSENV_setenv( GBS_BASE_PATH => $base_path, 1);
ENV_say( 1, "Created $GBS::BASE_PATH")
if (ENV_mkpath( $GBS::BASE_PATH, undef, 'EE'));
BOOTSTRAP_change( $GBS::BASE_PATH);
} else
{
ENV_whisper( 1, "GBS_BASE_PATH = $GBS::BASE_PATH");
}
}





sub BOOTSTRAP_change($)
{
my ($new_base_path,
) = @_;

ENV_say( 1, "New GBS_BASE_PATH defined: $new_base_path")
if (!$IN_INSTALL);




$new_base_path = ENV_os_paths( $new_base_path);
SPIT_file( "$GBS::BOOT_PATH/$BOOTSTRAP_FILE", SHELL_setenv( GBS_BASE_PATH => $new_base_path));
ENV_say( 2, "Updated $BOOTSTRAP_FILE")
if (!$IN_INSTALL);
}

1;


