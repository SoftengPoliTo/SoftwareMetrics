#=================================================
#
#   scamet.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::scamet;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SCAMET_name_is_valid
SCAMET_get_metric_data
SCAMET_group2txt
);
}




use glo::env;




sub SCAMET_name_is_valid($);
sub SCAMET_get_metric_data($);
sub SCAMET_group2txt($);




my %MET_DEFS = (








AKI => [ 'Akiyama\'s criterion',		    1, undef,	    [20,   1],	    0, 1 ], #
AV1 => [ 'Average size of Statement (1)',	    1, [4.0, 1],    [20.0, 2],	    0, 1 ], #
AV2 => [ 'Average size of Statement (2)',	    1, [4.0, 1],    [20.0, 2],	    0, 1 ], #
AV3 => [ 'Average size of Statement (3)',	    1, [4.0, 1],    [20.0, 2],	    0, 1 ], #
BAK => [ 'Number of backwards jumps',	    1, undef,	    [0, 2],	    1, 1 ], #
CAL => [ 'Nr of functions called',	    	    1, undef,	    [10, 1],	    1, 1 ], #
CYC => [ 'Cyclomatic complexity',		    1, [2, 0],	    [10, 1],	    0, 1 ], #
ELF => [ 'Nr of dangling ELSE IFs',		    1, undef,	    [0, 1],	    1, 1 ], #
FN1 => [ 'Nr of operator occurrences',	    1, [10, 1],	    [100, 1],	    1, 1 ], #
FN2 => [ 'Nr of operand occurrences',	    1, [10, 1],	    [100, 1],	    1, 1 ], #
GTO => [ 'Nr of GOTO\'s',			    1, undef,	    [0, 2],	    1, 1 ], #
HLB => [ 'Nr of Halstead\'s delivered bugs (B)', 1, undef,	    [0.5, 1],	    0, 1 ], #	values OK?
KDN => [ 'Knot density (KNT/XLN)',		    1, undef,	    [0.0, 2],	    1, 1 ], #
KNT => [ 'Nr of Knots',			    1, undef,	    [0, 2],	    1, 1 ], #
LCT => [ 'Nr of local variables declared',	    1, undef,	    [10, 1],	    1, 1 ], #
LIN => [ 'Nr of maint. code lines',		    1, [0, 0],	    [50, 1],	    1, 1 ], #
LOP => [ 'Nr Logical Operators',		    1, undef,	    [10, 1],	    1, 1 ], #
M07 => [ 'Essential Cyclomatic Complexity',	    1, undef,	    [4, 2],	    0, 1 ], #
M19 => [ 'Number of exit points',		    1, undef,	    [1, 2],	    1, 1 ], #
M29 => [ 'Number of func calling this func',    1, undef,	    [1, 2],	    1, 1 ], #
MCC => [ 'Myer\'s interval',		    1, [1, 1],	    [10, 1],	    0, 1 ], #
MIF => [ 'Deepest level of nesting',	    1, undef,	    [5, 1],	    0, 1 ], #
PAR => [ 'Nr of Function parameters',	    1, undef,	    [10, 1],	    1, 1 ], #
PBG => [ 'Residual Bugs',			    1, undef,	    [0, 1],	    1, 1 ], #
PDN => [ 'Path density (PTH/XLN)',		    1, undef,	    [100, 1],	    0, 1 ], #
PTH => [ 'Nr of Static program paths',	    1, undef,	    [200, 1],	    1, 1 ], #
RET => [ 'Nr of return points in function',	    1, [1, 2],	    [1, 2],	    1, 1 ], #
ST1 => [ 'Nr Statements in Function (1)',	    1, [1, 1],	    [50, 1],	    1, 1 ], #
ST2 => [ 'Nr Statements in Function (2)',	    1, [1, 1],	    [50, 1],	    1, 1 ], #
ST3 => [ 'Nr Statements in Function (3)',	    1, [1, 1],	    [50, 1],	    1, 1 ], #
SUB => [ 'Number of function calls',	    1, undef,	    [10, 1],	    0, 1 ], #
UNR => [ 'Nr of unreachable statements',	    1, undef,	    [0, 2],	    1, 1 ], #
UNV => [ 'Nr of unused variables',		    1, undef,	    [1, 1],	    1, 1 ], #
XLN => [ 'Nr of executable lines',		    1, [0, 0],	    [50, 1],	    1, 1 ], #

CBO => [ 'Coupling between objects',	    2, [1, 1],	    [25, 1],	    1, 1 ], #
DIT => [ 'Deepest inheritance',		    2, undef,	    [5, 1],	    0, 1 ], #
LCM => [ 'Lack of cohesion of methods',	    2, [1, 1],	    [2, 1],	    1, 1 ], #
MTH => [ 'Nr methods in class',		    2, [2, 1],	    [20, 1],	    1, 1 ], #
NOC => [ 'Nr Immediate children',		    2, [1, 1],	    [10, 1],	    1, 1 ], #
NOP => [ 'Nr Immediate parents',		    2, undef,	    [1, 1],	    0, 1 ], #
RFC => [ 'Response for class',		    2, [2, 1],	    [50, 1],	    0, 1 ], #
WMC => [ 'Weighted methods per class',	    2, [2, 1],	    [100, 1],	    0, 1 ], #

BME => [ 'Programmer-months: Embedded',	    3, undef,	    [2, 1],	    1, 1 ], #
BMO => [ 'Programmer-months: Organic',	    3, undef,	    [2, 1],	    1, 1 ], #
BMS => [ 'Programmer-months: Semi-detached',    3, undef,	    [2, 1],	    1, 1 ], #
BUG => [ 'Residual Bugs',			    3, [5, 1],	    [10, 1],	    1, 1 ], #
CBO => [ 'Coupling to other classes',	    2, [1, 1],	    [25,1],	    1, 1 ], #
CCA => [ 'Nr of Characters (C++)',		    3, [0, 0],	    [100000, 1],    1, 1 ], #
CCB => [ 'Nr of Code Characters (C++)',	    3, [0, 0],	    [100000, 1],    1, 1 ], #
CCC => [ 'Nr of Comment Characters (C++)',	    3, [0, 0],	    [100000, 1],    1, 1 ], #
CDN => [ 'Comment-to-Code ratio',		    3, [0.1, 1],    [0.8, 1],	    0, 1 ], #
DEV => [ 'Est. development. (man-days)',	    3, undef,	    [1, 1],	    1, 1 ], #
DIF => [ 'Program Difficulty',		    3, [1, 1],	    [12, 1],	    0, 1 ], #
ECT => [ 'Nr External variables decl',	    3, [0, 1],	    [1, 1],	    1, 1 ], #
EFF => [ 'Program effort',			    3, [1, 1],	    [2, 1],	    1, 1 ], #
FCO => [ 'Estimated function coupling',	    3, [1, 1],	    [2, 1],	    0, 1 ], #
FNC => [ 'Nr of Functions',			    3, [1, 2],	    [20, 1],	    1, 1 ], #
HAL => [ 'Halstead prediction of STTOT',	    3, [1, 1],	    [2, 1],	    0, 1 ], #
M20 => [ 'Nr operand occurences',		    3, [10, 1],	    [100, 1],	    1, 1 ], #
M21 => [ 'Nr operator occurences',		    3, [10, 1],	    [100, 1],	    1, 1 ], #
M22 => [ 'Nr of statements',		    3, [100, 1],    [200, 1],	    1, 1 ], #
M28 => [ 'Nr Non-Header comments',		    3, [10, 1],	    [80, 1],	    1, 1 ], #
M33 => [ 'Nr Internal Comments',		    3, [10, 1],	    [80, 1],	    1, 1 ], #
MOB => [ 'Code portability as percentage',	    3, [98, 1],	    [100, 1],	    0, 1 ], #
OPN => [ 'Nr distinct operands',		    3, [10, 1],	    [100, 1],	    0, 1 ], #
OPT => [ 'Nr distinct operators',		    3, [10, 1],	    [100, 1],	    0, 1 ], #
PRT => [ 'Est. porting (programmer-days)',	    3, undef,	    [1, 1],	    1, 1 ], #
SCT => [ 'Nr of static var. & func',	    3, undef,	    [20, 1],	    1, 1 ], #
SHN => [ 'Shannon information contents (bits)', 3, [10, 1],	    [50, 1],	    1, 1 ], #
TDE => [ 'Total Months: Enbedded',		    3, undef,	    [2, 1],	    1, 1 ], #
TDO => [ 'Total Months: Organic',		    3, undef,	    [2, 1],	    1, 1 ], #
TDS => [ 'Total Months: Semi-detached',	    3, undef,	    [2, 1],	    1, 1 ], #
TLN => [ 'Total preprocessed source lines',	    3, [10, 1],	    [150, 1],	    1, 1 ], #
TOT => [ 'Nr Tokens used',			    3, [10, 1],	    [50, 1],	    1, 1 ], #
TPP => [ 'Total unpreprocessed source lines',   3, [20, 1],	    [200, 1],	    1, 1 ], #
VAR => [ 'Nr variables',			    3, [10, 1],	    [50, 1],	    1, 1 ], #
VOL => [ 'Program volume (bits)',		    3, [10, 1],	    [100, 1],	    1, 1 ], #
ZIP => [ 'Zipf prediction of STTOT',	    3, [0, 1],	    [0, 1],	    0, 1 ], #
);

my @GROUP_NAMES = ( 'General', 'Function', 'Class', 'File', 'Project' );    # (Project is not used)






sub SCAMET_name_is_valid($)
{
my ($metric_name,
) = @_;


return (exists $MET_DEFS{$metric_name}) ? 1 : 0;
}




sub SCAMET_get_metric_data($)
{
my ($metric_name,
) = @_;


ENV_sig( F => "Unknown Metric: '$metric_name'")
if (!exists $MET_DEFS{$metric_name});

return @{$MET_DEFS{$metric_name}};
}




sub SCAMET_group2txt($)
{
my ($group,	    # number 0-4
) = @_;


return $GROUP_NAMES[$group];
}

1;


