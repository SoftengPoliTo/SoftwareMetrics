#=================================================
#
#   types.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::types;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
TYPES_split_and_validate
TYPES_split
TYPES_get_values
TYPES_type_text
TYPES_occur_text
TYPES_manda_text
TYPES_constr_text
);
}




use glo::env;
use glo::check;




sub TYPES_split_and_validate($;$);
sub TYPES_split($);
sub TYPES_get_values($$$$);
sub TYPES_type_text($);
sub TYPES_occur_text($);
sub TYPES_manda_text($);
sub TYPES_constr_text($$);

sub check_string($$$$);
sub check_choice($$$$);
sub check_file($$$$);
sub check_num($$$$);








my %TYPES = (
s => 'string',
i => 'integer',
b => 'boolean',
t => 'time ([+=]hh:mm or [+=]mm) or now)',
d => 'date (YYYY-MM-DD)',
);
my @TYPES_ORDER = qw( s i b t d);
my $TYPES = join( ',', @TYPES_ORDER);

my %OCCUR = (
s => 'scalar',
a => 'array'
);
my @OCCUR_ORDER = qw( s a);
my $OCCUR = join( ',', @OCCUR_ORDER);

my %MANDA = (
m => 'mandatory',
o => 'optional'
);
my @MANDA_ORDER = qw( m o );
my $MANDA = join( ',', @MANDA_ORDER);

my %CONSTR = (
n   => '',
w	=> 'word',
r   => 'range', 	    	    # list
'>' => 'greater',		    # value
'<' => 'less',		    # value
s   => 'choice',		    # list (selection)
e   => 'existing-file/dir',
d   => 'existing-dir',
f   => 'existing-file',
x   => 'non-existing-file/dir'
);
my @CONSTR_ORDER = qw( n w r > < s e d f x);
my $CONSTR = join( ',', @CONSTR_ORDER);

my %GET_REFS = (

sn	    => [ undef,			    undef ],
sw	    => [ undef,			    \&check_string ],
sr	    => [ undef,			    \&check_string ],
's>'    => [ undef,			    \&check_string ],
's<'    => [ undef,			    \&check_string ],
ss	    => [ undef,			    \&check_choice ],
se	    => [ undef,			    \&check_file ],
sd	    => [ undef,			    \&check_file ],
sf	    => [ undef,			    \&check_file ],
sx	    => [ undef,			    \&check_file ],
in	    => [ \&CHECK_convert_int,	    undef ],
ir	    => [ \&CHECK_convert_int,	    \&check_num ],
'i>'    => [ \&CHECK_convert_int,	    \&check_num ],
'i<'    => [ \&CHECK_convert_int,	    \&check_num ],
is	    => [ \&CHECK_convert_int,	    \&check_choice ],
bn	    => [ \&CHECK_convert_opt_bool,  undef ],
tn	    => [ \&CHECK_convert_time,	    undef ],
tr	    => [ \&CHECK_convert_time,	    \&check_string ],
dn	    => [ \&CHECK_convert_date,	    undef ],
dr	    => [ \&CHECK_convert_date,	    \&check_string ],
);

























sub TYPES_split_and_validate($;$)
{
my ($type_spec_or_ref,
$sig_on_error,	# optional. undef, F E EE W. Default F
) = @_;
my ($type, $occur, $manda, $constr, $constr_values_ref);

($type, $occur, $manda, $constr, $constr_values_ref) = TYPES_split( $type_spec_or_ref);

ENV_sig( $sig_on_error => "Invalid type '$type' ($TYPES)")
if (!exists $TYPES{$type});
ENV_sig( $sig_on_error => "Invalid occur '$occur' ($OCCUR)")
if (!exists $OCCUR{$occur});
ENV_sig( $sig_on_error => "Invalid manda '$manda' ($MANDA)")
if (!exists $MANDA{$manda});
ENV_sig( $sig_on_error => "Invalid constr '$constr' ($CONSTR)")
if (!exists $CONSTR{$constr});

if (wantarray)
{
return ( $type, $occur, $manda, $constr, $constr_values_ref);
} else
{
return [ $type, $occur, $manda, $constr, $constr_values_ref ];
}
}




sub TYPES_split($)
{
my ($type_spec_or_ref,
) = @_;
my ($type, $occur, $manda, $constr, $constr_values_ref);

if (ref $type_spec_or_ref)
{
($type, $occur, $manda, $constr, $constr_values_ref) = @{$type_spec_or_ref};
} else
{
my $type_spec = $type_spec_or_ref;
if (length $type_spec < 4)
{
$type_spec .= substr( 'sson', length $type_spec);
}

($type, $occur, $manda, $constr, my $rest) = split( '', $type_spec, 5);


my @constr_values;
if ($constr eq uc $constr)
{
@constr_values = split( ' ', $rest);
$constr = lc $constr;
} else
{
@constr_values = split( ',', $rest);
}


if ($constr eq 'r')
{
foreach my $range (@constr_values)
{
my ($r1, $r2) = $range =~ /(.*)\.\.(.*)/;
if (defined $r2)
{
$range = [ $r1, $r2 ];
}
}
$constr_values_ref = [ @constr_values ];
} elsif ($constr eq '>' || $constr eq 'e' || $constr eq 'f' || $constr eq 'd')
{
$constr_values_ref = [ [ $constr_values[0] ] ];
} elsif ($constr eq '<')
{
$constr_values_ref = [ [ undef, $constr_values[0] ] ];
} elsif ($constr eq 's')
{
$constr_values_ref = [ @constr_values ];
} else
{

}
}

if (wantarray)
{
return ( $type, $occur, $manda, $constr, $constr_values_ref);
} else
{
return [ $type, $occur, $manda, $constr, $constr_values_ref ];
}
}




sub TYPES_get_values($$$$)
{
my ($name,		    # 'value' if undef
$values_or_ref,	    # IN: comma-list or ref
$type_spec_or_ref,  # [ $type, $occur, $manda, $constr, $constr_values_ref ]
$error_text_ref,    # OUT: \undef or () if ok
) = @_;
my @values;
my @error_texts;


my $allow_multiple_errors = (ref $error_text_ref eq 'ARRAY') ? 1 : 0;

$name = 'value'
if (!defined $name);
my ($type, $occur, $manda, $constr, $constr_values_ref) = (ref $type_spec_or_ref) ? @{$type_spec_or_ref} : TYPES_split( $type_spec_or_ref);

if ($occur eq 'a')	    # array
{
@values = (ref $values_or_ref) ? @{$values_or_ref} : split( ',', $values_or_ref);
} else  #$occur eq 's') # scalar
{
$values[0] = (ref $values_or_ref) ? $$values_or_ref : $values_or_ref;
}






my $get_ref = $GET_REFS{"$type$constr"};

if (defined $get_ref)
{
my ($convert_func, $check_func) = @{$get_ref};
if (defined $convert_func)
{
if ($allow_multiple_errors)
{
@error_texts = $convert_func->( Value => \@values);	# CHECK_convert_int, etc
} else
{
$error_texts[0] = $convert_func->( Value => \@values);	# CHECK_convert_int, etc
}
}
if (defined $check_func && !defined $error_texts[0])
{
if ($allow_multiple_errors)
{
@error_texts = $check_func->( Value => \@values, $constr, $constr_values_ref);
} else
{
$error_texts[0] = $check_func->( Value => \@values, $constr, $constr_values_ref);
}
}
} else
{
ENV_sig( F => "Type $type with Constr $constr is a not supported combination");
}

if ($allow_multiple_errors)
{
@{$error_text_ref} = @error_texts;
} else
{
$$error_text_ref = $error_texts[0];
}

if ($occur eq 'a')	    # array
{
return (wantarray) ? @values : join( ',', @values);
} else  #$occur eq 's') # scalar
{
return $values[0];
}
}




sub check_string($$$$)
{
my ($item_name,			# undef == 'value'
$value_or_ref,			#
$constr,			# r, > <
$allowed_values_or_refs_ref,    # [ $value or [$min, $max] ... ]
) = @_;
my @error_texts;			# empty == OK

if ($constr eq 'w')
{
return CHECK_word( $item_name, $value_or_ref, $allowed_values_or_refs_ref);
} elsif ($constr eq 'r')
{
return CHECK_string_range( $item_name, $value_or_ref, $allowed_values_or_refs_ref);
} elsif ($constr eq '>')
{
return CHECK_string_range( $item_name, $value_or_ref, [ $allowed_values_or_refs_ref->[0]->[0], undef ]);
} elsif ($constr eq '<')
{
return CHECK_string_range( $item_name, $value_or_ref, [ undef, $allowed_values_or_refs_ref->[0]->[0] ]);
} else
{
ENV_sig( F => "Invalid constr ($constr)");
}
}




sub check_choice($$$$)
{
my ($item_name,		    # undef == 'value'
$value_or_ref,		    #
$constr,		    # s
$allowed_values_ref,	    #
) = @_;
my @error_texts;		    # empty == OK

return CHECK_string_choice( $item_name, $value_or_ref, $allowed_values_ref);
}




sub check_file($$$$)
{
my ($item_name,			# undef == 'value'
$value_or_ref,			#
$constr,			# e, d, f
$allowed_values_or_refs_ref,	# -1 == may not exist, 0 == syntax check only, 1 == must exist
) = @_;
my @error_texts;		    # empty == OK



if ($constr eq 'e')
{
return CHECK_file( $item_name, $value_or_ref, '', $allowed_values_or_refs_ref->[0]->[0]);
} elsif ($constr eq 'd')
{
return CHECK_dir( $item_name, $value_or_ref, '', $allowed_values_or_refs_ref->[0]->[0]);
} elsif ($constr eq 'f')
{
return CHECK_file( $item_name, $value_or_ref, '', $allowed_values_or_refs_ref->[0]->[0]);
} else
{
ENV_sig( F => "Invalid constr ($constr)");
}
}




sub check_num($$$$)
{
my ($item_name,			# undef == 'value'
$value_or_ref,			#
$constr,			# r, > <
$allowed_values_or_refs_ref,    # [ $value or [$min, $max] ... ]
) = @_;
my @error_texts;			# empty == OK



if ($constr eq 'r')
{
return CHECK_int_range( $item_name, $value_or_ref, $allowed_values_or_refs_ref);
} elsif ($constr eq '>')
{
return CHECK_int_range( $item_name, $value_or_ref, $allowed_values_or_refs_ref);
} elsif ($constr eq '<')
{
return CHECK_int_range( $item_name, $value_or_ref, $allowed_values_or_refs_ref);
} else
{
ENV_sig( F => "Invalid constr ($constr)");
}
}




sub TYPES_type_text($)
{
my ($type,
) = @_;

return $TYPES{$type};
}




sub TYPES_occur_text($)
{
my ($occur,
) = @_;

return $OCCUR{$occur};
}




sub TYPES_manda_text($)
{
my ($manda,
) = @_;

return $MANDA{$manda};
}




sub TYPES_constr_text($$)
{
my ($constr,
$constr_values_ref,
) = @_;
my @constr_text;

if ($constr ne 'n')
{
@constr_text = ($CONSTR{$constr} . ':');
if ($constr eq 'r')
{
foreach my $constr_or_ref (@{$constr_values_ref})
{
if (ref $constr_or_ref)
{
my ($r1, $r2) = @{$constr_or_ref};
push @constr_text, "$r1..$r2";
} else
{
push @constr_text, $constr_or_ref;
}
}
} else
{
push @constr_text, @{$constr_values_ref};
}
}

return wantarray ? @constr_text : "@constr_text";
}

1;
