#!must_be_sourced!
#=================================================
#   boot.sh
#    - Set GBS_BOOT_PATH
#    - Determine and set GBS_BASE_PATH
#    - Create ~/.gbs/bootstrap.sh if required
#    - Set GBS_PERL_CMD if not defined
#    - Setup the GUI environment (if available)
#=================================================

#
#   Assert TMPDIR
#
[[ "$TMPDIR"=="" ]] && \export TMPDIR=$HOME/tmp
\mkdir $HOME/tmp 2>/dev/null

#
#   Set GBS_BOOT_PATH
#
\export GBS_BOOT_PATH="$HOME/.gbs"

#
#   Set GBS_BASE_PATH
#
if [ -e "$GBS_BOOT_PATH/bootstrap.sh" ]
then
    \source "$GBS_BOOT_PATH/bootstrap.sh"
else
    if [ -e "$GBS_BOOT_PATH/base" ]
    then
	\export GBS_BASE_PATH="$GBS_BOOT_PATH/base"
    else
	\export GBS_BASE_PATH="$GBS_BOOT_PATH"
    fi

    #
    #	Write the bootstrap file
    #
    \echo "\\export GBS_BASE_PATH=$GBS_BASE_PATH" > "$GBS_BOOT_PATH/bootstrap.sh"
fi
#\echo "BOOT_: GBS_BASE_PATH set to '$GBS_BASE_PATH'"

#
#	Setup Perl
#
#echo GBS_PERL_PATH=$GBS_PERL_PATH
if [[ $GBS_PERL_PATH == '' ]]
then
    \export GBS_PERL_CMD="perl"
else
    \export GBS_PERL_CMD="$GBS_PERL_PATH/bin/perl"
    \echo "BOOT_: Perl set to '$GBS_PERL_PATH/bin/perl'"
fi

#
#   Setup the GUI environment (if available)
#
if [ "$XDG_DESKTOP_DIR" == '' ]
then
    #\echo "INSTALL_: Getting GUI info..."
    \test -f ${XDG_CONFIG_HOME:-$HOME/.config}/user-dirs.dirs && source ${XDG_CONFIG_HOME:-$HOME/.config}/user-dirs.dirs
    if [ "$XDG_DESKTOP_DIR" != '' ]
    then
	\export XDG_DESKTOP_DIR
    else
	\echo "BOOT_: GUI NOT present"
    fi
fi

#  **EOF**
