#=================================================
#
#  scmsmaint.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::scmsmaint;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SCMSMAINT_main
SCMSMAINT_fix_ignore
);
}




use glo::env;
use glo::ask;
use glo::slurp;
use glo::scm;
use mod::gbsglo;
use mod::gbsscm;
use mod::system;
use mod::dirstruct;




sub SCMSMAINT_main($$$);
sub SCMSMAINT_fix_ignore($$);

sub scm_modify($$$);

sub scm_fix_ignore($$$);
sub fix_ignore_level($);
sub fix_ignore_level_recurse($);
sub fix_ignore_wild();

sub scm_disable_enable($$$);
sub scm_change_this($$$);
sub scm_change_other($$$);




my $SAVED_SCMS;
my $OTHER_OSNAME;




sub SCMSMAINT_main($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;

my $scms_state = (defined $SAVED_SCMS) ? 'Disabled' : 'Enabled';
$OTHER_OSNAME = (SYSTEM_get_osnames( $GBS::ROOT_PATH, 'scms'))[1];	    # first (0) is current OS
$OTHER_OSNAME = ''
if (!defined $OTHER_OSNAME);
my @scm_menu_items = (
[ "Modify (fix) SCMS settings (Repository, Data)",
\&scm_modify ],
[ "Fix SCMS 'ignore' settings. (svn and git only)",
\&scm_fix_ignore ],
[ "Temporarily disable/enable SCMS   ($scms_state)",
\&scm_disable_enable ],
[ "Not Used",
sub { ENV_say( 1, "Not used!") } ],
[ "Not Used",
sub { ENV_say( 1, "Not used!") } ],
[ "Not Used",
sub { ENV_say( 1, "Not used!") } ],
[ "Not Used",
sub { ENV_say( 1, "Not used!") } ],
[ "Change SCMS",
\&scm_change_this ],
[ "Change SCMS for Other Platform ($OTHER_OSNAME)",
\&scm_change_other ],
);

ASK_menu( 'Select function to perform', \@scm_menu_items, $entries_ref);
}




sub scm_modify($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;




my ($gbs_scms, $gbs_scms_repository, $gbs_scms_data) = GBSSCM_preset( 0);

($gbs_scms, $gbs_scms_repository, $gbs_scms_data) =
SCM_select( [ undef, $gbs_scms_repository, $gbs_scms_data ], $GBS::ROOT_PATH);

ENV_say( 1, "Selected: $gbs_scms: $gbs_scms_repository ($gbs_scms_data)");
if (ASK_YNQ( 'OK?', 'Y', 1) eq 'Y')
{



SCM_preset( $GBS::ROOT_PATH, [$gbs_scms, $gbs_scms_repository, $gbs_scms_data ]);
GBSSCM_setenv( [ $gbs_scms, $gbs_scms_repository, $gbs_scms_data ]);
GBSSCM_connect();

SYSTEM_put_os( $GBS::ROOT_PATH, '.', scms	    => $gbs_scms);
SYSTEM_put_os( $GBS::ROOT_PATH, '.', scms_repository => $gbs_scms_repository);
SYSTEM_put(    $GBS::ROOT_PATH,      scms_data	    => $gbs_scms_data);
SYSTEM_write();	   # Includes backup and SCM_checkout
}
}




sub scm_fix_ignore($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;

GBSSCM_preset( 0);
my $current_id = SCM_get_current_id();
if ($current_id eq 'svn' || $current_id eq 'git')
{
ENV_say( 1, "GBS_ROOT_PATH: $GBS::ROOT_PATH");
my @item_refs;
push @item_refs, [ 'Whole System. (may take a while!)',
sub { fix_ignore_level( $GBS::ROOT_PATH) } ];
if ($GBS::SUBSYS)
{
push @item_refs, [ "Current SubSys ($GBS::SUBSYS)",
sub { fix_ignore_level( "$GBS::ROOT_PATH/dev/$GBS::SUBSYS") } ];
} else
{
push @item_refs, [ "Current SubSys - Not Available",
sub { ENV_say( 1, "Not Availabe!") } ],
}
if ($GBS::COMPONENT)
{
push @item_refs, [ "Current Component ($GBS::COMPONENT)",
sub { fix_ignore_level( "$GBS::ROOT_PATH/dev/$GBS::SUBSYS/comp/$GBS::COMPONENT") } ]
} else
{
push @item_refs, [ "Current Component - Not Available",
sub { ENV_say( 1, "Not Availabe!") } ],
}
push @item_refs, [ 'Wildcard',
\&fix_ignore_wild ];

ASK_menu( 'Select function', \@item_refs, $entries_ref);
} else
{
ENV_sig( W => 'Not SubVersioN or Git');
}
}




sub fix_ignore_level($)
{
my ($toplevel_spec) = @_;	# SYSTEM, SUBSYS, COMPONENT

GBSSCM_preset( 0);

ENV_say( 2, "Caching states...");
SCM_cache_states( 0);	    # 0 == do not force reread
my @paths = fix_ignore_level_recurse( $toplevel_spec);
my $nr_fixed = SCMSMAINT_fix_ignore( \@paths, 1);
ENV_say( 2, "Fixed $nr_fixed entries");
}




sub fix_ignore_level_recurse($)
{
my ($spec) = @_;
my @paths;

push @paths, $spec;
foreach my $dir (SLURP_dir_dirs( $spec, 0))
{
push @paths, fix_ignore_level_recurse( "$spec/$dir");    #recurse
}

return @paths;
}




sub fix_ignore_wild()
{
ENV_say( 1, "WildCards relative to GBS_ROOT_PATH");
my $wild_spec;
do
{
$wild_spec = ASK_text( 'Enter Wildcard', '', 0, undef);
if ($wild_spec)
{
my $abs_wild_spec = "$GBS::ROOT_PATH/$wild_spec";
my @specs = ENV_glob( $abs_wild_spec);
if (@specs)
{
my @paths;
foreach my $spec (@specs)
{
if (-e $spec)
{
push @paths, $spec
if (-d _);
} else
{
ENV_say( 1, "No such file/dir '$spec'");
}
}
SCMSMAINT_fix_ignore( \@paths, 1)
if (@paths);
} else
{
ENV_say( 1, "No files/directories found!");
}
}
} while ($wild_spec);
}




sub SCMSMAINT_fix_ignore($$)
{
my ($filespec_or_ref,
$interactive,		# bool
) = @_;
my $nr_fixed = 0;

ENV_say( 2, "Collecting...");

my @fix_refs;

foreach my $spec (ENV_deref( $filespec_or_ref))
{
my $short_spec = GBSGLO_short_filespecs( $spec);
my ($ignores_ref, $must_scm) = DIRSTRUCT_dir_attrib( $spec);
my @wanted_ignores = @{$ignores_ref};
if ($must_scm != 0)			# must_scm: 0 = no, 1 = yes, -1 = don't know
{
my $state = SCM_get_states( $spec, 0);	# state: 0 = checked in, 1 = checked_out, -1 = Not in scm
if ($state >= 0)	# state is in_scm
{
my @current_ignores = SCM_get_ignore( $spec);


ENV_whisper( 3, "DIR: $short_spec",
"  CUR-IGNORE: [ @current_ignores ]",
"  REQ-IGNORE: [ @wanted_ignores ], $must_scm");
if ("@current_ignores" ne "@wanted_ignores")
{
my @new_ignores = @wanted_ignores;



my @non_gbs_ignores = grep( $_ !~ /\.(gbs|usr\.\*|usr|gbsrc|gbs\.bat|gbs\.sh)$/, @current_ignores);

if (@non_gbs_ignores)
{
my %non_gbs_ignores = map { $_ => 1 } @non_gbs_ignores;
foreach my $wanted_ignore (@wanted_ignores)
{
push @new_ignores, $wanted_ignore
if (!exists $non_gbs_ignores{$wanted_ignore});
}
}

if ("@new_ignores" ne "@current_ignores")
{
ENV_say( 3, "DIR: $short_spec");
ENV_say( 4, "wanted   ignores=@wanted_ignores");
ENV_say( 4, "current  ignores=@current_ignores");
ENV_say( 4, "  user   ignores=@non_gbs_ignores");
ENV_say( 4, "new      ignores=@new_ignores");
push @fix_refs, [ $spec, $short_spec, \@current_ignores, \@new_ignores ];
}
} else
{












}
} else
{
ENV_whisper( 3, "DIR: $short_spec",
"  REQ-IGNORE: [ @wanted_ignores ], $must_scm - NOT SCM");
}
} else
{
ENV_whisper( 3, "DIR: $short_spec",
"  REQ-IGNORE: [ @wanted_ignores ], $must_scm");
}
}

if (@fix_refs)
{
ENV_say( 2, "Fixing...");
my $ans = 'Y';
foreach my $ref (@fix_refs)
{
my ($spec, $short_spec, $current_ignores_ref, $new_ignores_ref) = @{$ref};
if ($interactive && $ans ne 'A')
{
$ans = ASK_YNAE( "  Fix $short_spec [@{$current_ignores_ref}]=>[@{$new_ignores_ref}]?", 'Y', 0);
}
my $must_fix = 0;
if ($ans eq 'Y' || $ans eq 'A')
{
$must_fix = 1;
} elsif ($ans eq "N")
{
;
} elsif ($ans eq "E")
{
last;
}
if ($must_fix)
{
SCM_set_ignore( $spec, $new_ignores_ref);
ENV_say( 3, "$short_spec => fixed!");
$nr_fixed++;
}
}
} else
{
ENV_say( 2, 'Nothing to fix');
}
return $nr_fixed;
}




sub scm_disable_enable($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;

if (defined $SAVED_SCMS)
{



ENV_say( 1, "SCMS is currently disabled");
if ( ASK_YN( "Enable SCM '$SAVED_SCMS'?", 'Y') eq 'Y')
{
GBSSCM_resume();
$SAVED_SCMS = undef;
}
} else
{



if ($GBS::SCMS eq 'No_SCMS')
{
ENV_sig( W => "No current SCMS");
} else
{
ENV_say( 1, "SCMS ('$GBS::SCMS') is currently enabled");
if ( ASK_YN( "Disable SCMS?", 'Y') eq 'Y')
{
GBSSCM_suspend();
$SAVED_SCMS = $GBS::SCMS;
SCM_preset( $GBS::ROOT_PATH, [ 'no_scms', undef, undef ]);
}
}
}
}




sub scm_change_this($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;




my ($gbs_scms, $gbs_scms_repository, $gbs_scms_data) = GBSSCM_preset( 0);

($gbs_scms, $gbs_scms_repository, $gbs_scms_data) =
SCM_select( [ $gbs_scms, $gbs_scms_repository, $gbs_scms_data ], $GBS::ROOT_PATH);

ENV_say( 1, "Selected: $gbs_scms: $gbs_scms_repository ($gbs_scms_data)");
if (ASK_YNQ( 'OK?', 'Y', 1) eq 'Y')
{



SCM_preset( $GBS::ROOT_PATH, [$gbs_scms, $gbs_scms_repository, $gbs_scms_data ]);
GBSSCM_setenv( [ $gbs_scms, $gbs_scms_repository, $gbs_scms_data ]);
GBSSCM_connect();

SYSTEM_put_os( $GBS::ROOT_PATH, '.', scms	    => $gbs_scms);
SYSTEM_put_os( $GBS::ROOT_PATH, '.', scms_repository => $gbs_scms_repository);
SYSTEM_put(    $GBS::ROOT_PATH,      scms_data	    => $gbs_scms_data);
SYSTEM_write();	   # Includes backup and SCM_checkout
}
}




sub scm_change_other($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;

if ($OTHER_OSNAME ne '')
{
my $cur_other = SYSTEM_get_os( $GBS::ROOT_PATH, $OTHER_OSNAME, 'scms');
ENV_say( 1, "The SCMS for the other platform ($OTHER_OSNAME) is '$cur_other'");
if (ASK_YN( 'Change?', 'N') eq 'Y')
{
my @scm_names = SCM_get_names( '!');    # Other OS
my $new_other = ASK_value_from_menu( "Select SCMS for Platform $OTHER_OSNAME", \$cur_other,
undef, [ @scm_names ]);
ENV_say( 1, "Selected: $new_other");
if ($new_other ne $cur_other)
{
if (ASK_YN( 'Ok?', 'N') eq 'Y')
{
GBSSCM_preset( 0);
SYSTEM_put_os( $GBS::ROOT_PATH, $OTHER_OSNAME, scms => $new_other);
SYSTEM_write();    # Includes backup and SCM_checkout
ENV_say( 1, 'Changed');
}
} else
{
ENV_say( 1, 'Unchanged');
}
}
} else
{
ENV_sig( W => "There is no other Platform instance for this System");
}
}

1;
