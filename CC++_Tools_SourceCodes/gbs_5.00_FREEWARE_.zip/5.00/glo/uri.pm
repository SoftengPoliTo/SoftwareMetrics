#=================================================
#
#   uri.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================




package glo::uri;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
URI_normalize
);
}




use glo::env;




sub URI_normalize($$$$);

sub authority_scheme($$$$);
sub mailto_scheme($$$$);







my $IS_WIN32 = (ENV_is_win32());

my %SCHEME_DEF_REFS = (


file	=> [ \&authority_scheme,    'A' ],
http	=> [ \&authority_scheme,    'A' ],
https	=> [ \&authority_scheme,    'A' ],
mailto	=> [ \&mailto_scheme,	    'M' ],
svn		=> [ \&authority_scheme,    'A' ],
'svn+ssh'	=> [ \&authority_scheme,    'A' ],
);

my %SCHEME_ALIASES = (

file	=> [ [ 'file'		],  'A' ],
http	=> [ [ 'http', 'https'	],  'A' ],
mailto	=> [ [ 'mailto'		],  'M' ],
svn		=> [ [ 'svn', 'svn+ssh'	],  'A' ],
);




my %CACHE_REFS = (

);











sub URI_normalize($$$$)
{
my ($uri,			# Absolute or relative path
$path,			# Used for relative path. May be '' or undef
$allowed_schemes_ref,	# undef == must be specified. May also be single scalar
$error_text_ref,	# OUT: If undef then error_exit else '' if Ok
) = @_;
my ($full_uri, $scheme, @scheme_dependent);
my $error_text = '';

if (!defined $path && !defined $allowed_schemes_ref && !defined $error_text_ref && exists $CACHE_REFS{$uri})
{
($full_uri, $scheme, @scheme_dependent) = @{$CACHE_REFS{$uri}};

} else
{





$$error_text_ref = ''
if (defined $error_text_ref);




$uri =~ s/^<(?:URL:)?(.*)>$/$1/;	#
$uri =~ s/^"(.*)"$/$1/;			# remove surrounding quotes
$uri =~ s/^\s+(.*?)\s+$/$1/;		# remove leading and traing whitespace




my @allowed_schemes;
my $specific_scheme;
my $current_scheme_type = '';
if (defined $allowed_schemes_ref)
{
if (ref $allowed_schemes_ref)
{
foreach my $allowed_scheme (@{$allowed_schemes_ref})
{
my $alias_ref = $SCHEME_ALIASES{$allowed_scheme};
ENV_sig( F => "No such scheme alias '$allowed_scheme'")
if (!defined $alias_ref);
my ($aliases_ref, $scheme_type) = @{$alias_ref};
ENV_sig( F => "Cannot combine Authority with Mailto. ('$allowed_scheme'->'$scheme_type')")
if ($current_scheme_type ne '' && $scheme_type ne $current_scheme_type);
$current_scheme_type = $scheme_type;
push @allowed_schemes, @{$aliases_ref};
}
} else
{
$specific_scheme = $allowed_schemes_ref;		# not a ref
my $scheme_type_ref = $SCHEME_DEF_REFS{$specific_scheme};
ENV_sig( F => "No such scheme '$specific_scheme'")
if (!defined $scheme_type_ref);
$current_scheme_type = $scheme_type_ref->[1];	# $scheme_type
@allowed_schemes = ($specific_scheme);
}
}






my ($scheme, $rest) = $uri =~ /^([A-Za-z][A-Za-z0-9+.\-]+):(.*)$/;
if (defined $scheme)
{
$scheme = lc $scheme;
if (exists $SCHEME_DEF_REFS{$scheme})
{
if (@allowed_schemes && !grep $scheme eq $_, @allowed_schemes)
{
$error_text = "URI scheme '$scheme' not allowed in this context (@allowed_schemes)";
} else
{
$current_scheme_type = $SCHEME_DEF_REFS{$scheme}->[1];
}
} else
{
my @scheme_names = sort keys %SCHEME_DEF_REFS;
$error_text = "URI scheme '$scheme:' not recognised (@scheme_names)";
}
} else
{
$scheme = '';
$rest = $uri;
if (!defined $allowed_schemes_ref)
{
$error_text = "URI scheme must be specified. Syntax = [a-z][a-z0-9+.-]*:.*";
}
}




if ($error_text eq '')
{



if ($current_scheme_type eq 'A')
{
($full_uri, @scheme_dependent) = authority_scheme( [ @allowed_schemes ], $scheme, $rest, \$error_text);
} elsif ($current_scheme_type eq 'M')
{
($full_uri, @scheme_dependent) = mailto_scheme( undef, $scheme, $rest, \$error_text);
} else  # $current_scheme_type eq ''
{
ENV_sig( F => "Could not determine scheme_type '$current_scheme_type'")
}
}

if ($error_text eq '')
{

my $cache_ref = [ $full_uri, $scheme, @scheme_dependent ];
$CACHE_REFS{$uri} = $cache_ref;
$CACHE_REFS{$full_uri} = $cache_ref;
} else
{
$full_uri = $uri;
if (defined $error_text_ref)
{
$$error_text_ref = $error_text;
} else
{
ENV_sig( EE => $error_text, "- $uri");
}
}
}

if (wantarray)
{
return ($full_uri, $scheme, @scheme_dependent);
} else
{
return $full_uri;
}
}





sub authority_scheme($$$$)
{
my ($allowed_schemes_ref,
$scheme,		# '', file, http, https, svn svn+ssh
$rest,			# uri if $scheme eq ''
$error_text_ref,	# OUT: Always defined
) = @_;
my ($full_uri, @scheme_dependent);

my $error_text = '';

if ($scheme eq '')
{
my $perl_uri = ENV_perl_paths( $rest);
if (ENV_is_abs_path( $perl_uri))
{



$scheme = 'file';
if ($IS_WIN32)
{
if (substr( $perl_uri, 0, 2) ne '//')
{
$rest = "///$rest";	# local disk location
}
} else
{
$rest = "//$rest";
}
$full_uri = "$scheme:$rest";
} elsif ($rest =~ /^www\./i)
{



$scheme = 'http';
$rest = "//$rest";
$full_uri = "$scheme:$rest";
} else
{
$full_uri = $rest;
$error_text = "Cannot determine scheme";
}
} else
{
$full_uri = "$scheme:$rest";
}

if ($error_text eq '')
{
$rest = ENV_perl_paths( $rest);
if ($scheme eq 'file')
{



my $full_path;
my ($host, $path) = $rest =~ m!^//(.*?)/(.*)$!;
if (defined $host)
{

$host = ''
if (lc $host eq 'localhost');
$full_uri = "$scheme://$host/$path";
if ($IS_WIN32)
{
if ($host eq '')
{
if ($path =~ m!^[a-zA-Z]:!)
{
$full_path = $path;	    # Local Drive
} else
{
$error_text = "'$full_uri': path '$path' is not a Windows absolute path";
}
} else
{

$full_path = "//$host/$path";	    # Network drive
}
} else
{
$full_path = "/$path";
}
@scheme_dependent = ($path);
} else
{
$error_text = "'$full_uri': Syntax: 'file://[<host>]/<path>'";
}
} elsif ($scheme ne '')
{



my ($authority, $query, $fragment) = $rest =~ m!^//([^&#]+)&?([^#]*)#?(.*)$!;
if (defined $authority)
{
@scheme_dependent = ($authority, $query, $fragment);
} else
{
$error_text = "'$full_uri': Syntax: '$scheme://[<host>][/<path>][&<query][#fragment]'";
}

} else	# $scheme eq ''
{
$error_text = "Cannot determine scheme";
}
}


$$error_text_ref = $error_text
if ($error_text ne '');
return ($full_uri, @scheme_dependent);
}





sub mailto_scheme($$$$)
{
my ($allowed_schemes_ref,	# undef
$scheme,		# '' or mailto
$rest,			# uri if $scheme eq ''
$error_text_ref,	# OUT: If undef then error_exit else already set to ''
) = @_;
my ($full_uri, @scheme_dependent);

my $error_text = '';

ENV_sig( F => 'mailto: not implemented');
if ($scheme eq '')
{
$scheme = 'mailto';
$full_uri = "$scheme:$rest";
}

if ($error_text eq '')
{
$full_uri = "$scheme:$rest";
}


$$error_text_ref = $error_text
if ($error_text ne '');
return ($full_uri, @scheme_dependent);
}

1;

