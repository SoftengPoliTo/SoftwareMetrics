#=================================================
#
#   proc_win32.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::proc_win32;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
PROC_WIN32_create_normal
PROC_WIN32_create_detached
);
}




use Win32::Process;
use glo::env;




sub PROC_WIN32_create_detached($$$);
sub PROC_WIN32_create_normal($$$$);

sub win_create($$$$$);











































sub PROC_WIN32_create_detached($$$)
{
my ($command,
$full_command,
$curdir,
) = @_;


return win_create( $command, $full_command, DETACHED_PROCESS, $curdir, undef);
}




sub PROC_WIN32_create_normal($$$$)
{
my ($command,
$full_command,
$curdir,
$log_file,
) = @_;


return win_create(  $command, $full_command, 0, $curdir, $log_file);
}




sub win_create($$$$$)
{
my ($command,
$full_command,
$flags,
$curdir,
$log_file,
) = @_;
my ($pid, $proc);




my $inherit_handles = 0;
my $saved_stdout;
my $saved_stderr;
if (defined $log_file)
{
$inherit_handles = 1;
ENV_redirect_stdouterr( $log_file);
}
my $ok = Win32::Process::Create( $proc,		    #object to hold process.
$command,
$full_command,
$inherit_handles,      # inherit handles of parent
$flags,
$curdir);
my $error_text = ($ok) ? undef : "$^E";

if (defined $log_file)
{
ENV_restore_stdouterr();
}

if ($ok)
{
$pid = $proc->GetProcessID();
ENV_debug( 1, " pid=$pid");
} else
{
ENV_sig( F => "Failed to launch: $command",
"- $error_text",
"Full Command=$full_command");
}

return ($pid, $proc);
}

1;
