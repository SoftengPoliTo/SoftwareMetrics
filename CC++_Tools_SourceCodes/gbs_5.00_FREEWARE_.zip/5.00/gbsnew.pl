#=================================================
#
#   gbsnew.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSNEW @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::list;
use glo::spit;
use glo::ask;
use glo::askform;
use glo::slurp;
use glo::genopt;
use glo::version;
use glo::format;
use glo::scm;
use mod::gbsenv;
use mod::gbsenvs;
use mod::gbsglo;
use mod::gbsscm;
use mod::gbsdb;
use mod::roots;
use mod::rootsglo;
use mod::fcreate;
use mod::dirstruct;
use mod::system;
use mod::validate;
use mod::pluginmaint;
use mod::profile;
use mod::ssprop;




sub main_new_system($);
sub create_or_update_system($);
sub ask_new_system_data($);
sub scm_select($$$$);
sub validate_user();
sub main_new_other_system($);
sub main_new_subsys($);
sub ask_new_subsys_data($);
sub post_func_subsys($$);
sub check_subsys($$$);
sub main_new_component($);
sub ask_new_component_data($);
sub check_component($$$);
sub main_new_build($);
sub main_remove_build($);
sub main_new_audit($);
sub main_remove_audit($);
sub main_new_tool($);
sub main_remove_tool($);
sub select_via_menu();




my $CWD = ENV_cwd();

my @FUNCTION_REFS = (
[ 'exit',		undef			],
[ 'new_root',	\&main_new_system	],
[ 'new_other_root',	\&main_new_other_system ],
[ 'new_subsys',	\&main_new_subsys	],
[ 'new_component',	\&main_new_component	],
[ 'new_build',	\&main_new_build	],
[ 'rem_build',	\&main_remove_build	],
[ 'new_audit',	\&main_new_audit	],
[ 'rem_audit',	\&main_remove_audit	],
[ 'new_tool',	\&main_new_tool		],
[ 'rem_tool',	\&main_remove_tool	],
);
my %FUNCTION_REFS = map { $_->[0] => $_ } @FUNCTION_REFS;

my $RUNNING_STANDALONE = 0;

my @FILES_TO_DELETE;	# in case of fatal error or Quit









$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;





my $RESULT = '';	# The (first) item created: $new_root_path, $new_subsys, etc or ''
my @SETENV_PAIR_REFS;	# E.g.: GBS_ADMINISTRATOR=<list>

GBSENV_init( undef);













{
my @genopts = (
[ '<1>',	'function', 'ssosnew_root,new_other_root,new_subsys,new_component,new_build,rem_build,new_audit,rem_audit,new_tool,rem_tool', '', 'Function to be executed' ],
[ '<2>',	'func_arg', 'sso',                               '', 'Function dependent argument' ],
);
my @genconflicts = (
);
GENOPT_set_optdefs( 'gbsnew', \@genopts,
'Root/System, SubSystem, Component and Build Create/Remove/etc',
undef);
GENOPT_set_conflicts( \@genconflicts);
GENOPT_parse();
}
my $FUNCTION = GENOPT_get( 'function');
my $FUNC_ARG = GENOPT_get( 'func_arg');




VALIDATE_gbs();




{
if ($FUNCTION eq '')
{
$RUNNING_STANDALONE = 1;
select_via_menu();
} else
{
my $func = $FUNCTION_REFS{$FUNCTION}->[1];
$RESULT = $func->( $FUNC_ARG);
}
}




{




my @lines;
push @lines, $RESULT;		    # Created ROOT, SUBSYS, COMPONENT, Build, Audit or ''

foreach my $ref (@SETENV_PAIR_REFS)	    # GBS_ADMINISTRATOR, GBS_ALL_SUBSYSTEMS, etc
{
my ($env_name, $value_or_ref) = @{$ref};
$value_or_ref = join( ',', @{$value_or_ref})
if (ref $value_or_ref);
push @lines, "$env_name=$value_or_ref";
}
my $gbs_new_file_spec = ENV_getenv( 'GBS_NEW_FILE');
SPIT_file_nl( $gbs_new_file_spec, \@lines)
if ($gbs_new_file_spec);


ENV_say( 1, @lines)
if ($RUNNING_STANDALONE);
}

ENV_exit( $RC);




END
{
my $gbs_new_file_spec = ENV_getenv( 'GBS_NEW_FILE');
if (!-e $gbs_new_file_spec)
{
ENV_chdir( $CWD);
foreach my $file_or_dir (@FILES_TO_DELETE)
{
if (-d $file_or_dir)
{
ENV_rmtree( $file_or_dir, 1, 1, 'W')	    # $also_remove_top, $force
if (ASK_YN( "Delete path '$file_or_dir'", 'Y') eq 'Y');
} elsif (-f _)
{
ENV_unlink( $file_or_dir, 1, 'W')	    # $force
if (ASK_YN( "Delete file '$file_or_dir'", 'Y') eq 'Y');
}
}
}

ENV_print_end_msg( 0);
}




sub main_new_system($)
{
my ($spec_new_root_path) = @_;		# perl_format
my $new_root_path = '';

ENV_say( 1, "New Root ($spec_new_root_path)");

validate_user();




if (ROOTS_get_nr() > 0)
{
ENV_say( 1, "Currently in Roots-List:");
ROOTSGLO_print_root_cols();
} else
{
ENV_say( 1, "No Roots in Roots-List");
}
ENV_say( 0, '');

my $current_root_parent_path = '';
my $last_root_parent_path = '';
my @menu_refs = (
[ '', '' ]		    # <None> entry
);


if ($spec_new_root_path eq '')
{



$current_root_parent_path = ($GBS::ROOT_PATH eq '') ? '' : ENV_parent_path( $GBS::ROOT_PATH);

if ($current_root_parent_path ne '')
{
ENV_say( 1, "Current Root Parent is '$current_root_parent_path'");	# will be default
push @menu_refs, [ "Create a Root in the Current Parent Path ($current_root_parent_path)", 'ADD_CURPAR' ];
} else
{
my $last_root_path = GBSDB_last_root_get();
if ($last_root_path ne '')
{
$last_root_parent_path = ENV_parent_path( $last_root_path);
ENV_say( 1, "Last Used Root Parent is '$last_root_parent_path'");	# will be default
if (-d $last_root_parent_path)
{
push @menu_refs, [ "Create a Root in the Last Used Parent Path ($last_root_parent_path)", 'ADD_LASTPAR' ];
} else
{
ENV_say( 2, 'Does not exist (anymore) - skipped');
my $gbswa_root = ENV_get_user_path( 0) . '/GBSWA';	# ~/GBSWA or MyDocuments/GBSWA
push @menu_refs, [ "Create in User's GBSWA ($gbswa_root)", 'USE_GBSWA' ];
}
} else
{

my $gbswa_root = ENV_get_user_path( 0) . '/GBSWA';	# ~/GBSWA or MyDocuments/GBSWA
push @menu_refs, [ "Create in User's GBSWA ($gbswa_root)", 'USE_GBSWA' ];
}
}
if ($CWD !~ /^$GBS::ROOT_PATH/ || $GBS::ROOT_PATH eq '')
{
ENV_say( 1, "Currenty (CWD) in '$CWD'");
push @menu_refs, [ 'Use the Current Path (CWD) as Root Path', 'USE_ROOT' ];
push @menu_refs, [ 'Use the Current Path (CWD) as Parent Path', 'USE_PAR' ];
}
push @menu_refs, [ 'Explicitly specify a Root Path', 'SPEC_ROOT' ];
} else
{



$spec_new_root_path = ENV_abs_paths( undef, $spec_new_root_path);
my $exists = (-d $spec_new_root_path) ? 'Exist' : 'NOT Exists';
ENV_say( 1, "Specified '$spec_new_root_path' ($exists)");
push @menu_refs, [ 'Use the specified Path as Root Path', 'USE_SPEC_ROOT' ];
push @menu_refs, [ 'Use the specified Path as Parent Path', 'USE_SPEC_PAR' ];
}

my ($select_value, @more_values) = ASK_value_from_menu( 'Select Root Create action:', 1 , undef, [ @menu_refs ]);


if ($select_value ne '')
{
my $parent_path = '';
my $root_dir = '';
my $root_path = '';	# $parent_path/$root_dir
if ($select_value eq 'ADD_CURPAR')
{
$parent_path = $current_root_parent_path;
} elsif ($select_value eq 'ADD_LASTPAR')
{
$parent_path = $last_root_parent_path;
} elsif ($select_value eq 'USE_ROOT')
{
$root_path = $CWD;
} elsif ($select_value eq 'USE_GBSWA')
{
$parent_path = ENV_get_user_path( 0) . '/GBSWA';	# ~/GBSWA or MyDocuments/GBSWA
if (! -d $parent_path)
{
ENV_mkdir( $parent_path);
ENV_say( 1, " Created $parent_path");
}
} elsif ($select_value eq 'USE_PAR')
{
$parent_path = $CWD;
} elsif ($select_value eq 'SPEC_ROOT')
{

} elsif ($select_value eq 'USE_SPEC_ROOT')
{
$root_path = $spec_new_root_path;
} elsif ($select_value eq 'USE_SPEC_PAR')
{
$parent_path = $spec_new_root_path;
} else
{
ENV_sig( F => "Impossible $select_value");
}
if ($root_path ne '')
{
$parent_path = ENV_parent_path( $root_path);
$root_dir = ENV_parent_dir( $root_path, -1);
}





if ($parent_path eq '')
{



$root_path = ASK_path( "Enter New Root Path", $CWD, 0, 0);
} elsif ($root_dir eq '')
{



ENV_say( 1, "Root Parent is '$parent_path'");
my @dirs = SLURP_dir_dirs( $parent_path, 0);
if (@dirs > 0)
{
ENV_say( 0, "And contains:");
ENV_say( 0, FORMAT_cols( 0, 2, '  ', 2, \@dirs));
}
$root_dir = ASK_dir( 'Enter New Root Dir', '', 0, 0, $parent_path);   # $length, $must_exist, $path
$root_path = "$parent_path/$root_dir"
if ($root_dir ne '');
} else
{

ENV_say( 0, "OK");
}

if ($root_path ne '')
{
ENV_say( 0, '');
ENV_say( 1, "Selected path:",
"$root_path");

if (-e $root_path)
{



my @root_files = SLURP_dir_all( $root_path, 0);
if (@root_files)
{
ENV_say( 1, "This Root already exists and contains data:",
"@root_files");

if (ASK_YNQ( 'Continue and re-create this Root/System?', 'N', 1) eq 'Y')
{
$new_root_path = ENV_perl_paths_noquotes( $root_path);
}
} else
{
$new_root_path = ENV_perl_paths_noquotes( $root_path);
}
} else
{
if (ASK_YNQ( "Root does not exist. Create?", 'Y', 1) eq 'Y')
{
ENV_mkpath( $root_path);
$new_root_path = $root_path;
push @FILES_TO_DELETE, $new_root_path;
}
}




if ($new_root_path ne '')
{

create_or_update_system( $new_root_path);
}
}
}

ENV_sig( W => "No new Root/System created or updated")
if ($new_root_path eq '');

return $new_root_path;
}




sub create_or_update_system($)
{
my ($new_root_path,
) = @_;


ENV_chdir( $new_root_path);





my ( $system_name, $scms_info ) = ask_new_system_data( $new_root_path);
my @scms_items = SCM_split_info( $scms_info);




SCM_preset( $new_root_path, [ @scms_items ]);
GBSSCM_setenv( [ @scms_items ]);
GBSSCM_connect();




ENV_say( 1, "Validating Root: $new_root_path");
my $again;
do
{
$again = 0;
my $state = SCM_get_states( $new_root_path, 0);




if ($state == -1)
{
ENV_sig( W => "Root directory not under SCM control");
$again = 1;
} elsif ($state == 0)
{
SCM_checkout( $new_root_path);
}
if ($again)
{
ENV_say( 1, "You now have the chance to fix things. (like Checkout WA)",
"Then enter Y to Retry. Enter N or Q to Quit");
if (ASK_YNQ( "Retry?", 'Y', 1) eq 'Y')
{
GBSSCM_preset( 0);	    # reset scm
} else
{
ENV_exit();
}
}
} while ($again);




ENV_say( 1, "Creating System ...");
GBSENVS_set_root( 1);   # Cleanup
GBSENVS_update( 1, GBS_ROOT_PATH => $new_root_path);
my @new_dirs = DIRSTRUCT_mandatory_dirs( $GBS::ROOT_PATH, 'SYSTEM');
SCM_add_dirs( \@new_dirs, \&DIRSTRUCT_get_ignore_spec, 0, 0);	    # $pre_validated, $verbose
ENV_whisper( 1, "Setting ignores...");
SCM_set_ignore( $new_root_path, DIRSTRUCT_get_ignore_spec( $GBS::ROOT_PATH));

my @new_files;




push @new_files, FCREATE_switch( 'switch.gbs', $GBS::ROOT_PATH, $system_name);




push @new_files, FCREATE_sys( 'sys.gbs', $GBS::ROOT_PATH, $system_name);
SCM_add_txt_files( \@new_files, 0, 0);		# $prevalidated, $verbose




ENV_whisper( 1, "Filling system file");
SYSTEM_create( $GBS::ROOT_PATH);
SYSTEM_put(	$GBS::ROOT_PATH,	    version_start   => $GBS::FULL_VERSION);
SYSTEM_put(	$GBS::ROOT_PATH,	    system_name	    => $system_name);
SYSTEM_put_os( $GBS::ROOT_PATH, '.',    scms	    => $scms_items[0]);	    # $new_scms,
SYSTEM_put_os( $GBS::ROOT_PATH, '.',    scms_repository => $scms_items[1]);	    # $new_scms_repository,
SYSTEM_put(	$GBS::ROOT_PATH,	    scms_data	    => $scms_items[2]);	    # $new_scms_data,
SYSTEM_put(	$GBS::ROOT_PATH,	    root_version    => VERSION_get_version());
SYSTEM_put_os( $GBS::ROOT_PATH, '.',    builds	    => []);
SYSTEM_write();   # Includes backup and SCM_checkout

ENV_say( 1, "Root/System '$GBS::ROOT_PATH' created");




ENV_whisper( 1, "Setting GBS Administrator privilege...");
PROFILE_open( undef);
PROFILE_add_to_list( GBS_ADMINISTRATOR => $system_name);
PROFILE_close( 1);	# $must_write
push @SETENV_PAIR_REFS, [ GBS_ADMINISTRATOR => join( ',', sort( @GBS::ADMINISTRATOR, $system_name) )];
ENV_say( 1, "You are now also GBS Administrator for this Root/System");

}





sub ask_new_system_data($)
{
my ($new_root_path,
) = @_;
my ($system_name, $scms_info);




($system_name) = $new_root_path =~ m!.*[/\\](.+)!;	 #last directory
$system_name = ucfirst $system_name;
$scms_info = '';

my @mnem_refs;


push @mnem_refs, [ \$system_name, 'System_name', 'New System-Name',
"ssmw", $system_name, undef, 1, undef ];
push @mnem_refs, [ \$scms_info, 'SCMS', 'New SCMS',
"ssmn", $scms_info, undef, 1, [ \&scm_select ] ];
ASKFORM_new( 'New Root/System', 0, \@mnem_refs, undef, undef, undef);

return ( $system_name, $scms_info);
}




sub scm_select($$$$)
{
my ($mnem_hash_ref,
$mnem,
$this_default,
$length,
) = @_;

my ($mnem_value_ref, undef, $opt_name, $type_spec_ref, undef, $item_help_or_ref) = @{$mnem_hash_ref->{$mnem}};
my ($type, $occur, $manda, $constr, $constr_values_ref) = @{$type_spec_ref};

return SCM_select( $this_default, $constr_values_ref->[0]);  # $new_root_path
}




sub validate_user()
{
if (0)
{



ENV_say( 1, "==========================================================",
"== GBS is consultancy-ware",
"== The creation of a new Root/System is restricted by the",
"== licence agreement to consultants appointed by",
"== Randy Marques Consultancy",
"==========================================================");




my $digest = 'MaGP3Dn/Ix.uY';
my $ok = ASK_password( 'Enter GBS Consultancy password', $digest);
ENV_sig( EE => 'Invalid Password')
if (!$ok);
}
}




sub main_new_other_system($)
{
my ($spec_new_root_path) = @_;		# perl_format
my $new_root_path = $spec_new_root_path;

ENV_say( 1, "Adjust existing Root for this Platform ($spec_new_root_path)");


ENV_chdir( $new_root_path);





ENV_say( 1, "Platform...");
my $system_name = SYSTEM_get( $new_root_path, 'system_name');
my $new_scms = SYSTEM_get_os( $new_root_path, '.', 'scms');
my $new_scms_repository = SYSTEM_get_os( $new_root_path, '.', 'scms_repository');
my $new_scms_data = SYSTEM_get( $new_root_path, 'scms_data');
ENV_say( 1, "Current SCMS: " . SCM_join_info( [ $new_scms, $new_scms_repository, $new_scms_data ]));




my $must_write_repos = 0;
if ($new_scms_repository eq '')
{
my @repos;
foreach my $osname (SYSTEM_get_osnames( $new_root_path, 'scms_repository'))
{
my $repos = SYSTEM_get_os( $new_root_path, $osname, 'scms_repository');
push @repos, $repos
if ($repos);
}
if (@repos)
{
foreach my $repos (@repos)
{
ENV_say( 1, "SCM REPOSITORY: $repos");
if (ASK_YNQ( 'OK?', 'Y', 1) eq 'Y')
{
$new_scms_repository = $repos;
last;
}
}
$new_scms_repository = ASK_text( 'Enter Repository', '', 0)
if ($new_scms_repository eq '');
} else
{
$new_scms_repository = '';
}
$must_write_repos = 1;
}




my @scms_items = ($new_scms, $new_scms_repository, $new_scms_data);
SCM_preset( $new_root_path, [ @scms_items ]);
GBSSCM_setenv( [ @scms_items ]);
GBSSCM_connect();




if ($must_write_repos)
{
SYSTEM_put_os( $new_root_path, '.', scms_repository => $new_scms_repository);
SYSTEM_write();	   # Includes backup and SCM_checkout
}




my @new_files;
push @new_files, FCREATE_switch( 'switch.gbs', $new_root_path, $system_name);
SCM_add_txt_files( \@new_files, 0, 0);	    		# $prevalidated, $verbose
ENV_say( 1, "Root '$new_root_path' adjusted for this Platform");


return $new_root_path;
}




sub main_new_subsys($)
{
my ($spec_new_subsys) = @_;
my $new_subsys;

ENV_say( 1, "New SubSys: $spec_new_subsys");

VALIDATE_root();
VALIDATE_administrator();




my $gbs_dev_path = "$GBS::ROOT_PATH/dev";
my @subsystems = GBSGLO_subsystems();
ENV_say( 1, "Available SubSystems:");
if (@subsystems)
{
ENV_say( 0, FORMAT_indent( 0, 2, [ 0, "@subsystems" ]));
} else
{
ENV_say( 0, '  None');
}

$new_subsys = ASK_dir( "Enter New SubSystem-name", $spec_new_subsys, 0, 0, $gbs_dev_path,   # $length, $must_exist, $path
[ \&check_subsys, [ @subsystems ] ]);
$spec_new_subsys = '';

if ($new_subsys ne "")
{




my ($subsys_type, $import_dir, $export_dir, $res_sub_dir,
$builds_ref, $audits_ref, $extra_dirs) = ask_new_subsys_data( $new_subsys);

ENV_say( 1, "Creating SubSystem '$new_subsys'...");
GBSSCM_preset( 0);
GBSSCM_connect();

my $gbs_subsys_path = "$gbs_dev_path/$new_subsys";
ENV_mkdir( $gbs_subsys_path);





my $ssprop_filespec = SSPROP_set_type( $GBS::ROOT_PATH, $new_subsys, $subsys_type);




my @new_dirs;
push @new_dirs, $gbs_subsys_path;	    # already created
push @new_dirs, DIRSTRUCT_mandatory_dirs( $gbs_subsys_path, 'SUBSYS');
push @new_dirs, map { "$gbs_subsys_path/build/$_" } @{$builds_ref};
push @new_dirs, map { "$gbs_subsys_path/audit/$_" } @{$audits_ref};
push @new_dirs, "$gbs_subsys_path/import"
if ($import_dir);
push @new_dirs, "$gbs_subsys_path/export"
if ($export_dir);
push @new_dirs, "$GBS::ROOT_PATH/res/$new_subsys"
if ($res_sub_dir);

if ($subsys_type ne 'GBS')
{
push @new_dirs, "$gbs_subsys_path/app";
if ($subsys_type eq 'make')
{
if ($extra_dirs)
{
push @new_dirs, map { "$gbs_subsys_path/app/$_" } qw( src inc bld );
push @new_dirs, map { "$gbs_subsys_path/app/bld/$_" } @{$builds_ref};
}
}
}
SCM_add_dirs( \@new_dirs, \&DIRSTRUCT_get_ignore_spec, 0, 0);	    # $pre_validated, $verbose




my @new_files;
push @new_files, $ssprop_filespec;	    # already created
if ($subsys_type ne 'GBS')
{




push @new_files, FCREATE_subsys_script( 'gbssub', $GBS::ROOT_PATH, $new_subsys, $subsys_type);
if ($subsys_type eq 'make')
{
push @new_files, FCREATE_makefile( $GBS::ROOT_PATH, $new_subsys);
}
}
SCM_add_txt_files( \@new_files, 0, 0);			# $prevalidated, $verbose




{
my @gbs_all_subsystems = LIST_unique( [ sort (@GBS::ALL_SUBSYSTEMS, $new_subsys) ]);
push @SETENV_PAIR_REFS, [ GBS_ALL_SUBSYSTEMS => \@gbs_all_subsystems];

}

ENV_say( 1, "SubSystem '$new_subsys' created");

} else
{
ENV_sig( W => "No new SubSystem created");
}

return $new_subsys;
}




sub ask_new_subsys_data($)
{
my ($new_subsys,
) = @_;
my ($subsys_type, $import_dir, $export_dir, $res_sub_dir, @builds, @audits, $extra_dirs);

{
my @subsys_type_refs = SSPROP_get_all_types();

my $subsys_types = join( ',', map { $_->[1] } @subsys_type_refs);	# name
my $subsys_type_help = join( ', ', map { $_->[0] } @subsys_type_refs);	# nice_name
my $default_builds = (@GBS::ALL_BUILDS == 1) ? $GBS::ALL_BUILDS[0] : '*';
my $default_audits = (@GBS::ALL_AUDITS == 1) ? $GBS::ALL_AUDITS[0] : '';
my @mnem_refs;


push @mnem_refs, [ \$subsys_type, 'Type', 'SubSystem Type',
"ssms$subsys_types", 'GBS', $subsys_type_help, 1, \&post_func_subsys ];
push @mnem_refs, [ \$import_dir, 'Import-dir', 'Import directory required?',
'bsmn', 0, undef, 1, undef];
push @mnem_refs, [ \$export_dir, 'Export-dir', 'Export directory required?',
'bsmn', 1, undef, 1, undef];
push @mnem_refs, [ \$extra_dirs, 'Res-Sub-dir', 'Res SubSystem directory required?',
'bsmn', (@GBS::ALL_SUBSYSTEMS) ? 1 : 0, undef, 1, undef];
push @mnem_refs, [ \@builds, 'Builds', "Builds for SubSys '$new_subsys'",
"sams$GBS::ALL_BUILDS", $default_builds, undef, @GBS::ALL_BUILDS ? 1 : 0, undef ];
push @mnem_refs, [ \@audits, 'Audits', "Audits for SubSys '$new_subsys'",
"saos$GBS::ALL_AUDITS", $default_audits, undef, @GBS::ALL_AUDITS ? 1 : 0, undef ];
push @mnem_refs, [ \$extra_dirs, 'App-Sub-dirs', 'Create App Sub directories (app/src, app/inc, app/bld/<build>, ...)?',
'bsmn', 1, undef, 1, undef];
ASKFORM_new( 'New SubSystem', 0, \@mnem_refs, undef, undef, undef);
}

return ($subsys_type, $import_dir, $export_dir, $res_sub_dir, [ @builds ], [ @audits ], $extra_dirs);
}




sub post_func_subsys($$)
{
my ($mnem_hash_ref,
$mnem,
) = @_;

if ($mnem eq 'Type')
{
my $type_value = ${$mnem_hash_ref->{Type}->[0]};	# $mnem_value_ref
if ($type_value eq 'GBS')
{
$mnem_hash_ref->{'Import-dir'}->[6] = 1;		# $enabled
$mnem_hash_ref->{'App-Sub-dirs'}->[6] = 0;		# $enabled
} else
{
$mnem_hash_ref->{'Import-dir'}->[6] = 0;		# $enabled
$mnem_hash_ref->{'App-Sub-dirs'}->[6] = 1;		# $enabled
}
}
}




sub check_subsys($$$)
{
my ($values_ref,
$default_ref,
$existing_subsys_ref,
) = @_;
my $error_txt = '';

my $subsys = $values_ref->[0];
if (grep( $subsys eq $_, @{$existing_subsys_ref}))
{
$error_txt = "SubSystem '$subsys' already exists";
}

return $error_txt;
}




sub main_new_component($)
{
my ($spec_new_component) = @_;
my $new_component;

ENV_say( 1, "New Component: $spec_new_component");

VALIDATE_root();
VALIDATE_subsys_full_gbs();
VALIDATE_administrator();

my $gbs_subsys_path = "$GBS::ROOT_PATH/dev/$GBS::SUBSYS";
my $gbs_comp_path = "$gbs_subsys_path/comp";

my @current_comps = GBSGLO_components( $GBS::SUBSYS);
ENV_say( 1, "Available Components:");
if (@current_comps)
{
ENV_say( 0, FORMAT_indent( 0, 2, [ 0, "@current_comps" ]));
} else
{
ENV_say( 0, '  None');
}




$new_component = ASK_dir( "Enter New Component-name", $spec_new_component, 0, 0, $gbs_comp_path,   # $length, $must_exist, $path
[ \&check_component, [ @current_comps ] ]);
$spec_new_component = '';

if ($new_component ne "")
{



my ($builds_ref, $scope_comps_ref, $audits_ref) = ask_new_component_data( $new_component);

ENV_say( 1, "Creating Component '$new_component'...");
GBSSCM_preset( 0);
GBSSCM_connect();




my $component_path = "$gbs_comp_path/$new_component";
my @new_dirs;
push @new_dirs, $component_path;
push @new_dirs, DIRSTRUCT_mandatory_dirs( $component_path, 'COMPONENT');
push @new_dirs, map { "$component_path/bld/$_" } @{$builds_ref};
push @new_dirs, map { "$component_path/aud/$_" } @{$audits_ref};
foreach my $build (@{$builds_ref})
{
push @new_dirs, map { "$component_path/aud/$_/$build" } @{$audits_ref};
}
SCM_add_dirs( \@new_dirs, \&DIRSTRUCT_get_ignore_spec, 0, 0);	    # $pre_validated, $verbose




my $scope_file = FCREATE_scope( 'scope.gbs', $GBS::ROOT_PATH, $GBS::SUBSYS,
$new_component, $scope_comps_ref);
SCM_add_txt_files( $scope_file, 0, 0);		# $prevalidated, $verbose




{
my @gbs_all_components = LIST_unique( [ sort @GBS::ALL_COMPONENTS, $new_component ]);
push @SETENV_PAIR_REFS, [ GBS_ALL_COMPONENTS => \@gbs_all_components];

}

ENV_say( 1, "Component '$new_component' created");
} else
{
ENV_sig( W => "No new Component created");
$new_component = "";
}

return $new_component;
}




sub ask_new_component_data($)
{
my ($new_component,
) = @_;
my (@builds, @scope_comps, @audits);

my @all_builds = GBSGLO_subsystem_builds( $GBS::SUBSYS);
my @all_audits = GBSGLO_subsystem_audits( $GBS::SUBSYS);
my $default_builds = (@all_builds == 1) ? $all_builds[0] : '*';
my $default_audits = (@all_audits == 1) ? $all_audits[0] : '';

my @mnem_refs;


push @mnem_refs, [ \@scope_comps, 'Scope', "Components in scope for Component '$new_component'",
"saos$GBS::ALL_COMPONENTS", '', undef, @GBS::ALL_COMPONENTS ? 1 : 0, undef ];
push @mnem_refs, [ \@builds, 'Builds', "Builds for Component '$new_component'",
"samS@all_builds", $default_builds, undef, @all_builds ? 1 : 0, undef ];
push @mnem_refs, [ \@audits, 'Audits', "Audits for Component '$new_component'",
"saoS@all_audits", $default_audits, undef, @all_audits ? 1 : 0, undef ];
ASKFORM_new( 'New Component', 0, \@mnem_refs, undef, undef, undef);

return ([ @builds ], [ @scope_comps ], [ @audits ]);
}




sub check_component($$$)
{
my ($values_ref,
$default_ref,
$existing_comps_ref,
) = @_;
my $error_txt = '';

my $comp = $values_ref->[0];
if (grep( $comp eq $_, @{$existing_comps_ref}))
{
$error_txt = "Component '$comp' already exists";
} elsif (grep( $comp eq $_, qw( ALL RES EXPORT)))
{
$error_txt = "'ALL', 'RES' and 'EXPORT' are reserved names";
} else
{
;
}

return $error_txt;
}




sub main_new_build($)
{
my ($spec_new_build) = @_;	    # '' == ASK
my $new_build;

VALIDATE_root();
VALIDATE_administrator();

GBSSCM_preset( 0);

$new_build = PLUGINMAINT_new_build( $spec_new_build);
if ($new_build ne '')
{
push @SETENV_PAIR_REFS, [ GBS_ALL_BUILDS => [ SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '*', 'builds') ] ],
[ GBS_BUILDS     => [ SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '.', 'builds') ] ];
}

return $new_build;
}




sub main_remove_build($)
{
my ($default_build) = @_;
my $build_to_remove;

VALIDATE_root();
VALIDATE_administrator();

GBSSCM_preset( 0);

$build_to_remove = PLUGINMAINT_remove_build( $default_build);
if ($build_to_remove ne '')
{
push @SETENV_PAIR_REFS, [ GBS_ALL_BUILDS => [ SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '*', 'builds') ] ],
[ GBS_BUILDS     => [ SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '.', 'builds') ] ];
}

return $build_to_remove;
}




sub main_new_audit($)
{
my ($spec_new_audit) = @_;	    # '' == ASK
my $new_audit;

VALIDATE_root();
VALIDATE_administrator();

GBSSCM_preset( 0);

$new_audit = PLUGINMAINT_new_audit( $spec_new_audit);
if ($new_audit ne '')
{
push @SETENV_PAIR_REFS, [ GBS_ALL_AUDITS => [ SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '*', 'audits') ] ],
[ GBS_AUDITS     => [ SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '.', 'audits') ] ];
}

return $new_audit;
}




sub main_remove_audit($)
{
my ($default_audit) = @_;
my $audit_to_remove;

VALIDATE_root();
VALIDATE_administrator();

GBSSCM_preset( 0);

$audit_to_remove = PLUGINMAINT_remove_audit( $default_audit);
if ($audit_to_remove ne '')
{
push @SETENV_PAIR_REFS, [ GBS_ALL_AUDITS => [ SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '*', 'audits') ] ],
[ GBS_AUDITS     => [ SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '.', 'audits') ] ];
}

return $audit_to_remove;
}




sub main_new_tool($)
{
my ($spec_new_tool) = @_;	    # '' == ASK
my $new_tool;

VALIDATE_root();
VALIDATE_administrator();

GBSSCM_preset( 0);

$new_tool = PLUGINMAINT_new_tool( $spec_new_tool);
if ($new_tool ne '')
{
push @SETENV_PAIR_REFS, [ GBS_ALL_TOOLS => [ SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '*', 'tools') ] ],
[ GBS_TOOLS     => [ SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '.', 'tools') ] ];
}

return $new_tool;
}




sub main_remove_tool($)
{
my ($default_tool) = @_;
my $tool_to_remove;

VALIDATE_root();
VALIDATE_administrator();

GBSSCM_preset( 0);

$tool_to_remove = PLUGINMAINT_remove_tool( $default_tool);
if ($tool_to_remove ne '')
{
push @SETENV_PAIR_REFS, [ GBS_ALL_TOOLS => [ SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '*', 'tools') ] ],
[ GBS_TOOLS     => [ SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '.', 'tools') ] ];
}


return $tool_to_remove;
}




sub select_via_menu()
{
my @menu_refs = (
[ 'Exit',					    undef ],
[ 'Create a new Root/System',		    \&main_new_system ],
[ 'Adjust existing Root for this Platform', \&main_new_other_system ],
);
push @menu_refs,
[ 'Create a new SubSys',		    \&main_new_subsys ]
if ($GBS::ROOT_PATH ne '');
push @menu_refs,
[ 'Create a new Component',		    \&main_new_component ]
if ($GBS::SUBSYS ne '' && GBSGLO_subsystem_is_full_gbs( $GBS::SUBSYS));
push @menu_refs,
[ 'Create a new Build',		    \&main_new_build ]
if ($GBS::ROOT_PATH ne '');
push @menu_refs,
[ 'Remove a Build',			    \&main_remove_build ]
if ($GBS::ROOT_PATH ne '');
push @menu_refs,
[ 'Create a new Audit',			    \&main_new_audit ]
if ($GBS::ROOT_PATH ne '');
push @menu_refs,
[ 'Remove an Audit',			    \&main_remove_audit ]
if ($GBS::ROOT_PATH ne '');
push @menu_refs,
[ 'Create a new Tool',			    \&main_new_tool ]
if ($GBS::ROOT_PATH ne '');
push @menu_refs,
[ 'Remove a Tool',			    \&main_remove_tool ]
if ($GBS::ROOT_PATH ne '');

my $function = ASK_value_from_menu( 'Select Function', 0, undef, [ @menu_refs ]);
if (defined $function)
{
$RESULT = &$function( '');
}
}


