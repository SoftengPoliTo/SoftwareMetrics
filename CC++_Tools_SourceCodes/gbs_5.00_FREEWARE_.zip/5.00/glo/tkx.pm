#=================================================
#
#   tkx.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================






package glo::tkx;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
TKX_split
TKX_join
TKX_update
TKX_bell
TKX_geometry
TKX_winfo_pointerxy
TKX_wm_state
TKX_screen_size
TKX_tooltip
TKX_new_button
TKX_new_checkbutton
TKX_new_combobox
TKX_new_entry
TKX_new_label
TKX_new_radiobutton
TKX_wait_variable
TKX_wait_window_visibility
TKX_wait_window_destroyed
);
}




eval { use Tkx; };
Tkx::package_require('tooltip');
Tkx::namespace_import("::tooltip::tooltip");

use glo::env;




sub TKX_split($);
sub TKX_join(@);
sub TKX_update(;$);
sub TKX_bell();
sub TKX_geometry($;@);
sub TKX_wm_state($;$);
sub TKX_screen_size($);
sub TKX_winfo_pointerxy($);
sub TKX_tooltip($$@);
sub TKX_new_button($$$@);
sub TKX_new_checkbutton($$$@);
sub TKX_new_combobox($$$$@);
sub TKX_new_entry($$$@);
sub TKX_new_label($$@);
sub TKX_new_radiobutton($$$$$@);
sub TKX_wait_variable($);
sub TKX_wait_window_visibility($);
sub TKX_wait_window_destroyed($);

sub do_command_checkbutton($$$);
sub do_validate_entry($$$$);
















{
Tkx::ttk__style_configure( 'error.TCheckbutton' => -background => 'red',
-indicator => 'red');
Tkx::ttk__style_configure( 'error.TEntry'	    => -foreground => 'red');
}




BEGIN
{
ENV_is_gui( 1);
$TKX::MW = Tkx::widget->new( '.');
}






sub TKX_split($)
{
return Tkx::SplitList( $_->[0]);
}






sub TKX_join(@)
{
return Tkx::list( @_);
}





sub TKX_update(;$)
{
my ($option,    # Optional. Default = ''. Anything else is considered 'idletasks'
) = @_;

if (defined $option && $option ne '')
{
Tkx::update( 'idletasks');
} else
{
Tkx::update();
}
}




sub TKX_bell()
{
Tkx::bell();
}




sub TKX_geometry($;@)
{
my ($window,	    # Top Level Window
$new_width,	    # Optional
$new_height,	    # Optional
$new_x,		    # Optional
$new_y,		    # Optional
) = @_;
my ($width, $height, $x, $y);
my $old_geo;

$old_geo = $window->g_wm_geometry()
if (defined wantarray);

if (@_ > 1)
{



my $new_geo = '';
$new_geo = "${new_width}x$new_height"
if (defined $new_width);
if (defined $new_x)
{
$new_x = "+$new_x"
if ($new_x >= 0);
$new_y = "+$new_y"
if ($new_y >= 0);
$new_geo .= "$new_x$new_y";
}

$window->g_wm_geometry( $new_geo);
}

if (defined wantarray)
{




if (wantarray)
{
($width, $height, my $x_offset, $x, my $y_offset, $y) = $old_geo =~ /^(\d+)x(\d+)([+-]*)(\d+)([+-]*)(\d+)$/;

return ($width, $height, $x, $y);
} else
{
return $old_geo;
}
}
}




sub TKX_wm_state($;$)
{
my ($window,	    # Top Level Window
$new_state,	    # normal, iconic, withdrawn, or zoomed

) = @_;
my $old_state;

$old_state = $window->g_wm_state()
if (defined wantarray);

if (defined $new_state)
{




$window->g_wm_state( $new_state);
}

if (defined wantarray)
{


return $old_state;
}
}




sub TKX_screen_size($)
{
my ($window,	    # Top Level Window
) = @_;


if (wantarray)
{
return ( $window->g_winfo_screenwidth(), $window->g_winfo_screenheight() );
} else
{
return $window->g_winfo_screenwidth();
}
}




sub TKX_winfo_pointerxy($)
{
my ($window,
) = @_;
my ($x, $y);

my $xy = $window->g_winfo_pointerxy();
$xy =~ s/\+//g;
($x, $y) = split( ' ', $xy);

return ($x, $y);
}








sub TKX_tooltip($$@)
{
my ($widget,
$text,
@args		    # args for tkx function
) = @_;

Tkx::tooltip( $widget, $text, @args);
}

























sub TKX_new_button($$$@)
{
my ($parent,
$text_or_ref,
$command_func_or_ref,
@args		    # args for new_ttk__button function
) = @_;
my $button_widget;

my $text_or_variable = (ref $text_or_ref) ? '-textvariable' : '-text';
$button_widget = $parent->new_ttk__button( $text_or_variable => $text_or_ref, -command => $command_func_or_ref, @args);

return $button_widget;
}














sub TKX_new_checkbutton($$$@)
{
my ($parent,
$variable_ref,
$command_func_or_ref,	    # may be undef
@args			    # args for new_ttk__checkbutton function
) = @_;
my $checkbutton_widget;

$checkbutton_widget = $parent->new_ttk__checkbutton( -variable => $variable_ref, @args);
if (defined $command_func_or_ref)
{
my $func_ref = [ \&do_command_checkbutton, $checkbutton_widget, $variable_ref, $command_func_or_ref ];
$checkbutton_widget->configure( -command => $func_ref);
}

return $checkbutton_widget;
}




sub do_command_checkbutton($$$)
{
my ($this_widget,
$variable_ref,
$command_func_or_ref,
) = @_;
my $is_ok = 1;





my ($error_text, $newer_value);

if (defined $command_func_or_ref)
{
my $new_value = $$variable_ref;
($is_ok, $error_text) = ENV_call( $command_func_or_ref, [ $this_widget, $new_value ]);
if (!$is_ok)
{
Tkx::bell();
if (defined $error_text)
{
ENV_say( 1, 'Validation error', $error_text)
if ($error_text ne '');
}

}


if ($is_ok)
{
$this_widget->configure( -style => 'TCheckbutton');
} else
{
$this_widget->configure( -style => 'error.TCheckbutton');
}
}

return $is_ok;
}
















sub TKX_new_combobox($$$$@)
{
my ($parent,
$text_ref,
$values_ref,		# may be undef
$command_func_or_ref,	# may be undef
@args			# args for tkx function
) = @_;
my $combobox_widget;

my @this_args;
push @this_args, -values => $values_ref
if (defined $values_ref);
$combobox_widget = $parent->new_ttk__combobox( -textvariable => $text_ref, @this_args, @args);

$combobox_widget->g_bind( '<<ComboboxSelected>>', [ $command_func_or_ref, $combobox_widget ])
if (defined $command_func_or_ref);

return $combobox_widget;
}



















sub TKX_new_entry($$$@)
{
my ($parent,
$text_ref,
$validate_func_or_ref,	# undef=OK ($is_ok, $error_text, $newer_value) = $validate_func(

@args			# args for tkx function
) = @_;
my $entry_widget;


{
my @entry_args;
push @entry_args, ('-textvariable' => $text_ref)
if (defined $text_ref);
$entry_widget = $parent->new_ttk__entry( @entry_args, @args);
}

if (defined $validate_func_or_ref)
{
my $func_ref = [ \&do_validate_entry, Tkx::Ev( '%P', '%V'), $entry_widget, $validate_func_or_ref ];
$entry_widget->configure( -validate => 'all',		# was focusout
-validatecommand => $func_ref);
}

return $entry_widget;
}




sub do_validate_entry($$$$)
{
my ($new_value,	    # %P
$validate_action,   # %V    key, focusin, focusout, or forced
$this_widget,
$validate_func_or_ref,
) = @_;
my $is_ok = 1;







if ($validate_action eq 'key' || $validate_action eq 'focusout')
{
if (defined $validate_func_or_ref)
{
my ($error_text, $newer_value);
($is_ok, $error_text, $newer_value) = ENV_call( $validate_func_or_ref, [ $this_widget, $new_value, $validate_action ] );
if (!$is_ok)
{
Tkx::bell();
if (defined $error_text)
{
ENV_say( 1, 'Validation error', $error_text)
if ($error_text ne '');
$newer_value = $new_value
if (defined $newer_value && $newer_value eq '');
}
}
my $old_value = $this_widget->get();

if (defined $newer_value && $newer_value ne $old_value)
{
$this_widget->delete( 0, 'end');
$this_widget->insert( 0, $newer_value);
$this_widget->g_focus();
}

if ($is_ok)
{
$this_widget->configure( -style => 'TEntry');
} else
{
$this_widget->configure( -style => 'error.TEntry');
}
}
} else  # $validate_action == focusout or forced
{

}

return $is_ok;
}























sub TKX_new_label($$@)
{
my ($parent,
$text_or_ref,
@args			    # args for tkx function
) = @_;
my $label_widget;

my $text_or_variable = (ref $text_or_ref) ? '-textvariable' : '-text';
$label_widget = $parent->new_ttk__label( $text_or_variable => $text_or_ref, @args);

return $label_widget;
}














sub TKX_new_radiobutton($$$$$@)
{
my ($parent,
$text,
$variable_ref,
$value,
$command_func_or_ref,	    # may be undef
@args			    # args for tkx function
) = @_;
my $radiobutton_widget;

unshift @args, (-command => $command_func_or_ref)
if (defined $command_func_or_ref);
$radiobutton_widget = $parent->new_ttk__radiobutton( -text => $text, -variable => $variable_ref,
-value => $value, @args);

return $radiobutton_widget;
}




sub TKX_wait_variable($)
{
my ($glob_var_name,
) = @_;

Tkx::__tkwait( variable => $glob_var_name);
}




sub TKX_wait_window_visibility($)
{
my ($widget,
) = @_;

Tkx::__tkwait( visibility => $widget);
}





sub TKX_wait_window_destroyed($)
{
my ($widget,
) = @_;

Tkx::__tkwait( window => $widget);
}

1;

