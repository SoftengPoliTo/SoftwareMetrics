#=================================================
#
#   tkxdirtree.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::tkxdirtree;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
TKXDIRTREE_new
TKXDIRTREE_show_tree
TKXDIRTREE_show_flat
TKXDIRTREE_clear
TKXDIRTREE_get_selection
TKXDIRTREE_clear_selection
);
}




use Tkx;

use glo::env;
use glo::slurp;
use glo::scm;
use glo::tkx;
use glo::tkxglo;
use glo::tkxevent;
use glo::tkxfont;





sub TKXDIRTREE_new($$$@);
sub TKXDIRTREE_show_tree($$$);
sub TKXDIRTREE_show_flat($$$$$);
sub TKXDIRTREE_clear($);
sub TKXDIRTREE_get_selection($);
sub TKXDIRTREE_clear_selection($);









sub TKXDIRTREE_new($$$@)
{
my ($parent,
$select_mode,	    # 0 = None, 1 == single, 2 = multiple
$select_callback,
@treeview_args
) = @_;
my ($dtf, $dt);	    # dirtree_frame, dirtree

$dtf = $parent->new_ttk__frame( -relief => 'groove', -borderwidth => 3);
$dtf->g_grid_columnconfigure( 0, -weight => 1);
$dtf->g_grid_rowconfigure( 0, -weight => 1);

my $selectmode = qw( none browse extended)[$select_mode];
$dt = $dtf->new_ttk__treeview( -selectmode => $selectmode, @treeview_args);
$dt->g_grid( -column => 0, -row => 0, -sticky => 'news');

my $vs = $dtf->new_ttk__scrollbar( -orient => 'vertical', -command => [ $dt, 'yview']);
$vs->g_grid( -column => 1, -row => 0, -sticky => 'ns');
$dt->configure( -yscrollcommand => [ $vs, 'set' ]);

my $hs = $dtf->new_ttk__scrollbar( -orient => 'horizontal', -command => [ $dt, 'xview']);
$hs->g_grid( -column => 0, -row => 1, -sticky => 'we');
$dt->configure( -xscrollcommand => [ $hs, 'set' ]);

TKXEVENT_bind_treeview_select( $dt, $select_callback)
if (defined $select_callback);
TKXEVENT_bind_key_escape( $dt, sub { $dt->selection( 'set', Tkx::list()) });

return ($dtf, $dt);
}




sub TKXDIRTREE_show_tree($$$)
{
my ($dt,
$path,
$tag_refs_ref,  # ( [ $tag, $regex, $foreground, $background, @other_options ], ... )
) = @_;








$dt->tag_configure( 'dir',		-font => 'My_stdout_bold',  -foreground => 'blue');
$dt->tag_configure( 'file',		-font => 'My_stdout',	    -foreground => 'dark green');
$dt->tag_configure( 'hidden-file',	-font => 'My_stdout',	    -foreground => 'green');
$dt->tag_configure( 'checked_in',	-background => 'pale green');
$dt->tag_configure( 'checked_out',	-background => 'wheat');
foreach my $ref (@{$tag_refs_ref})
{
my ($tag, $regex, $foreground, $background, @other_options) = @{$ref};
my @options;
push @options, (-foreground => $foreground)
if (defined $foreground);
push @options, (-background => $background)
if (defined $background);
push @options, @other_options
if (@other_options);
$dt->tag_configure( $tag, -font => 'My_stdout', @options);
}




TKXGLO_cursor_push( 'watch');
$dt->heading( '#0', -text => $path, -anchor => 'w');


TKXDIRTREE_clear( $dt);
TKX_update();	# Show the cursor and the heading


TKX_update();	# Show the cursor and the heading





my @entry_specs = map { $_->[1] } SLURP_dir_tree_path( $path, 0);

if (@entry_specs > 50)
{
ENV_whisper( 1, "Caching states...");
SCM_cache_states( 0);	    # 0 == do not force reread
}
my @entry_refs;

foreach my $ref (SCM_get_states( \@entry_specs, 0))
{
my ($entryspec, $state) = @{$ref};
my $is_dir = (-d $entryspec) ? 1 : 0;
my $dir_entry = substr( $entryspec, length( $path) + 1);
my ($path, $entry) = $dir_entry =~ m!(.+)/(.+)!;
($path, $entry) = ( '', $dir_entry)
if (!defined $entry);
push @entry_refs, [ $is_dir, $dir_entry, $path, $entry, $entryspec, $state ];
}

TKX_update();	# Show the cursor and the heading




foreach my $ref (@entry_refs)
{
my ($is_dir, $dir_entry, $path, $entry, $entryspec, $state) = @{$ref};


my @tags;
foreach my $ref (@{$tag_refs_ref})
{
my ($tag, $regex) = @{$ref};
if ($entryspec =~ $regex)
{
push @tags, $tag;
last;
}
}
my $state_tag = ($state == 0) ? 'checked_in' : ($state == 1) ? 'checked_out' : undef;

if ($is_dir)
{
push @tags, 'dir'
if (@tags == 0);
push @tags, $state_tag
if (defined $state_tag);
$dt->insert( $path, 'end', -id => $dir_entry, -text => $entry, -values => [ $entryspec ], -tags => [ @tags ]);
} else
{
if (ENV_hide_file( $entryspec, undef))
{
@tags = 'hidden-file';
} else
{
push @tags, 'file'
if (@tags == 0);
}
push @tags, $state_tag
if (defined $state_tag);
$dt->insert( $path, 'end', -text => $entry, -values => [ $entryspec ], -tags => [ @tags ]);
}
}




TKXGLO_cursor_pop();



}




sub TKXDIRTREE_show_flat($$$$$)
{
my ($dt,
$formats_ref,	# L, R, C
$heads_ref,	# [ <head>, ... ]
$row_refs_ref,
$default_index,	# -1 == none
) = @_;

$row_refs_ref = [ [] ] if (!defined $row_refs_ref || !defined $row_refs_ref->[0]);




my @items;
my @item_refs;
my $col = 0;
foreach my $head (@{$heads_ref})
{
push @items, $head;
my $format = shift @{$formats_ref};
my $anchor = ($format eq 'R') ? 'e' : ($format eq 'C') ? 'format' : 'w';

my $max_length = length $head;
foreach my $row_ref (@{$row_refs_ref})
{
my $value = $row_ref->[$col];
$max_length = length $value
if (length $value > $max_length);
}
push @item_refs, [ $head, $head, $anchor, $max_length ];
$col++;
}





shift @items;   # First is item
$dt->configure( -columns => [ @items ]);
$item_refs[0]->[0] = '#0';		# $column




foreach my $ref (@item_refs)
{
my ($column, $head, $anchor, $max_length) = @{$ref};
my $minwidth = TKXFONT_measure( 'TkDefaultFont', "$head ");
my $width = TKXFONT_measure( 'My_stdout', 'x' x ++$max_length);
$width = ($width > $minwidth) ? $width : $minwidth;
$dt->column( $column, -minwidth => $minwidth, -width => $width, -anchor => $anchor);
$dt->heading( $column, -text => $head, -anchor => $anchor);
}




my $default_item_id;
my $index = 0;
foreach my $row_ref (@{$row_refs_ref})
{
my ($item, @values) = @{$row_ref};
my $item_id = $dt->insert( '', 'end', -text => $item, -values => [ @values ], -tags => [ 'row' ]);
$default_item_id = $item_id
if ($index == $default_index);
$index++;
}




if (defined $default_item_id)
{
$dt->selection( set => $default_item_id);
$dt->see( $default_item_id);
}




$dt->tag_configure( 'row', -font => 'My_stdout');
}




sub TKXDIRTREE_clear($)
{
my ($dt,
) = @_;

$dt->delete( $dt->children( ''));
}




sub TKXDIRTREE_get_selection($)
{
my ($dt,
) = @_;
my @selection_or_refs;	# [ $item, $itemspec ], ...

foreach my $sel_id (Tkx::SplitList( $dt->selection()))
{


my $item = $dt->item( $sel_id, '-text');
my @values = Tkx::SplitList( $dt->item( $sel_id, '-values'));
if (@values)
{

push @selection_or_refs, [ $item, @values ];
} else
{
push @selection_or_refs, $item;
}
}

return (wantarray) ? @selection_or_refs : $selection_or_refs[0];
}




sub TKXDIRTREE_clear_selection($)
{
my ($dt,
) = @_;

$dt->selection( 'set', Tkx::list());
}

1;

