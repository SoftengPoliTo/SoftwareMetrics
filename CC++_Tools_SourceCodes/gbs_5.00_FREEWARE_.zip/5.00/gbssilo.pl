#=================================================
#
#   gbssilo.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSSILO @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::genopt;
use glo::html;
use glo::spit;
use glo::time;
use mod::gbsenv;
use mod::gbsres;
use mod::gbsglo;
use mod::gbssilo;
use mod::gbssyssum;
use mod::gbshtml;




sub create_summaries();
sub sys_sum_file($$);
sub audit_sum_file();
sub create_build_audits_overview();




my $NOW_DATETIME = TIME_time2num();	    # YYYY-MM-DD HH:MM:SS
my $TODAY = substr( $NOW_DATETIME, 0, 10);  # YYYY-MM-DD






my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ 'ci',     'create_index',	    'bso',   1, "Create the HTML Index" ],
[ 'cs',     'create_summaries',	    'bso',   1, "Create the HTML Summaries" ],
[ 'vi',     'view_index',	    'bso',   1, "View index in HTML browser" ],
[ 'noc',    'no_create',	    'bso',   0, "No HTML Creation (forces --ci and --cs to '-')" ],
);
my @genconflicts = (


[ [ noc  => 1 ], '=' => 'ci', '=' => 'cs' ],
);
GENOPT_set_optdefs( 'gbssilo', \@genopts,
'Generate silo index and show in HTML browser',
undef);
GENOPT_set_conflicts( \@genconflicts);
GENOPT_parse();
}
my $CREATE_SUMMARIES = GENOPT_get( 'create_summaries');
my $CREATE_INDEX = GENOPT_get( 'create_index');
my $VIEW_INDEX = GENOPT_get( 'view_index');
my $NO_CREATE = GENOPT_get( 'no_create');

if ($NO_CREATE)
{
$CREATE_SUMMARIES = 0;
$CREATE_INDEX = 0;
}

{



GBSHTML_init( 'application');	    # Use Silo




if ($CREATE_SUMMARIES)
{
create_summaries();
create_build_audits_overview()
}




GBSSILO_create_index()
if ($CREATE_INDEX);




GBSSILO_view_index()
if ($VIEW_INDEX);
}




ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
}




sub create_summaries()
{



my @build_line_refs;
my @audit_line_refs;
my @tool_line_refs;
foreach my $sum_line_ref (GBSSYSSUM_read())
{



my $jobname = $sum_line_ref->[0];
if ($jobname eq 'gbssysaudit')
{
push @audit_line_refs, $sum_line_ref;
} elsif ($jobname eq 'gbssystool')
{
push @tool_line_refs, $sum_line_ref;
} else	# gbssysbuild and gbssysmake
{
push @build_line_refs, $sum_line_ref;
}
}
if (@build_line_refs)
{
sys_sum_file( gbssysbuild => \@build_line_refs)
}
if (@audit_line_refs)
{
sys_sum_file( gbssysaudit => \@audit_line_refs)
}
if (@tool_line_refs)
{
sys_sum_file( gbssystool => \@tool_line_refs)
}




audit_sum_file();
}




sub sys_sum_file($$)
{
my ($name,			# 'gbssysaudit', 'gbssysbuild', 'gbssystool'
$line_refs_ref,



) = @_;

ENV_whisper( 1, "$name: " . @{$line_refs_ref} . ' line(s)');
my $is_audit = ($name eq 'gbssysaudit') ? 1 : 0;
my $is_tool = ($name eq 'gbssystool') ? 1 : 0;




my $filespec = "$GBS::SILO_PATH/.gbs/gbssum/$name.html";
my @lines;
my $head_title = "Silo - $GBS::SYSTEM_NAME [$GBS::ROOT_PARENT] - Overview: $name";

push @lines, GBSHTML_doc_start( $filespec, $head_title, 1, '', undef); # $want_scripts, $body_class, $target_frame_name
push @lines, GBSHTML_doc_top( [ $head_title, HTML_link( $GBS::LOG_PATH, HTML_bold( 'GBS Log Directory'))],
( [ "Date: $NOW_DATETIME", '', '' ],
));




my @row_refs;




if ($is_audit)
{
push @lines, HTML_text( 'Please be aware that only the HTML-summary files were saved. Not the files referred to.'),
HTML_br(),
HTML_bold_txt( 'The files referred to will always be the last audited file versions.'),
HTML_br();
}
push @lines, HTML_br(),
HTML_text( 'Note that the following table is sortable by the items in the top row.');




foreach my $line_ref (reverse( @{$line_refs_ref}))
{
my (
$jobname,
$build_or_tool,
$uname,
$root_path,			    # os format
$logfile,			    # os format
$time_start,
$time_end,
$time_diff,
$timer_diff,
$state,			    # NORMAL, FAILED, KILLED
$rc,
$action,
$date_time,			    # YYYYMMDD-HHMMSS
$command_args,
$comments,
undef			    # '<<EOF>>'
) = @{$line_ref};

$logfile = ENV_perl_canon_paths( $logfile);

my $logfile_html;
if (-e $logfile)
{
$logfile_html = HTML_link( {target => '_blank'}, $logfile, 'VIEW');
} else
{
my ($path, $file) = ENV_split_spec_pf( $logfile);
my $moved_logfile = "$GBS::LOG_PATH/$file";
$logfile_html = (-e $moved_logfile) ? HTML_link( {target => '_blank'}, $moved_logfile, 'VIEW*') :
HTML_span( {title => $moved_logfile}, 'Missing');
}
my $state_html = HTML_div( {class => $state}, $state);
$date_time = TIME_unpack( $date_time);
$date_time =~ s/ /&nbsp;/;
if (substr( $date_time, 0, 10) eq $TODAY)
{
$date_time .= '*';
$date_time = HTML_span( { style => "background-color: #F0F0F0"}, $date_time);	# very light grey
}
if ($is_audit)
{
my ($audit) = $logfile =~ /gbssysaudit_${build_or_tool}_(.*)_\d/;
$audit = '*UNK*'
if (!defined $audit);
my $htmlfile = "$GBS::SILO_PATH/audits/" . ENV_split_spec_n( $logfile) . "_sum.html";
my $htmlfile_html = (-e $htmlfile) ? HTML_link( {target => '_blank'}, $htmlfile, 'VIEW') :
HTML_span( {title => $htmlfile}, 'Missing');
push @row_refs, [ $jobname, $audit, $build_or_tool, $date_time, $state_html, $rc, $logfile_html, $htmlfile_html, $command_args, $comments ];
} else
{
push @row_refs, [ $jobname, $build_or_tool, $date_time, $state_html, $rc, $logfile_html, $command_args, $comments ];
}
}

push @lines, HTML_br();
if ($is_audit)
{
push @lines, HTML_table( [ qw( - - - - -C -R -C -C - - ) ],
[ qw( Job Audit Build DateTime State RC LogFile HTML<BR>Sum Comand-Args Comments) ],
\@row_refs, border => 1, class => 'sortable border1');
} elsif ($is_tool)
{
push @lines, HTML_table( [ qw( - - - -C -R -C - - ) ],
[ qw( Job Tool DateTime State RC LogFile Comand-Args Comments) ],
\@row_refs, border => 1, class => 'sortable border1');
} else
{
push @lines, HTML_table( [ qw( - - - -C -R -C - - ) ],
[ qw( Job Build DateTime State RC LogFile Comand-Args Comments) ],
\@row_refs, border => 1, class => 'sortable border1');
}




push @lines, GBSHTML_doc_bottom();
push @lines, GBSHTML_doc_end();

SPIT_file_nl( $filespec, \@lines);
ENV_say( 1, "Created Silo $name");
}




sub audit_sum_file()
{
my @html_files = ENV_glob( "$GBS::LOG_PATH/gbsaudit_*_sum.html");
if (@html_files)
{



my $name = 'gbsaudit';
my $filespec = "$GBS::SILO_PATH/.gbs/gbssum/$name.html";
my @lines;
my $head_title = "Silo - $GBS::SYSTEM_NAME [$GBS::ROOT_PARENT] - Overview: $name";

push @lines, GBSHTML_doc_start( $filespec, $head_title, 1, '', undef); # $want_scripts, $body_class, $target_frame_name
push @lines, GBSHTML_doc_top( [ $head_title, HTML_link( $GBS::LOG_PATH, HTML_bold( 'GBS Log Directory'))],
( [ "Date: $NOW_DATETIME", '', '' ],
));



my @row_refs;




push @lines, HTML_text( 'Please be aware that only the HTML-summary files were saved. Not the files referred to.'),
HTML_br(),
HTML_bold_txt( 'The files referred to will always be the last audited file versions.'),
HTML_br();

push @lines, HTML_br(),
HTML_text( 'Note that the following table is sortable by the items in the top row.');




foreach my $html_filespec (@html_files)
{

my ($jobname, $build_or_tool, $audit, $numtime) = GBSRES_split_logfile_spec( $html_filespec);
if (defined $jobname)
{
my $date_time = TIME_unpack( $numtime);
$date_time =~ s/ /&nbsp;/;
if (substr( $date_time, 0, 10) eq $TODAY)
{
$date_time .= '*';
$date_time = HTML_span( { style => "background-color: #F0F0F0"}, $date_time);	# very light grey
}
push @row_refs, [ $jobname, $audit, $build_or_tool, $date_time,
HTML_link( {target => '_blank'}, $html_filespec, 'VIEW')];
}
}
@row_refs = sort { $b->[3] cmp $a->[3] } @row_refs;	# $numtime

push @lines, HTML_br();
push @lines, HTML_table( [ qw( - - - - -C ) ],
[ qw( Job Audit Build DateTime HTML<BR>Sum) ],
\@row_refs, border => 1, class => 'sortable border1');



push @lines, GBSHTML_doc_bottom();
push @lines, GBSHTML_doc_end();

SPIT_file_nl( $filespec, \@lines);
ENV_say( 1, "Created Silo $name");
}
}




sub create_build_audits_overview()
{
my $path = "$GBS::SILO_PATH/build_audits_overview";
ENV_mkdir( $path);
my $filespec = "$path/index.html";
my @lines;




my $head_title = "Silo - $GBS::SYSTEM_NAME [$GBS::SYSTEM_NAME] - Builds and Audits Overview";

push @lines, GBSHTML_doc_start( $filespec, $head_title, 1, '', undef); # $want_scripts, $body_class, $target_frame_name
push @lines, GBSHTML_doc_top( [ $head_title, HTML_link( '../index.html', HTML_bold( 'Silo Home')) ],
([ "Date: $NOW_DATETIME", '', ''],
));








push @lines, HTML_br(),
HTML_text( 'Note that the following table is sortable by the items in the top row.');




my @row_refs;

my $nr_builds = @GBS::ALL_BUILDS;

my $nr_audits = @GBS::ALL_AUDITS;
foreach my $subsys (@GBS::ALL_SUBSYSTEMS)
{
my $sstype = GBSGLO_subsystem_type( $subsys);

if ($sstype eq 'GBS')
{



foreach my $component (GBSGLO_components( $subsys))
{

my $component_path = "$GBS::ROOT_PATH/dev/$subsys/comp/$component";
foreach my $build (@GBS::ALL_BUILDS)
{
my $ss_build = (GBSGLO_subsystem_does_build( $subsys, $build)) ? $build : "$build*";
my @found_audits;
foreach my $audit (@GBS::ALL_AUDITS)
{
if (-e "$component_path/aud/$audit/$build")
{
push @found_audits, $audit;
}
}
if (@found_audits)
{
foreach my $audit (@found_audits)
{
my $ss_audit = (GBSGLO_subsystem_does_audit( $subsys, $audit, $build)) ? $audit : "$audit*";
push @row_refs, [ $subsys, $sstype, $ss_build, $ss_audit, $component, $ss_build, $audit ];
}
} else
{
push @row_refs, [ $subsys, $sstype, $ss_build, '', $component, $ss_build, '' ]
if ($ss_build ne "$build*");
}
}
}
} else
{



my $nr_ss_builds = 0;
foreach my $ss_build( @GBS::ALL_BUILDS)
{
if (GBSGLO_subsystem_does_build( $subsys, $ss_build))
{
my $nr_ss_audits = 0;
foreach my $ss_audit (@GBS::ALL_AUDITS)
{
if (GBSGLO_subsystem_does_audit( $subsys, $ss_audit, $ss_build))
{
push @row_refs, [ $subsys, $sstype, $ss_build, $ss_audit, '', '', ''];
$nr_ss_audits++;
$nr_ss_builds++;
}
}
if ($nr_ss_audits == 0)
{
push @row_refs, [ $subsys, $sstype, $ss_build, '', '', '', '' ];
$nr_ss_builds++;
}
}
}
push @row_refs, [ $subsys, $sstype, '', '', '', '', '' ]
if ($nr_ss_builds == 0);

}
}

push @lines, HTML_table( [ qw( - - - - - - - ) ],
[ qw( SubSys SSTYPE Build Audit Component Build Audit) ],
\@row_refs, border => 1, class => 'sortable border1');




push @lines, GBSHTML_doc_bottom();
push @lines, GBSHTML_doc_end();

SPIT_file_nl( $filespec, \@lines);
ENV_say( 1, "Created Silo Builds and Audits Overview");
}


