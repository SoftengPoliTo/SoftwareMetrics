#=================================================
#
#   gbssub.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSSUB @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::args;
use mod::gbsenv;
use mod::gbscmd;
use mod::fail;
use mod::build;
use mod::audit;
use mod::bldopt;
use mod::exec;
use mod::run;




sub set_command_envvars();
sub set_command_envvar($$$);
sub get_command_args();












my ($JOBTYPE,	    #  audit|build|make|cleanp_bld|cleanup_aud
$IGNORE_ERRORS, # bool
);

my $FOR_BUILD = 0;
my $FOR_MAKE = 0;
my $FOR_AUDIT = 0;
my $FOR_CLEANUP_BLD = 0;
my $FOR_CLEANUP_AUD = 0;
my $FOR_BUILD_OR_MAKE = 0;	    # build | make
my $FOR_CLEANUP = 0;	    # cleaup_aud | cleaup_build
















$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;




GBSENV_init( undef);

get_command_args();

if ($JOBTYPE eq 'build')
{
$FOR_BUILD = 1;
$FOR_BUILD_OR_MAKE = 1;
} elsif ($JOBTYPE eq 'make')
{
$FOR_MAKE = 1;
$FOR_BUILD_OR_MAKE = 1;
} elsif ($JOBTYPE eq 'audit')
{
$FOR_AUDIT = 1;
} elsif ($JOBTYPE eq 'cleanup_bld')
{
$FOR_CLEANUP_BLD = 1;
$FOR_CLEANUP = 1;
} elsif ($JOBTYPE eq 'cleanup_aud')
{
$FOR_CLEANUP_AUD = 1;
$FOR_CLEANUP = 1;
} else
{
ENV_sig( F => "Invalid JOBTYPE '$JOBTYPE'");
}

ENV_setenv( GBS_IGNORE_ERRORS => $IGNORE_ERRORS);
ENV_setenv( GBS_MAKE => GBSCMD_get_os_command( 'make'));




{
my $options_banner = BLDOPT_init();



if ($FOR_BUILD_OR_MAKE || $FOR_AUDIT)	    # exclude FOR_CLEANUPs
{





foreach my $src_type (BUILD_get_src_types( $GBS::BUILD))
{
my $type_postfix = '_' . uc substr( $src_type, 1);
my @env_def_refs = BLDOPT_get_envs_settings( $GBS::SUBSYS, '', $src_type);

foreach my $ref (@env_def_refs)
{
my ($envvar_name, @envvar_values) = @{$ref};
if ($envvar_name eq 'GBS_FLAGS')
{
push @envvar_values, BLDOPT_get_options_flags( $src_type, '$@.map');    # '%@' == current make build
}
$ENV{"$envvar_name$type_postfix"} = "@envvar_values";	# we do not want to use ENV_setenv because of the "" if empty
}
}

}




my $gbs_ignore_errors = ENV_getenv( 'GBS_IGNORE_ERRORS');
if ($GBS::SSTYPE eq 'make')
{



my @make_flags;

push @make_flags, '-k -i',			    # Keep going when some targets can't be made.
if ($gbs_ignore_errors);
$ENV{GBS_MAKE_FLAGS} = "@make_flags";	    # we do not want to use ENV_setenv because of the "" if empty
set_command_envvars();
} elsif ($GBS::SSTYPE eq 'MSVS')
{



my $gbs_mode = ENV_getenv( 'GBS_MODE');
my $msbuild_config = ($gbs_mode eq 'FINAL') ? 'Release' : ($gbs_mode eq 'DEBUG') ? 'Debug' : '';
$ENV{GBS_MSBUILD_CONFIG} = $msbuild_config; # we do not want to use ENV_setenv because of the "" if empty
} elsif ($GBS::SSTYPE eq 'Other')
{



set_command_envvars();
} else
{
ENV_sig( EE => "Invalid SubSys Type '$GBS::SSTYPE");
}




ENV_say( 1, "** $options_banner");





$RC = RUN_gbssub_script( $JOBTYPE);
ENV_say( 0, '-');
FAIL_log( "gbssub$JOBTYPE", $RC, $GBS::SUBSYS, '', '')
if ($RC != 0);

if ($FOR_BUILD_OR_MAKE)
{



if (-d "$GBS::ROOT_PATH/res/$GBS::SUBSYS" || -d "$GBS::ROOT_PATH/dev/$GBS::SUBSYS/export")
{
if ($IGNORE_ERRORS || $RC == 0)
{
ENV_say( 1, "Implicit gbsexport of $GBS::SUBSYS");
my @gbsexport_opts;
push @gbsexport_opts, '--i' if ($IGNORE_ERRORS);
my $this_rc = EXEC_run( 'gbsexport.pl', \@gbsexport_opts);
$RC = $this_rc if ($this_rc > $RC);
FAIL_log( 'gbsexport', $this_rc, $GBS::SUBSYS, '', '')
if ($this_rc != 0);
} else
{
ENV_say( 1, "SKIPPED: gbsexport of $GBS::SUBSYS");
}
}
}
}




ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
}




sub set_command_envvars()
{
foreach my $src_type (BUILD_get_src_types( $GBS::BUILD))
{
my $command_data_refs_ref = BUILD_get_src_command_data_refs( $GBS::BUILD, $src_type);
set_command_envvar( BUILD => $src_type, $command_data_refs_ref);
}
if ($FOR_AUDIT)
{
foreach my $src_type (AUDIT_get_src_types( $GBS::AUDIT))
{
my $command_data_refs_ref = AUDIT_get_src_command_data_refs( $GBS::AUDIT, $src_type);
set_command_envvar( AUDIT => $src_type, $command_data_refs_ref);
}
}
}




sub set_command_envvar($$$)
{
my ($uc_abt_type,		    # AUDIT, BUILD or TOOL
$src_type,
$command_data_refs_ref,	    # [$command_type, $command_items_ref, $ok_values, $exec_condition, $pos_arg_tokens];

) = @_;

my $command_type = $command_data_refs_ref->[0]->[0];    # not used (yet)
my $command_items_ref = $command_data_refs_ref->[0]->[1];
my @command_words = @{$command_items_ref};
my $command = shift @command_words;
$command = ENV_expand_envs( $command);
my @command = ($command);
while (defined $command_words[0] && $command_words[0] !~ /^[\$\%]/)
{
push @command, shift @command_words;
}

my $type_uc = uc substr( $src_type, 1);
ENV_setenv( "GBS_${uc_abt_type}_$type_uc" => ENV_join_quoted_space( @command));

}




sub get_command_args()
{


($JOBTYPE,	     #  audit|build|make|cleanp_bld|cleanup_aud
$IGNORE_ERRORS, # bool
) = ARGS_get( 2, 'perl gbssub.pl audit|build|make|cleanp_bld|cleanup_aud <ignore_errors>', undef);
}



