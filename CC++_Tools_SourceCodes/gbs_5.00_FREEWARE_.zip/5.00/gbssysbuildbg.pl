#=================================================
#
#   gbssysbuildbg.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSSYSGENBG @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::genopt;
use mod::gbsenv;
use mod::gbsoptenv;
use mod::validate;
use mod::sys;
use mod::plugin;
use mod::gbssysbg;














$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( 'build');













{
my @genopts = (
[ '<1>',    'steps_fspec',   'ssm',      "", "Steps-file spec" ],
[ 'i',	    'ignore_errors', 'bso',       0, "Continue generation after error(s)" ],
[ 'mm',	    'run_makemake',  'bso',       1, "Run 'gbsmakemake' on completion of Full GBS SubSystems" ],
[ 'export', 'run_export',    'bso',       1, "Run 'gbsexport' on completion" ],
[ 'files',  'files',	     'sao', '*:*.*', "Files to build" ],
[ 'jobs',   'jobs',     'isor1..9',       2, 'Max nr parallel jobs within a submitted job' ],
);
my @genenvs = qw( LOG_PATH DEBUGGER MODE OPT MAP FLAGS_* APP_* );
GENOPT_set_optdefs( 'gbssysbuildbg', \@genopts,
'This is the background counterpart of gbssysbuild',
undef);
GENOPT_set_envdefs( \&GBSOPTENV_set, \&GBSOPTENV_print, \@genenvs);
GENOPT_parse();
}
my $STEPS_FILE_SPEC = GENOPT_get( 'steps_fspec');
my $IGNORE_ERRORS = GENOPT_get( 'ignore_errors');
my $RUN_MAKEMAKE = GENOPT_get( 'run_makemake');
my $RUN_EXPORT = GENOPT_get( 'run_export');
my @FILES = GENOPT_get( 'files');
my $JOBS = GENOPT_get( 'jobs');

{



VALIDATE_root();




SYS_set_envs();
PLUGIN_setup( 'build');




my @opts = (
GENOPT_makeopt( 0, ignore_errors => $IGNORE_ERRORS),
GENOPT_makeopt( 1, run_makemake => $RUN_MAKEMAKE),
GENOPT_makeopt( 1, run_export => $RUN_EXPORT),
GENOPT_makeopt( 0, jobs => $JOBS),
);


$RC = GBSSYSBG_execute( 'build', $IGNORE_ERRORS, \@FILES, $STEPS_FILE_SPEC, \@opts);
}




ENV_exit( $RC);




END
{
my $rc = $?;




GBSSYSBG_print_errors()
if ($rc != 0);

ENV_print_end_msg( 1);
}


