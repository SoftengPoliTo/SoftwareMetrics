#=================================================
#
#   scmsvn.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
#   File states:
#    -2 => 'NO-FILE',
#    -1 => 'NOT-CCM',
#     0 => 'CHECKED-IN',
#     1 => 'CHECKED-OUT',
#=================================================
package glo::scmsvn;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SCMSVN_init
SCMSVN_connect
SCMSVN_cache_states
SCMSVN_get_states
SCMSVN_checkout
SCMSVN_uncheckout
SCMSVN_checkin
SCMSVN_remove
SCMSVN_move
SCMSVN_add_dirs
SCMSVN_add_files
SCMSVN_get_ignore
SCMSVN_set_ignore
SCMSVN_setup
);
}




use File::Path;
use glo::env;
use glo::list;
use glo::spit;
use glo::slurp;
use glo::ask;

ENV_whisper( 1, "Loading SubVersioN Plugin...");




sub SCMSVN_init($$);
sub SCMSVN_connect($$$);
sub SCMSVN_cache_states($);
sub SCMSVN_get_states($);
sub SCMSVN_checkout($);
sub SCMSVN_uncheckout($);
sub SCMSVN_checkin($);
sub SCMSVN_remove($);
sub SCMSVN_move($);
sub SCMSVN_add_dirs($);
sub SCMSVN_add_files($);
sub SCMSVN_get_ignore($);
sub SCMSVN_set_ignore($$);
sub SCMSVN_setup($$$);

sub check_repos($$$);
sub exec_version();
sub exec_info($);
sub exec_status($);
sub exec_full_status_recurse();
sub exec_commit($);
sub exec_revert($);
sub exec_delete($);
sub exec_move($$);
sub exec_add($);
sub exec_propset($$$);
sub exec_propget($$);
sub exec_list($);
sub exec_import($$);
sub admin_create($);

sub extract_state($$);
sub read_svn_list($);
sub add_svn_list($$);




my $APP_NAME;
my $APP_BASE_PATH;
my $APP_ROOT_PATH;
my $APP_ROOT_PATH_L;


my $EXEC_OS = 'svn';
my $EXEC_ADMIN_OS = 'svnadmin';

my $IS_WIN32 = ENV_is_win32();

my %FSTATES;

my $ALL_STATES_ARE_CACHED = 0;




sub SCMSVN_init($$)
{
($APP_NAME,
$EXEC_OS) = @_;

$EXEC_ADMIN_OS = $EXEC_OS;
my $type = ENV_split_spec_t( $EXEC_OS);
if ($type eq '')
{
$EXEC_ADMIN_OS =~ s/svn$/svnadmin/;
} else
{
$EXEC_ADMIN_OS =~ s/svn$type$/svnadmin$type/;
}
$APP_BASE_PATH = ENV_getenv( $APP_NAME . '_BASE_PATH');
}





sub SCMSVN_connect($$$)
{
(undef,		    # REPOSITORY
$APP_ROOT_PATH,
undef) = @_;	    # DATA
my ($repos_root_path, $internal_path, $connect_texts_ref);

$APP_ROOT_PATH_L = length $APP_ROOT_PATH;
$connect_texts_ref = exec_version();

($repos_root_path, $internal_path) = exec_info( $APP_ROOT_PATH);


%FSTATES = ();	    # clear previous file-states
$ALL_STATES_ARE_CACHED = 0;

return ($repos_root_path, $internal_path, $connect_texts_ref);
}




sub SCMSVN_cache_states($)
{
my ($force_reread,	# bool
) = @_;

if ($force_reread || !$ALL_STATES_ARE_CACHED)
{
%FSTATES = ();	    # clear previous file-states
foreach my $ref (exec_full_status_recurse())
{
my ($states_6, $filespec) = @{$ref};
my $scm_state = extract_state( $states_6, $filespec);
$FSTATES{$filespec} = $scm_state;
}
}
$ALL_STATES_ARE_CACHED = 1;


}








sub SCMSVN_get_states($)
{
my ($spec_refs_ref,	    # IN/OUT: [ [ $spec, $state ], ... ]
) = @_;



my @specs;
foreach my $spec_ref (@{$spec_refs_ref})
{
my ($spec, $state) = @{$spec_ref};

if (defined $state)	    # $state may be -2 (no such file/dir)
{

} else
{

$state = $FSTATES{$spec};
if (defined $state)
{

$spec_ref->[1] = $state;	# $state
} else
{
if ($ALL_STATES_ARE_CACHED)
{



$spec_ref->[1] = -1;	# $state = Not SCM

} else
{
push @specs, $spec;

}
}
}
}

if (@specs)
{



foreach my $ref (exec_status( \@specs))
{
my ($states_6, $filespec) = @{$ref};
my $scm_state = extract_state( $states_6, $filespec);
my $state = substr( $states_6, 0, 1);
$FSTATES{$filespec} = $scm_state;
}
}





foreach my $spec_ref (@{$spec_refs_ref})
{
my ($spec, $state) = @{$spec_ref};
$spec_ref->[1] = $FSTATES{$spec}
if (!defined $state)
}


}




sub SCMSVN_checkout($)
{
my ($rel_specs_ref) = @_;

ENV_chmod( 'u+w', @{$rel_specs_ref});

map { $FSTATES{$_} = 1 } @{$rel_specs_ref}; # checkout
}




sub SCMSVN_checkin($)
{
my ($rel_specs_ref) = @_;

exec_commit( $rel_specs_ref);
ENV_chmod( 'ugo-w', @{$rel_specs_ref});
map { $FSTATES{$_} = 0 } @{$rel_specs_ref}; # checkin
}




sub SCMSVN_uncheckout($)
{
my ($rel_specs_ref) = @_;

exec_revert( $rel_specs_ref);
ENV_chmod( 'ugo-w', @{$rel_specs_ref});
map { $FSTATES{$_} = 0 } @{$rel_specs_ref}; # checkin
}




sub SCMSVN_remove($)
{
my ($rel_specs_ref) = @_;

ENV_chmod( 'u+w', @{$rel_specs_ref});
exec_delete( $rel_specs_ref);
map { rmtree( $_, 0, 1) } @{$rel_specs_ref};
map { $FSTATES{$_} = -1 } @{$rel_specs_ref}; # notscm
}




sub SCMSVN_move($)
{
my ($pair_refs_ref) = @_;

foreach my $ref (@{$pair_refs_ref})
{
my ($old_spec, $new_spec) = @{$ref};
ENV_chmod( 'u+w', $old_spec);
exec_move( $old_spec, $new_spec);
$FSTATES{$old_spec} = -1;	# notscm
$FSTATES{$new_spec} = 1;    	# checkout
}
}




sub SCMSVN_add_dirs($)
{
my ($dir_refs_ref) = @_;	    #	[ $dir, $ignores_ref ]

my %ignores;

my @dir_specs;
foreach my $ref (@{$dir_refs_ref})
{
my ($dir, $ignores_ref) = @{$ref};
ENV_mkdir( $dir, oct(777))
if (!-d $dir);
push @dir_specs, $dir;
if (@{$ignores_ref})
{
my $ignores = "@{$ignores_ref}";
push @{$ignores{$ignores}}, $dir;
}
}

exec_add( \@dir_specs);
foreach my $ignores (keys %ignores)
{
my $dirs_ref = $ignores{$ignores};
my @ignores = split( ' ', $ignores);
exec_propset( $dirs_ref, ignore => [ @ignores ]);
}

map { $FSTATES{$_} = 1 } @dir_specs; # checkout
}




sub SCMSVN_add_files($)
{
my ($files_ref) = @_;

map { ENV_touch_file( $_) if (!-f $_) } @{$files_ref};
exec_add( $files_ref);
map { $FSTATES{$_} = 1 } @{$files_ref}; # checkout
}




sub SCMSVN_get_ignore($)
{
my ($dir,		# 1 dir only!
) = @_;
my @ignores;	# match: * = any string, ? = any single, [xx] = subset, [!xx] = non subset

@ignores = exec_propget( $dir, 'ignore');

return @ignores;
}




sub SCMSVN_set_ignore($$)
{
my ($dirs_ref,
$ignores_ref,
) = @_;
my $nr_dirs_changed = 0;

foreach my $dir (@{$dirs_ref})
{
exec_propset( [ $dir ], ignore => $ignores_ref);
}
}




sub SCMSVN_setup($$$)
{
my ($app_root_path,
$default_scms_repository_path,
$default_scms_data,
) = @_;
my ($scms_repository_path, $scms_data);

ENV_whisper( 1, exec_version());
if (-e "$app_root_path/.svn")
{



ENV_say( 1, 'Already under SVN:');
($scms_repository_path, $scms_data) = exec_info( $app_root_path);
ENV_say( 2, "$scms_repository_path => $scms_data");
} else
{




$default_scms_repository_path = ''
if (!defined $default_scms_repository_path);
$default_scms_data = 'trunk'
if (!defined $default_scms_data || $default_scms_data eq '');


my $again;
do
{
$again = 0;
my $index = ASK_index_from_menu( 'Do you want to:', 1, undef,
[ '<Quit>',
'Connect to an existing Repository',
'Create a local Repository' ]);
if ($index == 1)
{



my $select_again;
my $selected_line = '';
do
{
$select_again = 0;
my @svn_list = read_svn_list( 1);
if (@svn_list)
{
my $index = ASK_index_from_menu( 'Connect to:', $#svn_list + 1, undef, [ @svn_list, '<Specify>' ]);
if ($index < $#svn_list)
{



$selected_line = $svn_list[$index];
($scms_repository_path, $scms_data) = split( ' => ', $selected_line);
my $rc = exec_list( $scms_repository_path);
if ($rc == 1)
{
ENV_sig( 'E' => "Not an existing SVN Repository");
$selected_line = '';
$select_again = 1;
}
}
}
} while ($select_again);

if ($selected_line eq '')
{



ENV_say( 1, "Repository access URLs:");
ENV_say( 0, "  file:///path/to/repos         | Direct disk access (Unix)");
ENV_say( 0, "  file:///X:/path/to/repos      | Direct disk access (Windows)");
ENV_say( 0, "  http://<repos>                | WebDAV for Apache server");
ENV_say( 0, "  https://<repos>               | Same as http: but with SSL encryption");
ENV_say( 0, "  svn://<repos>                 | Access via svnserv server");
ENV_say( 0, "  svn+ssh://<repos>             | Same as svn, but through SSH tunnel");
($scms_repository_path) = ASK_uri( 'Enter SVN Repository URL', $default_scms_repository_path, 0,
[ qw( file http svn) ], [ \&check_repos, undef ]);
if ($scms_repository_path ne '')
{
$scms_data = ASK_dirs( 'Enter SVN Internal Path', $default_scms_data, -1, 0, '');   # $length, $must_exist, $path
} else
{
$again = 1;
}
}
} else  # $index == 2
{



if ($default_scms_repository_path eq '')
{
my @svn_lines = read_svn_list( 0);	# local platform files only
my $first_path;
if (@svn_lines)
{
($first_path) = split( ' => ', $svn_lines[0]);
$first_path = ($IS_WIN32) ? substr( $first_path, 8) : substr( $first_path, 7);
$first_path = ENV_parent_path( $first_path);
$default_scms_repository_path = $first_path
if ($first_path ne '');
}
}

my $rc;
do
{
$scms_repository_path = ASK_path( 'Enter Local Repository path', $default_scms_repository_path, 0, -1);	# may not exist, zero length
if ($scms_repository_path ne '')
{
ENV_say( 1, "Creating Repository '$scms_repository_path'...");
ENV_mkpath( $scms_repository_path);
$rc = admin_create( $scms_repository_path);
}
} while ($scms_repository_path ne '' && $rc != 0);

if ($scms_repository_path eq '')
{
$again = 1;
} else
{
$scms_repository_path = (($IS_WIN32) ? 'file:///' : 'file://') . $scms_repository_path;




$scms_data = ASK_dirs( 'Enter SVN Internal Path', $default_scms_data, -1, 0, '');   # $length, $must_exist, $path
my @svn_paths;
if ($scms_data =~ /trunk/)
{
@svn_paths = ( $scms_data, $scms_data );
$svn_paths[0] =~ s!trunk!tags!;
$svn_paths[1] =~ s!trunk!branches!;
if (ASK_YNQ( "Also create '$svn_paths[0]' and '$svn_paths[1]'?", 'Y', 1) eq 'N')
{
@svn_paths = ();
}
push @svn_paths, $scms_data;

{
my $tmp_path = ENV_get_tmp_path( 'svn');
map { ENV_mkpath( "$tmp_path/$_") } @svn_paths;
exec_import( $scms_repository_path, $tmp_path);
map { ENV_rmdir( "$tmp_path/$_") } @svn_paths;
ENV_rmdir( $tmp_path);
}
}
}
}
if ($again)
{
ENV_say( 1 => 'Retry...');
} else
{
add_svn_list( $scms_repository_path, $scms_data);
}
} while ($again);
}

return ( $scms_repository_path, $scms_data );
}




sub check_repos($$$)
{
my ($values_ref,
$default_ref,
$args_ref,
) = @_;
my $error_txt = '';

if ($values_ref->[0] ne '')
{
my $scms_repository_path = $values_ref->[0];
my $rc = exec_list( $scms_repository_path);
$error_txt = "Not a valid SVN Repository URL"
if ($rc == 1);
}

return $error_txt;
}
























sub exec_version()
{
my @connect_texts;

my @stdout;
my $command = ENV_join_quoted_space( $EXEC_OS, '--version');
ENV_run3( $command, undef, [0], \@stdout, undef);
if ($stdout[0] !~ /^svn, version/)
{
ENV_say( 0, @stdout);
ENV_sig( F => "Failed to start SVN session");
}
@connect_texts = @stdout[0..1];

return [ @connect_texts];
}



















sub exec_info($)
{
my ($app_root_path) = @_;
my ($repos_root_path, $internal_path);

my $stdout;
my $stderr;
my $command = ENV_join_quoted_space(  $EXEC_OS, 'info', $app_root_path);
my $rc = ENV_run3( $command, undef, [0,1], \$stdout, \$stderr);
if ($rc == 0)
{
my ($url) = $stdout =~ /^URL: (..*)$/m;
($repos_root_path) = $stdout =~ /^Repository Root: (..*)$/m;
if (!defined $url || !defined $repos_root_path)
{
ENV_print( 0, $stdout);
ENV_sig( EE => "'svn info' returned unexpected result\n");
}
$internal_path = $url;
$internal_path =~ s!^$repos_root_path/!!;
} else # $rc ==1
{
ENV_print( 0, $stdout);
ENV_print( 0, $stderr);
ENV_sig( EE => "'svn info' returned non-zero result ($rc)\n");
}

return ($repos_root_path, $internal_path);
}









sub exec_full_status_recurse()
{
my (@status_refs);	    # ( [ $states_6, $rel_filespec ])



my @stdout;
my @stderr;
my $command = ENV_join_quoted_space( $EXEC_OS, 'status', '-v', $APP_ROOT_PATH);
my $rc = ENV_run3( $command, undef, [0], \@stdout, \@stderr);
ENV_say( 0, 'STDERR', @stderr)
if (@stderr);









if (@stdout)
{

my $os_abs_path_qm = quotemeta( ENV_os_paths( $APP_ROOT_PATH));
foreach my $line (@stdout)
{

next
if ($line =~ /^\s+>/);
my $states_6 = substr( $line, 0, 6);
my ($os_filespec) = substr( $line, 41) =~ /($os_abs_path_qm.*)/;
if (defined $os_filespec)
{

my $filespec = ENV_perl_canon_paths( $os_filespec);
my $rel_filespec = (length $filespec > $APP_ROOT_PATH_L ) ? substr( $filespec, $APP_ROOT_PATH_L + 1) : '';
push @status_refs, [ $states_6, $rel_filespec ];
} else
{
ENV_sig( E => "==>$line", 'svn status: Filespec cannot be determined');
}
}
}


return @status_refs;
}















sub exec_status($)
{
my ($rel_specs_ref,	    # files/dirs MUST exist!
) = @_;
my (@status_refs);	    # ( [ $states_6, $filespec ])



my @stdout;
my @stderr;

my $command = ENV_join_quoted_space( $EXEC_OS, 'status', '-N');

my $rc = ENV_run3( $command, $rel_specs_ref, [0], \@stdout, \@stderr);
if (@stderr)
{

if (ENV_set_verbose())
{
ENV_whisper( 0, "STDERR:", @stderr)
} else
{
@stderr = grep( $_ !~ /warning: W155010/, @stderr); # svn: warning: W155010: The node '<filespec>' was not found.
ENV_say( 0, "STDERR:", @stderr)
if (@stderr);
}
}

if (@stdout)
{

my %states = map { $_ => '      ' } @{$rel_specs_ref};

foreach my $line (@stdout)
{

my $states_6 = substr( $line, 0, 6);
my $filespec = substr( $line, 7);
$filespec =~ s/^\s+//;		    # 7 char-state
$filespec = ENV_perl_paths_noquotes( $filespec);
$states{$filespec} = $states_6;

}
foreach my $filespec (@{$rel_specs_ref})
{
my $states_6 = $states{$filespec};
push @status_refs, [ $states_6, $filespec ];

}
} else
{



foreach my $spec (@{$rel_specs_ref})
{
push @status_refs, [ '      ', $spec ];
}
}


return @status_refs;
}

















sub exec_commit($)
{
my ($rel_specs_ref) = @_;


my $command = ENV_join_quoted_space( $EXEC_OS, 'commit', '-q', '-N', '-m', "Checkin by $APP_NAME");
ENV_run3( $command, $rel_specs_ref, [0], undef, undef);
}










sub exec_revert($)
{
my ($rel_specs_ref) = @_;

my $command = ENV_join_quoted_space( $EXEC_OS, 'revert', '-q');
ENV_run3( $command, $rel_specs_ref, [0], undef, undef);
}










sub exec_delete($)
{
my ($rel_specs_ref) = @_;


my $command = ENV_join_quoted_space( $EXEC_OS, 'delete', '-q', '--force');
ENV_run3( $command, $rel_specs_ref, [0], undef, undef);
}










sub exec_move($$)
{
my ($old_spec,
$new_spec,
) = @_;





my $command = ENV_join_quoted_space( $EXEC_OS, 'move', '-q', '--force');
ENV_run3( $command, [$old_spec, $new_spec], [0], undef, undef);
}










sub exec_add($)
{
my ($rel_specs_ref) = @_;

my $command = ENV_join_quoted_space( $EXEC_OS, 'add', '-N');
ENV_run3( $command, $rel_specs_ref, [0], undef, undef);
}










sub exec_propset($$$)
{
my ($dirs_ref,
$property,	# without svn: ( executable mime-type ignore keywords eol-style externals special needs-lock)
$property_values_ref,
) = @_;

my @property_values = @{$property_values_ref};


my $tmp_file = SPIT_tmp_file_nl( 'svn_property', \@property_values);
my $command = ENV_join_quoted_space( $EXEC_OS, 'propset', '-q', "svn:$property", '-F', $tmp_file);
ENV_run3( $command, $dirs_ref, [0], undef, undef);
unlink $tmp_file;
}












sub exec_propget($$)
{
my ($dir,
$property,	# without svn: ( executable mime-type ignore keywords eol-style externals special needs-lock)
) = @_;
my @property_values;

my @stdout;
my $stderr;
my $command = ENV_join_quoted_space( $EXEC_OS, 'propget', "svn:$property");
my $rc = ENV_run3( $command, [ $dir ], [0,1], \@stdout, \$stderr);
if ($rc == 1)
{
if ($stderr =~ /^svn: warning: W200017:/)
{
@property_values = ();
} else
{
ENV_print( 0, "STDERR: $stderr");
ENV_print( 0, "STDOUT: $stderr");
}
} else
{
@property_values = @stdout;
}

return @property_values;
}







sub exec_list($)
{
my ($repository) = @_;
my $rc;

my $command = ENV_join_quoted_space( $EXEC_OS, 'list', $repository);
$rc = ENV_run3( $command, undef, [0, 1], undef, undef);

return $rc;
}






sub exec_import($$)
{
my ($repository_path,
$import_path,
) = @_;

my $command = ENV_join_quoted_space( $EXEC_OS, 'import', $import_path, $repository_path,
'-m', "Import by $APP_NAME");
ENV_run3( $command, undef, [0], undef, undef);
}







sub admin_create($)
{
my ($repository_path) = @_;
my $rc;

my $command = ENV_join_quoted_space( $EXEC_ADMIN_OS, 'create', $repository_path);
$rc = ENV_run3( $command, undef, [0, 1], undef, undef);

return $rc;
}




















































sub extract_state($$)
{
my ($state_6,	    #
$filespec,
) = @_;
my $scm_state;	    # -1 = NotSCM, 0 = Checked_in, 1 = CheckedOut

my $state = substr( $state_6, 0, 1);
if (index( 'D?I', $state) >= 0)
{
$scm_state = -1;			# Not SCM
} elsif (index( 'AM', $state) >= 0)
{
$scm_state = 1;				# Checked Out;
} else
{
$scm_state = (-w $filespec) ? 1 : 0;	# Checked Out : Checked In
}

return $scm_state;
}




sub read_svn_list($)
{
my ($all_files_wanted,	    # bool. 0 = this_platform_files_only,
) = @_;
my @svn_list;

my $filespec = "$APP_BASE_PATH/svn_list.dat";
if (-e $filespec)
{
my @all_svn_lines = SLURP_file( $filespec);
my @new_svn_lines;
foreach my $svn_line (@all_svn_lines)
{
my $this_platform_file;
if ($IS_WIN32)
{
($this_platform_file) = $svn_line =~ m!^file:///([a-z]:.+) =>!i;
} else
{
($this_platform_file) = $svn_line =~ m!^file:///(.[^:].+) =>!i;
}
if (defined $this_platform_file)
{
if (-e $this_platform_file)
{
push @new_svn_lines, $svn_line;
push @svn_list, $svn_line;
} else
{
ENV_say( 1, "Removed from svn-list: $svn_line");
}
} else
{
push @new_svn_lines, $svn_line;
push @svn_list, $svn_line
if ($all_files_wanted);
}
}
if (@new_svn_lines != @all_svn_lines)
{
SPIT_file_nl( $filespec, \@svn_list);
}
}

return @svn_list;
}




sub add_svn_list($$)
{
my ($repository_path,
$internal_path,
) = @_;

my $filespec = "$APP_BASE_PATH/svn_list.dat";
my @svn_list = read_svn_list( 1);
unshift @svn_list, "$repository_path => $internal_path";	#  Add the entry (LRU)
LIST_unique( \@svn_list);
@svn_list = @svn_list[0..10]    # max lines
if (@svn_list > 10);
SPIT_file_nl( $filespec, \@svn_list);
}

1;

