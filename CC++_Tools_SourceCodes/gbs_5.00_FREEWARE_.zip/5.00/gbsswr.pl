#=================================================
#
#   gbsswr.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSSWR @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::shell;
use glo::ask;
use glo::genopt;
use glo::slurp;
use glo::file;
use glo::format;
use mod::gbsenv;
use mod::run;
use mod::roots;
use mod::rootsglo;
use mod::validate;
use mod::system;
use mod::fspec;
use mod::swb;
use mod::swa;
use mod::swt;
use mod::swc;
use mod::sws;
use mod::swr;
use mod::swrglo;
use mod::gbscheck;
use mod::swglo;
use mod::gbsdb;
use mod::profile;
use mod::gbscmd;
use mod::gbsglo;
use mod::plugin;
use mod::switch;




sub ask_root();
sub do_add_root();
sub ask_add_root_path();
sub check_gbs_root($$$);
sub do_remove_root();
sub do_show_roots();
sub select_root($$);
sub add_to_roots_list($);
sub check_and_write_roots_list();
sub cleanup_tmp_dir();




my $CWD = ENV_cwd();

my $CANCELLED = 0;






$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ '<1>',    'root_path', 	'sso', '', "System / Root: '' == ASK, '-' == none, '.' == current, '!' == CWD, '!<abs_file/dir_spec>', '!!' == current GBS_ROOT_PATH" ],
[ '<2>',    'subsystem',	'sso', '', "SubSystem: '-' == none, '.' == current" ],
[ '<3>',    'component',	'sso', '', "Component: '-' == none, '.' == current" ],
[ 'build', 'build',		'sso', '', "Build: '-' == none, '.' == current" ],
[ 'audit',  'audit',		'sso', '', "Audit: '-' == none, '.' == current" ],
[ 'tool',   'tool',		'sso', '', "Tool: '-' == none, '.' == current" ],
[ 'new',    'create_new_root',	'bso',	0, "Create a new System / Root" ],
[ 'add',    'add_root',		'bso',	0, "Add a Root to the Roots List" ],
[ 'remove', 'remove_root',	'bso',	0, "Remove a Root from the Roots List" ],
[ 'show',   'show_roots',	'bso',	0, "Show the Roots List" ],
[ 'exec',   'execute_command',	'sso', '', "(GBS-)Command(s) to execute. 'none' = OK" ],
[ 'nocd',   'no_cd',		'bso',	0, "Do not 'cd' to the selected directories "],
);
my @genconflicts = (
[ [ new => 1],	    '=', 'add', '=', 'remove', '=', 'show',   '=', 'exec', '=', '<2>', '=', 'build', '=', 'audit' ],
[ [ add => 1],	    '=', 'new', '=', 'remove', '=', 'show',   '=', 'exec', '=', '<2>', '=', 'build', '=', 'audit' ],
[ [ remove => 1],   '=', 'new', '=', 'add',    '=', 'show',   '=', 'exec', '=', '<2>', '=', 'build', '=', 'audit' ],
[ [ show => 1],	    '=', 'new', '=', 'add',    '=', 'remove', '=', 'exec', '=', '<1>', '=', 'build', '=', 'audit' ],
[ [ '<1>' => '-' ], '=', 'new', '=', 'add', '=', 'remove', '=', 'show',   '=', 'exec', '=', '<2>', '=', 'build', '=', 'audit' ],
[ [ '<2>' => '-' ], '=', '<3>' ],
[ [ '<1>' => '' ],  '=', 'build', '=', 'audit' ],
);
GENOPT_set_optdefs( [ 'gbsswr', 'swr' ], \@genopts,
[ 'Set a current Root/System or',
'Create a new one or Add / Remove one from the Roots List or',
'Show the Roots List'],
"You can only '--add' a Root if it was originally created by 'swr --new'");
GENOPT_set_conflicts( \@genconflicts);
GENOPT_parse();
}
my $ROOT_PATH = GENOPT_get( 'root_path');     	    # Unix or Windows format
my $SUBSYS = GENOPT_get( 'subsystem');
my $COMPONENT = GENOPT_get( 'component');
my $BUILD = GENOPT_get( 'build');
my $AUDIT = GENOPT_get( 'audit');
my $TOOL = GENOPT_get( 'tool');
my $NEW = GENOPT_get( 'create_new_root');
my $ADD = GENOPT_get( 'add_root');
my $REMOVE = GENOPT_get( 'remove_root');
my $SHOW_ROOTS = GENOPT_get( 'show_roots');
my $EXEC = GENOPT_get( 'execute_command');
my $NO_CD = GENOPT_get( 'no_cd');





VALIDATE_gbs();	    # Checks if GBS is active

my $ROOT_PATH_IS_NUMERIC = 0;
if ($ROOT_PATH ne '' && $ROOT_PATH ne '-' && $ROOT_PATH ne '.')
{
if ($ROOT_PATH =~ /^\d+$/)
{
$ROOT_PATH_IS_NUMERIC = 1;
} else
{
$ROOT_PATH = ENV_perl_paths_noquotes( ENV_perl_canon_paths( $ROOT_PATH));
}
}


{



if (!$NEW && !$ADD && !$REMOVE && ROOTS_get_nr() == 0)
{
my @menu_refs = (
[ '<Exit>' ],
[ 'Create new' ],
[ 'Add existing' ],
);
my $index = ASK_index_from_menu( 'No Root/System(s) defined', 0, undef, \@menu_refs);
if ($index == 1)
{
$NEW = 1;
} elsif ($index == 2)
{
$ADD = 1;
}
}

my $current_root_removed = 0;
if ($NEW || $ADD)
{



ENV_sig( EE => "Cannot specify Root number ($ROOT_PATH) with --new or --add")
if ($ROOT_PATH_IS_NUMERIC);

$ROOT_PATH = ENV_perl_paths_noquotes( ENV_perl_canon_paths( $CWD))
if ($ROOT_PATH eq '.');




if ($NEW)
{



SWR_reset();

my $new_root_path = RUN_gbsnew( 'new_root', $ROOT_PATH);
if ($new_root_path ne '')
{
$ROOT_PATH = $new_root_path;
add_to_roots_list( $ROOT_PATH);
ENV_say( 1, "Current Root is $ROOT_PATH");

$SUBSYS = '-';
$COMPONENT = '-';
$BUILD = '-';
$AUDIT = '-';
$TOOL = '-';
} else
{
$ROOT_PATH = '.';
$CANCELLED = 1;
}
} else	# ($ADD)
{



my $added_root_path = do_add_root();
$ROOT_PATH = ($added_root_path eq '') ? '.' : $added_root_path;
}
} elsif ($REMOVE)
{



my $removed_root_path = do_remove_root();
if ($removed_root_path eq $GBS::ROOT_PATH)
{
ENV_say( 1, "Current Root removed");
$current_root_removed = 1;
$ROOT_PATH = '-';	# No current
} else
{
$ROOT_PATH = '.';	# Keep current
$CANCELLED = 1;
}

} elsif ($SHOW_ROOTS)
{



do_show_roots();
}

if (!$CANCELLED)
{



$ROOT_PATH = ask_root()
if ($ROOT_PATH eq '');
my @swglo_items = SWRGLO_validate( $ROOT_PATH, $BUILD, $SUBSYS, $COMPONENT, $AUDIT, $TOOL);


my ($new_root_path, $new_build, $new_subsys, $new_component, $new_audit, $new_tool) = @swglo_items;


if ($GBS::ROOT_PATH ne '')
{








SWR_exit()
unless ($current_root_removed);




SWC_set( $GBS::SUBSYS, '', 0)	    # Clear Current Component
if ($GBS::COMPONENT ne '');
SWS_set( '', 0)			    # Clear Current SubSys
if ($GBS::SUBSYS ne '');
SWA_set( '', 0)			    # Clear Current Audit
if ($GBS::AUDIT ne '');
SWB_set( '', 0)			    # Clear Current Build
if ($GBS::BUILD ne '');
SWT_set( '', 0)			    # Clear Current Tool
if ($GBS::TOOL ne '');
SWR_reset();			    # Clear Current Root
GBSENV_setenv( GBS_ROOT_PATH => '', 1);




PLUGIN_reset();
SYSTEM_close();
}

if ($new_root_path ne '')
{








GBSENV_setenv( GBS_ROOT_PATH    => $new_root_path, 1);
GBSENV_setenv( GBS_BUILD	    => $new_build, 1);
GBSENV_setenv( GBS_SUBSYS	    => $new_subsys, 1);
GBSENV_setenv( GBS_COMPONENT    => $new_component, 1);
GBSENV_setenv( GBS_AUDIT	    => $new_audit, 1);
GBSENV_setenv( GBS_TOOL	    => $new_tool, 1);




SWR_entry();




SWR_set();
{
my $must_write = ($GBS::SUBSYS ne '');
SWS_set( $GBS::SUBSYS, $must_write);
}
{
my $must_write = ($GBS::COMPONENT ne '');
SWC_set( $GBS::SUBSYS, $GBS::COMPONENT, $must_write);
}





{
my @this_platform_builds = PLUGIN_get_abt_names( 'build');

if (@this_platform_builds == 0)
{
ENV_say( 1, 'At least one Build is required');
my $new_build = RUN_gbsnew( 'new_build', '');

PLUGIN_reset();
if ($new_build ne '')
{
GBSENV_setenv( GBS_BUILD => $new_build, 1);
}
}
}




SWB_set( $GBS::BUILD, 1);
SWA_set( $GBS::AUDIT, 1);
SWT_set( $GBS::TOOL, 1);

if (GBSENV_mode_is_interactive())
{
GBSDB_last_root_write( $GBS::ROOT_PATH);

if (!$NEW)
{
ENV_sig( W => "No current SubSystem")
if ($GBS::SUBSYS eq '');
ENV_sig( W => "No current Component")
if ($GBS::COMPONENT eq '' && GBSGLO_subsystem_is_full_gbs( $GBS::SUBSYS));
}
ENV_sig( W => "No current Build")
if ($GBS::BUILD eq '');
}
}







my @lines;
if ($GBS::ROOT_PATH eq '')
{



push @lines, SWGLO_set_title();
} else
{
push @lines, SHELL_echo( 1, '');




push @lines, SWGLO_set_title( $GBS::ROOT_PATH, $GBS::SUBSYS, $GBS::COMPONENT);
}




push @lines, GBSENV_changed_setenv_commands( 0);	# $must_log = 0




my $new_cwd = ($NO_CD) ? $CWD : SWGLO_new_cwd( $GBS::ROOT_PATH, $GBS::SUBSYS, $GBS::COMPONENT);
push @lines, SHELL_cd( $new_cwd);




push @lines, GBSCMD_get_full_gbs_command( gbsshow => '--brief');




if ($EXEC ne '' && $EXEC ne 'none')
{




my @exec_args = ENV_split_quoted_space( $EXEC);

my $command = shift @exec_args;
$command = 'gbsshow'
if ($command eq 'gbs');
my $command_items_ref;
if ($command =~ /\.(pl|bat|sh)/)
{
my $command_spec = "$GBS::SCRIPTS_PATH/$command";
if (-f $command_spec)
{
$command_items_ref = [ $command_spec, @exec_args ];
} else
{
ENV_sig( EE => "'--exec=$EXEC': Command not found");
}
} else
{




my $command_base = "$GBS::SCRIPTS_PATH/$command";
my $script_command = ENV_command_filespec( $command_base);	# Append .bat or .sh

if (-f $script_command)
{
$command_items_ref = [ $script_command, @exec_args ];
} elsif (-f "$command_base.pl")
{
$command_items_ref = [ "$command_base.pl", @exec_args ];
} else
{
ENV_sig( EE => "Invalid '--exec' command: $EXEC")
}
}
my $exec_command = ENV_prepare_command( $command_items_ref);


push @lines, SHELL_conditional_eq( GBS_RC => 0, $exec_command);
push @lines, SHELL_setrc();
} else
{
if ($GBS::ROOT_PATH ne '' && GBSENV_mode_is_interactive())
{
cleanup_tmp_dir();
}
}

push @lines, SHELL_exit_rc( 1);			# $is_sourced = 1
GBSENV_write_result_script( \@lines, 0);	# $print_lines = 0
}
}

ENV_exit( $RC);




END
{
if ($CANCELLED)
{
ENV_print_end_msg( 1);
} else
{
ENV_print_end_msg( 0);
}
}




sub ask_root()
{
my $root_path;	    # Perl format




my $nr_roots = ROOTS_get_nr();
if ($nr_roots == 0)
{
ENV_sig( EE => "No Root(s) defined for this user",
"use 'swr --add' to use an existing Root/System",
"or  'swr --new' to define a new Root/System");

} elsif ($nr_roots == 1)
{
my @all_root_paths = ROOTS_get_all();
$root_path = ENV_perl_paths_noquotes( $all_root_paths[0]);
ENV_say( 1, "Single Root '$root_path' taken by default");
} else
{



my $default_root_path = $GBS::ROOT_PATH;
$default_root_path = GBSDB_last_root_get()
if ($default_root_path eq '');
$root_path = select_root( "Select Root/System Directory", \$default_root_path);
}

return $root_path;
}




sub do_add_root()
{
my $root_path = $ROOT_PATH;	    # From CommandLine - Perl format

if ($root_path ne '')
{
ENV_say( 1, "Add Root/System ($root_path)");
} else
{
ENV_say( 1, "Add Root/System");
}

if ($root_path eq '')
{



ENV_say( 1, "Please note that you can only ADD a Root that was originally created with 'swr --new'");
if (GBSCHECK_system( $CWD))
{



ENV_say( 1, "Currently in '$CWD',",
"Which seems to be the Top of a GBS Root");
$root_path = $CWD
if (ASK_YNQ( "Do you want to add it?", 'N', 1) eq 'Y');   # exit on quit
}

if ($root_path eq '')
{
$root_path = ask_add_root_path();
}
} else
{



$root_path = ENV_perl_paths_noquotes( $root_path);
ENV_say( 1, "Adding $root_path");
ENV_sig( EE => "No such directory: $root_path")
if (!-d $root_path);
ENV_sig( EE => "Not a GBS Root: $root_path")
if (!GBSCHECK_system( $root_path));
}
$CANCELLED = 1
if ($root_path eq '');

if (!$CANCELLED)
{
my ($for_this_platform, $for_other_platform) = GBSCHECK_system_platform( $root_path);
if ($for_this_platform)
{
add_to_roots_list( $root_path);
} elsif ($for_other_platform)
{
ENV_say( 1, "Adding Other Platform...");
$root_path = RUN_gbsnew( 'new_other_root', $root_path);
if ($root_path ne '')
{



$BUILD = '-';
$AUDIT = '-';
$TOOL = '-';

add_to_roots_list( $root_path);
} else
{
$CANCELLED = 1;
}
} else
{
$CANCELLED = 1;
}
$root_path = ''
if ($CANCELLED);
}

ENV_sig( W => "No Root/System added!")
if ($CANCELLED);

return $root_path;
}




sub ask_add_root_path()
{
my $root_path = '';




ENV_say( 1, 'Searching for existing GBS Roots in known places...');
my $gbswa_root = ENV_get_user_path( 0) . '/GBSWA';	# ~/GBSWA or MyDocuments/GBSWA
my %possible_gbswa_paths;
$possible_gbswa_paths{$gbswa_root} = 1
if (-e $gbswa_root);
foreach my $path (( $CWD, $GBS::ROOT_PATH, ROOTS_get_all()))
{
$possible_gbswa_paths{ENV_parent_path($path)} = 1
if ($path ne '');				    # GBS_ROOT_PATH may be ''
}

foreach my $path (keys %possible_gbswa_paths)
{
if (-d $path)
{
my @possible_root_dirs = SLURP_dir_dirs( $path, 0);

@possible_root_dirs = grep( GBSCHECK_system( "$path/$_"), @possible_root_dirs);
if (@possible_root_dirs)
{
$possible_gbswa_paths{$path} = [ @possible_root_dirs ];
} else
{
delete $possible_gbswa_paths{$path};
}
} else
{
delete $possible_gbswa_paths{$path};
}

}
my @gbswa_path_refs = map { [ $_, $possible_gbswa_paths{$_} ] } sort keys %possible_gbswa_paths;

%possible_gbswa_paths = ();
if (@gbswa_path_refs)
{
ENV_say( 1, 'Found:',
ROOTSGLO_get_helpline());
my @non_added_roots;
foreach my $ref (@gbswa_path_refs)
{
my ($wa_path, $gbs_root_dirs_ref) = @{$ref};
ENV_say( 2, $wa_path);
foreach my $root_dir (@{$gbs_root_dirs_ref})
{
my $root_path = "$wa_path/$root_dir";
my ($is_this_platform, $is_other_platform) = GBSCHECK_system_platform( $root_path);
my $fc = ' ';		# Valid GBS Root
my ($for_current_platform, $for_other_platform) = GBSCHECK_system_platform( $root_path);
if ($for_current_platform)
{
$fc = ($for_other_platform) ? '+' : '=';	# + = Both platfoms
} else
{
$fc = ($for_other_platform) ? '*' : 'x';	# * = Only Other platform
}
if (!ROOTS_exists( $root_path))
{
if ($fc eq '+')
{
$fc = '*';
} elsif ($fc ne '*')
{
$fc = ' ';
}
}
ENV_say( 3, "$fc $root_dir");
push @non_added_roots, "$fc $root_path"
if ($fc eq ' ' or $fc eq '*');
}
}
if (@non_added_roots)
{
my $nr_not_added_roots = @non_added_roots;
ENV_say( 1, "Found $nr_not_added_roots non-added GBS Root directories:",
"- '*' indicates that the Root was created under a different OS - you can add it for this OS");
ENV_say( 0, FORMAT_cols( 0, 4, '  ', 3, \@non_added_roots));
if (ASK_YNQ( 'Add one of these?', 'N', 1) eq 'Y')
{
my $selected_path;
if (@non_added_roots == 1)
{
$selected_path = $non_added_roots[0];
ENV_say( 1, "Single GBS Root taken");
} else
{
$selected_path = ASK_value_from_menu( "Select Root/System Directory", 0, undef, [ '', @non_added_roots ]);
}
if ($selected_path ne '')
{
$root_path = substr( $selected_path, 2);	# remove leading '  ' or '* '
} else
{
ENV_say( 1, "No GBS Root selected");
}
}
} else
{
ENV_say( 1, 'All found roots were already added');
}
} else
{
ENV_say( 1, 'None found');
}

if ($root_path eq '')
{



$root_path = ASK_path( "Enter existing GBS Root Directory", '', 0, 1, [ \&check_gbs_root, undef ]);
$root_path = ENV_perl_canon_paths( $root_path);
}

return $root_path;
}




sub check_gbs_root($$$)
{
my ($values_ref,
$default_ref,
$args_ref,
) = @_;
my $error_txt = '';

my $root_path = $values_ref->[0];

if ($root_path ne '')
{
if (-d $root_path)
{
$error_txt = "Not a GBS Root: $root_path"
if (!GBSCHECK_system( $root_path));
} else
{
$error_txt = "No such directory '$root_path'";
}
}

return $error_txt;
}




sub do_remove_root()
{
my $root_path;	# Perl path nospace or '-'

ENV_say( 1, "Remove Root/System $ROOT_PATH");




if ($ROOT_PATH eq '')
{
$root_path = select_root( "Select Root to remove from Roots-List", 0);
$root_path = ENV_perl_paths_noquotes( $root_path);
} else
{
if ($ROOT_PATH_IS_NUMERIC)
{
my $root_number = $ROOT_PATH;
my @all_root_paths = ROOTS_get_all();	# Perl format nospace
my $nr_roots = @all_root_paths;
if ($root_number >= 1 && $root_number <= $nr_roots)
{

$root_path = $all_root_paths[$root_number - 1];
} else
{
ENV_sig( EE => "Numeric Root-selection ($root_number) must be 1-$nr_roots");
}
} elsif ($ROOT_PATH eq '.')
{
ENV_sig( EE => 'No current Root')
if ($GBS::ROOT_PATH eq '');
$root_path = ENV_perl_paths_noquotes( $GBS::ROOT_PATH);
} else
{
$root_path = ENV_perl_paths_noquotes( $ROOT_PATH);
}
}




my $must_delete = 0;
if ($root_path ne '-')
{
my $selected = ($root_path eq $GBS::ROOT_PATH) ? ' Current' : '';
ENV_say( 1, "Selected $selected: $root_path");
if (ASK_YN( "Sure Remove from RootList?", 'Y') eq 'Y')
{
if (-e $root_path)
{
my ($for_this_platform, $for_other_platform) = GBSCHECK_system_platform( $root_path);
ENV_say( 1, 'This Root also generates for an other platform!')
if ($for_other_platform);

if (ENV_is_in_path( $CWD, $root_path))
{
ENV_say( 1, "Your CWD ($CWD) is inside the root to be removed",
"Delete of the Root tree is not possible");
$must_delete = 0;
} else
{
ENV_say( 1, "Delete of the whole tree may be prevented by SCMS");
$must_delete = (-e $root_path && ASK_YN( "Try to delete the whole '$root_path' tree", 'N') eq 'Y');
}
}
} else
{
$root_path = '-';
}
}




if ($root_path eq '-')
{
$CANCELLED = 1;
} else
{



SWITCH_exit()
if ($root_path eq $GBS::ROOT_PATH);




if (ROOTS_delete( $root_path))
{
ENV_say( 1, "Removed Root '$root_path' from list");
if (-e $root_path)
{
if (-e FSPEC_system( 'system.gbs', $root_path))
{



my $system_name = SYSTEM_get_system_info( $root_path);
if (defined $system_name)
{
foreach my $envvar (qw( GBS_ADMINISTRATOR GBS_INTEGRATOR ))
{
my @values = ENV_getenv( $envvar);
my @new_values = grep( $_ ne $system_name, @values);
GBSENV_setenv( $envvar => \@new_values, 1);
}
PROFILE_open( undef);
PROFILE_remove_from_list( GBS_ADMINISTRATOR => $system_name);
PROFILE_remove_from_list( GBS_INTEGRATOR => $system_name);
PROFILE_close( 1);  # $must_write
}
} else
{
ENV_sig( I => 'Not a valid Root: No system.gbs file found',
$root_path);
}
}
} else
{
ENV_sig( E => "Root not in Roots-List: $root_path");
}




if ($must_delete)
{
ENV_say( 1, "Trying to delete the tree...");
if ( ENV_try( undef, sub { FILE_del_tree( E => $root_path, undef, 1) }, undef))
{
if (ENV_try( undef, sub { FILE_del_dirs( E => $root_path) }, undef))
{
ENV_say( 2, 'System/Root Deleted');
}
}
} else
{
ENV_say( 1, "Note that the Root Directories/Files are NOT deleted");
}
}

check_and_write_roots_list();

return $root_path;
}




sub do_show_roots()
{
ENV_say( 1, "Show Roots-List");

ROOTSGLO_print_root_cols();

check_and_write_roots_list();
$CANCELLED = 1;
}




sub select_root($$)
{
my ($prompt,		# for ASK_value_from_menu
$default,		# for ASK_value_from_menu (value or ref)
) = @_;
my $selected_root_path;

if (ROOTS_get_nr() > 0)
{
my $help_line = ROOTSGLO_get_helpline();
my @root_path_refs = ROOTSGLO_get_root_path_menu_refs();
unshift @root_path_refs, '';		# Add <None>

$selected_root_path = ASK_value_from_menu( [ $prompt, $help_line ], $default, undef, [ @root_path_refs ]);
if ($selected_root_path eq '')
{
$selected_root_path = '-';
}
} else
{
ENV_say( 1, "No Roots in Roots-List");
$selected_root_path = '-';
}

return $selected_root_path;
}




sub add_to_roots_list($)
{
my ($new_root_path) = @_;   # Perl format

if (ROOTS_add( $new_root_path))
{
ENV_say( 1, "Root '$new_root_path' added to Roots List...");
check_and_write_roots_list();
} else
{
ENV_sig( W => "Root '$new_root_path' already in Roots List");
}
}




sub check_and_write_roots_list()
{
foreach my $root_path (ROOTS_get_all())
{
my $ask_delete = 0;
if (-d $root_path)
{
if (!GBSCHECK_system( $root_path))
{
ENV_say( 1, "Root '$root_path'",
'in Roots-list is not a valid GBS Root (anymore)');
$ask_delete = 1;
}
} else
{
ENV_say( 1, "Root '$root_path'",
"in Roots-list does not exist (anymore)");
$ask_delete = 1;
}
if ($ask_delete)
{
ROOTS_delete( $root_path)
if (ASK_YN( 'Remove?', 'Y') eq 'Y');
}
}
ROOTS_write();
}




sub cleanup_tmp_dir()
{
ENV_say( 1, 'Cleanup tmp dir...');

my $now = time();				# get current time
my $days = 7;				# delete older than $days
my $age = $now - (60 * 60 * 24 * $days);	# convert days into seconds




{
my $count = 0;
my $tmp_path = "$GBS::ROOT_PATH/tmp";
foreach my $ref (SLURP_dir_tree( $tmp_path, 0))
{
my ($is_dir, $rel_spec) = @{$ref};
if (!$is_dir)
{
my $filespec = "$tmp_path/$rel_spec";
if ((stat $filespec)[9] < $age)
{

unlink $filespec;
$count++;
} else
{

}
}
}
if ($count > 0)
{
ENV_say( 2, "Deleted $count GBS tmp files");
}
}




{
my $count = 0;
my $tmp_path = ENV_get_os_tmpdir_path();
foreach my $filespec (ENV_glob( "$tmp_path/GBS*"))
{
if ((stat $filespec)[9] < $age)
{

unlink $filespec;
$count++;
} else
{

}
}
if ($count > 0)
{
ENV_say( 2, "Deleted $count OS tmp GBS files");
}
}
}


