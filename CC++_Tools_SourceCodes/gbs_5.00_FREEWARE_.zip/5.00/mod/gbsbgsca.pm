#=================================================
#
#   gbsbgsca.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbsbgsca;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSBGSCA_init
GBSBGSCA_do
);
}




use glo::env;
use glo::list;
use glo::slurp;
use mod::plugin;
use mod::scaglo;
use mod::scadef;
use mod::scafile;
use mod::gbsbgscasub;
use mod::gbsbgglo;




sub GBSBGSCA_init($);
sub GBSBGSCA_do($$$$);

sub do_file_pre();
sub do_file_run($);
sub do_file_post($);

sub find_settings_filespec(@);












my $PLUGIN_NICE_NAME;

my $PLUGIN_NAME_UC;	    # PCLINT, QAC, QACPP, CPPTEST
my $GBSEXT_PLUGIN_PATH;
my $GBSEXT_PLUGIN_REL;
my $GBS_PLUGIN_PATH;	    # $GBS_PLUGIN_ROOT/$plugin/$plugin_rel

my $P_INIT_FUNC;	    # once
my $P_SET_FUNC;		    # once
my $P_PRE_FUNC;		    # for every file
my $P_RUN_FUNC;		    # for every file
my $P_POST_FUNC;	    # for every file

my @COMPILER_SETTINGS;




my $SRC_PATH;
my $COMPONENT;
my @SRC_FILES;
my @OUT_FILES;

my @PRINTABLE_OUT_FILES;




sub GBSBGSCA_init($)
{
($COMPONENT,
) = @_;

($GBSEXT_PLUGIN_REL, $GBSEXT_PLUGIN_PATH) = PLUGIN_get_main_envs( $GBS::AUDIT_PLUGIN);
$PLUGIN_NAME_UC = uc $GBS::AUDIT_PLUGIN;
$GBS_PLUGIN_PATH = PLUGIN_get_gbs_path( $GBS::AUDIT_PLUGIN);

ENV_say( 1, "$PLUGIN_NAME_UC: $GBS::AUDIT ($GBS::BUILD_PLUGIN) Initialising...");

$PLUGIN_NICE_NAME = SCADEF_get_section_items( $GBS::AUDIT_PLUGIN, SETUP => 'NICE_NAME');




{
my %plugin_refs = (

cpptest	=> [ qw( cpptest cpptest ) ],
pclint	=> [ qw( pclint  pclint  ) ],
qac		=> [ qw( qac     prqa    ) ],
qacpp	=> [ qw( qac     prqa    ) ],
);
my ($lib_dir, $package) = @{$plugin_refs{$GBS::AUDIT_PLUGIN}};

my $eval_string = qq( use lib "$GBS::SCRIPTS_PATH/plugins/audit/$lib_dir/bin"; use $package; );
eval $eval_string;  	## no critic
ENV_sig( F => "'eval' failed", $eval_string, $@)
if ($@);

my %package_refs = (

cpptest => [ \&CPPTEST_init,    \&CPPTEST_set,  \&CPPTEST_pre,  \&CPPTEST_run,  \&CPPTEST_post ],
pclint  => [ \&PCLINT_init,	    \&PCLINT_set,   \&PCLINT_pre,   undef,	    \&PCLINT_post  ],
prqa    => [ \&PRQA_init,	    \&PRQA_set,	    \&PRQA_pre,	    undef,	    \&PRQA_post    ],
);




($P_INIT_FUNC, $P_SET_FUNC, $P_PRE_FUNC, $P_RUN_FUNC, $P_POST_FUNC) = @{$package_refs{$package}};
}




SCAGLO_init( $GBS::AUDIT_PLUGIN, $GBSEXT_PLUGIN_REL, $PLUGIN_NICE_NAME);    # Includes SCAMSG_init






{
my ($unkn_msg_func, $plugin_msg_filespecs_ref, $plugin_read_msg_file_func, $must_create_helpfile) =
$P_INIT_FUNC->( $GBS::AUDIT_PLUGIN, $GBSEXT_PLUGIN_PATH, $GBS_PLUGIN_PATH);	# e.g.: PCLINT_init, PRQA_init, CCPTEST_init

SCAGLO_validate( $unkn_msg_func, $plugin_msg_filespecs_ref, $plugin_read_msg_file_func, $must_create_helpfile);
}

my @quiet_paths = GBSBGSCASUB_init( $GBS::AUDIT_PLUGIN, $COMPONENT, undef);




my @gbs_defaults;
{
my $quiet_format = SCADEF_get_section_items( $GBS::AUDIT_PLUGIN, OPTION_FORMATS => 'QUIET_FORMAT');
if (defined $quiet_format)
{
foreach my $quiet_path (@quiet_paths)
{
push @gbs_defaults, sprintf( $quiet_format, ENV_enquote( ENV_os_paths( $quiet_path)));
}
}
}




{
my $compiler_format = SCADEF_get_section_items( $GBS::AUDIT_PLUGIN, OPTION_FORMATS => 'COMPILER_FORMAT');


if (defined $compiler_format)
{
my @files = sprintf( $compiler_format, $GBS::BUILD);
push @files, sprintf( $compiler_format, $GBS::BUILD_PLUGIN)
if ($GBS::BUILD_PLUGIN ne $GBS::BUILD);
my $compiler_filespec = find_settings_filespec( @files);

if (defined $compiler_filespec)
{
my ($via_format, $via_filetype) = SCADEF_get_section_items( $GBS::AUDIT_PLUGIN, SETUP => 'VIA_FORMAT');


@COMPILER_SETTINGS = ( sprintf( $via_format, ENV_shortest_paths( undef, $compiler_filespec)) );
}
} else
{
ENV_sig( I => "No 'COMPILER_SETTINGS' defined in SCADEF for $GBS::AUDIT");
}

}




$P_SET_FUNC->( \@COMPILER_SETTINGS, \@gbs_defaults);    # e.g.: PCLINT_settings, PRQA_settings
}





sub GBSBGSCA_do($$$$)
{
my ($src_files,		# List
$unix_style_search,	# bool
$out_files_ref,		# May be undef
$command_data_refs_ref,	# [ [ $command_type, $command_items_ref, $ok_values, $exec_condition, $pos_arg_tokens ], ... ]

) = @_;
my $rc;



ENV_say( 1, "$PLUGIN_NAME_UC: SCA $src_files");

$SRC_PATH = ENV_cwd();
@SRC_FILES = split( / /, $src_files);
@OUT_FILES = (defined $out_files_ref) ? @{$out_files_ref} : ();




do_file_pre();




$rc = do_file_run( $command_data_refs_ref );





$rc = do_file_post( $unix_style_search)
if ($rc == 0 || $rc == 1);
if ($rc >= 2)
{
GBSBGGLO_handle_rc( $rc, \@SRC_FILES, 'SCA-Post', \@OUT_FILES);
ENV_say( 1, "$PLUGIN_NAME_UC: Could not proceed because of severe internal errors (rc=$rc)");
}

return $rc;
}




sub do_file_pre()
{




ENV_say( 1, "$PLUGIN_NAME_UC: $PLUGIN_NICE_NAME($GBSEXT_PLUGIN_REL) Analysing @SRC_FILES...");

@PRINTABLE_OUT_FILES = ();
foreach my $src_file (@SRC_FILES)
{



SCAFILE_init( $GBS::SUBSYS, $COMPONENT, $src_file);




SCAFILE_delete_files();	    # .garg .gerr .gmet .gout .html .p




push @PRINTABLE_OUT_FILES, $P_PRE_FUNC->( $SRC_PATH, $src_file);	# E.g.: PCLINT_pre, PRQA_pre
}
LIST_unique( \@PRINTABLE_OUT_FILES)
if (@SRC_FILES > 1);
}




sub do_file_run($)
{
my ($command_data_refs_ref,
) = @_;
my $rc;	    # 1 = contains FATAL warnings, 2 = Execution error




if (defined $P_RUN_FUNC)
{
$rc = $P_RUN_FUNC->( \@SRC_FILES, 1, \@OUT_FILES, $command_data_refs_ref);   # E.g.: CPPTEST_run (obsolete)
} else
{
$rc = GBSBGGLO_exec( \@SRC_FILES, 1, "@OUT_FILES", $command_data_refs_ref);
}
if ($rc != 0)
{
ENV_say( 1, "***rc=$rc");

foreach my $filespec (@PRINTABLE_OUT_FILES)
{
ENV_say( 1, "***OutFile: $filespec ***");
if (-e $filespec)
{
map { ENV_say( 0, $_) } SLURP_file( $filespec);
ENV_say( 1, "***End OutFile***");
} else
{
ENV_say( 1, "***OutFile Not Found***");
$rc = 2;
}
}
}

return $rc;
}




sub do_file_post($)
{
my ($unix_style_search,	# bool
) = @_;
my $rc = 0;	    # 1 = contains FATAL warnings, 2 = Execution error




ENV_whisper( 1, "Post Handling...");
$rc = $P_POST_FUNC->( \@SRC_FILES, $unix_style_search);	    # E.g.: PCLINT_post, PRQA_post


return $rc;
}




sub find_settings_filespec(@)
{
my @files = @_;
my $filespec;


my @dirs = (
"$GBS::ROOT_PATH/sysaudit/$GBS::AUDIT_PLUGIN",
"$GBS::SCRIPTS_PATH/plugins/audit/$GBS::AUDIT_PLUGIN",
);

foreach my $dir (@dirs)
{
foreach my $file (@files)
{
my $this_filespec = "$dir/$file";
if (-f $this_filespec)
{
$filespec = $this_filespec;
last;
}
}
last if (defined $filespec);
}
if (defined $filespec)
{
ENV_say( 1, "Using '$filespec'");
} else
{
ENV_sig( EE => "File(s) '@files' not found in (@dirs)");
}

return $filespec;
}

1;

