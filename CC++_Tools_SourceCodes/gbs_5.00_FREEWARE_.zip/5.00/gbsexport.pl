#=================================================
#
#   gbsexport.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSEXPORT @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::slurp;
use glo::flock;
use glo::genopt;
use mod::gbsenv;
use mod::gbsglo;
use mod::gbsoptenv;
use mod::validate;
use mod::cleanup;
use mod::export;




sub do_all_exports();
sub select_export_file_locs();
sub select_export(@);
sub do_export($$$);
sub prune_directory($$);
sub error(@);
sub contains_dir($$);
sub debug_keeps();




my %OUT_DIRS;



my %KEEPS;



my @EXP_REFS;

my @RES_REFS;







$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ '<*>',     'export_file_locations', 'sao',  "", [ "<Component>... and/or SUBSYS:",
". == Current Component. <empty> == <all>"] ],
[ 'i',       'ignore_errors',         'bso',   0, "Continue generation after error(s)" ],
[ 'c',       'cleanup_all',	      'bso',   0, "Delete all, independent from build" ],
[ 'show',    'show_actions',	      'bso',   0, "Show all actions" ],
);
my @genenvs = qw( APP_* );
GENOPT_set_optdefs( 'gbsexport', \@genopts,
'Fill the export and/or res directories from the Components and/or Gen or SubSystem by Build',
undef);
GENOPT_set_envdefs( \&GBSOPTENV_set, \&GBSOPTENV_print, \@genenvs);
GENOPT_parse();
}
my @EXPORT_FILE_LOCS = GENOPT_get( 'export_file_locations');
my $IGNORE_ERRORS = GENOPT_get( 'ignore_errors');
my $MUST_CLEANUP_ALL = GENOPT_get( 'cleanup_all');
my $SHOW_ACTIONS = GENOPT_get( 'show_actions');




ENV_setenv( GBS_IGNORE_ERRORS => $IGNORE_ERRORS);




VALIDATE_subsys();
my $IS_FULL_GBS = GBSGLO_subsystem_is_full_gbs( $GBS::SUBSYS);
if ($IS_FULL_GBS)
{
VALIDATE_build();
} else
{
ENV_sig( EE => "No current Build")
if ($GBS::BUILD eq '');
}
ENV_whisper( 1, "SUBSYS=$GBS::SUBSYS BUILD=$GBS::BUILD EXPORT_FILE_LOCS=(@EXPORT_FILE_LOCS)");

my $GBS_RES_SUBSYS_PATH = "$GBS::RES_PATH/$GBS::SUBSYS";

my $EXPORT_DIR_EXISTS = -d $GBS::EXPORT_PATH;
my $RESSUB_DIR_EXISTS = -d $GBS_RES_SUBSYS_PATH;

my @GBS_ALL_BUILDS = ENV_getenv('GBS_ALL_BUILDS');
my @OTHER_BUILDS = grep( $GBS::BUILD ne $_, @GBS_ALL_BUILDS);
my $NR_SPECIFIED_FILES = 0;
my $NR_COMPONENTS = 0;
my $GEN_FILE_INCLUDED = 0;




if ($RESSUB_DIR_EXISTS || $EXPORT_DIR_EXISTS)
{

my $export_fh = ($EXPORT_DIR_EXISTS) ? FLOCK_ex_wait( "$GBS::SUBSYS_PATH/.export.lck") : undef;
my $ressub_fh = ($RESSUB_DIR_EXISTS) ? FLOCK_ex_wait( "$GBS::RES_PATH/.$GBS::SUBSYS.lck") : undef;

$RC = do_all_exports();

FLOCK_unlock( $ressub_fh)
if ($RESSUB_DIR_EXISTS);
FLOCK_unlock( $export_fh)
if ($EXPORT_DIR_EXISTS);
} else
{
ENV_say( 1, "No 'res' or 'export' dir for this SybSystem '$GBS::SUBSYS'");
}

ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
}




sub do_all_exports()
{
my $rc = 0;




my @selected_export_file_locs = select_export_file_locs();
ENV_whisper( 1, "Selected: (@selected_export_file_locs)");

if (@selected_export_file_locs)
{



select_export( @selected_export_file_locs);






if ($EXPORT_DIR_EXISTS)
{
ENV_say( 1, "");
ENV_say( 1, "Handling 'EXPORT'");
if ($MUST_CLEANUP_ALL)
{
CLEANUP_export( $GBS::SUBSYS);
} else
{
prune_directory( 'EXPORT', $GBS::EXPORT_PATH);
}
$rc = do_export( 'EXPORT', $GBS::EXPORT_PATH, \@EXP_REFS);
}
if ($RESSUB_DIR_EXISTS)
{
ENV_say( 1, "");
ENV_say( 1, "Handling 'RESSUB'");
if ($MUST_CLEANUP_ALL)
{
CLEANUP_res( $GBS::SUBSYS);
} else
{
prune_directory( 'RESSUB', $GBS_RES_SUBSYS_PATH);
}
$rc = do_export( 'RESSUB', $GBS_RES_SUBSYS_PATH, \@RES_REFS);
}
} else
{
ENV_sig( W => "No Export file(s) found/selected for SubSys $GBS::SUBSYS");
}

return $rc;
}




sub select_export_file_locs( )
{
my @selected_export_file_locs;




ENV_sig( EE => "No comp directory in SubSystem '$GBS::SUBSYS'")
if ($IS_FULL_GBS && ! -d $GBS::COMP_PATH);

if (@EXPORT_FILE_LOCS == 0)
{
if (-f "$GBS::SUBSYS_PATH/export.gbs")
{
$GEN_FILE_INCLUDED = 1;
push @selected_export_file_locs, 'SUBSYS:';
}
if ($IS_FULL_GBS)
{
foreach my $component (@GBS::ALL_COMPONENTS)
{
if (-f "$GBS::COMP_PATH/$component/export.gbs")
{
push @selected_export_file_locs, $component;
$NR_COMPONENTS++;
}
}
}
} else
{
foreach my $export_file_loc (@EXPORT_FILE_LOCS)
{
if (substr( $export_file_loc, -1, 1) eq ':')
{



if ($export_file_loc eq 'SUBSYS:')
{
ENV_sig( EE => "No export.gbs in SUBSYS:'!")
if (! -f "$GBS::SUBSYS_PATH/export.gbs");
$GEN_FILE_INCLUDED = 1;
push @selected_export_file_locs, 'SUBSYS:';
}
} else
{



my $component = $export_file_loc;
if ($IS_FULL_GBS)
{
if ($component eq '.')
{
$component = $GBS::COMPONENT;
ENV_sig( EE => 'No current Component!')
if ($component eq '');
}
ENV_sig( EE => "Component '$component' does not exist!")
if (! defined $GBS::ALL_COMPONENTS{$component});
ENV_sig( EE => "No export.gbs in Component '$component'!")
if (! -f "$GBS::COMP_PATH/$component/export.gbs");
ENV_sig( EE => "Component '$component' does not build for Build '$GBS::BUILD'!")
if (! GBSGLO_component_does_build( $GBS::SUBSYS, $component, $GBS::BUILD));
push @selected_export_file_locs, $component;
$NR_COMPONENTS++;
} else
{
ENV_sig( EE => "Cannot specify Component(s) ($component) in Non-GBS SubSys");
}
}
}
}

return @selected_export_file_locs;
}






sub select_export(@)
{
my @selected_export_file_locs = @_;	# Component and/or 'SUBSYS:'

ENV_say( 1, 'Parsing export(s)...');
foreach my $export_file_loc (@selected_export_file_locs)
{
my $export_type = ($export_file_loc eq 'SUBSYS:') ? 'SUBSYS' : 'CMP';

my @specs_refs = EXPORT_parse( $export_type, $export_file_loc, $GBS::BUILD);









my $skip_this_component = ($export_type eq 'CMP' &&
! GBSGLO_component_does_build( $GBS::SUBSYS, $export_file_loc, $GBS::BUILD));
ENV_whisper( 1, "Skipped Component '$export_file_loc' (Does not generate for this Build)")
if ($skip_this_component);
foreach my $specs_ref (@specs_refs)
{
my ($selected, $destination, $to_dir, $chmods_dir, @from_refs) = @{$specs_ref};





my @destinations = ($destination eq 'ANY') ? qw( EXPORT RESSUB) : ($destination);




my $must_export_this_dir;
if ($selected)
{
if (contains_dir( $to_dir, [ '*', $GBS::BUILD ]))
{
$must_export_this_dir = 1;
} elsif (contains_dir( $to_dir, \@OTHER_BUILDS ))
{
$must_export_this_dir = 0;
ENV_whisper( 1, "Skipped output directory '$to_dir' (Other Build)");
} else
{
$must_export_this_dir = 1;
}
} else
{
$must_export_this_dir = 0;
ENV_whisper( 1, "Skipped output directory '$to_dir' (Build Line Selector)");
}
my @dirs;
foreach my $dir (split '/', $to_dir)
{
push @dirs, $dir;
my $dir_spec = join( '/', @dirs);

foreach my $dest (@destinations)
{
if ($must_export_this_dir)
{
if (!exists $OUT_DIRS{$dest}->{$dir_spec})
{
$OUT_DIRS{$dest}->{$dir_spec} = $chmods_dir
}
}
$KEEPS{$dest}->{$dir_spec} = 1;
}
}
$to_dir =~ s/\*/$GBS::BUILD/g;




foreach my $ref (@from_refs)
{
my ($source, $to_file, $chmods_file) = @{$ref};



$NR_SPECIFIED_FILES++;

my $to_spec = ($to_dir) ? "$to_dir/$to_file" : $to_file;
map { $KEEPS{$_}->{$to_spec} = 1 } @destinations;
next if ($skip_this_component);

if ($must_export_this_dir)
{
if ($source eq 'INSTALL:')
{
my (undef, undef, undef, $command, @args) =  @{$ref};

my $dest_ref = [ $to_spec, $chmods_file, 'I', $export_type, $command, @args ];
push @EXP_REFS, $dest_ref
if ($destination eq 'EXPORT' || $destination eq 'ANY');
push @RES_REFS, $dest_ref
if ($destination eq 'RESSUB' || $destination eq 'ANY');
} else
{
my (undef, undef, undef, $from_dir, $from_file, $from_filespec) = @{$ref};


if (!contains_dir( $from_dir, \@OTHER_BUILDS))
{
if (-f $from_filespec)
{


my $dest_ref = [ $to_spec, $chmods_file, 'C', $from_filespec ];
push @EXP_REFS, $dest_ref
if ($destination eq 'EXPORT' || $destination eq 'ANY');
push @RES_REFS, $dest_ref
if ($destination eq 'RESSUB' || $destination eq 'ANY');
} else
{

error( "File not found ($source$from_file)",
"($from_filespec)");
}
} else
{
ENV_whisper( 1, "Skipped '$to_dir' <== '$from_dir/$from_file' (Other Build)");
}
}
} else
{

}
}
}
}

}





sub do_export($$$)
{
my ($destination,	    	# 'EXPORT' or 'RESSUB'
$export_path,
$export_refs_ref,
) = @_;
my $rc = 0;

ENV_whisper( 1, "* Exporting: '$destination'...");




my $out_dir_destinations_ref = $OUT_DIRS{$destination};
foreach my $to_dir (sort( keys( %{$out_dir_destinations_ref})))
{
my $new_dir = "$export_path/$to_dir";
$new_dir =~ s/\*/$GBS::BUILD/g;

if (! -d $new_dir)
{
ENV_whisper( 1, "Create Directory: $new_dir");
my $chmods = $out_dir_destinations_ref->{$to_dir};
ENV_mkdir( $new_dir, oct(751));		    # u=rwx,go=rx,o=x
map { ENV_chmod( $_, $new_dir) } split( ',', $chmods)
if ($chmods ne '');

} else
{

}
}




my $exported = 0;
my $copied = 0;
my $failed = 0;
my @copy_refs;
foreach my $ref (@{$export_refs_ref})
{
my ($to_subdir_file, $to_chmods, $action) = @{$ref};
$exported++;
my $to_file = "$export_path/$to_subdir_file";
my $replicated;
if ($action eq 'I')
{



my (undef, undef, undef, $export_type, $command, @args) = @{$ref};
unlink $to_file;
ENV_whisper( 1, "  Executing INSTALL: $command, @args");
ENV_pushd( ($export_type eq 'SUBSYS') ? $GBS::SUBSYS_PATH : $GBS::BUILD_PATH);
my $rc = ENV_system( [ $command, @args ], undef);
ENV_whisper( 0, '');
if ($rc == 0)
{
if (-e $to_file)
{
$replicated = 1;
} else
{
$replicated = -1;
ENV_say( 1, "  INSTALL Outputfile missing / not created ($to_subdir_file)");
}
} else
{
$replicated = -1;
ENV_say( 1, "  INSTALL Failed (rc=$rc)");
}
ENV_popd();
} else
{



my (undef, undef, undef, $from_file) =  @{$ref};
ENV_say( 1, "  $to_subdir_file <== $from_file")
if ($SHOW_ACTIONS);
if (ENV_file_is_same( $from_file, $to_file))
{
$replicated = 0;
} else
{
$replicated = (ENV_copy_file( $from_file, $to_file, 'E')) ? 1 : -1;
}
}
if ($replicated == -1)
{
$failed++;
} elsif ($replicated == 1)
{
$copied++;
}




if ($replicated == 1)
{
ENV_chmod( 'ugo=r', $to_file);
map { ENV_chmod( $_, $to_file) } split( ',', $to_chmods)
if ($to_chmods ne '');
}
}

if ($failed > 0)
{
ENV_sig( W => "$failed copies failed");
$rc = 2;
}




if ($IS_FULL_GBS)
{
my $gen_file = ($GEN_FILE_INCLUDED) ? " and 'SUBSYS:'" : '';
ENV_say( 1, "$NR_COMPONENTS Component(s)$gen_file. $NR_SPECIFIED_FILES file(s) specified, $exported exported, $copied copied");
} else
{
ENV_say( 1, "'SUBSYS:'. $NR_SPECIFIED_FILES file(s) specified, $exported exported, $copied copied");
}

return $rc;
}




sub prune_directory($$)
{
my ($destination,	    	# 'EXPORT' or 'RESSUB'
$export_path,
) = @_;

ENV_whisper( 1, "Searching for obsolete items in $destination...");


debug_keeps()
if (ENV_is_debug());
my $keeps_ref = $KEEPS{$destination};
my @files_to_delete;
my @dirs_to_delete;
foreach my $spec_ref (SLURP_dir_tree( $export_path, 1))
{
my ($is_dir, $spec) = @{$spec_ref};

my $dir = ($is_dir) ? $spec : ENV_split_spec_p( $spec);


my $must_delete = 0;
if (grep( ENV_is_in_path( $dir, $_), @dirs_to_delete))
{
$must_delete = 1;
} elsif (!contains_dir( $spec, \@GBS_ALL_BUILDS))
{
if (!exists $keeps_ref->{$spec})
{
$must_delete = 1;
}
}
if ($must_delete)
{
if ($is_dir)
{
ENV_whisper( 1, "Must delete Dir '$spec'");
push @dirs_to_delete, $spec;
} else
{
ENV_whisper( 1, "Must delete File '$spec'");
push @files_to_delete, $spec;
}
} else
{
ENV_say( 1, "$destination: $spec")
if ($SHOW_ACTIONS);
}
}

if (@files_to_delete)
{
my $nr_files_to_delete = @files_to_delete;
foreach my $file_to_delete (@files_to_delete)
{
$file_to_delete = "$export_path/$file_to_delete";
}
my $nr_files_deleted = unlink @files_to_delete;
ENV_say( 1, "$nr_files_deleted/$nr_files_to_delete file(s) deleted");
}
if (@dirs_to_delete)
{
my $nr_dirs_to_delete = @dirs_to_delete;
my $nr_dirs_deleted = 0;
foreach my $dir (reverse( @dirs_to_delete))
{
$dir = "$export_path/$dir";
if (rmdir $dir)
{
$nr_dirs_deleted++;
} else
{
ENV_say( 1, "Unable to delete dir: '$dir'",
"- $!");
}
}
ENV_say( 1, "$nr_dirs_deleted/$nr_dirs_to_delete dir(s) deleted");
}
}




sub error(@)
{
my @msgs = @_;

if ($IGNORE_ERRORS)
{
ENV_sig( E => @msgs);
} else
{
ENV_sig( EE => @msgs);
}
}




sub contains_dir($$)
{
my ($spec,
$sub_dirs_ref) = @_;
my $contains = 0;

my $this_spec = "/$spec/";
foreach my $sub_dir (@{$sub_dirs_ref})
{
if (index( $this_spec, "/$sub_dir/") >= 0)
{
$contains = 1;
last;
}
}

return $contains;
}




sub debug_keeps()
{
foreach my $dest (qw( RESSUB EXPORT))
{
foreach my $keep (sort( keys( %{$KEEPS{$dest}})))
{
ENV_say( 0, "DBG: KEEPS: $dest => $keep => $KEEPS{$dest}->{$keep}");
}
}

foreach my $dest (qw( RESSUB EXPORT))
{
foreach my $dir (sort( keys( %{$OUT_DIRS{$dest}})))
{
ENV_say( 0, "DBG: OUT_DIRS: $dest => $dir => $OUT_DIRS{$dest}->{$dir}");
}
}
}


