#=================================================
#
#   gbsstart.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSSTART @ARGV") if ($ENV{GBSDEBUG_FILE});




use 5.016_003;
use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::spit;
use glo::genopt;
use mod::gbsenv;
use mod::gbscmd;
use mod::gbsinit;














$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ '<1>',	'root', 	   'ssm',  '!', "System / Root: '-' == none, '.' == current, '!' == CWD, '!<abs_file/dir_spec>', '!!' == CWD = GBS_ROOT_PATH" ],
[ '<2>',	'subsystem',	   'sso',   '', "SubSystem: '-' == none, '.' or '' == current" ],
[ '<3>',	'component',	   'sso',   '', "Component: '-' == none, '.' or '' == current" ],
[ 'build',	'build',	   'sso',  '.', "Build: '-' == none, '.' or '' == current" ],
[ 'audit',	'audit',	   'sso',  '.', "Audit: '-' == none, '.' or '' == current" ],
[ 'tool',	'tool',		   'sso',  '.', "Toolt: '-' == none, '.' or '' == current" ],
[ 'exec',	'execute_command', 'ssm',   '', "(GBS-)Command to execute. 'none' = OK" ],
[ 'rel',	'rel',		   'sso',  '.', "Specific GBS release.  You can also specify 'cur' or 'current'"],
);
my @genconflicts = (
[ [ '<1>' => '-' ], '=', '<2>' ],
[ [ '<1>' => '-' ], '=', '<3>' ],
[ [ '<2>' => '-' ], '=', '<3>' ],
);
GENOPT_set_optdefs( 'gbsstart', \@genopts,
'Startup GBS and execute a (GBS) command. To be used for integration of GBS in other tools',
undef);
GENOPT_set_conflicts( \@genconflicts);
GENOPT_parse();
}
my $ROOT = GENOPT_get( 'root');
my $SUBSYS = GENOPT_get( 'subsystem');
my $COMPONENT = GENOPT_get( 'component');
my $BUILD = GENOPT_get( 'build');
my $AUDIT = GENOPT_get( 'audit');
my $TOOL = GENOPT_get( 'tool');
my $EXEC = GENOPT_get( 'execute_command');
my $REL = GENOPT_get( 'rel');

$REL = ''
if ($REL eq '.' || $REL eq 'cur' || $REL eq 'current');
ENV_sig( EE => 'Cannot specify --rel=? in gbsstart')
if ($REL eq '?');




{
my @lines = GBSINIT_setup( $REL, 0);	# $full_setup




$EXEC = ENV_encode( $EXEC);
{
my @args;
push @args, $ROOT;
push @args, $SUBSYS		if ($SUBSYS ne '');
push @args, $COMPONENT		if ($COMPONENT ne '');
push @args, "--build=$BUILD"  if ($BUILD ne '' && $BUILD ne '.');
push @args, "--audit=$AUDIT"	if ($AUDIT ne '' && $AUDIT ne '.');
push @args, "--tool=$TOOL"	if ($TOOL ne '' && $TOOL ne '.');
push @args, "--exec=$EXEC";

push @lines, GBSCMD_get_full_gbs_command( gbsswr => \@args);
}




my $filespec = SPIT_tmp_script_file_nl( 'gbsstart_exec', \@lines);

$RC = ENV_system( [ $filespec ], undef);


unlink $filespec;
}

ENV_exit( $RC);




END
{
ENV_print_end_msg( 0);
}


