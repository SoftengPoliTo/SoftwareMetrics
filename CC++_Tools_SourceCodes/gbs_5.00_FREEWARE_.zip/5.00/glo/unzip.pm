#=================================================
#
#   unzip.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::unzip;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
UNZIP_all
);
}




use glo::env;
use IO::Uncompress::Unzip qw($UnzipError);
use IO::File;




sub UNZIP_all($$;$);

sub zip_error($$;$);
sub file_error($$;$);








sub UNZIP_all($$;$)
{
my ($zipfile_spec,	# .zip
$out_path,	# Must exist
$sig_on_error,	# Optional: <severity><action> IWEF  EC. Default = 'F'
) = @_;
my ($nr_files, $nr_dirs);

my $zip_fh = IO::Uncompress::Unzip->new( $zipfile_spec);
if (defined $zip_fh)
{
my $status;	# 0 = EOF, > 0 = OK, < 0 = Error
do
{
$status = $zip_fh->nextStream();
if ($status > 0)
{
my $header_ref = $zip_fh->getHeaderInfo();
my $full_name = $header_ref->{Name};

my ($rel_path, $name) = ENV_split_spec_pf( $full_name);

if ($name eq '') # dir
{



my $full_path = "$out_path/$rel_path";
ENV_mkpath( $full_path);
$nr_dirs++;
} else
{



my $dest_path = "$out_path/$rel_path";
ENV_mkpath( $dest_path);

my $destfile = "$dest_path/$name";

my $file_fh = IO::File->new( $destfile, 'w');
if (defined $file_fh)
{
my $buff;
my $nr_bytes;    # 0 = EOF, > 0 = nr bytes read, < 0 = Error
do
{
$nr_bytes = $zip_fh->read( $buff);
if ($nr_bytes > 0)
{
$file_fh->write( $buff);
} elsif ($nr_bytes < 0)
{
$status = -1;
zip_error( "UNZIP: Error while reading '$full_name", $zipfile_spec, $sig_on_error);
} else  # $nr_ bytes == 0)
{

}
} while ($nr_bytes > 0);
$file_fh->close();
if ($status > 0)
{



my $stored_time = $header_ref->{'Time'};	# Last modification date
if (utime ($stored_time, $stored_time, $destfile))
{
$nr_files++;
} else
{
file_error( "Couldn't touch $destfile", $zipfile_spec, $sig_on_error);
}
}
} else
{
file_error( "Couldn't write to $destfile", $zipfile_spec, $sig_on_error);
}
}
} elsif ($status < 0)
{
zip_error( "UNZIP: 'nextStream()' failed", $zipfile_spec, $sig_on_error);
} else # ($status == 0)
{

}
} while ($status > 0);
} else
{
zip_error( 'Cannot open zipfile for reading', $zipfile_spec, $sig_on_error);
}

return (wantarray) ? ($nr_files, $nr_dirs) : $nr_files;
}




sub zip_error($$;$)
{
my ($message,
$zipfile_spec,	# .zip
$sig_on_error,	# Optional: <severity><action> IWEF  EC. Default = 'F'
) = @_;

$sig_on_error = 'F'
if (!defined $sig_on_error);

ENV_sig( $sig_on_error => $message, "- Error: $UnzipError", "- $zipfile_spec");
}




sub file_error($$;$)
{
my ($message,
$zipfile_spec,	# .zip
$sig_on_error,	# Optional: <severity><action> IWEF  EC. Default = 'F'
) = @_;

$sig_on_error = 'F'
if (!defined $sig_on_error);

ENV_sig( $sig_on_error => $message, "- Error: $!", "- $zipfile_spec,");
}

1;

