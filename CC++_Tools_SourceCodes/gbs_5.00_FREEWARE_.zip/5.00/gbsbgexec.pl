#=================================================
#
#   gbsbgexec.pl
#
#=================================================
#   This src_file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSBGEXEC @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::args;
use glo::spit;
use mod::gbsenv;
use mod::glkb;
use mod::gbsbgglo;




sub do_glkb($$$$$);
sub get_command_args();








my $BATCH_NAME = '';	# reference to be used in logging. E.g.: gbsbuild, gbsgen_post, gbsaudit, gbsaudit_post
my $COMPONENT;
my $GBSBGJOB_SCRIPT_SPEC;	# main input-src_file






$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);

get_command_args();

{
GBSBGGLO_init( $BATCH_NAME, $COMPONENT);    # sets CWD to SRC or SUSBSYS
$RC = GBSBGGLO_main( $GBSBGJOB_SCRIPT_SPEC, [ GLKB => \&do_glkb ]);
}

ENV_exit( $RC);




END
{
ENV_print_end_msg( 0);
}




sub do_glkb($$$$$)
{
my ($src_file,		# Never a list!
$must_print_commands,
$glkb_args_ref,		# [ $glkb_type, $glkb_file, $out_filespec, $glkb_via_format ]

$out_files_ref,		#
$command_data_refs_ref,	# [ [ $command_type, $command_items_ref, $ok_values, $exec_condition, $pos_arg_tokens ], ... ]

) = @_;
my $rc = 0;


ENV_whisper( 1, "GLKB $src_file");

my ($glkb_type, $glkb_file, $out_filespec, $glkb_via_format) = @{$glkb_args_ref};







GLKB_parse( $glkb_file, $GBS::BUILD, $GBS::COMPONENT);
my ( $nr_errors, $nr_warnings, @gl_lines ) = GLKB_get_lines();
ENV_say( 1, "$nr_warnings warning(s) found while processing '$GBS::COMPONENT:$glkb_file'")
if ($nr_warnings > 0);
if ($nr_errors > 0)
{
ENV_say( 1, "$nr_errors error(s) found while processing '$GBS::COMPONENT:$glkb_file'");
$rc = 2;
GBSBGGLO_handle_rc( $rc, [ $src_file ], 'GLKB', $out_files_ref);
} else
{
if (@gl_lines == 0)
{
ENV_say( 1, "No lines in '$GBS::COMPONENT:$glkb_file'");
$rc = 2;
GBSBGGLO_handle_rc( $rc, [ $src_file ], 'GLKB', $out_files_ref);
}
}





if (@gl_lines == 1 && $gl_lines[0] eq 'DUMMY')
{




ENV_say( 1, "Test not executed because of Build suppression",
"Dummy output src_file(s) generated");
SPIT_file( $out_filespec, ("$src_file: Test not executed because of Build suppression\n"));
foreach my $out_file (@{$out_files_ref})
{
SPIT_file( $out_file, '');
}
ENV_say( 0, '-');
} else
{



my $envvar_value;
if ($glkb_type eq 'FILE')
{
foreach my $item (@gl_lines)
{
$item = ENV_join_quoted_space( $item);
}
my $glkb_filespec = "../bld/$GBS::BUILD/$glkb_file";
SPIT_file_nl( $glkb_filespec, \@gl_lines);
$glkb_filespec = ENV_enquote( $glkb_filespec);
$envvar_value = sprintf( $glkb_via_format, $glkb_filespec);
} else	#$glkb_type eq 'LIST'
{
$envvar_value = "@gl_lines";

}
GBSBGGLO_set( GBS_GLKB => $envvar_value);




$rc = GBSBGGLO_exec( $src_file, $must_print_commands, $out_files_ref, $command_data_refs_ref);
}

return $rc;
}




sub get_command_args()
{
($BATCH_NAME,
$COMPONENT,
$GBSBGJOB_SCRIPT_SPEC,
) = ARGS_get( 3, 'perl gbsbgexec.pl <BATCH_NAME> <COMPONENT> <gbg_script>', undef);

}


