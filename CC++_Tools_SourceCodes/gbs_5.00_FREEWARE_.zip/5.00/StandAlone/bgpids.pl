#=================================================
#
#   bgpids.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;









sub show_processes();
sub print_line($$);
sub find_depth($$);
sub kill_pid($);
sub get_command_args();
sub print_usage();
sub env_sig($@);
sub env_say($@);




my $RC = 0;
my $MAIN_NAME_UC;
my $PREFIX;
my $PREFIX_;
my $IS_WIN32;
my $XTERM_WIDTH;
my $XTERM_HEIGHT;

BEGIN
{
$| = 1;							# $OUTPUT_AUTOFLUSH
($MAIN_NAME_UC) = map { uc $_ } "/$0" =~ m!.*[/\\](.+)\.!;	# Extract filename and make it uppercase
$PREFIX = $MAIN_NAME_UC;
$PREFIX_ = ' ' x (length( $PREFIX) + 1);
$IS_WIN32 = ($^O eq 'MSWin32');
$XTERM_WIDTH = 100;
$XTERM_HEIGHT = 50;
if (-t STDOUT)
{
if ($IS_WIN32)
{
require Win32::Console;
import  Win32::Console;
($XTERM_WIDTH, $XTERM_HEIGHT) = Win32::Console->new()->Size();
} else
{
($XTERM_HEIGHT, $XTERM_WIDTH) = split( / /, qx(stty size));
}
}




CORE::say( '=' x ($XTERM_WIDTH - 5) . '');
}




my $PRINT_MASK = "%5s %5s %8s %s";	# pid, stime, time, cmd




my $NR_ERRORS = 0;
my $NR_WARNINGS = 0;




my $INCLUDE_ALL = 0;
my $INCLUDE_FG = 0;
my $DO_KILL = 0;
my $KILL_SIG = "";
my @KILL_PIDS;
my @USERS;
get_command_args();






=optdoc
use glo::genopt;












{
my @genopts = (
[ '<*>', 'USERS',		 'sao', "", "<empty> == current user" ],
[ 'a',   'do_all',		 'bso',  0, "Include all processes" ],
[ 'f',   'do_fg',		 'bso',	 0, "Include parent (foreground) processes" ],
[ 'k',   'process_to_kill',  'iso', "", "Kill specified process-tree" ]
);
GENOPT_set_flag_prefix( '-');
GENOPT_set_optdefs( 'bgpids', \@genopts,
"Show and/or kill background processes",
undef);
}

=cut

my %full;

my %parents;

my %childs;

my %START_PIDS;		# pids without parents

my $MAX_DEPTH = 0;

if ($IS_WIN32)
{
env_sig( I => 'This program only runs under Linux');
} else
{




my @u_users = map { "-u $_" } @USERS;
my $ps_command = "ps -f @u_users";
my @pid_lines = split( /\n/, `$ps_command`);

shift @pid_lines;	    # remove heading

foreach my $line (@pid_lines)
{

my @ps_data = split( ' ', $line, 8);
next if (@ps_data != 8);

my ($pid, $ppid) = @ps_data[1..2];
$full{$pid} = [ @ps_data ];
$parents{$pid} = $ppid;
push @{$childs{$ppid}}, $pid;
}




foreach my $child (keys %parents)
{
my $parent = $parents{$child};
next if (exists $parents{$parent});	    # skip if parent present
next if (exists $START_PIDS{$parent});	    # already exsits (we may have duplicates here)
$START_PIDS{$parent} = [0,0];
}




foreach my $start_pid (keys %START_PIDS)
{
my ($nr_procs, $nr_fg_procs) = find_depth( 0, $start_pid);
$START_PIDS{$start_pid} = [ $nr_procs, $nr_fg_procs ];

}




show_processes();




if ($DO_KILL)
{
foreach my $pid (@KILL_PIDS)
{
if (exists $parents{$pid})
{
env_say( 1, "Killing $pid with all its child processes...");
kill_pid( $pid);
} else
{
env_say( 1, "*** pid $pid must be present in the displayed list! ***\a");
}
}
}
}

exit $RC;




END
{
env_say( 1, ($?) ? "Failed ($?)" : "Done");
}




sub find_depth($$)
{
my ($index,
$pid) = @_;
my ($nr_procs, $nr_fg_procs) = (0,0);

foreach my $child (@{$childs{$pid}})
{
$MAX_DEPTH = $index
if ($index > $MAX_DEPTH);
$nr_procs++;
my $tty = $full{$child}->[5];
$nr_fg_procs++
if ($tty ne '?');




if (exists $childs{$child})
{
my @counts = find_depth( $index + 1, $child);
$nr_procs += $counts[0];
$nr_fg_procs += $counts[1];
}
}
return ($nr_procs, $nr_fg_procs);
}




sub show_processes()
{
env_say( 0, "Batch jobs for user(s) @USERS:");
env_say( 0, sprintf( "%s $PRINT_MASK\n", ' ' x ($MAX_DEPTH * 2), 'PID', 'STIME', 'TIME', 'CMD'));

foreach my $start_pid (sort( keys( %START_PIDS)))
{
my ($nr_procs, $nr_fg_procs) = @{$START_PIDS{$start_pid}};
if ($INCLUDE_ALL)
{
print_line( 0, $start_pid);
} elsif ($INCLUDE_FG)
{
print_line( 0, $start_pid)
if ($nr_procs > 1);
} else
{
print_line( 0, $start_pid)
if ($nr_procs > 1 && $nr_fg_procs == 0);
}
}
}




sub print_line($$)
{
my ($index,
$pid,
) = @_;

my $lead_char = ($index == 0) ? '=' : '-';
my $lead = (' ' x ($index * 2)) . ($lead_char x (($MAX_DEPTH - $index) * 2));

foreach my $child (@{$childs{$pid}})
{
my ($uid, undef, $ppid, $c, $stime, $tty, $time, $cmd) = @{$full{$child}};
my $text = sprintf( $PRINT_MASK, $pid, $stime, $time, "$tty $cmd");
$text = substr( "$lead $text", 0, $XTERM_WIDTH);
env_say( 0, $text);




print_line( $index + 1, $child)
if (exists $childs{$child});
}
}




sub kill_pid($)
{
my ($pid) = @_;

my $command = "kill $KILL_SIG $pid";
env_say( 1, "$command");
`$command`;

if (exists $childs{$pid})
{
foreach my $child (@{$childs{$pid}})
{
kill_pid( $child);
}
}
}




sub get_command_args()
{
if (@ARGV == 1 && $ARGV[0] =~ /^--?(h|help)$/)
{
print_usage();
exit 0;
}

my $error_count = 0;
while (scalar @ARGV > 0)
{
my $arg = shift @ARGV;

if (substr($arg, 0, 1) eq '-')
{
if ($arg eq '-f')
{
$INCLUDE_FG = 1;
} elsif ($arg eq '-a')
{
$INCLUDE_ALL = 1;
} elsif ($arg eq '-k')
{
$DO_KILL = 1;
} elsif ($arg eq '-h')
{
$error_count++;
} elsif (length $arg == 2 && substr($arg, 1) ge '1' && substr($arg, 1) le '9')
{
if (! $DO_KILL)
{
env_say( 1, "Kill-signal ($arg) needs '-k' first");
$error_count++;
}
if ($KILL_SIG eq '')
{
$KILL_SIG = $arg;
} else
{
env_say( 1, "Kill-signal ($arg) may only be specified once ($KILL_SIG)");
$error_count++;
}
} else
{
env_say( 1, "Invalid flag '$arg'");
$error_count++;
}
} else
{
if ($DO_KILL)
{
if ($arg =~ /^[0-9]+$/)
{
push @KILL_PIDS, $arg;
} else
{
env_say( 1, "pid ($arg) must me numeric");
$error_count++;
}
} else
{
push @USERS, $arg;
}
}
}

if ($DO_KILL && scalar @KILL_PIDS == 0)
{
env_say( 1, "-k requires pids to kill");
$error_count++;
}
if ($error_count > 0)
{
print_usage();
exit 2;
}

if (@USERS == 0)
{
my $user = $ENV{USER};
push @USERS, $user
if ($user);
}
}




sub print_usage()
{
env_say( 1, "Usage: bgpids [<USERS>] [-f] [-k [-1..9] <pids>]");
}






sub env_sig($@)
{
my ($sig,		# <severity><action> IWEF  EC. May be undef or ''
@lines_or_refs
) = @_;

if (defined $sig && $sig ne '')
{
my @lines = map { "    $_" } map { (ref $_) ? @{$_} : $_ } @lines_or_refs;

my ($severity, $action) = split( '', $sig);

$action = ($severity eq 'F') ? 'E' : 'C'
if ($action eq '');
my $sev = index( 'IWEF', $severity);
my $sig_text = qw( INFO WARNING ERROR INTERNAL-ERROR)[$sev];




{
my $err;
$err = "Invalid Signal Severity '$severity' ($sig)"
if (!defined $sig_text);
$err = "Invalid Signal Action '$action' ($sig)"
if (index( 'EC', $action) < 0);
if (defined $err)
{
CORE::say( "$PREFIX: ** FATAL**\n    $err");
map { CORE::say( $_) } @lines;
exit 9;
}
}




CORE::say( "$PREFIX: ** $sig_text **");
map { CORE::say( $_) } @lines;




if ($sev > 0)	# WEF
{
${(undef, \$NR_WARNINGS, \$NR_ERRORS, \$NR_ERRORS)[$sev]}++;	# increment depending on severity
}




if ($action eq 'E')	    # Exit
{
if (defined $^S && $^S == 1)
{



die;
} else
{
my $exit_code = substr( '0129', $sev, 1);
exit $exit_code;
}
}
}
}




sub env_say($@)
{
my ($indent,    # 0 = no prefix, 1 = $prefix, 2 = $prefix_ - Negative = prefix_level - 1
@lines_and_or_refs
) = @_;

my @lines = map { (ref $_) ? @{$_} : $_ } @lines_and_or_refs;
if ($indent == 0)
{
map { CORE::say( $_) } @lines;
} else
{
if (abs( $indent) == 1)
{
my $first_line = shift @lines;
CORE::say( "$PREFIX: $first_line");
}
map { CORE::say( "$PREFIX_ $_") } @lines;
}
}


