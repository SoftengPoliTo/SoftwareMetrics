#=================================================
#
#   shortcut.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright © 2010-2020 - Randy Marques - All rights reserved
#=================================================
package glo::shortcut;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SHORTCUT_update
SHORTCUT_delete
);
}




BEGIN
{
if ($^O eq 'MSWin32')
{
require Win32::Shortcut;
import	Win32::Shortcut;
}
}
use glo::env;
use glo::inifile;




sub SHORTCUT_update($$$$$$$$$$);
sub SHORTCUT_delete($$);

sub win32_update_shortcut($$$$$$$);
sub lunix_update_shortcut($$$$$$$$);
sub get_shortcut_specs($$);




my $IS_WIN32 = (ENV_is_win32());
my $IS_LINUX = ! $IS_WIN32;

my $DESKTOP_PATH   = ENV_perl_paths_noquotes( ENV_get_desktop_path(0));	    # user_path
my $STARTMENU_PATH = ENV_perl_paths_noquotes( ENV_get_startmenu_path( 0));    # user_path


my %LOCATIONS = (

DESKTOP	=> $DESKTOP_PATH,
STARTMENU   => $STARTMENU_PATH,
);
my $SHORTCUT_FILETYPE = ($IS_WIN32) ? '.lnk' : '.desktop';
my $ICON_FILETYPE = ($IS_WIN32) ? '.ico' : '.png';













sub SHORTCUT_update($$$$$$$$$$)
{
my ($location_or_ref,	# DESKTOP or STARTMENU or STARTMENU/dirspec or path
$init_file,		# In case file at location does not exist. May be undef
$shortcut_title,	# Will also be the name of the file (without .type)
$type,			# 1 = Application, 2 = Link
$description,		#
$icon_spec,		#
$command_spec,		# without arguments. And no spaces! Default is cmd/xterm
$command_arguments,	# must be undef or '' if $type is Link
$working_directory,
$show,			# 0 = Normal, 1 = Maximised, -1 = Minimised
) = @_;
my $nr_updated_not_new = 0;



my @shortcut_refs = get_shortcut_specs( $location_or_ref, $shortcut_title);





if (!defined $init_file)
{
my $this_dir = ENV_split_spec_p( __FILE__);
$init_file = "$this_dir/glo/shortcut";
}
my $init_filespec = "$init_file$SHORTCUT_FILETYPE";




if (defined $type)
{
ENV_sig( F => "type ($type) must be 'Application' or 'Link'")
if ($type ne 'Application' && $type ne 'Link');
ENV_sig( F => "Command args must be undef or '' if type == 'Link'")
if ($type eq 'Link' && defined $command_arguments && $command_arguments ne '');
}




{
my ($dir, $file, $type) = ENV_split_spec_pnt( $icon_spec);
$type = $ICON_FILETYPE
if ($type eq '');


$icon_spec = "$dir/$file$type";

}




ENV_sig( F => "show ($show) must be 0, 1 or -1")
if (defined $show && ($show > 1 || $show < -1));




foreach my $ref (@shortcut_refs)
{
my ($location, $shortcut_filespec) = @{$ref};





my $is_new = 0;
if (! -f $shortcut_filespec)
{
my $from_file = ENV_split_spec_n( $shortcut_filespec);
ENV_say( 1, "Creating new '$from_file' Shortcut on $location...");

if (ENV_copy_file( $init_filespec, $shortcut_filespec, 'E'))
{
ENV_chmod( 'a+x', $shortcut_filespec);
ENV_chmod( 'u+w', $shortcut_filespec);
}
$is_new = 1;
}




my $updated;
if ($IS_WIN32)
{
$updated = win32_update_shortcut( $ref, $description, $icon_spec,
$command_spec, $command_arguments, $working_directory, $show);
} else
{
$updated = lunix_update_shortcut( $ref, $type, $shortcut_title, $description, $icon_spec,
$command_spec, $command_arguments, $working_directory);
}
$nr_updated_not_new++
if ($updated && !$is_new);
}

return $nr_updated_not_new;
}







sub win32_update_shortcut($$$$$$$)
{
my ($location_ref,		# [ $location, $shortcut_spec ]
$description,
$icon_spec,
$command_spec,		# without arguments. default ('') is %WINDIR%\system32\cmd.exe
$command_arguments,
$working_directory,
$show,			# 0 = Normal, 1 = Maximised, -1 = Minimised
) = @_;

my @updated;

my ($location, $shortcut_spec) = @{$location_ref};

my $link = Win32::Shortcut->new();
if ($link->Load( $shortcut_spec))
{




my $writable = (-w $shortcut_spec);
ENV_chmod( 'u+w', $shortcut_spec)
if (!$writable);


if (defined $command_spec)
{
$command_spec = "$ENV{WINDIR}/system32/cmd.exe"
if ($command_spec eq '');
$command_spec =~ tr/\//\\/;	    # Windows spec;
my $cur_command_spec = $link->Path();
if (lc $cur_command_spec ne lc $command_spec)
{
$link->Path( $command_spec);
push @updated, 'Path';
}
}

if (defined $command_arguments)
{
my $cur_command_arguments = $link->Arguments();
if ($cur_command_arguments ne $command_arguments)
{
$link->Arguments( $command_arguments);
push @updated, 'Arguments';
}
}

if (defined $working_directory)
{

my $cur_working_directory = $link->WorkingDirectory();
if (lc $cur_working_directory ne lc $working_directory)
{
$link->WorkingDirectory( $working_directory);
push @updated, 'WorkingDirectory';
}
}

if (defined $description)
{
my $cur_description = $link->Description();
if ($cur_description ne $description)
{
$link->Description( $description);
push @updated, 'Description';
}
}

if (defined $show)
{



$show = ($show == 0) ? 1 : ($show == 1) ? 3 : 7;
my $cur_show = $link->ShowCmd();
if ($cur_show ne $show)
{
$link->ShowCmd( $show);
push @updated, 'ShowCmd';
}
}

if (defined $icon_spec)
{
$icon_spec = ENV_os_paths( $icon_spec);
my $cur_icon_spec = $link->IconLocation;
if (lc $cur_icon_spec ne lc $icon_spec)
{
$link->IconLocation( $icon_spec);
push @updated, 'IconLocation';
}
}

if (@updated)
{
$link->Save() or ENV_sig( E => "Cannot save shortcut '$shortcut_spec'");
my $shortcut_title = ENV_split_spec_f( $shortcut_spec);
ENV_say( 1, "Shortcut '$shortcut_title' ($location) updated (@updated)");
}
ENV_chmod( 'u-w', $shortcut_spec)
if (!$writable);
$link->Close();
} else
{
ENV_sig( E => "Cannot Load shortcut '$shortcut_spec'");
}

return (@updated) ? 1 : 0;
}













sub lunix_update_shortcut($$$$$$$$)
{
my ($location_ref,		# [ $location, $shortcut_spec ]
$type,			# Application or Link
$shortcut_title,
$description,
$icon_spec,
$command_spec,		# without arguments. default ('') is xterm
$command_arguments,
$working_directory,
) = @_;

my @updated;



my ($location, $shortcut_spec) = @{$location_ref};
$command_spec = 'xterm'
if (defined $command_spec && $command_spec eq '');

if (-e $shortcut_spec)
{
my $writable = (-w $shortcut_spec);
ENV_chmod( 'u+w', $shortcut_spec)
if (!$writable);

my @parse_errors = INIFILE_load( $shortcut_spec, undef);
if (!@parse_errors)
{






my $section = 'Desktop Entry';				    # TBS must be made optional ('')
ENV_sig( EE => "[$section] not found in $shortcut_spec")
if (!INIFILE_set_sect( $section));			    # set the current section

my @action_refs = (

[ Name		=> 'EE', $shortcut_title ],
[ Type		=> 'EE', $type ],
[ Comment	=> 'EE', $description, ],
[ Description   => '',   $description, ],		    # not present in old versions
[ Icon		=> 'EE', $icon_spec ],
[ Path		=> '',   $working_directory ],		    # not present in old versions
);
foreach my $action_ref (@action_refs)
{
my ($key, $sig_on_error, $new_value) = @{$action_ref};
if (defined $new_value)
{
my $value = INIFILE_get_prop( undef, $key, $sig_on_error);	    # current section
if (defined $value)
{
push @updated, $key
if (INIFILE_update_prop( undef, $key, $new_value));  # current section

}
}
}

if (defined $command_spec || defined $command_arguments)
{
my $cur_type = INIFILE_get_prop( undef, 'Type', 'EE');	    # current section
if ($type eq 'Application')
{
my $key = 'Exec';
my $value = INIFILE_get_prop( undef, $key, '');	    # current section
if (defined $value)
{

my ($cur_command, $cur_arguments) = split( ' ', $value, 2); # assume no spaces in command!
my $exec_spec = (defined $command_spec) ? $command_spec : $cur_command;
my $new_args = (defined $command_arguments) ? $command_arguments : $cur_arguments;
$exec_spec .= ' ' . $new_args
if ($new_args ne '');

push @updated, $key
if (INIFILE_update_prop( undef, $key, $exec_spec));  # current section
} else
{
$value = INIFILE_get_prop( undef, 'URL', '');	    # current section
ENV_sig( EE => "No Exec and no URL key found", "- in $shortcut_spec\n")
if (!defined $value);
my $exec_spec = (defined $command_spec) ? $command_spec : $value;
my $new_args = (defined $command_arguments) ? $command_arguments : '';
$exec_spec .= ' ' . $new_args
if ($new_args ne '');

push @updated, $key
if (INIFILE_update_prop( undef, $key, $exec_spec));  # current section
}
} else	# $type eq 'Link' or 'Directory'
{
if (defined $command_spec)
{
my $key = 'URL';
my $value = INIFILE_get_prop( undef, $key, '');	    # current section
if (defined $value)
{
push @updated, $key
if (INIFILE_update_prop( undef, $key, $command_spec));	# current section
} else
{



$value = INIFILE_get_prop( undef, 'Exec', '');		# current section
ENV_sig( EE => "No URL and no Exec key found", "- in $shortcut_spec\n")
if (!defined $value);
push @updated, $key
if (INIFILE_replace_prop( undef, 'Exec', $key, $command_spec));	    # current section
}
}
}
}

if (@updated)
{

INIFILE_save();
my $shortcut_title = ENV_split_spec_f( $shortcut_spec);
ENV_say( 1, "Shortcut '$shortcut_title' ($location) updated (@updated)");
}
ENV_chmod( 'u-w', $shortcut_spec)
if (!$writable);

INIFILE_close();	# cleanup
} else
{
ENV_sig( E => "File '$shortcut_spec' contained parse errors", @parse_errors);
}
} else
{
ENV_sig( E => "Shortcut '$shortcut_spec' does not exist");
}

return (@updated) ? 1 : 0;
}




sub SHORTCUT_delete($$)
{
my ($location_or_ref,	# DESKTOP or STARTMENU or STARTMENU/dirspec or path
$shortcut_title,	# Is also be the name of the file (without .type)
) = @_;

foreach my $ref (get_shortcut_specs( $location_or_ref, $shortcut_title))
{
my ($location, $shortcut_filespec) = @{$ref};
if (-f $shortcut_filespec)
{
ENV_whisper( 2, "- Deleting Shortcut '$shortcut_title' from '$location");
ENV_chmod( 'u+w', $shortcut_filespec);
unlink $shortcut_filespec;
} else
{
ENV_say( 2, "- Shortcut '$shortcut_title' from '$location does not exist");
}
}
}




sub get_shortcut_specs($$)
{
my ($location_or_ref,	# DESKTOP or STARTMENU or STARTMENU/dirspec or path
$shortcut_title,	# Also the name of the file (without .type)
) = @_;
my @shortcut_refs;


my @locations = (ref $location_or_ref) ? @{$location_or_ref} : ($location_or_ref);




my $file_name = $shortcut_title;
$file_name =~ s/ /_/g
if ($IS_LINUX);




foreach my $location (@locations)
{
my $shortcut_dirspec;
if (exists $LOCATIONS{$location})
{
$shortcut_dirspec = $LOCATIONS{$location};
} elsif ($location =~ /^STARTMENU\/(.*)/)
{
$shortcut_dirspec = "$STARTMENU_PATH/$1";
if ( ! -d $shortcut_dirspec)
{
ENV_mkdir( $shortcut_dirspec);
ENV_say( 1, "Created GBS StartMenu Entry ($shortcut_dirspec)");
}
} elsif (ENV_is_abs_path( $location))
{
$shortcut_dirspec = $location;
} else
{
my @keys = keys( %LOCATIONS);
ENV_sig( F => "'$location:' must be a standard Shortcut location (@keys) or an absolue path\n");
}
my $shortcut_filespec = "$shortcut_dirspec/$file_name$SHORTCUT_FILETYPE";

push @shortcut_refs, [ $location, $shortcut_filespec];
}

return @shortcut_refs;
}

1;

