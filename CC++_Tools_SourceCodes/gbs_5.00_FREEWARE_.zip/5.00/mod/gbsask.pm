#=================================================
#
#   gbsask.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbsask;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSASK_subsys
GBSASK_component
GBSASK_audit
GBSASK_build
GBSASK_tool
);
}




use glo::env;
use glo::ask;
use mod::gbsglo;
use mod::plugin;




sub GBSASK_subsys(;$$$);
sub GBSASK_component($;$$$);
sub GBSASK_audit(;$$$);
sub GBSASK_build(;$$);
sub GBSASK_tool(;$);








sub GBSASK_subsys(;$$$)
{
my ($wanted_ss_types_ref,   # Optional. undef or [] == all
$default_build,		# Optional. Defaults to $GBS::BUILD
$default_audit,		# Optional. Defaults to $GBS::AUDIT
) = @_;
my $subsys;		# '' if no SubSys selected




my @wanted_ss_types = ENV_deref( $wanted_ss_types_ref);


$default_build = $GBS::BUILD
if (!defined $default_build);
$default_audit = $GBS::AUDIT
if (!defined $default_audit);




if (scalar @GBS::ALL_SUBSYSTEMS == 0)
{
ENV_sig( EE => "No SubSystem(s) defined - use 'sws --new' to define a SubSystem");
} elsif (scalar @GBS::ALL_SUBSYSTEMS == 1)
{
$subsys = $GBS::ALL_SUBSYSTEMS[0];
ENV_say( 1, "Single SubSystem '$subsys' taken by default");
} else
{



my @menu_refs;

foreach my $subsys (@GBS::ALL_SUBSYSTEMS)
{
my $ss_type = GBSGLO_subsystem_type( $subsys);
if (@wanted_ss_types == 0 || grep( $ss_type eq $_, @wanted_ss_types))
{
my $is_build = (GBSGLO_subsystem_does_build( $subsys, $default_build)) ? '+' : '-';
my $is_audit = (GBSGLO_subsystem_does_audit( $subsys, $default_audit, $default_build)) ? '+' : '-';
my $display_text_ref = [ $subsys, "[$ss_type$is_build$is_audit]" ];
push @menu_refs, [ $display_text_ref , $subsys ];
}
}
if (@menu_refs == 0)
{
ENV_say( 1, "No selectable SubSystem for (@wanted_ss_types)");
$subsys = '';
} elsif (@menu_refs == 1)
{
$subsys = $menu_refs[0]->[1];
ENV_say( 1, "Single selectable SubSystem '@{$menu_refs[0]->[0]}' taken by default");
} else
{
unshift @menu_refs, [ '', '' ];    # Entry 0. <None>
my $default_subsys = $GBS::SUBSYS;
my $prompt = "Select SubSystem [$default_build,$default_audit]";
my $help =   '[<SubSysType><t><a>] -> t = Active for this Build, a = Active for this Audit';
$subsys = ASK_value_from_menu( $prompt, \$default_subsys, [ 'L', 'R' ], [ @menu_refs ], $help);
}
}

return $subsys;
}




sub GBSASK_component($;$$$)
{
my ($subsys,
$default_component,	# Optional. Defaults to $GBS::COMPONENT
$default_build,		# Optional. Defaults to $GBS::BUILD
$default_audit,		# Optional. Defaults to $GBS::AUDIT
) = @_;
my $component;	# '' if no Component selected




$default_component = $GBS::COMPONENT
if (!defined $default_component);
$default_build = $GBS::BUILD
if (!defined $default_build);
$default_audit = $GBS::AUDIT
if (!defined $default_audit);




my @all_components = ($subsys eq $GBS::SUBSYS) ? @GBS::ALL_COMPONENTS : GBSGLO_components( $subsys);
if (scalar @all_components == 0)
{
ENV_sig( EE => "No Component(s) defined - use 'swc --new' to define Components");
} elsif (scalar @all_components == 1)
{
$component = $all_components[0];
ENV_say( 1, "Single Component '$component' taken by default");
} else
{



my @menu_refs = ( [ '', '' ] );    # Entry 0. <None>
foreach my $component (@all_components)
{
my $is_build = (GBSGLO_component_does_build( $subsys, $component, $default_build)) ? '+' : '-';
my $is_audit = (GBSGLO_component_does_audit( $subsys, $component, $default_audit, $default_build)) ? '+' : '-';
my $display_text_ref = [ $component,  "[$is_build$is_audit]" ];
push @menu_refs, [ $display_text_ref, $component ];
}
$default_component = ($subsys eq $GBS::SUBSYS) ? $GBS::COMPONENT : $default_component;
my $prompt = "Select Component for SubSys '$subsys' [$default_build,$default_audit]";
my $help =   '[<t><a>] -> t = Active for this Build, a = Active for this Audit';
$component = ASK_value_from_menu( $prompt, \$default_component, undef, [ @menu_refs ], $help);

}

return $component;
}




sub GBSASK_audit(;$$$)
{
my ($default_subsys,	# Optional. Defaults to $GBS::SUBSYS
$default_component,	# Optional. Defaults to $GBS::COMPONENT
$default_build,		# Optional. Defaults to $GBS::BUILD
) = @_;
my $audit = '';




$default_subsys = $GBS::SUBSYS
if (!defined $default_subsys);
$default_component = $GBS::COMPONENT
if (!defined $default_component);
$default_build = $GBS::BUILD
if (!defined $default_build);




if (scalar @GBS::AUDITS == 0)
{
ENV_sig( EE => "No Audit(s) defined - use 'swa --new' to define Audits");
} elsif (scalar @GBS::AUDITS == 1)
{
$audit = $GBS::AUDITS[0];
ENV_say( 1, "Single Audit '$audit' taken by default");
} else
{



my @audit_refs;


if ($default_subsys eq '')
{



foreach my $audit (@GBS::AUDITS)
{
push @audit_refs, [ $audit, '  ' ];
}
} elsif ($default_component eq '')
{



foreach my $audit (@GBS::AUDITS)
{
my $is_subsys = (GBSGLO_subsystem_does_audit( $default_subsys, $audit, $default_build)) ? '+' : '-';
push @audit_refs, [ $audit, "$is_subsys " ];
}
} else
{



foreach my $audit (@GBS::AUDITS)
{
my $is_subsys = (GBSGLO_subsystem_does_audit( $default_subsys, $audit, $default_build)) ? '+' : '-';
my $is_component = (GBSGLO_component_does_audit( $default_subsys, $default_component, $audit, $default_build)) ? '+' : '-';
push @audit_refs, [ $audit, "$is_subsys$is_component" ];
}
}

my @menu_refs = ( [ '', '' ] );    # Entry 0. <None>
foreach my $ref (@audit_refs)
{
my ($audit, $availability) = @{$ref};
my $plugin_name = PLUGIN_get_abt_plugin_name( $audit);
my $display_text_ref = [ $audit, "[$availability] [$plugin_name]" ];
push @menu_refs, [ $display_text_ref , $audit ];
}

my $default_audit = $GBS::AUDIT;
my $prompt = "Select Audit ($default_subsys,$default_component)";
my $help   = '[<s><c>] -> s = Active for this Subsys, c = Active for this Component';
$audit = ASK_value_from_menu( $prompt, \$default_audit, undef, [ @menu_refs ], $help);
}

return $audit;
}




sub GBSASK_build(;$$)
{
my ($default_subsys,	# Optional. Defaults to $GBS::SUBSYS
$default_component,	# Optional. Defaults to $GBS::COMPONENT
) = @_;
my $build = '';




$default_subsys = $GBS::SUBSYS
if (!defined $default_subsys);
$default_component = $GBS::COMPONENT
if (!defined $default_component);




if (scalar @GBS::BUILDS == 0)
{
ENV_sig( EE => "No Build(s) defined - use 'swb --new' to define Builds");
} elsif (scalar @GBS::BUILDS == 1)
{
$build = $GBS::BUILDS[0];
ENV_say( 1, "Single Build '$build' taken by default");
} else
{



my @build_refs;


if ($default_subsys eq '')
{



foreach my $build (@GBS::BUILDS)
{
push @build_refs, [ $build, '  ' ];
}
} elsif ($default_component eq '')
{



foreach my $build (@GBS::BUILDS)
{
my $is_subsys = (GBSGLO_subsystem_does_build( $default_subsys, $build)) ? '+' : '-';
push @build_refs, [ $build, "$is_subsys " ];
}
} else
{



foreach my $build (@GBS::BUILDS)
{
my $is_subsys = (GBSGLO_subsystem_does_build( $default_subsys, $build)) ? '+' : '-';
my $is_component = (GBSGLO_component_does_build( $default_subsys, $default_component, $build)) ? '+' : '-';
push @build_refs, [ $build, "$is_subsys$is_component" ];
}
}

my @menu_refs = ( [ '', '' ] );    # Entry 0. <None>
foreach my $ref (@build_refs)
{
my ($build, $availability) = @{$ref};
my $plugin_name = PLUGIN_get_abt_plugin_name( $build);
my $display_text_ref = [ $build, "[$availability] [$plugin_name]" ];
push @menu_refs, [ $display_text_ref , $build ];
}

my $default_build = $GBS::BUILD;
my $prompt = "Select Build ($default_subsys,$default_component)";
my $help   = '[<s><c>] -> s = Active for this Subsys, c = Active for this Component';
$build = ASK_value_from_menu( $prompt, \$default_build, undef, [ @menu_refs ], $help);
}

return $build;
}




sub GBSASK_tool(;$)
{
my ($default_subsys,	# Optional. Defaults to $GBS::SUBSYS
) = @_;
my $tool = '';




$default_subsys = $GBS::SUBSYS
if (!defined $default_subsys);




if (scalar @GBS::TOOLS == 0)
{
ENV_sig( EE => "No Tool(s) defined - use 'swt --new' to define Tools");
} elsif (scalar @GBS::TOOLS == 1)
{
$tool = $GBS::TOOLS[0];
ENV_say( 1, "Single Tool '$tool' taken by default");
} else
{



my @tool_refs;


if ($default_subsys eq '')
{



foreach my $tool (@GBS::TOOLS)
{
push @tool_refs, [ $tool, ' ' ];
}
} else
{



foreach my $tool (@GBS::TOOLS)
{
my $is_subsys = (GBSGLO_subsystem_does_tool( $default_subsys, $tool)) ? '+' : '-';
push @tool_refs, [ $tool, "$is_subsys" ];
}
}

my @menu_refs = ( [ '', '' ] );    # Entry 0. <None>
foreach my $ref (@tool_refs)
{
my ($tool, $availability) = @{$ref};
my $plugin_name = PLUGIN_get_abt_plugin_name( $tool);
my $display_text_ref = [ $tool, "[$availability] [$plugin_name]" ];
push @menu_refs, [ $display_text_ref , $tool ];
}

my $default_tool = $GBS::TOOL;
my $prompt = "Select Tool ($default_subsys)";
my $help   = '[<s>] -> s = Active for this Subsys';
$tool = ASK_value_from_menu( $prompt, \$default_tool, undef, [ @menu_refs ], $help);
}

return $tool;
}

1;

