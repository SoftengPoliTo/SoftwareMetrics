#=================================================
#
#   fix.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::fix;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
FIX_main
FIX_structure
FIX_sys_dirs
);
}




use glo::env;
use glo::ask;
use glo::file;
use glo::scm;
use mod::gbsenv;
use mod::gbsscm;
use mod::gbsglo;
use mod::dirstruct;
use mod::plugin;
use mod::system;
use mod::ssprop;
use mod::audit;
use mod::build;
use mod::tool;




sub FIX_main($$$);
sub FIX_structure();
sub FIX_sys_dirs();

sub check_dirs_and_files($);
sub check_illegal($);
sub check_missing($);
sub check_subsys_comp();
sub check_scm_control($);
sub add_files($$);
sub delete_files($$);
sub fix_execute_bit();
sub repair_ssprop_file($);
sub connect_scm();










sub FIX_main($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref,
) = @_;

GBSSCM_preset( 0);

check_dirs_and_files( 1);

if (ENV_is_linux())
{
fix_execute_bit();
}
}





sub FIX_structure()
{


return check_dirs_and_files( 0);
}




sub check_dirs_and_files($)
{
my ($must_check_scm) = @_;


ENV_say( 1, "Check GBS Directory Structure");

my $fails = 0;

if (ASK_YN( 'Check Audits, Builds and Tools?', 'N') eq 'Y')
{
$fails += FIX_sys_dirs();
}

ENV_say( 1, "Reading GBS directory structure...");
my @line_refs = DIRSTRUCT_all();








$fails += check_illegal( \@line_refs);
$fails += check_missing( \@line_refs);
if (ASK_YN( 'Check SubSystems / Components with Build/Audit combinations?', 'N') eq 'Y')
{
$fails += check_subsys_comp();
}

ENV_say( 1, "Check Directory Structure: " . (($fails == 0) ? 'Done' : 'Failed'));

if ($must_check_scm)
{
ENV_say( 0, '');
if (SCM_get_current_id())
{
$fails += check_scm_control( \@line_refs);
} else
{
ENV_say( 1, "No_SCM: Check SCM control: Not executed");
}
}

return ($fails == 0) ? 1 : 0;
}





sub FIX_sys_dirs()
{
my $failed = 0;

my @refs = (

[ 'audit',  'sysaudit', \&GBSGLO_system_audits, \@GBS::ALL_AUDITS,  \@GBS::AUDITS,  \&AUDIT_get_plugin ],
[ 'build',  'sysbuild', \&GBSGLO_system_builds, \@GBS::ALL_BUILDS,  \@GBS::BUILDS,  \&BUILD_get_plugin ],
[ 'tool',   'systool',  \&GBSGLO_system_tools,  \@GBS::ALL_TOOLS,   \@GBS::TOOLS,   \&TOOL_get_plugin  ],
);

my $changes = 0;
foreach my $ref (@refs)
{
my ($att_type, $sys_dir, $dirs_func, $gbs_all_atts_ref, $gbs_atts_ref, $get_plugin_func) = @{$ref};
my $att_type_s = $att_type . 's';		# audits, builds or tools
my $att_type_fuc = ucfirst $att_type;		# Audit, Build, Tool
my $att_type_s_fuc = $att_type_fuc . 's';	# Audits, Builds, Tools
my $plugin_type = substr( $sys_dir, 3);		# audit, build, tool

ENV_say( 1, "Checking $att_type_s_fuc...");

my %unhandled_atts = map { $_ => 1 } PLUGIN_get_all_abt_names( $plugin_type);


foreach my $dir ($dirs_func->())	    # all valid dirs in sysaudit, sysbuild or systool
{
if (exists $unhandled_atts{$dir})
{
delete $unhandled_atts{$dir};	    # Ok
} else
{
ENV_say( 1, "Found $sys_dir $att_type directory '$dir'. It is not known as a $att_type_fuc");
if (ASK_YN( "  Add it?", 'N') eq 'Y')
{



@{$gbs_all_atts_ref} = sort (@{$gbs_all_atts_ref}, $dir);
GBSENV_setenv( uc( "GBS_ALL_$att_type_s") => $gbs_all_atts_ref, 1);




my $plugin = $get_plugin_func->( $dir);




my $platform = $GBS::PLATFORM;
if (@GBS::PLATFORMS > 1)
{
$platform = ASK_value_from_menu( '  Select Platform', 0, undef, [ @GBS::PLATFORMS ]);
}
if ($platform eq $GBS::PLATFORM)
{
@{$gbs_atts_ref} = sort (@{$gbs_atts_ref}, $dir);
GBSENV_setenv( uc( "GBS_$att_type_s") => $gbs_atts_ref, 1);
SYSTEM_add_os_ref( $GBS::ROOT_PATH, '.', $att_type_s =>  [ $dir, $plugin ]);	    # audits, $builds or $tools
} else
{
SYSTEM_add_os_ref( $GBS::ROOT_PATH, $platform, $att_type_s => [ $dir, $plugin ]); # audits, $builds or $tools
}
ENV_say( 2, "$att_type_fuc '$dir' added for Platform '$platform'");
$changes++;
}
}
}
SYSTEM_write();   # Includes backup and SCM_checkout
PLUGIN_reset();

foreach my $unhandled_att (keys %unhandled_atts)
{
ENV_sig( E => "$att_type_fuc '$unhandled_att' in 'system.gbs' does not have a corresponding directory in '$sys_dir'",
"Use 'gbsedit system.gbs' to remove it.");
$failed = 1;
}
}

DIRSTRUCT_reset()
if ($changes);

return $failed;
}




sub check_illegal($)
{
my ($line_refs_ref) = @_;





my $failed = 0;




ENV_say( 1, "Checking for illegal directories/files...");
my $nr_typeerr_files = 0;
my @remove_refs;

foreach my $ref (@{$line_refs_ref})
{
my ($type, $avail, undef, $spec) = @{$ref};
if ($avail eq 'I')
{
ENV_say( 0, " - Illegal: $type $spec");
push @remove_refs, [ $type, $spec ];
} elsif ($avail eq 'i')
{
ENV_say( 0, " - TypeErr: $type $spec");
$nr_typeerr_files++;
}
}




if (@remove_refs > 0)
{
my $nr_illegal_files = @remove_refs;
ENV_sig( E => "$nr_illegal_files illegal files/directories");
$failed = delete_files( \@remove_refs, 1);	# $selective=1
}

$failed = 1
if ($nr_typeerr_files);

return $failed;
}




sub check_missing($)
{
my ($line_refs_ref) = @_;







my $dirs_ok = 1;
my $files_ok = 1;




ENV_say( 1, "Collecting missing Directories/Files...");
my @missing_dir_refs;
my @missing_file_refs;

foreach my $ref (@{$line_refs_ref})
{
my ($type, $avail, undef, $spec) = @{$ref};
if ($avail eq 'm')
{
if ($type eq 'D')
{
push @missing_dir_refs, $ref;
} else
{
push @missing_file_refs, $ref;
}
}
}




if (@missing_dir_refs)
{
$dirs_ok = 0;
ENV_say( 1, "Missing Directories:");
map {  ENV_say( 0, " - $_->[3]") } @missing_dir_refs;	# $spec
my $count = @missing_dir_refs;
ENV_say( 1, "$count Directories missing");
if (ASK_YN( 'Create missing directories?', 'Y') eq 'Y')
{
ENV_say( 1, "Creating directories...");
my @add_refs;		# [ $type, $scm, $spec ]	    # $type = 'D' or 'F'
foreach my $ref (@missing_dir_refs)
{
my ($type, $avail, $scm, $spec) = @{$ref};
push @add_refs, [ $type, $scm, $spec ];
$ref->[1] = $avail = 'M';			# update the list
}
add_files( \@add_refs, 0);		    # $selective=0
$dirs_ok = 1;
}
} else
{
ENV_say( 1, "All required Directories are present.");
}




if (@missing_file_refs)
{
my @missing_files;
foreach my $ref (@missing_file_refs)
{
my $spec = $ref->[3];
if ($spec =~ m!/ssprop\.gbs$!)
{
push @missing_files, $spec
if (!repair_ssprop_file( $spec));
} else
{
push @missing_files, $spec;
}
}
if (@missing_files)
{
$files_ok = 0;
ENV_say( 1, "Missing Files:");
map { ENV_say( 0, " - $_") } @missing_files;
my $count = @missing_files;
ENV_say( 1, "$count Files missing",
"Please create files with the gbsedit command");
}
} else
{
ENV_say( 1, "All required Files are present.");
}

return ($dirs_ok && $files_ok) ? 0 : 1;
}





sub check_subsys_comp()
{
my $failed = 0;	# Never 'fails'

ENV_say( 1, "Checking Build and Audit mismatches (Subsys <-> Component)...");

my @remove_refs;	    # [ $type, $spec ]		    #$type = 'D' or 'F'
my @add_refs;	    # [ $type, $scm, $spec ]	    # $type = 'D' or 'F'
foreach my $subsys (GBSGLO_subsystems_full_gbs())
{
foreach my $build (@GBS::ALL_BUILDS)
{



my @bld_build_paths = ENV_glob( "$GBS::ROOT_PATH/dev/$subsys/comp/*/bld/$build");

my $nr_bld_builds = @bld_build_paths;
my $sub_path = "dev/$subsys/build/$build";
if (GBSGLO_subsystem_does_build( $subsys, $build))
{
if ($nr_bld_builds == 0)
{
ENV_say( 1, "No Builds in $subsys audit for Build '$build'");
if (ASK_YN( "  Remove '$sub_path' from SubSys $subsys?", 'Y') eq 'Y')
{
push @remove_refs, [ 'D', $sub_path ];
}
}
} else
{
if ($nr_bld_builds > 0)
{
ENV_say( 1, "$nr_bld_builds Builds in $subsys comp-bld for Build '$build'");
}
}




foreach my $audit (@GBS::ALL_AUDITS)
{
my @aud_audit_build_paths = ENV_glob( "$GBS::ROOT_PATH/dev/$subsys/comp/*/aud/$audit/$build");

my $nr_aud_audit_builds = @aud_audit_build_paths;
my $sub_path = "dev/$subsys/audit/$audit/$build";
if (GBSGLO_subsystem_does_audit( $subsys, $audit, $build))
{
if ($nr_aud_audit_builds == 0)
{
ENV_say( 1, "No Audits in SubSys $subsys audit for Audit '$audit' and Build '$build'");
if (ASK_YN( "  Remove '$sub_path' from SubSys $subsys?", 'Y') eq 'Y')
{
push @remove_refs, [ 'D', $sub_path ];
}
}
} else
{
if ($nr_aud_audit_builds > 0)
{
ENV_say( 1, "$nr_aud_audit_builds Audits in SubSys $subsys comp-aud for Audit '$audit' and Build '$build'");
if (ASK_YN( "  Add '$sub_path' to SubSys $subsys?", 'Y') eq 'Y')
{
push @add_refs, [ 'D', 1, $sub_path ];
}
}
}
}
}
}




if (@remove_refs)
{
my $nr_removes = @remove_refs;
ENV_say( 1, "$nr_removes directories to remove");
delete_files( \@remove_refs, 0);	    # $selective=0
}




if (@add_refs)
{
my $nr_adds = @add_refs;
ENV_say( 1, "$nr_adds directories to add");
add_files( \@add_refs, 0);		    # $selective=0
}

return $failed;
}




sub check_scm_control($)
{
my ($line_refs_ref) = @_;





my $failed = 0;



my $nr_entries = @{$line_refs_ref};
ENV_say( 1, "Checking directories/files under SCM control may take a VERY long time",
"You may want to run a cleanup first...");
if (ASK_YN( "Check $nr_entries directories/files under SCM control?", 'N') eq 'Y')
{
ENV_chdir( $GBS::ROOT_PATH);
connect_scm();

ENV_say( 1, "Caching file_states...");
SCM_cache_states( 1);	    # 1 == force reread

ENV_say( 1, "Checking $nr_entries Directories/Files under SCM control...");
my @scm_not_allowed_refs;	# [ $type, $spec ]
my @not_scm_dir_refs;		# [ $state, $spec ]
my @not_scm_file_refs;		# [ $state, $spec ]
my %dirs_not_scm;
my $previous_display = '';
ENV_say( 1, "...");
foreach my $ref (@{$line_refs_ref})
{
my ($type, $avail, $scm, $spec) = @{$ref};







if ($spec =~ m|(.+?)/.+|)
{
my $main_dir = $1;

if ($main_dir eq 'dev')
{
if ($spec =~ m|(dev/.+?)/.+|)
{
my $subsys_dir = $1;

ENV_say( 2, "$subsys_dir...")
if ($subsys_dir ne $previous_display);
$previous_display = $subsys_dir;
} else
{
ENV_say( 2, "$main_dir...")
if ($main_dir ne $previous_display);
$previous_display = $main_dir;
}
} else
{
ENV_say( 2, "$main_dir...")
if ($main_dir ne $previous_display);
$previous_display = $main_dir;
}
}
ENV_whisper( 2, "- $spec...")
if (-d "$GBS::ROOT_PATH/$spec");
if (($avail eq 'M' || $avail eq 'm' || $avail eq 'O') && $scm >= 0)
{
my ($parent) = $spec =~ m!(.*)/.+$!;
$parent = '' if (!defined $parent);
my $state;
if ($parent && exists( $dirs_not_scm{$parent}))
{

$state = -1;
} else
{
my $full_spec = "$GBS::ROOT_PATH/$spec";
$state = SCM_get_states( $full_spec, 0);    #  -2 = nofile, -1 = notscm, 0 = Ci  1 = co
}

if ($scm == 0)
{



if ($state >= 0)	# ci or co
{

push @scm_not_allowed_refs, [ $type, $spec ];
} else		# not_scm
{
$dirs_not_scm{$spec} = 1
if ($type eq 'D');
}
} else # $scm = 1 or -1:  scm mandory if exists
{
if ($state >= 0)	# ci or co
{

} else		# not_exist = -2 not_scm = -1
{
if ($type eq 'D')
{
push @not_scm_dir_refs, [ $state, $spec ];
$dirs_not_scm{$spec} = 1;

} else
{
push @not_scm_file_refs, [ $state, $spec ];
}
}
}
}
}
ENV_whisper( 1, "Checks done");




if (@not_scm_dir_refs)
{
my $count = @not_scm_dir_refs;
ENV_say( 1, "$count Directories not under SCM control:");
my @add_refs;		# [ $type, $scm, $spec ]	    # $type = 'D' or 'F'
foreach my $ref (@not_scm_dir_refs)
{
my ($state, $spec) = @{$ref};
my $txt = ($state == -2) ? 'Missing' : 'Not SCM';
ENV_say( 0, " - $txt: $spec");
push @add_refs, [ 'D', 1, $spec ];
}
if (ASK_YN( 'Add missing Directories? (selective)', 'Y') eq 'Y')
{
add_files( \@add_refs, 1);		    # $selective=1
}
} else
{
ENV_say( 1, "All Directories under SCM control");
}




if (@not_scm_file_refs)
{
my $count = @not_scm_file_refs;
ENV_say( 1, "$count Files not under SCM control:");
my @add_refs;		# [ $type, $scm, $spec ]	    # $type = 'D' or 'F'
foreach my $ref (@not_scm_file_refs)
{
my ($state, $spec) = @{$ref};
my $txt = ($state == -2) ? 'Missing' : 'Not SCM';
ENV_say( 0, " - $txt: $spec");
push @add_refs, [ 'F', 1, $spec ]
if ($state == -1);
}
if (@add_refs)
{
if (ASK_YN( 'Add Non SCM Files? (selective)', 'Y') eq 'Y')
{
add_files( \@add_refs, 1);		    # $selective=1
}
}
my $nr_missing_files = $count - @add_refs;
if ($nr_missing_files > 0)
{
ENV_say( 1, "$nr_missing_files Files missing",
"Please create files with the gbsedit command");
}
} else
{
ENV_say( 1, "All Files under SCM control");
}




if (@scm_not_allowed_refs)
{
my $count = @scm_not_allowed_refs;
ENV_say( 1, "$count Directories/Files illegaly under SCM control:");
foreach my $ref (@scm_not_allowed_refs)
{
my ($type, $spec) = @{$ref};
ENV_say( 0, " - $type: $spec");
}
} else
{
ENV_say( 1, "No Directories/Files illegaly under SCM control");
}

ENV_say( 1, "Check SCM Done");
}

return $failed;
}






sub add_files($$)
{
my ($add_refs_ref,		# [ $type, $scm, $spec ]	    # $type = 'D' or 'F'
$selective,		# bool
) = @_;

connect_scm();

my $ans = ($selective) ? '' : 'A';
foreach my $ref (@{$add_refs_ref})
{
my ($type, $scm, $spec) = @{$ref};
$ans = ASK_YNAE( " - Add: $spec?", 'Y')
if ($ans ne 'A');
last if ($ans eq 'E');
if ($ans eq 'A' || $ans eq 'Y')
{
my $full_spec = "$GBS::ROOT_PATH/$spec";
if ($scm)
{



my $parent_dir = ENV_parent_path( $full_spec);
SCM_assert_co_dir( $parent_dir, \&DIRSTRUCT_get_ignore_spec);
}




if ($type eq 'D')
{
if ($scm)
{
SCM_add_dirs( $full_spec, \&DIRSTRUCT_get_ignore_spec, 1, 1)	# $prevalidated, $verbose
} else
{
ENV_mkdir( $full_spec);
}
} else
{
SCM_add_txt_files( $full_spec, 1, 1)				# $prevalidated, $verbose
if ($scm && -e $full_spec);
}
}
}
}




sub delete_files($$)
{
my ($remove_refs_ref,       # [ $type, $spec ]	    #$type = 'D' or 'F'
$selective,		# bool
) = @_;
my $failed = 1;

my $selective_txt = ($selective) ? ' (selective)' : '';
ENV_say( 1, "GBS can try to delete these files/directories",
"This may not always succeed",
"GBS is not able to remove them from SCM control (if applicable)");
if (ASK_YN( "Try to delete anyway?$selective_txt", 'N') eq 'Y')
{
$failed = 0;

connect_scm();

my $ans = ($selective) ? '' : 'A';
foreach my $ref (@{$remove_refs_ref})
{
my ($type, $spec) = @{$ref};
my $full_spec = "$GBS::ROOT_PATH/$spec";
if (-e $full_spec)	# may have been deleted in recursion
{
$ans = ASK_YNAE( " - Delete: $spec?", 'Y')
if ($ans ne 'A');
last if ($ans eq 'E');
if ($ans eq 'A' || $ans eq 'Y')
{
my ($nr_dirs_deleted, $nr_files_deleted, $total_scanned) = (0,0,0);
if ($type eq 'D')
{

($nr_dirs_deleted, $nr_files_deleted, $total_scanned) = FILE_del_tree( W => $full_spec, undef, 0);
if ($nr_dirs_deleted + $nr_files_deleted == $total_scanned)
{
$nr_dirs_deleted++
if (rmdir( $full_spec));
}
$total_scanned++;
} else  # $type eq 'F'
{

$total_scanned = 1;
$nr_files_deleted++
if (unlink( $full_spec));
}
my $total_deleted = $nr_dirs_deleted + $nr_files_deleted;
ENV_say( 2, "   $total_deleted/$total_scanned deleted ($spec)");
$failed = 1
if ($total_deleted != $total_scanned);
} else
{
$failed = 1;
}
}
}
}

return $failed;
}





sub fix_execute_bit()
{
if (ASK_YN( 'Fix execute-bit of .sh files? (Unix/Linux only)', 'N') eq 'Y')
{
ENV_chdir( $GBS::ROOT_PATH);
my $command = '\find . -name "*.sh" -exec \chmod +x {} \;';
ENV_say( 1, "$command");
ENV_system( $command, 0);
ENV_say( 1, "Done");
}
}




sub repair_ssprop_file($)
{
my ($spec) = @_;
my $repaired = 0;

my (undef, $subsys, $file) = split( '/', $spec);
ENV_say( 1, "Missing SubSys '$subsys' ssprop file '$spec'");
my $type;
if (-e "$GBS::ROOT_PATH/dev/$subsys/full.gbs")
{
$type = 'GBS';
} else
{
$type = 'Other';
}
if (ASK_YN( "Create for SS_TYPE '$type'?", 'Y') eq 'Y')
{
connect_scm();
my $full_filespec = SSPROP_set_type( undef, $subsys, $type);
SCM_add_txt_files( $full_filespec, 1, 1);			# $prevalidated, $verbose
$repaired = 1;
}

return $repaired;
}




sub connect_scm()
{





}

1;


