#=================================================
#
#   notify_tkx.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;




use Tkx;

use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::args;
use glo::tkx;
use glo::tkxevent;
use glo::tkxmain;
use glo::slurp;
use mod::gbsenv;
use mod::run;




sub view_and_exit();
sub get_command_args();








my ($JOB,
$JOB_RC,
$LOG_FILE_SPEC,
$JOB_STATE);







$| = 1;           # $OUTPUT_AUTOFLUSH

GBSENV_init( undef);

get_command_args();




{
my $icon_filespec;
my @label_args;
if ($JOB_RC == 0)
{
$icon_filespec = "$GBS::SCRIPTS_PATH/doc/images/gbs.gif";
} else
{
$icon_filespec = "$GBS::SCRIPTS_PATH/doc/images/gbs_test.gif";
@label_args = (-foreground => 'red');
}
TKXMAIN_new_window( "GBS Notify: $JOB",	    # Title
$icon_filespec,	    # Icon
undef,			    # Initial Geometry_ref (Width, Heigth, x, y)
undef,			    # Start Geomtry_ref (Width, Heigth, x, y)
undef);		    # Delete Window Command

TKX_bell();

TKX_new_label( $TKX::MW, "Batch Job: $JOB $JOB_STATE-END", @label_args)->g_pack();
TKX_new_label( $TKX::MW, "Exit-Status: $JOB_RC", @label_args)->g_pack();

TKX_new_label( $TKX::MW, "Logfile: $LOG_FILE_SPEC")->g_pack( -padx => 10);




my $view_button = TKX_new_button( $TKX::MW, 'View Log & Exit', \&view_and_exit);
$view_button->g_pack( -side => 'left',
-expand => 1,
-pady => 5);




my $exit_button = TKX_new_button( $TKX::MW, 'Exit', \&TKXMAIN_exit);
$exit_button->g_pack( -side => 'left',
-expand => 1,
-pady => 5);




if ($JOB_RC == 0)
{
$exit_button->g_focus;
$exit_button->configure( -default => 'active');
TKXEVENT_bind_key_return( $TKX::MW, \&TKXMAIN_exit);
} else
{
$view_button->g_focus;
$view_button->configure( -default => 'active');
TKXEVENT_bind_key_return( $TKX::MW, \&view_and_exit);
}
}




TKXMAIN_mainloop();




END
{
ENV_print_end_msg(0);
}




sub view_and_exit()
{
RUN_viewer( $LOG_FILE_SPEC);
TKXMAIN_exit();
}




sub get_command_args()
{


($JOB,
$JOB_RC,
$LOG_FILE_SPEC,
$JOB_STATE) = ARGS_get( [1,4], 'notify_tkx.pl [ <job> | test ] <job_rc> <log_filespec> <job_end>', undef);
if ($JOB eq 'test')
{
$JOB_RC = 0
if (!defined $JOB_RC);
if (!defined $LOG_FILE_SPEC)
{
($LOG_FILE_SPEC) = SLURP_dir_file_paths( $GBS::LOG_PATH, 0);		# get first logfile
$LOG_FILE_SPEC = "$GBS::LOG_PATH/gbssysaudit_test_2003-243.log"
if (!defined $LOG_FILE_SPEC);
}
$JOB_STATE = ($JOB_RC == 0) ? 'NORMAL' : 'FAILED'
if (!defined $JOB_STATE);
} else
{
ARGS_fatal( "4 Arguments expected (@ARGV)")
if (@ARGV != 4);
}
}


