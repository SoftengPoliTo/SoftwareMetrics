#=================================================
#
#   gbsxref_tkx.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;




use Tkx;

use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::slurp;
use glo::args;
use glo::tkx;
use glo::tkxglo;
use glo::tkxmain;
use glo::tkxmenu;
use glo::tkxmsg;
use glo::tkxnotebook;
use glo::tkxlistbox;
use glo::tkxmessage;
use mod::gbsenv;
use mod::gbsglo;
use mod::swglo;
use mod::swset;
use mod::scope;
use mod::validate;
use mod::gbsrc;




sub select_xref_none();
sub select_xref_scope();
sub select_xref_make();
sub create_tables($);
sub add_line($);
sub set_display_mode();
sub display_initial();
sub display($);
sub show($@);
sub select_center();
sub select_left();
sub select_right();
sub get_scope_lines();
sub get_make_lines();
sub select_build_dirs($$@);
sub set_global($);
sub about();
sub help();
sub get_args();







my $TEST_MODE = 0;




my @ALL_GBS_SUBSYSTEMS;
my $SUBSYS = set_global( $GBS::SUBSYS);
my $BUILD = set_global( $GBS::BUILD);

my $CURRENT_XREF_FUNC = \&select_xref_none;

my $CURRENT_DISPLAY_MODE = 'Full';

my @ALL;

my %ALL;

my @CUR;
my %USES;

my %USED;


my @LEFT;
my @CENTER;
my %CENTER;

my @RIGHT;

my $CURRENT_CENTER;

my $LLB;	    # Left List Box
my $RLB;	    # Right List Box
my $CLB;	    # Center List Box







$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);




get_args();




VALIDATE_root();
GBSRC_disable_write( 1);
SWGLO_set_all_platforms(1);

@ALL_GBS_SUBSYSTEMS = GBSGLO_subsystems_full_gbs();
$SUBSYS = '-'
if (! grep $SUBSYS eq $_, @ALL_GBS_SUBSYSTEMS);




{



TKXMAIN_new_window( "GBSXREF: Root/System: $GBS::ROOT_PATH",	# Title
"$GBS::SCRIPTS_PATH/doc/images/gbs.gif",	# Icon
[ 800, 500 ],				# Initial Width, Heigth
undef,					# Start Width, Heigth, x, y
undef);					# delete_window_func
$TKX::MW->g_wm_minsize( 500, 200);			# Width, Height




TKXMENU_main_add( $TKX::MW,
( [ 'File' =>
[ 'Exit'    => undef,	\&TKXMAIN_exit ] ],
[ 'Help' =>
[ 'About'   => undef,   \&about],
[ undef ],
[ 'Help'    => undef,   \&help ] ],
));




my ($nb, $np, $mp, $sp) = TKXNOTEBOOK_new( $TKX::MW, [ None  => \&select_xref_none ],
[ Make  => \&select_xref_make ],
[ Scope => \&select_xref_scope ],
);



{
;   # Empty
}




{
TKX_new_label( $mp, 'SubSystem: ')->g_pack( -side => 'left');
my $mps = TKX_new_combobox( $mp, \$SUBSYS, [ '-', @ALL_GBS_SUBSYSTEMS ],
sub { $CURRENT_XREF_FUNC->() }, -state => 'readonly');
$mps->g_pack( -side => 'left');

TKX_new_label( $mp, 'Build: ')->g_pack( -side => 'left');
my $mpt = TKX_new_combobox( $mp, \$BUILD,  [ '-', @GBS::ALL_BUILDS ],
sub { $CURRENT_XREF_FUNC->() } , -state => 'readonly');
$mpt->g_pack( -side => 'left');

TKX_new_label( $mp, 'Display Mode: ')->g_pack( -side => 'left');
my $mpd = TKX_new_combobox( $mp, \$CURRENT_DISPLAY_MODE, [ qw( Full Name.Type Name ) ],
sub { $CURRENT_XREF_FUNC->() } , -state => 'readonly');
$mpd->g_pack( -side => 'left');
}




{
TKX_new_label( $sp, 'SubSystem: ')->g_pack( -side => 'left');
my $sps = TKX_new_combobox( $sp, \$SUBSYS, [ '-', @ALL_GBS_SUBSYSTEMS ],
sub { $CURRENT_XREF_FUNC->() }, -state => 'readonly');
$sps->g_pack( -side => 'left');

TKX_new_label( $sp, 'Build: ')->g_pack( -side => 'left');
my $spt = TKX_new_combobox( $sp, \$BUILD,  [ '-', @GBS::ALL_BUILDS ],
sub { $CURRENT_XREF_FUNC->() } , -state => 'readonly');
$spt->g_pack( -side => 'left');
}




{
my $lf = $TKX::MW->new_ttk__frame( -relief => 'groove', -borderwidth => 3);
$lf->g_pack( -side => 'top', -fill => 'both', -expand => 1);

(my $llbf, $LLB) = TKXLISTBOX_new( $lf, \&select_left);
$llbf->g_pack( -side => 'left', -fill => 'both', -expand => 1);
$LLB->configure( -foreground => 'darkblue');

(my $clbf, $CLB) = TKXLISTBOX_new( $lf, \&select_center);
$clbf->g_pack( -side => 'left', -fill => 'both', -expand => 1);

(my $rlbf, $RLB) = TKXLISTBOX_new( $lf, \&select_right);
$rlbf->g_pack( -side => 'right', -fill => 'both', -expand => 1);
$RLB->configure( -foreground => 'darkblue');
}




{
my $mlf = $TKX::MW->new_ttk__frame( -relief => 'sunken', -borderwidth => 3);
$mlf->g_pack( -side => 'bottom', -fill => 'x');
TKXMSG_create( $mlf, 5, $TEST_MODE);
}
}




TKXMAIN_mainloop();

ENV_exit( $RC);




END
{

}




sub select_xref_none()
{
$CURRENT_XREF_FUNC = \&select_xref_none;
TKXLISTBOX_clear( $LLB);
TKXLISTBOX_clear( $CLB);
TKXLISTBOX_clear( $RLB);
}







sub select_xref_make()
{
$CURRENT_XREF_FUNC = \&select_xref_make;
TKXLISTBOX_clear( $LLB);
TKXLISTBOX_clear( $CLB);
TKXLISTBOX_clear( $RLB);

SWSET_subsys( $SUBSYS, '-', $BUILD, '-');
$SUBSYS = set_global( $GBS::SUBSYS);
$BUILD = set_global( $GBS::BUILD);

if ($SUBSYS ne '-' && $BUILD ne '-')
{
TKXGLO_cursor_push( 'watch');
$TKX::MW->g_grab();
my @line_refs = get_make_lines();

create_tables( \@line_refs);
set_display_mode();

display_initial();

TKXGLO_cursor_pop();
$TKX::MW->g_grab_release();
$CLB->g_focus();
}
}






sub select_xref_scope()
{
$CURRENT_XREF_FUNC = \&select_xref_scope;
TKXLISTBOX_clear( $LLB);
TKXLISTBOX_clear( $CLB);
TKXLISTBOX_clear( $RLB);

SWSET_subsys( $SUBSYS, '-', $BUILD, '-');
$SUBSYS = set_global( $GBS::SUBSYS);
$BUILD = set_global( $GBS::BUILD);
if ($SUBSYS ne '-' && $BUILD ne '-')
{
my $saved_cursor = $TKX::MW->cget( -cursor);
$TKX::MW->configure( -cursor => 'watch');
TKX_update();	    # Show the cursor
my @line_refs = get_scope_lines();

create_tables( \@line_refs);
$CURRENT_DISPLAY_MODE = 'Full';
set_display_mode();

display_initial();
display( $ALL{$GBS::COMPONENT})
if (defined $ALL{$GBS::COMPONENT});	    # select the current component if applicable

$TKX::MW->configure( -cursor => $saved_cursor);
$CLB->g_focus();
}
}




sub create_tables($)
{
my ($line_refs_ref
) =@_;

@ALL = ();
%ALL = ();
%USES = ();
%USED = ();
$CURRENT_CENTER = undef;

add_line( '<NO-REF>');

my $def_index;
foreach my $line_ref (@{$line_refs_ref})
{
my ($fc, $line) = @{$line_ref};

my $index;
if ($fc eq '-')
{
$index = add_line( $line);
if (! grep $index eq $_, @{$USES{$def_index}})
{
push @{$USES{$def_index}}, $index;
}
} elsif ($fc eq '+')
{
$index = add_line( $line);
$def_index = $index;
} else
{
$index = add_line( $line);
$def_index = undef;
}
}







while (my ($key, $valref) = each %USES)
{
foreach my $index (@{$valref})
{
push @{$USED{$index}}, $key;
}
}




my @norefs;
while (my ($key, $valref) = each %USES)
{
push @norefs, $key if (scalar @{$valref} == 0)
}
$USED{0} = [ @norefs ];

@norefs = ();
while (my ($key, $valref) = each %USED)
{
push @norefs, $key if (scalar @{$valref} == 0)
}
$USES{0} = [ @norefs ];
}




sub add_line($)
{
my ($name
) = @_;
my $index;

$index = $ALL{$name};
if (!defined $index)
{
push @ALL, $name;
$index = $#ALL;
$ALL{$name} = $index;


}

return $index;
}




sub set_display_mode()
{
if ($CURRENT_DISPLAY_MODE eq 'Full')
{
@CUR = @ALL;
} elsif ($CURRENT_DISPLAY_MODE eq 'Name.Type')
{
@CUR = ();
foreach my $line (@ALL)
{
my $cur = $line;
my $loc = rindex( $cur, '/');
$cur = substr( $cur, $loc + 1) if ($loc >= 0);
push @CUR, $cur;
}
} else #($CURRENT_DISPLAY_MODE eq 'Name')
{
@CUR = ();
foreach my $line (@ALL)
{
my $cur = $line;
my $loc = rindex( $cur, '/');
$cur = substr( $cur, $loc + 1) if ($loc >= 0);
$loc = rindex( $cur, '.');
$cur = substr( $cur, 0, $loc) if ($loc > 0);
push @CUR, $cur;
}
}
display_initial();
display( $CURRENT_CENTER)
if (defined $CURRENT_CENTER);
}




sub display_initial()
{
TKXLISTBOX_clear( $LLB);
TKXLISTBOX_clear( $CLB);
TKXLISTBOX_clear( $RLB);

@CENTER = show( $CLB, (0..$#ALL));
my $i = 0;
foreach my $index (@CENTER)
{
$CENTER{$index} = $i++;
}
}




sub display($)
{
my ($index
) = @_;

$CURRENT_CENTER = $index;

@LEFT = show( $LLB, @{$USED{$index}});

my $cindex = $CENTER{$index};
$CLB->see( $cindex);
$CLB->selection_set( $cindex);


@RIGHT = show( $RLB, @{$USES{$index}});





}




sub show($@)
{
my ($lb,
@indices
) = @_;


@indices = sort { $CUR[$a] cmp $CUR[$b] } @indices;
my @list = map { $CUR[$_] } @indices;
TKXLISTBOX_clear( $lb);
TKXLISTBOX_say( $lb, 0, undef, \@list);

return @indices;
}




sub select_center()
{
my ($sel_index) = TKXLISTBOX_get_selection_indices( $CLB);
if (defined $sel_index)
{
my $index = $CENTER[$sel_index];

display( $index);
} else
{
TKX_bell();
}
}




sub select_left()
{
my ($sel_index) = TKXLISTBOX_get_selection_indices( $LLB);
if (defined $sel_index)
{
my $index = $LEFT[$sel_index];

display( $index);
} else
{
TKX_bell();
}
}




sub select_right()
{
my ($sel_index) = TKXLISTBOX_get_selection_indices( $RLB);
if (defined $sel_index)
{
my $index = $RIGHT[$sel_index];

display( $index);
} else
{
TKX_bell();
}
}




sub get_scope_lines()
{
my @line_refs = ();


foreach my $component (@GBS::ALL_COMPONENTS)
{
push @line_refs, [ '+', $component ];
foreach my $comp (SCOPE_get_components( $GBS::SUBSYS, $component))
{
push @line_refs, [ '-', $comp ];
}
}
return @line_refs;
}




sub get_make_lines()
{
my @line_refs;


my $subsys_path = "$GBS::ROOT_PATH/dev/$GBS::SUBSYS";
my $dev_path_ = "$GBS::ROOT_PATH/dev/";
my $ext_path_ = "$GBS::ROOT_PATH/ext/";
my $res_path_ = "$GBS::ROOT_PATH/res/";
my $base_l = length $dev_path_;




my $froms = "$subsys_path/comp/*/bld/$GBS::BUILD/*.* $subsys_path/comp/*/inc/*.* $subsys_path/comp/*/loc/*.*";
foreach my $file (ENV_glob $froms)
{
push @line_refs, [ '+', 'DEV:' . substr( $file, $base_l) ];
}





my @other_builds = grep $GBS::BUILD ne $_, @GBS::ALL_BUILDS;
foreach my $subsys (@GBS::ALL_SUBSYSTEMS)
{
my $res_subsys_path = "$GBS::ROOT_PATH/res/$subsys";
if ( -d $res_subsys_path)
{
my @file_dir_refs = SLURP_dir_tree_path( $res_subsys_path, 0);
my @file_dirs = select_build_dirs( $GBS::BUILD, \@other_builds, @file_dir_refs);
foreach my $file (@file_dirs)
{
push @line_refs, [ '+', 'RES:' . substr( $file, $base_l) ];
}
}
last if ($subsys eq $GBS::SUBSYS);	    # stop after current (or before?????)
}




my @ref_files = ENV_glob( "$subsys_path/comp/*/bld/$GBS::BUILD.ref");
if (@ref_files)
{
foreach my $ref_file (@ref_files)
{
foreach my $line (SLURP_file( $ref_file))
{
my ($level, $file) = split( / /, $line, 2);
my $fc = ($level eq '0') ? '+' : '-';
if (substr($file, 0, 1) eq '#')
{
my ($unk_file) = split ' ', substr( $file, 2);
$file = "UNK:$unk_file";
} else
{
my $base = substr( $file, 0, $base_l);
if ($base eq $dev_path_)
{
$file = 'DEV:' . substr( $file, $base_l);
} elsif ($base eq $res_path_)
{
$file = 'RES:' . substr( $file, $base_l);
} elsif ($base eq $ext_path_)
{
$file = 'EXT:' . substr( $file, $base_l);
} else
{

}
}
push @line_refs, [ $fc, $file ];
}
}
} else
{
@line_refs = ();
ENV_sig( W => "No Makefiles found for build '$GBS::BUILD'");
}


return @line_refs;
}




sub select_build_dirs($$@)
{
my ($build,
$other_builds_ref,
@file_dir_refs
) = @_;
my @selection;

my @other_builds = @{$other_builds_ref};
foreach my $ref (@file_dir_refs)
{
my $file_dir = $ref->[1];
if ($file_dir =~ m!/res/.*/$build(/|$)!)
{
push @selection, $file_dir;
} else
{
push @selection, $file_dir if (!grep( $file_dir =~ m!/res/.*/$_(/|$)!, @other_builds));
}
}


return @selection;
}




sub set_global($)
{
my ($variable,
) = @_;

return ($variable eq '') ? '-' : $variable;
}




sub about()
{
TKXMESSAGE_about( "GBSXREF - About", <<ENDHERE

   This program is a part of the [u][b]GBS[/b] (Generic Build Support)[/u]
   package created by Randy Marques of Randy Marques Consultancy.
   For information: [i]http://www.genericbuildsupport.com[/i]

   [b]Copyright � 2015-2025 - Randy Marques - All rights reserved[/b]

ENDHERE
);
}




sub help()
{
TKXMESSAGE_ok( "GBSXREF - Help", 'question', <<ENDHERE
For CrossReference of Files select TAB 'Make'
For CrossReference of Components: select TAB 'Scope'

Click on an item in the center column:
- On the left the items referring TO the item in the center are displayed
- On the right the items referred BY the item in the center are displayed

ENDHERE
);
}




sub get_args()
{
(my $verbose,
$TEST_MODE,
) = ARGS_get( 2, 'perl gbsxref_tkx.pl <verbose> <test_mode>', '- Must be called via perl gbsxref.pl');

ENV_set_verbose(1)
if ($verbose)
}


