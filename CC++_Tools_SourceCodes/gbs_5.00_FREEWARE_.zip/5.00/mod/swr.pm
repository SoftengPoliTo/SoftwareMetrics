#=================================================
#
#   swr.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::swr;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SWR_reset
SWR_set
SWR_entry
SWR_exit
SWR_cleanup
);
}




use glo::env;
use glo::shell;
use glo::scm;
use mod::gbsenvs;
use mod::gbsenv;
use mod::gbsrc;
use mod::system;
use mod::gbsres;
use mod::sys;
use mod::steps;
use mod::plugin;
use mod::switch;




sub SWR_reset();
sub SWR_set();
sub SWR_entry();
sub SWR_exit();
sub SWR_cleanup();










sub SWR_reset()
{
ENV_debug( 1, "ReSet $GBS::ROOT_PATH");




GBSENVS_set_root( 0);
ENV_set_tmpdir_path( undef);
}






sub SWR_set()
{
ENV_debug( 1, "Set $GBS::ROOT_PATH");




my $plugin_root;
my $root_parent_dir;
my $log_path;
my @os_names;
my @scm_skiptypes;
my @all_skiptypes;




$plugin_root = ENV_parent_path( $GBS::ROOT_PATH) . '/.gbs';
if (!-e $plugin_root)
{
ENV_mkdir( $plugin_root);
ENV_hide_file( $plugin_root, 1);	# hide
}
$plugin_root .= '/plugins';
mkdir $plugin_root;

$root_parent_dir = ENV_parent_dir( $GBS::ROOT_PATH, -1);

$log_path = ENV_getenv_perl_path( 'GBS_LOG_ROOT') . "/$root_parent_dir";
mkdir $log_path;




@scm_skiptypes = @{SCM_preinfo( SYSTEM_get_os( $GBS::ROOT_PATH, '.', 'scms'), $GBS::ROOT_PATH)};
@all_skiptypes = ( GBSRES_skiptypes(), @scm_skiptypes, SYS_skiptypes( $GBS::ROOT_PATH) );

GBSENVS_set_root( 1, $GBS::ROOT_PATH,
[ PLUGIN_ROOT	    => $plugin_root,
ROOT_PATH	    => $GBS::ROOT_PATH,
ROOT_PARENT	    => $root_parent_dir,
LOG_PATH	    => $log_path,

SYSTEM_NAME	    => SYSTEM_get( $GBS::ROOT_PATH, 'system_name'),
SCMS		    => SYSTEM_get_os( $GBS::ROOT_PATH, '.', 'scms'),
SCMS_DATA	    => SYSTEM_get( $GBS::ROOT_PATH, 'scms_data'),
SCMS_REPOSITORY	    => SYSTEM_get_os( $GBS::ROOT_PATH, '.', 'scms_repository'),
ROOT_VERSION	    => SYSTEM_get( $GBS::ROOT_PATH, 'root_version'),
BUILDS		    => [ SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '.', 'builds') ],
AUDITS		    => [ SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '.', 'audits') ],
TOOLS		    => [ SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '.', 'tools') ],

ALL_SUBSYSTEMS	    => [ STEPS_get_subsystems_order( $GBS::ROOT_PATH) ],
ALL_BUILDS	    => [ SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '*', 'builds') ],
ALL_AUDITS	    => [ SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '*', 'audits') ],
ALL_TOOLS	    => [ SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '*', 'tools') ],

PLATFORMS	    => [ SYSTEM_get_osnames( $GBS::ROOT_PATH, 'builds') ],
SKIPTYPES	    => \@all_skiptypes,
SCM_SKIPTYPES	    => \@scm_skiptypes,
IS_INTEGRATOR	    => GBSENV_is_integrator(),
IS_ADMINISTRATOR    => GBSENV_is_administrator(),
]);
ENV_set_tmpdir_path( "$GBS::ROOT_PATH/tmp");




if ($GBS::ROOT_VERSION lt $GBS::VERSION)
{
ENV_sig( W => "GBS ROOT-VERSION ($GBS::ROOT_VERSION) mismatch ($GBS::VERSION)",
'Setup of Plugins is skipped',
"Please run gbsmaint 7 9 (Upgrade)");
} else
{
PLUGIN_check_plugins( 0);   #	$must_reset
}




GBSRC_write_base( root => $GBS::ROOT_PATH)
if (GBSENV_mode_is_interactive());
}





sub SWR_entry()
{
my $system_name = SYSTEM_get( $GBS::ROOT_PATH, 'system_name');
ENV_say( 1, "Starting $GBS::ROOT_PATH($system_name)...");




foreach my $cust_env_name (GBSENV_get_custom_envs())
{
my $all_env_name = 'GBSALL_' . substr( $cust_env_name, 4);   # replace 'GBS_' by 'GBSALL_'
my $all_value = ENV_getenv( $all_env_name);

if ($all_value ne '')
{
ENV_say( 1, "$all_env_name => $cust_env_name => $all_value");
ENV_setenv( $cust_env_name => $all_value);
}
}




foreach my $env (keys %ENV)
{
if (substr( $env, 0, 10) eq 'GBSALLEXT_')
{
my $all_value = ENV_getenv( $env);
my $cust_env_name = 'GBSEXT_' . substr( $env, 10);
ENV_say( 1, "$env => $cust_env_name => $all_value");
ENV_setenv( $cust_env_name => $all_value);
}
}





my $rc = SWITCH_entry();
ENV_sig( EE => 'Cannot continue')
if ($rc != 0);
}




sub SWR_exit()
{
my @lines;







map { ENV_setenv( $_, undef) } GBSENV_get_envs_to_reset();




my $rc = SWITCH_exit();
ENV_sig( EE => 'Cannot continue')
if ($rc != 0);
}




sub SWR_cleanup()
{
my @lines;




push @lines, map { SHELL_setenv( $_, undef) } GBSENV_get_envs_to_reset();



return @lines;
}

1;


