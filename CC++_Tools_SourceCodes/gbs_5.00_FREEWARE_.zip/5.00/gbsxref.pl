#=================================================
#
#   gbsxref.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSXREF @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::genopt;
use mod::gbsenv;
use mod::validate;
use mod::run;












$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ 't',      'test_mode',    'bso',	    0, 'Run in test-mode - Internal use' ],
);
GENOPT_set_optdefs( 'gbsxref', \@genopts,
'Show cross-references using makefiles and/or scope-files Launcher',
undef);
GENOPT_parse();
}
my $TEST_MODE = GENOPT_get( 'test_mode');
my $VERBOSE = GENOPT_get( 'verbose');

VALIDATE_root();

RUN_tkx( gbsxref_tkx => $TEST_MODE, [ $VERBOSE, $TEST_MODE ] );

ENV_exit( $RC);




END
{
ENV_print_end_msg( ($TEST_MODE) ? 1 : 0);
}


