#=================================================
#
#  admin.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::admin;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
ADMIN_main
);
}




use glo::env;
use glo::ask;
use glo::scm;
use glo::format;
use mod::gbsscm;
use mod::scmsmaint;
use mod::system;
use mod::validate;
use mod::templates;
use mod::pluginmaint;
use mod::upgrade;
use mod::fix;
use mod::gbsedit;
use mod::fcreate;




sub ADMIN_main($$$);

sub do_user_templates($$$);
sub do_create_template($$$);
sub do_copy_templates($$$);
sub check_type($$$);
sub do_edit_template($$$);

sub fix_system_gbs($$$);








sub ADMIN_main($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;

my @admin_menu_items = (
[ "Plugins (Build/Audit/Tools): Install/Replace/Remove",
\&PLUGINMAINT_dialog ],
[ "Handle User Templates",
\&do_user_templates ],
[ "Not used",
sub { ENV_say( 1, "Not used!") } ],
[ "SCMS Tools",
\&SCMSMAINT_main ],
[ "Fix system.gbs",
\&fix_system_gbs ],
[ "Not used",
sub { ENV_say( 1, "Not used!") } ],
[ "Not used",
sub { ENV_say( 1, "Not used!") } ],
[ "Not used",
sub { ENV_say( 1, "Not used!") } ],
[ "Upgrade from previous release",
\&UPGRADE_main ],
);

ENV_say( 1, "GBS Administrator Tools");

if (VALIDATE_administrator())
{
ASK_menu( 'Select function to perform', \@admin_menu_items, $entries_ref);
}
}




sub do_user_templates($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;

ENV_say( 1, "You can find and edit the Templates in GBS_SYS_PATH/templates");

GBSSCM_preset( 0);

my @template_menu_items = (
[ 'Create a new User template',
\&do_create_template ],
[ 'Copy User Templates',
\&do_copy_templates ],
[ 'Edit User Template',
\&do_edit_template ],
);

ASK_menu( 'Select function to perform', \@template_menu_items, $entries_ref);
}




sub do_create_template($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;




my $usr_templates_path = TEMPLATES_get_path( 0);
my @usr_template_files = TEMPLATES_find_all_by_path( 0); # 0 = User
ENV_say( 1, 'Current User Templates',
(@usr_template_files) ? FORMAT_cols( 0, 2, ' | ', 2, \@usr_template_files) : '<none>');




my $file = ASK_text( "Enter new name (must start with 'any')", undef, 0, [ \&check_type, undef ]);
if ($file ne '')
{
my $filespec = "$usr_templates_path/$file";
my $must_create = 'Y';
if (!-e $filespec ||
ASK_YN( '  File already exists. Overwrite?', 'Y') eq 'Y')
{



my $file_type = ENV_split_spec_t( $file);
my ($begin_com, $end_com, $start_index) = TEMPLATES_get_comment_chars( $file_type);
my $comment_ref;
if (defined $begin_com)
{
$comment_ref = [ $begin_com, $end_com, $start_index ];
} else
{
($begin_com, $end_com, $start_index) = ( '#', '', 0);
$begin_com = ASK_text( '- Enter Begin Comments character(s)', $begin_com, [ 0 , 3 ]);
if ($begin_com ne '')
{
$end_com = ASK_text( '- Enter   End Comments character(s)', $end_com,  [ 0, 3 ]);
$start_index = ASK_int( '- Enter Begin Comments start index ', $start_index,  [ 0, 2 ], [ [ 0, ] ]);
$comment_ref = [ $begin_com, $end_com, $start_index ];
TEMPLATES_add_comment_chars( $file_type, $comment_ref);
} else
{
$comment_ref = '';
ENV_say( 1, "Creating empty file...");
}
}
FCREATE_any( $filespec, $comment_ref);




SCM_assert_co_file( $filespec)
if (ASK_YN( '  Add to SCMS?', 'Y') eq 'Y');




if (ASK_YN( '  Edit the file?', 'Y') eq 'Y')
{
GBSEDIT_edit_file( $filespec, '', 1, undef);	# file_is_in_current_gbs_path
}
}
}
}




sub do_copy_templates($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;

my $usr_templates_path = TEMPLATES_get_path( 0);
my $shr_path_defined = (defined TEMPLATES_get_path( 1)) ? 1 : 0;
my @shr_template_files = TEMPLATES_find_all_by_path( 1); # 1 = Share
my @gbs_template_files = TEMPLATES_find_all_by_path( 2); # 2 = GBS
do
{



ENV_say( 1, 'Current GBS Templates',
FORMAT_cols( 0, 2, ' | ', 2, \@gbs_template_files));
ENV_say( 1, 'Current Share Templates',
($shr_path_defined) ? FORMAT_cols( 0, 2, ' | ', 2, \@shr_template_files) : '<none>');

my @usr_template_files = TEMPLATES_find_all_by_path( 0); # 0 = User
ENV_say( 1, 'Current User Templates',
(@usr_template_files) ? FORMAT_cols( 0, 2, ' | ', 2, \@usr_template_files) : '<none>');




my $source_path_index;
if ( @usr_template_files || @shr_template_files)
{
my @menu_items = (
'',			# None
);
push @menu_items, [ User => 0 ]
if (@usr_template_files);
push @menu_items, [ Share => 1 ]
if (@shr_template_files);
push @menu_items, [ GBS => 2 ];
$source_path_index = ASK_value_from_menu( 'Select Template source', 0, undef, \@menu_items);
} else
{
$source_path_index = 2;
}


my $copy_cancelled = 0;
if ($source_path_index ne '')
{



my $source_template_files_ref = ( \@usr_template_files, \@shr_template_files, \@gbs_template_files )[$source_path_index];
my $from_file = ASK_value_from_menu( 'Select Template to copy', 0, undef, [ '', @{$source_template_files_ref} ]);

if ($from_file ne '')
{
my $to_file = ASK_text( "Enter new name (must start with 'any')", $from_file, 0, [ \&check_type, undef ]);
if ($to_file ne '')
{
my $source_path = TEMPLATES_get_path( $source_path_index);
my $from_spec = "$source_path/$from_file";
ENV_say( 1, "  Copy $from_file to $to_file");
my $to_spec = "$usr_templates_path/$to_file";
my $must_copy = 'Y';
if (-e $to_spec)
{
if ($from_spec eq $to_spec)
{
ENV_say( 2, '*** Source and destination are the same ***');	# Warning?
$must_copy = 'N';
} else
{
$must_copy = ASK_YN( '  File already exists. Overwrite?', 'Y');
}
}
if ($must_copy eq 'Y')
{
SCM_assert_co_file( $to_spec)
if (ASK_YN( '  Add to SCMS?', 'Y') eq 'Y');
my $copied = ENV_copy_file( $from_spec, $to_spec, 'E');    # no exit on error
if ($copied)
{
ENV_chmod( 'u+w', $to_spec);
ENV_say( 2, 'File copied');

}
} else
{
$copy_cancelled = 1;
}
} else
{
$copy_cancelled = 1;
}
} else
{
$copy_cancelled = 1;
}
} else
{
$copy_cancelled = 1;
}
ENV_say( 1, "- Copy cancelled")
if ($copy_cancelled);
} while (ASK_YN( 'Copy more?', 'N') eq 'Y');
}





sub check_type($$$)
{
my ($values_ref,
$default_ref,
$app_data_ref,
) = @_;
my $error_txt = '';	# non empty == error



my $value = $values_ref->[0];
if ($value ne '')
{
my ($name, $type) = ENV_split_spec_nt( $value);
if ($name eq '')
{
$value = "any$type";
$values_ref->[0] = $value;
} elsif ($name !~ /^any(_[^.]+|)$/)
{
$error_txt = "Filename ($value) must be either 'any' or start with 'any_'";
} else
{
if ($type eq '')
{
$type = ENV_split_spec_t( $$default_ref);
$value = "$name$type";
$values_ref->[0] = $value;
}
}
}

return $error_txt;
}




sub do_edit_template($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;




my $usr_templates_path = TEMPLATES_get_path( 0);
my @usr_template_files = TEMPLATES_find_all_by_path( 0); # 0 = User
if (@usr_template_files)
{
my $file = ASK_value_from_menu( 'Select Template File to edit', 0, undef, [ '', @usr_template_files ]);
if ($file ne '')
{



my $filespec = "$usr_templates_path/$file";
SCM_assert_co_file( $filespec);
GBSEDIT_edit_file( $filespec, '', 1, undef);	# file_is_in_current_gbs_path
}
} else
{
ENV_say( 1, 'No files in User Templates directory',
"- $usr_templates_path");
}
}




sub fix_system_gbs($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;

ENV_say( 1, "Check system.gbs...");

GBSSCM_preset( 0);

if (SYSTEM_fix( $GBS::ROOT_PATH))
{
ENV_say( 2, "system.gbs: Internals Fixed");
} else
{
ENV_say( 2, "system.gbs: No Internals Fix needed");
}




FIX_sys_dirs();

ENV_say( 1, "Check system.gbs done");
}

1;
