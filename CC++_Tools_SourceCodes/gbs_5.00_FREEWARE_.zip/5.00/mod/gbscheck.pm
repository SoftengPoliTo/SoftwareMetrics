#=================================================
#
#   gbscheck.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbscheck;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSCHECK_root
GBSCHECK_subsys
GBSCHECK_component
GBSCHECK_build
GBSCHECK_audit
GBSCHECK_tool

GBSCHECK_system
GBSCHECK_system_platform
);
}




use glo::env;
use mod::gbsenv;
use mod::gbsglo;
use mod::swb;
use mod::swa;




sub GBSCHECK_root($$$;$);
sub GBSCHECK_subsys($$$;$);
sub GBSCHECK_component($$$$;$);
sub GBSCHECK_build($$$$$$;$);
sub GBSCHECK_audit($$$$$$$;$);
sub GBSCHECK_tool($$$$$$;$);

sub GBSCHECK_system($);
sub GBSCHECK_system_platform($;$);

sub select_item($$$$$);

sub check_gbs_subsys($);
sub check_nongbs_subsys($);
sub check_component($);



my ($THIS_CMD_EXT, $OTHR_CMD_EXT) = ENV_shell_filetype();




sub GBSCHECK_root($$$;$)
{
my ($root_path,		# '', '.', $os_or_perl_path or $roots_number
$default_root_path,	# '' or $perl_path
$root_paths_ref,
$sig_on_error,		# Optional: undef, '', 'EE', etc. Default: 'EE'
) = @_;
my $new_root_path = '';	# Perl path, no space. '' if failed

$sig_on_error = 'EE'
if (!defined $sig_on_error);

my $nr_root_paths = @{$root_paths_ref};

if ($nr_root_paths > 0)
{
$new_root_path = select_item( RootPath => $root_path, $default_root_path, $root_paths_ref, $sig_on_error);

if ($new_root_path ne '')
{
if (-d $new_root_path)
{
if (GBSCHECK_system( $new_root_path))
{
my ($is_this_platform, $is_other_platform) = GBSCHECK_system_platform( $new_root_path, $sig_on_error);
if ($is_this_platform || $is_other_platform)
{
if (!$is_this_platform)
{
ENV_sig( $sig_on_error, "Root '$root_path'",
"($new_root_path)",
'is a GBS Root on another platform');
$new_root_path = '';
}
} else
{
$new_root_path = '';
}
} else
{
ENV_sig( $sig_on_error, "Root '$root_path' ($new_root_path) is not a valid GBS Root");
$new_root_path = '';
}
} else
{
ENV_sig( $sig_on_error, "Root-path '$new_root_path' does not exist (anymore)");
$new_root_path = '';
}
}
} else
{
ENV_sig( W => 'No Root-paths defined for this user');
}

return $new_root_path;
}




sub GBSCHECK_subsys($$$;$)
{
my ($root_path,		#
$subsys,		# '', '.', $subsys or $subsystems_number
$default_subsys,	# May be ''
$sig_on_error,		# Optional: undef, '', 'EE', etc. Default: 'EE'
) = @_;
my $new_subsys = '';	# '' if failed

$sig_on_error = 'EE'
if (!defined $sig_on_error);

my @subsystems = GBSGLO_subsystems( $root_path);
my $nr_subsystems = @subsystems;

if ($nr_subsystems > 0)
{
$new_subsys = select_item( SubSys => $subsys, $default_subsys, \@subsystems, $sig_on_error);

if ($new_subsys ne '')
{
if (GBSGLO_subsystem_exists( $root_path, $new_subsys))
{
my $subsys_path = "$root_path/dev/$new_subsys";
if (GBSGLO_subsystem_is_full_gbs( $new_subsys, $root_path))
{
if (!check_gbs_subsys( $subsys_path))
{
ENV_sig( $sig_on_error, "SubSys '$new_subsys' is not a valid Full-GBS SubSystem",
"One or more GBS directories and/or files are missing");
$new_subsys = '';
}
} else
{
if (!check_nongbs_subsys( $subsys_path))
{
ENV_sig($sig_on_error, "SubSys '$new_subsys' is not a valid Non-GBS SubSystem",
"One or more GBS directories and/or files are missing");
$new_subsys = '';
}
}
} else
{
ENV_sig( $sig_on_error, "SubSys '$new_subsys' does not exist (anymore)");
$new_subsys = '';
}
}
} else
{
ENV_sig( W => "No SubSystems defined for this Root:", "  $root_path");
}

return $new_subsys;
}




sub GBSCHECK_component($$$$;$)
{
my ($root_path,		#
$subsys,		# Must be GBS Subsys
$component,		# '', '.', $component or $component_number
$default_component,	# May be ''
$sig_on_error,		# Optional: undef, '', 'EE', etc. Default: 'EE'
) = @_;
my $new_component = '';	# '' if failed

$sig_on_error = 'EE'
if (!defined $sig_on_error);

my @components = GBSGLO_components( $subsys, $root_path);
my $nr_components = @components;

if ($nr_components > 0)
{
$new_component = select_item( Component => $component, $default_component, \@components, $sig_on_error);

if ($new_component ne '')
{
if (GBSGLO_component_exists( $root_path, $subsys, $new_component))
{
my $component_path = "$root_path/dev/$subsys/comp/$new_component";
if (!check_component( $component_path))
{
ENV_sig( $sig_on_error, "Component '$new_component' is not a valid GBS Component",
"One or more GBS directories are missing");
}
} else
{
ENV_sig( $sig_on_error, "Component '$new_component' does not exist (anymore)");
$new_component = '';
}
}
} else
{
ENV_sig( W => "No Components defined for SubSys '$subsys'");
}

return $new_component;
}




sub GBSCHECK_build($$$$$$;$)
{
my ($root_path,
$subsys,	    # may be ''
$component,	    # may be ''
$build,		    # '', '.', $build or $build_number
$defaults_ref,	    # [ $default_builds, @gbsrc_builds ]
$builds_ref,	    # Allowed builds
$sig_on_error,	    # Optional: undef, '', 'EE', etc. Default: 'EE'
) = @_;
my $new_build = '';

$sig_on_error = 'EE'
if (!defined $sig_on_error);

my ($default_build, @gbsrc_builds) = @{$defaults_ref};
my $nr_builds = @{$builds_ref};


if ($nr_builds > 0)
{
my $selected_build = select_item( Build => $build, $default_build, $builds_ref, $sig_on_error);
if ($selected_build ne '')
{
$new_build = SWB_validate_dirs( $root_path, $subsys, $component, $selected_build);
if ($new_build eq '')
{
foreach my $gbsrc_build (@gbsrc_builds)
{
my $validated_build = SWB_validate_dirs( $root_path, $subsys, $component, $gbsrc_build);
if ($validated_build ne '')
{
ENV_say( 1, "Previous Build '$validated_build' taken as default");
$new_build = $validated_build;
last;
}
}
}
if ($new_build eq '')
{



if ($subsys eq '')
{
$new_build = $builds_ref->[0];
ENV_say( 1, "Build '$new_build' tentatively taken as default");
} else
{
if ($component eq '')
{
my $bld_path = "$root_path/dev/$subsys/comp/$component/bld";
foreach my $build (@{$builds_ref})
{
if (-d "$bld_path/$build")
{
$new_build = $build;
last;
}
}
}
if ($new_build eq '')
{
my $build_path = "$root_path/dev/$subsys/build";
foreach my $build (@{$builds_ref})
{
if (-d "$build_path/$build")
{
$new_build = $build;
last;
}
}
}
if ($new_build eq '')
{
ENV_say( 1, "No Build directories found");
} else
{
ENV_say( 1, "Build '$new_build' tentatively assumed");
}
}
}
}
} else
{
ENV_sig( W => "No Builds defined");
}

return $new_build;
}




sub GBSCHECK_audit($$$$$$$;$)
{
my ($root_path,
$subsys,	    # may be ''
$component,	    # may be ''
$build,
$audit,		    # '', '.', $audit or $audit_number
$defaults_ref,	    # [ $default_builds, @gbsrc_builds ]
$audits_ref,
$sig_on_error,	    # Optional: undef, '', 'EE', etc. Default: 'EE'
) = @_;
my $new_audit = '';

$sig_on_error = 'EE'
if (!defined $sig_on_error);

my ($default_audit, @gbsrc_audits) = @{$defaults_ref};
my $nr_audits = @{$audits_ref};


if ($nr_audits > 0)
{
my $selected_audit = select_item( Audit => $audit, $default_audit, $audits_ref, $sig_on_error);

if ($selected_audit ne '')
{
$new_audit = SWA_validate_dirs( $root_path, $subsys, $component, $build, $selected_audit);
if ($new_audit eq '')
{
foreach my $gbsrc_audit (@gbsrc_audits)
{
my $validated_audit = SWA_validate_dirs( $root_path, $subsys, $component, $build, $gbsrc_audit);
if ($validated_audit ne '')
{
ENV_say( 1, "Previous Audit '$validated_audit' taken as default");
$new_audit = $validated_audit;
last;
}
}
}
if ($new_audit eq '')
{



if ($subsys eq '')
{
$new_audit = $audits_ref->[0];
ENV_say( 1, "Audit '$new_audit' tentatively taken as default");
} else
{
if ($component eq '')
{
my $aud_path = "$root_path/dev/$subsys/comp/$component/aud";
foreach my $audit (@{$audits_ref})
{
if (-d "$aud_path/$audit")
{
$new_audit = $audit;
last;
}
}
}
if ($new_audit eq '')
{
my $audit_path = "$root_path/dev/$subsys/audit";
foreach my $audit (@{$audits_ref})
{
if (-d "$audit_path/$audit")
{
$new_audit = $audit;
last;
}
}
}
if ($new_audit eq '')
{
ENV_say( 1, "No Audit directories found");
} else
{
ENV_say( 1, "Audit '$new_audit' tentatively assumed");
}
}
}
}
} else
{

}

return $new_audit;
}




sub GBSCHECK_tool($$$$$$;$)
{
my ($root_path,
$subsys,	    # Not used
$component,	    # Not used
$tool,		    # '', '.', $tool or $tool_number
$default_tool,
$tools_ref,
$sig_on_error,	    # Optional: undef, '', 'EE', etc. Default: 'EE'
) = @_;
my $new_tool = '';

$sig_on_error = 'EE'
if (!defined $sig_on_error);

my $nr_tools = @{$tools_ref};

if ($nr_tools > 0)
{
$new_tool = select_item( Tool => $tool, $default_tool, $tools_ref, $sig_on_error);
} else
{
ENV_sig( W => "No Tools defined");
}

return $new_tool;
}




sub select_item($$$$$)
{
my ($item_name,	    # RootPath, SubSys, Component, Build, Audit, Tool
$item,		    # $root_path, $subsys, $component, $build, $audit, $tool
$default_item,
$item_list_ref,
$sig_on_error,
) = @_;
my $new_item = '';

my $nr_list_items = @{$item_list_ref};

if ($item eq '.' || $item eq '')
{
if ($default_item eq '')
{



if ($item eq '')
{
if ($nr_list_items == 1)
{
$new_item = $item_list_ref->[0];
ENV_say( 1, "No current $item_name",
"Single $item_name '$new_item' taken by default");
}
} else
{
ENV_sig( W => "No current $item_name");
}
} else
{
$new_item = $default_item;
}
} elsif ($item =~ /^\d+$/)
{



my $item_number = $item;
if ($item_number >= 1 && $item_number <= $nr_list_items)
{

$new_item = $item_list_ref->[$item_number - 1];
} else
{
ENV_sig( $sig_on_error, "Numeric $item_name-selection ($item_number) must be 1-$nr_list_items");
}
} else
{



if (grep( $item eq $_, @{$item_list_ref}))
{
$new_item = $item;
} else
{
my $error_text = '';
if (GBSENV_mode_is_interactive() && grep( /^$item/, @{$item_list_ref}) )
{
my @items = grep( /^$item/, @{$item_list_ref});
if (@items == 1)
{
$new_item = $items[0];
ENV_say( 1, "$item_name name $item expanded to $new_item");
} else
{
$error_text = "Ambiguous $item_name '$item'. (@items). $item_name-List:";
}
} else
{
$error_text = "$item_name '$item' not found in $item_name-List:";
}
if ($error_text ne '')
{
my $list = '  ' . join( ', ', @{$item_list_ref});
my @list = (length($list) < 80) ? ($list) : map { "  $_" } @{$item_list_ref};
ENV_sig( $sig_on_error, $error_text, @list);
}
}
}

return $new_item;
}




sub GBSCHECK_system($)
{
my ($root_path) = @_;


return ( -f "$root_path/system.gbs" &&
-d "$root_path/dev" &&
-d "$root_path/ext" &&
-d "$root_path/res");
}




sub GBSCHECK_system_platform($;$)
{
my ($root_path,
$sig_on_error,	    # Default = 'E'
) = @_;
my ($for_current_platform, $for_other_platform) = ( 0, 0 );	# bool


$sig_on_error = 'E'
if (!defined $sig_on_error);

if (-f "$root_path/switch.gbs$THIS_CMD_EXT")
{
$for_current_platform = 1;
}
if (wantarray)
{
if (-f "$root_path/switch.gbs$OTHR_CMD_EXT")
{
$for_other_platform = 1;
} else
{
ENV_sig( $sig_on_error => "Cannot determine Platform for Root:", "  $root_path")
if (!$for_current_platform);
}
return ($for_current_platform, $for_other_platform);
} else
{
return $for_current_platform;
}
}





sub check_gbs_subsys($)
{
my ($subsys_path) = @_;

return ( -d "$subsys_path/comp" &&
-d "$subsys_path/build" &&
-d "$subsys_path/audit");
}





sub check_nongbs_subsys($)
{
my ($subsys_path) = @_;

return ( -d "$subsys_path/app" &&
-d "$subsys_path/build" &&
-d "$subsys_path/audit");
}




sub check_component($)
{
my ($component_path) = @_;

return ( -d "$component_path/src" &&
-d "$component_path/loc" &&
-d "$component_path/bld");
}

1;


