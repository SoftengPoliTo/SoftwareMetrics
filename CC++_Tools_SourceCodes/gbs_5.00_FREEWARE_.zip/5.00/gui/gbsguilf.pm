#=================================================
#
#  gbsguilf.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package gui::gbsguilf;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSGUILF_create
);
}




use Tkx;

use glo::env;

use glo::tkx;
use glo::tkxglo;
use glo::tkxmenu;
use glo::tkxevent;
use glo::tkxdirtree;
use glo::tkxmessage;
use mod::swset;
use mod::audit;
use mod::gbsscm;
use gui::gbsguiexec;
use gui::gbsguifile;




sub GBSGUILF_create($);

sub set_build_cbbox();
sub set_audit_cbbox();
sub set_subsys_cbbox();
sub set_component_cbbox();
sub build_changed();
sub audit_changed();
sub subsystem_changed();
sub component_changed();
sub sub_dir_changed();
sub left_click($$$);
sub double_left_click($$$);
sub right_click($$$);
sub execute_inter($$@);
sub execute_direct($$@);
sub execute_prompt($$@);
sub set_global($);
sub show_dir_tree($);








my @TAG_REFS = (

[ skiptypes => join( '|', @GBS::SKIPTYPES), 'grey',	undef ],
[ usr	=> qw/\.usr$/,			'red',	undef ],
);





my $LF;

my $BUILD = set_global( $GBS::BUILD);
my $AUDIT = set_global( $GBS::AUDIT);
my $SUBSYS = set_global( $GBS::SUBSYS);
my $COMPONENT = set_global( $GBS::COMPONENT);

my $SUB_DIR = 'src';	    # . src loc inc build audit dat sav opt
my $CURRENT_PATH;	    # Current Path
my $DT;			    # DirTree
my $RCM;		    # Righ Click Menu
my @RCM_ITEM_REFS;	    # Right Click items.

my @RCM_COMMAND_REFS = (



[ 'gbsbuild'	=> \@RCM_ITEM_REFS,	\&execute_direct, 'gbsbuild' ],
[ 'gbsbuild @ARGS'	=> \@RCM_ITEM_REFS,	\&execute_prompt, 'gbsbuild' ],
[ 'gbsmake'		=> \@RCM_ITEM_REFS,	\&execute_direct, 'gbsmake'  ],
[ 'gbsmake @ARGS'	=> \@RCM_ITEM_REFS,	\&execute_prompt, 'gbsmake'  ],
[ 'gbsmake -r'	=> \@RCM_ITEM_REFS,	\&execute_direct, 'gbsmake', '--r' ],
[ 'gbsmake -r @ARGS'=> \@RCM_ITEM_REFS,	\&execute_prompt, 'gbsmake', '--r' ],
[ 'gbsaudit'	=> \@RCM_ITEM_REFS,	\&execute_direct, 'gbsaudit' ],
[ 'gbsaudit @ARGS'	=> \@RCM_ITEM_REFS,	\&execute_prompt, 'gbsaudit' ],
[ 'gbsedit'		=> \@RCM_ITEM_REFS,	\&execute_direct, 'gbsedit'  ],
[ 'gbsedit --nco'	=> \@RCM_ITEM_REFS,	\&execute_direct, 'gbsedit', '--nco' ],
[ 'gbsedit @ARGS'	=> \@RCM_ITEM_REFS,	\&execute_prompt, 'gbsedit'  ],
[ 'gbsscm state'	=> \@RCM_ITEM_REFS,	\&execute_direct, 'gbsscm_ state'    ],
[ 'gbsscm @ARGS'	=> \@RCM_ITEM_REFS,	\&execute_prompt, 'gbsscm_ ""'       ],
[ undef ],
[ 'New Directory'	=> \@RCM_ITEM_REFS,	\&execute_inter,  'newdir*'  ],		# '*' == must refresh
[ 'New File'	=> \@RCM_ITEM_REFS,	\&execute_inter,  'newfile*' ],		# '*' == must refresh
[ 'Delete'		=> \@RCM_ITEM_REFS,	\&execute_inter,  'delete*'  ],		# '*' == must refresh
[ 'proto'		=> \@RCM_ITEM_REFS,	\&execute_direct, 'proto*'   ],		# '*' == must refresh
[ undef ],
[ 'Execute'		=> \@RCM_ITEM_REFS,	\&execute_direct, 'execute' ],
[ 'Execute @ARGS'	=> \@RCM_ITEM_REFS,     \&execute_prompt, 'execute' ],
[ undef ],
[ 'Navigate here'	=> \@RCM_ITEM_REFS,     \&execute_direct, 'navigate' ],
[ 'Terminal here'	=> \@RCM_ITEM_REFS,     \&execute_direct, 'terminal' ],
);

my %RC_COMMANDS = (

gbsbuild	    => [ 1, 1, 1, undef, 1 ],
gbsmake	    => [ 1, 1, 1, undef, 1 ],
gbsaudit	    => [ 1, 1, 1, undef, 1 ],
gbsedit	    => [ 1, 1, 1,     1, 1 ],
gbsscm	    => [ 1, 0, 1, undef, 0 ],
New_File	    => [ 0, 0, 0,     1, 1 ],
New_Directory   => [ 0, 0, 0,     1, 1 ],
Delete	    => [ 0, 0, 1, undef, 0 ],
proto	    => [ 1, 1, 1,     1, 1 ],
Execute	    => [ 1, 1, 1,     1, 1 ],
Navigate	    => [ 1, 0, 0,     1, 0 ],
Terminal	    => [ 1, 0, 0,     1, 0 ],
);

my $BUILDS_CB;
my $AUDITS_CB;
my $SUBSYS_CB;
my $COMPONENTS_CB;

my @GBS_SUBSYS_WIDGETS;    # Enable/Disable: Select Components widget
my @GBS_SUBDIR_WIDGETS;    # Enable/Disable: '.', src, glo, loc, etc

my %LAST_SUBDIRS;





sub GBSGUILF_create($)
{
($LF,	    # Left Frame
) = @_;






my $top_frame = $LF->new_ttk__frame( -borderwidth => 3);
$top_frame->g_pack( -side => 'top', -fill => 'x');

(my $dirtree_frame, $DT) = TKXDIRTREE_new( $LF, 2, undef);	    # $select_mode == multiple
$dirtree_frame->g_pack( -side => 'bottom', -fill => 'both', -expand => 1);
TKXEVENT_bind_mouse_left_click_1( $DT, \&left_click);
TKXEVENT_bind_mouse_left_click_2( $DT, \&double_left_click);
TKXEVENT_bind_mouse_right_click_1( $DT, \&right_click);

my $subdir_frame = $LF->new_ttk__frame( -borderwidth => 3);
$subdir_frame->g_pack( -side => 'left', -fill => 'x');




GBSSCM_preset(0);




my $components_label_cbbox;
my @table_refs = (










[ [ label   => 'System Name: ' ],
[ var	    => \$GBS::SYSTEM_NAME ] ],
[ [ label   => 'System Root: ' ],
[ var	    => \$GBS::ROOT_PATH ] ],
[ [ label   => 'Build: ' ],
[ combo   => \$BUILD, \$BUILDS_CB, \&build_changed ],
[ '' ] ],
[ [ label   => 'Audit: ' ],
[ combo   => \$AUDIT, \$AUDITS_CB, \&audit_changed ],
[ '' ] ],
[ [ label   => 'SubSystem: ' ],
[ combo   => \$SUBSYS, \$SUBSYS_CB, \&subsystem_changed ],
[ label   => 'Type: ' ],
[ var	    => \$GBS::SSTYPE, undef, (-width => 6) ] ],
[ [ label   => 'Component: ', \$components_label_cbbox ],
[ combo   => \$COMPONENT, \$COMPONENTS_CB, \&component_changed ],
[ '' ] ],
);
TKXGLO_create_table( $top_frame, [ qw( R L R L) ], \@table_refs);
@GBS_SUBSYS_WIDGETS = ( $components_label_cbbox );




foreach my $sub_dir (qw( . src loc inc build audit dat sav opt))
{
my $cb = TKX_new_radiobutton( $subdir_frame, $sub_dir, \$SUB_DIR, $sub_dir, \&sub_dir_changed);
$cb->g_pack( -side => 'left', -fill => 'x', -expand => 1);
push @GBS_SUBDIR_WIDGETS, $cb;
}




set_build_cbbox();
set_audit_cbbox();
set_subsys_cbbox();
set_component_cbbox();
sub_dir_changed();




$RCM = TKXMENU_popup_add( $LF, file_rc => @RCM_COMMAND_REFS);
}




sub set_build_cbbox()
{
$BUILDS_CB->configure( -values => [ '-', @GBS::BUILDS ]);
}




sub set_audit_cbbox()
{
$AUDITS_CB->configure( -values => [ '-', @GBS::AUDITS ]);
}




sub set_subsys_cbbox()
{
$SUBSYS_CB->configure( -values => [ '-', @GBS::ALL_SUBSYSTEMS ]);
}




sub set_component_cbbox()
{
$COMPONENTS_CB->configure( -values => [ '-', @GBS::ALL_COMPONENTS ]);
}




sub build_changed()
{
$BUILD = set_global( SWSET_build( $BUILD));
sub_dir_changed();
}




sub audit_changed()
{
$AUDIT = set_global( SWSET_audit( $AUDIT));
sub_dir_changed();
}




sub subsystem_changed()
{
$SUBSYS = set_global( SWSET_subsys( $SUBSYS, '', '', ''));	# Component, Build, Audit
$BUILD = set_global( $GBS::BUILD)
if ($GBS::BUILD ne $BUILD);
$AUDIT = set_global( $GBS::AUDIT)
if ($GBS::AUDIT ne $AUDIT);
$COMPONENT = set_global( $GBS::COMPONENT);

$SUB_DIR = '.';
if ($GBS::SSTYPE eq 'GBS')
{
set_component_cbbox();
component_changed();
}
sub_dir_changed();
}




sub component_changed()
{
$COMPONENT = set_global( SWSET_component( $COMPONENT, '', ''));	# Build, Audit
$BUILD = set_global( $GBS::BUILD)
if ($GBS::BUILD ne $BUILD);
$AUDIT = set_global( $GBS::AUDIT)
if ($GBS::AUDIT ne $AUDIT);

$SUB_DIR = '.';
if ($GBS::COMPONENT ne '')
{
my $sub_dir = $LAST_SUBDIRS{$GBS::SUBSYS}->{$GBS::COMPONENT};
if (defined $sub_dir)
{
$SUB_DIR = $sub_dir;
} else
{
$SUB_DIR = 'src';
}
}

sub_dir_changed();
}




sub sub_dir_changed()
{
TKX_update();

if ($GBS::SUBSYS ne '')
{
if ($GBS::SSTYPE eq 'GBS')
{
if ($GBS::COMPONENT ne '')
{
my $sub_dirs = $SUB_DIR;	# may be '.'
if ($SUB_DIR eq 'build')
{
if ($GBS::BUILD ne '')
{
$sub_dirs = "bld/$GBS::BUILD";
} else
{
$sub_dirs = "bld";
}
} elsif ($SUB_DIR eq 'audit')
{
if ($GBS::AUDIT ne '' && $GBS::BUILD ne '')
{
$sub_dirs = "aud/$GBS::AUDIT/$GBS::BUILD";
} else
{
$sub_dirs = "aud";
}
}
$CURRENT_PATH = "$GBS::ROOT_PATH/dev/$GBS::SUBSYS/comp/$GBS::COMPONENT/$sub_dirs";
$CURRENT_PATH =~ s!/\.$!!;
$LAST_SUBDIRS{$GBS::SUBSYS}->{$GBS::COMPONENT} = $SUB_DIR;
} else  # $GBS::COMPONENT eq ''
{
$CURRENT_PATH = "$GBS::ROOT_PATH/dev/$GBS::SUBSYS/comp";
}
} else	# $GBS::SSTYPE ne 'GBS'
{
$CURRENT_PATH = "$GBS::ROOT_PATH/dev/$GBS::SUBSYS";
}
} else  # $GBS::SUBSYS ne ''
{
$CURRENT_PATH = $GBS::ROOT_PATH;
}




if ($GBS::SSTYPE eq 'GBS')
{
$COMPONENTS_CB->configure( -state => 'readonly');
} else
{
$SUB_DIR = '.';
$COMPONENTS_CB->configure( -state => 'disabled');
}
if ($GBS::COMPONENT ne '')
{
foreach my $widget (@GBS_SUBSYS_WIDGETS, @GBS_SUBDIR_WIDGETS)   # Component & Subdirs
{
$widget->configure( -state => 'normal');
}
TKXMENU_enable_item( menu_bar => 'gbs', 1);
} else
{
$SUB_DIR = '.';
foreach my $widget (@GBS_SUBSYS_WIDGETS, @GBS_SUBDIR_WIDGETS)   # Component & Subdirs
{
$widget->configure( -state => 'disable');
}
TKXMENU_enable_item( menu_bar => 'gbs', 0);
}




if (-d $CURRENT_PATH)
{
show_dir_tree( 0);
} else
{
$CURRENT_PATH = $GBS::ROOT_PATH;
if ($GBS::SUBSYS ne '')
{
$CURRENT_PATH .= "/dev/$GBS::SUBSYS";
if ($GBS::COMPONENT ne '')
{
$CURRENT_PATH .= "/comp/$GBS::COMPONENT";
}
}
}
ENV_chdir( $CURRENT_PATH);

}




sub left_click($$$)
{
my ($widget,
$x,
$y,
) = @_;


my @selection_refs = TKXDIRTREE_get_selection( $widget);

TKXDIRTREE_clear_selection( $widget)
if (@selection_refs);
}




sub double_left_click($$$)
{
my ($widget,
$x,
$y,
) = @_;


my @selection_refs = TKXDIRTREE_get_selection( $widget);
my @items = map { $_->[0] } @selection_refs;
if (@selection_refs == 1)
{
my ($item, $itemspec) = @{$selection_refs[0]};
my $type = ENV_split_spec_t( $itemspec);
if (-d $itemspec)
{
TKXMESSAGE_ok( Double_Left_Click => 'info', "No action defined for directories ($item)");
} elsif (ENV_is_command_type( $type))
{
ENV_pushd( $CURRENT_PATH);
GBSGUIEXEC_direct( 'Execute', 'execute', $itemspec);
ENV_popd();
} else
{
TKXMESSAGE_ok( Double_Left_Click => 'info', "No action defined for '$item'");
}
} elsif (@selection_refs != 0)
{
TKXMESSAGE_ok( Double_Left_Click => 'info', "No action defined for multiple selection (@items)");
}
}




sub right_click($$$)
{
my ($widget,
$x,
$y,
) = @_;


my @selection_refs = TKXDIRTREE_get_selection( $widget);

my $nr_selections = @selection_refs;

my $contains_dirs = 0;
my $contains_hidden_files = 0;
{
my $skiptypes_re = join( '|', @GBS::SKIPTYPES);

foreach my $ref (@selection_refs)
{

my ($item, $itemspec) = @{$ref};

$contains_hidden_files = 1
if ($item =~ /$skiptypes_re/ || ENV_hide_file( $itemspec, undef));
$contains_dirs = 1
if (-d $itemspec);
}
}





foreach my $ref (@RCM_ITEM_REFS)
{
my ($menu_id, $command_label, $entry_nr) = @{$ref};


$command_label =~ s/^New /New_/;
my ($command, @args) = split( ' ', $command_label);

my ($no_hidden_files_allowed, $no_dirs_allowed, $min_items, $max_items, $more_checks_needed) = @{$RC_COMMANDS{$command}};

my $pre_enable = 1;
if ($no_hidden_files_allowed && $contains_hidden_files)
{
$pre_enable = 0;
} elsif ($no_dirs_allowed && $contains_dirs)
{
$pre_enable = 0;
} elsif (defined $min_items && $nr_selections < $min_items)
{
$pre_enable = 0;
} elsif (defined $max_items && $nr_selections > $max_items)
{
$pre_enable = 0;
}

my $must_enable = 0;
if ($pre_enable)
{
if ($more_checks_needed)
{

$must_enable = 0;
if ($command eq 'gbsbuild')
{
$must_enable = 1
if ($SUB_DIR eq 'src' );
} elsif ($command eq 'gbsmake')
{
my $first_arg = (defined $args[0]) ? $args[0] : '';
$must_enable = 1
if (($SUB_DIR eq 'src'   && $first_arg eq '-r') ||
($SUB_DIR eq 'build' && $first_arg ne '-r'));
} elsif ($command eq 'gbsaudit')
{
if ($SUB_DIR eq 'src')
{
$must_enable = 1;
if ($GBS::AUDIT ne '' && $GBS::BUILD ne '' &&
-e "$GBS::COMPONENT_PATH/aud/$GBS::AUDIT/$GBS::BUILD")
{
my @allowed_types = AUDIT_get_src_types( $GBS::AUDIT);
foreach my $ref (@selection_refs)
{
my $type = ENV_split_spec_t( $ref->[0]);    # $item
if (!grep( $type eq $_, @allowed_types))
{
$must_enable = 0;
last;
}
}
} else
{
$must_enable = 0;
}
}
} elsif ($command eq 'gbsedit')
{
$must_enable = 1
if (-T $selection_refs[0]->[1])	# $itemspec
} elsif ($command eq 'New_Directory')
{
$must_enable = 1
if ($SUBSYS ne '' && $GBS::SSTYPE ne 'GBS' ||
grep( $SUB_DIR eq $_, qw( dat sav opt)));
} elsif ($command eq 'New_File')
{
$must_enable = 1
if ($SUBSYS ne '' && $GBS::SSTYPE ne 'GBS' ||
grep( $SUB_DIR eq $_, qw( src loc inc dat sav opt)));
} elsif ($command eq 'proto')
{
$must_enable = 1
if ($selection_refs[0]->[0] =~ /\.(c|cpp|oc|pl|pm)$/);  # $item
} elsif ($command eq 'Execute')
{
my $type = ENV_split_spec_t( $selection_refs[0]->[0]);	# $item
$must_enable = 1
if (ENV_is_command_type( $type));
} else
{
ENV_sig( F => "Unknown command '$command'");
}
} else
{
$must_enable = 1;
}
}
TKXMENU_enable_item( $menu_id, $entry_nr, $must_enable);
}

TKXMENU_popup_post( $RCM, $x, $y);
}




sub execute_inter($$@)
{
my ($menu_label,
$command,
@args
) = @_;

my $must_refresh = $command =~ s/\*$//;

my @selection_refs = TKXDIRTREE_get_selection( $DT);


my $nr_changed_items = 0;

if ($command eq 'delete')
{
my @filespecs = map { $_->[1] } @selection_refs;
$nr_changed_items = GBSGUIFILE_delete( $command, $CURRENT_PATH, \@filespecs);
} elsif ($command eq 'newfile' || $command eq 'newdir')
{
my $path;
if (@selection_refs)
{
my $itemspec = $selection_refs[0]->[1];
if (-d $itemspec)
{
$path = $itemspec;
} else
{
$path = ENV_parent_path( $itemspec);
}
} else
{
$path = $CURRENT_PATH;
}
if ($command eq 'newfile')
{
$nr_changed_items = GBSGUIFILE_new_file( $command, $path);
} else
{
$nr_changed_items = GBSGUIFILE_new_dir( $command, $path);
}
} else
{
ENV_sig( F => "Unknown command '$command'");
}

show_dir_tree( $must_refresh)
if ($nr_changed_items > 0);
}




sub execute_direct($$@)
{
my ($menu_label,
$command,
@args
) = @_;



my $must_refresh = $command =~ s/\*$//;

my @selection_refs = TKXDIRTREE_get_selection( $DT);


my @rel_specs = ('');
@rel_specs = ENV_strip_path( $CURRENT_PATH, [ map { $_->[1] } @selection_refs ])	# $selspecs
if (@selection_refs);

ENV_pushd( $CURRENT_PATH);
GBSGUIEXEC_direct( $menu_label, $command, [ @rel_specs, @args ]);
show_dir_tree( $must_refresh);
ENV_popd();
}




sub execute_prompt($$@)
{
my ($menu_label,
$command,
@args
) = @_;

my @selection_refs = TKXDIRTREE_get_selection( $DT);
my @rel_specs = ENV_strip_path( $CURRENT_PATH, [ map { $_->[1] } @selection_refs ]);	# $selspecs

ENV_pushd( $CURRENT_PATH);
GBSGUIEXEC_prompt( $menu_label, $command, [ @rel_specs, @args ]);
ENV_popd();
}




sub set_global($)
{
my ($variable,
) = @_;

return ($variable eq '') ? '-' : $variable;
}

my $CUR_TREE_PATH = '';



sub show_dir_tree($)
{
my ($refresh,
) = @_;

if ($refresh || $CURRENT_PATH ne $CUR_TREE_PATH)
{





TKXDIRTREE_show_tree( $DT, $CURRENT_PATH, \@TAG_REFS);

}
$CUR_TREE_PATH = $CURRENT_PATH;
}

1;
