#=================================================
#
#   tkxafter.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::tkxafter;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
TKXAFTER_sleep
TKXAFTER_timer
TKXAFTER_idle
TKXAFTER_info
TKXAFTER_info_all
TKXAFTER_cancel
);
}




use Tkx;







sub TKXAFTER_sleep($);
sub TKXAFTER_timer($$@);
sub TKXAFTER_idle($@);
sub TKXAFTER_info_all();
sub TKXAFTER_info($);
sub TKXAFTER_cancel($);
















sub TKXAFTER_sleep($)
{
my ($miliseconds,
) = @_;


return Tkx::after( $miliseconds);
}




sub TKXAFTER_timer($$@)
{
my ($miliseconds,
@functions
) = @_;


return Tkx::after( $miliseconds, @functions);
}




sub TKXAFTER_idle($@)
{
my (@functions
) = @_;


return Tkx::after_idle( @functions);
}




sub TKXAFTER_info_all()
{


return Tkx::after_info()
}




sub TKXAFTER_info($)
{
my ($after_id,
) = @_;
my ($function, $type);  # $type = 'timer' or 'idle'

return Tkx::after_info( $after_id)
}




sub TKXAFTER_cancel($)
{
my ($after_id,
) = @_;

Tkx::after_cancel( $after_id);
}

1;

