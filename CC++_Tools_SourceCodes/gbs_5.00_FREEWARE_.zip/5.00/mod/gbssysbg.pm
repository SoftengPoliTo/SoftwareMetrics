#=================================================
#
#   gbssysbg.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbssysbg;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSSYSBG_execute
GBSSYSBG_print_errors
);
}




use glo::env;
use glo::slurp;
use glo::struct;
use glo::banner;
use mod::gbsglo;
use mod::exec;
use mod::cleanup;
use mod::sws;
use mod::gbscmd;




sub GBSSYSBG_execute($$$$$);
sub GBSSYSBG_print_errors();

sub do_sub_build($$$);
sub do_sub_audit($$);
sub do_tool($$);
sub do_audit_sum($);
sub do_command($);








my $IGNORE_ERRORS;	    # bool
my $FILES_REF;		    # may be undef




my $FOR_GEN = 0;
my $FOR_MAKE = 0;
my $FOR_AUDIT = 0;
my $FOR_TOOL = 0;
my $ACTION_TEXT;

my $GBS_AUDIT_EXECUTED = 0;





sub GBSSYSBG_execute($$$$$)
{
my ($jobtype,			# 'build', 'make', 'audit' or 'tool'
$ignore_errors,			# bool
$files_ref,			# --files= may be undef
$steps_filespec,
$options_ref,
) = @_;
my $rc = 0;

$IGNORE_ERRORS = $ignore_errors;
$FILES_REF = $files_ref;

my @command_options = @{$options_ref};  # --i, --mm, --export, --summary,  etc




$GBS_AUDIT_EXECUTED = 0;
if ($jobtype eq 'build')
{
$FOR_GEN = 1;
$ACTION_TEXT = 'Generating';
} elsif ($jobtype eq 'make')
{
$FOR_MAKE = 1;
$ACTION_TEXT = 'Making';
} elsif ($jobtype eq 'audit')
{
$FOR_AUDIT = 1;
$ACTION_TEXT = "Auditing $GBS::AUDIT";
} elsif ($jobtype eq 'tool')
{
$FOR_TOOL = 1;
$ACTION_TEXT = "Executing $GBS::TOOL";
} else
{
ENV_sig( F => "Invalid jobtype '$jobtype'");
}
ENV_setenv( GBS_IGNORE_ERRORS => $IGNORE_ERRORS);





my $step_data_refs_ref = STRUCT_decode( [ SLURP_file( $steps_filespec) ]);




ENV_unlink( $steps_filespec, 1, 'W');   # $force, $sig_on_error

my @step_data_refs = @{$step_data_refs_ref};




{
my @steps = map { $_->[0] } @step_data_refs;
BANNER_print( 'SYSTEM', "ALL_STEPS: @steps");
}

while (@step_data_refs)
{



my $step_data_ref = shift @step_data_refs;
my ($step_name, $subsys, $tool, $must_force_execute, $command_data_refs_ref) = @{$step_data_ref};


my $must_execute = ($IGNORE_ERRORS || $must_force_execute);
if ($rc == 0 || $IGNORE_ERRORS || $must_force_execute)
{
my $banner_name = ($must_force_execute) ? 'EXPLICIT STEP' : 'STEP';
my $done_text;
my $this_rc;
if ($subsys ne '')
{







BANNER_print( 'SUBSYS', [
"$banner_name: $step_name - SubSystem: $subsys",
"Silent switch to SubSystem: $subsys" ]);
SWS_set( $subsys, 0);
my $subsys_path = "$GBS::ROOT_PATH/dev/$subsys";
ENV_chdir( $subsys_path);




if ($FOR_AUDIT)
{
$this_rc = do_sub_audit( $subsys, \@command_options);
$done_text = "SubSystem $step_name - Build=$GBS::BUILD - Audit=$GBS::AUDIT";
} else
{
$this_rc = do_sub_build( $jobtype, $subsys, \@command_options);
$done_text = "SubSystem $step_name - Build=$GBS::BUILD";
}
} else
{



ENV_chdir( $GBS::ROOT_PATH);
my $nr_commands = (defined $command_data_refs_ref) ? @{$command_data_refs_ref} : 0;
if ($nr_commands > 0)
{
BANNER_print( 'SUBSYS', "$banner_name: $step_name - $nr_commands commands");
my @commands;
foreach my $command_data_ref (@{$command_data_refs_ref})
{
$this_rc = do_command( $command_data_ref);
last
if ($this_rc != 0);
}
$done_text = "Command $step_name";
} else # Tool
{
BANNER_print( 'SUBSYS', "$banner_name: $step_name - Tool: $tool");
$this_rc = do_tool( $tool, \@command_options);
$done_text = "Tool $step_name";
}
}
$rc = $this_rc
if ($this_rc > $rc);

if ($this_rc == 0)
{
BANNER_print( 'NOTE', "DONE: $done_text");
} else
{
BANNER_print( 'FAIL', "FAILED: $done_text - RC=$this_rc");
}
if ($this_rc != 0 && !$IGNORE_ERRORS)
{
if (@step_data_refs)
{
my $nr_steps = @step_data_refs;
BANNER_print( 'NOTE', "Remaining STEPs ($nr_steps) will be skipped");
} else
{
BANNER_print( 'NOTE', 'No Remaining STEPs');
}
last;
}
}
}




if ($FOR_AUDIT)
{
my $this_rc = do_audit_sum( \@command_options);
$rc = $this_rc if ($this_rc > $rc);
}

return $rc;
}





sub do_sub_build($$$)
{
my ($jobtype,	    # 'build' or 'make'
$subsys,
$gbs_build_opts_ref,
) = @_;
my $rc = 0;




if ($FOR_GEN)
{
BANNER_print( 'NOTE', "Implicit: Cleanup the bld directories for SubSys: $subsys");
CLEANUP_subsys_bld( $subsys, $GBS::BUILD);
}




if (GBSGLO_subsystem_is_full_gbs( $subsys))
{



my @gbs_build_opts = @{$gbs_build_opts_ref};
ENV_say( 1, "$ACTION_TEXT Full GBS SubSystem: $subsys (@gbs_build_opts)...");
$rc = EXEC_run( "gbs$jobtype.pl", [ @{$FILES_REF}, @gbs_build_opts ]);
} else
{



ENV_say( 1, "$ACTION_TEXT Non-Full GBS SubSystem: $subsys...");




$rc = EXEC_run( 'gbssub.pl', [ $jobtype, $IGNORE_ERRORS ]);
}

return $rc;
}




sub do_sub_audit($$)
{
my ($subsys,
$gbsaudit_opts_ref,
) = @_;
my $rc = 0;




if (GBSGLO_subsystem_is_full_gbs( $subsys))
{



my @gbsaudit_opts = @{$gbsaudit_opts_ref};
ENV_say( 1, "$ACTION_TEXT Full GBS SubSystem: $subsys (@gbsaudit_opts)...");
my @args = ( @{$FILES_REF}, @gbsaudit_opts, "--caller=gbssysaudit");	# 1 == Execute Audit only

$rc = EXEC_run( "gbsaudit.pl", \@args);
$GBS_AUDIT_EXECUTED = 1;
} else
{



ENV_say( 1, "$ACTION_TEXT Non-Full GBS SubSystem: $subsys...");
$rc = EXEC_run( 'gbssub.pl', [ 'audit', $IGNORE_ERRORS ]);
}

return $rc;
}




sub do_audit_sum($)
{
my ($gbsaudit_opts_ref) = @_;
my $rc = 0;




ENV_chdir( $GBS::ROOT_PATH);
if ($GBS_AUDIT_EXECUTED)
{



my @gbsaudit_opts = @{$gbsaudit_opts_ref};
my @gbsauditsum_opts = grep( $_ =~ /^--(i|stdout|sum|vs)/, @gbsaudit_opts);
BANNER_print( 'SUBSYS', "IMPLICIT STEP: Create Audit Summary (@gbsauditsum_opts)" );
$rc = EXEC_batch_run( GBSCMD_get_gbs_command( gbsauditsum => [ gbssysaudit => @gbsauditsum_opts ]));
$GBS_AUDIT_EXECUTED = 0;
} else
{



BANNER_print( 'SUBSYS', "IMPLICIT STEP: Create Audit Summary (Non full GBS)" );
$rc = EXEC_run( 'gbssub.pl', [ 'auditsum', $IGNORE_ERRORS ]);
}

if ($rc == 0)
{
BANNER_print( 'NOTE', "AUDIT SUMMARY: Build=$GBS::BUILD Audit=$GBS::AUDIT");
} else
{
BANNER_print( 'FAIL', "AUDIT SUMMARY FAILED: Build=$GBS::BUILD Audit=$GBS::AUDIT - RC=$rc");
}

return $rc;
}




sub do_tool($$)
{
my ($tool,
$gbstool_opts_ref,
) = @_;
my $rc = 0;

my @gbstool_opts = @{$gbstool_opts_ref};
ENV_say( 1, "$ACTION_TEXT $tool (@gbstool_opts)...");
my @args = ( $tool, @gbstool_opts );

$rc = EXEC_run( "gbstool.pl", \@args);

return $rc;
}




sub do_command($)
{
my ($command_data_ref,


) = @_;
my $rc = 0;

my ($command_type, $command_items_ref, $ok_values, $exec_condition, $pos_arg_tokens) = @{$command_data_ref};
my ($command, @args) = @{$command_items_ref};
my $command_line = ENV_join_quoted_space( @{$command_items_ref});



if ($command eq 'ECHO')
{
BANNER_print( 'NOTE', "Execute ECHO");
my $line = ENV_expand_envs( "@args");
ENV_say( 0, $line);
} elsif ($command eq 'SET')
{
BANNER_print( 'NOTE', "Execute $command_line");
my ($name, $value) = split( / /, "@args", 2);

$value = ENV_expand_envs( $value);
ENV_setenv( $name => $value);
} else
{
BANNER_print( 'NOTE', "Executing Command: $command_line...");
$rc = EXEC_batch_run( [ $command, @args ]);
}

return $rc;
}





sub GBSSYSBG_print_errors()
{
my $gbs_logfile = ENV_getenv( 'GBS_LOGFILE');
if ($gbs_logfile && $gbs_logfile ne '-')
{
my $fail_filespec = "$gbs_logfile.err";
if (-e $fail_filespec)
{
BANNER_print( 'FAIL', [
'Error Log:',
'',
SLURP_file( $fail_filespec) ]);
}
}
}

1;


