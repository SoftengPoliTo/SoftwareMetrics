#!must_be_sourced
#
#   Run the generic gbssource perl script
#   gbssource.sh <gbs_script> <arguments>...
#
GBS_RC=0
let GBS_SCRIPT_LEVEL+=1

#
#  Extract the name of the script and make it uppercase
#
GBS_SCRIPT=${1%.*}
GBS_SCRIPT=${GBS_SCRIPT^^}

#
#   Sanity
#
[[ "$TMPDIR"=="" ]] && \export TMPDIR=$HOME/tmp

#
#  Debug
#
#echo "GBSSOURCE:${GBS_SCRIPT}_: $*"

if [[ $GBS_PID == '' && "$GBS_SCRIPT" != "GBSSETUP" ]]
then
    echo "GBSSW_: ** GBS not started for this subprocess: Use 'gbs' or 'gbsstart' **"
    GBS_RC=1
else
    \export GBS_RESULT_FILE=$TMPDIR/${GBS_SCRIPT}_RESULT_`hostname`_$GBS_PID.tmp
    \rm -f $GBS_RESULT_FILE 2> /dev/null
    $GBS_PERL_CMD $GBS_SCRIPTS_PATH/$*
    GBS_RC=$?
    set --

    #
    #   Selectively setup the environment
    #
    if [[ $GBS_RC -eq 0 && -f $GBS_RESULT_FILE ]]
    then
	#
	#   Execute the setup of environment variables
	#
	. $GBS_RESULT_FILE
	GBS_RC=$?
    fi
    \rm -f $GBS_RESULT_FILE 2> /dev/null
    unset GBS_RESULT_FILE
fi
unset GBS_SCRIPT

#   End
let GBS_SCRIPT_LEVEL-=1
if (( $GBS_SCRIPT_LEVEL <= 0 ))
then
    unset GBS_PROMPT_SEPARATOR_PRINTED
    unset GBS_SCRIPT_LEVEL
fi
\set --
bash -c "exit $GBS_RC" # set $?

## EOF ##
