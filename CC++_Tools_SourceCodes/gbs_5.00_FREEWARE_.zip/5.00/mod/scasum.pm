#=================================================
#
#   scasum.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::scasum;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SCASUM_init
SCASUM_run
);
}




use glo::env;
use glo::html;
use glo::spit;
use glo::slurp;
use glo::time;
use mod::gbsenv;
use mod::gbsres;
use mod::gbshtml;
use mod::gfl;
use mod::plugin;
use mod::audit;
use mod::scadef;
use mod::scamet;
use mod::scaglo;
use mod::scamsg;
use mod::scafile;
use mod::sca;
use mod::scahist;




sub SCASUM_init($);
sub SCASUM_run();

sub init_msg();
sub init_metrics();
sub update_metric_thresholds();

sub lvl_grand_total();
sub lvl_subsys_head($);
sub lvl_subsys_break();
sub lvl_component_head($);
sub lvl_component_break();
sub lvl_handle_file($);
sub print_totals($$);
sub create_ano_html_file();
sub ano_line_html($$);
sub ano_print_nav($$);
sub get_file_line($$);
sub create_log_html_file($$);
sub generate_levels_summary();
sub print_file_line();
sub generate_message_summary();
sub generate_metrics_summary($);
sub generate_settings_links();
sub generate_suspicious_files_list();
sub generate_worse_files_list();
sub generate_special_warnings_summary();
sub write_lines_or_link($$$);
sub get_diff($$$);
sub color_text($$$);
sub color_value($$$);
sub color_value_f($$$);
sub delta_value($$);
sub clear_totals($);
sub add_totals($);
sub calc_levels_sum($);
sub calc_density($$$$);
sub ano_href($$$);
sub print_legend();
sub dot_print($$);
sub read_cur_gmet_file();
sub read_hist_gmet_file();
sub gmet_init();
sub gmet_store_all($);
sub gmet_store_warnings($);
sub gmet_store_totals($);
sub gmet_store_specws($);
sub gmet_store_stats($);




my $GBS_JOB_ARGS = ENV_getenv( 'GBS_JOB_ARGS');		# set by gbsjob.pl May be empty
my $GBS_DOC_PATH = "$GBS::SCRIPTS_PATH/doc";





my $RARR = '&'. 'rarr;';	    # right-arrow

my %MET_DEFS;






my @MET_DEFS_ORDER;

my %DIFFS = (

Iclean   => [ 'OK: Clean',        'Clean'  ],
Igone    => [ 'OK: Gone',         'Gone'   ],
Ibetter  => [ 'OK: Improved',     'Better' ],
Isame    => [ 'Same',             'Same'   ],
Iworse   => [ 'NOK: Worse',       'Worse'  ],
Wclean   => [ 'OK: Clean',        'Clean'  ],
Wgone    => [ 'OK: Gone',         'Gone'   ],
Wbetter  => [ 'OK: Improved',     'Better' ],
Wsame    => [ 'Same',             'Same'   ],
Wworse   => [ 'NOK: Worse',       'Worse'  ],
Fclean   => [ 'OK: Clean',	      'Clean'  ],
Fgone    => [ 'OK: Gone',         'Gone'   ],
Fbetter  => [ 'NOK: Syntax',      'Fatal: Better' ],
Fsame    => [ 'NOK: Syntax',      'Fatal: Same' ],
Fworse   => [ 'NOK: Syntax',      'Fatal: Worse' ],
);




my $PLUGIN_NICE_NAME;
my $SUM_FILE_SPEC;
my $SUM_FILE_PATH;
my $SUM_FILE_NAME;	    # gbs<job>_<build>_<audit>_YYMMDD-hhmmss_sum
my $SUM_FILE_TYPE;	    # .html
my $SUM_FILE_DATETIME;
my $RELEASE_TEXT;

my $VIA_FORMAT;		    # From audit.gbs
my $VIA_FILE_TYPE;	    # From audit.gbs
my $VIA_RE;

my @MSG_LEVEL_REFS;



my %MSG_LEVEL_REFS;

my %LEVEL_INDEX;

my @LEVEL_TEXTS;
my $NR_LEVELS;
my $LAST_LEVEL_I;		# $NR_LEVELS - 1;
my @FATAL_LEVEL_INDEXES;

my @EXTRA_LEVEL_TEXTS = (
"Nr.\nLines",
"Nr.\nFuncs",
"Nr.\nClass",
"Nr.\nconst",
);
my $NR_LINES_I = 0;
my $NR_FUNCS_I = 1;
my $NR_CLASS_I = 2;

my $LAST_TOT_I = 3;
my $NR_EXTRA_LEVELS = @EXTRA_LEVEL_TEXTS;

my $HELP_FILES_PATH,	    # undef if no msg help files

my %SPECIAL_MSG_IDS;	    # Fatal and SPECWS





my %SPECWS;






my $TOTAL_SUBSYS_COUNT = 0;
my $TOTAL_COMP_COUNT = 0;
my $CUR_TOTAL_FILE_COUNT = 0;
my $HIST_TOTAL_FILE_COUNT = 0;
my @SYSTEM_MSG_SUM_REFS;

my @SYSTEM_TOTAL_SUM_REFS;





my $CUR_SUBSYS = '';
my $SUBSYS_COUNT = 0;
my @SUBSYS_MSG_SUM_REFS;

my @SUBSYS_TOTAL_SUM_REFS;





my $CUR_COMPONENT = '';
my $CUR_SRC_PATH;
my $CUR_AUD_BUILD_PATH;
my $COMP_COUNT = 0;
my @COMP_MSG_SUM_REFS;

my @COMP_TOTAL_SUM_REFS;





my $CUR_FILE = '';
my $CUR_FILE_SPEC = '';
my $CUR_OS_FILE_SPEC = '';
my $FILE_COUNT = 0;
my $IS_NEW_FILE = 0;
my $FILE_LOG_FILE_SPEC;
my $FILE_ANO_FILE_SPEC;




my %GMET_MSG_REFS;

my @GMET_MSG_SUM_REFS;


my @GMET_TOTAL_SUM_REFS;


my %GMET_SPECW_REFS;

my %GMET_STAT_REFS;



my @ROW_REFS;           # HTML rows
my @SUM_REFS = (

[ \@GMET_MSG_SUM_REFS,   \@GMET_TOTAL_SUM_REFS ],	    # 0	= File
[ \@COMP_MSG_SUM_REFS,   \@COMP_TOTAL_SUM_REFS ],	    # 1 = Component
[ \@SUBSYS_MSG_SUM_REFS, \@SUBSYS_TOTAL_SUM_REFS ],	    # 2 = SubSys
[ \@SYSTEM_MSG_SUM_REFS, \@SYSTEM_TOTAL_SUM_REFS ],	    # 3 = System
);




my %TOTAL_SPECW_REFS;			# Sum of %GMET_SPECW_REFS


my %TOTAL_STAT_REFS;			# Sum of %GMET_STAT_REFS



my %SKIPPED_MSGS;	    # present in Hist and not in Cur


my %SKIPPED_METRICS;	    # present in Hist and not in Cur





my %TOTAL_MSG_COUNT;



my @TOTAL_SUSP_FILE_REFS;


my %TOTAL_WORSE_FILES;





my @SCA_DEPEND_REFS;






my %CODE_FILES_REF;





sub SCASUM_init($)
{
(	$SUM_FILE_SPEC,
) = @_;

GBSHTML_init( 'application');	    # Use Silo

my $plugin_rel = PLUGIN_get_main_envs( $GBS::AUDIT_PLUGIN);
ENV_whisper( 1, "Audit $GBS::AUDIT [$GBS::AUDIT_PLUGIN ($plugin_rel)] for Build $GBS::BUILD",
$SUM_FILE_SPEC);

%SPECWS = map { @{$_} } @{SCADEF_get_section_items( $GBS::AUDIT_PLUGIN, 'MESSAGES', 'SPECIAL')};
$PLUGIN_NICE_NAME = AUDIT_get_section_items( $GBS::AUDIT, 'SETUP', 'NICE_NAME');

$RELEASE_TEXT = "$PLUGIN_NICE_NAME ($plugin_rel)";

SCAGLO_init( $GBS::AUDIT_PLUGIN, $plugin_rel, $PLUGIN_NICE_NAME);	# Includes SCAMSG_init

($SUM_FILE_PATH, $SUM_FILE_NAME, $SUM_FILE_TYPE) = ENV_split_spec_pnt( $SUM_FILE_SPEC);
$SUM_FILE_DATETIME = TIME_unpack( GBSRES_get_logfile_numtime( $SUM_FILE_NAME));







($VIA_FORMAT, $VIA_FILE_TYPE) = AUDIT_get_section_items( $GBS::AUDIT, SETUP => 'VIA_FORMAT');

if ($VIA_FORMAT ne '')
{
$VIA_RE = quotemeta "$VIA_FORMAT$VIA_FILE_TYPE";
$VIA_RE =~ s!\\%s!(\\S+)!;
$VIA_RE = "\\s*$VIA_RE\\s*";

}




init_msg();





init_metrics();
}




sub init_msg()
{



@MSG_LEVEL_REFS = SCADEF_get_levels( $GBS::AUDIT_PLUGIN);



foreach my $ref (@MSG_LEVEL_REFS)
{
my ($severity_level, $severity, $severiy_text, $severity_index) = @{$ref};

$MSG_LEVEL_REFS{$severity_level} = $ref;
if ($severiy_text =~ s/_/\n/g)
{
$severiy_text .= " ($severity_level)";
} else
{
$severiy_text .= "\n($severity_level)";
}
my $level_index = scalar @LEVEL_TEXTS;
push @LEVEL_TEXTS, $severiy_text;
$LEVEL_INDEX{$severity_level} = $level_index;
push @FATAL_LEVEL_INDEXES, $level_index
if ($severity eq 'F');
}


$NR_LEVELS = @LEVEL_TEXTS;
$LAST_LEVEL_I = $#LEVEL_TEXTS;




SCAMSG_read_file();
{
my @all_msg_ids;
my @fatal_msg_ids;

foreach my $ref (SCAMSG_get_msgs_and_levels())
{
my ($msg_id, $level) = @{$ref};
push @all_msg_ids, $msg_id;
push @fatal_msg_ids, $msg_id
if ($MSG_LEVEL_REFS{$level}->[1] eq 'F');   # $severity IWF
}
SCA_init( \@all_msg_ids, \@fatal_msg_ids, [ keys %SPECWS ]);
%SPECIAL_MSG_IDS = map { $_ => 1 } (@fatal_msg_ids, keys %SPECWS);
}




$HELP_FILES_PATH = SCADEF_get_section_items( $GBS::AUDIT_PLUGIN, 'HELPFILES', 'PATH');
$HELP_FILES_PATH = ''
if (!defined $HELP_FILES_PATH);





map { clear_totals( $_) } 0 .. 3;	#   $sum_level 0 - 3


}




sub init_metrics()
{
my @metric_names =  @{SCADEF_get_section_items( $GBS::AUDIT_PLUGIN, 'METRICS', 'ENABLE')};
if (!@metric_names)
{
push @metric_names, 'TLN';	# Total source lines after pre-processing
push @metric_names, 'TPP';	# Total source lines before pre-processing
}






my %met_defs_sorted;

my $met_defs_sorted = 0;
foreach my $metric_name (@metric_names)
{

$MET_DEFS{$metric_name} = [ SCAMET_get_metric_data( $metric_name) ];


if (!$met_defs_sorted{$metric_name})	    # prevent duplicates (should have been done earlier)
{
push @MET_DEFS_ORDER, $metric_name;
$met_defs_sorted = 0;
$met_defs_sorted{$metric_name} = 1;
}
}




if (!$met_defs_sorted)
{

my @order_refs = ( [], [], [], []);		    # function, class, file, project
foreach my $key (@MET_DEFS_ORDER)
{
my $group = $MET_DEFS{$key}->[1];
push @{$order_refs[$group]}, $key;
}
@MET_DEFS_ORDER = map { @{$_} } @order_refs;

$met_defs_sorted = 1;
}
}




sub update_metric_thresholds()
{
my @metric_threshold_refs = SCA_get_threshold_refs();


foreach my $ref (@metric_threshold_refs)
{
my ($metric_name, $new_min_value, $new_max_value, $msg_id ) = @{$ref};	    # msg_id not used yet

my $defs_ref = $MET_DEFS{$metric_name};


if ($new_min_value ne '')
{
if (defined $defs_ref->[2])			    # $min_ref
{
my $cur_min_value = $defs_ref->[2]->[0];    # $min_ref->$limit
if ($cur_min_value ne $new_min_value)
{
$defs_ref->[2]->[0] = $new_min_value;   # $min_ref->$limit
ENV_say( 1, "METRIC $metric_name min limit changed from $cur_min_value to $new_min_value");
}
} else
{
ENV_sig( W => "No min limit for metric $metric_name - Ignored");
}
}

if ($new_max_value ne '')
{
if (defined $defs_ref->[3])			    # $max_ref
{
my $cur_max_value = $defs_ref->[3]->[0];    # $max_ref->$limit
if ($cur_max_value ne $new_max_value)
{
$defs_ref->[3]->[0] = $new_max_value;   # $max_ref->$limit
ENV_say( 1, "METRIC $metric_name max limit changed from $cur_max_value to $new_max_value");
}
} else
{
ENV_sig( W => "No max limit for metric $metric_name - Ignored");
}
}

}
}




sub SCASUM_run()
{



my $title = "$PLUGIN_NICE_NAME Summary $SUM_FILE_NAME";
my $build_text = $GBS::BUILD;
$build_text .= " [ $GBS_JOB_ARGS ]"
if (!GBSENV_mode_is_interactive());

my @sum_lines;
push @sum_lines, GBSHTML_doc_start( $SUM_FILE_SPEC, $title, 0, '', undef); # $want_scripts, $body_class, $target_frame_name
$title = "$PLUGIN_NICE_NAME Summary Report ($GBS::AUDIT)";
push @sum_lines,
GBSHTML_doc_top( [ $title, HTML_link( '.', HTML_bold( 'Log Directory')) ],
( [ System => $GBS::SYSTEM_NAME,	'' ],
[ Root   => $GBS::ROOT_PATH,		'' ],
[ Build => $build_text,		'' ],
[ Summary=> $SUM_FILE_NAME,		'' ],
[ Date   => $SUM_FILE_DATETIME,	'' ],
));
my $cur_section = 1;
push @sum_lines, $RELEASE_TEXT;




ENV_whisper( 1, "Create Summary...");
push @sum_lines, GBSHTML_h( 1, undef, "$PLUGIN_NICE_NAME Message Summary", ++$cur_section);
push @sum_lines, print_legend();
push @sum_lines, generate_levels_summary();




ENV_whisper( 1, "Create Warning Message Summary...");
push @sum_lines, GBSHTML_h( 1, undef, "$PLUGIN_NICE_NAME Warning Message Summary",  ++$cur_section);
push @sum_lines, generate_message_summary();




ENV_whisper( 1, "Create Metrics Summary...");
push @sum_lines, GBSHTML_h( 1, undef, "$PLUGIN_NICE_NAME Metrics Summary",  ++$cur_section);
push @sum_lines, generate_metrics_summary( 'SUMMARY');




ENV_whisper( 1, "Create SCA Settings Links...");
push @sum_lines, GBSHTML_h( 1, undef, "$PLUGIN_NICE_NAME SCA Settings:", ++$cur_section);
push @sum_lines, generate_settings_links();




ENV_whisper( 1, "Create Suspicious Files Summary...");
push @sum_lines, GBSHTML_h( 1, undef, "$PLUGIN_NICE_NAME Suspicious Files Summary",  ++$cur_section);
push @sum_lines, generate_suspicious_files_list();




ENV_whisper( 1, "Create Decreased Quality Files Summary...");
push @sum_lines, GBSHTML_h( 1, undef, "$PLUGIN_NICE_NAME Decreased Quality Files Summary",  ++$cur_section);
push @sum_lines, generate_worse_files_list();




ENV_whisper( 1, " Create Special Warnings Summary...");
push @sum_lines, GBSHTML_h( 1, undef, "$PLUGIN_NICE_NAME Special Warnings Summary", undef);  # last section!
push @sum_lines, generate_special_warnings_summary();




push @sum_lines, GBSHTML_doc_bottom();
push @sum_lines, GBSHTML_doc_end();


SPIT_file_nl( $SUM_FILE_SPEC, \@sum_lines);
}




sub generate_levels_summary()
{
my @lines;




my ($audit, undef, @subsys_refs) = GFL_read( $GBS::AUDIT);
foreach my $subsys_ref (@subsys_refs)
{



my ($subsys, undef, @comp_refs) = @{$subsys_ref};

lvl_subsys_head( $subsys);
foreach my $comp_ref (@comp_refs)
{



my ($component, undef, @files) = @{$comp_ref};

lvl_component_head( $component);
foreach my $in_file (@files)
{




lvl_handle_file( $in_file);
print_file_line();
$CUR_FILE = '';
$CUR_FILE_SPEC = '';
$CUR_OS_FILE_SPEC = '';
}
lvl_component_break();
$CUR_COMPONENT = '';
}
lvl_subsys_break();
$CUR_SUBSYS = '';
}




lvl_grand_total();
my @formats = qw( -TL -TRN);			    # Name, Legend
map { push @formats, qw( -TR ) } 1 .. $NR_LEVELS;	    # msg-levels
push @formats, qw( -TR);				    # total Msgs
map { push @formats, qw( -TR ) } 1 .. $NR_EXTRA_LEVELS; # Total MSG,


push @lines, HTML_table( [ @formats ],
undef,
[ @ROW_REFS ],
class => 'border1-padding1');
@ROW_REFS = ();	# cleanup

return @lines;
}




sub print_file_line()
{
my $out_base = "$CUR_AUD_BUILD_PATH/$CUR_FILE";
my $garg_filespec = "$out_base.garg";		    # In

$FILE_ANO_FILE_SPEC = "$out_base.html";
$FILE_LOG_FILE_SPEC = "$out_base.log.html";

SCAFILE_init( $CUR_SUBSYS, $CUR_COMPONENT, $CUR_FILE);  # returns $gout_filespec




gmet_init();
$IS_NEW_FILE =0;
if (read_cur_gmet_file())
{



$IS_NEW_FILE = read_hist_gmet_file();




create_ano_html_file();
create_log_html_file( $garg_filespec, 1);




print_totals( 0, $CUR_FILE);

add_totals( 0);	# File




{
my $diff_count = 0;
foreach my $ref (@GMET_MSG_SUM_REFS)
{
my (undef, undef, $t_cur_msg_sum, $t_hist_msg_sum) = @{$ref};
my $diff = $t_cur_msg_sum - $t_hist_msg_sum;
$diff_count += $diff
if ($diff > 0);
}
my $fatal_count = 0;
map { $fatal_count += $GMET_MSG_SUM_REFS[$_]->[2] } @FATAL_LEVEL_INDEXES;  # $t_cur_msg_sum

if ($diff_count > 0)
{
my $key = "$CUR_SUBSYS:$CUR_COMPONENT:$CUR_FILE";
$TOTAL_WORSE_FILES{$key} = [ $IS_NEW_FILE, $diff_count, $fatal_count, 0 ];

}
}






while (my ($msg_id, $ref) = each %GMET_MSG_REFS)
{


my $t_cur_msg_count = $ref->[2];
my $t_hist_msg_count = $ref->[3];
if ($t_cur_msg_count > 0)				# hist may also contain errors, so select only current
{
my $msg_ref = $TOTAL_MSG_COUNT{$msg_id};
if (!defined $msg_ref)
{
$msg_ref = [ 0, 0, 0, ];	# $cur_msg_count, $hist_msg_count, $msg_file_count, @file_refs (pushed later)
$TOTAL_MSG_COUNT{$msg_id} = $msg_ref;
}
$msg_ref->[0] += $t_cur_msg_count;  # $cur_msg_count
$msg_ref->[1] += $t_hist_msg_count; # $hist_msg_count
$msg_ref->[2]++;		    # $msg_file_count
push @{$msg_ref}, [ $CUR_SUBSYS, $CUR_COMPONENT, $CUR_FILE, $t_cur_msg_count ];	# @file_refs
}
}
} else
{
$FILE_ANO_FILE_SPEC = $CUR_FILE_SPEC
if (!-e $FILE_ANO_FILE_SPEC);

create_log_html_file( $garg_filespec, 0);

my $line1 = HTML_text( '   ') .
HTML_link( {target => '_blank'}, $FILE_ANO_FILE_SPEC, HTML_text( $CUR_FILE));
my $line2 = HTML_text( '   ') .
HTML_link( {target => '_blank'}, $FILE_LOG_FILE_SPEC, HTML_text( "$CUR_FILE.log"));

push @ROW_REFS, [ HTML_div( {class => 'align-left'}, $line1 . '<br>' . $line2),
HTML_div( {class => 'align-left', style => "color:red"}, 'No Analysis Data') ];

my @lines;
push @lines, "$CUR_COMPONENT:$CUR_FILE: No Analysis Data file found ($CUR_FILE.gmet)";
push @lines, "$CUR_COMPONENT:$CUR_FILE: No Annotated file found ($CUR_FILE.html)"
if (!-e $FILE_ANO_FILE_SPEC);
push @lines, "$CUR_COMPONENT:$CUR_FILE: No Arguments Log file found ($CUR_FILE.garg)"
if (!-e $garg_filespec);
ENV_sig( W => @lines);
}
}




sub lvl_grand_total()
{
lvl_component_break()
if ($CUR_COMPONENT);
lvl_subsys_break()
if ($CUR_SUBSYS);

if ($SUBSYS_COUNT > 1)
{
lvl_subsys_head( '');
push @ROW_REFS, [ '' ];
print_totals( 3, $SUBSYS_COUNT);
}
}




sub lvl_subsys_head($)
{
my ($subsys) = @_;

my @row;

$CUR_SUBSYS = $subsys;

if ($subsys eq '')  # grand total
{
push @row, '';
} else
{
SCA_read_msgs( $subsys);
push @SCA_DEPEND_REFS, [ $subsys, SCA_get_filespec() ];	# undef if does not exist



update_metric_thresholds();

my $hist_date = SCAHIST_select_subsys( $subsys);
push @row, HTML_div( {class => 'align-left'}, HTML_bold_txt( "SubSystem:\n$subsys"),
HTML_text( "\nHist-date: $hist_date"));
}
push @row, map { HTML_bold_txt( $_) } ( "Legend ",
@LEVEL_TEXTS,
"Total\nMsgs",
@EXTRA_LEVEL_TEXTS,
);
push @ROW_REFS, [ @row ];

clear_totals( 2);	    # SubSys
$COMP_COUNT = 0;
}




sub lvl_subsys_break()
{
$SUBSYS_COUNT++;
$TOTAL_SUBSYS_COUNT++;
if ($COMP_COUNT > 1 || $SUBSYS_COUNT > 1)
{
print_totals( 2, $COMP_COUNT);
}
add_totals( 2);	# SubSys
}





sub lvl_component_head($)
{
my ($component) = @_;

$CUR_COMPONENT = $component;
$CUR_SRC_PATH = "$GBS::ROOT_PATH/dev/$CUR_SUBSYS/comp/$CUR_COMPONENT/src";
$CUR_AUD_BUILD_PATH = "$GBS::ROOT_PATH/dev/$CUR_SUBSYS/comp/$CUR_COMPONENT/aud/$GBS::AUDIT/$GBS::BUILD";

my @row = ( [ {class => 'align-left'}, HTML_bold_txt( "  $CUR_COMPONENT") ]);
push @ROW_REFS, [ @row ];

clear_totals( 1);	    # Component
$FILE_COUNT = 0;
}





sub lvl_component_break()
{
$COMP_COUNT++;
$TOTAL_COMP_COUNT++;
if ($FILE_COUNT > 1 || $COMP_COUNT > 1 || $SUBSYS_COUNT > 1)
{
print_totals( 1, $FILE_COUNT);
}
add_totals( 1);	# Component
}




sub lvl_handle_file($)
{
my ($new_file,
) = @_;

$CUR_FILE = $new_file;
$CUR_FILE_SPEC = "$CUR_SRC_PATH/$CUR_FILE";
$CUR_OS_FILE_SPEC = ENV_os_paths( $CUR_FILE_SPEC);
$FILE_COUNT++;
$CUR_TOTAL_FILE_COUNT++;
clear_totals( 0);	    # file
}




sub print_totals($$)
{
my ($sum_level,             # 0 = line, 1 = comp, 2 = subsys, 3 = system
$info,                  # name, nr_files, nr_comp or nr_subsys
) = @_;
my @line;

my ($msg_sum_refs_ref, $tot_sum_refs_ref) = @{$SUM_REFS[$sum_level]};

my ($s_cur_nr_lines,
$s_hist_nr_lines,
$t_cur_nr_lines,
$t_hist_nr_lines) = @{$tot_sum_refs_ref->[$NR_LINES_I]};

my $line1;
my $line2;
my $line3;




if ($sum_level == 0)
{
my $name = $info;
$line1 = HTML_text( '   ') .
HTML_link( {target => '_blank'}, $FILE_ANO_FILE_SPEC,
HTML_text( $name));
$line2 = ($IS_NEW_FILE) ? HTML_text( '   (new)') : '';
$line3 = HTML_text( '   ') .
HTML_link( {target => '_blank'}, $FILE_LOG_FILE_SPEC,
HTML_text( "$name.log"));
} elsif ($sum_level == 1)
{
$line1 = HTML_bold_txt( "  $CUR_COMPONENT");
$line2 = HTML_bold_txt( "  Component Totals:");
$line3 = HTML_text( "  $info File(s)");
} elsif ($sum_level == 2)
{
$line1 = HTML_bold_txt( " $CUR_SUBSYS");
$line2 = HTML_bold_txt( " Subsys Totals:");
$line3 = HTML_text( "  $info Component(s)");
} else #($sum_level == 3)
{
$line1 = '';
$line2 = HTML_bold( "System Totals:");
$line3 = HTML_text( "  $info SubSystem(s)");
}
push @line, HTML_div( $line1) . HTML_div( $line2) . HTML_div( $line3);




push @line, HTML_div( HTML_bold( "Source$RARR")) .
HTML_div( HTML_bold( "Total$RARR")) .
HTML_div( HTML_bold( "Density$RARR"));




my $s_severity_index = 0;	# 0 = Info, 1 = Warning, 2 = Fatal
my $t_severity_index = 0;	# 0 = Info, 1 = Warning, 2 = Fatal
for (my $level_index = 0; $level_index < $NR_LEVELS; $level_index++)
{

my ($s_cur_msg_sum, $s_hist_msg_sum,
$t_cur_msg_sum, $t_hist_msg_sum) = @{$msg_sum_refs_ref->[$level_index]};
my $severity = $MSG_LEVEL_REFS[$level_index]->[1];
$line1 = color_value( $s_cur_msg_sum, $s_hist_msg_sum, $severity);    # Source
$line2 = color_value( $t_cur_msg_sum, $t_hist_msg_sum, $severity);    # Total
my $density      = calc_density( $t_cur_msg_sum,  $t_cur_nr_lines,  $s_cur_msg_sum,  $s_cur_nr_lines);
my $hist_density = calc_density( $t_hist_msg_sum, $t_hist_nr_lines, $s_hist_msg_sum, $s_hist_nr_lines);
$line3 = color_value_f( $density, $hist_density, $severity);	    # Density
push @line, "$line1$line2$line3";

my $severity_index = $MSG_LEVEL_REFS[$level_index]->[3];
if ($s_cur_msg_sum > 0 && $s_severity_index < $severity_index)
{
$s_severity_index = $severity_index;
}
if ($t_cur_msg_sum > 0 && $t_severity_index < $severity_index)
{
$t_severity_index = $severity_index;
}
}




{
my ($s_cur_msg_count, $s_hist_msg_count,
$t_cur_msg_count, $t_hist_msg_count) = calc_levels_sum( $msg_sum_refs_ref );
my $t_cur_density =  calc_density( $t_cur_msg_count,  $t_cur_nr_lines,  $s_cur_msg_count,  $s_cur_nr_lines);
my $t_hist_density = calc_density( $t_hist_msg_count, $t_hist_nr_lines, $s_hist_msg_count, $s_hist_nr_lines);

my $s_severity = substr( 'IWF', $s_severity_index, 1);
my $t_severity = substr( 'IWF', $t_severity_index, 1);
$line1 = color_value( $s_cur_msg_count, $s_hist_msg_count, $s_severity);	# Source Total
$line2 = color_value( $t_cur_msg_count, $t_hist_msg_count, $t_severity);	# Total Total
$line3 = color_value_f( $t_cur_density, $t_hist_density,   $t_severity);	# Density (Average?)
push @line, "$line1$line2$line3";
}




foreach my $ref ( @{$tot_sum_refs_ref})
{
my ($s_cur_tot_sum, $s_hist_tot_sum, $t_cur_tot_sum, $t_hist_tot_sum) = @{$ref};
$line1 = delta_value( $s_cur_tot_sum, $s_hist_tot_sum);			    # Source
$line2 = delta_value( $t_cur_tot_sum, $t_hist_tot_sum);			    # Total
push @line, "$line1$line2";
}

push @ROW_REFS, [ @line ];
}




sub create_ano_html_file()
{



my @counts = map { 0 } (0..$NR_LEVELS);




my @warning_refs = SCAFILE_gerr_read();
my $nr_warnings = @warning_refs;




my @src_line_refs = map { [ $_ , undef ] } ( '', SLURP_file( $CUR_FILE_SPEC), '<EOF>');  # $line_nr indexes from 1

my $nr_lines = @src_line_refs;
my $index = 0;
for (my $w = 0;  $w < $nr_warnings; $w++)
{
my $ref = $warning_refs[$w];


my $msg_id = $ref->[6];
if (SCA_msg_is_enabled( $msg_id) || exists $SPECIAL_MSG_IDS{$msg_id})
{
my $src_line_nr = $ref->[0];
$src_line_nr = $#src_line_refs
if ($src_line_nr >= $nr_lines);
push @{$src_line_refs[$src_line_nr]->[1]}, $index++;	# $warn_indexes_ref
my $msg_level = $ref->[4];
$counts[$LEVEL_INDEX{$msg_level}]++;
} else
{
$warning_refs[$w] = undef;
}
}
@warning_refs = grep defined $_, @warning_refs;
my $nr_filtered_warnings = @warning_refs;

my @ano_lines;




my $heading = "$CUR_FILE - $CUR_COMPONENT - $CUR_SUBSYS - $GBS::ROOT_PATH";
push @ano_lines, GBSHTML_doc_start( $FILE_ANO_FILE_SPEC, $heading, 0, '', undef); # $want_scripts, $body_class, $target_frame_name




my $title = "$CUR_FILE [ $GBS::AUDIT - $GBS::BUILD ]";
push @ano_lines, GBSHTML_doc_top( [ $title, HTML_link( $CUR_FILE_SPEC, HTML_bold('Actual Source File'))],
( [ $heading, '', ''],
[ "Date: $SUM_FILE_DATETIME", '', ''],
));
my $cur_section = 1;




push @ano_lines, "Nr. messages: $nr_filtered_warnings ($nr_warnings)";




push @ano_lines, GBSHTML_h( 1, undef, "Annotated source: $CUR_FILE_SPEC", ++$cur_section);




push @ano_lines, HTML_anchor( 'FIRST', '');
push @ano_lines, ano_print_nav( \@warning_refs, -1);
push @ano_lines, HTML_pre_s();
for (my $line_nr = 0; $line_nr < $nr_lines; $line_nr++)
{
my ($line, $warn_indexes_ref) = @{$src_line_refs[$line_nr]};
if (defined $warn_indexes_ref)
{



push @ano_lines, HTML_pre_e();
push @ano_lines, HTML_anchor( "ERR_LINE_$line_nr", '');
push @ano_lines, HTML_pre_s();
push @ano_lines, ano_line_html( $line_nr, $line);
foreach my $w (@{$warn_indexes_ref})
{

my ($src_line_nr, $col_nr, $filespec, $line_nr, $msg_level, $level_text,
$msg_id, $msg_text, $help_file_url, @extra_src_lines) = @{$warning_refs[$w]};




if ($filespec ne '-')
{
push @ano_lines, HTML_span( { style => "color:green" }, $filespec);
push @ano_lines, ano_line_html( $line_nr, get_file_line( $filespec, $line_nr));
}




my $color;
{
my $severity = $MSG_LEVEL_REFS{$msg_level}->[1];	    # I, W, F
$color = ($severity eq 'F') ? 'red' : ($severity eq 'W') ? 'blue' : 'black';
}




if ($col_nr >= 0)
{
my $lead = ' ' x $col_nr;
push @ano_lines, HTML_span( { style => "color:$color" }, "    $lead....^");
}




push @ano_lines, map { sprintf( "%5s:  %s", '', HTML_pre_txt( $_)); } @extra_src_lines;





push @ano_lines, HTML_pre_e();



my $html_text = HTML_text( $msg_text);
if ($help_file_url)
{
$html_text = HTML_link( { target => '_blank', style => "color:$color"} ,
"$HELP_FILES_PATH/$help_file_url", $html_text);
}
$html_text =  "** $html_text" . HTML_br() . "\n" .
"** Level: $level_text ($msg_level) -- Msg id: $msg_id";

push @ano_lines, HTML_div( { style => "color:$color" }, HTML_bold( $html_text));




push @ano_lines, ano_print_nav( \@warning_refs, $w);




push @ano_lines, HTML_pre_s();
}
} else
{



push @ano_lines, ano_line_html( $line_nr, $line);
}
}
push @ano_lines, HTML_pre_e();
push @ano_lines, HTML_anchor( 'END', '');
push @ano_lines, ano_print_nav(  \@warning_refs, $nr_filtered_warnings);




push @ano_lines, GBSHTML_h( 1, undef, "Metrics Summary: $CUR_FILE_SPEC ($nr_lines Lines)", undef);
push @ano_lines, HTML_br();

no integer;
my @row_refs;
my $t_count = 0;
for (my $level_index = 0; $level_index < $NR_LEVELS; $level_index++)
{
my $count = $counts[$level_index];
my $level = $LEVEL_TEXTS[$level_index];
$level =~ s/\\n/ /;
my $density = ($nr_lines == 0) ? 0.0 : ($count * 1.0) / $nr_lines;
push @row_refs, [ $level, sprintf( "%1.4f", $density), sprintf( "%5d", $count) ];
$t_count += $count;
}
my $t_density = ($nr_lines == 0) ? 0.0 : ($t_count * 1.0) / $nr_lines;
push @row_refs, [ '------ ', ' ------- ', ' ------------- ' ];
push @row_refs, [ 'Totals',  sprintf( "%1.4f", $t_density), sprintf( "%5d", $t_count) ];
use integer;

my @formats = qw( -L -C -C );
my @headings = ( 'Error Level', 'Density', 'No. of Errors');
push @ano_lines, HTML_table( \@formats, \@headings,
\@row_refs, class => 'border1');




push @ano_lines, GBSHTML_doc_bottom();
push @ano_lines, GBSHTML_doc_end();


SPIT_file_nl( $FILE_ANO_FILE_SPEC, \@ano_lines);

}




sub ano_line_html($$)
{
my ($line_nr,
$line,
) = @_;
my @html_lines;

push @html_lines, sprintf( "%5d:  %s", $line_nr, HTML_pre_txt( ENV_detab( $line)));

return @html_lines;
}




sub ano_print_nav($$)
{
my ($warning_refs_ref,
$warn_index,
) = @_;
my $out_line;

my $last_warn_index = $#{$warning_refs_ref};

if ($warn_index >= 0)
{
$out_line = HTML_link( "#FIRST", HTML_text( "<top>"));
} else
{
$out_line = HTML_text( '<top>');
}

if ($warn_index >= 1)
{
my $prev_nr = $warning_refs_ref->[$warn_index-1]->[0];
$out_line .= HTML_link( "#ERR_LINE_$prev_nr", HTML_text( "<prev>"));
} else
{
$out_line .= HTML_text( '<prev>');
}

if ($warn_index < $last_warn_index)
{
my $next_nr = $warning_refs_ref->[$warn_index+1]->[0];
$out_line .= HTML_link( "#ERR_LINE_$next_nr", HTML_text( "<next>"));
} else
{
$out_line .= HTML_text( '<next>');
}

if ($warn_index <= $last_warn_index)
{
$out_line .= HTML_link( "#END", HTML_text( "<bottom>"));
} else
{
$out_line .= HTML_text( '<bottom>');
}

return (HTML_bold( $out_line) . HTML_br());
}




sub get_file_line($$)
{
my ($filespec,
$line_nr,
) = @_;


my $lines_ref = $CODE_FILES_REF{$filespec};	#   $filespec=> $lines_ref;
if (!defined $lines_ref)
{

$lines_ref = $CODE_FILES_REF{$filespec} = [ SLURP_file( $filespec) ];
} else
{

}

return $lines_ref->[ $line_nr - 1 ];
}




sub create_log_html_file($$)
{
my ($garg_filespec,
$data_available,
) = @_;

my @log_lines;




my $heading = "$CUR_FILE.log - $CUR_COMPONENT - $CUR_SUBSYS - $GBS::ROOT_PATH";
push @log_lines, GBSHTML_doc_start( $FILE_LOG_FILE_SPEC, $heading, 0, '', undef); # $want_scripts, $body_class, $target_frame_name




my $title = "$CUR_FILE.log [ $GBS::AUDIT - $GBS::BUILD ]";
push @log_lines, GBSHTML_doc_top( [ $title, HTML_link(  $FILE_ANO_FILE_SPEC, HTML_bold( 'Annotated Source')) ],
( [ $heading, '', ''],
[ "Date: $SUM_FILE_DATETIME", '', ''],
));
my $cur_section = 1;




push @log_lines, GBSHTML_h( 1, undef, 'Warnings Summary', ++$cur_section);

if ($data_available)
{
my @msg_ids = sort( { $a cmp $b } keys( %GMET_MSG_REFS));

if (@msg_ids)
{
my @row_refs;
foreach my $msg_id (@msg_ids)
{

my $msg_ref = SCAMSG_get_msg_data( $msg_id);
ENV_sig( F => "Unknown message '$msg_id'")
if (!defined $msg_ref);
my (undef, $level, $level_text, $msg_text, $help_file_url) = @{$msg_ref};
my $s_cur_msg_count = $GMET_MSG_REFS{$msg_id}->[0];
my $s_hist_msg_count = $GMET_MSG_REFS{$msg_id}->[1];
my $t_cur_msg_count = $GMET_MSG_REFS{$msg_id}->[2];
my $t_hist_msg_count = $GMET_MSG_REFS{$msg_id}->[3];

my $severity = $MSG_LEVEL_REFS{$level}->[1];

my $s_diff_txt = color_text( $s_cur_msg_count, $s_hist_msg_count, $severity);
my $t_diff_txt = color_text( $t_cur_msg_count, $t_hist_msg_count, $severity);

my $msg_id_txt = $msg_id;
if ($help_file_url)
{
$msg_id_txt = HTML_link( {target => '_blank'},
"$HELP_FILES_PATH/$help_file_url",
$msg_id);
}
my $warning_txt;
if ($severity eq 'F')
{
$warning_txt = 'Error';
} else
{
$warning_txt = 'Warning';
}
$level_text = '****' if (!defined $level_text);
$msg_text = '****' if (!defined $msg_text);
push @row_refs, [ $warning_txt, $msg_id_txt, $level, $level_text,
$s_hist_msg_count, $s_cur_msg_count, $s_diff_txt,
$t_hist_msg_count, $t_cur_msg_count, $t_diff_txt,
$msg_text ];
}
my @formats = qw( - -CN -C - -R -R -N -R -R -N -N);
my @headings = ( 'Severity', 'Msg-Id', 'Level', 'Level-Txt',
'SRC<BR>Hist', 'SRC<BR>Now', 'SRC<BR>Diff',
'TOT<BR>Hist', 'TOT<BR>Now', 'TOT<BR>Diff',
'Message Text');
push @log_lines, HTML_table( \@formats, \@headings,
\@row_refs, class => 'border1');
} else
{
push @log_lines, HTML_p( "No Warnings for this file");
}
} else
{
push @log_lines, HTML_p( "No Data Available");
}




push @log_lines, GBSHTML_h( 1, undef, 'Metrics Summary:', ++$cur_section);
if ($data_available)
{
push @log_lines, generate_metrics_summary( 'FILE');
} else
{
push @log_lines, HTML_p( "No Data Available");
}




push @log_lines, GBSHTML_h( 1, undef, 'Special Messages:', ++$cur_section);
if ($data_available)
{
if (%GMET_SPECW_REFS)
{
foreach my $text (sort( keys( %GMET_SPECW_REFS)))
{
push @log_lines, HTML_h( 3, "$text:");
foreach my $item (keys( %{$GMET_SPECW_REFS{$text}}))
{
if ($item eq '')
{
push @log_lines, HTML_italic_txt( "  <Undefined>\n")
} else
{
push @log_lines, HTML_text( "  $item\n");
}
}
}
} else
{
push @log_lines, HTML_p( "No Special Messages for this file");
}
} else
{
push @log_lines, HTML_p( "No Data Available");
}




{
push @log_lines, GBSHTML_h( 1, undef, 'Master Settings file:', undef);
my @lines = SCAFILE_garg_read();
if (@lines)
{
push @log_lines, '<PRE>';
foreach my $line (@lines)
{








if (defined $VIA_RE && $line =~ $VIA_RE)
{
my $via_filespec = $1 . $VIA_FILE_TYPE;

my $abs_via_filespec = ENV_abs_paths( $CUR_SRC_PATH, $via_filespec);

push @log_lines, sprintf $VIA_FORMAT,
HTML_link( {target => '_blank'}, $abs_via_filespec,
HTML_text( $via_filespec));
} else
{
push @log_lines, $line;
}
}
push @log_lines, '</PRE>';
} else
{
push @log_lines, HTML_text( 'No data');
}

}




push @log_lines, GBSHTML_doc_bottom();
push @log_lines, GBSHTML_doc_end();


SPIT_file_nl( $FILE_LOG_FILE_SPEC, \@log_lines);
}




sub generate_message_summary()
{
my @lines;

my @row_refs;
my $total_count = 0;
my @new_messages;
foreach my $msg_id (sort( { $a cmp $b } keys %TOTAL_MSG_COUNT))
{



my $msg_ref = $TOTAL_MSG_COUNT{$msg_id};



my ($cur_msg_count, $hist_msg_count, $msg_file_count, @file_refs) = @{$msg_ref};


my (undef, $level, $level_text, $msg_text, $help_file_url) = SCAMSG_get_msg_data( $msg_id);
my $msg_link_or_txt = $msg_id;
if (defined $help_file_url)
{
$msg_link_or_txt = HTML_link( {target => '_blank'},
"$HELP_FILES_PATH/$help_file_url",
$msg_id);
}
$level = HTML_div( {class => 'worse9'}, $level)
if ($MSG_LEVEL_REFS{$level}->[1] eq 'F');	# $severity (IWF)
push @row_refs, [ $msg_link_or_txt, $level, $level_text, $hist_msg_count, $cur_msg_count, $msg_file_count, $msg_text ];




if (!GBSENV_mode_is_interactive())
{
push @new_messages, "-E $msg_id\t\t# $msg_text"
if ($cur_msg_count > $hist_msg_count);
}




my $nr_rows = int ((scalar @file_refs + 1) / 2);
while (@file_refs)
{
my @line = ( '', undef, undef, undef, undef );
for (my $i = 0; $i < 2 && @file_refs; $i++)
{
my $file_ref = shift @file_refs;
my ($subsys, $comp, $file, $count) = @{$file_ref};
my $href = ano_href( $subsys, $comp, $file);
push @line, "$href ($count)";
}
push @line, ''
if ($nr_rows > 1 && scalar @line < 6);
push @row_refs, [ @line ];
}
$total_count += $cur_msg_count;
}

push @row_refs, [ HTML_bold( 'Total:'), undef, undef, $total_count, '' ] ;

my @formats = qw( -BRN -BC -BL -BR -BR -BN -BN -BN );
my @headings = (
'Msg-Id',
'Level',
'Level-Txt',
'Hist<BR>Count',
'Cur<BR>Count',
'Nr.<BR>Files',
'Message<BR>Affected Files'
);
my @table_lines = HTML_table( \@formats,\@headings,
\@row_refs, class => 'border1');

push @lines, write_lines_or_link( 'Warning Message Summary', 'ms', \@table_lines);




if (@new_messages)
{
ENV_say( 1, "The following Msg are new. You can use this list to copy&paste into a sca_*.gbs file",
@new_messages);
}




if (%SKIPPED_MSGS)
{
my @warn_lines;
foreach my $msg_id (sort( { $a <=> $b } keys %SKIPPED_MSGS))
{
push @warn_lines, "Message $msg_id does not exist anymore: skipped ($SKIPPED_MSGS{$msg_id})";
}
ENV_sig( W => @warn_lines);
}

return @lines;
}




sub generate_metrics_summary($)
{
my ($s_type,         # 'SUMMARY' or 'FILE'
) = @_;
my @lines;




my $cur_nr_files;
my $cur_nr_class;
my $cur_nr_funcs;
my $hist_nr_files;
my $hist_nr_class;
my $hist_nr_funcs;
my $header_line;
my $met_data_ref;	# %GMET_STAT_REFS or %TOTAL_STAT_REFS
if ($s_type eq 'FILE')
{

$cur_nr_files = 1;
$cur_nr_class = $GMET_TOTAL_SUM_REFS[$NR_CLASS_I]->[0];   # $s_cur_tot_sum
$cur_nr_funcs = $GMET_TOTAL_SUM_REFS[$NR_FUNCS_I]->[0];   # $s_cur_tot_sum
$hist_nr_files = 1;
$hist_nr_class = $GMET_TOTAL_SUM_REFS[$NR_CLASS_I]->[1];   # $s_hist_tot_sum
$hist_nr_funcs = $GMET_TOTAL_SUM_REFS[$NR_FUNCS_I]->[1];   # $s_hist_tot_sum
$header_line = '';
$met_data_ref = \%GMET_STAT_REFS;
} elsif ($s_type eq 'SUMMARY')
{

$cur_nr_files = $CUR_TOTAL_FILE_COUNT;
$cur_nr_class = $SYSTEM_TOTAL_SUM_REFS[$NR_CLASS_I]->[0];   # $s_cur_tot_sum
$cur_nr_funcs = $SYSTEM_TOTAL_SUM_REFS[$NR_FUNCS_I]->[0];   # $s_cur_tot_sum
$hist_nr_files = $HIST_TOTAL_FILE_COUNT;
$hist_nr_class = $SYSTEM_TOTAL_SUM_REFS[$NR_CLASS_I]->[1];   # $s_hist_tot_sum
$hist_nr_funcs = $SYSTEM_TOTAL_SUM_REFS[$NR_FUNCS_I]->[1];   # $s_hist_tot_sum
$header_line = "SubSystems: $TOTAL_SUBSYS_COUNT, Components: $TOTAL_COMP_COUNT, Files: $cur_nr_files ($hist_nr_files)";
$met_data_ref = \%TOTAL_STAT_REFS;
} else
{
ENV_sig( F => "Invalid s_type value '$s_type'");
}
$header_line .= ", Functions: $cur_nr_funcs ($hist_nr_funcs)"
if ($cur_nr_funcs >= 0);
$header_line .= ", Classes: $cur_nr_class ($hist_nr_class)"
if ($cur_nr_class >= 0);
$header_line =~ s/^, //;		    # remove possible leading ', '
push @lines, HTML_p( HTML_bold( $header_line));

$cur_nr_funcs = -1 if ($cur_nr_funcs == 0);
$cur_nr_class = -1 if ($cur_nr_class == 0);
$hist_nr_files = -1 if ($hist_nr_files == 0);
$hist_nr_funcs = -1 if ($hist_nr_funcs == 0);
$hist_nr_class = -1 if ($hist_nr_class == 0);

my @violation_refs;

my @row_refs;
my @no_data_row_refs;
my $prev_group = 0;
no integer;
foreach my $metric_name (@MET_DEFS_ORDER)
{
my ($title, $group, $min_ref, $max_ref, $do_tot, $do_avg) = @{$MET_DEFS{$metric_name}};
if ($group != $prev_group)
{



if (@no_data_row_refs)
{
push @row_refs, @no_data_row_refs;
@no_data_row_refs = ();
}




my $metric_group_name = SCAMET_group2txt( $group);
my @headings = ('Key  ', "$metric_group_name Metrics", 'SET<br>Min', 'SET<br>Max',
'HIST<br>Min',  'HIST<br>Max',  'HIST<br>Total',	'HIST<br>Average',
'NOW<br>Min',   'NOW<br>Max',   'NOW<br>Total',	'NOW<br>Average',
);
push @row_refs, [ map { HTML_bold( $_) } @headings ];
$prev_group = $group;
}




my $metric_name_href = HTML_link( "$GBS_DOC_PATH/metrics.html#ST$metric_name", $metric_name);

my ($set_min, $set_min_sev_index, $set_min_sev) = ( '', undef, undef);
my ($set_max, $set_max_sev_index, $set_max_sev) = ( '', undef, undef);
if (defined $min_ref)
{
($set_min, $set_min_sev_index) = @{$min_ref};
$set_min_sev = substr( 'IWF', $set_min_sev_index, 1);
}
if (defined $max_ref)
{
($set_max, $set_max_sev_index) = @{$max_ref};
$set_max_sev = substr( 'IWF', $set_max_sev_index, 1);
}




if (exists $met_data_ref->{$metric_name})	# %GMET_STAT_REFS or %TOTAL_STAT_REFS
{
my ($cur_met_min, $hist_met_min, $cur_met_max, $hist_met_max, $cur_met_tot, $hist_met_tot) = @{$met_data_ref->{$metric_name}};


my @sev_classes = qw(Isame Wsame Fsame);

my ($hist_min_html, $cur_min_html,
$hist_max_html, $cur_max_html,
$hist_tot_html, $cur_tot_html,
$hist_avg_html, $cur_avg_html
) = ('', '', '', '', '', '', '', '');


{
my $hist_class = 'Wclean';
my $cur_class = 'Wclean';
if (defined $hist_met_min)
{
if ($set_min ne '' && $hist_met_min < $set_min)
{
$hist_class = $sev_classes[$set_min_sev_index];
}
$hist_min_html = HTML_div( { class => $hist_class }, dot_print( $hist_met_min, 3));
}
if ($set_min ne '' && $cur_met_min < $set_min)
{
$cur_class = $sev_classes[$set_min_sev_index];
push @violation_refs, [ $metric_name, "$cur_met_min < $set_min" ];
}
$cur_min_html = HTML_div( { class => $cur_class }, dot_print( $cur_met_min, 3));
}

if (defined $max_ref)
{
my $hist_class = 'Wclean';
my $cur_class = 'Wclean';
if (defined $hist_met_max)
{
if ($hist_met_max > $set_max)
{
$hist_class = $sev_classes[$set_max_sev_index];
}
$hist_max_html = HTML_div( { class => $hist_class }, dot_print( $hist_met_max, 3));
}
if ($cur_met_max > $set_max)
{
$cur_class = $sev_classes[$set_max_sev_index];
push @violation_refs, [ $metric_name, "$cur_met_max > $set_max" ];
}
$cur_max_html = HTML_div( { class => $cur_class }, dot_print( $cur_met_max, 3));
}

if ($do_tot)
{
$hist_tot_html = dot_print( $hist_met_tot, 2)
if (defined $hist_met_tot);
$cur_tot_html = dot_print( $cur_met_tot, 2);
}

if ($do_avg)
{
my $cur_divider;
my $hist_divider;
my $name;
if ($group == 1)        # function based
{
$cur_divider = $cur_nr_funcs;
$hist_divider = $hist_nr_funcs;
$name = 'func';
} elsif ($group == 2)   # class based
{
$cur_divider = $cur_nr_class;
$hist_divider = $hist_nr_class;
$name = 'class';
} elsif ($group == 3)   # file based
{
$cur_divider = $cur_nr_files;
$hist_divider = $hist_nr_files;
$name = 'file';
} else                  # unknown
{
;
}
my $cur_avg = $cur_met_tot / $cur_divider;
my $hist_avg = (defined $hist_met_tot) ? $hist_met_tot / $hist_divider : undef;

my $cur_average = '';
my $hist_average = '';
if (defined $name)
{
$cur_average = sprintf( "%8.2f per $name", $cur_avg);
$hist_average = sprintf( "%8.2f per $name", $hist_avg)
if (defined $hist_met_tot);
}

$cur_avg_html = $cur_average;
$hist_avg_html = $hist_average;
if (defined $max_ref)
{
my $hist_class = 'Wclean';
my $cur_class = 'Wclean';
if (defined $hist_met_tot)
{
if ($hist_avg > $set_max)
{
$hist_class = $sev_classes[$set_max_sev_index];
}
$hist_avg_html = HTML_div( { class => $hist_class }, $hist_average);
}
if ($cur_avg > $set_max)
{
$cur_class = $sev_classes[$set_max_sev_index];
}
$cur_avg_html = HTML_div( { class => $cur_class }, $cur_average);
}
}
push @row_refs, [ $metric_name_href, $title, $set_min, $set_max,
$hist_min_html, $hist_max_html, $hist_tot_html, $hist_avg_html,
$cur_min_html,  $cur_max_html,  $cur_tot_html,  $cur_avg_html ];
} else
{
my $html_no_data = HTML_div( {class => 'align-left'}, 'No data');
push @no_data_row_refs, [ $metric_name_href, $title, $set_min, $set_max, $html_no_data, undef, undef, undef ];
}
}
if (@no_data_row_refs)
{
push @row_refs, @no_data_row_refs;
@no_data_row_refs = ();
}
use integer;

if (@violation_refs && $s_type eq 'FILE')
{
my $file = "$CUR_SUBSYS:$CUR_COMPONENT:$CUR_FILE";
push @TOTAL_SUSP_FILE_REFS, [ $file, @violation_refs ];
}

my @formats = qw( -L -L -R -R -R -R -R -R -R -R -R -R);
push @lines, HTML_table( \@formats, undef, \@row_refs, class => 'border1');




if ($s_type eq 'SUMMARY')
{
if (%SKIPPED_METRICS)
{
my @warn_lines;
foreach my $metric_name (sort( keys %SKIPPED_METRICS))
{
push @warn_lines, "Metric $metric_name does not exist anymore: skipped ($SKIPPED_METRICS{$metric_name})";
}
ENV_sig( W => @warn_lines);
}
}

return @lines;
}




sub generate_settings_links()
{
my @lines;

foreach my $ref (@SCA_DEPEND_REFS)
{
my ($subsys, $sca_flags_filespec, @dependencies) = @{$ref};
if (defined $sca_flags_filespec)
{
push @lines, "$subsys: " . HTML_link( {target => '_blank'}, $sca_flags_filespec, HTML_text( $sca_flags_filespec)), HTML_br();
if (@dependencies)
{
my @li_lines;
foreach my $depend_filespec (@dependencies)
{
push @li_lines, HTML_li( HTML_link( {target => '_blank'}, $depend_filespec, HTML_text( $depend_filespec)));
}
push @lines, HTML_ul( @li_lines);
}
} else
{
push @lines, HTML_p( "$subsys: No SCA Settings file for this Audit (Build)");
}
}

return @lines;
}




sub generate_suspicious_files_list()
{
my @lines;

my $nr_susp_files = @TOTAL_SUSP_FILE_REFS;
if ($nr_susp_files > 0)
{
my @row_refs;
foreach my $ref (@TOTAL_SUSP_FILE_REFS)
{
my ($file_id , @violation_refs) = @{$ref};
my ($subsys, $comp, $file) = split ':', $file_id;
my $file_href = ano_href( $subsys, $comp, "$file.log");
my $nr_rows = int ((scalar @violation_refs + 3) / 4);

my @line = ( $file_href );
while (@violation_refs)
{
for ( my $i = 0; $i < 4 && @violation_refs; $i++)
{

my ($metric_name, $violation_text) = @{shift @violation_refs};
my $title = $MET_DEFS{$metric_name}->[0];
push @line, HTML_span({title => $title},
HTML_link( "$GBS_DOC_PATH/metrics.html#ST$metric_name", $metric_name) .
HTML_text( ": $violation_text"));
}
push @line, '' if (scalar @line < 5);
push @row_refs, [@line ];
@line = (undef);
}
}
my @formats = qw( -T -N -N -N -N );
my @headings = ( 'File', 'Metrics Violations');
my @table_lines = HTML_table( \@formats, \@headings, \@row_refs, class => 'border1');
push @lines, write_lines_or_link( 'Suspicious Files Summary', 'sf', \@table_lines);

ENV_say( 1, "$nr_susp_files Suspicious file(s) found");
} else
{
my $line = "No Suspicious Files found.";
push @lines, HTML_p( HTML_bold( $line));
ENV_say( 1, $line);
}

return @lines;
}




sub generate_worse_files_list()
{
my @lines;

if (%TOTAL_WORSE_FILES)
{
ENV_say( 1, "Decreased Quality:");
my @row_refs;
my @scf_files = sort( keys( %TOTAL_WORSE_FILES));
my $max_scf_length = 0;
map { $max_scf_length = length( $_) if (length( $_) > $max_scf_length) } @scf_files;
foreach my $scf_file (@scf_files)
{
my @line;
my ($subsys, $comp, $file) = split ':', $scf_file;
my ($is_new_file, $total_count, $fatal_count, $density_is_same) = @{$TOTAL_WORSE_FILES{$scf_file}};

my $pfatal_count = ($fatal_count > 0) ? " ($fatal_count)" : '';
my $new = ($is_new_file) ? 'new' : '';

my $href = ano_href( $subsys, $comp, $file);
push @row_refs, [ $href, "+$total_count", $new, $pfatal_count ];

ENV_say( 2, sprintf( "**> %-*s +%3d$pfatal_count $new", $max_scf_length + 1, "$scf_file:", $total_count));
}
push @lines, HTML_table( [ qw( - -R -C -R ) ],
[ qw( File Warnings New Errors ) ],
\@row_refs, class => 'border1');
} else
{
my $line = "All $CUR_TOTAL_FILE_COUNT file(s) Same or Increased Quality";
push @lines, HTML_p( $line);
ENV_say( 1, $line);
}

return @lines;
}




sub generate_special_warnings_summary()
{
my @lines;

if (%TOTAL_SPECW_REFS)
{
my @row_refs;
foreach my $text (sort( keys( %TOTAL_SPECW_REFS)))
{
foreach my $item (sort( keys( %{$TOTAL_SPECW_REFS{$text}})))
{
my ($cur_count, $hist_count) = @{$TOTAL_SPECW_REFS{$text}->{$item}};
my $html_item = $item;
if ($item eq '')
{
$item = '<Undefined>';
$html_item = HTML_italic_txt( $item);
}
ENV_say( 1, "****> $text: $item ($cur_count, $hist_count)");
push @row_refs, [ $text, $html_item, $cur_count, $hist_count ];
}
}
push @lines, HTML_table( [ qw( - - -R -R) ],
[ qw( Warning/Error Item Cur<BR>Occurs Hist<BR>Occurs) ],
\@row_refs, class => 'border1');
} else
{
push @lines, HTML_p( HTML_bold( 'No Special Messages'));
}

return @lines;
}




sub write_lines_or_link($$$)
{
my ($heading,
$type,		    # without the dot! e.g.: 'ms', 'sf'
$lines_ref,
) = @_;
my @lines;

if (@{$lines_ref} > 100)

{
my $file_name = "$SUM_FILE_NAME.$type";
my $file = "$file_name$SUM_FILE_TYPE";		    # .html
my $filespec = "$SUM_FILE_PATH/$file";


{
my @file_lines;
push @file_lines, GBSHTML_doc_start( $filespec, "$PLUGIN_NICE_NAME $heading $file",
0, '', undef); # $want_scripts, $body_class, $target_frame_name

my $title = "$PLUGIN_NICE_NAME $heading";
push @file_lines, GBSHTML_doc_top( [ $title, HTML_link( $SUM_FILE_SPEC, HTML_bold('Summary_file'))],
[ "Date: $SUM_FILE_DATETIME", '' ],
);
push @file_lines, HTML_br();
push @file_lines, @{$lines_ref};
push @file_lines, GBSHTML_doc_bottom();
push @file_lines, GBSHTML_doc_end();
SPIT_file_nl( $filespec, \@file_lines);
}
push @lines, HTML_p(
HTML_text( "$heading very large - Created in seperate file: "),
HTML_link( {target => '_blank'}, $filespec, "$file"));
return @lines;
} else
{
return @{$lines_ref};
}
}




sub get_diff($$$)
{

my ($msg_count,
$hist_count,
$severity,	# I, W, F
) = @_;
my $diff_class;

$hist_count = 0
if (!defined $hist_count);

my $diff_type;
if ($msg_count > $hist_count)	    # worse
{
$diff_type = 'worse';
} elsif ($msg_count == $hist_count)	    # same
{
if ($msg_count == 0)
{
$diff_type = 'clean';
} else
{
$diff_type = 'same';
}
} else				    # better
{
if ($msg_count == 0)
{
$diff_type = 'gone';
} else
{
$diff_type = 'better';
}
}

$diff_class = "$severity$diff_type";


return $diff_class;
}




sub color_text($$$)
{
my ($value,
$hist_value,
$severity,	# I, W, F
) = @_;

my $diff_class = get_diff( $value, $hist_value, $severity);
my $diff_text = $DIFFS{$diff_class}->[0];
return HTML_div( {class => $diff_class}, $diff_text);
}




sub color_value($$$)
{
my ($value,
$hist_value,
$severity,  	# I, W, F
) = @_;

my $diff_class = get_diff( $value, $hist_value, $severity);
my @div = (class => $diff_class);
push @div, (title => $hist_value) if ($value != $hist_value);

return HTML_div( {@div}, $value);
}




sub color_value_f($$$)
{
my ($value,
$hist_value,
$severity,	# I, W, F
) = @_;
my $html;

my $diff_class = get_diff( $value, $hist_value, $severity);
my @div = (class => $diff_class);

no integer;
push @div, (title => sprintf( "%0.3f", $hist_value / 1000.0))
if ($value != $hist_value);
$html = HTML_div( {@div}, sprintf( "%0.3f", $value / 1000.0));
use integer;

return $html;
}




sub delta_value($$)
{
my ($cur_value,
$hist_value,
) = @_;
my $html;


if ($cur_value >= 0)
{
if ($cur_value == $hist_value)
{
$html = HTML_div( HTML_text( "$cur_value="));
} else
{
my $diff = ($cur_value > $hist_value) ? '>' : '<';
$html = HTML_div( {title => $hist_value}, HTML_text( "$cur_value$diff"));
}
} else
{
$html = HTML_text( ' ');
}

return $html;
}




sub clear_totals($)
{
my ($sum_level) = @_;   # 0 = line, 1 = comp, 2 = subsys, 3 = system

my ($msg_sum_refs_ref, $tot_sum_refs_ref) = @{$SUM_REFS[$sum_level]};

foreach my $i (0 .. 3)
{
map { $msg_sum_refs_ref->[$_]->[$i] = 0 } 0 .. $LAST_LEVEL_I;
map { $tot_sum_refs_ref->[$_]->[$i] = 0 } 0 .. $LAST_TOT_I;

}
}





sub add_totals($)
{
my ($sum_level,             # 0 = line, 1 = comp, 2 = subsys, 3 = system
) = @_;

my ($from_msg_sum_refs_ref, $from_tot_sum_refs_ref) = @{$SUM_REFS[$sum_level]};
my ($to_msg_sum_refs_ref,   $to_tot_sum_refs_ref)   = @{$SUM_REFS[$sum_level + 1]};

foreach my $i (0 .. 3)
{
map { $to_msg_sum_refs_ref->[$_]->[$i] += $from_msg_sum_refs_ref->[$_]->[$i] } 0 .. $LAST_LEVEL_I;
map { $to_tot_sum_refs_ref->[$_]->[$i] += $from_tot_sum_refs_ref->[$_]->[$i] } 0 .. $LAST_TOT_I;
}
}




sub calc_levels_sum($)
{
my ($sum_refs_ref) = @_;
my @sums = (0,0,0,0);

foreach my $ref (@{$sum_refs_ref})
{
map { $sums[$_] += $ref->[$_] } ( 0 .. 3);
}

return @sums;
}




sub calc_density($$$$)
{
my ($total_nr_msg,
$total_nr_lines,
$source_nr_msg,	    # in case total_nr_lines == 0
$source_nr_lines,   # in case total_nr_lines == 0
) = @_;
my $density = 0;


if ($total_nr_msg > 0)
{
if ($total_nr_lines > 0)
{
$total_nr_msg *= 1000;
$density = $total_nr_msg / $total_nr_lines;
} elsif ($source_nr_lines > 0)
{
$source_nr_msg *= 1000;
$density = $source_nr_msg / $source_nr_lines;
}
$density = 1
if $density == 0;
$density = - $density
if ($total_nr_lines <= 0);
}
return $density;
}




sub ano_href($$$)
{
my ($subsys,
$component,
$file,
) = @_;

my $name = "${subsys}::${component}:$file";
my $filespec = "$GBS::ROOT_PATH/dev/$subsys/comp/$component/aud/$GBS::AUDIT/$GBS::BUILD/$file.html";

return HTML_link( {target => '_blank'}, $filespec, $name);
}




sub print_legend()
{
my @lines;

push @lines, HTML_bold_txt( "Legend:");

my @row;
my $cell;
foreach my $type (qw( Wclean Wgone))
{
my $color_text = $DIFFS{$type}->[1];
$cell .= HTML_div( {class => $type}, $color_text);
}
push @row, $cell;
$cell = '';
foreach my $type (qw( Wbetter Wsame Wworse))
{
my $color_text = $DIFFS{$type}->[1];
$cell .= HTML_div( {class => $type}, $color_text);
}
push @row, $cell;
$cell = '';
foreach my $type (qw( Fbetter Fsame Fworse))
{
my $color_text = $DIFFS{$type}->[1];
$cell .= HTML_div( {class => $type}, $color_text);
}
push @row, $cell;

$cell = HTML_text( "Source\nTotal\nDensity");
push @row, scalar HTML_table( undef, undef, [[$cell]], class => 'border1');
push @row, HTML_bold_txt( "Nr.Lines:\n") .
HTML_text( "  Source = Nr lines in source\n" .
"  Total = Nr lines after preprocessing");
push @row, HTML_bold_txt( "Density:\n").
HTML_text( "  Positive: TotalNr.Msgs / Nr.TotalLines  (lines after preprocessing)\n".
"  Negative: SourceNr.Msgs / Nr.SourceLines (lines in source)");

push @lines, HTML_table( [ qw( -T -T -T -T) ],
undef,
[ [ @row ] ],
cellspacing => 10);

return @lines;
}




sub dot_print($$)
{
my ($value,
$decimals,
) = @_;

if (index( $value, '.') >= 0)
{
$value = sprintf( "%.${decimals}f", $value);
}
return $value;
}




sub read_cur_gmet_file()
{
my $file_exists = SCAFILE_gmet_read( undef);

if ($file_exists)
{
gmet_store_all( 0);	# cur values
}

return $file_exists;
}





sub read_hist_gmet_file()
{
my $is_new_file;

my $gmet_file = "$CUR_FILE.gmet";
my @lines = SCAHIST_get_file( $CUR_SUBSYS, $CUR_COMPONENT, $gmet_file);
if (@lines)
{
SCAFILE_gmet_read( \@lines);

gmet_store_all( 1);	# hist values

$HIST_TOTAL_FILE_COUNT++;
$is_new_file = 0;
} else
{
ENV_say( 1, "No History for $CUR_SUBSYS:$CUR_COMPONENT:$gmet_file");
$is_new_file = 1;
}

return $is_new_file;
}




sub gmet_init()
{
%GMET_MSG_REFS = ();
%GMET_SPECW_REFS = ();
%GMET_STAT_REFS = ();
}




sub gmet_store_all($)
{
my ($gmet_index,        # 0 = cur, 1 = hist
) = @_;




gmet_store_warnings( $gmet_index);




gmet_store_totals( $gmet_index);




gmet_store_specws( $gmet_index);




gmet_store_stats( $gmet_index);
}





sub gmet_store_warnings($)
{
my ($gmet_index,        # 0 = cur, 1 = hist
) = @_;

foreach my $gmet_count_ref (SCAFILE_gmet_get_counts())
{
my ($msg_level, $msg_id, $s_msg_count, $t_msg_count) = @{$gmet_count_ref};
if ($gmet_index == 0 || SCAMSG_msg_exists( $msg_id))	    # In case of 'hist' message may not exist anymore
{
if (SCA_msg_is_enabled( $msg_id) || exists $SPECIAL_MSG_IDS{$msg_id})	    # TBS Sure????
{


$GMET_MSG_REFS{$msg_id} = [ 0, 0, 0, 0 ]
if (!exists $GMET_MSG_REFS{$msg_id});
$GMET_MSG_REFS{$msg_id}->[0 + $gmet_index] = $s_msg_count;		# $s_index_msg_count
$GMET_MSG_REFS{$msg_id}->[2 + $gmet_index] = $t_msg_count;		# $t_index_msg_count

my $msg_level_index = $LEVEL_INDEX{$msg_level};
$GMET_MSG_SUM_REFS[$msg_level_index]->[0 + $gmet_index] += $s_msg_count;	# $s_index_msg_sum
$GMET_MSG_SUM_REFS[$msg_level_index]->[2 + $gmet_index] += $t_msg_count;	# $t_index_msg_sum
}
} else
{
$SKIPPED_MSGS{$msg_id}++;
}
}
}





sub gmet_store_totals($)
{
my ($gmet_index,     # 0 = cur, 1 = hist
) = @_;

foreach my $gmet_total_ref (SCAFILE_gmet_get_totals())
{
my ($index, $total_name, $s_count, $t_count) = @{$gmet_total_ref};



$GMET_TOTAL_SUM_REFS[$index]->[0 + $gmet_index] = $s_count;		# $s_index_tot_sum
$GMET_TOTAL_SUM_REFS[$index]->[2 + $gmet_index] = $t_count;		# $t_index_tot_sum
}
}






sub gmet_store_specws($)
{
my ($gmet_index,     # 0 = cur, 1 = hist (cur only!)
) = @_;

if ($gmet_index == 0)
{
foreach my $gmet_specws_ref (SCAFILE_gmet_get_specws())
{
my ($warning_text, $item) = @{$gmet_specws_ref};

if (!exists $GMET_SPECW_REFS{$warning_text}->{$item})
{
$GMET_SPECW_REFS{$warning_text}->{$item}  = [ 0, 0 ];   # [ $cur_count, $hist_count ]
$TOTAL_SPECW_REFS{$warning_text}->{$item} = [ 0, 0 ];   # [ $cur_count, $hist_count ]
}
$GMET_SPECW_REFS{$warning_text}->{$item}->[$gmet_index]++;
$TOTAL_SPECW_REFS{$warning_text}->{$item}->[$gmet_index]++;
}
}
}






sub gmet_store_stats($)
{
my ($gmet_index,     # 0 = cur, 1 = hist
) = @_;

foreach my $gmet_stats_ref (SCAFILE_gmet_get_stats())
{
my ($metric_name, $new_min, $new_max, $new_total) = @{$gmet_stats_ref};

if ($gmet_index == 0 || exists $GMET_STAT_REFS{$metric_name})    # In case of 'hist' metric may not exist anymore
{
no integer;     # enable floats




{
$GMET_STAT_REFS{$metric_name}->[0 + $gmet_index] = $new_min;
$GMET_STAT_REFS{$metric_name}->[2 + $gmet_index] = $new_max;
$GMET_STAT_REFS{$metric_name}->[4 + $gmet_index] = $new_total;
}




if (exists $TOTAL_STAT_REFS{$metric_name})
{
my $met_min = $TOTAL_STAT_REFS{$metric_name}->[0 + $gmet_index];
$TOTAL_STAT_REFS{$metric_name}->[0 + $gmet_index] = $new_min
if (!defined $met_min || $new_min < $met_min);
my $met_max = $TOTAL_STAT_REFS{$metric_name}->[2 + $gmet_index];
$TOTAL_STAT_REFS{$metric_name}->[2 + $gmet_index] = $new_max
if (!defined $met_max || $new_max > $met_max);
$TOTAL_STAT_REFS{$metric_name}->[4 + $gmet_index] += $new_total;
} else
{

$TOTAL_STAT_REFS{$metric_name}->[0 + $gmet_index] = $new_min;
$TOTAL_STAT_REFS{$metric_name}->[2 + $gmet_index] = $new_max;
$TOTAL_STAT_REFS{$metric_name}->[4 + $gmet_index] = $new_total;
}

use integer;    # disable floats
} else
{
$SKIPPED_METRICS{$metric_name}++;
}
}
}

1;


