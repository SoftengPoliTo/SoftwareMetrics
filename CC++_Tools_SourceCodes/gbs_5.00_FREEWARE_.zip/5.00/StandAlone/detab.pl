#=================================================
#
#   detab.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;









sub run_detab($);
sub find_files_recursively(@);
sub recurse_dir($);
sub find_files(@);
sub do_args();
sub usage();
sub detab($$);
sub retab($);
sub warning($;@);
sub error($;@);
sub fatal($;@);
sub env_say($@);




my $RC = 0;
my $MAIN_NAME_UC;
my $PREFIX;
my $PREFIX_;
my $IS_WIN32;
my $XTERM_WIDTH;
my $XTERM_HEIGHT;

BEGIN
{
$| = 1;							# $OUTPUT_AUTOFLUSH
($MAIN_NAME_UC) = map { uc $_ } "/$0" =~ m!.*[/\\](.+)\.!;	# Extract filename and make it uppercase
$PREFIX = $MAIN_NAME_UC;
$PREFIX_ = ' ' x (length( $PREFIX) + 1);
$IS_WIN32 = ($^O eq 'MSWin32');
$XTERM_WIDTH = 100;
$XTERM_HEIGHT = 50;
if (-t STDOUT)
{
if ($IS_WIN32)
{
require Win32::Console;
import  Win32::Console;
($XTERM_WIDTH, $XTERM_HEIGHT) = Win32::Console->new()->Size();
} else
{
($XTERM_HEIGHT, $XTERM_WIDTH) = split( / /, qx(stty size));
}
}




CORE::say( '=' x ($XTERM_WIDTH - 5) . '');
}








my @MSG_LINES;

my @REL_FILE_SPECS;
my @RECURSE_WILD_SPECS;
my $IS_TEST_MODE = 0;
my $MUST_RECURSE = 0;
my $MODULO = 8;
my $SMART_TABS = 0;

my $NR_FILES_MODIFIED = 0;
my $NR_FILES_WRITTEN = 0;






=optdoc
use glo::genopt;












{
my @genopts = (
[ '<*>', 'files',    'sso',	"", "Files to process or directory in case of -r" ],
[ 't', 'test',	     'bso',	 0, "test only - do not make modifications" ],
[ 'r', 'recurse',    'bso',	 0, "recurse directory looking for -f= files" ],
[ 'f', 'wild_files', 'sao',	"", "wild-card files to process" ],
[ 'm', 'modulo',     'iso',	 8, "The TAB size the file was created with" ],
[ 's', 'smart_tabs', 'bso',	 0, "retab leading whitespace (modulo 8)" ],
);
GENOPT_set_flag_prefix( '-');
GENOPT_set_optdefs( 'detab', \@genopts,
'Replace TABs by spaces in files',
undef);
GENOPT_parse();
}

=cut




do_args();




{
if (@REL_FILE_SPECS)
{
env_say( 1, "Found " . scalar @REL_FILE_SPECS . " file(s).");
foreach my $file (@REL_FILE_SPECS)
{
run_detab( $file);
}
} else
{
warning( "No files found");
}
}




{
env_say( 0, '');
my $nr_files_parsed = @REL_FILE_SPECS;
env_say( 1, "Files parsed/modified/written: $nr_files_parsed / $NR_FILES_MODIFIED / $NR_FILES_WRITTEN");
}

exit $RC;




END
{
if (@MSG_LINES)
{
env_say( 1, "The following warnings/errors were encountered:");
env_say( 2, @MSG_LINES);
}

my $rc = $?;
print( "\a")
if ($rc > 0 || @MSG_LINES > 0);

env_say( 1, ($rc) ? "Failed ($?)" : "Done");
}




sub run_detab($)
{
my ($file) = @_;

env_say( 1, " File: $file");
if (open( my $in_fh, '<', $file))
{
my @lines = <$in_fh>;
close $in_fh;
my $detab_count = 0;
foreach my $line (@lines)
{
my $old_line = $line;
$line = detab( $line, $MODULO);
$line = retab( $line)
if ($SMART_TABS);
if ($line ne $old_line)
{
$detab_count++;


}
}
if ($detab_count > 0)
{
$NR_FILES_MODIFIED++;

if ($IS_TEST_MODE)
{
env_say( 1, " Test-mode: $detab_count lines detabbed");
} else
{
if (open( my $out_fh, '>', $file))
{
print( $out_fh @lines);
close $out_fh;
env_say( 1, " Written: $detab_count lines detabbed");
$NR_FILES_WRITTEN++;
} else
{
error( "Unable to write file $file", "- $!");
}
}
}

} else
{
error( "Unable to open file $file", "- $!");
}
}




sub find_files_recursively(@)
{
my @wild_dirs = @_;
my @rel_filespecs;

foreach my $wild_dir_spec (@wild_dirs)
{
$wild_dir_spec =~ s!//!/!g;
$wild_dir_spec =~ s!/$!!g;
}
env_say( 1, "Recursing (@RECURSE_WILD_SPECS) files in (@wild_dirs) ...");
foreach my $wild_dir_spec (@wild_dirs)
{
my @dir_specs;
if ($wild_dir_spec =~ /[\*\?]/)
{
push @dir_specs, grep -d $_, glob( $wild_dir_spec);
} else
{
if (-d $wild_dir_spec)
{
push @dir_specs, $wild_dir_spec;
} elsif (-f _)
{
warning( "FileSpec must be directory: '$wild_dir_spec'");
} else
{
warning( "No such directory '$wild_dir_spec'");
}
}
foreach my $dir_spec (@dir_specs)
{
push @rel_filespecs, recurse_dir( $dir_spec);
}
}

return @rel_filespecs;
}





sub recurse_dir($)
{
my ($dir,
) = @_;
my @rel_filespecs;




foreach my $wild_file (@RECURSE_WILD_SPECS)
{
my $filespec = "$dir/$wild_file";
if ($wild_file =~ /[\*\?]/)
{
push @rel_filespecs, grep ! -d $_, glob( $filespec);
} else
{
if (-f $filespec)
{
push @rel_filespecs, $filespec;
}
}
}




opendir( DIR, "$dir") || fatal( "Cannot opendir '$dir'", $?);
my @entries = readdir( DIR);
closedir( DIR);
foreach my $entry (@entries)
{
next if (substr( $entry, 0, 1) eq '.');	    # Skip directories/files starting with '.'
my $this_dir = "$dir/$entry";
push @rel_filespecs, recurse_dir( $this_dir)
if (-d $this_dir);
}

return @rel_filespecs;
}




sub find_files(@)
{
my @filespecs = @_;
my @rel_filespecs;

env_say( 1, "Files: (@filespecs)");

foreach my $filespec (@filespecs)
{
if ($filespec =~ /[\*\?]/)
{
push @rel_filespecs, glob( $filespec);
} else
{
if (-f $filespec)
{
push @rel_filespecs, $filespec
} elsif (-d _)
{
warning( "FileSpec must be file: '$filespec'");
} else
{
warning( "No such file '$filespec'");
}
}
}

return @rel_filespecs;
}




sub do_args()
{
env_say( 1, "@ARGV");
if (@ARGV == 1 && $ARGV[0] =~ /^--?(h|help)$/)
{
usage();
exit 0;
} else
{
if (@ARGV < 1)
{
usage();
exit 9;
}
}




my @rel_file_defs;
foreach my $arg (@ARGV)
{
if (substr($arg,0,1) eq '-')
{
if ($arg eq '-t' || $arg eq '-t+')
{
$IS_TEST_MODE = 1;
} elsif ($arg eq '-t-')
{
$IS_TEST_MODE = 0;
} elsif ($arg eq '-r' || $arg eq '-r+')
{
$MUST_RECURSE = 1;
} elsif ($arg eq '-r-')
{
$MUST_RECURSE = 0;
} elsif (substr( $arg, 0, 3) eq '-r=')
{
$MUST_RECURSE = 1;
$arg = substr ($arg, 3);
push @RECURSE_WILD_SPECS, split( ',', $arg);
} elsif (substr( $arg, 0, 3) eq '-f=')
{
$arg = substr ($arg, 3);
push @RECURSE_WILD_SPECS, split( ',', $arg);
} elsif (substr( $arg, 0, 3) eq '-m=')
{
$arg = substr ($arg, 3);
($MODULO) = $arg =~ /^(\d+)$/;
if (!defined $MODULO || $MODULO < 1)
{
env_say( 1, "Option -m= requires a decimal number > 0 ($arg)");

exit 9;
} else
{
env_say( 1, "Modulo set to $MODULO");
}
} elsif ($arg eq '-s' || $arg eq '-s+')
{
$SMART_TABS = 1;
} elsif ($arg eq '-s-')
{
$SMART_TABS = 0;
} else
{
env_say( 1, "Invalid option '$arg'. Allowed '-t', '-r', '-r=<files>', '-f=<files>', '-m=<modulo>', '-s'");
usage();
exit 9;
}
} else
{
push @rel_file_defs, $arg;
}
}

if ($MUST_RECURSE && @RECURSE_WILD_SPECS == 0)
{
env_say( 1, "No recurse (wild-)files specified. Assume *.*");
push @RECURSE_WILD_SPECS, '*.*';
}




if ($IS_WIN32)
{
foreach my $rel_file_def (@rel_file_defs)
{
$rel_file_def =~ tr!\\!/!;
}
}




if ($MUST_RECURSE)
{
@REL_FILE_SPECS = find_files_recursively( @rel_file_defs);
} else
{
@REL_FILE_SPECS = find_files( @rel_file_defs);
}





{
my %seen;
@REL_FILE_SPECS = grep { ! $seen{ $_ }++ } @REL_FILE_SPECS;
}
}




sub usage()
{
CORE::say( "usage is: detab <files...>|<dir> [-t] [-r] [-r=<files>] [-f=<files> [-s]");
CORE::say( "    -t          == test-only");
CORE::say( "    -r          == recurse directory");
CORE::say( "    -r=<files>  == recurse direcory using comma-separated wild files");
CORE::say( "    -f=<files>  == comma-separated wild files");
CORE::say( "    -m=<modulo> == number specifying original modulo (default=8)");
CORE::say( "    -s          == smart_tabs: retab leading whitespace (modulo 8)");
}





sub detab($$)
{
my ($line,
$modulo,
) = @_;

my $tab_pos = index( $line, "\t");
while ($tab_pos >= 0)
{

my $wanted_out_pos = (($tab_pos + $modulo) /$modulo) * $modulo;
my $nr_spaces = $wanted_out_pos - $tab_pos;
my $spaces = ' ' x $nr_spaces;
$line = substr( $line, 0, $tab_pos) .
$spaces .
substr( $line, $tab_pos + 1);

$tab_pos = index( $line, "\t");
}

return $line;
}





sub retab($)
{
my ($line,
) = @_;
my $new_line = '';


while (substr( $line, 0, 8) eq '        ')
{
$new_line .= "\t";
$line = substr( $line, 8);
}
$new_line .= $line;

return $new_line;
}




sub warning($;@)
{
my ($first_line,
@rest_lines,
) = @_;

env_say( 1, "*WARNING* $first_line");
if (@rest_lines)
{
map { env_say( 2, $_) } @rest_lines;
}
push @MSG_LINES, "WRN: $first_line";
}




sub fatal($;@)
{
my ($first_line,
@rest_lines,
) = @_;

env_say( 1, "*FATAL* $first_line");
if (@rest_lines)
{
map { env_say( 2, $_) } @rest_lines;
}
push @MSG_LINES, "FTL: $first_line";

exit 9;
}




sub error($;@)
{
my ($first_line,
@rest_lines,
) = @_;

env_say( 1, "*ERROR* $first_line");
if (@rest_lines)
{
map { env_say( 2, $_) } @rest_lines;
}
push @MSG_LINES, "ERR: $first_line";
$RC = 2
if ($RC < 2);
}




sub env_say($@)
{
my ($indent,    # 0 = no prefix, 1 = $prefix, 2 = $prefix_ - Negative = prefix_level - 1
@lines_and_or_refs
) = @_;

my @lines = map { (ref $_) ? @{$_} : $_ } @lines_and_or_refs;
if ($indent == 0)
{
map { CORE::say( $_) } @lines;
} else
{
if (abs( $indent) == 1)
{
my $first_line = shift @lines;
CORE::say( "$PREFIX: $first_line");
}
map { CORE::say( "$PREFIX_ $_") } @lines;
}
}


