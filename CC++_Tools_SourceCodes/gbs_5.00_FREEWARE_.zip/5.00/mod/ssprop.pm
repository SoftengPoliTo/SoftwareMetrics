#=================================================
#
#   ssprop.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::ssprop;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SSPROP_read
SSPROP_is_full_gbs
SSPROP_get_all_types
SSPROP_get_type
SSPROP_set_type
);
}




use glo::env;
use glo::slurp;
use glo::spit;




sub SSPROP_read($$;$);
sub SSPROP_is_full_gbs($$);
sub SSPROP_get_all_types();
sub SSPROP_get_type($$);
sub SSPROP_set_type($$$);

sub read_file($$);
sub get_key($$);




my $IS_WIN32 = ENV_is_win32();




my %CACHE;



my @ALL_TYPE_REFS = (

[ 'GBS',			    'GBS' ,  1, 1 ],
[ 'Microsoft Visual Studio',    'MSVS',  1, 0 ],
[ 'make',			    'make',  1, 1 ],
[ 'Other',			    'Other', 1, 1 ],
);

my @ALL_TYPES = map { $_->[1] } @ALL_TYPE_REFS;	    # $name
my %ALL_TYPES = map { $_ => 1 } @ALL_TYPES;

my @ALL_VALID_TYPE_REFS;


if ($IS_WIN32)
{
@ALL_VALID_TYPE_REFS = grep( $_->[2] == 1, @ALL_TYPE_REFS);	# $for_win32
} else
{
@ALL_VALID_TYPE_REFS = grep( $_->[3] == 1, @ALL_TYPE_REFS);	# $for lunix
}




sub SSPROP_read($$;$)
{
my ($root_path,	    # If undef, $GBS::ROOT_PATH is assumed
$subsys,
$force_read,	    # Optional
) = @_;

my $key = get_key( $root_path, $subsys);
read_file( $root_path, $subsys)
if ($force_read || !exists $CACHE{$key});
}




sub SSPROP_is_full_gbs($$)
{
my ($root_path,	# If undef, $GBS::ROOT_PATH is assumed
$subsys,
) = @_;


return (SSPROP_get_type( $root_path, $subsys) eq 'GBS') ? 1 : 0;
}




sub SSPROP_get_all_types()
{

return @ALL_VALID_TYPE_REFS;
}




sub SSPROP_get_type($$)
{
my ($root_path,	# If undef, $GBS::ROOT_PATH is assumed
$subsys,
) = @_;
my $type;		# GBS, MSVS, make, Other

my $key = get_key( $root_path, $subsys);
read_file( $root_path, $subsys)
if (!exists $CACHE{$key});

return $CACHE{$key};
}





sub SSPROP_set_type($$$)
{
my ($root_path,	# If undef, $GBS::ROOT_PATH is assumed
$subsys,
$type,		# from @ALL_VALID_TYPE_REFS
) = @_;
my $ssproc_filespec;

my @valid_types = map { $_->[1] } @ALL_VALID_TYPE_REFS; # $type
ENV_sig( F => "Invalid type '$type' (@valid_types)")
if (!grep( $type eq $_, @valid_types));

(my $key, $root_path) = get_key( $root_path, $subsys);
$ssproc_filespec = "$root_path/dev/$subsys/ssprop.gbs";
SPIT_file( $ssproc_filespec, $type);
$CACHE{$key} = $type;

return $ssproc_filespec;
}




sub read_file($$)
{
my ($root_path,	# If undef, $GBS::ROOT_PATH is assumed
$subsys,
) = @_;

(my $key, $root_path) = get_key( $root_path, $subsys);
my $ssprop_filespec = "$root_path/dev/$subsys/ssprop.gbs";
my $type;
if (-e $ssprop_filespec)
{
($type) = SLURP_file( $ssprop_filespec);
ENV_sig( EE => "Invalid type '$type' (@ALL_TYPES)")
if (!exists $ALL_TYPES{$type});
} else
{
$type = 'UNK';
}
$CACHE{$key} = $type;
}




sub get_key($$)
{
my ($root_path,	# If undef, $GBS::ROOT_PATH is assumed
$subsys,
) = @_;
my ($key, $new_root_path);

if (defined $root_path)
{
$key = "$root_path/$subsys";
$new_root_path = $root_path;
} else
{
$key = "./$subsys";
$new_root_path = $GBS::ROOT_PATH;
}

return (wantarray) ? ($key, $new_root_path) : $key;
}

1;


