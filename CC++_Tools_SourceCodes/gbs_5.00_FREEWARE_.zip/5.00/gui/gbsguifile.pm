#=================================================
#
#  gbsguifile.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package gui::gbsguifile;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSGUIFILE_new_dir
GBSGUIFILE_new_file
GBSGUIFILE_delete
);
}




use Tkx;

use glo::env;

use glo::scm;

use glo::tkxmessage;
use glo::tkxform;

use mod::gbsscm;
use mod::dirstruct;
use mod::templates;
use mod::floc;
use mod::gbsedit;
use gui::gbsguiexec;




sub GBSGUIFILE_new_dir($$);
sub GBSGUIFILE_new_file($$);
sub GBSGUIFILE_delete($$$);

sub dirname_changed($$$$$);
sub filename_changed($$$$$);
sub add_to_scm_changed($$$$);












my $SCMS_ACTIVE = 0;
my $ALLOW_SCMS;




sub GBSGUIFILE_new_dir($$)
{
my ($command,
$path,
) = @_;
my $nr_created = 0;

ENV_pushd( $path);

my $parent_state = SCM_get_states( $path, 0);	    # pre_validated




my $ALLOW_SCMS = ($parent_state >= 0) ? 1 : 0;
my @mnem_refs = (

[ undef, 'Directory_name',  '', 'ssmd-1', undef, undef, 1, \&dirname_changed ],	# may not exist
[ undef, 'Add to SCM',      '', 'bsm',        0, undef, $ALLOW_SCMS ],
);

my @values = TKXFORM_dialogue( $TKX::MW, 'Create new Directory', \@mnem_refs, undef, undef, "Path: $path");
if (@values)
{
my ($dir_name, $add_scm) = @values;
my $dirspec = "$path/$dir_name";

if ($add_scm)
{
if (!$SCMS_ACTIVE)
{
GBSSCM_preset( 0);
GBSSCM_connect();
$SCMS_ACTIVE = 1;
}
SCM_add_dirs( $dirspec, \&DIRSTRUCT_get_ignore_spec, 0, 0);	    # $pre_validated, $verbose
$nr_created++;
} else
{
$nr_created += ENV_mkdir( $dirspec, undef, 'E');
}
}

ENV_popd();

return $nr_created;
}




sub dirname_changed($$$$$)
{
my ($this_widget,
$validate_action,   # key or focusout
$newer_value,
$mnem,
$form_ref,  # [ $this_tl, $form_name, $mnem_refs_ref, $mnem_hash_ref, $is_modal, $ok_func];

) = @_;
my ($is_ok, $error_text) = ( 1, undef);



if ($validate_action eq 'key')
{
if ($ALLOW_SCMS)
{
my $dirspec = '';
if ($newer_value ne '')
{
my $cwd = ENV_cwd();
$dirspec = "$cwd/$newer_value";




my ($scm, $avail) = DIRSTRUCT_file_attrib( $dirspec);


my $new_state;
my $new_value;
if ($scm == 0)
{
TKXFORM_store_value( $form_ref, 'Add to SCM', 0, 'disable');
} elsif ($scm == 1)
{
TKXFORM_store_value( $form_ref, 'Add to SCM', 1, 'normal');
} else
{
TKXFORM_set_state( $form_ref, 'Add to SCM', '');
}
} else
{
TKXFORM_set_state( $form_ref, 'Add to SCM', '');
}
}
} else  # ($validate_action eq 'focusout')
{
}

return ($is_ok, $error_text);
}




sub GBSGUIFILE_new_file($$)
{
my ($command,
$path,
) = @_;
my $nr_created = 0;



ENV_pushd( $path);

my @mnem_refs = (

[ undef, 'File_name',  '', 'ssmf-1', undef, undef, 1, \&filename_changed ],	# may not exist
[ undef, 'Add to SCM', '', 'bsm',        0, undef, 1, \&add_to_scm_changed ],
[ undef, 'Template',   '', 'ssos',      '', undef, 0 ],
[ undef, 'Edit',       '', 'bso',        0, undef, 1 ],
);

my @values = TKXFORM_dialogue( $TKX::MW, 'Create new File', \@mnem_refs, undef, undef, "Path: $path");
if (@values)
{
my ($file, $add_scm, $template, $do_edit) = @values;
my $filespec = "$path/$file";

my ($errors_ref, @environment) = FLOC_validate_filespec( $filespec);
my $extra_data = '';



if (defined $errors_ref)
{

} else
{
if ($template ne '')
{
my $template_filespec;
my $file_type = ENV_split_spec_t( $file);
foreach my $template_spec_ref (TEMPLATES_find_by_type( $file_type))
{
if ($template_spec_ref->[0] eq $template) # $nice_name,
{
$template_filespec = $template_spec_ref->[1];	# $anyfile_spec
last;
}
}
$extra_data = $template_filespec;
}
if ($add_scm)
{
GBSSCM_preset( 0);
GBSSCM_connect();
SCM_assert_co_file( $filespec);
}

if (GBSEDIT_create_file( $path, $file, 1, \@environment, $extra_data))
{
$nr_created++;
if ($do_edit)
{
GBSGUIEXEC_direct( 'New File', 'gbsedit', [ $file ]);
}
}
}
}

ENV_popd();

return $nr_created;
}




sub add_to_scm_changed($$$$)
{
my ($this_widget,
$newer_value,
$mnem,
$form_ref,  # [ $this_tl, $form_name, $mnem_refs_ref, $mnem_hash_ref, $is_modal, $ok_func];

) = @_;
my ($is_ok, $error_text) = ( 1, undef);



return ($is_ok, $error_text);
}




sub filename_changed($$$$$)
{
my ($this_widget,
$validate_action,   # key or focusout
$newer_value,
$mnem,
$form_ref,  # [ $this_tl, $form_name, $mnem_refs_ref, $mnem_hash_ref, $is_modal, $ok_func];

) = @_;
my ($is_ok, $error_text) = ( 1, undef);



if ($validate_action eq 'key')
{
my $filespec = '';
my @template_names;
my ($type) = $newer_value =~ /(\..*)/;
if (defined $type && length $type > 1)
{
my ($newer_file, $generic_file_name, $is_gbs_file, undef, $gbs_file_type) = FLOC_analyse_name( $newer_value);
if ($newer_file ne $newer_value)
{

$newer_value = $newer_file;
$type = ENV_split_spec_t( $newer_value);
}
if (!$is_gbs_file)
{
my @template_spec_refs = TEMPLATES_find_by_type( $type);

@template_names = map { $_->[0] } @template_spec_refs;
}
my $cwd = ENV_cwd();
$filespec = "$cwd/$newer_value";
}




if ($filespec ne '')
{
my ($scm, $avail) = DIRSTRUCT_file_attrib( $filespec);


my $new_state;
my $new_value;
if ($scm == 0)
{
TKXFORM_store_value( $form_ref, 'Add to SCM', 0, 'disable');
} elsif ($scm == 1)
{
TKXFORM_store_value( $form_ref, 'Add to SCM', 1, 'normal');
} else
{
TKXFORM_set_state( $form_ref, 'Add to SCM', '');
}
} else
{
TKXFORM_set_state( $form_ref, 'Add to SCM', '');
}




my $template_name = (@template_names) ? $template_names[0] : '';
my $state = (@template_names > 1) ? 'readonly' : 'disable';
TKXFORM_store_combo_values( $form_ref, Template => [ @template_names ], $template_name, $state);

} else  # ($validate_action eq 'focusout')
{
if ($newer_value ne '')
{
my $cwd = ENV_cwd();
my $filespec = "$cwd/$newer_value";
my $errors_ref = FLOC_validate_filespec( $filespec);
if (defined $errors_ref)
{
$is_ok = 0;
$error_text = join( "\n", @{$errors_ref});
}
}
}

return ($is_ok, $error_text, $newer_value);
}




sub GBSGUIFILE_delete($$$)
{
my ($command,
$path,
$filespecs_ref,
) = @_;
my $nr_deleted = 0;

my @items = map { '- ' . substr( $_, length( $path) + 1) } @{$filespecs_ref};
if (TKXMESSAGE_yesno( Delete => 'info', [ "Sure delete", @items, '?' ], 'no') eq 'yes')
{
foreach my $filespec (reverse @{$filespecs_ref})
{
my $item = substr( $filespec, length( $path) + 1);
if (-d $filespec)
{
TKXMESSAGE_ok( Delete => 'info', "Directory delete not implemented yet. ($item)");
} elsif (-e _)
{

my $state = SCM_get_states( $filespec, 0);	    # pre_validated




if ($state >= 0)
{
SCM_remove_names( $filespec);
}
ENV_unlink( $filespec, 1, 'E')
if (-e $filespec);
$nr_deleted++;
}
}
}

return $nr_deleted;
}

1;
