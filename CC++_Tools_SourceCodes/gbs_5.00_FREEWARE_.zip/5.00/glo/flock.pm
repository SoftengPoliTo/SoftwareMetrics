#=================================================
#
#   flock.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::flock;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
FLOCK_ex_wait
FLOCK_ex_nowait
FLOCK_sh_wait
FLOCK_sh_nowait
FLOCK_unlock
);
}





use glo::env;




sub FLOCK_ex_wait($);
sub FLOCK_ex_nowait($);
sub FLOCK_sh_wait($);
sub FLOCK_sh_nowait($);
sub FLOCK_unlock($;$);

sub prepend_dot($);








use constant LOCK_SH => 1;  # Shared lock (for reading)
use constant LOCK_EX => 2;  #  Exclusive lock (for writing)
use constant LOCK_NB => 4;  #  Non-blocking request (don't stall)
use constant LOCK_UN => 8;  #  Free the lock (careful!)





my %LOCKS;





sub FLOCK_ex_wait($)
{
my ($filespec) = @_;
my $fh;

$filespec = prepend_dot( $filespec);

open( $fh, '>>', $filespec) || ENV_sig( F => "Cannot open/append '$filespec'", "- $!");
flock( $fh, LOCK_EX) || ENV_sig( W => "Cannot flock/2 (EX) '$filespec'", "- $!");
$LOCKS{$fh} = $filespec;

return $fh;
}




sub FLOCK_ex_nowait($)
{
my ($filespec) = @_;
my $fh_or_undef;			# undef if the lock did not succeed

$filespec = prepend_dot( $filespec);

open( my $fh, '>>', $filespec) || ENV_sig( F => "Cannot open/append '$filespec'", "- $!");
if (flock( $fh, LOCK_EX | LOCK_NB))
{
$LOCKS{$fh} = $filespec;
$fh_or_undef = $fh;
} else
{
$fh_or_undef = undef;
close( $fh) || ENV_sig( F => "Cannot close '$filespec'", "- $!");
}

return $fh_or_undef;
}




sub FLOCK_sh_wait($)
{
my ($filespec) = @_;
my $fh;

$filespec = prepend_dot( $filespec);

open( $fh, '>>', $filespec) || ENV_sig( F => "Cannot open/append '$filespec'", "- $!");
flock( $fh, LOCK_SH) || ENV_sig( W => "Cannot flock/1 (SH) '$filespec'", "- $!");
$LOCKS{$fh} = $filespec;

return $fh;
}




sub FLOCK_sh_nowait($)
{
my ($filespec) = @_;
my $fh_or_undef;			# undef if the lock did not succeed

$filespec = prepend_dot( $filespec);

open( my $fh, '>>', $filespec) || ENV_sig( F => "Cannot open/append '$filespec'", "- $!");
if (flock( $fh, LOCK_SH | LOCK_NB))
{
$LOCKS{$fh} = $filespec;
$fh_or_undef = $fh;
} else
{
$fh_or_undef = undef;
close( $fh) || ENV_sig( F => "Cannot close '$filespec'", "- $!");
}

return $fh_or_undef;
}




sub FLOCK_unlock($;$)
{
my ($fh,
$must_delete_lockfile, # bool. optional. default = 0
) = @_;

my $filespec = $LOCKS{$fh};

flock( $fh, LOCK_UN) || ENV_sig( W => "Cannot flock/8 (UN) '$filespec'", "- $!");
close( $fh) || ENV_sig( F => "Cannot close '$filespec'", "- $!");
delete( $LOCKS{$fh});
unlink $filespec
if (defined $must_delete_lockfile && $must_delete_lockfile == 1);
}





sub prepend_dot($)
{
my ($filespec) = @_;

my ($path, $name, $type) = ENV_split_spec_pnt( $filespec);
$filespec = "$path/.$name.lck"
if ($type eq '.lck' && substr( $name, 0, 1) ne '.');

return $filespec;
}

1;

