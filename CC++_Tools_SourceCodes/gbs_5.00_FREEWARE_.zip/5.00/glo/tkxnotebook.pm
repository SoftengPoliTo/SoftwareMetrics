#=================================================
#
#   tkxnotebook.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::tkxnotebook;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
TKXNOTEBOOK_new
);
}




use Tkx;


use glo::tkxevent;




sub TKXNOTEBOOK_new($@);
















sub TKXNOTEBOOK_new($@)
{
my ($parent,
@tab_refs		# [ $name, $visibility_func, @tab_args ]
) = @_;
my ($nb, @tab_frame_widgets);

($nb = $parent->new_ttk__notebook()) ->
g_pack( -side => 'top', -fill => 'x');




foreach my $ref (@tab_refs)
{
my ($name, $visibility_func, @tab_args) = @{$ref};
my $tf = $nb->new_ttk__frame( -relief => 'sunken');
$nb->add( $tf, -text => $name, @tab_args);
TKXEVENT_bind_visibility( $tf, $visibility_func);
push @tab_frame_widgets, $tf;
}

return ( $nb, @tab_frame_widgets );
}

1;

