#=================================================
#
#   gbsbgsca.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSBGSCA @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::args;
use mod::gbsenv;
use mod::gbsbgsca;
use mod::gbsbgglo;




sub get_command_args();








my $BATCH_NAME = '';	# reference to be used in logging. E.g.: gbsbuild, gbsgen_post, gbsaudit, gbsaudit_post
my $COMPONENT;
my $GBSBGJOB_SCRIPT_SPEC;	# main input-file






$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);

get_command_args();
GBSBGGLO_init( $BATCH_NAME, $COMPONENT);	# sets CWD to SRC or SUSBSYS
GBSBGSCA_init( $COMPONENT);
$RC = GBSBGGLO_main( $GBSBGJOB_SCRIPT_SPEC, [ SCA => \&GBSBGSCA_do ]); # May be called multiple times

ENV_exit( $RC);




END
{
ENV_print_end_msg( 0);
}




sub get_command_args()
{
($BATCH_NAME,
$COMPONENT,
$GBSBGJOB_SCRIPT_SPEC,
) = ARGS_get( 3, 'perl gbsbgsca.pl <BATCH_NAME> <COMPONENT> <gbg_script>', undef);

}


