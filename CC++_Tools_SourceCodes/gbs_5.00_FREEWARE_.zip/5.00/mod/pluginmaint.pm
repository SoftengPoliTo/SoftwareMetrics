#=================================================
#
#   pluginmaint.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::pluginmaint;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
PLUGINMAINT_new_build
PLUGINMAINT_remove_build
PLUGINMAINT_new_audit
PLUGINMAINT_remove_audit
PLUGINMAINT_new_tool
PLUGINMAINT_remove_tool
PLUGINMAINT_dialog
PLUGINMAINT_check_switch
);
}




use glo::env;
use glo::list;
use glo::ask;
use glo::askform;
use glo::slurp;
use glo::file;
use glo::format;
use glo::scm;
use mod::gbsenvs;
use mod::gbsglo;
use mod::fspec;
use mod::fcreate;
use mod::dirstruct;
use mod::swb;
use mod::swa;
use mod::gbsscm;
use mod::plugin;
use mod::system;
use mod::plg;
use mod::switch;
use mod::gbsedit;




sub PLUGINMAINT_new_build($);
sub PLUGINMAINT_remove_build($);
sub PLUGINMAINT_new_audit($);
sub PLUGINMAINT_remove_audit($);
sub PLUGINMAINT_new_tool($);
sub PLUGINMAINT_remove_tool($);
sub PLUGINMAINT_dialog($$);
sub PLUGINMAINT_check_switch();

sub main_remove_abt($$$);
sub main_update_dialog($$$);
sub main_new_abt($$$);
sub remove_abt($$);
sub update_dialog($$);
sub update_plugin($$$);
sub new_build($$);
sub build_create_dirs($$$);
sub build_update_dirs($$$);
sub new_audit($$);
sub audit_create_dirs($$$$);
sub audit_update_dirs($$$);
sub new_tool($$);
sub tool_create_dirs($$);
sub tool_update_dirs($$$);
sub ask_new_abt($);
sub ask_abt($);
sub select_abt($$);
sub ask_new_data($$);
sub ask_action($$$$);
sub ask_plugin($$$$);
sub ask_builds($$$$);
sub ask_subsys($$$$);
sub ask_comps($$$$);
sub ask_plugin_name();
sub do_install($$$);
sub get_plugins();
sub do_plugin_file($$$);
sub copy_1_file($$$$);
sub select_selector_abts($$$);
sub add_dirs($);
sub system_add($$);
sub system_store();
sub setup_type($);
sub setup_abt($);
sub do_gbsext($);
sub join_info($$);
sub split_info($);















my %PLUGIN_SETUP = (

audit   => [ qw( audit Audit  audit.gbs  audits)	 ],
build   => [ qw( build Build  build.gbs  builds)     ],	# We want platform Builds only
tool    => [ qw( tool  Tool   tool.gbs   tools)      ],
);

my %EXCLUDE_ABT_NAMES = (

audit   => [ qw (ALL) ],
build   => [ qw (ALL makemake_stubs) ],
tool    => [ qw (ALL) ],
);




my $ABT_TYPE;		    # 'audit',     'build',     'tool'
my $ABT_TYPE_NAME;	    # 'Audit',     'Build',     'Tool'
my $ABT_FILE;		    # 'audit.gbs', 'build.gbs', 'tool.gbs'
my $ABT_TYPE_ID;	    # 'audits',    'builds',    'tools'		# also used for $ABTS_ENV_NAME

my $ABT_TYPE_NAME_S;		# 'Audits',     'Builds',     'Tools'

my $ABT_ENV_NAME;		# 'GBS_AUDIT', 'GBS_BUILD', 'GBS_TOOL'
my $ABTS_ENV_NAME;		# 'GBS_AUDITS', 'GBS_BUILDS', 'GBS_TOOLS'
my $ALL_ABTS_ENV_NAME;		# 'GBS_ALL_AUDITS', 'GBS_ALL_BUILDS', 'GBS_ALL_TOOLS'

my $ABT_NAME;			# e.g.: $GBS_BUILD
my $GBS_ABTS_PATH;		# $GBS::ROOT_PATH/sys$ABT_TYPE
my $GBS_ABT_PATH;		# $GBS::ROOT_PATH/sys$ABT_TYPE/$ABT_NAME

my $GBS_ABT_VALUE;
my @GBS_ABT_VALUES;
my @GBS_ALL_ABT_VALUES;

my $ACTION;	# P_REF P_ORG O_NEW O_REF or COPY




my %PLUGINS;

my $PLUGINS_MAX_NAME;




sub PLUGINMAINT_new_build($)
{
my ($default_build) = @_;

return new_build( 'build', $default_build);
}




sub PLUGINMAINT_remove_build($)
{
my ($default_build) = @_;

return remove_abt( 'build', $default_build);
}




sub PLUGINMAINT_new_audit($)
{
my ($default_audit) = @_;

return new_audit( 'audit', $default_audit);
}




sub PLUGINMAINT_remove_audit($)
{
my ($default_audit) = @_;

return remove_abt( 'audit', $default_audit);
}




sub PLUGINMAINT_new_tool($)
{
my ($default_tool) = @_;

return new_tool( 'tool', $default_tool);
}




sub PLUGINMAINT_remove_tool($)
{
my ($default_tool) = @_;

return remove_abt( 'tool', $default_tool);
}




sub PLUGINMAINT_dialog($$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;

GBSSCM_preset( 0);

my @menu_items = (


[ 'Build: Update',		\&main_update_dialog, 'build' ],

[ "\nAudit: Define/Install",	\&main_new_abt,       'audit' ],
[ 'Audit: Update',		\&main_update_dialog, 'audit' ],
[ 'Audit: Remove',		\&main_remove_abt,    'audit' ],
[ 'Tools: Define/Install',	\&main_new_abt,       'tool' ],
[ 'Tools: Update',		\&main_update_dialog, 'tool' ],
[ 'Tools: Remove',		\&main_remove_abt,    'tool' ],
);

ASK_menu( 'Select function to perform:', \@menu_items, $entries_ref);
}




sub main_remove_abt($$$)
{
my ($menu_entry,
$data_ref,		    # $abt_type
$entries_ref,
) = @_;

ENV_say( 0, '');
my $abt_type = $data_ref;
GBSSCM_connect();

remove_abt( $abt_type, '');	    # no default_abt
}




sub main_update_dialog($$$)
{
my ($menu_entry,
$data_ref,		    # $abt_type
$entries_ref,
) = @_;

ENV_say( 0, '');
my $abt_type = $data_ref;
GBSSCM_connect();

update_dialog( $abt_type, '');	# no default_abt
}




sub main_new_abt($$$)
{
my ($menu_entry,
$data_ref,		    # $abt_type
$entries_ref,
) = @_;

ENV_say( 0, '');
my $abt_type = $data_ref;
GBSSCM_connect();

if ($abt_type eq 'build')
{
new_build( $abt_type, '');
} elsif ($abt_type eq 'audit')
{
new_audit( $abt_type, '');
} elsif ($abt_type eq 'tool')
{
new_tool( $abt_type, '');
} else
{
ENV_sig( F => "Impossible abt_type: $abt_type");
}
}




sub remove_abt($$)
{
my ($abt_type,		# audit build tool
$default_abt,
) = @_;
my $removed_abt = '';	# '' if nothing removed

setup_type( $abt_type);
ENV_say( 1, "Remove $ABT_TYPE_NAME $default_abt");

ENV_say( 1, "Available $ABT_TYPE_NAME_S = '@GBS_ABT_VALUES'",
"Current $ABT_TYPE_NAME = '$GBS_ABT_VALUE'");

$default_abt = ''
if (!defined $default_abt);
my $abt_to_remove = ($default_abt eq '') ? ask_abt( 'remove') : select_abt( remove => $default_abt);




setup_abt( $abt_to_remove);	# Set $ABT_NAME and GBS_ABT_PATH

SYSTEM_remove_os_ref( $GBS::ROOT_PATH, '.', $ABT_TYPE_ID => $abt_to_remove);
@GBS_ABT_VALUES = grep( $abt_to_remove ne $_, @GBS_ABT_VALUES);
system_store();

ENV_say( 1, "$ABT_TYPE_NAME $abt_to_remove removed",
"Note that the $ABT_TYPE_NAME Directories/Files are NOT deleted");
ENV_say( 1, "Remaining $ABT_TYPE_NAME_S: '@GBS_ABT_VALUES'");

$removed_abt = $abt_to_remove;
setup_abt( undef);	# Clear $ABT_NAME and GBS_ABT_PATH

return $removed_abt;
}




sub update_dialog($$)
{
my ($abt_type,		# audit build tool
$default_abt,
) = @_;

setup_type( $abt_type);
ENV_say( 1, "Update $ABT_TYPE_NAME $default_abt");




my ($abt_name, $plugin_name) = ask_abt( 'update');



setup_abt( $abt_name);    # Set $ABT_NAME and GBS_ABT_PATH

my $update_dirs_func;
if ($abt_type eq 'audit')
{
$update_dirs_func = \&audit_update_dirs;
} elsif ($abt_type eq 'build')
{
$update_dirs_func = \&build_update_dirs;
} else #($abt_type eq 'tool')
{
$update_dirs_func = \&tool_update_dirs;
}

my @menu_items = (
[ 'Add/Repair Directories',
$update_dirs_func, $abt_name ],
[ "Update $ABT_TYPE_NAME $abt_name [$plugin_name]",
\&update_plugin, [ $abt_name, $plugin_name ] ],
);
ASK_menu( "Select Update for $abt_name", \@menu_items, undef);

}




sub update_plugin($$$)
{
my ($menu_entry,
$data_ref,		    # [ $abt_name, $plugin_name ]
$entries_ref) = @_;

my ($abt_name, $plugin_name) = @{$data_ref};

ENV_say( 1, "Update $ABT_TYPE_NAME $abt_name [$plugin_name]");

$plugin_name = ask_plugin_name()	    # Ask plugin_name
if (!$plugin_name);

do_plugin_file( $plugin_name, $abt_name, 'U')
if ($plugin_name);
}




sub new_build($$)
{
my ($abt_type,		# audit build tool
$default_abt,
) = @_;
my $new_build;

setup_type( $abt_type);
ENV_say( 1, "New $ABT_TYPE_NAME $default_abt");

my $default_build = $default_abt;

$new_build = ask_new_abt( $default_build);




if ($new_build ne '')
{




setup_abt( $new_build);	    # Set $ABT_NAME and GBS_ABT_PATH
my ($plugin_name,
$org_abt,
undef,		    # $builds_ref
$subsys_ref,
$components_selector,
) = ask_new_data( $new_build, 1);




ENV_say( 1, "Creating Build '$new_build'...");




build_create_dirs( $new_build, $subsys_ref, $components_selector);




do_install( $plugin_name, $org_abt, $new_build);




system_add( $new_build, $plugin_name);
SWB_set( $new_build, 0);

ENV_say( 1, "Build '$new_build' created");




$ACTION = undef;




do_gbsext( $plugin_name);
} else
{
ENV_sig( W => "No new Build selected!");
}

return $new_build;
}




sub build_create_dirs($$$)
{
my ($build,
$subsys_ref,
$components_selector,	# $selector: @components
) = @_;

my ($comps_selector, @components) = split_info($components_selector);

my @new_dirs;
push @new_dirs, "$GBS::ROOT_PATH/sysbuild/$build";
push @new_dirs, "$GBS::ROOT_PATH/sysbuild/makemake_stubs/$build";
push @new_dirs, "$GBS::ROOT_PATH/tmp/$build";

my @subsystems = @{$subsys_ref};
foreach my $subsys (@subsystems)
{
push @new_dirs, "$GBS::ROOT_PATH/dev/$subsys/build/$build";

if (GBSGLO_subsystem_is_full_gbs( $subsys))
{
my @components = select_selector_abts( $comps_selector, \@components, [ GBSGLO_components( $subsys) ]);
foreach my $component (@components)
{
push @new_dirs, "$GBS::ROOT_PATH/dev/$subsys/comp/$component/bld/$build";
}
}
}

GBSENVS_update( 1, GBS_ALL_BUILDS => [ sort( $GBS::ALL_BUILDS, $build) ]);
DIRSTRUCT_reset();
add_dirs( \@new_dirs);
}




sub build_update_dirs($$$)
{
my ($menu_entry,
$data_ref,		    # $build
$entries_ref) = @_;

my $build = $data_ref;

ENV_say( 1, "Build $build");

my (undef,			# $plugin_name,
undef,			# $org_abt
undef,			# $builds_ref
$subsys_ref,
$components_selector,
) = ask_new_data( $build, 0);

ENV_say( 1, "Updating Build '$build'...");
build_create_dirs( $build, $subsys_ref, $components_selector);
}




sub new_audit($$)
{
my ($abt_type,		# audit build tool
$default_abt,
) = @_;
my $new_audit;

setup_type( $abt_type);
ENV_say( 1, "New $ABT_TYPE_NAME $default_abt");

$new_audit = ask_new_abt( '');




if ($new_audit ne '')
{
setup_abt( $new_audit);   # Set $ABT_NAME and GBS_ABT_PATH
my ($plugin_name,
$org_abt,
$builds_ref,
$subsys_ref,
$components_selector,
) = ask_new_data( $new_audit, 1);




ENV_say( 1, "Creating Audit '$new_audit'...");




audit_create_dirs( $new_audit, $builds_ref, $subsys_ref, $components_selector);




do_install( $plugin_name, $org_abt, $new_audit);




system_add( $new_audit, $plugin_name);
SWA_set( $new_audit, 0);

ENV_say( 1, "Audit '$new_audit' created");




$ACTION = undef;




do_gbsext( $plugin_name);
} else
{
ENV_sig( W => "No new Audit selected!");
}

return $new_audit;
}




sub audit_create_dirs($$$$)
{
my ($audit,
$builds_ref,
$subsys_ref,
$components_selector,	# $selector: @components
) = @_;

my ($comps_selector, @components) = split_info($components_selector);

my @new_dirs;
push @new_dirs, "$GBS::ROOT_PATH/sysaudit/$audit";
push @new_dirs, "$GBS::ROOT_PATH/tmp/$audit";

my @builds = @{$builds_ref};
foreach my $build (@builds)
{
my @subsystems = @{$subsys_ref};
foreach my $subsys (@subsystems)
{
push @new_dirs, "$GBS::ROOT_PATH/dev/$subsys/audit/$audit";
push @new_dirs, "$GBS::ROOT_PATH/dev/$subsys/audit/$audit/$build";

if (GBSGLO_subsystem_is_full_gbs( $subsys))
{
my @components = select_selector_abts( $comps_selector, \@components, [ GBSGLO_components( $subsys) ]);
foreach my $component (@components)
{
push @new_dirs, "$GBS::ROOT_PATH/dev/$subsys/comp/$component/aud/$audit";
push @new_dirs, "$GBS::ROOT_PATH/dev/$subsys/comp/$component/aud/$audit/$build";
}
}
}
}

GBSENVS_update( 1, GBS_ALL_AUDITS => [ sort( @GBS::ALL_AUDITS, $audit) ]);
DIRSTRUCT_reset();
add_dirs( \@new_dirs);
}




sub audit_update_dirs($$$)
{
my ($menu_entry,
$data_ref,		    # $audit
$entries_ref) = @_;

my $audit = $data_ref;

ENV_say( 1, "Audit $audit");

my (undef,			    # $plugin_name
undef,			    # $org_or_abt
$builds_ref,
$subsys_ref,
$components_selector,
) = ask_new_data( $audit, 0);

ENV_say( 1, "Updating Audit '$audit'...");
audit_create_dirs( $audit, $builds_ref, $subsys_ref, $components_selector);
}




sub new_tool($$)
{
my ($abt_type,		# audit build tool
$default_abt,
) = @_;
my $new_tool;

setup_type( $abt_type);
ENV_say( 1, "New $ABT_TYPE_NAME $default_abt");

$new_tool = ask_new_abt( '');




if ($new_tool ne '')
{
setup_abt( $new_tool);   # Set $ABT_NAME and GBS_ABT_PATH
my ($plugin_name,
$org_abt,
undef,	    # $builds_ref
$subsys_ref,
undef,	    # $components_selector
) = ask_new_data( $new_tool, 1);




ENV_say( 1, "Creating Tool '$new_tool'...");




tool_create_dirs( $new_tool, $subsys_ref);




do_install( $plugin_name, $org_abt, $new_tool);




system_add( $new_tool, $plugin_name);
GBSENVS_update( 1, GBS_TOOL => $new_tool);

ENV_say( 1, "Tool '$new_tool' created");




$ACTION = undef;




do_gbsext( $plugin_name);
} else
{
ENV_sig( W => "No new Tool selected!");
}

return $new_tool;
}




sub tool_create_dirs($$)
{
my ($tool,
$subsys_ref,
) = @_;

my @new_dirs;
push @new_dirs, "$GBS::ROOT_PATH/systool/$tool";
push @new_dirs, "$GBS::ROOT_PATH/tmp/$tool";

my @subsystems = @{$subsys_ref};
foreach my $subsys (@subsystems)
{
push @new_dirs, "$GBS::ROOT_PATH/dev/$subsys/tool/$tool";
}

GBSENVS_update( 1, GBS_ALL_TOOLS => [ sort( @GBS::ALL_TOOLS, $tool) ]);
DIRSTRUCT_reset();
add_dirs( \@new_dirs);
}




sub tool_update_dirs($$$)
{
my ($menu_entry,
$data_ref,		    # $tool
$entries_ref) = @_;

my $tool = $data_ref;

ENV_say( 1, "Tool $tool");

my (undef,		# $plugin_name
undef,		# org_abt
undef,		# $builds_ref
$subsys_ref,
undef,		# $components_selector
) = ask_new_data( $tool, 0);

ENV_say( 1, "Updating Tool '$tool'...");
tool_create_dirs( $tool, $subsys_ref);
}




sub ask_abt($)
{
my ($function,	    # remove update refer copy
) = @_;
my ($abt, $plugin_name);

if (@GBS_ABT_VALUES)
{
my @menu_items = ( [ '<Quit>' ]);
foreach my $abt_name (@GBS_ABT_VALUES)
{
my $plugin_name = PLUGIN_get_abt_plugin_name( $abt_name);
push @menu_items, [ "$abt_name [$plugin_name]", $abt_name, $plugin_name ];
};
my $default_abt = ($function eq 'remove') ? '' : $GBS_ABT_VALUE;

($abt, $plugin_name) = ASK_value_from_menu( "Select $ABT_TYPE_NAME to $function",
\$default_abt, undef, [ @menu_items ]);
} else
{
ENV_say( 1, "No $ABT_TYPE_NAME_S defined!");
}

ENV_say( 1, "Selected: $abt [$plugin_name]");

return wantarray ? ($abt, $plugin_name) : $abt;
}




sub select_abt($$)
{
my ($function,	    # remove
$wanted_abt,	    # take it if it exists
) = @_;
my ($abt, $plugin_name);

if (grep $_ eq $wanted_abt, @GBS_ABT_VALUES)
{
$abt = $wanted_abt;
$plugin_name = PLUGIN_get_abt_plugin_name( $abt);
} else
{
ENV_sig( EE => "$ABT_TYPE_NAME '$wanted_abt' does not exists");
}

ENV_say( 1, "Selected: $abt [$plugin_name]");

return wantarray ? ($abt, $plugin_name) : $abt;
}




sub ask_new_abt($)
{
my ($default_abt) = @_;
my $new_abt;	    # '' if not selected

ENV_say( 1, "Create New $ABT_TYPE_NAME");

my @gbs_all_builds = SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '*', 'builds');
my @gbs_all_audits  = SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '*', 'audits');
my @gbs_all_tools   = SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '*', 'tools');

{



ENV_say( 1, "All Items:");
my @row_refs = ( [ 'All Builds', "@gbs_all_builds" ],
[ 'All Audits', "@gbs_all_audits" ],
[ 'ALL Tools',  "@gbs_all_tools"  ],
);
ENV_say( 0, FORMAT_table( 0, 2, ': ', undef, @row_refs));
}

{



if (@GBS_ABT_VALUES)
{
ENV_say( 1, "Available $ABT_TYPE_NAME_S:");
my @abts;
foreach my $abt_name (@GBS_ABT_VALUES)
{
my $plugin_name = PLUGIN_get_abt_plugin_name( $abt_name);
push @abts, "$abt_name [$plugin_name]";
};
ENV_say( 0, FORMAT_cols( 0, 2, '  |  ', 2, \@abts));
} else
{
ENV_say( 1, "No $ABT_TYPE_NAME_S defined");
}
}




my @exclude_names = ( @gbs_all_builds, @gbs_all_audits, @gbs_all_tools, @{$EXCLUDE_ABT_NAMES{$ABT_TYPE}} );
$default_abt = ''
if (grep( $default_abt eq $_, @exclude_names));
do
{
$new_abt = ASK_not_word( "Enter New $ABT_TYPE_NAME-name", $default_abt, 20, \@exclude_names);
if ($new_abt ne '')
{
my $abt_path = "$GBS_ABTS_PATH/$new_abt";
if (-d $abt_path)
{
my @files = SLURP_dir_all( $abt_path, 0);
ENV_say( 1, "  $ABT_TYPE_NAME directory '$new_abt' already exists",
"  It Contains:",
"    @files");
$new_abt = undef
if (ASK_YNQ( "  Use it ($new_abt) anyway?", 'N', 1) eq 'N');
}
}
} while (!defined $new_abt);

return $new_abt;
}




sub ask_new_data($$)
{
my ($abt_name,	    # name of build, audit or tool
$ask_new,	    # bool: 1 = ask for new, 0 = ask for update
) = @_;
my ($plugin_name, $org_abt, $builds_ref, $subsys_ref, $components_selector);

my $builds_required = ($ABT_TYPE eq 'audit') ? 1 : 0;
my $components_required = (GBSGLO_subsystems_full_gbs() > 0  && ($ABT_TYPE eq 'build' || $ABT_TYPE eq 'audit')) ? 1 : 0;




my $action_name = '';
my $plugin_info = '';
my $builds_info = '';
my $subsys_info = '';
my $comps_info = '';
my $must_ask_builds = 0;
my $must_ask_subsystems = 0;
if ($builds_required)
{
$builds_info = (@GBS::BUILDS == 0) ? 'None' : (@GBS::BUILDS == 1) ? "All: $GBS::BUILDS[0]" : '';
$must_ask_builds = 1
if ($builds_info eq '');
}
{
$subsys_info = (@GBS::ALL_SUBSYSTEMS == 0) ? 'None' : (@GBS::ALL_SUBSYSTEMS == 1) ? "All: $GBS::ALL_SUBSYSTEMS[0]" : '';
$must_ask_subsystems = 1
if ($subsys_info eq '');
}

$ACTION = '';
{
my @mnem_refs;


if ($ask_new)
{
push @mnem_refs, [ \$action_name, 'Action', 'Action',
"ssmn", '', undef, 1, [ \&ask_action ] ];
push @mnem_refs, [ \$plugin_info, 'Plugin', 'Plugin',
"ssmn", '', undef, 1, [ \&ask_plugin ] ];
}
push @mnem_refs, [ \$builds_info, 'Builds', 'Builds',
"ssmn", '', undef, $must_ask_builds, [ \&ask_builds ] ];
push @mnem_refs, [ \$subsys_info, 'SubSystems', 'SubSystems',
"ssmn", '', undef, $must_ask_subsystems, [ \&ask_subsys ] ];
push @mnem_refs, [ \$comps_info, 'Components', 'Components',
"ssmn", '', undef, $components_required, [ \&ask_comps ] ];

ASKFORM_new( "New $ABT_TYPE_NAME", 0, \@mnem_refs, undef, undef, undef);
}

($plugin_name, $org_abt) = split_info( $plugin_info);
if ($builds_required)
{
my (undef, @builds) = split_info( $builds_info);
$builds_ref = \@builds;
}
{
my (undef, @subsystems) = split_info( $subsys_info);
$subsys_ref = \@subsystems;
}


return ($plugin_name, $org_abt, $builds_ref, $subsys_ref, $comps_info);
}




sub ask_action($$$$)
{
my ($mnem_hash_ref,
$mnem,
$this_default,
$length,
) = @_;
my $action_name;

my ($mnem_value_ref, undef, $opt_name, $type_spec_ref, undef, $item_help_or_ref) = @{$mnem_hash_ref->{$mnem}};
my ($type, $occur, $manda, $constr, $constr_values_ref) = @{$type_spec_ref};

my @menu_item_refs;

push @menu_item_refs, [ '<Quit>', undef ];
push @menu_item_refs, [ "Create a Reference to a $ABT_TYPE_NAME Plugin", 'P_REF'  ];
push @menu_item_refs, [ "Create a Copy of a $ABT_TYPE_NAME Plugin",      'P_ORG'  ];
push @menu_item_refs, [ "Create a New own $ABT_TYPE_NAME",		     'O_NEW'  ];
push @menu_item_refs, [ "Create a Reference to an own $ABT_TYPE_NAME",   'O_REF'  ];
push @menu_item_refs, [ "Create a Copy of an existing $ABT_TYPE_NAME",   'COPY'   ];
map { $_->[0] =~ s/ a A/ an A/ } @menu_item_refs;	    # $display_text
my $index =
ASK_index_from_menu( "Select action for Creating new $ABT_TYPE_NAME", 1, undef, [ @menu_item_refs ]);
($action_name, $ACTION) = @{$menu_item_refs[$index]};

return $action_name;
}




sub ask_plugin($$$$)
{
my ($mnem_hash_ref,
$mnem,
$this_default,
$length,
) = @_;
my $plugin_info;

my ($mnem_value_ref, undef, $opt_name, $type_spec_ref, $default, $item_help_or_ref) = @{$mnem_hash_ref->{$mnem}};


my ($plugin_name, $org_abt);
if ($ACTION eq 'P_REF' || $ACTION eq 'P_ORG')
{
$plugin_name = ask_plugin_name();
} elsif ($ACTION eq 'O_NEW')
{
$plugin_name = $default;	    # $abt_name;
} elsif ($ACTION eq 'O_REF')
{
(undef, $plugin_name) = ask_abt( 'refer');
} elsif ($ACTION eq 'COPY')
{
($org_abt, $plugin_name) = ask_abt( 'copy');
} else
{
ENV_sig( F => "Unhandled action '$ACTION'");
}

$plugin_info = join_info( $plugin_name, $org_abt);

return $plugin_info;
}




sub ask_builds($$$$)
{
my ($mnem_hash_ref,
$mnem,
$this_default,
$length,
) = @_;
my $builds_info;

my ($mnem_value_ref, undef, $opt_name, $type_spec_ref, undef, $item_help_or_ref) = @{$mnem_hash_ref->{$mnem}};


ENV_say( 1, "  Possible Builds:",
"  @GBS::BUILDS");
my $builds_selector = ASK_value_from_menu( "  Select Builds-Selector",
0, undef, [ qw( All Only Exclude) ]);
my @selectors;
if ($builds_selector eq 'Only' || $builds_selector eq 'Exclude')
{
push @selectors, ASK_values_from_list( "$builds_selector Builds:", '', 0, [ @GBS::BUILDS ]);
}
my @builds = select_selector_abts( $builds_selector, \@selectors, [ @GBS::BUILDS ]);
$builds_info = join_info( $builds_selector, \@builds);

return $builds_info;
}




sub ask_subsys($$$$)
{
my ($mnem_hash_ref,
$mnem,
$this_default,
$length,
) = @_;
my $subsys_info;

my ($mnem_value_ref, undef, $opt_name, $type_spec_ref, undef, $item_help_or_ref) = @{$mnem_hash_ref->{$mnem}};


ENV_say( 1, "  Possible SubSystems:",
"  @GBS::ALL_SUBSYSTEMS");
my $subsystems_selector = ASK_value_from_menu( "  Select SubSystems-Selector",
0, undef, [ qw( All Only Exclude None) ]);
my @selectors;
if ($subsystems_selector eq 'Only' || $subsystems_selector eq 'Exclude')
{
push @selectors, ASK_values_from_list( "  $subsystems_selector SubSystems:", '', 0, [ @GBS::ALL_SUBSYSTEMS ]);
}
my @subsystems = select_selector_abts( $subsystems_selector, \@selectors, [ @GBS::ALL_SUBSYSTEMS ]);
$subsys_info = join_info( $subsystems_selector, \@subsystems);

return $subsys_info;
}




sub ask_comps($$$$)
{
my ($mnem_hash_ref,
$mnem,
$this_default,
$length,
) = @_;
my $comps_info;

my ($mnem_value_ref, undef, $opt_name, $type_spec_ref, undef, $item_help_or_ref) = @{$mnem_hash_ref->{$mnem}};


my $subsys_info = ${$mnem_hash_ref->{SubSystems}->[0]};	# $mnem_value_ref
my (undef, @subsystems) = split_info( $subsys_info);
my $components_selector;
my @components;
if (@subsystems == 0)
{
$components_selector = 'None';
} elsif (@subsystems == 1)
{
my @all_components = GBSGLO_components( $subsystems[0]);
if (@all_components == 0)
{
$components_selector = 'None';
} elsif (@all_components == 1)
{
$components_selector = 'All';
@components = ($all_components[0]);
} else
{
ENV_say( 1, "  Possible Components:",
"  @all_components");
$components_selector = ASK_value_from_menu( "  Select Components-Selector",
0, undef, [ qw( All Only Exclude None) ]);
my @selectors;
if ($components_selector eq 'Only' || $components_selector eq 'Exclude')
{
push @selectors, ASK_values_from_list( "  $components_selector Components:", '', 0, \@all_components);
}
@components = select_selector_abts( $components_selector, \@selectors, \@all_components);
}
} else
{
ENV_say( 1, "  Multiple SubSystems are involved: use wildcards for Components Selection");
$components_selector = ASK_value_from_menu( "  Select Components-Selector",
0, undef, [ qw( All Only Exclude None) ]);
if ($components_selector eq 'Only' || $components_selector eq 'Exclude')
{



@components = ASK_wild_words( "  $components_selector (wild) Components:", '', -1);
}
}
$comps_info = join_info( $components_selector, \@components);

return $comps_info;
}




sub ask_plugin_name()
{
my $plugin_name;

get_plugins();




my @menu_refs;
push @menu_refs, ([ '<Quit>' ]);		# Menu entry 0 : <Quit>

foreach my $ref (@{$PLUGINS{$ABT_TYPE}})
{
my ($name, $description) = @{$ref};
my $display_text = sprintf( "%-*s: %s", $PLUGINS_MAX_NAME, $name, $description);
push @menu_refs, [ $display_text, $name ];
}




my $default_abt = ($ABT_TYPE eq 'build') ? $GBS::BUILD_PLUGIN : ($ABT_TYPE eq 'audit') ? $GBS::AUDIT_PLUGIN : $GBS::TOOL_PLUGIN;
my $index = ASK_index_from_menu( "  Select $ABT_TYPE_NAME plugin",
\$default_abt, undef, [ @menu_refs ]);
$plugin_name = $menu_refs[$index]->[1];	# $name
ENV_say( 1, "Selected: $plugin_name");

return $plugin_name;
}




sub do_install($$$)
{
my ($plugin_name,
$org_abt,	    # Only needed for ACTION == "COPY'
$abt_name,
) = @_;

my $plugin_filespec = FSPEC_abt_file( $ABT_FILE, $GBS::ROOT_PATH, $abt_name);


if ($ACTION eq 'P_REF')
{
if (-e $plugin_filespec)
{
SCM_assert_co_file( $plugin_filespec);
ENV_unlink( $plugin_filespec);
}
FCREATE_abt_ref_file( $ABT_FILE, $GBS::ROOT_PATH, $abt_name, $plugin_name);
do_plugin_file( $plugin_name, $abt_name, 'I');
} elsif ($ACTION eq 'P_ORG')
{
do_plugin_file( $plugin_name, $abt_name, 'U');
} elsif ($ACTION eq 'O_NEW')
{
FCREATE_abt_file( $ABT_FILE, $GBS::ROOT_PATH, $abt_name, $plugin_name);
} elsif ($ACTION eq 'O_REF')
{
if (-e $plugin_filespec)
{
SCM_assert_co_file( $plugin_filespec);
ENV_unlink( $plugin_filespec);
}
FCREATE_abt_ref_file( $ABT_FILE, $GBS::ROOT_PATH, $abt_name, $plugin_name);
} elsif ($ACTION eq 'COPY')
{
my $from_plugin_abt = $org_abt;
my $from_path = "$GBS_ABTS_PATH/$from_plugin_abt";
my @files = SLURP_dir_files( $from_path, 0);
if (@files)
{
ENV_say( 1, "$ABT_TYPE_NAME $from_plugin_abt contains the following files",
"@files");
my @to_filespecs;
foreach my $file (@files)
{
my $from_spec = "$from_path/$file";
my $to_spec = "$GBS_ABT_PATH/$file";
ENV_say( 0, " copy $from_spec -> $GBS_ABT_PATH/");
SCM_assert_co_file( $to_spec);			# TBS add ABT-translate
FILE_copy_translate( $from_spec, $to_spec);
push @to_filespecs, $to_spec;
}
ENV_say( 1, scalar @to_filespecs . " copied");
SCM_add_txt_files( \@to_filespecs, 0, 1)
} else
{
ENV_say( 1, "No files in $ABT_TYPE_NAME $from_plugin_abt");
}
} else
{
ENV_sig( F => "Impossible $ACTION");
}




if (! -e $plugin_filespec)
{



FCREATE_abt_file( $ABT_FILE, $GBS::ROOT_PATH, $abt_name, $plugin_name);
}
SCM_add_txt_files( $plugin_filespec, 0, 1);		# $prevalidated, $verbose_level
}




sub get_plugins()
{
if (! $PLUGINS{$ABT_TYPE})
{
my @plugin_refs = PLG_get_plugins( $ABT_TYPE);





$PLUGINS_MAX_NAME = 0;
foreach my $ref (@plugin_refs)
{
my $plugin_name = $ref->[0];
my $name_length = length( $plugin_name);
$PLUGINS_MAX_NAME = $name_length
if ($name_length > $PLUGINS_MAX_NAME);
}
$PLUGINS{$ABT_TYPE} = [ @plugin_refs ];
}
}




sub do_plugin_file($$$)
{
my ($plugin_name,
$abt_name,
$install_or_update, # 'I' or 'U'
) = @_;

my $to_dir = "$GBS_ABTS_PATH/$abt_name";
my $plugins_root_path = "$GBS::SCRIPTS_PATH/plugins/$ABT_TYPE";
my $from_path = "$plugins_root_path/$plugin_name";

my @data_refs = PLG_get_plugin_data( $plugin_name, $ABT_TYPE, $install_or_update);




if (@data_refs)
{



ENV_say( 1, "Plugin Data overview:");
foreach my $ref (@data_refs)
{
my ( $func, $command, $ask_default, @args ) = @{$ref};
if ($command eq 'C')
{



ENV_say( 0, "  Copy @args");
} elsif ($command eq 'R')
{



ENV_say( 0, "  Run @args");
} elsif ($command eq 'D')
{



ENV_say( 0, "  Create Dir(s) @args");
} else # ($command eq 'E')
{



ENV_say( 0, "  Echo @args");
}
}




ENV_say( 1, "Executing...");
foreach my $ref (@data_refs)
{
my ( $func, $command, $ask_default, @args ) = @{$ref};
if ($command eq 'C')
{



my ($from_file, $to_file) = @args;	    # names may contain dirs!
my @file_refs;

if (ENV_is_wildcard( $from_file))
{
my @from_files = ENV_glob( "$from_path/$from_file");
foreach my $from_file (@from_files)
{
$from_file =~ s!^$from_path/!!;
my $file = ENV_split_spec_f( $from_file);
push @file_refs, [ $file, $from_file, $file ];
}
} else
{
my $file = ENV_split_spec_f( $from_file);
$to_file = $file
if (! $to_file);
push @file_refs, [ $file, $from_file, $to_file ];
}
my @from_file_names = map { $_->[1] } @file_refs;
ENV_say( 1, "Files to copy:");
ENV_say( 0, "    @from_file_names");

my $ans = ($ask_default eq '+') ? 'A' : $ask_default;
foreach my $ref (@file_refs)
{
my ($file, $from_file, $to_file) = @{$ref};
my $from_filespec = "$from_path/$from_file";
my $to_filespec   = "$to_dir/$to_file";

$ans = ASK_YNAE( "Copy file: $from_file?", $ask_default)
if ($ans ne 'A');
if ($ans eq 'Y' || $ans eq 'A')
{
copy_1_file( $file, $from_filespec, $to_filespec, $plugin_name);
} elsif ($ans eq 'E')
{
last;
}
}
} elsif ($command eq 'R')
{



my ($script, $script_spec) = @args;

my $ans = 'Y';
if ($ask_default ne '+')
{
$ans = ASK_YN( 'Run Installer?', $ask_default);
}
if ($ans eq 'Y')
{
ENV_say( 1, "Executing $script...");
my $command_items_ref = [ $script_spec, $func, $from_path, $to_dir ];
my $rc = ENV_system( $command_items_ref, undef);
ENV_sig( E => "Install failed")
if ($rc != 0);
}
} elsif ($command eq 'D')
{



my $dir = $args[0];
my $dir_spec = "$to_dir/$dir";
if (!-d $dir_spec)
{
ENV_say( 1, "Creating Directory '$dir'");
SCM_add_dirs( [ $dir_spec ], \&DIRSTRUCT_get_ignore_spec, 0, 1);	    # $pre_validated, $verbose
}
} else # ($command eq 'E')
{



ENV_say( 1, "$args[0]");
}
}
} else
{

}
}




sub copy_1_file($$$$)
{
my ($file_name,
$in_filespec,
$to_filespec,
$plugin_name,
) = @_;

my $ans = 'Y';
if (-e $to_filespec)
{
$ans = ASK_YN( "File already exists. Replace?", "N");
}
if ($ans eq 'Y')
{
SCM_assert_co_file( $to_filespec);

my $file_name_uc = uc $file_name;
$file_name_uc =~ s/\..*$//;		    # remove .type
my $type_name_uc = uc $ABT_TYPE_NAME;    # BUILD AUDIT TOOL
FILE_copy_template( $in_filespec, $to_filespec,
( SCRIPT => $file_name_uc, $type_name_uc => $plugin_name ));

ENV_chmod ('ug+x', $to_filespec)
if (ENV_is_shell_file( $to_filespec));
SCM_add_txt_files( $to_filespec, 1, 1);	# $prevalidated, $verbose_level
ENV_say( 1, "File copied");
}
}




sub select_selector_abts($$$)
{
my ($selector,			# 'All', 'Only', "Exclude', 'None'
$selections_ref,		# Do not modify! ??
$all_abts_ref,
) = @_;
my @selection;

my @selection_list = @{$selections_ref};    # copy. We do not want to modify
if ($selector eq 'All')
{
@selection =  @{$all_abts_ref};
} elsif ($selector eq 'Only')
{
@selection = ENV_wildcards( \@selection_list, $all_abts_ref, undef);
} elsif ($selector eq 'Exclude')
{
@selection = ENV_not_wildcards( \@selection_list, $all_abts_ref);
} elsif ($selector eq 'None')
{
@selection = ();
} else
{
ENV_sig( F => "Impossible selector: $selector");
}


return @selection;
}




sub add_dirs($)
{
my ($dirs_ref) = @_;

my @dirs = LIST_unique( $dirs_ref);		# remove duplicates
my @spec_refs = SCM_get_states( \@dirs, 0);	# -2=no such file, -1=not in SCM, 0=checked-in, 1=checked-out

my @new_dirs;
foreach my $ref (@spec_refs)
{
my ($spec, $state) = @{$ref};
push @new_dirs, $spec
if ($state < 0);
}
ENV_debug( 1, "New:", @new_dirs);
SCM_add_dirs( \@new_dirs, \&DIRSTRUCT_get_ignore_spec, 0, 1);	    # $pre_validated, $verbose_level
}




sub system_add($$)
{
my ($new_abt,
$plugin,
) = @_;




if (grep( $_ eq $new_abt, @GBS_ABT_VALUES))
{
ENV_sig( E => "SYSTEM Add $ABT_TYPE_ID $new_abt: not executed. Already present");
} else
{
SYSTEM_add_os_ref( $GBS::ROOT_PATH, '.', $ABT_TYPE_ID => [ $new_abt, $plugin ]);
@GBS_ABT_VALUES = sort( ( @GBS_ABT_VALUES, $new_abt ));
system_store();
}
}




sub system_store()
{




SYSTEM_write();    # Includes backup and SCM_checkout
PLUGIN_reset();

@GBS_ALL_ABT_VALUES = SYSTEM_get_os_ref_names( $GBS::ROOT_PATH, '*', $ABT_TYPE_ID);




GBSENVS_update( 1, $ABTS_ENV_NAME => \@GBS_ABT_VALUES);
GBSENVS_update( 1, $ALL_ABTS_ENV_NAME => \@GBS_ALL_ABT_VALUES);
}




sub setup_type($)
{
my ($abt_type) = @_;

if (defined $abt_type)
{
($ABT_TYPE, $ABT_TYPE_NAME, $ABT_FILE, $ABT_TYPE_ID) = @{$PLUGIN_SETUP{$abt_type}};

$ABT_TYPE_NAME_S = "${ABT_TYPE_NAME}s";

$GBS_ABTS_PATH		    = "$GBS::ROOT_PATH/sys$ABT_TYPE";	# e.g.: sysaudit sysbuild systool

my $abt_type_id_uc = uc $ABT_TYPE_ID;
$ABTS_ENV_NAME	    = "GBS_$abt_type_id_uc";		# 'GBS_AUDITS',     'GBS_BUILDS',     'GBS_TOOLS'
$ALL_ABTS_ENV_NAME  = "GBS_ALL_$abt_type_id_uc";	# 'GBS_ALL_AUDITS', 'GBS_ALL_BUILDS', 'GBS_ALL_TOOLS'
$ABT_ENV_NAME	    = substr( $ABTS_ENV_NAME, 0, -1);	# 'GBS_AUDIT',      'GBS_BUILD',      'GBS_TOOL'

$GBS_ABT_VALUE = ENV_getenv( $ABT_ENV_NAME);		    # E.g.: $GBS::BUILD
@GBS_ABT_VALUES = ENV_getenv( $ABTS_ENV_NAME);		    # E.g.: @GBS::BUILDS
@GBS_ALL_ABT_VALUES = ENV_getenv( $ALL_ABTS_ENV_NAME);	    # E.g.: @GBA::ALL_BUILDS
} else
{
($ABT_TYPE, $ABT_TYPE_NAME, $ABT_FILE, $ABT_TYPE_ID) = ();

$ABT_TYPE_NAME_S = undef;

$GBS_ABTS_PATH = undef;

$ABTS_ENV_NAME	= undef;
$ALL_ABTS_ENV_NAME = undef;
$ABT_ENV_NAME = undef;

$GBS_ABT_VALUE = undef;
@GBS_ABT_VALUES = ();
@GBS_ALL_ABT_VALUES = ();
}

setup_abt( undef);	    # Clear $ABT_NAME and GBS_ABT_PATH
}




sub setup_abt($)
{
my ($abt_name) = @_;

if (defined $abt_name)
{
$ABT_NAME = $abt_name;
$GBS_ABT_PATH = "$GBS_ABTS_PATH/$abt_name";
} else
{
$ABT_NAME = undef;
$GBS_ABT_PATH = undef;
}
}




sub do_gbsext($)
{
my ($plugin_name,
) = @_;




my $plugin_uc = uc $plugin_name;
my $path_env_name = "GBSEXT_${plugin_uc}_PATH";
my $rel_env_name = "GBSEXT_${plugin_uc}_REL";
if (ENV_getenv( $path_env_name) eq '' || ENV_getenv( $rel_env_name) eq '')
{
ENV_sig( W => "You must 'gbsedit switch.gbs' to define",
"- $path_env_name and",
"- $rel_env_name");
if ( ASK_YN( "Do you want to edit switch.gbs now? (in a separate window)", 'Y') eq 'Y')
{
my $switch_filespec = FSPEC_switch( 'switch.gbs', $GBS::ROOT_PATH);
GBSSCM_preset( 0);
GBSSCM_connect();
SCM_assert_co_file( $switch_filespec);
GBSEDIT_edit_file( $switch_filespec, '', 1, \&PLUGINMAINT_check_switch);	# file_is_in_current_gbs_path
}
}




my $gbs_silo_cache_path = "$GBS::ROOT_PATH/silo/.gbs/cache";
my $gbs_silo_plugin_path = "$gbs_silo_cache_path/$plugin_name";
if (! -e $gbs_silo_plugin_path)
{
ENV_say( 1, "Creating Silo Plugin dir...");
SCM_add_dirs( $gbs_silo_plugin_path, \&DIRSTRUCT_get_ignore_spec, 0, 1);	    # $pre_validated, $verbose_level
}
}




sub join_info($$)
{
my ($name,
$values_or_ref,
) = @_;


my @values = ENV_deref( $values_or_ref);
if (@values)
{
return "$name: @values";
} else
{
return $name;
}
}




sub split_info($)
{
my ($info_text,		    # E.g.: Only: comp1 comp2
) = @_;
my ($name, @values);

($name, my $rest) = split( ':', $info_text);
@values = split( ' ', $rest)
if (defined $rest);


return ($name, @values);
}





sub PLUGINMAINT_check_switch()
{
my $file_is_ok = 0;

my $rc = SWITCH_exit();
if ($rc == 0)
{
$rc = SWITCH_entry();
if ($rc == 0)
{
$rc = PLUGIN_check_plugins( 1);  #	Returns error_count. $must_reset
} else
{
ENV_sig( W => "'SWITCH_entry' failed");
}
} else
{
ENV_sig( W => "'SWITCH_exit' failed");
}
$file_is_ok = ($rc == 0) ? 1 : 0;

return $file_is_ok;

}

1;
