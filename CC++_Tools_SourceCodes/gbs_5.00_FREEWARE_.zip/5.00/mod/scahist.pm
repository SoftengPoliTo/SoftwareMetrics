#=================================================
#
#   scahist.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::scahist;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SCAHIST_select_subsys
SCAHIST_get_file
SCAHIST_commit
);
}




use glo::env;
use glo::slurp;
use glo::scm;
use glo::time;
use mod::gbsglo;
use mod::dirstruct;




sub SCAHIST_select_subsys($);
sub SCAHIST_get_file($$$);
sub SCAHIST_commit($$);




my $CUR_SUBSYS = '';
my $CUR_HIST_DATE = 'None';
my %HISTORIES;





sub SCAHIST_select_subsys($)
{
my ($subsys,
) = @_;


if ($subsys ne $CUR_SUBSYS)
{
%HISTORIES = ();
$CUR_SUBSYS = $subsys;
my $gbs_audit_path = "$GBS::ROOT_PATH/dev/$CUR_SUBSYS/audit";
my $this_audit_path = "$gbs_audit_path/$GBS::AUDIT";
my @hist_files = grep /^hist_${GBS::BUILD}_\d+\.gbs$/, SLURP_dir_files( $this_audit_path, 0);

if (@hist_files)
{




my $cur_hist_file = $hist_files[-1];	# files are sorted
my ($hist_date) = $cur_hist_file =~ /hist_.*?_(\d{8})\.gbs/;
$CUR_HIST_DATE = TIME_unpack( $hist_date);




ENV_say( 1, "Reading SubSys History $CUR_SUBSYS: $cur_hist_file...");
my @in_lines = SLURP_file( "$this_audit_path/$cur_hist_file");
my $comp_path = "$GBS::ROOT_PATH/dev/$CUR_SUBSYS/comp";
while (@in_lines)
{
my $line = shift @in_lines;
ENV_sig( F => "Syntax error in history-file format ($cur_hist_file)",
"Expected line to start with ::",
$line)
if (substr( $line, 0, 2) ne '::');
my $component = substr( $line, 2);
my @comp_lines;
while (@in_lines && $in_lines[0] ne '::EOC')
{
push @comp_lines, shift @in_lines;
}
shift @in_lines;    # ::EOC


if (-d "$comp_path/$component")
{
while (@comp_lines)
{
my $line = shift @comp_lines;
my $file = substr( $line, 1);

my @out_lines;
while (@comp_lines && $comp_lines[0] ne ':EOF')
{
push @out_lines, shift @comp_lines;
}
shift @comp_lines;  # :EOF
$HISTORIES{$component}->{$file} = [ @out_lines ];
}
} else
{
ENV_say( 1, "History: Component '$component' does not exist anymore - skipped");
}
}
} else
{
$CUR_HIST_DATE = 'None';
ENV_say( 1, "No $GBS::AUDIT/$GBS::BUILD History for SubSystem $CUR_SUBSYS");
}
}

return $CUR_HIST_DATE;
}




sub SCAHIST_get_file($$$)
{
my ($subsys,
$component,
$file,
) = @_;




ENV_sig( F => "Subsys $subsys not selected ($CUR_SUBSYS)")
if ($subsys ne $CUR_SUBSYS);

my $lines_ref = $HISTORIES{$component}->{$file};
if (defined $lines_ref)
{
return @{$lines_ref};
} else
{
return ();
}
}




sub SCAHIST_commit($$)
{
my ($audits_ref,
$builds_ref,
) = @_;

my $date = TIME_date2num_packed();

ENV_say( 1, "Hist-id = $date");





foreach my $subsys (GBSGLO_subsystems_full_gbs())
{
my $subsys_path = "$GBS::ROOT_PATH/dev/$subsys";
ENV_say( 1, "$subsys...");
foreach my $audit (@{$audits_ref})
{

foreach my $build (@{$builds_ref})
{





my $count = 0;
my @lines;
foreach my $component (GBSGLO_components_for_audit( $subsys, $audit, $build))
{
my $component_path = "$subsys_path/comp/$component";
my @audit_hist_files = ENV_glob( "$component_path/aud/$audit/$build/*.gmet");

if (@audit_hist_files)
{
push @lines, "::$component";
foreach my $audit_hist_file (@audit_hist_files)
{
my $file_name = ENV_split_spec_f( $audit_hist_file);

push @lines, ":$file_name";
push @lines, SLURP_file_raw( $audit_hist_file);
push @lines, ":EOF";
$count++;
}
push @lines, "::EOC";
}
}




if (@lines)
{
ENV_say( 1, "Consolidating: $subsys / $audit / $build ($count files)...");
my $hist_dir = "$subsys_path/audit/$audit";
my $hist_file_name = "hist_${build}_$date.gbs";
my $hist_file = "$hist_dir/$hist_file_name";

SCM_add_dirs( $hist_dir, \&DIRSTRUCT_get_ignore_spec, 1, 0)	    # $pre_validated, $verbose
if (SCM_get_states( $hist_dir, 0) == -1); # not SCM

SCM_store_file( $hist_file, \@lines );
} else
{
ENV_say( 1, "No $audit files for $subsys / $audit / $build");
}

}
}
}
}

1;

