#=================================================
#
#   tkxfont.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::tkxfont;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
TKXFONT_create
TKXFONT_configure
TKXFONT_measure
TKXFONT_metrics
TKXFONT_actual
TKXFONT_delete
TKXFORM_families
TKXFORM_names
);
}




use Tkx;





sub TKXFONT_create($@);
sub TKXFONT_configure($@);
sub TKXFONT_measure($$;$);
sub TKXFONT_metrics($;$$);
sub TKXFONT_actual($;$$$);
sub TKXFONT_delete($@);
sub TKXFORM_families(;$);
sub TKXFORM_names();
















sub TKXFONT_create($@)
{
my ($fontname,	    # may be undef
@option_value_list  # family, size, weight [normal,bold], slant [roman,italic], underline, overstrike
) = @_;


return Tkx::font_create( $fontname => @option_value_list);
}






sub TKXFONT_configure($@)
{
my ($fontname,
@option_or_option_value_list,	# optional: family, size, weight [normal,bold], slant [roman,italic],

) = @_;
my $attributes;


$attributes = Tkx::font_configure( $fontname, @option_or_option_value_list);

if (@option_or_option_value_list == 0)
{
return (wantarray) ? Tkx::SplitList( $attributes) : $attributes;
} elsif (@option_or_option_value_list == 1)
{
return $attributes;	# only 1
} else
{
return;
}
}





sub TKXFONT_measure($$;$)
{
my ($font,	    # fontname, systemfont, family ?size? ?style? ?style ...?, X-font names (XLFD), option value ?option value ...?
$text,
$window,    # Optional. Default is Main-Window
) = @_;


my @args = (defined $window) ? (-displayof => $window) : ();

return Tkx::font_measure( $font, @args, $text, @args);
}





sub TKXFONT_metrics($;$$)
{
my ($font,	    # fontname, systemfont, family ?size? ?style? ?style ...?, X-font names (XLFD), option value ?option value ...?
$option,    # Optional. -ascent -descent -linespace -fixed
$window,    # Optional. Default is Main-Window
) = @_;
my $metrics;

my @args;
push @args, -displayof => $window
if (defined $window);
push @args, $option
if (defined $option);

$metrics = Tkx::font_metrics( $font, @args);

return (wantarray) ? Tkx::SplitList( $metrics) : $metrics;
}





sub TKXFONT_actual($;$$$)
{
my ($font,	    # fontname, systemfont, family ?size? ?style? ?style ...?, X-font names (XLFD), option value ?option value ...?
$window,    # Optional. Default is Main-Window
$option,    # Optional. family, size, weight, slant, underline, overstrike
$char,
) = @_;
my $attributes;


my @args;
push @args, -displayof => $window
if (defined $window);
push @args, '--' => $char
if (defined $char);
$attributes = Tkx::font_actual( $font, @args);


return (wantarray) ? Tkx::SplitList( $attributes) : $attributes;
}





sub TKXFONT_delete($@)
{
my @font_names = @_;

Tkx::font_delete( @font_names);
}





sub TKXFORM_families(;$)
{
my ($window,
) = @_;	    # Optional. Dfault is Main_Window

my @args = (defined $window) ? (-displayof => $window) : ();

return Tkx::font_families( @args);
}





sub TKXFORM_names()
{
return Tkx::font_names();
}

1;

