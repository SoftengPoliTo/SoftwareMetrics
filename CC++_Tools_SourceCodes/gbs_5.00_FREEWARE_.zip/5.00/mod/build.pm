#=================================================
#
#   build.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::build;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
BUILD_get_option_names
BUILD_validate_option
BUILD_is_glkb_type
BUILD_get_type_verb
BUILD_read
BUILD_set_bld_envs
BUILD_option_items
BUILD_get_options
BUILD_is_src_type
BUILD_get_section_items
BUILD_get_src_items
BUILD_get_src_subitems
BUILD_get_src_types
BUILD_get_inc_types
BUILD_get_bld_types
BUILD_get_unixlib_glb_types
BUILD_get_primary_bld_type
BUILD_get_rule_gen_order
BUILD_get_src_command_data_refs
BUILD_get_src_command_data_refs_exp
BUILD_get_section_commands_data_refs
BUILD_get_sysincs_file
BUILD_get_sysflags_file
BUILD_get_dependencies
BUILD_get_plugin
);
}




use glo::env;
use glo::path;
use mod::gbssfile;
use mod::gbsfilecom;
use mod::gbsfileglo;




sub BUILD_get_option_names($);
sub BUILD_validate_option($$);
sub BUILD_is_glkb_type($);
sub BUILD_get_type_verb($);
sub BUILD_read($;$);
sub BUILD_option_items($);
sub BUILD_set_bld_envs($);
sub BUILD_get_options($$);
sub BUILD_is_src_type($$);
sub BUILD_get_src_types($);
sub BUILD_get_inc_types($);
sub BUILD_get_bld_types($);
sub BUILD_get_unixlib_glb_types($$);
sub BUILD_get_primary_bld_type($$);
sub BUILD_get_section_items($$@);
sub BUILD_get_src_items($$@);
sub BUILD_get_src_subitems($$$@);
sub BUILD_get_rule_gen_order($);
sub BUILD_get_src_command_data_refs($$);
sub BUILD_get_src_command_data_refs_exp($$$$);
sub BUILD_get_section_commands_data_refs($$);
sub BUILD_get_sysincs_file($$);
sub BUILD_get_sysflags_file($$);
sub BUILD_get_dependencies($$);
sub BUILD_get_plugin($);

sub read_build($);
sub do_src_entry($$);
sub do_src_exit($$);
sub do_src_gen_type($$$$$);
sub do_src_glkb($$$$$);
sub do_src_format($$$$$);
sub do_src_inc_types($$$$$);
sub do_src_out_types($$$$$);
sub do_opt_out_types($$$$$);
sub do_src_option_values($$$$$);
sub do_src_multi_src($$$$$);








my @OPTIONS_ORDER = qw( MODE OPT DEBUGGER MAP);
my @OPTIONS_ORDER_AUDIT = qw( MODE);
my %OPTION_LIST_DEFS = (	    # first (->[0]) == default_default

MODE	=> [ qw( FINAL ASSERT DEBUG PROFILING) ],
OPT 	=> [ qw( YES SPEED SIZE DEBUG NO ) ],
DEBUGGER	=> [ qw( NO YES ) ],
MAP 	=> [ qw( YES NO ) ],
);
my %OPTIONS_DEFS;

while (my ($option, $values_ref) = each( %OPTION_LIST_DEFS))
{
map { $OPTIONS_DEFS{$option}->{$_} = 1 } @{$values_ref};
}

my %OPI;			    # OPTIONS_INIT

while (my ($option, $values_ref) = each( %OPTION_LIST_DEFS))
{
my $opt = substr( $option, 0, 3);
map { $OPI{$opt}->{$_} = [] } @{$values_ref};
}

my @GLKB_DEFAULTS = ( 'LIST', 'STANDARD');

my %ALL_GENERIC_TYPES = (

gen => 1,
asm => 1,
c	=> 0,
glb => 0,
glk => 0,
glt => 0,
);

my %GLKB_TYPES = (
glb => 1,
glk => 1,
glt => 1,
);
my @GLKB_TYPES = sort( keys( %GLKB_TYPES));

my %GEN_TYPE_VERBS = (
gen => 'Generating',
asm => 'Assembling',
c   => 'Compiling',
glb => 'Lib-Archiving',
glk => 'Linking',
glt => 'Testing',
);

my @MULTI_SRC_TYPES = qw( NO YES COMMA_LIST);
my %MULTI_SRC_TYPES = map { $_ => 1 } @MULTI_SRC_TYPES;







my %DUP_INC_TYPES;

my %DUP_BLD_TYPES;

my %DUP_GLB_BLD_TYPES;




my $CUR_GEN_TYPE;	    # gen asm c glb glk glt (that is NOT the $src_type, but the $gen_type from $src_type => TYPE)




my $CUR_BUILD = '';
my $CUR_BUILD_REF;	    #	$BUILDS{$CUR_BUILD}




my %BUILDS;


























































my %SETUP_DEFS = (
NICE_NAME	    => [ 'ss' , undef,     0, undef, 1,			 undef, undef ],
VIA_FORMAT	    => [ 'av' , ['%s',''], 0, undef, undef,		 undef, undef ],
REQUIRE	    => [ 'ps' , [],	   0, 3,     1,			 undef, undef ],
);

my %INIT_DEFS = (
SET_W	    => [ 'pa' , [],	   0, 1,     1,			 undef,	undef ],
SET_X	    => [ 'pa' , [],	   0, 1,     1,			 undef,	undef ],
SET		    => [ 'pa' , [],	   0, 2,     1,			 undef,	undef ],
SETPATH	    => [ 'pa' , [],	   0, 3,   [1],			 undef,	undef ],
BIN_DIR	    => [ 'ss' , '',	   0, 3,     1,			 undef,	undef ],
COMMAND	    => [ 'pc' , [],	   0, 4, undef,			 undef, undef ],    # $command_data_ref
);

my %DFT_DEFS = (    # DEFAULTS
MODE     	=> [ 'sss', 'FINAL', 0,   undef, undef,			 undef, $OPTIONS_DEFS{MODE} ],
OPT     	=> [ 'sss', 'YES',   0,   undef, undef,			 undef, $OPTIONS_DEFS{OPT}  ],
DEBUGGER    => [ 'sss', 'NO',    0,	  undef, undef,			 undef, $OPTIONS_DEFS{DEBUGGER}  ],
MAP     	=> [ 'sss', 'YES',   0,   undef, undef,			 undef, $OPTIONS_DEFS{MAP}  ],
);

my %SRC_DEFS = (

TYPE	    => [ 'as' , [],	   1, 0, [1,3],	     \&do_src_gen_type,	undef ],    # [ $env_type, $include_re, $comment_re ]
ORDER	    => [ 'sir', undef,	   1, 1,     1,			 undef, [ [0] ] ],
SRC_ABS_PATH    => [ 'sb' , 0,	   0, 1,     1,			 undef,	undef ],
INC_TYPES	    => [ 'ast', [],	   0, 1,   [1],	    \&do_src_inc_types,	undef ],
OUT_TYPES	    => [ 'ast', [],	   1, 1,   [1],	    \&do_src_out_types,	undef ],
OUT_FILES	    => [ 'ast', [],	   0, 1,   [1],			 undef,	undef ],
OPT_OUT_TYPES   => [ 'ast', [],	   0, 1,   [1],	    \&do_opt_out_types,	undef ],
GLKB	    => [ 'as' , [],	   0, 1, [1,2],		 \&do_src_glkb,	undef ],    # [ $glkb_spec, $lib_spec ]
INCLUDE_BLD     => [ 'sb' , 0,	   0, 1,     1,			 undef,	undef ],
INCLUDE_INC     => [ 'sb' , 1,	   0, 1,     1,			 undef,	undef ],
INC_FORMAT	    => [ 'af' , ['',''],   0, 1, undef,	       \&do_src_format,	undef ],
SYSINC_FORMAT   => [ 'af' , ['',''],   0, 1, undef,	       \&do_src_format,	undef ],
FLAG_FORMAT     => [ 'af' , ['',''],   0, 1, undef,	       \&do_src_format,	undef ],
SYSFLAG_FORMAT  => [ 'af' , ['',''],   0, 1, undef,	       \&do_src_format,	undef ],
INC_ABS_PATH    => [ 'sb' , 0,	   0, 1,     1,			 undef,	undef ],
INC_SEARCH_STYLE=> [ 'sss', 'UNIX',	   0, 1,     1,			 undef,	[ qw( UNIX STANDARD) ] ],
MODE	    => [ 'ha' , $OPI{MOD}, 0, 1,   [0],	\&do_src_option_values, undef ],
OPT 	    => [ 'ha' , $OPI{OPT}, 0, 1,   [0], \&do_src_option_values, undef ],
DEBUGGER	    => [ 'ha' , $OPI{DEB}, 0, 1,   [0], \&do_src_option_values, undef ],
MAP 	    => [ 'ha' , $OPI{MAP}, 0, 1,   [0], \&do_src_option_values, undef ],
MULTI_SRC	    => [ 'as' , [ 'NO', ''], 0, 2, [1,2],   \&do_src_multi_src, undef ],
COMMAND	    => [ 'pc' , [],	   1, 3, undef,			 undef, undef ],    # $command_data_refs
);










my %SECTION_DEFS = (
SETUP	=> [ 'N', 0, 1, 0,   \%SETUP_DEFS,  undef,	  undef ],
INIT	=> [ 'N', 0, 0, 0,   \%INIT_DEFS,   undef,	  undef ],
DEFAULTS	=> [ 'N', 0, 0, 0,   \%DFT_DEFS,    undef,	  undef ],
SRC		=> [ 'S', 0, 0, [1], \%SRC_DEFS,    \&do_src_entry, \&do_src_exit ],
);





sub BUILD_get_option_names($)
{
my ($option,	    # MODE OPT DEBUGGER MAP
) = @_;

return @{$OPTION_LIST_DEFS{$option}}
}





sub BUILD_validate_option($$)
{
my ($name,		    # GBS_
$value,
) = @_;
my ($is_ok, $new_value) = ( 1, $value);

my $option = substr( $name, 4);   # remove GBS_

if (!exists $OPTIONS_DEFS{$option}->{$value})
{
$is_ok = 0;
$new_value = "Invalid value '$value', must be one of: (@{$OPTION_LIST_DEFS{$option}})";
}

return ($is_ok, $new_value);
}





sub BUILD_is_glkb_type($)
{
my ($type,
) = @_;

return exists( $GLKB_TYPES{$type});
}





sub BUILD_get_type_verb($)
{
my ($gen_type) = @_;

return $GEN_TYPE_VERBS{$gen_type};	    # e.g. Compiling, Linking, etc
}




sub BUILD_read($;$)
{
my ($build,
$force_read,	    # Optional
) = @_;
my $struct_id;

read_build( $build)
if ($build ne $CUR_BUILD || $force_read);

$struct_id = "sysbuild/$build";

return $struct_id;
}





sub BUILD_set_bld_envs($)
{
my ($build,	# build or ''
) = @_;

if ($build eq '')
{

map { ENV_setenv( $_ => undef) } grep( /^GBS_BLD_/, keys %ENV);
map { ENV_setenv( "GBS_$_" => '') } @OPTIONS_ORDER;
} else
{
read_build( $build)
if ($build ne $CUR_BUILD);




foreach my $src_type (@{$CUR_BUILD_REF->{SRC}->{'.'}->{ORDER}})
{
my $gbs_bld_env = 'GBS_BLD_' . uc substr( $src_type, 1);
my $value = $CUR_BUILD_REF->{SRC}->{$src_type}->{OUT_TYPES}->[0]; #	primary out_type
ENV_setenv( $gbs_bld_env => $value);

}




foreach my $item (@OPTIONS_ORDER)	    # MODE, OPT, DEBUGGER, MAP
{
my $env_name = "GBS_$item";
my $value = $CUR_BUILD_REF->{DEFAULTS}->{$item};
ENV_setenv( $env_name => $value);

}
}
}





sub BUILD_option_items($)
{
my ($build,
) = @_;
my @row_refs;   # [ $gbs_option, $cur_value, $default, "@values" ]

read_build( $build)
if ($build ne $CUR_BUILD);

push @row_refs, [ qw( Option Cur-Value Default Possible-Values) ];
foreach my $option (@OPTIONS_ORDER)	    # MODE OPT DEBUGGER MAP
{
my $gbs_option = "GBS_$option";
my $cur_value = ENV_getenv( $gbs_option);
my $default = $CUR_BUILD_REF->{DEFAULTS}->{ $option};
my @values = @{$OPTION_LIST_DEFS{$option}};
push @row_refs, [ $gbs_option, $cur_value, $default, "@values" ];
}

return @row_refs;
}




sub BUILD_get_options($$)
{
my ($build,
$for_audit,
) = @_;
my @option_refs;		# [ $opt_name, $default_value_name, $env_var, $choice ]

read_build( $build)
if ($build ne $CUR_BUILD);

foreach my $opt_name (($for_audit) ? @OPTIONS_ORDER_AUDIT : @OPTIONS_ORDER)	    # MODE OPT DEBUGGER MAP
{
my $default_value_name = $CUR_BUILD_REF->{DEFAULTS}->{$opt_name};
my $env_var = ENV_getenv( "GBS_$opt_name");
my $choice = ($env_var eq '') ? $default_value_name : $env_var;
push @option_refs, [ $opt_name, $default_value_name, $env_var, $choice ];
}

return @option_refs;
}




sub BUILD_is_src_type($$)
{
my ($build,
$src_type,
) = @_;

read_build( $build)
if ($build ne $CUR_BUILD);

return exists( $CUR_BUILD_REF->{SRC}->{$src_type});
}




sub BUILD_get_src_types($)
{
my ($build,
) = @_;

read_build( $build)
if ($build ne $CUR_BUILD);

return @{$CUR_BUILD_REF->{SRC}->{'.'}->{ORDER}};
}




sub BUILD_get_inc_types($)
{
my ($build,
) = @_;

read_build( $build)
if ($build ne $CUR_BUILD);

return @{$CUR_BUILD_REF->{'.'}->{INC_TYPES}};
}




sub BUILD_get_bld_types($)
{
my ($build,

) = @_;

read_build( $build)
if ($build ne $CUR_BUILD);

return @{$CUR_BUILD_REF->{'.'}->{BLD_TYPES}};
}




sub BUILD_get_unixlib_glb_types($$)
{
my ($build,
$src_type,
) = @_;
my @unixlib_glb_types = ();

read_build( $build)
if ($build ne $CUR_BUILD);

if ($CUR_BUILD_REF->{SRC}->{$src_type}->{GLKB}->[1] eq 'UNIXLIB')
{
@unixlib_glb_types =  @{$CUR_BUILD_REF->{'.'}->{GLB_BLD_TYPES}};
}


return @unixlib_glb_types;
}





sub BUILD_get_primary_bld_type($$)
{
my ($build,
$src_type,
) = @_;
my $bld_type;

read_build( $build)
if ($build ne $CUR_BUILD);

ENV_sig( F => "Unknown src-type '$src_type' for Build '$CUR_BUILD'")
if (! exists $CUR_BUILD_REF->{SRC}->{$src_type});

$bld_type = $CUR_BUILD_REF->{SRC}->{$src_type}->{OUT_TYPES}->[0];


return $bld_type;
}




sub BUILD_get_section_items($$@)
{
my ($build,
$section,	    # INIT DEFAULTS SRC .
@items,
) = @_;
my @values = ();


read_build( $build)
if ($build ne $CUR_BUILD);

return GBSSFILE_get_section_items( $CUR_BUILD_REF, $section, @items);
}




sub BUILD_get_src_items($$@)
{
my ($build,
$src_type,
@items,
) = @_;
my @values = ();

read_build( $build)
if ($build ne $CUR_BUILD);


return GBSSFILE_get_subsection_items( $CUR_BUILD_REF, 'SRC', $src_type, @items);
}




sub BUILD_get_src_subitems($$$@)
{
my ($build,
$src_type,
$item,
@subitems,
) = @_;
my @values;


read_build( $build)
if ($build ne $CUR_BUILD);

return GBSSFILE_get_subsection_subitems( $CUR_BUILD_REF, 'SRC', $src_type, $item, @subitems);
}




sub BUILD_get_rule_gen_order($)
{
my ($build,
) = @_;
my @genorder_refs;


read_build( $build)
if ($build ne $CUR_BUILD);

if (exists $CUR_BUILD_REF->{'.'}->{GEN_ORDER})
{
@genorder_refs = @{$CUR_BUILD_REF->{'.'}->{GEN_ORDER}};
} else
{

foreach my $src_type (@{$CUR_BUILD_REF->{SRC}->{'.'}->{ORDER}})
{
my $gen_order = $CUR_BUILD_REF->{SRC}->{$src_type}->{ORDER};
push @{$genorder_refs[$gen_order]}, $src_type;
}
@genorder_refs = grep( defined, @genorder_refs);
$CUR_BUILD_REF->{'.'}->{GEN_ORDER} = [ @genorder_refs ];
}


return @genorder_refs;
}




sub BUILD_get_src_command_data_refs($$)
{
my ($build,
$src_type,
) = @_;
my $command_data_refs_ref;	# or @command_data_refs



read_build( $build)
if ($build ne $CUR_BUILD);

$command_data_refs_ref = $CUR_BUILD_REF->{SRC}->{$src_type}->{COMMAND};


return (wantarray) ? @{$command_data_refs_ref} : $command_data_refs_ref;
}




sub BUILD_get_src_command_data_refs_exp($$$$)
{
my ($build,
$src_type,
$pos_args_ref,		    # 1=$file_name, 2=$in_filespec, 3=$out_filespec, 4=$out_file_dir, 5=$out_filetype
$command_line_flags_ref,    # *
) = @_;
my @command_data_refs;



my $nr_pos_args = @{$pos_args_ref};
ENV_sig( F => "Nr pos_args ($nr_pos_args) must be 5")
if ($nr_pos_args != 5);

read_build( $build)
if ($build ne $CUR_BUILD);

my $command_data_refs_ref = BUILD_get_src_command_data_refs( $build, $src_type);
@command_data_refs = GBSFILECOM_expand_command_data_refs( $command_data_refs_ref, $pos_args_ref, $command_line_flags_ref);

return (wantarray) ? @command_data_refs : \@command_data_refs;
}




sub BUILD_get_section_commands_data_refs($$)
{
my ($build,
$section,
) = @_;
my $command_data_refs_ref;	# or @command_data_refs



read_build( $build)
if ($build ne $CUR_BUILD);

$command_data_refs_ref = $CUR_BUILD_REF->{$section}->{COMMAND};

return (wantarray) ? @{$command_data_refs_ref} : $command_data_refs_ref;
}




sub BUILD_get_sysincs_file($$)
{
my ($build,
$src_type,
) = @_;
my $filespec;

read_build( $build)
if ($build ne $CUR_BUILD);

my $type = substr( $src_type, 1);
my $file = "sysincs_$type.gbs";
$filespec = PATH_search_file( $file, $CUR_BUILD_REF->{'.'}->{SEARCH_PATH});
if ($filespec)
{
return (wantarray) ? ($filespec) : $filespec;
} else
{
return (wantarray) ? () : undef;
}
}




sub BUILD_get_sysflags_file($$)
{
my ($build,
$src_type,
) = @_;
my $filespec;

read_build( $build)
if ($build ne $CUR_BUILD);

my $type = substr( $src_type, 1);
my $file = "sysflags_$type.gbs";
$filespec = PATH_search_file( $file, $CUR_BUILD_REF->{'.'}->{SEARCH_PATH});
if ($filespec)
{
return (wantarray) ? ($filespec) : $filespec;
} else
{
return (wantarray) ? () : undef;
}
}





sub BUILD_get_dependencies($$)
{
my ($build,
$src_type,
) = @_;
my @depends;

read_build( $build)
if ($build ne $CUR_BUILD);




@depends = (@{$CUR_BUILD_REF->{'.'}->{DEPENDENCIES}}, @{$CUR_BUILD_REF->{SRC}->{$src_type}->{'.'}->{DEPENDENCIES}});


return @depends;
}




sub BUILD_get_plugin($)
{
my ($build) = @_;


read_build( $build)
if ($build ne $CUR_BUILD);

return $CUR_BUILD_REF->{'.'}->{PLUGIN_NAME};
}




sub read_build($)
{
my ($build) = @_;


$CUR_BUILD = $build;
$CUR_BUILD_REF = $BUILDS{$CUR_BUILD};
if (!defined $CUR_BUILD_REF)
{
$BUILDS{$CUR_BUILD} = {};
$CUR_BUILD_REF = $BUILDS{$CUR_BUILD};




my $build_file = "$GBS::SYSBUILD_PATH/$CUR_BUILD/build";
my @inc_path = ( "$GBS::SYSBUILD_PATH/$CUR_BUILD",
$GBS::SYSBUILD_PATH);
GBSSFILE_parse( $CUR_BUILD_REF, $build_file, \@inc_path, \%SECTION_DEFS);




$CUR_BUILD_REF->{'.'}->{INC_TYPES} = []
if (!defined $CUR_BUILD_REF->{'.'}->{INC_TYPES});
$CUR_BUILD_REF->{'.'}->{BLD_TYPES} = []
if (!defined $CUR_BUILD_REF->{'.'}->{BLD_TYPES});
$CUR_BUILD_REF->{'.'}->{GLB_BLD_TYPES} = []
if (!defined $CUR_BUILD_REF->{'.'}->{GLB_BLD_TYPES});




%DUP_INC_TYPES = ();
%DUP_BLD_TYPES = ();
%DUP_GLB_BLD_TYPES = ();


}
}




sub do_src_entry($$)
{
my ($section,	# SRC
$args_ref,	# $src_types
) = @_;






foreach my $src_type (@{$args_ref})
{
GBSFILEGLO_sig( EE => "SRC '$src_type' must start with a . (dot), followed by at least one character")
if ($src_type !~ /\../);
GBSFILEGLO_sig( EE => "SRC '.glkb' is reserved for internal use")
if ($src_type eq '.glkb');
}




$CUR_GEN_TYPE = '';



return @{$args_ref};
}




sub do_src_exit($$)
{
my ($section,	# SRC
$args_ref,	# [ @type_names ]
) = @_;


}





sub do_src_gen_type($$$$$)
{
my ($section,	# SRC
$subsection,	# e.g. .c, .cpp
$item,		# TYPE
$values_ref,	# [ $type, $include_re, $comment_re ]
$constr_arg,	# undef
) = @_;
my ($type, $include_re, $comment_re) = @{$values_ref};

$include_re = ENV_eval_empty( $include_re);
$comment_re = ENV_eval_empty( $comment_re);
$CUR_GEN_TYPE = $type;
GBSFILEGLO_sig( EE => "Unknown TYPE '$type'")
if (!exists $ALL_GENERIC_TYPES{$type});
GBSFILEGLO_sig( EE => "Cannot specify reg-exps for Type '$type'")
if ($include_re ne '' && !$ALL_GENERIC_TYPES{$type});

if ($GLKB_TYPES{$type})
{
$CUR_BUILD_REF->{SRC}->{$subsection}->{INCLUDE_INC} = 0;
$CUR_BUILD_REF->{SRC}->{$subsection}->{GLKB}        = [ @GLKB_DEFAULTS ];

}
return ( $type, $include_re, $comment_re );
}




sub do_src_glkb($$$$$)
{
my ($section,	# SRC
$subsection,	# e.g. .glk, .glb, .glt
$item,		# GLKB
$values_ref,	# ($env_type, $libtype)
$constr_arg,
) = @_;
my ($env_type, $lib_type);

GBSFILEGLO_sig( EE => "Can only specify GLKB with types '@GLKB_TYPES' ($CUR_GEN_TYPE)")
if (!$GLKB_TYPES{$CUR_GEN_TYPE});

($env_type, $lib_type) = @{$values_ref};




if ($env_type eq 'VARIABLE')
{
$env_type = 'LIST';
GBSFILEGLO_sig( I => "'VARIABLE' replaced by 'LIST'");
} else
{
GBSFILEGLO_sig( EE => "Env_Type '$env_type' must be 'LIST' or 'FILE'")
if ($env_type ne 'LIST' && $env_type ne 'FILE');
}




if (defined $lib_type)
{
GBSFILEGLO_sig( EE => "Lib_Type '$lib_type' must be 'STANDARD' (default) or 'UNIXLIB' or empty")
if ($lib_type ne 'STANDARD' && $lib_type ne 'UNIXLIB');
} else
{
$lib_type = 'STANDARD';
}

return ( $env_type, $lib_type ); # GLKB
}




sub do_src_format($$$$$)
{
my ($section,	# SRC
$subsection,	# e.g. .c .cpp .glk
$item,		# INC_FORMAT SYSINC_FORMAT FLAG_FORMAT SYSFLAG_FORMAT
$values_ref,	# ($env_type, $printf_format)
$constr_arg,
) = @_;
my ($env_type, $printf_format) = @{$values_ref};


return ( $env_type, $printf_format );
}




sub do_src_inc_types($$$$$)
{
my ($section,	# SRC
$subsection,	# e.g. .h, .hpp
$item,		# INC_TYPES
$values_ref,
$constr_arg,
) = @_;
my @values = @{$values_ref};

foreach my $type (@values)
{
if (!$DUP_INC_TYPES{$type})
{
push @{$CUR_BUILD_REF->{'.'}->{INC_TYPES}}, $type;
$DUP_INC_TYPES{$type} = 1;
}
}

return @values;
}




sub do_src_out_types($$$$$)
{
my ($section,	# SRC
$subsection,	# e.g. .c, .cpp
$item,		# OUT_TYPES
$values_ref,
$constr_arg,
) = @_;
my @values = @{$values_ref};

my $primary_type = $values[0];
GBSFILEGLO_sig( EE => "Primary Output-type ($primary_type) must start with '.'")
if (substr( $primary_type, 0, 1) ne '.');

foreach my $value (@values)
{

if (!$DUP_BLD_TYPES{$value})
{

push @{$CUR_BUILD_REF->{'.'}->{BLD_TYPES}}, $value;
$DUP_BLD_TYPES{$value} = 1;
}
if ($CUR_GEN_TYPE eq 'glb' && $value eq $primary_type)
{
if (!$DUP_GLB_BLD_TYPES{$value})
{

push @{$CUR_BUILD_REF->{'.'}->{GLB_BLD_TYPES}}, $value;
$DUP_GLB_BLD_TYPES{$value} = 1;
}
}
}

return @values;
}




sub do_opt_out_types($$$$$)
{
my ($section,	# SRC
$subsection,	# e.g. .c, .cpp
$item,		# OPT_OUT_TYPES
$values_ref,
$constr_arg,
) = @_;
my @values = @{$values_ref};

foreach my $value (@values)
{
if (!$DUP_BLD_TYPES{$value})
{
push @{$CUR_BUILD_REF->{'.'}->{BLD_TYPES}}, $value;
$DUP_BLD_TYPES{$value} = 1;
}
}

return @values;
}




sub do_src_option_values($$$$$)
{
my ($section,	# SRC
$subsection,	# e.g. .c, .cpp
$item,		# MODE, OPT, DEBUGGER, MAP
$values_ref,	# ([ $sub_key, @sub_values ], ...)
$constr_arg,
) = @_;
my @new_value_refs; # ( [ $sub_key, @sub_values ], ...)

my @value_refs = @{$values_ref};
foreach my $ref (@value_refs)
{
my ($sub_key, @sub_values) = @{$ref};

if ($sub_key eq '*')
{
map { push @new_value_refs, [ $_, @sub_values ] } @{$OPTION_LIST_DEFS{$item}};
} else
{
GBSFILEGLO_sig( EE => "Unknown $item: $sub_key")
if (!exists $OPTIONS_DEFS{$item}->{$sub_key});
push @new_value_refs, $ref;
}
}

return @new_value_refs;
}




sub do_src_multi_src($$$$$)
{
my ($section,	# SRC
$subsection,	# e.g. .c, .cpp
$item,		# MULTI_SRC
$values_ref,	# ($multi_src_type, @printf_format_values)	(NO YES COMMA_LIST)
$constr_arg,
) = @_;
my ($multi_src_type, $printf_format);

($multi_src_type, my @printf_format_values) = @{$values_ref};
$printf_format = "@printf_format_values";


GBSFILEGLO_sig( EE => "Unknown MULTI_SRC type: $multi_src_type",
"Allowed values are: (@MULTI_SRC_TYPES)")	    # NO YES COMMA_LIST
if (!exists $MULTI_SRC_TYPES{$multi_src_type});
GBSFILEGLO_sig( EE => "Cannot specify printf_format ($printf_format) with MULTI_SRC type 'No")
if ($multi_src_type eq 'NO' && $printf_format ne '');
GBSFILEGLO_sig( EE => "MULTI_SRC printf_format ($printf_format) must contain '%s'")
if ($printf_format ne '' && $printf_format !~ /%s/);

if ($multi_src_type ne 'NO')
{
my ($glkb_type) = @{$CUR_BUILD_REF->{SRC}->{$subsection}->{GLKB}};
GBSFILEGLO_sig( EE => "Cannot combine MULTI_SRC with GLKB")
if (defined $glkb_type);
}

return ( $multi_src_type, $printf_format ); # MULTI_SRC
}

1;

