#=================================================
#
#   swa.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::swa;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SWA_validate_dirs
SWA_set
);
}




use glo::env;
use mod::gbsenvs;
use mod::gbsenv;
use mod::gbsglo;
use mod::gbsrc;
use mod::plugin;




sub SWA_validate_dirs($$$$$);
sub SWA_set($$);








sub SWA_set($$)
{
my ($audit,
$must_write,
) = @_;
my $old_audit = $GBS::AUDIT;

ENV_debug( 1, "Set $GBS::ROOT_PATH ($audit)");




if ($audit eq '')
{
GBSENVS_set_audit( 1);
} else
{
GBSENVS_set_audit( 1, '',
[ AUDIT	    => $audit,
AUDIT_PLUGIN  => PLUGIN_get_abt_plugin_name( $audit),
]);
}




if ($must_write && GBSENV_mode_is_interactive())
{
GBSRC_write_root( audit => $audit);
GBSRC_write_subsys( $GBS::SUBSYS, audit => $audit)
if ($GBS::SUBSYS ne '');
}

return $old_audit;
}




sub SWA_validate_dirs($$$$$)
{
my ($root_path,
$subsys,
$component,
$build,
$audit,
) = @_;
my $new_audit = $audit;


if ($subsys ne '')
{



my $audit_path = "$root_path/dev/$subsys/audit";
if (-d "$audit_path/$audit")
{
if (-d "$audit_path/$audit/$build")
{



if ( $component ne '' && GBSGLO_subsystem_is_full_gbs( $subsys, $root_path))
{
my $aud_path = "$root_path/dev/$subsys/comp/$component/aud";
if (-d "$aud_path/$audit")
{
if (!-d "$aud_path/$audit/$build")
{
ENV_sig( W => "Component '$component' does not audit for Audit '$audit' and Build ($build)");
$new_audit = '';
}
} else
{
ENV_sig( W => "Component '$component' does not audit for Audit '$audit'");
$new_audit = '';
}
}
} else
{
ENV_sig( W => "SubSystem '$subsys' does not audit for Audit '$audit' and Build ($build)");
$new_audit = '';
}
} else
{
ENV_sig( W => "SubSystem '$subsys' does not audit for Audit '$audit'");
$new_audit = '';
}
}

return $new_audit;
}

1;



