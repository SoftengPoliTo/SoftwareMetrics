#=================================================
#
#   args.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::args;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
ARGS_get
ARGS_error_exit
ARGS_fatal
);
}




use glo::env;
use glo::check;




sub ARGS_get($$$;$);
sub ARGS_error_exit(@);
sub ARGS_fatal(@);

sub unix_glob(@);
sub print_usage();




my $USAGE;




sub ARGS_get($$$;$)
{
my ($limits,	# undef = any; value = exact, ref = [min,max]
$usage,		#
$help_or_ref,	#
$must_decode,	# Optonal. convert %20 to ' '. Default = 1;
) = @_;
my @argv;

$must_decode = 1
if (!defined $must_decode);
$USAGE = $usage;




if (@ARGV == 1)
{
if ($ARGV[0] eq '--h')
{
print_usage();
exit(0);
} elsif ($ARGV[0] eq '--help')
{
print_usage();
if (defined $help_or_ref)
{
ENV_say( 0, $help_or_ref);
} else
{
ENV_say( 0, '*No additional help*');
}
exit(0);
}
}




if (defined $limits)
{
my $nr_args = @ARGV;
my $error_text = CHECK_int_range( 'nr ARGuments', $nr_args, [ $limits ]);
if (defined $error_text)
{
ARGS_error_exit( $error_text);
}
}

if ($must_decode)
{



@argv = ENV_decode( @ARGV);
if (ENV_is_win32())
{
foreach my $arg (@argv)
{
$arg =~ s/\$_/ /g;
}
@argv = unix_glob( @argv);
} else
{
foreach my $arg (@argv)
{
$arg =~ s/\%_/ /g;
}
}
} else
{
@argv = @ARGV;
}

@argv = ()
if ("@argv" eq '');

return @argv;
}




sub unix_glob(@)
{
my @args = @_;
my @new_args;

foreach my $arg (@args)
{
my @files = ENV_glob( $arg);

push @new_args, (@files) ? @files : $arg;
}
return @new_args;
}




sub ARGS_error_exit(@)
{
my @lines = @_;

ENV_say( 0, "$0 @ARGV");
print_usage();
ENV_say( 0, @lines);
exit( 2);
}




sub ARGS_fatal(@)
{
my @lines = @_;

ENV_say( 0, "$0 @ARGV");
print_usage();
ENV_say( 0, @lines);
ENV_stackdump();
exit( 9);
}




sub print_usage()
{
ENV_say( 0, "Usage: $USAGE");
}

1;

