#ifdef preprocessor___

   	   #endif

class A
{
	A() : m_asign(0), asd(4)
	{
if(){}
	}int method()
	{
		return 0;
	}int operator ++ ()
	{
		return 0;
	}

	int m_asign;
};

//
namespace aaa {
int main(int a, string b)
{
	return 0;

	try {

	}
	catch (a) // for cyclomatic complexity test
	{

	}
	catch (b) // for cyclomatic complexity test
	{

	}
}
}

"text" // C++ comments
"text________________"
"text" /* C comment */
"text________________"
"multiline____________
_text________________"
"multiline____________
_text________________"
"text" /* C multiline_
_____comment */ "text"
"text" /* C multiline_
_____comment */ "text"
