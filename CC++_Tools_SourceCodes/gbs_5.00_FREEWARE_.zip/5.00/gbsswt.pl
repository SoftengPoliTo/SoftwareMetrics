#=================================================
#
#   gbsswt.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSSWT @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::ask;
use glo::genopt;
use mod::gbsenv;
use mod::gbscmd;
use mod::gbsask;
use mod::run;
use mod::validate;
use mod::swset;








my $CANCELLED = 0;






$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( 'tool');













{
my @genopts = (
[ '<1>',    'tool',		'sso',  '', "Tool: '' == ASK, '-' == none, '.' == current" ],
[ 'new',    'create_new_tool', 'bso',   0, "Create a new Tool" ],
[ 'remove', 'remove_tool',     'bso',   0, "Remove a Tool from the Tools List" ],
);
my @genconflicts = (
[ [ new => 1 ], [ '=' => remove => 1] ],
);
GENOPT_set_optdefs( [ 'gbsswt', 'swt' ], \@genopts,
'Set and/or Create new Current Tool',
undef);
GENOPT_set_conflicts( \@genconflicts);
GENOPT_parse();
}
my $TOOL = GENOPT_get( 'tool');
my $NEW = GENOPT_get( 'create_new_tool');
my $REMOVE = GENOPT_get( 'remove_tool');




VALIDATE_root();




if (!$NEW && @GBS::TOOLS == 0)
{
if (ASK_YN( "No Tool(s) defined. Define now?", 'Y') eq 'Y')
{
$NEW = 1;
}
}




if ($NEW)
{
$TOOL = RUN_gbsnew( 'new_tool', $TOOL);
if ($TOOL eq '')
{
$TOOL = '.';
$CANCELLED = 1;
} else
{
ENV_say( 1, "Current Tool is $TOOL");
}
} elsif ($REMOVE)
{
my $removed_tool = RUN_gbsnew( 'rem_tool', $TOOL);
if ($GBS::TOOL eq $removed_tool)
{
ENV_say( 1, "Current Tool removed");
$TOOL = '';	# No current
} else
{
ENV_say( 1, "Current Tool is $GBS::TOOL");
$TOOL = '.';	# Keep current
}
}

if (!$CANCELLED)
{



if ($TOOL eq '')
{
$TOOL = GBSASK_tool();
$TOOL = '-'
if ($TOOL eq '');
}
SWSET_tool( $TOOL);








{
my @lines;
if (ENV_get_changed_envs())
{
push @lines, GBSENV_changed_setenv_commands( 0);
}
push @lines, GBSCMD_get_full_gbs_command( gbsshow => '--brief');

GBSENV_write_result_script( \@lines, 0);
}
}

ENV_exit( $RC);




END
{
ENV_print_end_msg( 0);
}


