#=================================================
#
#   tkxentry.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::tkxentry;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
TKXENTRY_new
TKXENTRY_get_invalid
TKXENTRY_get
TKXENTRY_put
);
}




use Tkx;

use glo::env;
use glo::types;
use glo::tkx;




sub TKXENTRY_new($$$$$$$@);
sub TKXENTRY_get_invalid();
sub TKXENTRY_get($);
sub TKXENTRY_put($;$);

sub do_validate($$$$);
sub get_width($$);








my $MAX_INT_LENGTH = length( "-2147483646");




my $INVALID_ENTRY_WIDGET;   # undef if current widget is OK




sub TKXENTRY_new($$$$$$$@)
{
my ($parent,
$textvariable_ref,
$width_or_ref,		# undef, $width or [ $width, $max_length ]
$default,
$name,
$type_spec_or_ref,	# [ $type, $occur, $manda, $constr, $constr_values_ref]
$post_func_or_ref,	# [ $post_func, $post_func_args_ref ]


@entry_args
) = @_;
my $this_entry;


my ($type, $occur, $manda, $constr, $constr_values_ref) = TYPES_split( $type_spec_or_ref);

my $default_width = ($type eq 'i') ? $MAX_INT_LENGTH : undef;
my ($width, $max_length) = get_width( $width_or_ref, $default_width);
unshift @entry_args, (-width => $width)
if (defined $width);

if ($occur eq 's' && lc $constr eq 's')	# scalar & selection
{
$this_entry = TKX_new_combobox( $parent, $textvariable_ref, $constr_values_ref, undef,
-state => 'readonly', @entry_args);
} else
{
$this_entry = TKX_new_entry( $parent, $textvariable_ref,
[ \&do_validate, [ $max_length, $default, $name, $type_spec_or_ref, $post_func_or_ref ] ],
@entry_args);
}

return $this_entry;
}




sub do_validate($$$$)
{
my ($this_widget,
$new_value,	    # %P
$validate_action,   # %V    key focusout
$validate_args_ref,
) = @_;
my ($is_ok, $error_text, $newer_value) = (1, undef, '');



$is_ok = 1;
$INVALID_ENTRY_WIDGET = undef;

if ($validate_action eq 'key' || $validate_action eq 'focusout')
{
my ($max_length, $default, $name, $type_spec_or_ref, $post_func_or_ref) = @{$validate_args_ref};
if ($validate_action eq 'key')
{
$newer_value = $new_value;
} else  # ($validate_action eq 'focusout')
{
if ($new_value ne '')
{
$newer_value = TYPES_get_values( $name, $new_value, $type_spec_or_ref, \$error_text);
if (defined $error_text)
{
$is_ok = 0;
$INVALID_ENTRY_WIDGET = $this_widget;
}
}
}




if (defined $post_func_or_ref && $is_ok)
{
($is_ok, $error_text, $newer_value) = ENV_call( $post_func_or_ref, [ $this_widget, $validate_action, $newer_value ]);
}
}




return ($is_ok, $error_text, $newer_value);
}




sub get_width($$)
{
my ($width_or_ref,
$default_max_length,
) = @_;
my ($width, $max_length);

if (defined $width_or_ref)
{
if (ref $width_or_ref)
{
($width, $max_length) = @{$width_or_ref}
} else
{
$width = $width_or_ref;
}
}
$max_length = (defined $width) ? $width : $default_max_length
if (!defined $max_length);

return ($width, $max_length);
}





sub TKXENTRY_get_invalid()
{
return $INVALID_ENTRY_WIDGET;
}




sub TKXENTRY_get($)
{
my ($widget,
) = @_;

return $widget->get();
}




sub TKXENTRY_put($;$)
{
my ($widget,
$value,	    # optional. undef will only clear the value. equal to ''
) = @_;

$widget->delete( 0, 'end');
$widget->insert( 0, $value)
if (defined $value);
}

1;

