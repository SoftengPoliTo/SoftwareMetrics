#=================================================
#
#   roots.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::roots;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
ROOTS_get_nr
ROOTS_get_all
ROOTS_exists
ROOTS_add
ROOTS_delete
ROOTS_write
ROOTS_close
);
}





use mod::gbsdb;




sub ROOTS_get_nr();
sub ROOTS_get_all();
sub ROOTS_exists($);
sub ROOTS_add($);
sub ROOTS_delete($);
sub ROOTS_write();
sub ROOTS_close($);

sub verify_file_open();












my $FILE_IS_OPEN = 0;
my $FILE_MODIFIED = 0;




my @ROOT_PATHS;		# Perl path nospace





sub ROOTS_get_nr()
{


verify_file_open();

return scalar @ROOT_PATHS;
}




sub ROOTS_get_all()
{


verify_file_open();

return @ROOT_PATHS;
}




sub ROOTS_exists($)
{
my ($root_path, 		# Perl path nospace
) = @_;


verify_file_open();

return (grep $_ eq $root_path, @ROOT_PATHS) ? 1 : 0;
}




sub ROOTS_add($)    		# Perl path nospace
{
my ($root_path,
) = @_;
my $is_added = 0;

verify_file_open();

if (!grep $_ eq $root_path, @ROOT_PATHS)
{
@ROOT_PATHS = sort (@ROOT_PATHS, $root_path);
$is_added = 1;
$FILE_MODIFIED = 1;
}

return $is_added;
}




sub ROOTS_delete($)
{
my ($root_path, 		# Perl path nospace
) = @_;
my $is_deleted = 0;

verify_file_open();

my $old_nr_roots = @ROOT_PATHS;
@ROOT_PATHS = grep $_ ne $root_path, @ROOT_PATHS;
if (@ROOT_PATHS != $old_nr_roots)
{
$is_deleted = 1;
$FILE_MODIFIED = 1;
}

return $is_deleted;
}




sub ROOTS_write()
{
my $was_modified = $FILE_MODIFIED;

if ($FILE_MODIFIED)
{
GBSDB_roots_write( \@ROOT_PATHS);
$FILE_MODIFIED = 0;
}

return $was_modified;
}




sub ROOTS_close($)
{
my ($must_write) = @_;
my $was_modified = $FILE_MODIFIED;

if ($FILE_IS_OPEN)
{
if ($must_write)
{
ROOTS_write();
}
@ROOT_PATHS = ();
$FILE_IS_OPEN = 0;
}

return $was_modified;
}




sub verify_file_open()
{
if (!$FILE_IS_OPEN)
{
@ROOT_PATHS = GBSDB_roots_get();
$FILE_IS_OPEN = 1;
$FILE_MODIFIED = 0;
}
}

1;
