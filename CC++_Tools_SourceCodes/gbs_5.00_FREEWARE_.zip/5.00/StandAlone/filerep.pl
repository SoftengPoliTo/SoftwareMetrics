#=================================================
#
#   filerep.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;





use File::Glob ':bsd_glob';      # Override glob built-in
use Cwd;




sub filerep_file($);

sub find_files_recursively(@);
sub recurse_dir($);
sub find_files(@);
sub read_args();
sub usage();
sub env_sig($@);
sub env_say($@);




my $RC = 0;
my $MAIN_NAME_UC;
my $PREFIX;
my $PREFIX_;
my $IS_WIN32;
my $XTERM_WIDTH;
my $XTERM_HEIGHT;

BEGIN
{
$| = 1;							# $OUTPUT_AUTOFLUSH
($MAIN_NAME_UC) = map { uc $_ } "/$0" =~ m!.*[/\\](.+)\.!;	# Extract filename and make it uppercase
$PREFIX = $MAIN_NAME_UC;
$PREFIX_ = ' ' x (length( $PREFIX) + 1);
$IS_WIN32 = ($^O eq 'MSWin32');
$XTERM_WIDTH = 100;
$XTERM_HEIGHT = 50;
if (-t STDOUT)
{
if ($IS_WIN32)
{
require Win32::Console;
import  Win32::Console;
($XTERM_WIDTH, $XTERM_HEIGHT) = Win32::Console->new()->Size();
} else
{
($XTERM_HEIGHT, $XTERM_WIDTH) = split( / /, qx(stty size));
}
}




CORE::say( '=' x ($XTERM_WIDTH - 5) . '');
}




my $CWD = getcwd();




my @MSG_LINES;




my @REGEXPS;
my @REL_FILE_DEFS;	# May contain wildcards




my $IS_TEST_MODE = 0;
my $MUST_RECURSE = 0;
my @RECURSE_WILD_SPECS;
my @TYPE_GROUPS;
my %OPTIONS = (
t   => [ 'b', \$IS_TEST_MODE ],
r   => [ 'l', \$MUST_RECURSE, \@RECURSE_WILD_SPECS ],
R   => [ 'l', \$MUST_RECURSE, \@TYPE_GROUPS ],
);

my %TYPE_GROUPS = (
perl    => [ '*.p?' ],
c	    => [ '*.c', '*.h' ],
'c++'   => [ '*.cpp', '*.h' ],
gbs	    => [ '*.gbs', '*.usr' ],
html    => [ '*.html' ],
script  => [ '*.bat', '*.doskey', '*.sh' ],
);

my @REL_FILE_SPECS;

my $NR_ERRORS = 0;
my $NR_WARNINGS = 0;

my @REP_REFS;


my $RENAMES_PRESENT = 0;
my $RENAME_COUNT = 0;
my $DELETES_PRESENT = 0;
my $DELETE_COUNT = 0;






=optdoc
use glo::genopt;












{
my @genopts = (
[ '<1>', 'command_or_commandsfile',  'ssm', "", [ 'Rename/Delete Command or @filespec of file containing Rename/Delete Commands',
"Rename/Delete Command: <delim><find><delim><replace><delim>[g|r][i]",
"- g = glob rename (default)",
"- r = Perl regular expression rename",
"- i = ignore case of search string",
"Empty <replace> deletes the file",
"commandsfile:  Empty lines and lines beginning with '#' are ignored" ] ],

[ '<*>', 'files',	'sso',	'',  "(wild-)Files and.or Dirs to process" ],
[ 't', 'test',		'bso',	 0, "test only - do not make modifications" ],
[ 'r', 'recurse',	'sao',	 '', "recurse direcory using comma-separated wild files" ],
[ 'R', 'recurse_group', 'sao',   '', "recurse direcory using comma-separated file-groups. e.g.: perl" ],
);
GENOPT_set_flag_prefix( '-');
GENOPT_set_optdefs( 'filerep', \@genopts,
'Rename/Delete files',
"Directory/Files starting with '.' are skipped");
GENOPT_parse();
}

=cut




{

read_args();

if ($MUST_RECURSE && @RECURSE_WILD_SPECS == 0)
{
env_say( 1, "No recurse (wild-)files specified. Assume *.*");
push @RECURSE_WILD_SPECS, '*.*';
}
map { CORE::say( "REGEXPS=$_") } @REGEXPS;
map { CORE::say( "REL_FILE_DEFS=$_") } @REL_FILE_DEFS;




my @rel_file_defs;
foreach my $find (@REGEXPS)
{
env_say( 1, "Command: $find");

my $delim = substr( $find, 0, 1);
my $command = substr( $find, 1);
my ($find, $replace, $replace_options) = split( quotemeta $delim, $command);
env_sig( EE => "- No find string specified")
if ($find eq '');
env_sig( EE => "- No replace string specified ($find)")
if (!defined $replace_options);
if ($replace_options ne '')
{
$replace_options = lc $replace_options;
} else
{
$replace_options = 'g';		# glob rename
}

my @replace_options = split( '', $replace_options);
my $replace_mode;			# g = glob, r = RegExp
my $must_ignore_case = 0;		# i
my $is_eval_mode = 0;
foreach my $option (@replace_options)
{
if (index( 'gr', $option) >= 0)
{
if (defined $replace_mode)
{
env_sig( EE => "- Replace mode ('$option') already defined to '$replace_mode'");
} else
{
$replace_mode = $option;
}
} elsif ($option eq 'i')
{
$must_ignore_case = 1;
} else
{
env_sig( EE => "- Invalid rep option '$option'. Allowed: [g|r] [i]");
}
}
$replace_mode = 'g'
if (!defined $replace_mode);




my $search;
if ($replace_mode eq 'g')				# glob rename
{
$find =~ tr!\\!/!;
if ($find !~ m!/! && $replace !~ m!/!)
{
$find = "*/$find";
$replace = "*/$replace";
}
$search = quotemeta( $find);
$search =~ s/\\\*/(.*)/g;
$search =~ s/\\\?/(.)/g;

if ($must_ignore_case)
{
$search = qr/^$search$/i;
} else
{
$search = qr/^$search$/;
}

if ($replace =~ /(\*|\?)/)
{
my $i = 1;
$replace =~ s/(\*|\?)/'$' . $i++/ge;	# concat to $1, $2, $3, etc
$replace = '"' . $replace . '"';
$is_eval_mode = 1;
}
} elsif ($replace_mode eq 'r')			# regexp rename
{
$search = $find;
if ($must_ignore_case)
{
$search = qr/$search/i;
} else
{
$search = qr/$search/;
}

if ($replace =~ /\$\d/)
{
$replace = '"' . $replace . '"';
$is_eval_mode = 1;
}
} else
{
env_sig( EE => "- Invalid option '$replace_mode'. Allowed:[g|r]");
}
if ($replace ne '')
{
$RENAMES_PRESENT++;
} else
{
$DELETES_PRESENT++;
}




push @REP_REFS, [$search, $replace, $is_eval_mode];
env_say( 2, "- find=$find ($search), replace=$replace, options=$replace_options");
}




env_say( 1, "Currently in: $CWD");
if ($MUST_RECURSE)
{
@REL_FILE_SPECS = find_files_recursively( @REL_FILE_DEFS);
} else
{
@REL_FILE_SPECS = find_files( @REL_FILE_DEFS);
}





{
my %seen;
@REL_FILE_SPECS = grep { ! $seen{ $_ }++ } @REL_FILE_SPECS;
}
}




{
if (@REL_FILE_SPECS)
{
env_say( 1, "Found " . scalar @REL_FILE_SPECS . " file(s).");
foreach my $filespec (@REL_FILE_SPECS)
{

filerep_file( $filespec);
}
} else
{
env_sig( W => "No files found");
}
}




{
env_say( 0, '');
if ($IS_TEST_MODE)
{
env_say( 1, "TestMode: $RENAME_COUNT files selected for rename")
if ($RENAMES_PRESENT);
env_say( 1, "TestMode: $DELETE_COUNT files selected for delete")
if ($DELETES_PRESENT);
} else
{
env_say( 1, "$RENAME_COUNT files renamed")
if ($RENAMES_PRESENT);
env_say( 1, "$DELETE_COUNT files deleted")
if ($DELETES_PRESENT);
}
$RC = 1
if ($RENAME_COUNT == 0 && $DELETE_COUNT == 0);

if (@MSG_LINES)
{
env_say( 1, "The following errors were encountered:");
map { env_say( 0, "  $_"); } @MSG_LINES;
$RC = 2;
}
}

exit $RC;




END
{
if (@MSG_LINES)
{
env_say( 1, "The following warnings/errors were encountered:");
map { env_say( 2, $_); } @MSG_LINES;
}

my $rc = $?;
print( "\a")
if ($rc > 0 || @MSG_LINES > 0);

env_say( 1, ($rc) ? "Failed ($?)" : "Done");
}




sub filerep_file($)
{
my ($old_file) = @_;


foreach my $ref (@REP_REFS)
{



my ($search, $replace, $is_eval_mode) = @{$ref};

if ($replace ne '')
{



my $new_file = $old_file;
my $changed;

if ($is_eval_mode)
{
$changed = $new_file =~ s/$search/$replace/gee;
} else
{
$changed = $new_file =~ s/$search/$replace/g;
}
if ($changed)
{
CORE::say( "  $old_file => $new_file");
if (! $IS_TEST_MODE)
{
CORE::say( "    rename( $old_file, $new_file)");
if (!rename( $old_file, $new_file))
{
env_sig( E => 'Rename failed', $!);

}
}
$RENAME_COUNT++;
last;
}
} else
{



if ($old_file =~ /$search/)
{
CORE::say( "  Delete $old_file");
if (! $IS_TEST_MODE)
{
CORE::say( "    unlink( $old_file)");
if (!unlink( $old_file))
{
env_sig( E => 'Delete failed:', $!);

}
}
$DELETE_COUNT++;
last;
}
}
}
}




sub find_files_recursively(@)
{
my @wild_dirs = @_;
my @rel_filespecs;

foreach my $wild_dir_spec (@wild_dirs)
{
$wild_dir_spec =~ s!//!/!g;
$wild_dir_spec =~ s!/$!!g;
}
env_say( 1, "Recursing (@RECURSE_WILD_SPECS) files in (@wild_dirs) ...");
foreach my $wild_dir_spec (@wild_dirs)
{
my @dir_specs;
if ($wild_dir_spec =~ /[\*\?]/)
{
push @dir_specs, grep -d $_, glob( $wild_dir_spec);
} else
{
if (-d $wild_dir_spec)
{
push @dir_specs, $wild_dir_spec;
} elsif (-f _)
{
env_sig( W => "FileSpec must be directory: '$wild_dir_spec'");
} else
{
env_sig( W => "No such directory '$wild_dir_spec'");
}
}
foreach my $dir_spec (@dir_specs)
{
push @rel_filespecs, recurse_dir( $dir_spec);
}
}

return @rel_filespecs;
}





sub recurse_dir($)
{
my ($dir,
) = @_;
my @rel_filespecs;




foreach my $wild_file (@RECURSE_WILD_SPECS)
{
my $filespec = "$dir/$wild_file";
if ($wild_file =~ /[\*\?]/)
{
push @rel_filespecs, grep ! -d $_, glob( $filespec);
} else
{
if (-f $filespec)
{
push @rel_filespecs, $filespec;
}
}
}




opendir( DIR, "$dir") || env_sig( F => "Cannot opendir '$dir'", $?);
my @entries = readdir( DIR);
closedir( DIR);
foreach my $entry (@entries)
{
next if (substr( $entry, 0, 1) eq '.');	    # Skip directories/files starting with '.'
my $this_dir = "$dir/$entry";
push @rel_filespecs, recurse_dir( $this_dir)
if (-d $this_dir);
}

return @rel_filespecs;
}




sub find_files(@)
{
my @filespecs = @_;
my @rel_filespecs;

env_say( 1, "Files: (@filespecs)");

foreach my $filespec (@filespecs)
{
if ($filespec =~ /[\*\?]/)
{
push @rel_filespecs, glob( $filespec);
} else
{
if (-f $filespec)
{
push @rel_filespecs, $filespec
} elsif (-d _)
{
push @rel_filespecs, glob( "$filespec/*.*");
env_sig( W => "FileSpec must be file: '$filespec'. Assumed $filespec/*.*");
} else
{
env_sig( W => "No such file '$filespec'");
}
}
}

return @rel_filespecs;
}




sub read_args()
{

if (@ARGV == 1 && $ARGV[0] =~ /^--?(h|help)$/)
{
usage();
exit 0;
} else
{
if (@ARGV < 2 || substr($ARGV[0], 0, 1) eq '-')
{
env_say( 1, "Not enough arguments");
usage();
exit 9;
}
}




my @pos_args;
my @options;
foreach my $arg (@ARGV)
{
if (substr( $arg, 0, 1) eq '-')
{
push @options, $arg;
} else
{
push @pos_args, $arg;
}
}




my $regexp_or_file = shift @pos_args;
if (substr( $regexp_or_file, 0, 1) eq '@')
{
my $regexp_file = substr( $regexp_or_file, 1);
env_say( 1, "Filerep File: '$regexp_file'");
open( my $in_fh, '<', $regexp_file) or env_sig( F => "Cannot open '$regexp_file'", $!);
my @lines = <$in_fh>;
close $in_fh;
foreach my $line (@lines)
{
$line =~ s/\s+$//;
if ($line ne '' && substr($line, 0, 1) ne '#')
{
push @REGEXPS, $line;
}
}
} else
{
push @REGEXPS, $regexp_or_file;
}
foreach my $pos_arg (@pos_args)
{
$pos_arg =~ tr!\\!/!	# perl_paths
if ($IS_WIN32);
push @REL_FILE_DEFS, $pos_arg
}

foreach my $option (@options)
{
my ($opt, $value) = $option =~ /-(.?)(.*)/;

my $ref = $OPTIONS{$opt};
if (defined $ref)
{
my ($type, $scalar_store_ref, $list_store_ref) = @{$ref};
if ($type eq 'b' || $type eq 'l')			# bool or list
{
if ($value eq '' || $value eq '+')
{
$$scalar_store_ref = 1;
} elsif ($value eq '-')
{
$$scalar_store_ref = 0;
} else
{
if ($type eq 'l')			    # list
{
if (substr( $value, 0, 1) eq '=')
{
$$scalar_store_ref = 1
if (defined $scalar_store_ref);
push @{$list_store_ref}, split( ',', substr( $value, 1));
} else
{
env_sig( E => "Invalid value ($value) for option '$option'. Allowed: '', '+', '-', '=<comma-list>'");
}
} else
{
env_sig( E => "Invalid value ($value) for option '$option'. Allowed: '', '+', '-'");
}
}
} elsif ($type eq 's')				    # scalar
{
if (substr( $value, 0, 1) eq '=')
{
$$scalar_store_ref = substr( $value, 1);
} else
{
env_sig( E => "Invalid value ($value) for option '$option'. Allowed: '=<comma-list>'");
}
}
} else
{
env_sig( E => "Invalid option '$option'.");
}
}




foreach my $type_group (@TYPE_GROUPS)
{
my $ref = $TYPE_GROUPS{$type_group};
if (!defined $ref)
{
my @all_groups = sort keys %TYPE_GROUPS;
env_sig( E => "Unknown type-group '-R=$type_group'",
"Allowed '@all_groups'");
} else
{
push @RECURSE_WILD_SPECS, @{$ref};
}
}

if (@REL_FILE_DEFS == 0)
{
(@REL_FILE_DEFS) = ($MUST_RECURSE) ? '.' : '*.*';
}




if ($NR_ERRORS > 0)
{
usage();
exit 2;
}
}




sub usage()
{
CORE::say( 'usage is: filerep <command> | @<commands-file> <files/dirs?...');
CORE::say( '                  [-t] [-r] [-r=<files>] [-R=<file-groups]');
CORE::say( '  command = <delim><find><delim><replace><delim>[g|r][i]');
CORE::say( '    g = glob rename');
CORE::say( '    r = perl regular expresion rename');
CORE::say( '    i = ignore case of search string');
CORE::say( '    Empty <replace> deletes the file');
CORE::say( '    -t == test-only');
CORE::say( '  -r = recurse directory');
CORE::say( '  -r=<files> = recurse direcory using comma-separated wild files');
CORE::say( '  -R=<file-groups> = recurse direcory using comma-separated file-groups. e.g.: perl');
CORE::say( "  commands-file: Empty lines and lines beginning with '#' are ignored");
CORE::say( "  wild files: Directories and Files starting with '.' are skipped");
CORE::say( "  Exit status is 0 if match, 1 if no match, else 2 if trouble" );
}






sub env_sig($@)
{
my ($sig,		# <severity><action> IWEF  EC. May be undef or ''
@lines_or_refs
) = @_;

if (defined $sig && $sig ne '')
{
my @lines = map { "    $_" } map { (ref $_) ? @{$_} : $_ } @lines_or_refs;

my ($severity, $action) = split( '', $sig);

$action = ($severity eq 'F') ? 'E' : 'C'
if ($action eq '');
my $sev = index( 'IWEF', $severity);
my $sig_text = qw( INFO WARNING ERROR INTERNAL-ERROR)[$sev];
my $sig_text_3 = qw( INF WRN ERR INT)[$sev];




{
my $err;
$err = "Invalid Signal Severity '$severity' ($sig)"
if (!defined $sig_text);
$err = "Invalid Signal Action '$action' ($sig)"
if (index( 'EC', $action) < 0);
if (defined $err)
{
CORE::say( "$PREFIX: ** FATAL**\n    $err");
map { CORE::say( $_) } @lines;
exit 9;
}
}




CORE::say( "$PREFIX: ** $sig_text **");
map { CORE::say( $_) } @lines;
push @MSG_LINES, "$sig_text_3: $lines[0]";




if ($sev > 0)	# WEF
{
${(undef, \$NR_WARNINGS, \$NR_ERRORS, \$NR_ERRORS)[$sev]}++;	# increment depending on severity
}




if ($action eq 'E')	    # Exit
{
if (defined $^S && $^S == 1)
{



die;
} else
{
my $exit_code = substr( '0129', $sev, 1);
exit $exit_code;
}
}
}
}




sub env_say($@)
{
my ($indent,    # 0 = no prefix, 1 = $prefix, 2 = $prefix_ - Negative = prefix_level - 1
@lines_and_or_refs
) = @_;

my @lines = map { (ref $_) ? @{$_} : $_ } @lines_and_or_refs;
if ($indent == 0)
{
map { CORE::say( $_) } @lines;
} else
{
if (abs( $indent) == 1)
{
my $first_line = shift @lines;
CORE::say( "$PREFIX: $first_line");
}
map { CORE::say( "$PREFIX_ $_") } @lines;
}
}


