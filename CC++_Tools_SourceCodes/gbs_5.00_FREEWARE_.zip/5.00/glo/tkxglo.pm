#=================================================
#
#   tkxglo.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::tkxglo;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
TKXGLO_geo_adjust_window
TKXGLO_geo_center_window
TKXGLO_photo
TKXGLO_create_table
TKXGLO_cursor_push
TKXGLO_cursor_pop
);
}




use Tkx;
use glo::env;
use glo::tkx;





sub TKXGLO_geo_adjust_window($);
sub TKXGLO_geo_center_window($$);
sub TKXGLO_photo($;$);
sub TKXGLO_create_table($$$);
sub TKXGLO_cursor_push($);
sub TKXGLO_cursor_pop();








my $IS_WIN32 = ENV_is_win32();

my @DECORATION_SIZES_REFS = (

[ 52, 0, 0, 0 ],	    # Windows
[ 15, 4, 4, 4 ],	    # Linux
);




my %PHOTOS;


my @CURSOR_STACK;





sub TKXGLO_geo_adjust_window($)
{
my ($this_geometry_ref,	# May be undef. Default is current geometry
) = @_;
my ($new_width, $new_height, $new_x, $new_y);

my ($screen_width, $screen_height) = TKX_screen_size( $TKX::MW);

my ($width, $height, $x, $y) = (defined $this_geometry_ref) ? @{$this_geometry_ref} : TKX_geometry( $TKX::MW);

$new_x = $x;
$new_y = $y;
$new_width = $width;
$new_height = $height;

my ($top, $right, $bottom, $left) = ($IS_WIN32) ? @{$DECORATION_SIZES_REFS[0]} : @{$DECORATION_SIZES_REFS[1]};

my $usable_width = $screen_width - $left - $right;
$new_width = $usable_width - $x
if ($x + $width > $usable_width);


my $usable_height = $screen_height - $top - $bottom;
$new_height = $usable_height - $y
if ($y + $height > $usable_height);



return ($new_width, $new_height, $new_x, $new_y);
}





sub TKXGLO_geo_center_window($$)
{
my ($main_window_or_geo_ref,    # if undef: screen geo
$sub_window_or_geo_ref,
) = @_;
my ($width, $height, $new_x, $new_y);






my @main_geo;
if (!defined $main_window_or_geo_ref)
{
@main_geo = (TKX_screen_size( $TKX::MW), 0, 0);
} elsif (ref $main_window_or_geo_ref eq 'ARRAY')
{
@main_geo = @{$main_window_or_geo_ref};
} else
{
@main_geo = TKX_geometry( $main_window_or_geo_ref);
}
my ($main_width, $main_height, $main_x, $main_y) = @main_geo;




if (ref $sub_window_or_geo_ref eq 'ARRAY')
{
($width, $height) = @{$sub_window_or_geo_ref};
} else
{
($width, $height) = TKX_geometry( $sub_window_or_geo_ref);
}




$new_x = ($main_width - $width) / 2;
$new_x = $main_x + 4
if ($new_x < 0);
$new_x += $main_x;

$new_y = ($main_height - $height) / 2;
$new_y = $main_y + 4
if ($new_y < 0);
$new_y += $main_y;

return ($width, $height, $new_x, $new_y);
}




sub TKXGLO_photo($;$)
{
my ($photo_name,
$photo_filespec,    # may be undef. Will overwrite existing $photo_name
) = @_;
my $photo;

if (defined $photo_filespec)
{
$photo = Tkx::image_create_photo( -file => $photo_filespec);
$PHOTOS{$photo_name} = $photo;
} else
{
$photo = $PHOTOS{$photo_name};
}

return $photo;
}




sub TKXGLO_create_table($$$)
{
my ($frame_ref,
$align_ref,	    # [ R or L, ...]
$table_refs_ref,    # [ @row_refs ]









) = @_;


my $nr_cols = @{$align_ref};
my $row = 0;
foreach my $row_ref (@{$table_refs_ref})
{
if (ref $row_ref)
{
my $col = 0;
for (my $col = 0; $col < $nr_cols; $col++)
{
my $col_ref = $row_ref->[$col];
if (defined $col_ref)
{

my ($anchor, $sticky) = ($align_ref->[$col] eq 'R') ? ('ne', 'ew') : ('nw', 'ew');
my @widget_options;
my $widget;
my ($type, $item_or_ref, $widget_ref, @args) = @{$col_ref};
if ($type eq 'label')
{



push @widget_options, ( -anchor => $anchor );
push @widget_options, @args;
$widget = TKX_new_label( $frame_ref, $item_or_ref, @widget_options);
} elsif ($type eq 'var')
{



push @widget_options, ( -anchor => $anchor );
push @widget_options, ( -relief => 'sunken');
push @widget_options, @args;
$widget = TKX_new_label( $frame_ref, $item_or_ref, @widget_options);
} elsif ($type eq 'combo')
{




my $action_ref = shift @args;
push @widget_options, @args;
$widget = TKX_new_combobox( $frame_ref, $item_or_ref, undef, $action_ref,
-state => 'readonly', @widget_options);
} elsif ($type eq '')
{



$widget = $frame_ref->new_label( -text => '');
} else
{
ENV_sig( F => "Invalid type '$type'");
}
$$widget_ref = $widget
if (defined $widget_ref);

my @grid_options;
my $colspan = 1;
while (! defined $row_ref->[$col + $colspan] && $col + $colspan < $nr_cols)
{
$colspan++;
}
push @grid_options, ( -columnspan => $colspan )
if ($colspan > 1);


$widget->g_grid( -row => $row, -column => $col, -sticky => $sticky, @grid_options);
}
}
} else
{



if ($row_ref eq '-')
{
my $widget = $frame_ref->new_ttk__separator( -orient => 'horizontal');
$widget->g_grid( -row => $row, -column => 0, -sticky => 'ew', -columnspan => $nr_cols);
} else
{
ENV_sig( F => "Invalid row_ref '$row_ref'");
}
}

$row++;
}
}




sub TKXGLO_cursor_push($)
{
my ($cursor,    # one of '', 'watch', ...
) = @_;
my $old_cursor;

$old_cursor = $TKX::MW->cget( '-cursor');
push @CURSOR_STACK, $old_cursor;
$TKX::MW->configure( -cursor => $cursor);

TKX_update();	    # Show the cursor

return $old_cursor;
}




sub TKXGLO_cursor_pop()
{
my $this_cursor;

ENV_sig( F => 'Cursor_Stack exhausted')
if (@CURSOR_STACK == 0);


$this_cursor = pop @CURSOR_STACK;
$TKX::MW->configure( -cursor => $this_cursor);
TKX_update();	    # Show the cursor

return $this_cursor;
}


1;

