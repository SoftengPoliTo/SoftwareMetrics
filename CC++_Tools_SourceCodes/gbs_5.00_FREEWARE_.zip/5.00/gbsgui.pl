#=================================================
#
#   gbsgui.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSGUI @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::genopt;
use mod::gbsenv;
use mod::validate;
use mod::run;












$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ 't',      'test_mode',    'bso',	    0, 'Run in test-mode' ],
[ 'geo',    'geo',          'sso',	  '.', 'Start geometry - Internal use (width, height, x, y)' ],
);
GENOPT_set_optdefs( 'gbsgui', \@genopts,
'Startup the GBS GUI',
undef);
GENOPT_parse();
}
my $TEST_MODE = GENOPT_get( 'test_mode');
my $GEO = GENOPT_get( 'geo');
my $VERBOSE = GENOPT_get( 'verbose');

VALIDATE_root();

RUN_tkx( gbsgui_tkx => $TEST_MODE, [ $VERBOSE, $TEST_MODE, $GEO ] );

ENV_exit( $RC);




END
{
ENV_print_end_msg( ($TEST_MODE) ? 1 : 0);
}


