#=================================================
#
#   gbssystoolbg.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSSYSTOOLBG @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::genopt;
use mod::gbsenv;
use mod::gbsoptenv;
use mod::validate;
use mod::sys;
use mod::plugin;
use mod::gbssysbg;














$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( 'tool');













{
my @genopts = (
[ '<1>',    'steps_fspec',  'ssm',      "", "Steps-file spec" ],
[ 'i' ,	    'ignore_errors', 'bso',      0, "Continue generation after error(s)" ],
[ 'vs',	    'view_sum',	    'bso',       1, "View summary at completion" ],
[ 'jobs',   'jobs',    'isor1..9',       2, 'Max nr parallel jobs within a submitted job' ],
);
my @genenvs = qw( LOG_PATH FLAGS_* APP_* );
GENOPT_set_optdefs( 'gbssystoolbg', \@genopts,
'This is the background counterpart of gbssystool',
undef);
GENOPT_set_envdefs( \&GBSOPTENV_set, \&GBSOPTENV_print, \@genenvs);
GENOPT_parse();
}
my $STEPS_FILE_SPEC = GENOPT_get( 'steps_fspec');
my $IGNORE_ERRORS = GENOPT_get( 'ignore_errors');
my $MUST_VIEW_SUM = GENOPT_get( 'view_sum');
my $JOBS = GENOPT_get( 'jobs');

{



VALIDATE_root();




SYS_set_envs();
PLUGIN_setup( 'tool');




my @opts =
(
GENOPT_makeopt( 0, ignore_errors => $IGNORE_ERRORS),
GENOPT_makeopt( 0, view_sum => $MUST_VIEW_SUM),
GENOPT_makeopt( 0, jobs => $JOBS),
);


$RC = GBSSYSBG_execute( 'tool', $IGNORE_ERRORS, undef, $STEPS_FILE_SPEC, \@opts);
}




ENV_exit( $RC);




END
{
my $rc = $?;




GBSSYSBG_print_errors()
if ($rc != 0);

ENV_print_end_msg( 1);
}


