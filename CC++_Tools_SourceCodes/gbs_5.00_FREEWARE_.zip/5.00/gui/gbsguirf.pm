#=================================================
#
#  gbsguirf.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package gui::gbsguirf;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSGUIRF_create
GBSGUIRF_exec
GBSGUIRF_exec_xterm
GBSGUIRF_exec_detached
);
}




use Tkx;

use glo::env;
use glo::spit;
use glo::proc;

use glo::tkxlistbox;




sub GBSGUIRF_create($);
sub GBSGUIRF_exec($$);
sub GBSGUIRF_exec_xterm($$);
sub GBSGUIRF_exec_detached($$);




my $IS_LINUX = ENV_is_linux();








my $RF;	    # Right Frame
my $RLB;    # Right List Box




sub GBSGUIRF_create($)
{
($RF,
) = @_;

my $width = ENV_get_term_size();
(my $rlbf, $RLB) = TKXLISTBOX_new( $RF, undef, -font => 'My_stdout', -width => $width);
$rlbf->g_pack( -side => 'right', -fill => 'both' , -expand => 1);
}




sub GBSGUIRF_exec($$)
{
my ($command,
$full_command,
) = @_;





TKXLISTBOX_say( $RLB, 300, undef, $command);

ENV_setenv( GBS_PROMPT_SEPARATOR_PRINTED => 0);


my $this_command;
if ($IS_LINUX && $full_command =~ /^(\.|source)\s+/)
{
$this_command = SPIT_tmp_script_file_nl( 'GBS_GUI_EXEC', $full_command);

} else
{
$this_command = $full_command;
}

open( my $pipe, '-|', $this_command) || ENV_sig( F => "Unable to open pipe '$full_command'", "- $!");
while (my $line = <$pipe>)
{

TKXLISTBOX_say( $RLB, 300, undef, $line);
}
close $pipe;
unlink $this_command
if ($this_command ne $full_command);
TKXLISTBOX_say( $RLB, 300, undef, '-');
}




sub GBSGUIRF_exec_xterm($$)
{
my ($command,
$full_command,
) = @_;



my $command_items_ref = ENV_split_quoted_space( $full_command);

PROC_spawn_detached_xterm( $command_items_ref, $command, 1);
}




sub GBSGUIRF_exec_detached($$)
{
my ($command,
$full_command,
) = @_;



my $command_items_ref = ENV_split_quoted_space( $full_command);
PROC_spawn_detached( $command_items_ref, 0);
}

1;
