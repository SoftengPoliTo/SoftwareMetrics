#=================================================
#
#   gbsauditsum.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSAUDIT @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;

use glo::genopt;
use mod::gbsenv;

use mod::gbsoptenv;
use mod::validate;


use mod::run;

use mod::gbsbgjob;

use mod::gfl;


use mod::audit;
use mod::fspec;




sub do_summary();
sub show_summary_file_name();
sub get_sum_filespec($);




my $HTML_LOG_PATH;
my $SUM_FILESPEC;




my $MUST_SHOW_STDOUT = 0;






$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( 'audit');













{
my @genopts = (
[ '<1>',    'caller',		'ssosgbsaudit,gbssysaudit', 'gbsaudit', 'gbsaudit or gbssysaudit' ],
[ 'i',      'ignore_errors',    'bso',	    0, "Continue auditing after error(s)" ],
[ 'stdout', 'show_stdout',	'bso',	    1, "Show errorlines (0 when not interactive)" ],
[ 'vs',     'view_sum',		'bso',	    1, "View summary at completion" ],
[ 'sum',    'run_summary',	'bso',	    1, "Create summary" ],
);
my @genenvs = qw( LOG_PATH MODE FLAGS_* APP_* );
GENOPT_set_optdefs( 'gbsauditsum', \@genopts,
'Perform an AUDIT on one or more files - Internal use only',
'Summary files are written to $GBS_LOG_PATH. View with gbssilo');
GENOPT_set_envdefs( \&GBSOPTENV_set, \&GBSOPTENV_print, \@genenvs);
GENOPT_parse();
}
my $CALLER = GENOPT_get( 'caller');
my $IGNORE_ERRORS = GENOPT_get( 'ignore_errors');
my $SHOW_STDOUT = GENOPT_get( 'show_stdout');
my $MUST_VIEW_SUM = GENOPT_get( 'view_sum');
my $MUST_DO_SUM = GENOPT_get( 'run_summary');




ENV_setenv( GBS_IGNORE_ERRORS => $IGNORE_ERRORS);
$MUST_SHOW_STDOUT = (GBSENV_mode_is_interactive() && $SHOW_STDOUT) ? 1 : 0;
ENV_setenv( GBS_AUDIT_OPTIONS => [ $MUST_SHOW_STDOUT ]);




















VALIDATE_root();




if ($CALLER eq 'gbsaudit')
{



$HTML_LOG_PATH = ENV_getenv_perl_path( 'GBS_LOG_PATH');
} else
{



$HTML_LOG_PATH = "$GBS::ROOT_PATH/silo/audits";
mkdir $HTML_LOG_PATH
if (!-e $HTML_LOG_PATH);
}


if ($MUST_DO_SUM)
{
my $this_rc = do_summary();
$RC = $this_rc
if ($this_rc > $RC);
}
show_summary_file_name();





ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
}




sub do_summary()
{
my $rc = 0;

my ($app, $app_data_ref) = GFL_read_head( $GBS::AUDIT); # $GBS::TMP_PATH/$GBS::AUDIT _ $GBS::EXEC_ID.gfl
if (defined $app)
{
$SUM_FILESPEC = get_sum_filespec( $app_data_ref->[0]);  # $datetime_packed);




{
GBSBGJOB_batch_init( 1);
my @bgjob_refs;
if (-e FSPEC_scadef( $GBS::AUDIT_PLUGIN))
{
push @bgjob_refs, GBSBGJOB_banner( "Audit SCA Summary: $GBS::AUDIT");
push @bgjob_refs, GBSBGJOB_scasum( "${GBS::AUDIT}_summary", $SUM_FILESPEC);
} else
{
my @pos_args = ($SUM_FILESPEC);
my @command_data_refs = AUDIT_get_summary_command_data_refs_exp( $GBS::AUDIT, \@pos_args);
if (@command_data_refs)
{
push @bgjob_refs, GBSBGJOB_banner( "Audit Summary: $GBS::AUDIT");
push @bgjob_refs, GBSBGJOB_exec( "${GBS::AUDIT}_summary", undef, undef, @command_data_refs);	# $must_print_commands, $out_files
} else
{
ENV_say( 1, "$GBS::AUDIT: No Summary Command specified in audit.gbs");
}
}
if (@bgjob_refs)
{
$rc = GBSBGJOB_batch_run( 'gbsaudit_post', '-', \@bgjob_refs);
ENV_say( 1, "$GBS::AUDIT: Summary generated ($rc)...")
if (-e $SUM_FILESPEC);
}
GBSBGJOB_batch_finish();
}




if (-e $SUM_FILESPEC)
{
if ($MUST_VIEW_SUM)
{
ENV_whisper( 1, "$GBS::AUDIT: View Summary file");
ENV_sig( F => "$GBS::AUDIT: Summary file not found '$SUM_FILESPEC'")
if (!-f $SUM_FILESPEC);
ENV_whisper( 1, "$GBS::AUDIT: Starting Browser...");
RUN_browser( $SUM_FILESPEC);
}
} else
{
ENV_say( 1, "$GBS::AUDIT: No Summary generated ($rc)...");
}
unlink( GFL_filespec( $GBS::AUDIT));
} else
{
ENV_say( 1, "$GBS::AUDIT: No Summary generated...");
}

return $rc;
}




sub show_summary_file_name()
{
if (defined $SUM_FILESPEC)
{
ENV_say( 1, "Summary file:");
ENV_say( 2, "  $SUM_FILESPEC");
}
}




sub get_sum_filespec($)
{
my ($audit_datetime_packed,
) = @_;


my $audit_prefix = join( '_', $CALLER, $GBS::BUILD, $GBS::AUDIT, $audit_datetime_packed);

return "$HTML_LOG_PATH/${audit_prefix}_sum.html";
}


