#=================================================
#
#  maint.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::maint;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
MAINT_audits_handling
MAINT_map_network_drives
);
}




use glo::env;
use glo::ask;
use glo::format;
use mod::gbsdb;
use mod::audit;
use mod::swa;




sub MAINT_audits_handling($$$);
sub MAINT_map_network_drives($$$);

sub run_audit($$);

sub map_add($$$);
sub map_del($$$);
sub map_show($);




my $IS_WIN32 = ENV_is_win32();




sub MAINT_audits_handling($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref
) = @_;

my $longest_string = 0;
my @audit_refs;

foreach my $audit (@GBS::AUDITS)
{
my ($plugin, $both_length);
$plugin = AUDIT_get_plugin( $audit);
$both_length = length( $audit) + length( $plugin);
push @audit_refs, [ $audit, $plugin, $both_length ];
$longest_string = $both_length
if ($both_length > $longest_string);
}

if (@audit_refs > 0)
{
my @audit_items;
foreach my $ref (@audit_refs)
{
my ($audit, $plugin, $both_length) = @{$ref};
my $command_items_ref = AUDIT_get_maint_command_ref( $audit);	# pclintmaint.pl, prqamaint.pl
if (defined $command_items_ref)
{
my $string = "$audit     " . (' ' x ($longest_string - $both_length)) . "[$plugin]";
push @audit_items, [ $string, \&run_audit, [ $audit, $plugin, $command_items_ref ] ];
}
}

ASK_menu( 'Select Audit', \@audit_items, $entries_ref);
} else
{
ENV_sig( W => "No Audit Maintenance scripts specified");
}
}




sub run_audit($$)
{
my ($menu_entry,
$data_ref,
$entries_ref,
) = @_;

my ($audit, $plugin, $command_items_ref) = @{$data_ref};


my $saved_gbs_audit = SWA_set( $audit, 0);

ENV_say( 1, "Executing [ $plugin ] Maint...");	# pclintmaint.pl, prqamaint.pl

push @{$command_items_ref}, @{$entries_ref}		# Add the remaining menu entries
if (defined $entries_ref);

my $full_command = ENV_prepare_command( $command_items_ref);
ENV_system( $full_command, undef);			# no RC check, no logfile

SWA_set( $saved_gbs_audit, 0);			# restore
}




sub MAINT_map_network_drives($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref,
) = @_;

my @map_refs = GBSDB_maps_get();
map_show( \@map_refs);

my @menu_refs = (
[ 'Add    Entry', \&map_add, \@map_refs ],
[ 'Delete Entry', \&map_del, \@map_refs ],
);
ASK_menu( 'Select MAPs action', \@menu_refs, $entries_ref);

}




sub map_add($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref
) = @_;

my @map_refs = @{$data_ref};

my $win_path;
my $lunix_path;
if ($IS_WIN32)
{
$win_path = ASK_path( "Enter Windows Path (X:/... or //...)", '', 0, 1);
} else
{
$win_path = ASK_other_path( "Enter Windows Path (X:/... or //...)", '', 0);
}
if ($win_path ne '')
{
if ($IS_WIN32)
{
$lunix_path = ASK_other_path( "Enter Lunix Path (~/... or /...)", '', 0);
} else
{
$lunix_path = ASK_path( "Enter Lunix Path (~/... or /...)", '', 0, 1);
}
if ($lunix_path ne '')
{
ENV_say( 2, "$win_path -> $lunix_path");
if (ASK_YNQ( "OK?", 'Y', 1) eq 'Y')
{
push @map_refs, [ $win_path, $lunix_path ];
GBSDB_maps_write( \@map_refs);
@{$data_ref} = @map_refs;
ENV_say( 1, "Added");
}
}
}
map_show( \@map_refs);
}




sub map_del($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref
) = @_;

my @map_refs = @{$data_ref};

my @wins = map { "$_->[0] -> $_->[1]" } @map_refs;
my $index = ASK_index_from_menu( "Windows Path to be deleted", -1, undef, [ '', @wins ]);
if ($index != 0)
{
my ($win_path, $lunix_path) = @{$map_refs[$index - 1]};
ENV_say( 2, "$win_path -> $lunix_path");
if (ASK_YNQ( "OK?", 'Y', 1) eq 'Y')
{
@map_refs = grep $win_path ne $_->[0], @map_refs;
GBSDB_maps_write( \@map_refs);
@{$data_ref} = @map_refs;
ENV_say( 1, "Deleted");
}
}
map_show( \@map_refs);
}




sub map_show($)
{
my ($map_refs_ref) = @_;

if (@{$map_refs_ref})
{
ENV_say( 1, "Current Maps:");
ENV_say( 0, FORMAT_table( 0, 2, ' -> ', undef, @{$map_refs_ref}));
} else
{
ENV_say( 1, "No current Maps");
}
}

1;
