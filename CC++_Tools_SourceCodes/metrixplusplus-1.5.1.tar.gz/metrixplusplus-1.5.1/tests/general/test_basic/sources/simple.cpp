

// Just produce any code in order to test basic workflow
namespace hmm
{

#define old_prep

class A
{

	A()
	{
		/* first funtion */
		this->m_me88er = 10;
		if (a & b)
		{
			for (int i = 0; i < 0 && i > 0; i++)
			{
				int a; // right?
			}
		}
	}


	int func(int param = 5)
	{
		class embeded
		{
			embeded()
			{
				int a = 10;
				if (true)
				{
					// again crazy
				}
			}
		};
		if (a);
	}

	int func_to_be_removed_in_new_sources(int param = 5)
	{
		class embeded
		{
			embeded()
			{
				int a = 10;
				if ("text")
				{
					/* again crazy */
				}
			}
		};
		if (a && b);
	}

	int never(int how_long = 999)
	{
		while(true)
		{

		}
		return 1;
	}

	int m_me88er = 10;
};

}
