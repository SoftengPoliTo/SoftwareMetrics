#=================================================
#
#   fcreate.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::fcreate;

use strict;
use warnings FATAL =>  'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
FCREATE_any
FCREATE_flinc
FCREATE_sysflinc
FCREATE_sca
FCREATE_export
FCREATE_ssprop
FCREATE_abt_file
FCREATE_abt_ref_file
FCREATE_scope
FCREATE_owners
FCREATE_system
FCREATE_steps
FCREATE_switch
FCREATE_sys
FCREATE_comment_chars
FCREATE_subsys_script
FCREATE_makefile
FCREATE_gbsall
);
}




use glo::env;
use glo::spit;
use glo::file;
use mod::fspec;
use mod::templates;




sub FCREATE_any($$;$);
sub FCREATE_flinc($$$$$);
sub FCREATE_sysflinc($$$);
sub FCREATE_sca($$$$$);
sub FCREATE_export($$$$);
sub FCREATE_ssprop($$);
sub FCREATE_abt_file($$$$);
sub FCREATE_abt_ref_file($$$$);
sub FCREATE_scope($$$$$);
sub FCREATE_owners($$);
sub FCREATE_system($$);
sub FCREATE_steps($$$);
sub FCREATE_switch($$$);
sub FCREATE_sys($$$);
sub FCREATE_comment_chars($);
sub FCREATE_subsys_script($$$$);
sub FCREATE_makefile($$);
sub FCREATE_gbsall($$);

sub create_gbs_file($$$@);
sub create_file($$$@);
sub create_empty_file($);








sub FCREATE_any($$;$)
{
my ($filespec,
$template_spec_or_comment_ref,	# $template_spec or [ $begin_comment, $end_comment, $start_index ]
$subsys_component_ref,		# Optional [ $subsys, $component ]. If undef: do not translate %token%
) = @_;



my ($path, $file_name, $filetype) = ENV_split_spec_pnt( $filespec);
my $file = "$file_name$filetype";

if (!defined $template_spec_or_comment_ref)
{



SPIT_file( $filespec, []);
} elsif (ref $template_spec_or_comment_ref)
{



my ($begin_com, $end_com, $start_index) = @{$template_spec_or_comment_ref};

my $begin_com_l = length( $begin_com);
my $end_com_l = length( $end_com);
my $max_line_length = 72 - $start_index;
my $border_length = $max_line_length - $begin_com_l - $end_com_l;
my $left_com = $begin_com . ' ' x (4 - $begin_com_l);
my $left_com_l = length( $left_com);
my $file_text = 'File: ' . (defined $subsys_component_ref) ? $file : '%FILE%';
my $file_text_l = length( $file_text);
my $leader = ' ' x $start_index;
my @lines;
push @lines, $leader. $begin_com . '=' x $border_length . $end_com;
push @lines, $leader. $left_com  . $file_text . ' ' x ($max_line_length - $left_com_l - $file_text_l - $end_com_l) . $end_com;
push @lines, $leader. $begin_com . '=' x $border_length . $end_com;
push @lines, '';
push @lines, $leader. $begin_com . ' ===EOF=== ' . $end_com;
foreach my $line (@lines)
{
$line =~ s/\s*$//;	# remove trailing white
}

SPIT_file_nl( $filespec, \@lines);
} elsif ($template_spec_or_comment_ref ne '')
{



my ($subsys, $component) = @{$subsys_component_ref};
my $template_spec = $template_spec_or_comment_ref;

my $include_guard = uc $file;
$include_guard =~ s/\./_/g;
$path =~ s/$GBS::ROOT_PATH/\$GBS_ROOT_PATH/;

FILE_copy_template( $template_spec, $filespec,
SYSTEM_NAME	    => $GBS::SYSTEM_NAME,
SUBSYS	    => $subsys,
COMPONENT	    => $component,
FILE	    => $file,
FILE_NAME	    => $file_name,
FILE_TYPE	    => $filetype,
PATH	    => $path,
UC_FILE	    => uc $file,
UC_FILE_NAME    => uc $file_name,
UC_FILE_TYPE    => uc $filetype,
INCLUDE_GUARD   => $include_guard,
);
} else
{



SPIT_file( $filespec, []);
}

return $filespec;
}






sub FCREATE_flinc($$$$$)
{
my ($file,		    # incs_<type>.gbs, incs_<type>.usr, etc. see above
$root_path,
$subsys,	    # may be ''
$component,	    # may be ''
$build,		    # may be ''
) = @_;
my $filespec;



my $template = ( $file =~ /^incs/) ? 'incs' : 'flags';

$filespec = FSPEC_flinc( $file, $root_path, $subsys, $component, $build);

create_gbs_file( $filespec, $template, undef,
BUILD => $build);

return $filespec;
}






sub FCREATE_sysflinc($$$)
{
my ($file,		    # sysincs_<type>.gbs, sysincs_<type>.usr, etc. see above
$root_path,
$build,
) = @_;
my $filespec;

my $template = ( $file =~ /^sysincs/) ? 'incs' : 'flags';

$filespec = FSPEC_sysflinc( $file, $root_path, $build);

create_gbs_file( $filespec, $template, undef,
BUILD => $build);

return $filespec;
}






sub FCREATE_sca($$$$$)
{
my ($file,		    # sca_<build>.gbs, sca_ALL.gbs, sca_<build>.usr, etc. see above
$root_path,
$subsys,	    # may be ''
$audit,
$build_or_name,	    # may also be <uppercase_name>
) = @_;
my $filespec;

my $meta;
if ($subsys)
{
$meta = $subsys . '::AUDIT';
} else
{
$meta = 'SYSAUDIT';
}
$meta .= ":$audit";
$meta .= "[$build_or_name]";

$filespec = FSPEC_sca( $file, $root_path, $subsys, $audit, $build_or_name);
create_gbs_file( $filespec, 'sca', undef,
META => $meta);

return $filespec;
}




sub FCREATE_ssprop($$)
{
my ($root_path,
$subsys,
) = @_;
my $filespec;

$filespec = FSPEC_ssprop( $root_path, $subsys);
create_empty_file( $filespec);

return $filespec;
}




sub FCREATE_export($$$$)
{
my ($file,	    	#export.gbs or export.usr
$root_path,
$subsys,
$component,	# can be '' in case of build/export.gbs or undef for non-gbs subsys
) = @_;
my $filespec;

my $meta = $subsys;
$meta .= '::' . $component
if ($component ne '');
$filespec = FSPEC_export( $file, $root_path, $subsys, $component);
create_gbs_file( $filespec, 'export', undef,
META => $meta);

return $filespec;
}




sub FCREATE_abt_file($$$$)
{
my ($file,		# e.g. build.gbs, audit.usr, tool.gbs, etc
$root_path,
$abt_name,
$plugin_name,
) = @_;
my $filespec;

(my $path, $file) = FSPEC_abt_file( $file, $root_path, $abt_name);
$filespec = "$path/$file";

my $template_name = ENV_split_spec_n( $file);
create_gbs_file( $filespec, $template_name, undef,
ABT_NAME	 =>  $abt_name,
PLUGIN	 =>  $plugin_name,
);

return $filespec;
}




sub FCREATE_abt_ref_file($$$$)
{
my ($file,		# e.g. build.gbs, audit.usr, tool.gbs, etc
$root_path,
$abt_name,	# e.g.: mingwd
$plugin_name,	# e.g.: mingw
) = @_;
my $filespec;

(my $path, $file) = FSPEC_abt_file( $file, $root_path, $abt_name);
$filespec = "$path/$file";

my $file_name = ENV_split_spec_n( $file);
my $filename_gbs = "$file_name.gbs";

my $template_file = "${file_name}_ref";
create_gbs_file( $filespec, $template_file, undef,
ABT_NAME	 =>  $abt_name,
PLUGIN	 =>  $plugin_name,
INCLUDE	 =>  $filename_gbs,
);

return $filespec;
}




sub FCREATE_scope($$$$$)
{
my ($file,		# scope.gbs or scope.usr
$root_path,
$subsys,
$component,
$lines_ref) = @_;
my $filespec;

$filespec = FSPEC_scope( $file, $root_path, $subsys, $component);
create_gbs_file( $filespec, 'scope', $lines_ref,
META => "$subsys\:\:$component");

return $filespec;
}




sub FCREATE_owners($$)
{
my ($file,		    #  with or without .gbs or .usr
$root_path,
) = @_;
my $filespec;

$filespec = FSPEC_owners( $file, $root_path);
create_gbs_file( $filespec, 'owners', undef);

return $filespec;
}




sub FCREATE_system($$)
{
my ($file,		    #  with or without .gbs or .usr
$root_path,
) = @_;
my $filespec;

$filespec = FSPEC_system( $file, $root_path);
create_empty_file( $filespec);

return $filespec;
}




sub FCREATE_steps($$$)
{
my ($file,		# steps.gbs or steps.usr
$root_path,
$system_name) = @_;
my $filespec;

$filespec = FSPEC_steps( $file, $root_path);

my @lines;
foreach my $subsys (@GBS::ALL_SUBSYSTEMS)
{
push @lines,
"STEP $subsys",
"     EXEC       = SELECT",
'';
}
create_gbs_file( $filespec, 'steps', \@lines,
SYSTEM_NAME => $system_name);

return $filespec;
}




sub FCREATE_switch($$$)
{
my ($file,			# switch.gbs or switch.gbs.bat or switch.gbs.sh or

$root_path,
$system_name) = @_;
my $filespec;

my $site = $GBS::SITE;
$site = 'EIN'
if ($site eq '');

$filespec = FSPEC_switch( $file, $root_path);
my $template_file = ENV_split_spec_f( $filespec);
create_gbs_file( $filespec, $template_file, undef,
SYSTEM_NAME => $system_name,
SITE => $site);

return $filespec;
}




sub FCREATE_sys($$$)
{
my ($file,		# sys.gbs or sys.usr
$root_path,
$system_name) = @_;
my $filespec;

$filespec = FSPEC_sys( $file, $root_path);
create_gbs_file( $filespec, 'sys', undef,
SYSTEM_NAME => $system_name);

return $filespec;
}




sub FCREATE_comment_chars($)
{
my ($root_path,
) = @_;
my $filespec;

$filespec = FSPEC_comment_chars( $root_path);
create_gbs_file( $filespec, 'comment_chars', undef);

return $filespec;
}




sub FCREATE_subsys_script($$$$)
{
my ($file_name,	# gbssub with or without .sh or .bat
$root_path,
$subsys,
$ss_type,	# MAKE, MSVS or OTHER
) = @_;
my $filespec;

$filespec = FSPEC_subsys_script( $file_name, $root_path, $subsys);
my $filetype = ENV_split_spec_t( $filespec);
create_gbs_file( $filespec, lc "gbssub_$ss_type$filetype", undef,
SUBSYS =>  $subsys);

return $filespec;
}




sub FCREATE_makefile($$)
{
my ($root_path,
$subsys,
) = @_;
my $filespec;

$filespec = FSPEC_makefile( $root_path, $subsys);
create_file( $filespec, 'Makefile.mk', undef,
SUBSYS =>  $subsys);

return $filespec;
}




sub FCREATE_gbsall($$)
{
my ($filetype,	    # full_name+type or .sh or .bat or ''
$in_install,	    # In GBS_SCRIPTS_ROOT else in GBS_BASE_PATH
) = @_;
my $filespec;

$filespec = FSPEC_gbsall( $filetype, $in_install);
my $template_file = ENV_split_spec_f( $filespec);
my $location = ($in_install) ? 'Install' : 'User';
create_gbs_file( $filespec, $template_file, undef,
LOCATION =>  $location);

return $filespec;
}




sub create_gbs_file($$$@)
{
my ($filespec,	    # path/file
$template_file,	    # $file or $name
$lines_ref,	    # may be undef
@translate	    # Optional. ($token, $value) | ($token, [@insert_lines]), ...
) = @_;



if (!-e $filespec || -z $filespec)
{
$template_file .= '.gbs'
if ($template_file !~ /\./);
my $template_spec = TEMPLATES_get_gbs( $template_file, 'I');
ENV_whisper( 1, "Creating $filespec",
"From template $template_file");
my ($path, $file) = ENV_split_spec_pf( $filespec);
$path =~ s/$GBS::ROOT_PATH/\$GBS_ROOT_PATH/;
my @general_translate = (
FILE => $file,
PATH => $path,
);
push @general_translate, (_LINES_ => $lines_ref)
if (defined $lines_ref);
FILE_copy_template( $template_spec, $filespec, (@translate, @general_translate));
chmod 0755, $filespec
if (substr( $filespec, -3, 3) eq '.sh');	# set file to 'x'
} else
{
ENV_say( 1, "'$filespec' already exists - not created");
}
}




sub create_file($$$@)
{
my ($filespec,	    # path/name.gbs or .usr
$template_file,	    # $file or $name
$lines_ref,	    # may be undef
@translate	    # Optional. ($token, $value) | ($token, [@insert_lines]), ...
) = @_;



if (!-e $filespec || -z $filespec)
{
my $template_spec = TEMPLATES_get_gbs( $template_file, 'F');
ENV_whisper( 1, "Creating $filespec",
"From template $template_file");
my ($path, $file) = ENV_split_spec_pf( $filespec);
$path =~ s/$GBS::ROOT_PATH/\$GBS_ROOT_PATH/;
my @general_translate = (
FILE => $file,
PATH => $path,
);
push @general_translate, (_LINES_ => $lines_ref)
if (defined $lines_ref);
FILE_copy_template( $template_spec, $filespec, (@translate, @general_translate));
chmod 0755, $filespec
if (substr( $filespec, -3, 3) eq '.sh');	# set file to 'x'
} else
{
ENV_say( 1, "'$filespec' already exists - not created");
}
}




sub create_empty_file($)
{
my ($filespec) = @_;

my $file = ENV_split_spec_f( $filespec);
if (!-f $filespec)
{
ENV_whisper( 1, "Creating empty $file file");
SPIT_file( $filespec, []);
chmod 0755, $filespec
if (substr( $filespec, -3, 3) eq '.sh');	# set file to 'x'
} else
{
ENV_say( 1, "$file file already exists - not created");
}
}

1;

