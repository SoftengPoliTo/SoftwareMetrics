#=================================================
#
#   sws.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::sws;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SWS_set
);
}




use glo::env;
use mod::gbsenvs;
use mod::gbsenv;
use mod::gbsglo;
use mod::gbsrc;
use mod::ssprop;




sub SWS_set($$);








sub SWS_set($$)
{
my ($subsys,
$must_write,
) = @_;
my $old_subsys = $GBS::SUBSYS;

ENV_debug( 1, "Set $GBS::ROOT_PATH, $subsys");




if ($subsys eq '')
{



GBSENVS_set_subsys( 1);
} else
{



my $subsys_path = "$GBS::ROOT_PATH/dev/$subsys";
my $ss_type = SSPROP_get_type( undef, $subsys);
my $is_full_gbs = ($ss_type eq 'GBS') ? 1 : 0;
my $comp_path = '';
my @all_components;
my $app_path = '';
if ($is_full_gbs)
{
$comp_path = "$subsys_path/comp";
@all_components = GBSGLO_components( $subsys, $GBS::ROOT_PATH);
} else
{
$app_path = "$subsys_path/app";
}

GBSENVS_set_subsys( 1, $subsys_path,
[ SUBSYS		=> $subsys,
SSTYPE		=> $ss_type,    	# GBS MSVS make Other
SUBSYS_PATH	=> $subsys_path,


COMP_PATH		=> $comp_path,
ALL_COMPONENTS	=> \@all_components,


APP_PATH		=> $app_path,
]);
}




GBSRC_write_root( subsys => $subsys)
if ($must_write && GBSENV_mode_is_interactive());

return $old_subsys;
}

1;


