#!/bin/bash
#=================================================
#   File:   %FILE%
#   Path:   %PATH%
#   SubSys: %SUBSYS%
#=================================================
# 	Requires 1 parameter: action
# 	Called to cleanup, build, make or audit a non-GBS SubSystem
#	For 'make' SubSystems
#=================================================
#
#   Currently in $GBS_ROOT_PATH/dev/$GBS_SUBSYS
#   Applicable EnvVars:
#	GBS_BUILD
#	GBS_BUILD_PLUGIN
#	GBS_BUILD_PLUGIN_PATH				('make' or 'Other')
#	GBS_BUILD_PLUGIN_BIN_PATH			('make' or 'Other')
#	GBS_BUILD_<src_type>				('make' or 'Other')
#	GBS_AUDIT_PLUGIN	    (for Audit only)
#	GBS_AUDIT_PLUGIN_PATH	    (for Audit only)    ('make' or 'Other')
#	GBS_AUDIT_PLUGIN_BIN_PATH   (for Audit only)	('make' or 'Other')
#	GBS_AUDIT_<src_type>	    (for Audit only)	('make' or 'Other')
#
#   Availabe EnvVars:
#       GBS_ROOT_PATH
#       GBS_SUBSYS
#       GBS_SUBSYS_PATH
#       GBS_AUDIT_PATH
#       GBS_BUILD_PATH
#       GBS_APP_PATH
#
#	GBS_MAKE		<make command>
#     	GBS_IGNORE_ERRORS       0 | 1
#      	GBS_MODE                FINAL | ASSERT | DEBUG | PROFILING
#      	GBS_OPT                 YES | SPEED | SIZE | DEBUG | NO
#      	GBS_DEBUGGER            NO | YES
#      	GBS_MAP                 NO | YES
#
#      	GBS_BLD_<src_type>      <primary_output_type>
#      	GBS_SYSFLAGS_<src_type>
#      	GBS_FLAGS_<src_type>	also contains flags resulting from MODE, OPT, DEBUGGER and MAP
#      	GBS_SYSINCS_<src_type>
#      	GBS_INCS_<src_type>
#
#       GBS_MAKE_FLAGS		'-i' if GBS_IGNORE_ERRORS == TRUE
#
#=================================================
rc=0

action=$1

#
#   Adjust for proper actions
#   Just one to a few lines per action. Keep it simple. Do not try to be clever.
#   Do not forget to set rc to proper exit value (0=success, >0=fail)
#

case $action in
#
#   CLEANUP_BLD
#
cleanup_bld)
    echo "GBSSUB_: ** SubSys=$GBS_SUBSYS - Build=$GBS_BUILD - Action=$action"
    #  <== add your command(s) to execute the bld_cleanup here and remove these lines.
    #      Do not forget to set rc to proper exit value (0=success, >0=fail)
    #  <== Probably something like:
    $GBS_MAKE clean -f Makefile.mk
    rc=$?
    ;;
build)
    #
    # 	BUILD
    #
    echo "GBSSUB_: ** SubSys=$GBS_SUBSYS - Build=$GBS_BUILD - Action=$action"
    #  <== add your command(s) to execute the build here and remove these lines.
    # 	   Do not execute the 'clean' in this command.
    #      Do not forget to set rc to proper exit value (0=success, >0=fail)
    #  <== Probably something like:
    $GBS_MAKE -f Makefile.mk -B -k $GBS_MAKE_FLAGS
    rc=$?
    ;;
make)
    #
    # 	MAKE
    #
    echo "GBSSUB_: ** SubSys=$GBS_SUBSYS - Build=$GBS_BUILD - Action=$action"
    #  <== add your command(s) to execute the make here and remove these lines.
    #      Do not forget to set rc to proper exit value (0=success, >0=fail)
    #  <== Probably something like:
    $GBS_MAKE -f Makefile.mk $GBS_MAKE_FLAGS
    rc=$?
    ;;
cleanup_aud)
    #
    # 	CLEANUP_AUD
    #
    echo "GBSSUB_: ** SubSys=$GBS_SUBSYS - Build=$GBS_BUILD - Audit=$GBS_AUDIT - Action=$action"
    #  <== add your command(s) to execute the audit_cleanup here and remove these lines.
    #      Do not forget to set rc to proper exit value (0=success, >0=fail)
    #  <== Probably something like:
    $GBS_MAKE clean -f Makefile_aud.mk
    rc=$?
    ;;
audit)
    #
    # 	AUDIT
    #
    echo "GBSSUB_: ** SubSys=$GBS_SUBSYS - Build=$GBS_BUILD - Audit=$GBS_AUDIT - Action=$action"
    #  <== add your command(s) to execute the gbssubaudit.bat here and
    #      remove these lines.
    #      Do not forget to set rc to proper exit value (0=success, >0=fail)
    #  <== Probably something like:
    #  $GBS_MAKE -f Makefile_aud.mk -B -k $GBS_MAKE_FLAGS
    echo "GBSSUB_: No audits for non-GBS SubSystems"
    rc=$?
    ;;
*)
    #
    # 	DEFAULT
    #
    echo "GBSSUB_: ***FATAL ERROR***"
    echo "- Invalid action '$action'. Must be one of (cleaunp_bld build make cleanup_aud audit)"
    rc=9
esac

exit $rc
###EOF###
