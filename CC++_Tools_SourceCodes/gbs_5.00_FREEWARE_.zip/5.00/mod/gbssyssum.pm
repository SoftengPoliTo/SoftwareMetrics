#=================================================
#
#   gbssyssum.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbssyssum;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSSYSSUM_start
GBSSYSSUM_update
GBSSYSSUM_finish
GBSSYSSUM_read
GBSSYSSUM_recreate
);
}




use glo::env;
use glo::slurp;
use glo::spit;
use glo::flock;
use mod::gbsres;
use mod::logsum;




sub GBSSYSSUM_start($);
sub GBSSYSSUM_update($);
sub GBSSYSSUM_finish($);
sub GBSSYSSUM_read();
sub GBSSYSSUM_recreate($);








my $GBSSUM_PATH = "$GBS::SILO_PATH/.gbs/gbssum";
my $GBSSYSSUM_FILESPEC = "$GBSSUM_PATH/gbssyssum.log";

my $DEFAULT_GBS_LOG_PATH = $GBS::LOG_PATH;




my $LOGFILE_SPEC;
my $GBSSUM_LOGFILE_SPEC;
my $GBSSUM_LOGFILE_SPEC_FH;







sub GBSSYSSUM_start($)
{
my ($sum_line_ref,		# @ITEMS    (without <<EOF>>)



) = @_;

$LOGFILE_SPEC = ENV_perl_paths( $sum_line_ref->[4]);  # $os_logfile
my $logfile = ENV_split_spec_f( $LOGFILE_SPEC);
$GBSSUM_LOGFILE_SPEC = "$GBSSUM_PATH/$logfile.sum";




$GBSSUM_LOGFILE_SPEC_FH = FLOCK_ex_wait( "$GBSSUM_LOGFILE_SPEC.lck");
LOGSUM_write( $GBSSUM_LOGFILE_SPEC, $sum_line_ref);
}








sub GBSSYSSUM_update($)
{
my ($sum_line_ref,		# @ITEMS



) = @_;

my $logfile_spec = ENV_perl_paths( $sum_line_ref->[4]);  # $os_logfile
my $logfile = ENV_split_spec_f( $logfile_spec);
my $gbssum_logfile_spec = "$GBSSUM_PATH/$logfile.sum";




my $sumline = LOGSUM_write( "$logfile_spec.sum", $sum_line_ref);

my $fh = FLOCK_ex_wait( "$GBSSYSSUM_FILESPEC.lck");
SPIT_append_file_nl( $GBSSYSSUM_FILESPEC, $sumline);
FLOCK_unlock( $fh);




unlink $gbssum_logfile_spec;
unlink "$GBSSUM_PATH/.$logfile.sum.lck";
}








sub GBSSYSSUM_finish($)
{
my ($sum_line_ref,		# @ITEMS    (without <<EOF>>)



) = @_;




my $sumline = LOGSUM_write( "$LOGFILE_SPEC.sum", $sum_line_ref);

my $fh = FLOCK_ex_wait( "$GBSSYSSUM_FILESPEC.lck");
SPIT_append_file_nl( $GBSSYSSUM_FILESPEC, $sumline);
FLOCK_unlock( $fh);




unlink $GBSSUM_LOGFILE_SPEC;
FLOCK_unlock( $GBSSUM_LOGFILE_SPEC_FH, 1);
}





sub GBSSYSSUM_read()
{
my @sum_line_refs;




my $fh = FLOCK_ex_wait( "$GBSSYSSUM_FILESPEC.lck");	    # Exclusive because we may have to append the file




if (-e $GBSSYSSUM_FILESPEC)
{
my $line_nr = 0;
foreach my $sum_line (SLURP_file( $GBSSYSSUM_FILESPEC))
{
$line_nr++;
next if ($sum_line eq '');
my @items = split( /\t/, $sum_line);

my $eof = $items[15];
if (defined $eof && $eof eq '<<EOF>>')
{
push @sum_line_refs, \@items;
} else
{
ENV_sig( W => "Invalid log line in $GBSSYSSUM_FILESPEC",
sprintf( "%8d %s", $line_nr, $sum_line));
}
}
}




my @files_added;
foreach my $sum_filespec (ENV_glob( "$GBSSUM_PATH/*.log.sum"))
{

my ($filename) = $sum_filespec =~ m!.*/(.*)\.log.sum$!;
my $fh = FLOCK_ex_nowait( "$sum_filespec.lck");
if (defined $fh)
{
ENV_say( 1, "$filename: Not Locked");




my @line_items = LOGSUM_read( $sum_filespec);
push @sum_line_refs, \@line_items;




my $log_sum_filespec = "$GBS::LOG_PATH/$filename.log.sum";
ENV_whisper( 2, "Writing $log_sum_filespec...");
LOGSUM_write( $log_sum_filespec, \@line_items)
if (!-e $log_sum_filespec);
push @files_added, $sum_filespec;

FLOCK_unlock( $fh, 1);
} else
{
ENV_say( 1, "$filename: Running");
}
}




if (@files_added)
{
my $nr_added = @files_added;
ENV_say( 1, "Adding $nr_added summary file(s)...");
ENV_say( 2, 'Sorting and writing...');
@sum_line_refs = sort { $a->[12] cmp $b->[12] } @sum_line_refs;	    # $date_time
if (-e $GBSSYSSUM_FILESPEC)
{
my $backup_filespec = ENV_backup_file( $GBSSYSSUM_FILESPEC, '.sav', 'F');	    # $exit_on_error
ENV_say( 2, "Backup created: $backup_filespec");
}
my @lines = map { join( "\t", @{$_}) } @sum_line_refs;
SPIT_file_nl( $GBSSYSSUM_FILESPEC, \@lines);
ENV_say( 1, "Deleting $nr_added file(s)...");
unlink @files_added;
}

FLOCK_unlock( $fh);

return @sum_line_refs;
}




sub GBSSYSSUM_recreate($)
{
my ($log_path) = @_;    # may be undef. Default = $GBS_LOG_PATH

$log_path = $DEFAULT_GBS_LOG_PATH
if (!defined $log_path);

LOGSUM_reset();

ENV_say( 1, "Recreating Silo gbssyssum.log from $log_path...");

my @log_sum_files = ENV_glob( "$log_path/*.log.sum");
my $nr_files = @log_sum_files;
if ($nr_files > 0)
{
ENV_say( 2, "Found $nr_files .log.sum Files");
if (-e $GBSSYSSUM_FILESPEC)
{
my $backup_filespec = ENV_backup_file( $GBSSYSSUM_FILESPEC, '.sav', 'F');	    # $exit_on_error
ENV_say( 2, "Backup created: $backup_filespec");
}




my @log_sum_file_refs;

foreach my $sum_file (@log_sum_files)
{
my $numtime = GBSRES_get_logfile_numtime( $sum_file);
push @log_sum_file_refs, [ $numtime, $sum_file ];
}
@log_sum_file_refs = sort { $a->[0] cmp $b->[0] } @log_sum_file_refs;





my @lines;
foreach my $ref (@log_sum_file_refs)
{
my (undef, $sum_file) = @{$ref};
my $line = LOGSUM_read( $sum_file);

push @lines, $line;
}
SPIT_file_nl( $GBSSYSSUM_FILESPEC, \@lines);
ENV_say( 1, 'Recreating Silo gbssyssum.log: Done');
} else
{
ENV_say( 1, 'No .log.sum files found');
}
}

1;
