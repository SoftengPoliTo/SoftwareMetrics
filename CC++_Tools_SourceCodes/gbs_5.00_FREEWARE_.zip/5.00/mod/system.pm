#=================================================
#
#   system.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::system;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SYSTEM_read
SYSTEM_get_system_info
SYSTEM_get
SYSTEM_get_os
SYSTEM_get_os_refs
SYSTEM_get_os_ref_names
SYSTEM_get_os_ref_value
SYSTEM_get_osnames
SYSTEM_create
SYSTEM_put
SYSTEM_put_os
SYSTEM_put_os_refs
SYSTEM_add_os_ref
SYSTEM_remove_os_ref
SYSTEM_write
SYSTEM_close
SYSTEM_fix
);
}




use glo::env;
use glo::slurp;
use glo::scm;
use mod::gbsfile;




sub SYSTEM_read();
sub SYSTEM_get_system_info($);
sub SYSTEM_get($$);
sub SYSTEM_get_os($$$);
sub SYSTEM_get_os_refs($$$);
sub SYSTEM_get_os_ref_names($$$);
sub SYSTEM_get_os_ref_value($$$$);
sub SYSTEM_get_osnames($$);
sub SYSTEM_create($);
sub SYSTEM_put($$$);
sub SYSTEM_put_os($$$$);
sub SYSTEM_put_os_refs($$$$);
sub SYSTEM_add_os_ref($$$$);
sub SYSTEM_remove_os_ref($$$$);
sub SYSTEM_write();
sub SYSTEM_close();
sub SYSTEM_fix($;@);

sub read_file($);
sub get_item($);
sub get_os_item($$);
sub put_item($$);
sub put_os_item($$$);
sub write_file();
sub general_init();
sub check_value($$$$);








my $CUR_OS = $^O;
my @SUPPORTED_SCMS = SCM_get_names( '*');   # All platforms
my $DEFAULT_SCMS = $SUPPORTED_SCMS[0];

my %DEFS = (




id		    => [ 0, 0, 'system',       0, [ 'system' ] ],
system_name     => [ 0, 0, 'NoName',       0, undef ],
version_start   => [ 0, 0, '0',            0, qr/^\d{9}$/ ],		# RVVYYMMDD
version_end	    => [ 0, 0, '',             1, qr/^\d{9}$/ ],		# RVVYYMMDD
scms	    => [ 1, 0, $DEFAULT_SCMS,  0, \@SUPPORTED_SCMS ],
scms_data	    => [ 0, 0, '',             1, undef ],
scms_repository => [ 1, 0, '',             1, undef ],
root_version    => [ 0, 0, '0.00',         0, qr/^\d+\.\d\d$/ ],		# r.vv
builds	    => [ 1, 1, [],             0, undef ],			# [ $build, $plugin ]
audits	    => [ 1, 1, [],             1, undef ],			# [ $audit, $plugin ]
tools	    => [ 1, 1, [],             1, undef ],			# [ $tool, $plugin ]
);
my @ITEMS = qw( id system_name root_version version_start version_end
scms scms_data scms_repository builds audits tools);

my %old_item_names = (
build_start => 'version_start',
build_end	=> 'version_end',
targets	=> 'builds',
);




my $CUR_ROOT_PATH = '';
my $CURRENT_FILE = '';
my $FILE_CHANGED = 0;

my %DATA;



my %OTHER_OS;


my $NR_ERRORS_FOUND = 0;
my $RUNNING_FIX = 0;




sub SYSTEM_read()
{
read_file( $GBS::ROOT_PATH);
}








sub SYSTEM_get_system_info($)
{
my ($root_path, # must exist
) = @_;
my @values;	    # ($system_name, $root_version);

my $filespec = "$root_path/system.gbs";
my @lines = SLURP_file( $filespec);

foreach my $item (qw( system_name root_version))
{
my ($line) = grep( /^$item=/, @lines);
ENV_sig( EE => "SYSTEM item '$item' not found in $filespec")
if (!defined $line);
my $value = substr( $line, length( $item) + 1);
ENV_sig( EE => "No value for SYSTEM item '$item' in $filespec")
if (!defined $value);

push @values, $value;
}

return wantarray ? @values : $values[0];
}




sub SYSTEM_get($$)
{
my ($root_path,
$item,
) = @_;

my $def_ref = $DEFS{$item};
ENV_sig( F => "No such SYSTEM item ($item)")
if (!defined $def_ref);
ENV_sig( F => "Must use SYSTEM_get_os")
if ($def_ref->[0] == 1);	# $is_os_item

read_file( $root_path)
if ($root_path ne $CUR_ROOT_PATH);

return get_item( $item);
}





sub SYSTEM_get_os($$$)
{
my ($root_path,
$osname,	    # '.' == Current OS
$item,
) = @_;
my $value;		    # $value or $values_ref

my $def_ref = $DEFS{$item};
ENV_sig( F => "No such SYSTEM item ($item)")
if (!defined $def_ref);
ENV_sig( F => "Must use SYSTEM_get")
if ($def_ref->[0] == 0);	# $is_os_item

read_file( $root_path)
if ($root_path ne $CUR_ROOT_PATH);

$osname = $CUR_OS
if ($osname eq '.');

$value = get_os_item( $osname, $item);		# scalar: $value or $values_ref

return $value;
}





sub SYSTEM_get_os_refs($$$)
{
my ($root_path,
$osname,		# '.' == Current OS, '*' == All OS
$item,			# 'audits', 'builds', 'tools'
) = @_;
my @values_refs;		# ( [ $name, $value ], ...)



my $def_ref = $DEFS{$item};
ENV_sig( F => "No such SYSTEM item ($item)")
if (!defined $def_ref);
ENV_sig( F => "Must use SYSTEM_get")
if ($def_ref->[0] == 0);	# $is_os_item

read_file( $root_path)
if ($root_path ne $CUR_ROOT_PATH);


$osname = $CUR_OS
if ($osname eq '.');

my @osnames = ($osname eq '*') ? keys %{$DATA{$item}} : ($osname);
foreach my $osname (@osnames)
{
push @values_refs, @{get_os_item( $osname, $item)};
}

return @values_refs;
}





sub SYSTEM_get_os_ref_names($$$)
{
my ($root_path,
$osname,		# '.' == Current OS, '*' == All OS
$item,			# 'audits', 'builds', 'tools'
) = @_;
my @names;

my $def_ref = $DEFS{$item};
ENV_sig( F => "No such SYSTEM item ($item)")
if (!defined $def_ref);
ENV_sig( F => "Must use SYSTEM_get")
if ($def_ref->[0] == 0);	# $is_os_item

read_file( $root_path)
if ($root_path ne $CUR_ROOT_PATH);

$osname = $CUR_OS
if ($osname eq '.');

my @osnames = ($osname eq '*') ? keys %{$DATA{$item}} : ($osname);
foreach my $osname (@osnames)
{
push @names, map { $_->[0] } @{get_os_item( $osname, $item)};	# [ $name, $value ]
}

return @names;
}




sub SYSTEM_get_os_ref_value($$$$)
{
my ($root_path,
$osname,		# '.' == Current OS, '*' == All OS
$item,			# 'audits', 'builds', 'tools'
$name,			# e.g: audit_name
) = @_;
my $value;

my $def_ref = $DEFS{$item};
ENV_sig( F => "No such SYSTEM item ($item)")
if (!defined $def_ref);
ENV_sig( F => "Must use SYSTEM_get")
if ($def_ref->[0] == 0);	# $is_os_item

read_file( $root_path)
if ($root_path ne $CUR_ROOT_PATH);

$osname = $CUR_OS
if ($osname eq '.');
my @osnames = ($osname eq '*') ? keys %{$DATA{$item}} : ($osname);

my @item_refs = map { @{get_os_item( $_, $item)} } @osnames;
foreach my $ref (@item_refs)	# [ $name, $value ]
{
if ($ref->[0] eq $name)
{
$value = $ref->[1];
last;
}
}
ENV_sig( F => "No such SYSTEM item name: $osname $item $name")
if (!defined $value);

return $value;
}






sub SYSTEM_get_osnames($$)
{
my ($root_path,
$item,
) = @_;
my @osnames;

my $def_ref = $DEFS{$item};
ENV_sig( F => "No such SYSTEM item ($item)")
if (!defined $def_ref);
ENV_sig( F => "No osname for item $item")
if ($def_ref->[0] == 0);	# $is_os_item

read_file( $root_path)
if ($root_path ne $CUR_ROOT_PATH);

@osnames = keys( %{$DATA{$item}});
@osnames = reverse @osnames
if ($osnames[0] ne $CUR_OS);

return @osnames;
}




sub SYSTEM_create($)
{
my ($root_path,
) = @_;

general_init();
$CUR_ROOT_PATH = $root_path;
$CURRENT_FILE = "$root_path/system.gbs";
$FILE_CHANGED = 0;
}




sub SYSTEM_put($$$)
{
my ($root_path,
$item,
$value,	    # $value or $values_ref
) = @_;

my $def_ref = $DEFS{$item};
ENV_sig( F => "No such SYSTEM item ($item)")
if (!defined $def_ref);
ENV_sig( F => "Must use SYSTEM_put_os")
if ($def_ref->[0] == 1);	# $is_os_item

read_file( $root_path)
if ($root_path ne $CUR_ROOT_PATH);

put_item( $item, $value);
}




sub SYSTEM_put_os($$$$)
{
my ($root_path,
$osname,    # '.' == Current OS
$item,
$value,	    # $value or $values_ref
) = @_;

my $def_ref = $DEFS{$item};
ENV_sig( F => "No such SYSTEM item ($item)")
if (!defined $def_ref);
ENV_sig( F => "Must use SYSTEM_put")
if ($def_ref->[0] == 0);	# $is_os_item

read_file( $root_path)
if ($root_path ne $CUR_ROOT_PATH);

$osname = $CUR_OS
if ($osname eq '.');

put_os_item( $osname, $item, $value);
}




sub SYSTEM_put_os_refs($$$$)
{
my ($root_path,
$osname,	    # '.' == Current OS
$item,
$values_refs_ref,   # [ [ $name, $value ], ... ]
) = @_;

my $def_ref = $DEFS{$item};
ENV_sig( F => "No such SYSTEM item ($item)")
if (!defined $def_ref);
ENV_sig( F => "Must use SYSTEM_put")
if ($def_ref->[0] == 0);	# $is_os_item

read_file( $root_path)
if ($root_path ne $CUR_ROOT_PATH);

$osname = $CUR_OS
if ($osname eq '.');

my @values_refs = sort( { $a->[0] cmp $b->[0] } @{$values_refs_ref});

put_os_item( $osname, $item, \@values_refs);
}




sub SYSTEM_add_os_ref($$$$)
{
my ($root_path,
$osname,	    # '.' == Current OS
$item,
$values_ref,	    # [ $name, $value ]
) = @_;

my $def_ref = $DEFS{$item};
ENV_sig( F => "No such SYSTEM item ($item)")
if (!defined $def_ref);
ENV_sig( F => "Must use SYSTEM_put")
if ($def_ref->[0] == 0);	# $is_os_item

read_file( $root_path)
if ($root_path ne $CUR_ROOT_PATH);

$osname = $CUR_OS
if ($osname eq '.');

my @values_refs = (@{get_os_item( $osname, $item)}, $values_ref);		    # [ $name, $value ]
@values_refs = sort( { $a->[0] cmp $b->[0] } @values_refs);

put_os_item( $osname, $item, \@values_refs);
}




sub SYSTEM_remove_os_ref($$$$)
{
my ($root_path,
$osname,	    # '.' == Current OS
$item,
$name,		    # [ $name, $value ]
) = @_;


my $def_ref = $DEFS{$item};
ENV_sig( F => "No such SYSTEM item ($item)")
if (!defined $def_ref);
ENV_sig( F => "Must use SYSTEM_put")
if ($def_ref->[0] == 0);	# $is_os_item

read_file( $root_path)
if ($root_path ne $CUR_ROOT_PATH);

$osname = $CUR_OS
if ($osname eq '.');

my @values_refs = grep( $_->[0] ne $name, @{get_os_item( $osname, $item)});	    # [ $name, $value ]

put_os_item( $osname, $item, \@values_refs);
}




sub SYSTEM_write()
{
my $file_written = $FILE_CHANGED;

write_file()
if ($FILE_CHANGED);

return $file_written;
}




sub SYSTEM_close()
{
if ($CUR_ROOT_PATH ne '')
{
$CUR_ROOT_PATH = '';
$CURRENT_FILE = '';
$FILE_CHANGED = 0;
%DATA = ();
%OTHER_OS = ();
}
}




sub SYSTEM_fix($;@)
{
my ($root_path,
@item_pairs,	    # repair-pairs
) = @_;
my $is_updated;

$RUNNING_FIX = 1;
read_file( $root_path)
if ($root_path ne $CUR_ROOT_PATH);
while (@item_pairs)
{
my $name = shift @item_pairs;
my $value = shift @item_pairs;
put_item( $name, $value);
}

if ($NR_ERRORS_FOUND > 0)
{
if (get_item( 'build_start') == 0)
{
put_item( build_start => $GBS::FULL_VERSION);  # RVVYYMMDD
}
$NR_ERRORS_FOUND = 0;
}

$is_updated = $FILE_CHANGED;
write_file()
if ($FILE_CHANGED);
$RUNNING_FIX = 0;

return $is_updated;
}




sub read_file($)
{
my ($root_path) = @_;

my $filespec = "$root_path/system.gbs";

general_init();
$NR_ERRORS_FOUND = 0;
$FILE_CHANGED = 0;
$CUR_ROOT_PATH = '';
$CURRENT_FILE = '';


GBSFILE_open( $filespec, 1, undef, undef);
my $line = GBSFILE_get_line();
while ($line)
{

my ($name, $value) = split( /=/,$line, 2);
$value = ''
if (!defined $value);
my ($item, $osname) = split( /-/, $name, 2);
$osname = ''
if (!defined $osname);
{
my $new_item_name = $old_item_names{$item};
if (defined $new_item_name)
{
$item = $new_item_name;
$FILE_CHANGED = 1;
}
}
my $def_ref = $DEFS{$item};
if (defined $def_ref)
{
my ($is_os_item, $is_ref_list, $default, $empty_ok, $check) = @{$def_ref};
if ($is_ref_list)
{
my @values;
if ($value ne '')
{
@values = split( ',', $value);
if (@values != 2)
{
$values[1] = lc $values[0];
GBSFILE_sig( W => "$item -> $osname: Incomplete value list ($values[0])",
"Assumed (@values)");
$NR_ERRORS_FOUND++;
$FILE_CHANGED = 1 ;
}
} else
{
if (!$empty_ok)
{
GBSFILE_sig( W => "Item '$name' must have a value");
}
}
if ($is_os_item)
{

push @{$DATA{$item}->{$osname}}, [ @values ];
$OTHER_OS{$osname} = 1
if ($osname ne $CUR_OS);
} else
{

push @{$DATA{$item}}, [ @values ];
}
} else
{
if ($value ne '')
{
check_value( $item, $default, $check, $value)
if (defined $check);
} else
{
if (!$empty_ok)
{
GBSFILE_sig( W => "Item '$name' must have a value");
$value = $default;
}
}
if ($is_os_item)
{

$DATA{$item}->{$osname} = $value;
$OTHER_OS{$osname} = 1
if ($osname ne $CUR_OS);
} else
{

$DATA{$item} = $value;
}
}
} else
{
GBSFILE_sig( W => "Invalid item '$name'");
}
$line = GBSFILE_get_line();
}





foreach my $item (@ITEMS)
{
my (undef, $is_ref_list, $default, $empty_ok) = @{$DEFS{$item}};
if (!$empty_ok && !defined $DATA{$item})
{
GBSFILE_sig( W => "Item '$item' missing");
$DATA{$item} = $default;
$NR_ERRORS_FOUND++;
}
}

ENV_sig( W => "system.gbs: $NR_ERRORS_FOUND errors found.",
"Use gbsmaint 7 5 (Fix system.gbs) to repair",
"or gbsedit system.gbs for manual repair")
if ($NR_ERRORS_FOUND > 0 && !$RUNNING_FIX);

$CURRENT_FILE = $filespec;
$CUR_ROOT_PATH = $root_path;


}




sub get_item($)
{
my ($item,
) = @_;
my $value;

$value = $DATA{$item};

return $value;
}




sub get_os_item($$)
{
my ($osname,
$item,
) = @_;
my $value;



$value = $DATA{$item}->{$osname};
if (!defined $value)
{
my $default = $DEFS{$item}->[2];   # $default;
my @available_keys = sort( grep( $DATA{$item}->{$_}, keys( %OTHER_OS)));
ENV_sig( W => "$item: No data for this OS ($osname)",
"Available for OS: (@available_keys)",
"Assume: $default");
$value = $default;
$DATA{$item}->{$osname} = $value;
$FILE_CHANGED = 1;
}

return $value;
}





sub put_item($$)
{
my ($item,
$value,	    # or $values_ref
) = @_;

if ($DATA{$item} ne $value)
{
$DATA{$item} = $value;
$FILE_CHANGED = 1;
}
}






sub put_os_item($$$)
{
my ($osname,    # Note that osname must already be present as scms!
$item,
$value,	    # or $values_ref
) = @_;

ENV_sig( E => "Invalid OSname '$osname' in name '$item'")
if (!exists $DATA{scms}->{$osname});

if (ref $value)
{
$value = [ sort( { $a->[0] cmp $b->[0] } @{$value}) ];
}

if ($DATA{$item}->{$osname} ne $value)
{
$DATA{$item}->{$osname} = $value;
$FILE_CHANGED = 1;
}
}





sub write_file()
{
my @lines;
push @lines, '#';
push @lines, '#   SYSTEM.GBS';
push @lines, '#';

foreach my $item (@ITEMS)
{
my ($is_os_item, $is_ref_list, $default) = @{$DEFS{$item}};
if ($is_os_item)
{
while (my ($os, $value) = each %{$DATA{$item}})
{
my $value = $DATA{$item}->{$os};
$value = $default
if (!defined $value);
if ($is_ref_list)
{
push @lines, map { "$item-$os=" . join( ',', @{$_}) } @{$value};
} else
{
push @lines, "$item-$os=$value";
}
}
} else
{
my $value = $DATA{$item};
if ($is_ref_list)
{
push @lines, map { "$item=" . join( ',', @{$_}) } @{$value};
} else
{
push @lines, "$item=$value";
}
}
}

push @lines, '###EOF###';


ENV_backup_file( $CURRENT_FILE, '.sav', 'E')
if (-e $CURRENT_FILE);
SCM_store_file( $CURRENT_FILE, \@lines);

$FILE_CHANGED = 0;
}




sub general_init()
{
%DATA = ();
%OTHER_OS = ();

foreach my $item (@ITEMS)
{
my ($is_os_item, $is_ref_list, $default, $empty_ok) = @{$DEFS{$item}};

if ($is_os_item)
{
$DATA{$item}->{$CUR_OS} = ENV_clone( $default);
} else
{
$DATA{$item} = ENV_clone( $default);
}
}

}




sub check_value($$$$)
{
my ($item,
$default,
$check,
$value,
) = @_;

my $old_value = $value;
if (ref $check eq 'ARRAY')
{
if (!grep( $value eq $_, @{$check}))
{
if (grep (lc $value eq lc $_, @{$check}))
{
$value = lc $value;
} else
{
$value = $default;
}
GBSFILE_sig( W => "Invalid value: $old_value",
"Possible value(s): (@{$check})",
"Assumed: $value");
}
} elsif (ref $check eq 'Regexp')
{
if ($value !~ $check)
{
$value = $default;
GBSFILE_sig( W => "Invalid format value: $old_value",
"Regexp: $check",
"Assumed: $value");
}
} else
{
ENV_sig( F => 'Impossible else. $check=' . ref $check);
}
}

1;
