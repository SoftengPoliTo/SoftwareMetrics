#=================================================
#
#   bash.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================




package glo::bash;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
BASH_parse
BASH_get_login_spec
BASH_get_envvar_names
BASH_get_envvar
BASH_get_alias_names
BASH_get_alias
BASH_replace_lines
BASH_add_aliases
BASH_remove_aliases
BASH_cleanup
);
}




use glo::env;
use glo::slurp;
use glo::spit;




sub BASH_parse($);
sub BASH_get_login_spec();
sub BASH_get_envvar_names($);
sub BASH_get_envvar($);
sub BASH_get_alias_names();
sub BASH_get_alias($);

sub BASH_replace_lines($$$$);
sub BASH_add_aliases($$$@);
sub BASH_remove_aliases($$$@);
sub BASH_cleanup();

sub read_login_and_parse();
sub parse_file($$);
sub parse_line($);
sub open_env_file($$);
sub replace_env_file_lines($$);
sub write_env_file();







my $HOME = ENV_getenv( 'HOME' );

my @LOGIN_NAMES = qw( .bash_profile .bash_login .profile );  # Is also search order

my $BASHRC_SPEC = "$HOME/.bashrc";
my $BASH_ALIASES_SPEC = "$HOME/.bash_aliases";




my $SIG_ON_ERROR;	# '', 'F', 'EE', etc
my $CUR_LOGIN_NAME;	# (e.g.: .bash_profile)
my $CUR_LOGIN_SPEC;	# Do Not Initialize!

my %FILESPEC_REFS;

my @FILESPEC_REFS;


my %ENV_VARS;


my %ALIASES;





my $CUR_ENV_FILESPEC = '';
my $APP_NAME;			# e.g: 'GBS'
my @ENV_LINES;
my $ENV_LINES_MODIFIED;




sub BASH_parse($)
{
($SIG_ON_ERROR,	# undef, '', 'F', 'EE', etc
) = @_;


read_login_and_parse();

return $CUR_LOGIN_SPEC; # .bash_profile .bash_login .profile
}




sub BASH_get_login_spec()
{
return $CUR_LOGIN_SPEC;
}





sub BASH_get_envvar_names($)
{
my ($is_export,	    # undef = all
) = @_;
my @envvar_names;

ENV_sig( F => 'Bash files not parsed')
if (! defined $CUR_LOGIN_SPEC);

if (defined $is_export)
{
map { push @envvar_names, $_->[0] if ($_->[2] == $is_export) } values %ENV_VARS;    # [0]=$name, [2]=$is_export
} else
{
@envvar_names = keys %ENV_VARS;
}

return @envvar_names;
}




sub BASH_get_envvar($)
{
my ($envvar_name,
) = @_;
my ($value, $is_export, $is_login, $filespec, $line_nr);

ENV_sig( F => 'Bash files not parsed')
if (! defined $CUR_LOGIN_SPEC);

my $envvar_ref = $ENV_VARS{$envvar_name};
if (defined $envvar_ref)
{
(undef, $value, $is_export, $is_login, my $filespec_ref, $line_nr) = @{$envvar_ref};
($filespec, $is_login) = @{$filespec_ref};
}

return (wantarray) ? ($value, $is_export, $is_login, $filespec, $line_nr) : $value;
}





sub BASH_get_alias_names()
{


ENV_sig( F => 'Bash files not parsed')
if (! defined $CUR_LOGIN_SPEC);

return keys %ALIASES;
}




sub BASH_get_alias($)
{
my ($alias_name,
) = @_;
my ($value, $filespec, $is_login, $line_nr);

ENV_sig( F => 'Bash files not parsed')
if (! defined $CUR_LOGIN_SPEC);

my $alias_ref = $ALIASES{$alias_name};
if (defined $alias_ref)
{
(undef, $value, my $filespec_ref, $line_nr) = @{$alias_ref};
($filespec, $is_login) = @{$filespec_ref};
}

return (wantarray) ? ($value, $filespec, $is_login, $line_nr) : $value;
}




sub read_login_and_parse()
{



foreach my $name (@LOGIN_NAMES)	# .bash_profile .bash_login .profile
{
my $spec = "$HOME/$name";
if (-f $spec)
{
$CUR_LOGIN_NAME = $name;
$CUR_LOGIN_SPEC = $spec;

last;
}
}
ENV_sig( $SIG_ON_ERROR => "No Bash login script found (@LOGIN_NAMES)")
if (!defined $CUR_LOGIN_NAME);




parse_file( $CUR_LOGIN_SPEC, 1);	    # $is_login




foreach my $env (qw( BASH_ENV ENV))
{
my $env_filespec = ENV_expand_envs( ENV_getenv_perl_path( $env));
if ($env_filespec ne '')
{
if (-f $env_filespec && ! exists $FILESPEC_REFS{$env_filespec})
{
parse_file( $env_filespec, 0);	# !login-file
}
}
}
}




sub parse_file($$)
{
my ($filespec,	    # bash file
$is_login,
) = @_;

ENV_whisper( 1, "BASH: parse_file: $filespec");

my $filespec_ref = [ $filespec, $is_login, ENV_split_spec_n( $filespec) ];
$FILESPEC_REFS{$filespec} = $filespec_ref;
push @FILESPEC_REFS, $filespec_ref;

my $line_nr = 0;
foreach my $line (SLURP_file( $filespec))
{
$line_nr++;
next
if ($line eq '' ||			# skip empty lines
$line =~ /(^\s*$)|(^\s*#)/);	# skip lines with whitespace only or comment lines
$line =~ s/\s+$//;			# remove trailing whitespace





my @tokens = parse_line( $line);
while (@tokens)
{
my $token = shift @tokens;
if ($token =~ /^(\.|\\?source)$/)
{



my $new_file_spec = ENV_expand_envs( shift @tokens);	    # include ~/
if (-f $new_file_spec)
{
if ($new_file_spec !~ m!^/etc/! && !exists $FILESPEC_REFS{$new_file_spec})
{
my $new_is_login = $is_login;
if ($new_file_spec =~ m!/.bashrc$! ||
$new_file_spec eq ENV_getenv_perl_path( 'BASH_ENV'))
{
$new_is_login = 0;
}
parse_file( $new_file_spec, $new_is_login)
} else
{
ENV_whisper( 1, "source'd file '$new_file_spec' skipped (starts with '/etc')");
}
} else
{
ENV_whisper( 1, "source'd file '$new_file_spec' does not exist");
}
} elsif ($token =~ /^(\\?export|\\?let|(\w+)=(.*))$/)
{



my ($command, $name, $value) = ($1, $2, $3);
my @names;
if (defined $name)
{
$command = 'implicit';
} else
{
$command =~ s/^\\//;	    # let or export
my $assignment_or_value = shift @tokens;
($name, $value) = split( '=', $assignment_or_value, 2);
if (!defined $value)
{
@names = ($name);
while (@tokens && $tokens[0] ne ';')
{
push @names, shift @tokens;
}
}
}
if (@names)
{
my $is_export = 1;
foreach my $name (@names)
{
my $envvar_ref = $ENV_VARS{$name};
if (defined $envvar_ref)
{
$envvar_ref->[2] = $is_export;
} else
{
$ENV_VARS{$name} = [ $name, '<unkown>', $is_export, $is_login, $filespec_ref, $line_nr ];
}
}

} else
{
my $is_export = ($command eq 'export') ? 1 : 0;
my $envvar_ref = $ENV_VARS{$name};
if (defined $envvar_ref)
{
$envvar_ref->[1] = $value;
$envvar_ref->[2] = 1
if ($is_export);
} else
{
$ENV_VARS{$name} = [ $name, $value, $is_export, $is_login, $filespec_ref, $line_nr ];
}

}
} elsif ($token =~ /^\\?alias$/)
{



my $assignment = shift @tokens;
my ($name, $value) = split( '=', $assignment, 2);

$ALIASES{$name} = [ $name, $value, $filespec_ref, $line_nr ];
} else
{



while (@tokens && $tokens[0] ne ';')
{
shift @tokens;
}
}
}
}
}




sub parse_line($)
{
my ($line,
) = @_;
my @tokens;

if ($line =~ /['"]/)
{
$line =~ s/^\s+//;
my $word;
while (length($line)) {



$line =~ s/^
(?:

(")                             # $quote
((?>[^\\"]*(?:\\.[^\\"]*)*))"   # $quoted
|	# --OR--

(')                             # $quote
((?>[^\\']*(?:\\.[^\\']*)*))'   # $quoted
|   # --OR--

(                               # $unquoted
(?:\\.|[^\\"'])*?
)

(                               # $delim
\Z(?!\n)                    # EOL   ## noperlxref
|   # --OR--
(?-x:\s+)		    # delimiter
|   # --OR--
(?!^)(?=["'])               # a quote
)
)//xs or return;		# extended layout
my ($quote, $quoted, $unquoted, $delim) = (($1 ? ($1,$2) : ($3,$4)), $5, $6);


return() unless( defined($quote) || length($unquoted) || length($delim));

$unquoted =~ s/\\(.)/$1/sg
if (defined $unquoted);
$quoted =~ s/\\(.)/$1/sg
if (defined $quote && $quote eq '"');
$word .= substr( $line, 0, 0);	# leave results tainted
$word .= defined $quote ? $quoted : $unquoted;

if (length( $delim) || !length( $line ))
{
if (defined $quote)
{
push @tokens, $word;
undef $word;
} else
{
my $hash_loc = index( $word, '#');
if ($hash_loc >= 0)
{
$word = substr( $word, 0, $hash_loc);
}
if ($word ne '')
{
my @snippets = split /(;)/, $word;
push @tokens, @snippets;
undef $word;
}
last
if ($hash_loc >= 0);
}
}
}
} else
{
my @parts = split ' ', $line;
foreach my $part (@parts)
{
my $hash_loc = index( $part, '#');
if ($hash_loc >= 0)
{
$part = substr( $part, 0, $hash_loc);
}
if ($part ne '')
{
my @snippets = split /(;)/, $part;
push @tokens, @snippets;
}
last
if ($hash_loc >= 0);
}
}


return @tokens;
}






sub BASH_replace_lines($$$$)
{
my ($env_filespec,	    # May be undef
$must_write,	    # bool
$app_name,	    # E.g.: 'GBS'
$lines_ref,	    # [ @lines ]
) = @_;

if (defined $env_filespec)
{



open_env_file( $env_filespec, $app_name);

replace_env_file_lines( $app_name, $lines_ref);

write_env_file()
if ($must_write);
}
}




sub BASH_add_aliases($$$@)
{
my ($env_filespec,	    # May be undef
$must_write,	    # bool
$app_name,	    # E.g.: 'GBS'
@alias_refs,	    # ( [ $alias => $command ]
) = @_;

if (!defined $env_filespec)
{
if ($CUR_ENV_FILESPEC ne '')
{
$env_filespec = $CUR_ENV_FILESPEC;
} else
{



read_login_and_parse()
if (@FILESPEC_REFS == 0);





if (exists $FILESPEC_REFS{$BASH_ALIASES_SPEC})
{
$env_filespec = $BASH_ALIASES_SPEC;
} elsif (exists $FILESPEC_REFS{$BASHRC_SPEC})
{
$env_filespec = $BASHRC_SPEC;
} else
{
($env_filespec) = grep( $_->[1] == 0, @FILESPEC_REFS);
ENV_sig( $SIG_ON_ERROR => 'No ENV file defined in executed login-files:', "(@FILESPEC_REFS)")
if (!defined $env_filespec);
}
ENV_whisper( 2, "- Selected: $env_filespec");
}
}

if (defined $env_filespec)
{



open_env_file( $env_filespec, $app_name);




my @alias_lines;
my $alias_search_re;
{
my @aliases;
foreach my $ref (@alias_refs)
{
my ($alias, $command) = @{$ref};
push @alias_lines, "\\alias $alias='$command'";
push @aliases, $alias;
}
my $aliases = join( '|', @aliases);
$alias_search_re = qr((^|\s+)\\?alias\s+($aliases)=);
}




{
my $alias_count = 0;
foreach my $line (@ENV_LINES)
{
if ($line =~ /$alias_search_re/)
{
$line = undef;
$alias_count++;
}
}

if ($alias_count > 0)
{
@ENV_LINES = grep( defined $_, @ENV_LINES);
$ENV_LINES_MODIFIED = 1;
}
}




replace_env_file_lines( "$app_name aliases", \@alias_lines);

write_env_file()
if ($must_write);
}
}




sub BASH_remove_aliases($$$@)
{
my ($env_filespec,	    # May not be undef
$must_write,	    # bool
$app_name,	    # Lower case! (E.g.: 'gbs')	if ! undef: also remove heading
@alias_refs,	    # ( [ $alias => $command ]
) = @_;
my $removed_count = 0;

if (defined $env_filespec)
{
ENV_whisper( 1, "Removing aliases from $env_filespec");




open_env_file( $env_filespec, $app_name);




my $alias_search_re;
{
my @aliases;
foreach my $ref (@alias_refs)
{
my ($alias, $command) = @{$ref};
push @aliases, $alias;
}
my $aliases = join( '|', @aliases);
$alias_search_re = qr((^|\s+)\\?alias\s+($aliases)=);
}




{
foreach my $line (@ENV_LINES)
{
if ($line =~ /$alias_search_re/)
{
ENV_whisper( 2, $line);
$line = undef;
$removed_count++;
}
}

if ($removed_count > 0)
{
@ENV_LINES = grep( defined $_, @ENV_LINES);
$ENV_LINES_MODIFIED = 1;
}
}




if (defined $app_name)
{
replace_env_file_lines( "$app_name aliases", undef);
}

write_env_file()
if ($must_write);
} else
{
ENV_sig( F => "'\$env_filespec' not defined!");
}

return $removed_count;
}




sub open_env_file($$)
{
my ($env_filespec,	    # May not be undef
$app_name,	    # (E.g.: 'GBS')
) = @_;

if ($CUR_ENV_FILESPEC ne $env_filespec)
{
if ($CUR_ENV_FILESPEC ne '')
{
write_env_file();
undef @ENV_LINES;
}
@ENV_LINES = SLURP_file( $env_filespec);
$CUR_ENV_FILESPEC = $env_filespec;
$APP_NAME = $app_name;
$ENV_LINES_MODIFIED = 0;
}
}





sub replace_env_file_lines($$)
{
my ($heading,
$lines_ref,	# undef == remove all
) = @_;

my @insert;
if (defined $lines_ref)
{
@insert = ('#',
"#   $heading - Automated insert. Do not modify this and the lines below",
'#',
@{$lines_ref},
'#',
"#   END $heading - Automated insert. Do not modify this and the lines above",
);
}




my $heading_re = quotemeta( $heading);
my $start_index;
my $end_index;
for (my $i = 0; $i < @ENV_LINES; $i++)
{
if ($ENV_LINES[$i] =~ /^#\s+$heading_re(\s+|$)/i)
{
$start_index = $i;
last;
}
}
if (defined $start_index)
{




$start_index--;
for (my $i = $start_index + 3;  $i < @ENV_LINES; $i++)
{
$end_index = $i - 1
if (!defined $end_index && $ENV_LINES[$i] =~ /^(#|\s*$)/);
if ($ENV_LINES[$i] =~ /^#\s+END\s+$heading_re(\s+|$)/i)
{
$end_index = $i;
last;
}
}

my $count = $end_index - $start_index + 1;

my $replace = "@ENV_LINES[$start_index..$end_index]";

if ("@insert" ne $replace)
{

splice( @ENV_LINES, $start_index, $count, @insert); # remove lines and replace by @insert
$ENV_LINES_MODIFIED = 1;
}
} else
{



if (defined $lines_ref)
{
$start_index = $#ENV_LINES;
$start_index--
if ($ENV_LINES[$start_index] eq '');
if ($ENV_LINES[$start_index] =~ /^#.*EOF/)
{
splice( @ENV_LINES, $start_index, 0, (@insert, ''));
} else
{
push @ENV_LINES, (@insert, '');
}
$ENV_LINES_MODIFIED = 1;
}
}
}




sub write_env_file()
{
if ($ENV_LINES_MODIFIED)
{
if (-f $CUR_ENV_FILESPEC)
{
my $lc_app_name = lc $APP_NAME;
my $backup_filespec = ENV_backup_file( $CUR_ENV_FILESPEC, ".${lc_app_name}_saved", 'F');
ENV_whisper( 1, "- Saved $CUR_ENV_FILESPEC to $backup_filespec");
}

ENV_say( 1, "- Writing $CUR_ENV_FILESPEC...");
my $writable = (-w $CUR_ENV_FILESPEC);
ENV_chmod( 'u+w', $CUR_ENV_FILESPEC)
if (!$writable);

SPIT_file_nl( $CUR_ENV_FILESPEC, \@ENV_LINES);
ENV_chmod( 'u-w', $CUR_ENV_FILESPEC)
if (!$writable);
}
}




sub BASH_cleanup()
{
undef $SIG_ON_ERROR;
undef $CUR_LOGIN_NAME;
undef $CUR_LOGIN_SPEC;
undef %FILESPEC_REFS;
undef @FILESPEC_REFS;
undef %ENV_VARS;
undef %ALIASES;

$CUR_ENV_FILESPEC = '';
undef $APP_NAME;
undef @ENV_LINES;
undef $ENV_LINES_MODIFIED;
}

1;

