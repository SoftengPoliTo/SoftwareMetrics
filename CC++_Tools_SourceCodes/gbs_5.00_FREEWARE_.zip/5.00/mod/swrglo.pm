#=================================================
#
#   swrglo.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::swrglo;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SWRGLO_validate
);
}




use glo::env;
use glo::version;
use mod::gbsrc;
use mod::system;
use mod::roots;
use mod::gbsglo;
use mod::gbscheck;




sub SWRGLO_validate($$$$$$);




my $CWD = ENV_cwd();





sub SWRGLO_validate($$$$$$)
{
my ($root_path,	    # '', '-', '.', '!!', '!<os_spec>', <number>, <perl_path_nospace>
$build,		    # '', '-', '.', <build>
$subsys,	    # '', '-', '.', <subsys>
$component,	    # '', '-', '.', <component>
$audit,		    # '', '-', '.', <audit>
$tool,		    # '', '-', '.', <tool>
) = @_;
my ($new_root_path, $new_build, $new_subsys, $new_component, $new_audit, $new_tool);




















{

if ($root_path eq '-')
{
$new_root_path = '';
} else
{



my $this_root_path;
if (substr( $root_path, 0, 1) eq '!')
{
if ($root_path eq '!!')
{
$this_root_path = $CWD;
} else
{
my $this_path = ($root_path eq '!') ? $CWD : substr( $root_path, 1);
($this_root_path, my $found_subsys, my $found_component) = GBSGLO_split_gbs_spec( $this_path);
if ($this_root_path ne '')
{
if ($found_subsys ne '')
{
$subsys = $found_subsys
if ($subsys eq '.' || $subsys eq '');
if ($found_component ne '')
{
$component = $found_component
if ($component eq '.' || $component eq '');
} else
{
$component = '-';
}
} else
{
$subsys = '-';
$component = '-';
}
ENV_whisper( 1, "Found: $this_root_path / $found_subsys / $found_component");
} else
{
ENV_sig( EE => "No GBS-Root found in '$this_path'");
}
}
} else	# $root_path eq '', '.', <number> or <spec>
{
$this_root_path = $root_path;
}

if ($this_root_path ne '')
{



if ($this_root_path !~ /^(\.|\d+)$/)	# Not a '.' or number
{
$this_root_path = ENV_perl_paths_noquotes( $this_root_path);
ENV_sig( EE => "Root '$this_root_path' is not a valid GBS Root")
if (!-e "$this_root_path/system.gbs");
}
my $default_root_path = GBSRC_get_base( 'root');
my @all_roots = ROOTS_get_all();
$new_root_path = GBSCHECK_root( $this_root_path, $default_root_path, \@all_roots);




if ($new_root_path ne '')
{
my $version_start = SYSTEM_get( $new_root_path, 'version_start');
my $version_end = SYSTEM_get( $new_root_path, 'version_end');

if ($GBS::FULL_VERSION < $version_start ||
($version_end && $GBS::FULL_VERSION > $version_end))
{
my $build_now_print = VERSION_full_version_2_version( $GBS::FULL_VERSION);
my $version_start_print = VERSION_full_version_2_version( $version_start);
my $version_end_print = VERSION_full_version_2_version( $version_end);
if ($GBS::FULL_VERSION < $version_start)
{
ENV_sig( EE => "Current GBS version: $build_now_print ($GBS::FULL_VERSION) too old.",
"Need at least GBS version $version_start_print ($version_start).",
"Range: [$version_start-$version_end]");

} else
{
ENV_sig( EE => "Current GBS version: $build_now_print ($GBS::FULL_VERSION) too new.",
"Need latest GBS version $version_end_print ($version_end).",
"Range: [$version_start-$version_end]");
}
$new_root_path = '';
}
}

if ($new_root_path ne '')
{



if (! ROOTS_exists( $new_root_path))
{
ENV_sig( W => "'$new_root_path' is not listed in Roots List",
"Use 'swr --add' to add the Root to the Roots List",
"Continuing anyway...");
}
}
}
}

if ($new_root_path eq '')
{
$subsys = '-';
$component = '-';
$build = '-';
$audit = '-';
$tool = '-';
} else
{
my $new_gbs_root_version = SYSTEM_get( $new_root_path, 'root_version');
if ($new_gbs_root_version lt $GBS::VERSION)
{
ENV_sig( W => "GBS ROOT-VERSION ($new_gbs_root_version) mismatch ($GBS::VERSION)",
"Please run gbsmaint 7 9 (Upgrade)",
"Currencies are reset");
$subsys = '-';
$component = '-';
$build = '-';
$audit = '-';
$tool = '-';
}
}
}









{

if ($subsys eq '-')
{
$new_subsys = '';
$component = '-';
} else # $subsys eq '', '.' or <name>
{
my $default_subsys = GBSRC_get_root( $new_root_path, 'subsys');
$new_subsys = GBSCHECK_subsys( $new_root_path, $subsys, $default_subsys);
$component = '-'
if ($new_subsys eq '');
}
}









{

if ($component eq '-')
{
$new_component = '';
} else # $component eq '', '.' or <name>
{
if (GBSGLO_subsystem_is_full_gbs( $new_subsys, $new_root_path))
{
my $default_component = GBSRC_get_subsys( $new_root_path, $new_subsys, 'component');
$new_component = GBSCHECK_component( $new_root_path, $new_subsys, $component, $default_component);
} else
{
if ($component eq '')
{
$new_component = '';
} else
{
ENV_sig( EE => "Cannot specify a component ($component) for Non GBS SubSystem");
}
}
}
}









{

if ($build eq '-')
{
$new_build = '';
} else # $build eq '.' or <name>
{
my $default_build = GBSRC_get_root( $new_root_path, 'build');
my $defaults_ref = [ $default_build ];
my @builds = map { $_->[0] } SYSTEM_get_os_refs( $new_root_path, '.', 'builds');   # [ $build, $plugin ]
$new_build = GBSCHECK_build( $new_root_path, $new_subsys, $new_component, $build, $defaults_ref, \@builds);
}
}





$new_audit = '';
if ($build ne '-')
{

if ($audit ne '-')	# $audit eq '.' or <name>
{
my @audits = map { $_->[0] } SYSTEM_get_os_refs( $new_root_path, '.', 'audits');   # [ $audit, $plugin ]
if (@audits)
{
my $default_audit = GBSRC_get_root( $new_root_path, 'audit');
my $defaults_ref = [ $default_audit ];
$new_audit = GBSCHECK_audit( $new_root_path, $new_subsys, $new_component,
$new_build, $audit, $defaults_ref, \@audits);
}
}
}




{

$new_tool = '';
if ($tool ne '-')	# $tool eq '.' or <name>
{
my @tools = map { $_->[0] } SYSTEM_get_os_refs( $new_root_path, '.', 'tools');   # [ $tool, $plugin ]
if (@tools)
{
my $default_tool = GBSRC_get_root( $new_root_path, 'tool');
$new_tool = GBSCHECK_tool( $new_root_path, $new_subsys, $new_component, $tool, $default_tool, \@tools);
}
}
}










return ($new_root_path, $new_build, $new_subsys, $new_component, $new_audit, $new_tool);
}

1;


