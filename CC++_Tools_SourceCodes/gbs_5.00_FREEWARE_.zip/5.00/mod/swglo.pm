#=================================================
#
#   swglo.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::swglo;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SWGLO_set_all_platforms
SWGLO_validate_subsys
SWGLO_validate_component
SWGLO_validate_build
SWGLO_validate_audit
SWGLO_validate_tool

SWGLO_new_cwd
SWGLO_set_title
);
}




use glo::env;
use mod::gbsenv;
use mod::gbsrc;
use mod::gbsglo;
use mod::gbscmd;
use mod::gbscheck;




sub SWGLO_set_all_platforms($);
sub SWGLO_validate_subsys($);
sub SWGLO_validate_component($$);
sub SWGLO_validate_build($$$);
sub SWGLO_validate_audit($$$$);
sub SWGLO_validate_tool($$);
sub SWGLO_new_cwd($$$);
sub SWGLO_set_title(@);




my $VALIDATE_ALL_PLATFORMS = 0;		# ALL only for gbsxref





sub SWGLO_set_all_platforms($)
{
my ($must_set,
) = @_;
my $was_set = $VALIDATE_ALL_PLATFORMS;

$VALIDATE_ALL_PLATFORMS = $must_set;

return $was_set;
}




sub SWGLO_validate_subsys($)
{
my ($subsys,	    # '', '-', number or value
) = @_;
my $new_subsys = '';

if ($subsys eq '-')
{
$new_subsys = '';
} else # $subsys eq '', '.' or <name>
{
my $default_subsys = $GBS::SUBSYS;
$default_subsys = GBSRC_get_root( $GBS::ROOT_PATH, 'subsys')
if ($default_subsys eq '');
$new_subsys = GBSCHECK_subsys( $GBS::ROOT_PATH, $subsys, $default_subsys);
}

return $new_subsys;
}




sub SWGLO_validate_component($$)
{
my ($subsys,
$component,	    # '', '-', number or value
) = @_;
my $new_component = '';

if ($component eq '-')
{
$new_component = '';
} else # $component eq '', '.' or <name>
{
if (GBSGLO_subsystem_is_full_gbs( $subsys))
{
my $default_component = GBSRC_get_subsys( $GBS::ROOT_PATH, $subsys, 'component');
$new_component = GBSCHECK_component( $GBS::ROOT_PATH, $subsys, $component, $default_component);
} else
{
if ($component eq '')
{
$new_component = '';
} else
{
ENV_sig( EE => "Cannot specify a component ($component) for Non GBS SubSystem");
}
}
}

return $new_component;
}




sub SWGLO_validate_build($$$)
{
my ($subsys,
$component,
$build,	    # '', '-', number or value
) = @_;
my $new_build = '';

if ($build eq '-')
{
$new_build = '';
} else # $build eq '.' or <name>
{
my $root_build = GBSRC_get_root( $GBS::ROOT_PATH, 'build');
my $subsys_build = ($subsys eq '') ? '' : GBSRC_get_subsys( $GBS::ROOT_PATH, $subsys, 'build');
my $default_build = ($GBS::BUILD eq '') ? $root_build : $GBS::BUILD;
my @gbsrc_builds;
push @gbsrc_builds, $subsys_build
if ($subsys_build ne '' && $subsys_build ne $default_build);
push @gbsrc_builds, $root_build
if ($root_build ne '' && $root_build ne $default_build && $root_build ne $subsys_build);
my $defaults_ref = [ $default_build, @gbsrc_builds ];
my $builds_ref = ($VALIDATE_ALL_PLATFORMS) ? \@GBS::ALL_BUILDS : \@GBS::BUILDS;	# ALL only for gbsxref
$new_build = GBSCHECK_build( $GBS::ROOT_PATH, $subsys, $component, $build, $defaults_ref, $builds_ref);
}

return $new_build;
}




sub SWGLO_validate_audit($$$$)
{
my ($subsys,
$component,
$build,
$audit,	    # '', '-', number or value
) = @_;
my $new_audit = '';

if ($audit eq '-')
{
$new_audit = '';
} else # $audit eq '.' or <name>
{
my $root_audit = GBSRC_get_root( $GBS::ROOT_PATH, 'audit');
my $subsys_audit = ($subsys eq '') ? '' : GBSRC_get_subsys( $GBS::ROOT_PATH, $subsys, 'audit');
my $default_audit = ($GBS::AUDIT eq '') ? $root_audit : $GBS::AUDIT;
my @gbsrc_audits;
push @gbsrc_audits, $subsys_audit
if ($subsys_audit ne '' && $subsys_audit ne $default_audit);
push @gbsrc_audits, $root_audit
if ($root_audit ne '' && $root_audit ne $default_audit && $root_audit ne $subsys_audit);
my $defaults_ref = [ $default_audit, @gbsrc_audits ];
my $audits_ref = ($VALIDATE_ALL_PLATFORMS) ? \@GBS::ALL_AUDITS : \@GBS::AUDITS;	# ALL only for gbsxref
$new_audit = GBSCHECK_audit( $GBS::ROOT_PATH, $subsys, $component, $build, $audit, $defaults_ref, $audits_ref);
}

return $new_audit;
}




sub SWGLO_validate_tool($$)
{
my ($subsys,
$tool,	    # '', '-', number or value
) = @_;
my $new_tool = '';

if ($tool eq '-')
{
$new_tool = '';
} else # $tool eq '.' or <name>
{
my $root_tool = GBSRC_get_root( $GBS::ROOT_PATH, 'tool');
my $default_tool = ($GBS::TOOL eq '') ? $root_tool : $GBS::TOOL;
my $tools_ref = ($VALIDATE_ALL_PLATFORMS) ? \@GBS::ALL_TOOLS : \@GBS::TOOLS;	# ALL only for gbsxref
$new_tool = GBSCHECK_tool( $GBS::ROOT_PATH, undef, undef, $tool, $default_tool, $tools_ref);
}

return $new_tool;
}




sub SWGLO_new_cwd($$$)
{
my ($root_path,
$subsys,
$component,
) = @_;
my $new_cwd;

if ($component ne '')
{
$new_cwd = "$root_path/dev/$subsys/comp/$component/src";
} elsif ($subsys ne '')
{
$new_cwd = "$root_path/dev/$subsys";
} elsif ($root_path ne '')
{
$new_cwd = $root_path;
} else  # $root_path eq ''
{





my $cwd = ENV_cwd();
if ($GBS::ROOT_PATH ne '' &&
substr( $cwd, 0, length($GBS::ROOT_PATH)) . '/' eq $GBS::ROOT_PATH . '/')
{
$new_cwd = ENV_parent_path( $GBS::ROOT_PATH);
ENV_say( 1, "Setting CWD to $new_cwd...");
} else
{
$new_cwd = $cwd;
}
}

return $new_cwd;
}





sub SWGLO_set_title(@)
{
my @text = @_;  # $root_path, $subsys, $component
my @lines;

if (!GBSENV_mode_is_background())	    # INTERACTIVE or FOREGROUND
{
if (@text == 1 && $text[0] eq '-')
{
push @lines, GBSCMD_set_xtitle( '');
} else
{
my @text = reverse @text;
my $text = (@text) ? join ( ' - ', @text) : '-';
push @lines, GBSCMD_set_xtitle( "GBS: $text");
}
}

return @lines;
}

1;


