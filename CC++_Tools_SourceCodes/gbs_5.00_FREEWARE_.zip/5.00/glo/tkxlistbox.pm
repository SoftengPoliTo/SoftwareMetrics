#=================================================
#
#   tkxlistbox.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::tkxlistbox;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
TKXLISTBOX_new
TKXLISTBOX_clear
TKXLISTBOX_say
TKXLISTBOX_width
TKXLISTBOX_get_selection
TKXLISTBOX_get_selection_indices
);
}




use Tkx;


use glo::tkx;
use glo::tkxevent;




sub TKXLISTBOX_new($$@);
sub TKXLISTBOX_clear($);
sub TKXLISTBOX_say($$$$);
sub TKXLISTBOX_width($);
sub TKXLISTBOX_get_selection($);
sub TKXLISTBOX_get_selection_indices($);








my %SIG_COLORS = (

W	=> 'Green',
E	=> 'Red',
F	=> 'Red',
);








sub TKXLISTBOX_new($$@)
{
my ($parent,
$select_callback,
@listbox_args
) = @_;
my ($lbf, $lb);	    # listbox_frame, listbox

$lbf = $parent->new_ttk__frame( -relief => 'groove', -borderwidth => 3);
$lbf->g_grid_columnconfigure( 0, -weight => 1);
$lbf->g_grid_rowconfigure( 0, -weight => 1);

$lb = $lbf->new_tk__listbox( @listbox_args);
$lb->g_grid( -column => 0, -row => 0, -sticky => 'news');

my $vs = $lbf->new_ttk__scrollbar( -orient => 'vertical', -command => [ $lb, 'yview']);
$vs->g_grid( -column => 1, -row => 0, -sticky => 'ns');
$lb->configure( -yscrollcommand => [ $vs, 'set' ]);

my $hs = $lbf->new_ttk__scrollbar( -orient => 'horizontal', -command => [ $lb, 'xview']);
$hs->g_grid( -column => 0, -row => 1, -sticky => 'we');
$lb->configure( -xscrollcommand => [ $hs, 'set' ]);

TKXEVENT_bind_listbox_select( $lb, $select_callback)
if (defined $select_callback);

return ($lbf, $lb);
}




sub TKXLISTBOX_clear($)
{
my ($widget,
) = @_;

$widget->delete( 0, 'end');
}





sub TKXLISTBOX_width($)
{
my ($widget,
) = @_;
my $width;

$width = $widget->cget( '-width');


return $width;
}




sub TKXLISTBOX_say($$$$)
{
my ($widget,
$nr_lines_to_keep,	# buffer_size. May be zero (no limit)
$text_type,		# colour
$line_or_ref,
) = @_;




my $nr_lines;
if (ref $line_or_ref)
{
foreach my $line (@{$line_or_ref})
{
$line =~ s/\s+$//;	# Remove trailing whitespace
}
$widget->insert_end( @{$line_or_ref});
$nr_lines = @{$line_or_ref};
} else
{
$line_or_ref =~ s/\s+$//;
$widget->insert_end( $line_or_ref);
$nr_lines = 1;
}

if (defined $text_type)
{
my $color = $SIG_COLORS{$text_type};
if (defined $color)
{
my $last_index = $widget->index( 'end') - 1;
my $first_index = $last_index - $nr_lines + 1;
foreach my $i ($first_index..$last_index)
{
$widget->itemconfigure( $i, -foreground => $color)
}
TKX_bell();
}
}




if ($nr_lines_to_keep != 0)
{
my $nr_current_lines = $widget->index( 'end');
if ($nr_current_lines > $nr_lines_to_keep)
{
$widget->delete( 0, $nr_current_lines - $nr_lines_to_keep);
}
}




$widget->see( 'end');
TKX_update();
}




sub TKXLISTBOX_get_selection($)
{
my ($widget,
) = @_;
my @selection;

@selection = map { $widget->get( $_) } TKXLISTBOX_get_selection_indices( $widget);

return @selection;
}




sub TKXLISTBOX_get_selection_indices($)
{
my ($widget,
) = @_;
my @selection_indices;

my $selection_indices = $widget->curselection();
@selection_indices = Tkx::SplitList( $selection_indices);

return @selection_indices;
}

1;

