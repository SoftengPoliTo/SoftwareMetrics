#=================================================
#
#   gbsbgjob.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbsbgjob;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSBGJOB_banner
GBSBGJOB_echo
GBSBGJOB_set
GBSBGJOB_exec_short
GBSBGJOB_exec
GBSBGJOB_glkb
GBSBGJOB_sca
GBSBGJOB_scasum
GBSBGJOB_batch_init
GBSBGJOB_batch_run
GBSBGJOB_batch_queue
GBSBGJOB_batch_wait
GBSBGJOB_batch_finish
);
}




use glo::env;
use glo::struct;
use glo::spit;
use mod::gbsenv;
use mod::exec;
use mod::fail;




sub GBSBGJOB_banner(@);
sub GBSBGJOB_echo(@);
sub GBSBGJOB_set($$);
sub GBSBGJOB_exec_short($$$$);
sub GBSBGJOB_exec($$$$);
sub GBSBGJOB_glkb($$$$$);
sub GBSBGJOB_sca($$$$);
sub GBSBGJOB_scasum($$);
sub GBSBGJOB_batch_init($);
sub GBSBGJOB_batch_run($$$);
sub GBSBGJOB_batch_queue($$$);
sub GBSBGJOB_batch_wait();
sub GBSBGJOB_batch_finish();

sub set_batch_type($);








my %BATCH_PROGS = (

exec    => "$ENV{GBS_SCRIPTS_PATH}/gbsbgexec.pl",
sca	    => "$ENV{GBS_SCRIPTS_PATH}/gbsbgsca.pl",
scasum  => "$ENV{GBS_SCRIPTS_PATH}/gbsbgscasum.pl",
);




my $BATCH_TYPE;	    # exec, sca, scasum

my @QUEUED_FILES;




sub GBSBGJOB_banner(@)
{
my @lines = @_;

return [ BANNER => \@lines ];
}




sub GBSBGJOB_echo(@)
{
my (@lines) = @_;

return [ ECHO => \@lines ];
}




sub GBSBGJOB_set($$)
{
my ($name,
$value,
) = @_;


return [ SET => [ $name, $value ] ];
}




sub GBSBGJOB_exec_short($$$$)
{
my ($file,			# for failure logging purposes
$must_print_commands,	# undef = ok
$out_files_ref,		# undef = ok
$command_items_ref,
) = @_;

$must_print_commands = '-'
if (!defined $must_print_commands);

my $command_data_refs_ref;	# [ [ $command_type, $command_items_ref, $ok_values, $exec_condition, $pos_arg_tokens ], ... ]

my $command_type = 'S';
my @command = ENV_prepare_command( $command_items_ref);
$command_data_refs_ref = [ [ $command_type, \@command, 0, '-' ] ];

set_batch_type( 'exec');

return [ EXEC => [ $file, $must_print_commands, $out_files_ref, $command_data_refs_ref ] ];
}




sub GBSBGJOB_exec($$$$)
{
my ($file,			# for failure logging purposes
$must_print_commands,	# undef = ok
$out_files_ref,		# undef = ok
$command_data_refs_ref,	# [ [ $command_type, $command_items_ref, $ok_values, $exec_condition, $pos_arg_tokens ], ... ]

) = @_;


$must_print_commands = '-'
if (!defined $must_print_commands);

set_batch_type( 'exec');

return [ EXEC => [ $file, $must_print_commands, $out_files_ref, $command_data_refs_ref ] ];
}




sub GBSBGJOB_glkb($$$$$)
{
my ($file,			# for failure logging purposes
$must_print_commands,	# undef = OK
$glkb_args_ref,		# [ $gen_type, $glkb_type, $glkb_file, $out_filespec ]
$out_files_ref,		# undef = OK
$command_data_refs_ref,	# [ [ $command_type, $command_items_ref, $ok_values, $exec_condition, $pos_arg_tokens ], ... ]

) = @_;



$must_print_commands = '-'
if (!defined $must_print_commands);

set_batch_type( 'exec');

return [ GLKB => [ $file, $must_print_commands, $glkb_args_ref, $out_files_ref, $command_data_refs_ref ] ];
}




sub GBSBGJOB_sca($$$$)
{
my ($src_files,		# List
$unix_style_search,	# bool
$out_files_ref,		# undef = ok
$command_data_refs_ref,	# [ [ $command_type, $command_items_ref, $ok_values, $exec_condition, $pos_arg_tokens ], ... ]

) = @_;

set_batch_type( 'sca');

return [ SCA => [ $src_files, $unix_style_search, $out_files_ref, $command_data_refs_ref ] ];
}




sub GBSBGJOB_scasum($$)
{
my ($file,			# for failure logging purposes
$sum_filespec,
) = @_;

set_batch_type( 'scasum');

return [ SCASUM => [ $file, $sum_filespec ] ];
}




sub GBSBGJOB_batch_init($)
{
my ($max_parallel_jobs) = @_;









$BATCH_TYPE = '';

EXEC_batch_init( $max_parallel_jobs);
}




sub GBSBGJOB_batch_run($$$)
{
my ($batch_name,	# gbsgen_post, gbsaudit_post
$component,	# '-' == none
$bgjob_refs_ref,
) = @_;
my $rc;

ENV_sig( F => "BATCH_type was not initialised", @{$bgjob_refs_ref})
if ($BATCH_TYPE eq '');




my @lines = STRUCT_encode( $bgjob_refs_ref);
my $gbsbg_file = SPIT_tmp_file_nl( "gbsbg_batch_$batch_name", \@lines);

my $batch_prog = $BATCH_PROGS{$BATCH_TYPE};	    # e.g.: 'gbsbgexec.pl'
$rc = EXEC_batch_run( [ $batch_prog, $batch_name, $component, $gbsbg_file ]);
$BATCH_TYPE = '';

unlink $gbsbg_file;

return $rc;
}




sub GBSBGJOB_batch_queue($$$)
{
my ($batch_name,	# gbsbuild gbs_audit
$component,	# '-' == none
$bgjob_refs_ref,
) = @_;
my $queued;		    # 1 = queued, 0 == not queued because of failed steps

ENV_sig( F => "BATCH_type was not initialised", $batch_name, $component)
if ($BATCH_TYPE eq '');




my @lines = STRUCT_encode( $bgjob_refs_ref);
my $gbsbg_file = SPIT_tmp_file_nl( "gbsbg_batch_$batch_name", \@lines);
push @QUEUED_FILES, $gbsbg_file;

my $batch_prog = $BATCH_PROGS{$BATCH_TYPE};	    # e.g.: 'gbsbgexec.pl'
$queued = EXEC_batch_queue( [ $batch_prog, $batch_name, $component, $gbsbg_file ]);
$BATCH_TYPE = '';

return $queued;
}




sub GBSBGJOB_batch_wait()
{
my $rc;

$rc = EXEC_batch_wait();

unlink @QUEUED_FILES;
@QUEUED_FILES = ();

return $rc;
}




sub GBSBGJOB_batch_finish()
{
if ($GBS::EXEC_LEVEL == 0)	# may have be called by gbsmake->gbsbuild!
{



my @lines = FAIL_read();
if (@lines)
{
ENV_say( 1, "Failed:");
map { ENV_print( 0, "###  $_") } @lines;	# We cannot use ENV_say because the lines are already formatted
unlink FAIL_filespec()
if (!GBSENV_mode_is_background());
}
}


set_batch_type( '');
}




sub set_batch_type($)
{
my ($type) = @_;	 # exec, sca, scasum or undef

ENV_sig( F => "GBSBGJOB_batch_init was not called")
if (!defined $BATCH_TYPE);

if ($BATCH_TYPE eq '')
{
$BATCH_TYPE = $type;
} elsif ($BATCH_TYPE eq $type)
{

} else
{
ENV_sig( F => "BATCH_TYPE mismatch ($BATCH_TYPE <- $type)");

}
}

1;


