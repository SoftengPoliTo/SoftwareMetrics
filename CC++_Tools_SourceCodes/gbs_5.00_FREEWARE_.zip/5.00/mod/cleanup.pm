#=================================================
#
#   cleanup.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::cleanup;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
CLEANUP_small_stuff
CLEANUP_system_bld
CLEANUP_subsys_bld
CLEANUP_comp_bld
CLEANUP_system_aud
CLEANUP_subsys_aud
CLEANUP_comp_aud
CLEANUP_system_make_files
CLEANUP_subsys_make_files
CLEANUP_export
CLEANUP_res
CLEANUP_currencies
CLEANUP_silo_user_directory
CLEANUP_silo_cache_directory
CLEANUP_plugin_cache_directories
CLEANUP_tmp_directory
CLEANUP_usr_files
CLEANUP_obsolete_bld_files
);
}




use glo::env;
use glo::file;
use mod::gbsglo;
use mod::build;
use mod::exec;
use mod::sws;
use mod::swb;
use mod::swa;




sub CLEANUP_small_stuff();
sub CLEANUP_system_bld($);
sub CLEANUP_subsys_bld($$);
sub CLEANUP_comp_bld($);
sub CLEANUP_system_aud($$);
sub CLEANUP_subsys_aud($$$);
sub CLEANUP_comp_aud($$);
sub CLEANUP_system_make_files($);
sub CLEANUP_subsys_make_files($);
sub CLEANUP_export($);
sub CLEANUP_res($);
sub CLEANUP_currencies();
sub CLEANUP_silo_user_directory();
sub CLEANUP_silo_cache_directory();
sub CLEANUP_plugin_cache_directories();
sub CLEANUP_tmp_directory();
sub CLEANUP_usr_files();
sub CLEANUP_obsolete_bld_files();

sub get_make_files($$);
sub delete_files($$);
sub delete_contents($$$);








sub CLEANUP_small_stuff()
{
ENV_say( 1, "Cleanup .lck files");
{
my @files;
push @files, map { ENV_glob( "$GBS::ROOT_PATH/dev/$_/.*.lck") } GBSGLO_subsystems_full_gbs();
push @files, "$GBS::RES_PATH/.*.lck";
delete_files( \@files, 1);
}
}




sub CLEANUP_system_bld($)
{
my ($build) = @_;

ENV_say( 1, "Cleanup for All Builds for Build '$build'...");




my @all_subsys = GBSGLO_subsystems_for_build( $build);
if (@all_subsys)
{
my $nr_subsys = @all_subsys;
my @full_gbs_subsystems;
my @non_gbs_subsystems;
foreach my $subsys (@all_subsys)
{
if (GBSGLO_subsystem_is_full_gbs( $subsys))
{
push @full_gbs_subsystems, $subsys;
} else
{
push @non_gbs_subsystems, $subsys;
}
}
my $nr_full_subsys = @full_gbs_subsystems;
my $nr_non_full_subsys = @non_gbs_subsystems;




if (@full_gbs_subsystems)
{
ENV_say( 1, "Cleanup Build of all ($nr_full_subsys/$nr_subsys) Full-GBS SubSystems for Build '$build'");

my @files = map { ENV_glob( "$GBS::ROOT_PATH/dev/$_/comp/*/bld/$build/*") } @full_gbs_subsystems;
delete_files( \@files, 1);
}




if (@non_gbs_subsystems)
{
ENV_say( 1, "Cleanup Build of all ($nr_non_full_subsys/$nr_subsys) Non-GBS SubSystems for Build '$build'");

my $saved_build = SWB_set( $build, 0);
my $saved_subsys = $GBS::SUBSYS;
foreach my $subsys (@non_gbs_subsystems)
{
ENV_say( 1, "SubSys: $subsys:");
SWS_set( $subsys, 0);
ENV_chdir( "$GBS::DEV_PATH/$subsys");
EXEC_run( 'gbssub.pl', [ 'cleanup_bld', 0 ]);
}
SWS_set( $saved_subsys, 0);   # restore
SWB_set( $saved_build, 0);   # restore
}
} else
{
ENV_say( 2, "No Builds for Build '$build'");
}
}




sub CLEANUP_subsys_bld($$)
{
my ($subsys,
$build) = @_;

if (GBSGLO_subsystem_does_build( $subsys, $build))
{
if (GBSGLO_subsystem_is_full_gbs( $subsys))
{



ENV_say( 1, "Cleanup BLD of Full-GBS SubSystem '$subsys' for Build '$build'");

my @bld_files = ENV_glob( "$GBS::ROOT_PATH/dev/$subsys/comp/*/bld/$build/*");
delete_files( \@bld_files, 1);
} else
{



ENV_say( 1, "Cleanup BLD of Non-GBS SubSystem '$subsys' for Build '$build'");

my $saved_build = SWB_set( $build, 0);
EXEC_run( 'gbssub.pl', [ 'cleanup_bld', 0 ]);
SWB_set( $saved_build, 0);   # restore
}
} else
{
ENV_say( 1, "SubSystem '$subsys' does generate for Build '$build'");
}
}




sub CLEANUP_comp_bld($)
{
my ($build) = @_;

if (GBSGLO_component_does_build( $GBS::SUBSYS, $GBS::COMPONENT, $build))
{
ENV_say( 1, "Cleanup Build of Component '$GBS::SUBSYS:$GBS::COMPONENT' for Build '$build'");

my @bld_files = ENV_glob( "$GBS::ROOT_PATH/dev/$GBS::SUBSYS/comp/$GBS::COMPONENT/bld/$build/*");
delete_files( \@bld_files, 1);
} else
{
ENV_say( 1, "Component '$GBS::SUBSYS:$GBS::COMPONENT' does not generate for Build '$build'");
}
}




sub CLEANUP_system_aud($$)
{
my ($audit,
$build,
) = @_;

ENV_say( 1, "Cleanup for All Audits for Audit '$audit' and Build '$build'...");




my @all_subsys = GBSGLO_subsystems_for_audit( $audit, $build);
if (@all_subsys)
{
my $nr_subsys = @all_subsys;
my @full_gbs_subsystems;
my @non_gbs_subsystems;
foreach my $subsys (@all_subsys)
{
if (GBSGLO_subsystem_is_full_gbs( $subsys))
{
push @full_gbs_subsystems, $subsys;
} else
{
push @non_gbs_subsystems, $subsys;
}
}
my $nr_full_subsys = @full_gbs_subsystems;
my $nr_non_full_subsys = @non_gbs_subsystems;




if (@full_gbs_subsystems)
{
ENV_say( 1, "Cleanup Audit of all ($nr_full_subsys/$nr_subsys) Full-GBS SubSystems for Audit '$audit' and Build '$build'");

my @aud_dirs = map { ENV_glob( "$GBS::ROOT_PATH/dev/$_/comp/*/aud/$audit/$build") } @full_gbs_subsystems;
delete_contents( \@aud_dirs, undef, 1);
}




if (@non_gbs_subsystems)
{
ENV_say( 1, "Cleanup Audit of all ($nr_non_full_subsys/$nr_subsys) Non-GBS SubSystems for Audit '$audit' and Build '$build'");

my $saved_audit = SWA_set( $audit, 0);
my $saved_build = SWB_set( $build, 0);
my $saved_subsys = $GBS::SUBSYS;
foreach my $subsys (@non_gbs_subsystems)
{
ENV_say( 1, "SubSys: $subsys");
SWS_set( $subsys, 0);
ENV_chdir( "$GBS::ROOT_PATH/dev/$subsys");
EXEC_run( 'gbssub.pl', [ 'cleanup_aud', 0 ]);
}
SWS_set( $saved_subsys, 0);   # restore
SWB_set( $saved_build, 0);   # restore
SWA_set( $saved_audit, 0);    # restore
}
} else
{
ENV_say( 2, "No Audits for Audit '$audit' and Build '$build'");
}
}




sub CLEANUP_subsys_aud($$$)
{
my ($subsys,
$audit,
$build,
) = @_;

if (GBSGLO_subsystem_does_audit( $subsys, $audit, $build))
{
if (GBSGLO_subsystem_is_full_gbs( $subsys))
{



ENV_say( 1, "Cleanup Audit of GBS SubSystem '$subsys' for Audit '$audit' and Build '$build'");

my @aud_dirs = ENV_glob( "$GBS::ROOT_PATH/dev/$subsys/comp/*/aud/$audit/$build");
delete_contents( \@aud_dirs, undef, 1);
} else
{



ENV_say( 1, "Cleanup Audit of non-GBS SubSystem '$subsys' for Audit '$audit' and Build '$build'");

my $saved_audit = SWA_set( $audit, 0);
my $saved_build = SWB_set( $build, 0);
EXEC_run( 'gbssub.pl', [ 'cleanup_aud', 0 ]);
SWB_set( $saved_build, 0);   # restore
SWA_set( $saved_audit, 0);    # restore
}
} else
{
ENV_say( 1, "SubSystem '$subsys' does Audit for Audit '$audit' and Build '$build'");
}
}




sub CLEANUP_comp_aud($$)
{
my ($audit,
$build,
) = @_;

if (GBSGLO_component_does_audit( $GBS::SUBSYS, $GBS::COMPONENT, $audit, $build))
{
ENV_say( 1, "Cleanup Audit $audit of Component '$GBS::SUBSYS:$GBS::COMPONENT' for Audit '$audit' and Build '$build'");

my @aud_dirs = ENV_glob( "$GBS::ROOT_PATH/dev/$GBS::SUBSYS/comp/$GBS::COMPONENT/aud/$audit/$build");
delete_contents( \@aud_dirs, undef, 1);
} else
{
ENV_say( 1, "Component '$GBS::SUBSYS:$GBS::COMPONENT' does not Audit for Audit '$audit' and Build '$build'");
}
}




sub CLEANUP_system_make_files($)
{
my ($build) = @_;

ENV_say( 1, "Cleanup Make files of all SubSystems of $GBS::ROOT_PATH for Build '$build'");

my @make_files = map { get_make_files( $_, $build) } GBSGLO_subsystems_full_gbs();
delete_files( \@make_files, 1);
}




sub CLEANUP_subsys_make_files($)
{
my ($build) = @_;

ENV_say( 1, "Cleanup Make files of SubSystem $GBS::SUBSYS for Build '$build'");

my @make_files = get_make_files( $GBS::SUBSYS, $build);
delete_files( \@make_files, 1);
}




sub get_make_files($$)
{
my ($subsys,
$build,
) = @_;

return ( ENV_glob( "$GBS::ROOT_PATH/dev/$subsys/build/$build.mk",
"$GBS::ROOT_PATH/dev/$subsys/comp/*/bld/$build.mk",
"$GBS::ROOT_PATH/dev/$subsys/comp/*/bld/$build.ref",
)
);
}




sub CLEANUP_export($)
{
my ($subsys) = @_;	# '*' == ALL

ENV_say( 1, "Cleanup EXPORT Directory for SubSystem: $subsys");

my @dirs;
if ($subsys eq '*')
{
@dirs = map { "$GBS::ROOT_PATH/dev/$_/export" } GBSGLO_subsystems_full_gbs();
} else
{
@dirs = ("$GBS::ROOT_PATH/dev/$subsys/export");
}

delete_contents( \@dirs, undef, 1);
}




sub CLEANUP_res($)
{
my ($subsys) = @_;	# '*' == ALL



my @dirs;
if ($subsys eq '*')
{
@dirs = map { "$GBS::ROOT_PATH/res/$_" } @GBS::ALL_SUBSYSTEMS;
} else
{
@dirs = ("$GBS::ROOT_PATH/res/$subsys");
}

delete_contents( \@dirs, undef, 1);
}




sub CLEANUP_currencies()
{

my @files;

if ($GBS::ROOT_PATH eq '')
{
ENV_say( 1, "No Root: Cleanup User currencies");



push @files, "$GBS::BASE_PATH/.gbsrc";
} else
{



push @files, "$GBS::ROOT_PATH/dev/.gbsrc";




push @files, map { "$GBS::ROOT_PATH/dev/$_/comp/.gbsrc" } GBSGLO_subsystems_full_gbs();
}




delete_files( \@files, 1);
}




sub CLEANUP_silo_user_directory()
{

ENV_say( 2, "'doxygen' found. May take a long time...")
if (-e "$GBS::ROOT_PATH/silo/doxygen");

my @del_refs;




delete_contents( [ "$GBS::ROOT_PATH/silo" ], [ "^\.gbs\$" ], 1 );
}




sub CLEANUP_silo_cache_directory()
{


my @del_refs;




my @cache_dirs = ENV_glob( "$GBS::ROOT_PATH/silo/.gbs/cache/*");
delete_contents( \@cache_dirs, undef, 1);
}




sub CLEANUP_plugin_cache_directories()
{


my @del_refs;




my $gbs_plugin_path = ENV_canonicalize_paths( "$GBS::PLUGIN_ROOT/..");
my @cache_dirs = ( "$gbs_plugin_path/html", ENV_glob( "$GBS::PLUGIN_ROOT/*") );
delete_contents( \@cache_dirs, undef, 1);
}




sub CLEANUP_tmp_directory()
{


my @del_refs;




my @builds_re = map { "^$_\$" } @GBS::ALL_BUILDS, @GBS::AUDITS, @GBS::TOOLS;
delete_contents( [ "$GBS::ROOT_PATH/tmp" ], \@builds_re, 1);




my @build_dirs = map { "$GBS::ROOT_PATH/tmp/$_" } @GBS::ALL_BUILDS;
delete_contents( \@build_dirs, undef, 0);
}




sub CLEANUP_usr_files()
{


my @files;
push @files, ENV_glob( "$GBS::ROOT_PATH/*.usr");
push @files, ENV_glob( "$GBS::ROOT_PATH/dev/*/*.usr");
push @files, ENV_glob( "$GBS::ROOT_PATH/dev/*/build/*.usr");
push @files, ENV_glob( "$GBS::ROOT_PATH/dev/*/build/*/*.usr");
push @files, ENV_glob( "$GBS::ROOT_PATH/dev/*/comp/*/*.usr");
push @files, ENV_glob( "$GBS::ROOT_PATH/dev/*/comp/*/opt/*.usr");
push @files, ENV_glob( "$GBS::ROOT_PATH/dev/*/comp/*/opt/*/*.usr");
push @files, ENV_glob( "$GBS::ROOT_PATH/sys/*.usr");
push @files, ENV_glob( "$GBS::ROOT_PATH/sys/*/*.usr");
push @files, ENV_glob( "$GBS::ROOT_PATH/sysaudit/*.usr");
push @files, ENV_glob( "$GBS::ROOT_PATH/sysaudit/*/*.usr");
push @files, ENV_glob( "$GBS::ROOT_PATH/sysbuild/*.usr");
push @files, ENV_glob( "$GBS::ROOT_PATH/sysbuild/*/*.usr");




my $gbs_tmp_dir = "$GBS::ROOT_PATH/tmp";
my $total = 0;
my $nr_moved = 0;
foreach my $filespec (@files)
{
$total++;
my $short_spec = $filespec;
$short_spec =~ s!$GBS::ROOT_PATH/!!;
ENV_say( 1, "  .../$short_spec");
my $temp_name = $short_spec;
$temp_name =~ s!/!_!g;
if (rename( $filespec, "$gbs_tmp_dir/$temp_name"))
{
$nr_moved++;
} else
{
ENV_sig( W => "Failed to rename $short_spec to tmp_dir/$temp_name", "- $!");
}
}
ENV_say( 1, "  $nr_moved/$total .usr files move to TMP directory");
}




sub CLEANUP_obsolete_bld_files()
{

my @files;
ENV_say( 1, "Searching...");

foreach my $build (@GBS::ALL_BUILDS)
{


my @src_types = BUILD_get_src_types( $build);
my %bld_out_types;
my %bld_out_files;
foreach my $src_type (@src_types)
{

$bld_out_types{$src_type} = [ BUILD_get_src_items( $build, $src_type, 'OUT_TYPES'),
BUILD_get_src_items( $build, $src_type, 'OPT_OUT_TYPES'),
'.map' ];
$bld_out_files{$src_type} = [ BUILD_get_src_items( $build, $src_type, 'OUT_FILES') ];
}

foreach my $subsys (GBSGLO_subsystems_for_build( $build))
{

foreach my $comp (GBSGLO_components_for_build( $subsys, $build))
{

my $build_path = "$GBS::ROOT_PATH/dev/$subsys/comp/$comp/bld/$build";
my @bld_files = GBSGLO_glob( "$build_path/*");
my %bld_files = map { ENV_split_spec_f( $_) => 1 } @bld_files;

my %src_types_found;
foreach my $src_file (GBSGLO_glob( "$GBS::ROOT_PATH/dev/$subsys/comp/$comp/src/*"))
{
my ($name, $src_type) = ENV_split_spec_nt( $src_file);
$src_types_found{$src_type} = 1;
foreach my $bld_type (@{$bld_out_types{$src_type}})
{
delete( $bld_files{"$name$bld_type"});
}
}

foreach my $src_type (keys( %src_types_found))
{
foreach my $bld_file (@{$bld_out_files{$src_type}})
{
delete( $bld_files{$bld_file});
}
}

my @files_to_delete = keys( %bld_files);
map { ENV_say( 1, "==> $subsys:$comp:$build:$_") } @files_to_delete;
push @files, map { "$build_path/$_" } @files_to_delete;
}
}
}




delete_files( \@files, 1);
}







sub delete_files($$)
{
my ($filespecs_ref,
$must_print_result,
) = @_;

my ($nr_delete, $total) = (0,0);
foreach my $filespec (@{$filespecs_ref})
{
my $file = ENV_split_spec_f( $filespec);
next if (grep( $file =~ $_, @GBS::SCM_SKIPTYPES));
if (-e $filespec)
{
$total++;
if (unlink( $filespec))
{
$nr_delete++;
} else
{
my $err_msg = $!;
if (!$err_msg)
{
if (!-f $filespec)
{
$err_msg = 'Not a File';
} else
{
$err_msg = 'Unknown reason';
}
}
ENV_sig( E => "Unable to delete file '$filespec'", "- $err_msg");
}
}
}

if ($must_print_result)
{
ENV_say( 1, "  $nr_delete/$total Files deleted");
}
}




sub delete_contents($$$)
{
my ($dirs_ref,
$extra_ignore_re_ref,
$must_print_result,
) = @_;

my @skiptypes_re = @GBS::SCM_SKIPTYPES;
push @skiptypes_re, @{$extra_ignore_re_ref}
if (defined $extra_ignore_re_ref);

my @counts = (0,0,0);	# ($nr_dirs_deleted, $nr_files_deleted, $total_scanned)
foreach my $dir (@{$dirs_ref})
{



if (-d $dir)
{
my @this_counts = FILE_del_tree( W => $dir, \@skiptypes_re, 0);
map { $counts[$_] += $this_counts[$_] } 0..$#this_counts;
}
}
if ($must_print_result)
{
my ($nr_dirs_deleted, $nr_files_deleted, $total_scanned) = @counts;
my $nr_delete = $nr_dirs_deleted + $nr_files_deleted;
ENV_say( 1, "  $nr_delete/$total_scanned Files and/or Dirs deleted");
}
}

1;

