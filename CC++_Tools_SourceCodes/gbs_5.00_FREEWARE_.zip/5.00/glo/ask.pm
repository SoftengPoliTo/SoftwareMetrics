#=================================================
#
#   ask.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::ask;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
ASK_text
ASK_not_text
ASK_word
ASK_not_word
ASK_wild_words
ASK_bool
ASK_int
ASK_password
ASK_pause
ASK_values_from_list
ASK_time
ASK_date
ASK_YN
ASK_YNQ
ASK_YNEQ
ASK_YNAE
ASK_YNAEQ
ASK_more
ASK_menu
ASK_index_from_menu
ASK_value_from_menu
ASK_uri
ASK_path
ASK_other_path
ASK_dir
ASK_dirs
ASK_file
ASK_filespec
);
}




use glo::env;
use glo::check;
use glo::list;
use glo::format;
use glo::uri;




sub ASK_text($$$;$$);
sub ASK_not_text($$$$;$$);
sub ASK_word($$$;$$);
sub ASK_not_word($$$$;$$);
sub ASK_wild_words($$$;$$);
sub ASK_bool($$$$;$$);
sub ASK_int($$$$;$$);
sub ASK_uri($$$$;$$);
sub ASK_path($$$$;$$);
sub ASK_other_path($$$;$$);
sub ASK_dir($$$$$;$$);
sub ASK_dirs($$$$$;$$);
sub ASK_file($$$$$;$$);
sub ASK_filespec($$$$;$$);
sub ASK_time($$$$;$$);
sub ASK_date($$$$;$$);
sub ASK_values_from_list($$$$;$$);
sub ASK_YN($$;$);
sub ASK_YNQ($$$;$);
sub ASK_YNEQ($$$;$);
sub ASK_YNAE($$;$);
sub ASK_YNAEQ($$$;$);
sub ASK_more($$$;$);
sub ASK_menu($$$;$);
sub ASK_index_from_menu($$$$;$);
sub ASK_value_from_menu($$$$;$);
sub ASK_password($$;$$);
sub ASK_pause($);

sub gen_menu($$);
sub gen_ask_fc_list($$$$);
sub gen_ask_s($$$$$$);
sub read_line($$$);
sub general_input_handling($$);
sub check_length($$$);
sub check_and_set_menu_entry($$$);
sub check_and_set_wildcard_values($$$);
sub check_and_set_uri($$$);
sub check_and_set_path($$$);
sub check_and_set_other_path($$$);
sub check_dir($$$);
sub check_dirs($$$);
sub check_file($$$);
sub check_and_set_check_filespec($$$);
sub check_chars($$$);
sub check_not_allowed_values($$$);
sub check_bool($$$);
sub check_integer($$$);
sub check_num_values($$$);
sub check_string_values($$$);
sub check_allowed_values($$$);
sub check_duplicate_values($$$);
sub check_time($$$);
sub check_date($$$);
sub handle_menu($$$$$);
sub show_menu($$$$$);
sub show_files($);
sub opt_checks($);
sub add_help($$);
sub get_help_lines($);
sub min_max($);
sub local_prompt($$);
sub print_error($);
sub deref_prompt($);
sub quit();




my $IS_WIN32 = (ENV_is_win32());

my @WORD_CHARS = ( '\w', 'A-Z a-z 0-9 _' );
my @WILD_WORD_CHARS = ( '\w*?', 'A-Z a-z 0-9 _ * ?' );

my $MENU_LEVEL = 0;

















sub ASK_text($$$;$$)
{
my ($prompt_or_ref,
$default_or_ref,    # '', scalar or array_ref
$length,	    # >0 = max, <0 = min or [ $min, $max ]
$opt_checks_ref,    # optional: [ [ $check_func, $app_data_ref ]... ]
$help_or_ref,	    # optional: $help or [ @help ] or \&help_func
) = @_;


my @check_refs = (
opt_checks( $opt_checks_ref),
);

return gen_ask_s( $prompt_or_ref, $default_or_ref, $length, \@check_refs, $help_or_ref, 1);
}





sub ASK_not_text($$$$;$$)
{
my ($prompt_or_ref,
$default_or_ref,    # '', scalar or array_ref
$length,	    # >0 = max, <0 = min or [ $min, $max ]
$invalid_values_ref,
$opt_checks_ref,    # optional: [ [ $check_func, $app_data_ref ]... ]
$help_or_ref,	    # optional: $help or [ @help ] or \&help_func
) = @_;


my ($level, $prompt) = deref_prompt( $prompt_or_ref);
ENV_say( $level, "$prompt, NOT one of (@{$invalid_values_ref})");
$prompt = 'Enter value';
$prompt_or_ref = [ $level, $prompt ];

my @check_refs = (
[ \&check_not_allowed_values, $invalid_values_ref ],
opt_checks( $opt_checks_ref),
);

return gen_ask_s( $prompt_or_ref, $default_or_ref, $length, \@check_refs, $help_or_ref, 1);
}





sub ASK_word($$$;$$)
{
my ($prompt_or_ref,
$default_or_ref,    # '', scalar or array_ref
$length,	    # >0 = max, <0 = min or [ $min, $max ]
$opt_checks_ref,    # optional: [ [ $check_func, $app_data_ref ]... ]
$help_or_ref,	    # optional: $help or [ @help ] or \&help_func
) = @_;


my @check_refs = (
[ \&check_chars, \@WORD_CHARS ],
opt_checks( $opt_checks_ref),
);

return gen_ask_s( $prompt_or_ref, $default_or_ref, $length, \@check_refs, $help_or_ref, 1);
}





sub ASK_not_word($$$$;$$)
{
my ($prompt_or_ref,
$default_or_ref,    # '', scalar or array_ref
$length,	    # >0 = max, <0 = min or [ $min, $max ]
$invalid_values_ref,
$opt_checks_ref,    # optional: [ [ $check_func, $app_data_ref ]... ]
$help_or_ref,	    # optional: $help or [ @help ] or \&help_func
) = @_;


my ($level, $prompt) = deref_prompt( $prompt_or_ref);
ENV_say( $level, "$prompt, NOT one of:",
"@{$invalid_values_ref}");

my @check_refs = (
[ \&check_chars, \@WORD_CHARS ],
[ \&check_not_allowed_values, $invalid_values_ref ],
opt_checks( $opt_checks_ref),
);

return gen_ask_s( $prompt_or_ref, $default_or_ref, $length, \@check_refs, $help_or_ref, 1);
}





sub ASK_wild_words($$$;$$)
{
my ($prompt_or_ref,
$default_or_ref,    # '', scalar or array_ref
$length,	    # >0 = max, <0 = min or [ $min, $max ]
$opt_checks_ref,    # optional: [ [ $check_func, $app_data_ref ]... ]
$help_or_ref,	    # optional: $help or [ @help ] or \&help_func
) = @_;


my @check_refs = (
[ \&check_chars,	    \@WILD_WORD_CHARS ],
[ \&check_duplicate_values, undef ],
opt_checks( $opt_checks_ref),
);

return gen_ask_s( $prompt_or_ref, $default_or_ref, $length, \@check_refs, $help_or_ref, 1);
}





sub ASK_values_from_list($$$$;$$)
{
my ($prompt_or_ref,
$default_or_ref,	# '', scalar or array_ref
$length,		# >0 = max, <0 = min or [ $min, $max ]
$possible_values_ref,
$opt_checks_ref,	# optional: [ [ $check_func, $app_data_ref ]... ]
$help_or_ref,		# optional: $help or [ @help ] or \&help_func
) = @_;




{
my ($level, $prompt) = deref_prompt( $prompt_or_ref);
ENV_say( $level, $prompt);
my @possible_values = @{$possible_values_ref};
my $values_text = (@possible_values == 1) ? "($possible_values[0])" : "(@possible_values *)";
map { ENV_say( 0, $_) } FORMAT_hanging( 0, 4, 1, $values_text);
}

$prompt_or_ref = local_prompt( (wantarray) ? 'Enter list' : 'Enter value', $prompt_or_ref);

my @check_refs = (
[ \&check_and_set_wildcard_values, $possible_values_ref ],
[ \&check_allowed_values, $possible_values_ref ],
opt_checks( $opt_checks_ref),
);

$help_or_ref = add_help( $help_or_ref, 'Wildcards are allowed');

return gen_ask_s( $prompt_or_ref, $default_or_ref, $length, \@check_refs, $help_or_ref, 1 );
}




sub ASK_bool($$$$;$$)
{
my ($prompt_or_ref,
$default_or_ref,	# '', scalar or array_ref
$length,		# >0 = max, <0 = min or [ $min, $max ]
$possible_values_ref,	# undef
$opt_checks_ref,	# optional: [ [ $check_func, $app_data_ref ]... ]
$help_or_ref,		# optional: $help or [ @help ] or \&help_func
) = @_;




my ($level, $prompt) = deref_prompt( $prompt_or_ref);
$prompt .= ' (y/n)';
$prompt_or_ref = [ $level, $prompt ];

my @defaults = ENV_deref( $default_or_ref);
foreach my $default (@defaults)
{
if ($default eq '0')
{
$default = 'n';
} elsif ($default eq '1')
{
$default = 'y';
}
}

my @check_refs = (
[ \&check_bool, undef ],
opt_checks( $opt_checks_ref),
);

return gen_ask_s( $prompt_or_ref, \@defaults, $length, \@check_refs, $help_or_ref, 0);
}




sub ASK_int($$$$;$$)
{
my ($prompt_or_ref,
$default_or_ref,	# '', scalar or array_ref
$length,		# >0 = max, <0 = min or [ $min, $max ]
$possible_values_ref,	# [ value, [ min, max ], ... ] or undef
$opt_checks_ref,	# optional: [ [ $check_func, $app_data_ref ]... ]
$help_or_ref,		# optional: $help or [ @help ] or \&help_func
) = @_;


my @check_refs = (
[ \&check_integer, undef ],
[ \&check_num_values, $possible_values_ref ],
opt_checks( $opt_checks_ref),
);

return gen_ask_s( $prompt_or_ref, $default_or_ref, $length, \@check_refs, $help_or_ref, 1);
}



















sub ASK_uri($$$$;$$)
{
my ($prompt_or_ref,
$default_or_ref,	# '', scalar or array_ref
$length,		# >0 = max, <0 = min or [ $min, $max ]
$allowed_schemes_ref,	# undef == ALL. chose: file ftp htp svn mailto
$opt_checks_ref,	# optional: [ [ $check_func, $app_data_ref ]... ]
$help_or_ref,		# optional: $help or [ @help ] or \&help_func
) = @_;
my ($uri, $scheme, @scheme_dependent);

my @check_refs = (
[ \&check_and_set_uri, $allowed_schemes_ref ],
opt_checks( $opt_checks_ref),
);

$uri = gen_ask_s( $prompt_or_ref, $default_or_ref, $length, \@check_refs, $help_or_ref, 1);
if (wantarray)
{
if ($uri eq '')
{
return ( $uri, '', ());  # get from cache
} else
{
return URI_normalize( $uri, undef, undef, undef);  # get from cache
}
} else
{
return $uri;
}
}






sub ASK_path($$$$;$$)
{
my ($prompt_or_ref,
$default_or_ref,    # '', scalar or array_ref
$length,	    # >0 = max, <0 = min or [ $min, $max ]
$must_exist,	    # 1=must exist 0= may exist -1=may not exist
$opt_checks_ref,    # optional: [ [ $check_func, $app_data_ref ]... ]
$help_or_ref,	    # optional: $help or [ @help ] or \&help_func
) = @_;


my @check_refs = (
[ \&check_and_set_path, $must_exist ],
opt_checks( $opt_checks_ref),
);

return gen_ask_s( $prompt_or_ref, $default_or_ref, $length, \@check_refs, $help_or_ref, 1);
}







sub ASK_other_path($$$;$$)
{
my ($prompt_or_ref,
$default_or_ref,    # '', scalar or array_ref
$length,	    # >0 = max, <0 = min or [ $min, $max ]
$opt_checks_ref,    # optional: [ [ $check_func, $app_data_ref ]... ]
$help_or_ref,	    # optional: $help or [ @help ] or \&help_func
) = @_;


my @check_refs = (
[ \&check_and_set_other_path, 1 ],
opt_checks( $opt_checks_ref),
);

return gen_ask_s( $prompt_or_ref, $default_or_ref, $length, \@check_refs, $help_or_ref, 1);
}







sub ASK_dir($$$$$;$$)
{
my ($prompt_or_ref,
$default_or_ref,    # '', scalar or array_ref
$length,	    # >0 = max, <0 = min or [ $min, $max ]
$must_exist,	    # 1=must exist 0= may exist -1=may not exist
$path,		    # May be ''
$opt_checks_ref,    # optional: [ [ $check_func, $app_data_ref ]... ]
$help_or_ref,	    # optional: $help or [ @help ] or \&help_func
) = @_;


my ($level, $prompt) = deref_prompt( $prompt_or_ref);
$prompt .= (defined $path && $path ne '') ? " (/<dirname>)" : " (<dirname>)";
$prompt_or_ref = [ $level, $prompt ];

my @check_refs = (
[ \&check_dir, [ $must_exist, $path ] ],
opt_checks( $opt_checks_ref),
);

$help_or_ref = add_help( $help_or_ref, sub { show_files( $path) });

return gen_ask_s( $prompt_or_ref, $default_or_ref, $length, \@check_refs, $help_or_ref, 1);
}







sub ASK_dirs($$$$$;$$)
{
my ($prompt_or_ref,
$default_or_ref,    # '', scalar or array_ref
$length,	    # >0 = max, <0 = min or [ $min, $max ]
$must_exist,	    # 1=must exist 0= may exist -1=may not exist
$path,		    # May be ''
$opt_checks_ref,    # optional: [ [ $check_func, $app_data_ref ]... ]
$help_or_ref,	    # optional: $help or [ @help ] or \&help_func
) = @_;


my ($level, $prompt) = deref_prompt( $prompt_or_ref);
$prompt .= (defined $path && $path ne '') ? " (/<dirnames>)" : " (<dirnames>)";
$prompt_or_ref = [ $level, $prompt ];

my @check_refs = (
[ \&check_dirs, [ $must_exist, $path ] ],
opt_checks( $opt_checks_ref),
);

$help_or_ref = add_help( $help_or_ref, sub { show_files( $path) });

return gen_ask_s( $prompt_or_ref, $default_or_ref, $length, \@check_refs, $help_or_ref, 1);
}






sub ASK_file($$$$$;$$)
{
my ($prompt_or_ref,
$default_or_ref,    # '', scalar or array_ref
$length,	    # >0 = max, <0 = min or [ $min, $max ]
$must_exist,	    # 1=must exist 0= may exist -1=may not exist
$path,		    # May be ''
$opt_checks_ref,    # optional: [ [ $check_func, $app_data_ref ]... ]
$help_or_ref,	    # optional: $help or [ @help ] or \&help_func
) = @_;


my ($level, $prompt) = deref_prompt( $prompt_or_ref);
$prompt .= (defined $path && $path ne '') ? " (/<file>)" : " (<file>)";
$prompt_or_ref = [ $level, $prompt ];

my @check_refs = (
[ \&check_file, [ $must_exist, $path ] ],
opt_checks( $opt_checks_ref),
);

$help_or_ref = add_help( $help_or_ref, sub { show_files( $path) });

return gen_ask_s( $prompt_or_ref, $default_or_ref, $length, \@check_refs, $help_or_ref, 1);
}




sub ASK_filespec($$$$;$$)
{
my ($prompt_or_ref,
$default_or_ref,    # '', scalar or array_ref
$length,	    # >0 = max, <0 = min or [ $min, $max ]
$must_exist,	    # 1=must exist 0= may exist -1=may not exist
$opt_checks_ref,    # optional: [ [ $check_func, $app_data_ref ]... ]
$help_or_ref,	    # optional: $help or [ @help ] or \&help_func
) = @_;


my @check_refs = (
[ \&check_and_set_check_filespec, [ $must_exist, '' ] ],
opt_checks( $opt_checks_ref),
);

return gen_ask_s( $prompt_or_ref, $default_or_ref, $length, \@check_refs, $help_or_ref, 1);
}





sub ASK_time($$$$;$$)
{
my ($prompt_or_ref,
$default_or_ref,	# '', scalar or array_ref
$length,		# >0 = max, <0 = min or [ $min, $max ], default = 10
$possible_values_ref,	# [ value, [ min, max ], ... ] or undef
$opt_checks_ref,	# optional: [ [ $check_func, $app_data_ref ]... ]
$help_or_ref,		# optional: $help or [ @help ] or \&help_func
) = @_;
my $value;			# YYYY-MM-DD


$length = 10
if (!defined $length);

my @check_refs = (
[ \&check_time, undef ],
[ \&check_string_values, $possible_values_ref ],
opt_checks( $opt_checks_ref),
);

$help_or_ref = add_help( $help_or_ref, "Format: '[+=]hh:mm' or '[+=]mm' or 'now'");

return gen_ask_s( $prompt_or_ref, $default_or_ref, $length, \@check_refs, $help_or_ref, 1);
}





sub ASK_date($$$$;$$)
{
my ($prompt_or_ref,
$default_or_ref,	# '', scalar or array_ref
$length,		# >0 = max, <0 = min or [ $min, $max ], default = 10
$possible_values_ref,	# [ value, [ min, max ], ... ] or undef
$opt_checks_ref,	# optional: [ [ $check_func, $app_data_ref ]... ]
$help_or_ref,		# optional: $help or [ @help ] or \&help_func
) = @_;
my $value;			# YYYY-MM-DD


$length = 10
if (!defined $length);

my @check_refs = (
[ \&check_date, undef ],
[ \&check_string_values, $possible_values_ref ],
opt_checks( $opt_checks_ref),
);

$help_or_ref = add_help( $help_or_ref, 'Format: YYYY-MM-DD');

return gen_ask_s( $prompt_or_ref, $default_or_ref, $length, \@check_refs, $help_or_ref, 1);
}




sub ASK_YN($$;$)
{
my ($prompt_or_ref,
$default,
$help_or_ref,	    # optional: $help or [ @help ] or \&help_func
) = @_;
my $ans;

$ans = gen_ask_fc_list( $prompt_or_ref, $default, [ qw( Yes No) ], $help_or_ref);

return $ans;
}




sub ASK_YNQ($$$;$)
{
my ($prompt_or_ref,
$default,
$exit_on_quit,
$help_or_ref,	    # optional: $help or [ @help ] or \&help_func
) = @_;
my $ans;

$ans = gen_ask_fc_list( $prompt_or_ref, $default, [ qw( Yes No Quit) ], $help_or_ref);

quit()
if ($ans eq 'Q' && $exit_on_quit);

return $ans;
}




sub ASK_YNEQ($$$;$)
{
my ($prompt_or_ref,
$default,
$exit_on_quit,
$help_or_ref,	    # optional: $help or [ @help ] or \&help_func
) = @_;
my $ans;

$ans = gen_ask_fc_list( $prompt_or_ref, $default,
[ 'Yes',
'No',
'End and keep previous',
'Quit'
],
$help_or_ref );

quit()
if ($ans eq 'Q' && $exit_on_quit);

return $ans;
}




sub ASK_YNAE($$;$)
{
my ($prompt_or_ref,
$default,
$help_or_ref,	    # optional: $help or [ @help ] or \&help_func
) = @_;
my $ans;

$ans = gen_ask_fc_list( $prompt_or_ref, $default,
[ 'Yes',
'No',
'All or the rest',
'End and keep previous',
],
$help_or_ref);

return $ans;
}




sub ASK_YNAEQ($$$;$)
{
my ($prompt_or_ref,
$default,
$exit_on_quit,
$help_or_ref,	    # optional: $help or [ @help ] or \&help_func
) = @_;
my $ans;

$ans = gen_ask_fc_list( $prompt_or_ref, $default,
[ 'Yes',
'No',
'All or the rest',
'End and keep previous',
'Quit',
],
$help_or_ref);

quit()
if ($ans eq 'Q' && $exit_on_quit);

return $ans;
}




sub ASK_more($$$;$)
{
my ($slack,
$header,
$lines_ref,
$help_or_ref,	    # optional: $help or [ @help ] or \&help_func
) = @_;

(undef, my $nr_rows) = ENV_get_term_size();
$nr_rows -= $slack + 1;
my $nr_lines = @{$lines_ref};


if ($nr_lines < $nr_rows)
{
ENV_say( 0, $header)
if ($header);
ENV_say( 0, $lines_ref);
} else
{
my $last_page = $nr_lines / $nr_rows;
my $page = 0;

do
{
my $from = $page * $nr_rows;
my $to = $from + $nr_rows - 1;
$to = $nr_lines - 1 if ($to > $nr_lines - 1);

ENV_say( 0, $header)
if ($header);
ENV_say( 0, @{$lines_ref}[$from..$to]);

my $default;
my @answers;
if ($page == 0)
{
@answers = qw( Next Last End);
$default = 'N';
} elsif ($page == $last_page)
{
@answers = qw( Previous First End);
$default = 'E';
} else
{
@answers = qw( Next Previous First Last End);
$default = 'N';
}
my $prompt = ($page == $last_page) ? 'Last' : 'More';
my $ans = gen_ask_fc_list( $prompt, $default, \@answers, $help_or_ref);
if ($ans eq 'N')
{
$page++;
} elsif ($ans eq 'P')
{
$page--;
} elsif ($ans eq 'F')
{
$page = 0;
} elsif ($ans eq 'L')
{
$page = $last_page;
} elsif ($ans eq 'E')
{
$page = -1;
}
$page = -1 if ($page > $last_page);
} while ($page >= 0);
}
}









sub ASK_menu($$$;$)
{
my ($prompt_or_ref,
$menu_refs_ref,	    	# [ [ $text, $function, $func_data_ref ], ...]

$entries_ref,		# may be undef
$help_or_ref,		# optional: $help or [ @help ] or \&help_func
) = @_;

$MENU_LEVEL++;

my ($level, $prompt) = deref_prompt( $prompt_or_ref);
my $prompt_ref = [ $level, $prompt, $help_or_ref ];

if (defined $entries_ref && @{$entries_ref})
{
my @entries = @{$entries_ref};

my $entry_nr = shift @entries;
my $index = $entry_nr - 1;

my $nr_menu_refs = @{$menu_refs_ref};
if ($index >= 0 && $index < $nr_menu_refs)
{



my $entry_ref = $menu_refs_ref->[$index];
my ($text, $func, $func_data_ref) = @{$entry_ref};
$text =~ s/\n//g;	    # Remove possible newlines from text
$text =~ s/\s\s+/ /g;   # Reduce multiple spaces to one (may have been used for alignment in menu)

ENV_say( 2, "$text...");




$func->( $index, $func_data_ref, [ @entries ]);
} else
{
ENV_sig( W => "No such menu sub-entry-$MENU_LEVEL: $entry_nr (@entries)");
gen_menu( $prompt_ref, $menu_refs_ref);
}
} else
{
gen_menu( $prompt_ref, $menu_refs_ref);
}

$MENU_LEVEL--;
}




sub gen_menu($$)
{
my ($prompt_ref,		# [ $level, $prompt, $help_or_ref ]
$menu_refs_ref,	    	#  ($display_text, $function, $func_argument_ref, @nestings)
) = @_;

my @menu_refs = @{$menu_refs_ref};

if ($MENU_LEVEL == 1)
{
unshift @menu_refs, [ "Exit (program)" ];
} else
{
unshift @menu_refs, [ "Exit (to previous menu)" ];
}
my $max = @menu_refs - 1;
my @display_texts = map { $_->[0] } @menu_refs;
my ($level, $prompt) = @{$prompt_ref};
my $choice_prompt_ref = [ $level, "Choice (0-$max)" ];

my @check_refs = (
[ \&check_and_set_menu_entry, \@display_texts ],
[ \&check_num_values, [ [ 0, $max ] ]],
);

my $value = 0;
do
{
show_menu( $prompt_ref, 0, 0, undef, \@display_texts);

$value = gen_ask_s( $choice_prompt_ref, 0, -1, \@check_refs, undef, 1);

if ($value > 0)
{



my ($text, $func, @args) = @{$menu_refs[$value]};
$text =~ s/\n//g;	    # Remove possible newlines from text
$text =~ s/\s\s+/ /g;   # Reduce multiple spaces to one (may have been used for alignment in menu)
ENV_say( 2, $text);




$func->( $value - 1, @args)
if (defined $func);
ENV_say( 0, '');
}
} while ($value != 0);
}




sub ASK_index_from_menu($$$$;$)
{
my ($prompt_or_ref,
$default_index_or_ref,	# ref == default_value, -1 == no default, 0 = first
$format_ref, 		# May be undef. Formats: L R
$menu_refs_ref,	    	# [ $display_text_or_ref, ...,


$help_or_ref,		# optional: $help or [ @help ] or \&help_func
) = @_;
my $index;

my ($level, $prompt) = deref_prompt( $prompt_or_ref);
my $prompt_ref = [ $level, $prompt, $help_or_ref ];

$index = handle_menu( $prompt_ref, $default_index_or_ref, $format_ref, $menu_refs_ref, $help_or_ref);

quit()
if (lc $menu_refs_ref->[$index]->[0] eq lc '<Quit>');	    # $display_text_or_ref

return $index;
}




sub ASK_value_from_menu($$$$;$)
{
my ($prompt_or_ref,
$default_index_or_ref,	# ref == default_value, -1 == no default, 0 = first
$format_ref, 		# May be undef. Formats: L R
$menu_refs_ref,	    	# [ $display_text_or_ref, ...,



$help_or_ref,		# optional: $help or [ @help ] or \&help_func
) = @_;
my ($value, @more_values);

my ($level, $prompt) = deref_prompt( $prompt_or_ref);
my $prompt_ref = [ $level, $prompt, $help_or_ref ];

my $index = handle_menu( $prompt_ref, $default_index_or_ref, $format_ref, $menu_refs_ref, $help_or_ref);

my $display_text = lc $menu_refs_ref->[$index]->[0];
if ($display_text eq lc '<Quit>')
{
quit();
} elsif ($display_text eq lc '<Specify>')
{
my $func = $menu_refs_ref->[$index]->[1];   # $value
if (wantarray)
{
($value, @more_values) = $func->();
} else
{
$value = $func->();
}
} else
{
shift @{$menu_refs_ref->[$index]};			# remove $display_text_or_ref
($value, @more_values) = @{$menu_refs_ref->[$index]};
}


return (wantarray) ? ($value, @more_values) : $value;
}





sub ASK_password($$;$$)
{
my ($prompt_or_ref,
$digest,	    # Password encryption. if undef the password value is returned
$opt_checks_ref,    # optional: [ [ $check_func, $app_data_ref ]... ]
$help_or_ref,	    # optional: $help or [ @help ] or \&help_func
) = @_;
my $ok_or_value;




my ($level, $prompt) = deref_prompt( $prompt_or_ref);
$prompt .= ' '
if (index( ' )]', substr($prompt, -1, 1)) == -1);
$prompt .= '[]: ';

my $remain = 4;
do
{
ENV_reap_beeps();
my $password;
if ($IS_WIN32)
{
my $os_gbs_scripts = ENV_getenv( 'GBS_SCRIPTS_PATH');
my $command = "$os_gbs_scripts\\win32utils\\password.exe";

my ($prefix, undef) = ENV_get_prefix( $level);
my $command_items_ref = [ $command, "$prefix: $prompt" ];
my $password_text;
ENV_run3( $command_items_ref, undef, 0, \$password_text, undef);


if ($password_text =~ /^Password=<(.*)>$/)
{
$password = $1;
} else
{
ENV_sig( F => "Error calling '$command': ", "- $password_text");
}
} else
{
ENV_print( $level, $prompt);
system( "stty -echo");
chomp( $password = <STDIN>);
system( "stty echo");
ENV_say( 0, '');
}


if (!general_input_handling( $password, $help_or_ref))	# handle '?' and '!'
{
if (defined $digest && $digest ne '')
{
$ok_or_value = (crypt( $password, $digest) eq $digest);
if ($ok_or_value)
{
$remain = 0;	    # done
} else
{
$remain--;
if ($remain > 0)
{
print_error( "Password invalid - try again ($remain)");
} else
{
print_error( "Password invalid");
}
}
} else
{
$ok_or_value = $password;
$remain = 0;	    # done
}
}
} while ($remain > 0);

return $ok_or_value;
}




sub ASK_pause($)
{
my ($prompt_or_ref	    # may be undef
) = @_;

ENV_reap_beeps();

if (defined $prompt_or_ref)
{
my ($level, $prompt) = deref_prompt( $prompt_or_ref);
ENV_say( 1, $prompt);
}
ENV_say( 2, ''); $| = 1;   # and flush


my $command = ($IS_WIN32) ? 'pause' : 'read -r -p "Press <ENTER> to continue . . ." key;';
ENV_system( $command, 0);
}




sub gen_ask_fc_list($$$$)
{
my ($prompt_or_ref,
$default,			# uppercase
$possible_values_ref,		# [ Yes, No, Etc ]
$help_or_ref,			# optional: $help or [ @help ] or \&help_func
) = @_;
my $value;

my ($level, $prompt) = deref_prompt( $prompt_or_ref);

my @prompt_list;
my @allowed_values;
my @q_list;
foreach my $possible_value (@{$possible_values_ref})
{
my $fc = lc substr( $possible_value, 0, 1);
push @allowed_values, ($fc, uc $fc);
push @prompt_list, $fc;
push @q_list, "$fc=$possible_value";
}
my $prompt_list = join( '/', @prompt_list);
my $q_list = join( ', ', @q_list);
$prompt = "$prompt ($prompt_list)";
$prompt_or_ref = [ $level, $prompt ];


my $check_refs = [
[ \&check_allowed_values, \@allowed_values ],
];

$default = lc $default;
$help_or_ref = add_help( $help_or_ref, $q_list);
$value = gen_ask_s( $prompt_or_ref, $default, -1, $check_refs, $help_or_ref, 1);

return uc $value;
}





sub gen_ask_s($$$$$$)
{
my ($prompt_or_ref,
$default_or_ref,    # '', scalar or array_ref
$length,	    # >0 = max, <0 = min or [ $min, $max ]
$check_refs_ref,    # [ $check_func, $app_data ]...
$help_or_ref,
$must_echo_change,  # bool
) = @_;
my @values;




my $default_text = ENV_deref( $default_or_ref);

my $error_txt;
do
{



$error_txt = '';
my ($line, $full_prompt, $typed_line) = read_line( $prompt_or_ref, $default_text, $help_or_ref);
if (wantarray)
{
$line =~ s/\s*,\s*/ /g;
@values = split( ' ', $line);
} else
{
$values[0] = $line;
}




my @check_refs = ([ \&check_length, $length ],
@{$check_refs_ref},
);
foreach my $ref (@check_refs)
{
my ($check_func, $app_data_ref) = @{$ref};
$error_txt = $check_func->( \@values, \$default_text, $app_data_ref);   # call the check_function
$error_txt = ''
if (!defined $error_txt);
last
if ($error_txt ne '');
}




if ($must_echo_change)
{
ENV_say( 1, "$full_prompt@values")
if ($typed_line ne '' && "@values" ne $typed_line);
}




print_error( $error_txt)
if ($error_txt ne '');
} while ($error_txt ne '');

return (wantarray) ? @values : $values[0];
}




sub read_line($$$)
{
my ($prompt_or_ref,
$default_text,
$help_or_ref,  	#$help, @help, or &helpfunc
) = @_;
my ($line, $full_prompt, $typed_line);




my ($level, $prompt) = deref_prompt( $prompt_or_ref);
$prompt .= ' '
if (index( ' )]', substr($prompt, -1, 1)) == -1);
$full_prompt = "$prompt\[$default_text\]: ";

my $again;
do
{
ENV_reap_beeps();
$again = 0;




ENV_print( $level, $full_prompt);
$typed_line = <STDIN>;
$typed_line = "\a\n"
if (!defined $typed_line);	#SIGINT
chomp $typed_line;
$line = ($typed_line eq '') ? $default_text : $typed_line;
$line =~ s/\s+$//;		# remove trailing whitespace
$line =~ s/^\s+//;		# remove leading whitespace
} while (general_input_handling( $line, $help_or_ref));

return ( $line, $full_prompt, $typed_line);
}




sub general_input_handling($$)
{
my ($line,
$help_or_ref,
) = @_;
my $handled = 1;

if ($line eq '?')
{
my @help_lines = get_help_lines( $help_or_ref);
if (@help_lines)
{
map { ENV_say( 0, "  $_") } @help_lines;
} else
{
print_error( 'No help available');
}
} elsif ($line eq '!')
{
ENV_beep();
ENV_sig( WE => "Terminating...")
if (ASK_YN( 'Quit?', 'Y') eq 'Y');

} else
{
$handled = 0;
}

return $handled;
}




sub check_length($$$)
{
my ($values_ref,
$default_ref,
$app_data_ref,  	# $min_max_length or [ $min_length, $max_length ]
) = @_;
my $error_txt = '';

my @values = @{$values_ref};

$values[0] = ''
if (@values == 0);

foreach my $value (@values)
{
my $value_length = length( $value);
my ($min_length, $max_length) = min_max( $app_data_ref);

if ($max_length > 0)
{
if ($value_length > $max_length)
{
$error_txt = "Maximum length = $max_length ($value)";
last;
}
}
if ($min_length > 0)
{
if ($value_length <  $min_length)
{
if ($value_length == 0)
{
$error_txt = 'Empty reply not allowed here';
} else
{
$error_txt = "Minimum length = $min_length ($value)";
}
last;
}
}
}

return $error_txt;
}




sub check_and_set_menu_entry($$$)
{
my ($values_ref,	# Value will be changed
$default_ref,
$app_data_ref,	# [ @display_texts_or_refs ]
) = @_;
my $error_txt = '';


my @display_texts = map { (ref $_) ? "@{$_}" : $_ } @{$app_data_ref};
foreach my $value (@{$values_ref})
{
if ($value =~ /^\d+$/)   	# numeric
{
$value = $value * 1;
} else
{
my $m_line = quotemeta $value;
my $match_count = grep( /^$m_line/, @display_texts);

if ($match_count == 0)
{
$error_txt = "No match ($value)";
last;
} elsif ($match_count == 1)
{
$value = 0;

while ($display_texts[$value] !~ /^$m_line/)
{
$value++;
}
} else
{
$error_txt = "Ambiguous reply ($value)";
last;
}
}
}

return $error_txt;
}




sub check_and_set_wildcard_values($$$)
{
my ($values_ref,	# @values will be changed
$default_ref,
$app_data_ref,
) = @_;
my $error_txt = '';

my @non_matches;
my @new_values = ENV_wildcards( $values_ref, $app_data_ref, \@non_matches);
if (@non_matches)
{
$error_txt = "Unmatched wild-card(s): '@non_matches'";
} else
{
@{$values_ref} = @new_values;
}

return $error_txt;
}




sub check_and_set_uri($$$)
{
my ($values_ref,		# @values will be changed
$default_ref,
$allowed_schemes_ref,
) = @_;
my $error_text = '';

foreach my $uri (@{$values_ref})
{
if ($uri ne '')
{
$uri = URI_normalize( ENV_expand_envs( $uri), '', $allowed_schemes_ref, \$error_text);
last
if (defined $error_text);
}
}

return $error_text;
}



sub check_and_set_path($$$)
{
my ($values_ref,		# @values will be changed
$default_ref,
$must_exist,		# -1, 0 or 1
) = @_;
my $error_text = '';

foreach my $path (@{$values_ref})
{
if ($path ne '')
{
$path = ENV_perl_paths_noquotes( ENV_expand_envs( $path));
if (substr( $path, 0, 1) eq '.')
{
my $default = $$default_ref;
$path = ENV_perl_paths_noquotes( ENV_abs_paths( $default, $path));
}
}
}

$error_text = CHECK_path( 'Path', $values_ref, $must_exist);

return $error_text;
}




sub check_and_set_other_path($$$)
{
my ($values_ref,	# @values will be changed
$default_ref,
$app_data_ref,
) = @_;
my $error_text = '';

foreach my $path (@{$values_ref})
{
if ($path ne '')
{
if (substr( $path, 0, 1) eq '.')
{
my $default_path = $$default_ref;
$path = "$default_path/$path";
}
$path = ENV_perl_canon_paths( $path);
}
}

$error_text = CHECK_other_path( 'Path', $values_ref);

return $error_text;
}





sub check_dir($$$)
{
my ($values_ref,
$default_ref,
$app_data_ref,	    # [ $must_exist, $path ]
) = @_;
my $error_text = '';

my ($must_exist, $path) = @{$app_data_ref};

$error_text = CHECK_dir( 'Directory', $values_ref, $path, $must_exist);

return $error_text;
}





sub check_dirs($$$)
{
my ($values_ref,
$default_ref,
$app_data_ref,	    # [ $must_exist, $path ]
) = @_;
my $error_text = '';

my ($must_exist, $path) = @{$app_data_ref};

$error_text = CHECK_dirs( 'Directories', $values_ref, $path, $must_exist);

return $error_text;
}





sub check_file($$$)
{
my ($values_ref,
$default_ref,
$app_data_ref,	    # [ $must_exist, $path ]
) = @_;
my $error_text = '';

my ($must_exist, $path) = @{$app_data_ref};

$error_text = CHECK_file( 'File', $values_ref, $path, $must_exist);

return $error_text;
}





sub check_and_set_check_filespec($$$)
{
my ($values_ref,
$default_ref,
$app_data_ref,	    # [ $must_exist, '' ]
) = @_;
my $error_text = '';

my ($must_exist) = @{$app_data_ref};

foreach my $filespec (@{$values_ref})
{
if ($filespec ne '')
{
$filespec = ENV_perl_paths_noquotes( ENV_expand_envs( $filespec));
if (substr( $filespec, 0, 1) eq '.')
{
my $default = $$default_ref;
$filespec = ENV_perl_paths_noquotes( ENV_abs_paths( $default, $filespec));
}
}
}

$error_text = CHECK_filespec( 'Filespec', $values_ref, $must_exist);

return $error_text;
}




sub check_chars($$$)
{
my ($values_ref,
$default_ref,
$app_data_ref,
) = @_;
my $error_txt = '';

my ($valid_chars, $valid_chars_msg) = @{$app_data_ref};

foreach my $value (@{$values_ref})
{
if ($value ne '')
{

if ($value =~ /[^$valid_chars]/)
{
$error_txt = "Word may only contain '$valid_chars_msg' ($value)";
last;
}
}
}

return $error_txt;
}




sub check_bool($$$)
{
my ($values_ref,
$default_ref,
undef,		# not used
) = @_;
my $error_text = '';

$error_text = CHECK_convert_bool( 'Boolean Value', $values_ref);

return $error_text;
}




sub check_integer($$$)
{
my ($values_ref,
$default_ref,
undef,		# not used
) = @_;
my $error_text = '';

$error_text = CHECK_convert_int( 'Value', $values_ref);

return $error_text;
}




sub check_num_values($$$)
{
my ($values_ref,
$default_ref,
$possible_values_ref, 	    # 	# [ value, [ min, max ], ... ]
) = @_;
my $error_text = '';

$error_text = CHECK_int_range( undef, $values_ref, $possible_values_ref)
if (defined $possible_values_ref);

return $error_text;
}




sub check_string_values($$$)
{
my ($values_ref,
$default_ref,
$possible_values_ref, 	    # 	# [ value, [ min, max ], ... ]
) = @_;
my $error_text = '';


$error_text = CHECK_string_range( undef, $values_ref, $possible_values_ref)
if (defined $possible_values_ref);

return $error_text;
}




sub check_allowed_values($$$)
{
my ($values_ref,
$default_ref,
$valid_values_ref,
) = @_;
my $error_txt = '';

if (defined $values_ref && defined $valid_values_ref)
{
foreach my $value (@{$values_ref})
{
if ($value ne '')
{
if (LIST_firstidx_str( $value, $valid_values_ref) == -1)
{
$error_txt = "Must be one of (@{$valid_values_ref}) ($value)";
last;
}
}
}
}

return $error_txt;
}




sub check_not_allowed_values($$$)
{
my ($values_ref,
$default_ref,
$invalid_values_ref,
) = @_;
my $error_txt = '';

if (defined $invalid_values_ref)
{
foreach my $value (@{$values_ref})
{
if ($value ne '')
{
if (grep( $_ eq $value, @{$invalid_values_ref}))
{
$error_txt = "'$value' not allowed";
last;
}
}
}
}

return $error_txt;
}




sub check_duplicate_values($$$)
{
my ($values_ref,
$default_ref,
$app_data_ref,	    # undef
) = @_;
my $error_txt = '';

foreach my $value (@{$values_ref})
{
if ($value ne '')
{
if (grep( $value eq $_, @{$values_ref}) > 1)
{
$error_txt = "'$value' may appear only once";
last;
}
}
}

return $error_txt;
}




sub check_time($$$)
{
my ($values_ref,
$default_ref,
$app_data_ref,
) = @_;
my $error_text = '';

$error_text = CHECK_convert_time( 'Time', $values_ref);

return $error_text;
}





sub check_date($$$)
{
my ($values_ref,
$default_ref,
$app_data_ref,
) = @_;
my $error_text = '';

$error_text = CHECK_convert_date( 'Date', $values_ref);

return $error_text;
}




sub handle_menu($$$$$)
{
my ($prompt_ref,		# [ $level, $prompt, $help_or_ref ]
$default_index_or_ref,	# ref == default_value, -1 == no default, 0 = first
$format_ref,		# May be undef. Formats: L R
$menu_refs_ref,	    	# [ $display_text_or_ref, ...,



$help_or_ref,		# undef=ok. $help or [ @help ] or \&help_func
) = @_;
my $index;

foreach my $ref (@{$menu_refs_ref})
{
$ref = [ $ref, $ref ]
if (!ref $ref);
}
my @display_texts_or_refs = map { $_->[0] } @{$menu_refs_ref};
my $start_index = 1;
if ($display_texts_or_refs[0] eq '')
{
$display_texts_or_refs[0] = '<None>';
$start_index = 0;
} elsif ($display_texts_or_refs[0] =~ /^<.*>$/)
{
$start_index = 0;
}

my $default_index;
if (ref $default_index_or_ref)
{
my $default_value = $$default_index_or_ref;
if (defined $default_value)
{

$default_index = LIST_firstidx_ref_str( $default_value, $menu_refs_ref, 1);
} else
{
$default_index = -1;
}
} else
{
$default_index = $default_index_or_ref;
}
$default_index = 0
if ($start_index == 0 && $default_index == -1);

show_menu( $prompt_ref, $start_index, $default_index, $format_ref, \@display_texts_or_refs);

unshift @display_texts_or_refs, ''
if ($start_index == 1);  # array starts at '1'
my $max_index = @{$menu_refs_ref} - 1 + $start_index;
my $default_txt = ($default_index == -1) ? '' : $default_index + $start_index;
my $choice_prompt = "Choice ($start_index-$max_index)";

my $check_refs = [
[ \&check_and_set_menu_entry, \@display_texts_or_refs ],
[ \&check_num_values, [ [ $start_index, $max_index ] ] ],
];

my $index_value = gen_ask_s( $choice_prompt, $default_txt, -1, $check_refs, $help_or_ref, 1);

$index = $index_value - $start_index;

return $index;
}




sub show_menu($$$$$)
{
my ($prompt_ref,		    # [ $level, $prompt, $help_or_ref ]
$first_index,		    # (0 or 1)
$default_index,		    # -1 == none
$format_ref,		    # undef or [R, L]
$display_texts_or_refs_ref,
) = @_;




{
my ($level, $prompt, $help_or_ref) = @{$prompt_ref};
my @prompt_lines = ($prompt, get_help_lines( $help_or_ref));
ENV_say( $level, @prompt_lines);
}




my $default_count = $first_index + $default_index;
my @list_lines;
{
my $count = $first_index;
my @row_refs;
foreach my $text_or_ref (@{$display_texts_or_refs_ref})
{
my @texts = (ref $text_or_ref) ? @{$text_or_ref} : ($text_or_ref);
my ($leading_newlines) = $texts[0] =~ /^(\n+)/;
if (defined $leading_newlines)
{
$texts[0] =~ s/^\n+//;
map { push @row_refs, [ "\n" ] } (1 .. length( $leading_newlines));
}
my $arrow = ($count == $default_count) ? '->' : '  ';
push @row_refs, [ "$arrow$count.", @texts ];
$count++;
}

my @format = ('R');		# for the $count part
push @format, @{$format_ref}
if (defined $format_ref);
@list_lines = FORMAT_table( 0, 0, ' ', [ @format ], @row_refs);

}

@list_lines = FORMAT_cols( 0, 0, ' | ', 3, [ @list_lines ]);
ENV_say( 0, @list_lines);
}




sub show_files($)
{
my ($path,
) = @_;
my @lines;

if ($path)
{
push @lines, "Path: $path";
foreach my $file (sort( ENV_readdir( $path, 1)))	    # 1 == $include_dot_files
{
next
if (substr( $file, 0, 1) eq '.');
my $type;
if (-d "$path/$file")
{
$type = 'd';
} elsif (-f _)
{
$type = 'f';
} else
{
$type = '~';
}
push @lines, "-$type $file";
}
}

return @lines;
}




sub opt_checks($)
{
my ($opt_checks_ref,
) = @_;
my @refs = ();

if ($opt_checks_ref)
{


if (ref $opt_checks_ref->[0] eq 'ARRAY')
{
@refs = @{$opt_checks_ref};
} else
{
@refs = ($opt_checks_ref);
}
}
return @refs;
}




sub add_help($$)
{
my ($help_or_ref,
$extra_help,
) = @_;


if (defined $help_or_ref)
{
if (ref $help_or_ref eq 'ARRAY')
{
push @{$help_or_ref}, $extra_help;
} elsif (ref $help_or_ref eq 'CODE')
{
$help_or_ref = [ $help_or_ref, $extra_help ];
} else # SCALAR
{
$help_or_ref = [ $help_or_ref, $extra_help ];
}
} else
{
$help_or_ref = $extra_help;
}

return $help_or_ref;
}




sub get_help_lines($)
{
my ($help_or_ref,
) = @_;

my @help_lines;
if (defined $help_or_ref)
{
$help_or_ref = [ $help_or_ref ]
if (ref $help_or_ref ne 'ARRAY');
foreach my $help (@{$help_or_ref})
{
if (ref $help eq 'CODE')
{
push @help_lines, $help->();
} else
{
push @help_lines, $help;
}
}
}

return @help_lines;
}




sub min_max($)
{
my ($min_max_ref,
) = @_;
my ($min, $max) = (0, 0);

if (defined $min_max_ref)
{
if (ref $min_max_ref)
{
($min, $max) = @{$min_max_ref};
} else
{
if ($min_max_ref > 0)
{
$max = $min_max_ref;
} else
{
$min = abs $min_max_ref;
}
}
}
return ($min, $max);
}




sub local_prompt($$)
{
my ($prompt_or_ref,
$original_prompt,
) = @_;
my $local_prompt_ref;

my ($level, $prompt) = deref_prompt( $prompt_or_ref);
my ($leading_spaces) = $original_prompt =~ /^(\s*)/;
my $local_prompt = "$leading_spaces$prompt";
$local_prompt_ref = [ $level, $local_prompt ];

return $local_prompt_ref;
}




sub print_error($)
{
my ($line_or_ref,
) = @_;

ENV_beep();
my @lines = (ref $line_or_ref) ? @{$line_or_ref} : ($line_or_ref);
ENV_say( 2, '- ' . shift @lines);
map { ENV_say( 2, "  $_") } @lines;
}




sub deref_prompt($)
{
my ($prompt_or_ref,
) = @_;


if (ref $prompt_or_ref)
{

ENV_stackdump()
if (ref $prompt_or_ref ne 'ARRAY');
my @values = @{$prompt_or_ref};
unshift @values, 1
if ($values[0] !~ /^\d+$/);
return @values;
} else
{
return (1, $prompt_or_ref);
}
}




sub quit()
{
ENV_say( 1, 'Quitting...');
ENV_exit();
}

1;
