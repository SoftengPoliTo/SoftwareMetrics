#=================================================
#
#   log.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::log;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
LOG_main
);
}




use glo::env;
use glo::list;
use glo::slurp;
use glo::spit;
use glo::ask;
use glo::time;
use mod::gbsres;
use mod::logsum;
use mod::gbssyssum;




sub LOG_main($$$);

sub menu_fix_log($$$);
sub fix_log($);
sub menu_fix_sum_files($$$);
sub fix_sum_files($);
sub fix_sum_file($);
sub menu_fix_html_files($$$);
sub fix_html_files($);
sub fix_html_file($);
sub menu_create_missing_sum_files($$$);
sub create_missing_sum_files($);
sub create_missing_sum_file($);
sub analyze_logfile($);
sub menu_recreate_gbssyssum($$$);
sub recreate_gbssyssum($);
sub menu_prune_html_files($$$);
sub menu_prune_log_files($$$);
sub menu_distribute_all_log_files($$$);
sub distribute_html_files($);
sub distribute_log_files($);
sub move_log_files($$$);
sub move_files($$$);
sub ask_log_path($);
sub print_selection($$);
sub sort_specs_on_numtime($);
sub subtract_days($$);












my $DEFAULT_LOG_PATH = $GBS::LOG_PATH;




sub LOG_main($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;

my @main_menu_items = (
[ "Fix Current Log Files ($GBS::ROOT_PARENT)",		    \&menu_fix_log, $GBS::ROOT_PARENT		],
[ "Fix All     Log Files",				    \&menu_fix_log, undef		   	],

[ "\nFix Summary (.log.sum) Files",			    \&menu_fix_sum_files,			],
[ "Fix gbsaudit html Files",				    \&menu_fix_html_files			],
[ 'Create missing Summary (.sum) Files',		    \&menu_create_missing_sum_files,	        ],
[ 'Re-create Silo gbssyssum.log',			    \&menu_recreate_gbssyssum, $GBS::LOG_PATH    ],

[ "\nPrune gbsaudit Summary files (html)",		    \&menu_prune_html_files			],
[ 'Prune Log files (.log, .log.sum, .log.err)',		    \&menu_prune_log_files			],

[ "\nDistribute all Log Files from ROOT to various PATHs",  \&menu_distribute_all_log_files, $GBS::LOG_ROOT ],
);

ASK_menu( 'Select function to perform', \@main_menu_items, $entries_ref);
}




sub menu_fix_log($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref,
) = @_;

fix_log( $data_ref);
}




sub fix_log($)
{
my ($root_parent_or_undef) = @_;

my @root_parents;
if (defined $root_parent_or_undef)
{
@root_parents = ($root_parent_or_undef);
ENV_say( 1, "Fix Current Log Files (@root_parents)");
} else
{
@root_parents = SLURP_dir_dirs( $GBS::LOG_ROOT, 0);	# do not include dot files
ENV_say( 1, 'Fix All Log Files', "@root_parents");
}

if (@root_parents)
{
my $do_parent = 'Y';
foreach my $root_parent (@root_parents)
{
if (@root_parents > 1 && $do_parent ne 'A')
{
$do_parent = ASK_YNAEQ( "Fix Parent $root_parent?", 'Y', 1);	# $exit_on_quit
}
if ($do_parent eq 'Y' || $do_parent eq 'A')
{
ENV_say( 2, "Fixing Parent '$root_parent'");

my $log_path = "$GBS::LOG_ROOT/$root_parent";
fix_sum_files( $log_path);
create_missing_sum_files( $log_path);
fix_html_files( $log_path);
recreate_gbssyssum( $log_path);
} elsif ($do_parent eq 'E')
{
last;
}
}
} else
{
ENV_say( 2, 'No Log Parents found');
}
}




sub menu_fix_sum_files($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref,
) = @_;

fix_sum_files( $data_ref);
}




sub fix_sum_files($)
{
my ($log_path) = @_;    # may be undef

$log_path = ask_log_path( 'Path')
if (!defined $log_path);

if (defined $log_path)
{
ENV_say( 1, "Fix Sum Files: $log_path...");

my @sum_files = ENV_glob( "$log_path/gbssys*.log.sum");
my $nr_files = @sum_files;
if ($nr_files > 0)
{
ENV_say( 2, "Found $nr_files Log Summary Files");
LOGSUM_reset();

my $fixed = 0;
foreach my $sum_filespec (@sum_files)
{
$fixed += fix_sum_file( $sum_filespec);
}
ENV_say( 1, "Fixed $fixed .log.sum files");
} else
{
ENV_say( 1, 'No Log Summary files found');
}
}
}




sub fix_sum_file($)
{
my ($sum_filespec,
) = @_;
my $fixed = 0;


my ($sum_file_path, $sum_file) = ENV_split_spec_pf( $sum_filespec);
my ($sum_file_name) = $sum_file =~ /^(.*)\.log\.sum$/;
my @sum_lines = LOGSUM_read( $sum_filespec);
my ($sum_jobname, $sum_build_or_tool, $sum_uname) = @sum_lines[0..2];
if ($sum_jobname eq '' || $sum_build_or_tool eq '' || $sum_uname eq '')
{
ENV_say( 3, "Logfile:$sum_filespec messed-up",
"- find and analyze .log file...");
my $log_filespec = "$sum_file_path/$sum_file_name.log";
if (-e $log_filespec)
{
my @sum_items = analyze_logfile( $log_filespec);
if (@sum_items)
{
LOGSUM_write( $sum_filespec, \@sum_items);
$fixed = 1;
ENV_say( 4, "Created $sum_filespec");
}
} else
{
ENV_say( 3, 'File not found');
}
} else
{
my $sum_log_spec = ENV_perl_paths( $sum_lines[4]);
my ($sum_log_path, $sum_log_file) = ENV_split_spec_pf( $sum_log_spec);
if ($sum_log_path ne $sum_file_path)
{

LOGSUM_update_logfile_spec( $sum_filespec, "$sum_file_path/$sum_file_name.log");
$fixed = 1;
}
}

return $fixed;
}




sub menu_fix_html_files($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref,
) = @_;

fix_html_files( $data_ref);
}




sub fix_html_files($)
{
my ($log_path) = @_;    # may be undef

$log_path = ask_log_path( 'Path')
if (!defined $log_path);

if (defined $log_path)
{
ENV_say( 1, "Fix gbsaudit .html Files: $log_path...");

my @html_files = ENV_glob( "$log_path/gbsaudit_*.html");
my $nr_files = @html_files;
if ($nr_files > 0)
{
ENV_say( 2, "Found $nr_files gbsaudit_*.html Files");

my $fixed = 0;
foreach my $html_filespec (@html_files)
{
$fixed += fix_html_file( $html_filespec);

}
ENV_say( 1, "Fixed $fixed .html files");
} else
{
ENV_say( 1, 'No gbsaudit_*.html found');
}
}
}




sub fix_html_file($)
{
my ($html_filespec,
) = @_;
my $fixed = 0;


my @lines = SLURP_file( $html_filespec);
my $location_line = $lines[1];

my ($old_filespec) = $location_line =~ /^<!-- (.+) -->$/;
if (defined $old_filespec)
{
if ($old_filespec ne $html_filespec)
{
$lines[1] = "<!-- $html_filespec -->";
my $new_path = ENV_split_spec_p( $html_filespec);
my $old_path = ENV_split_spec_p( $old_filespec);
foreach my $line (@lines)
{
my @hrefs = $line =~ /\s(HREF|SRC)="(\.\.[^"]+)"/ig;
if (@hrefs)
{
my $short_line = $line;
$short_line =~ s/^\s*//;

while (@hrefs)
{
my $type = shift @hrefs;
my $href = shift @hrefs;

my $old_abs_spec = ENV_canonicalize_paths( "$old_path/$href");
my $new_rel_spec = ENV_rel_paths( $new_path, $old_abs_spec);


$line =~ s/$type="$href"/$type="$new_rel_spec"/;

}
}
}
SPIT_file_nl( $html_filespec, \@lines);
$fixed = 1;
}
} else
{
ENV_say( 2, 'Cannot determine old location - Skipped',
$html_filespec,
$location_line);
}

return $fixed;
}




sub menu_create_missing_sum_files($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref,
) = @_;

create_missing_sum_files( $data_ref);
}




sub create_missing_sum_files($)
{
my ($log_path) = @_;    # may be undef

$log_path = ask_log_path( 'Path')
if (!defined $log_path);

if (defined $log_path)
{
ENV_say( 1, "Create missing Sum Files: $log_path...");
my @log_files = ENV_glob( "$log_path/*.log");
my $nr_files = @log_files;
if ($nr_files > 0)
{
ENV_say( 2, "Found $nr_files .log Files");
LOGSUM_reset();

my $created = 0;
foreach my $log_filespec (@log_files)
{
$created += create_missing_sum_file( $log_filespec);
}
ENV_say( 1, "Created $created .log.sum files");
} else
{
ENV_say( 1, 'No logfiles found');
}
}
}




sub create_missing_sum_file($)
{
my ($log_filespec,
) = @_;
my $created = 0;

my ($log_file_name) = $log_filespec =~ m!.*/(.*)\.log$!;
my $sum_filespec = "$log_filespec.sum";
if (!-e $sum_filespec)
{
ENV_say( 3, "Logfile:$log_filespec .sum file missing",
"- analyze .log file to create .sum file...");
my @sum_items = analyze_logfile( $log_filespec);
if (@sum_items)
{
LOGSUM_write( $sum_filespec, \@sum_items);
$created++;
} else
{
ENV_say( 3, '- Not possible to create .sum file');
}
}

return $created;
}




sub analyze_logfile($)
{
my ($log_filespec) = @_;
my @sum_items;

my @log_lines = SLURP_file( $log_filespec);
my @lines = grep( /^=== /, @log_lines);
if (@lines)
{
@lines = grep( $_ !~ /G E N E R I C/, @lines);


my %items;

my $last_title;
foreach my $line (@lines)
{
my ($title, $value) = $line =~ /^=== (\S+):\s*(.*)/;
if (defined $title)
{
$items{$title} = $value;
$last_title = $title;
} else
{
($value) = $line =~ /^===\s+(.*)/;
$items{$last_title} .= " $value";
}
}
if (keys %items > 5)
{

my ($jobname,	    # gbssysbuild, gbssysmake, gbssysaudit, gbssystool
$build_or_tool,
$uname,
$os_root_spec,
$os_logfile_spec,   # $GBS::LOG_PATH/$jobname_$build_$audit_$datetime.log
$time_start,	    # YYYY-MM-DD hh:mm:ss
$pid_or_time_end,   # YYYY-MM-DD hh:mm:ss
$time_diff,	    # hhh:mm:ss
$timer_diff,	    # "$clock $cpu_system $cpu_user $cpu_all" in seconds
$state,		    # START NORMAL FAILED KILLED
$rc,		    # Numeric
$audit,
$date_time,	    # YYMMDD-hhmmss as used in $logfile_name
$command_args,
$comment,
);
my $value;
$value = $items{JOB};
if (defined $value)
{
($jobname, $build_or_tool, $audit) = $value =~ m!(\S+) \((\S+) / (\S+)\)!;
($jobname, $build_or_tool) = $value =~ m!(\S+) \((\S+)!
if (!defined $jobname);
($jobname) = $value =~ m!(\S+)!
if (!defined $jobname);
}

$uname = $items{HOST};
$os_root_spec = $items{ROOT};
$os_logfile_spec = $items{LOGFILE};
$time_start = $items{START};
$pid_or_time_end = $items{END};
$time_diff = $items{ELAPSED};

$value = $items{USAGE};
if (defined $value)
{

my (@values) = $value =~ /Clock: (\d+) .*, System: ([\d.]+), User: ([\d.]+), Total: ([\d.]+)/;
foreach my $value (@values)
{
$value =~ s/\.//;
$value = $value * 1;
}

$timer_diff = "@values";
}

$value = $items{STATUS};
if (defined $value)
{
($state, $rc) = $value =~ /(\S+)\s+\(\d+\)/;
if (!defined $state)
{
$state = 'FAILED';
$rc = 255;
}
} else
{
if ($log_lines[-1] =~ /Terminating on signal/ ||
$log_lines[-2] =~ /Terminating on signal/ ||
$log_lines[-3] =~ /Terminating on signal/)
{
$state = 'KILLED';
} else
{
$state = 'FAILED';
}
$rc = 255;
}

$date_time = GBSRES_get_logfile_numtime( $log_filespec);
$date_time = TIME_time2num_packed()
if (!defined $date_time);

$command_args = $items{ARGS};
$comment = $items{COMMENT};

@sum_items = ($jobname, $build_or_tool, $uname, $os_root_spec, $os_logfile_spec, $time_start,
$pid_or_time_end, $time_diff, $timer_diff, $state, $rc, $audit, $date_time, $command_args,
$comment);
foreach my $item (@sum_items)
{
$item = ''
if (!defined $item);
}

} else
{
ENV_say( 2, '  Logfile does not contain enough valid data');
}

} else
{
ENV_say( 2, '  No valid data in logfile');
}

return @sum_items;
}




sub menu_recreate_gbssyssum($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref,
) = @_;

recreate_gbssyssum( $data_ref);
}




sub recreate_gbssyssum($)
{
my ($log_path) = @_;    # may be undef

$log_path = ask_log_path( 'Path')
if (!defined $log_path);

GBSSYSSUM_recreate( $log_path)
if (defined $log_path);
}




sub menu_prune_html_files($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref,
) = @_;

my $log_path = $data_ref;    # may be undef

$log_path = ask_log_path( 'Path')
if (!defined $log_path);

if (defined $log_path)
{
ENV_say( 1, "Prune gbsaudit .html files: $log_path...");

my @html_filespecs = ENV_glob( "$log_path/gbsaudit_*_sum.html");
my $nr_files = @html_filespecs;
if ($nr_files > 0)
{
ENV_say( 2, "Found $nr_files gbsaudit_*_sum.html files");
my $today = TIME_time2numdate();	# now
my $build_wild = ASK_wild_words( 'Build(s) to prune (wildcard allowed)', '*', -1);
my $audit_wild = ASK_wild_words( 'Audit(s) to prune (wildcard allowed)', '*', -1);
my @pre_selected_files = ENV_glob_files( "$log_path/gbsaudit_${build_wild}_${audit_wild}_*_sum.html");
@pre_selected_files = sort_specs_on_numtime( \@pre_selected_files);
print_selection( \@pre_selected_files, 'pre-selected');
if (@pre_selected_files)
{
my $default_from_date = TIME_unpack_date( GBSRES_get_logfile_numtime( $pre_selected_files[0]));
my $from_date = ASK_date( 'From date', $default_from_date, undef, [ [ $default_from_date , $today ] ]);
my $default_to_date = subtract_days( $today, 7);
$default_to_date = $from_date
if ($from_date ne '' && $from_date gt $default_to_date);
$default_to_date = ''
if ($default_to_date eq $default_from_date);

my $to_date   = ASK_date( 'To   date', $default_to_date, undef, [ [ $from_date, $today ] ]);

my @selected_files;
if ($from_date eq '' && $to_date eq '')
{
@selected_files = @pre_selected_files;
} else
{
foreach my $file (@pre_selected_files)
{
my $num_date = TIME_unpack_date( GBSRES_get_logfile_numtime( $file));
my $skip = 0;
$skip = 1
if ($from_date ne '' && $num_date lt $from_date);
$skip = 1
if ($to_date ne '' && $num_date gt $to_date);
push @selected_files, $file
if (!$skip);

}
}
my $nr_files = @selected_files;
if ($nr_files > 0)
{
print_selection( \@selected_files, 'selected');
if (ASK_YNQ( "Move selected $nr_files files to ./pruned directory?", 'N', 1) eq 'Y')	#exit on quit
{
my $nr_moved_files = 0;
ENV_say( 1, 'Moving...');
foreach my $file (@selected_files)
{
my $file_name = substr( $file, 0, -5);	# remove '.html'
my @files = ($file, ENV_glob_files( "$log_path/$file_name.*.html"));


$nr_moved_files += move_files( $log_path, \@files, "$log_path/pruned");
}
ENV_say( 2, "Moved $nr_moved_files .html files");
}
} else
{
ENV_say( 2, 'No files selected');
}
}
} else
{
ENV_say( 2, 'No .html files found');
}
}
}




sub menu_prune_log_files($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref,
) = @_;

my $log_path = $data_ref;    # may be undef

$log_path = ask_log_path( 'Path')
if (!defined $log_path);

if (defined $log_path)
{
ENV_say( 1, "Prune gbssys* .log files: $log_path...");

my @sum_filespecs = ENV_glob( "$log_path/gbssys*_*_*.log.sum");
my $nr_files = @sum_filespecs;
if ($nr_files > 0)
{
ENV_say( 2, "Found $nr_files gbssys*_*_*.log.sum files");
my $today = TIME_time2numdate();	# now
my $command_wild = ASK_wild_words( 'Command(s) to prune (wildcard allowed)', '*', -1);
my $build_wild = ASK_wild_words( 'Build(s) to prune (wildcard allowed)', '*', -1);
my $audit_wild = ASK_wild_words( 'Audit(s) to prune (wildcard allowed)', '*', -1);
my @pre_selected_files = ENV_glob_files( "$log_path/gbssys${command_wild}_${build_wild}_${audit_wild}_*.log.sum");
@pre_selected_files = sort_specs_on_numtime( \@pre_selected_files);
print_selection( \@pre_selected_files, 'pre-selected');
if (@pre_selected_files)
{
my $default_from_date = TIME_unpack_date( GBSRES_get_logfile_numtime( $pre_selected_files[0]));
my $from_date = ASK_date( 'From date', $default_from_date, undef, [ [ $default_from_date , $today ] ]);
my $default_to_date = subtract_days( $today, 180);
$default_to_date = $from_date
if ($from_date ne '' && $from_date gt $default_to_date);
$default_to_date = ''
if ($default_to_date eq $default_from_date);

my $to_date   = ASK_date( 'To   date', $default_to_date, undef, [ [ $from_date, $today ] ]);

my @selected_files;
if ($from_date eq '' && $to_date eq '')
{
@selected_files = @pre_selected_files;
} else
{
foreach my $file (@pre_selected_files)
{
my $num_date = TIME_unpack_date( GBSRES_get_logfile_numtime( $file));
my $skip = 0;
$skip = 1
if ($from_date ne '' && $num_date lt $from_date);
$skip = 1
if ($to_date ne '' && $num_date gt $to_date);
push @selected_files, $file
if (!$skip);

}
}
my $nr_files = @selected_files;
if ($nr_files > 0)
{
print_selection( \@selected_files, 'selected');
if (ASK_YNQ( "Move selected $nr_files files to ./pruned directory?", 'N', 1) eq 'Y')	#exit on quit
{
my $nr_moved_files = 0;
ENV_say( 1, 'Moving...');
foreach my $file (@selected_files)
{
$nr_moved_files += move_log_files( $log_path, $file, "$log_path/pruned");
}
ENV_say( 2, "Moved $nr_moved_files .log files");
recreate_gbssyssum( $log_path);
}
} else
{
ENV_say( 2, 'No files selected');
}
}
} else
{
ENV_say( 2, 'No .log files found');
}
}
}





sub menu_distribute_all_log_files($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref,
) = @_;

my $log_root = $data_ref;    # may be undef

$log_root = ask_log_path( 'Root')
if (!defined $log_root);

if (defined $log_root)
{
ENV_say( 1, "Move Log files: $log_root...");
my @parents;




push @parents, distribute_html_files( $log_root);




push @parents, distribute_log_files( $log_root);




my @filespecs = SLURP_dir_files( $log_root, 0);	    # do not include dot files
print_selection( \@filespecs, 'remaining');




if (@parents)
{
LIST_unique( \@parents);
@parents = sort @parents;
ENV_say( 1, "Fixing moved files in parent-dirs:", "@parents");
foreach my $parent (@parents)
{
fix_log( $parent);
}
}
}
}




sub distribute_html_files($)
{
my ($log_root,
) = @_;
my %parents;	# only the keys are retuned

my @html_filespecs = ENV_glob( "$log_root/gbsaudit_*.html");
my $nr_files = @html_filespecs;
if ($nr_files > 0)
{
ENV_say( 2, "Found $nr_files gbsysaudit_*.html Files");

my $nr_renamed = 0;
foreach my $html_filespec (@html_filespecs)
{
my @lines = SLURP_file_head( $html_filespec, 6);
my $line = $lines[5];

my (undef, $parent_dir) = $line =~ m!("|/)([^/]*)/silo/!;
if (defined $parent_dir)
{
my $file = ENV_split_spec_f( $html_filespec);
$nr_renamed += move_files( $log_root, [$file], "$log_root/$parent_dir");
$parents{$parent_dir} = 1;
} else
{
ENV_say( 3, "Invalid line - File skipped", $html_filespec, $line);
}
}
ENV_say( 2, "Moved $nr_renamed files");
} else
{
ENV_say( 2, "No gbsysaudit_*.html Files found");
}

return keys %parents;
}






sub distribute_log_files($)
{
my ($log_root,
) = @_;
my %parents;	# only the keys are retuned

my @log_sum_filespecs = ENV_glob( "$log_root/gbssys*.log.sum");
my $nr_files = @log_sum_filespecs;
if ($nr_files > 0)
{
ENV_say( 2, "Found $nr_files gbssys*.log.sum Files");
LOGSUM_reset();

my $nr_renamed = 0;
foreach my $log_sum_filespec (@log_sum_filespecs)
{

my $os_logfile_spec = LOGSUM_get_os_logfile_spec( $log_sum_filespec);
if ($os_logfile_spec ne '')
{
my $os_root_spec = ENV_perl_paths( LOGSUM_get_os_root_spec( $log_sum_filespec));
my ($parent_dir) = $os_root_spec =~ m!.*/(.*)!;
my $log_sum_file = ENV_split_spec_f( $log_sum_filespec);

$nr_renamed += move_log_files( $log_root, $log_sum_file, "$log_root/$parent_dir");
$parents{$parent_dir} = 1;
} else
{
ENV_say( 3, "Empty .log.sum file - Skipped", "- $log_sum_filespec");
}
}
ENV_say( 2, "Moved $nr_renamed files");
}
{
ENV_say( 2, "No gbssys*.log.sum Files found");
}

return keys %parents;
}




sub move_log_files($$$)
{
my ($from_path,
$log_sum_file,		# *.log.sum
$to_path,
) = @_;
my $nr_renamed = 0;

my $log_file = substr( $log_sum_file, 0, -4);	# remove .sum
my @files_to_rename;
push @files_to_rename, $log_file
if (-e "$from_path/$log_file");
push @files_to_rename, "$log_file.sum"
if (-e "$from_path/$log_file.sum");
push @files_to_rename, "$log_file.err"
if (-e "$from_path/$log_file.err");
$nr_renamed += move_files( $from_path, \@files_to_rename, $to_path);

return $nr_renamed;
}




sub move_files($$$)
{
my ($from_path,
$files_ref,	# files_to_rename
$to_path,	# "$log_root/$parent_dir"
) = @_;
my $nr_renamed = 0;

mkdir $to_path;
foreach my $file (@{$files_ref})
{
my $in_spec = "$from_path/$file";
my $out_spec = "$to_path/$file";
if (rename( $in_spec, $out_spec))
{
$nr_renamed++;
} else
{
ENV_sig( E => "Cannot move", "  '$in_spec' to", "  '$out_spec'", "  - $!");
}
}

return $nr_renamed;
}




sub ask_log_path($)
{
my ($root_or_path) = @_;	# 'Root' or 'Path'
my $log_path;

my @choice = ( '',
"Current LOG ROOT ($GBS::LOG_ROOT",
"Current LOG PATH ($GBS::LOG_PATH)",
"Specify LOG Parent ($GBS::ROOT_PARENT)",
'Specify LOG Path',
);
my $default_index = ($root_or_path eq 'Path') ? 2 : 1;

my $index = ASK_index_from_menu( "Select Log $root_or_path", $default_index, undef, [ @choice ]);
if ($index == 0)
{
$log_path = undef;
} elsif ($index == 1)
{
$log_path = $GBS::LOG_ROOT;
} elsif ($index == 2)
{
$log_path = $GBS::LOG_PATH;
} elsif ($index == 3)
{
my $parent_dir = ASK_dir( "Enter existing LOG Parent", $GBS::ROOT_PARENT, 0, 1, $GBS::LOG_ROOT);   # $length, $must_exist, $path
$log_path = "$GBS::LOG_ROOT/$parent_dir";
} else  #($index == 4)
{
$log_path = ASK_path( "Enter existing LOG Directory", $DEFAULT_LOG_PATH, 0, 1);   # $length, $must_exist
}

$DEFAULT_LOG_PATH = $log_path
if (defined $log_path);

return $log_path;
}




sub print_selection($$)
{
my ($list_ref,
$verb,		    # e.g.: 'selected', 'remaining', 'deleted', etc
) = @_;

my $nr_files = @{$list_ref};
if ($nr_files == 0)
{
ENV_say( 1, "No files $verb");
} elsif ($nr_files <= 10)
{
ENV_say( 1, "$nr_files files $verb", $list_ref);
} else # $nr_files > 10
{
ENV_say( 1, "$nr_files files $verb", (@{$list_ref}[ 0..4], '...', @{$list_ref}[-5..-1]));
}
}





sub sort_specs_on_numtime($)
{
my ($specs_ref) = @_;	# Also names only
my @sorted_specs;

my @spec_refs;

foreach my $spec (@{$specs_ref})
{
my $numtime = GBSRES_get_logfile_numtime( $spec);
push @spec_refs, [ $numtime, $spec ]
if (defined $numtime);
}
map { push @sorted_specs, $_->[1] } sort { $a->[0] cmp $b->[0] } @spec_refs;	    # ascending

return @sorted_specs;
}




sub subtract_days($$)
{
my ($numtime,
$days,
) = @_;
my $new_numtime;

my $time = TIME_num2time( $numtime);
my $seconds = $days * 24 * 60 * 60;
my $new_time = $time - $seconds;
$new_numtime = TIME_time2numdate( $new_time);


return $new_numtime;
}

1;
