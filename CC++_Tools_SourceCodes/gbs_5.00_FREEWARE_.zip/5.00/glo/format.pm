#=================================================
#
#   format.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::format;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
FORMAT_cols
FORMAT_table
FORMAT_indent
FORMAT_hanging
);
}




use glo::env;




sub FORMAT_cols($$$$$);
sub FORMAT_table($$$$@);
sub FORMAT_indent($$@);
sub FORMAT_hanging($$$$);

sub get_width($);








sub FORMAT_cols($$$$$)
{
my ($width,			# 0 = term-width, <0 = term_width - $width, undef == anylength
$l_margin,		# size
$separator,		# string
$min_rows,		# minimum number of rows
$items_ref,		# [ @items ]
) = @_;
my @out_lines;

$width = get_width( $width);
my $table_width = $width - $l_margin;
my $separator_l = length $separator;
my $nr_items = scalar @{$items_ref};




my $max_item_l = 1;
map { $max_item_l = length $_ if (length $_ > $max_item_l) } @{$items_ref};




my $nr_cols = ($table_width + $separator_l) / ($max_item_l + $separator_l);
$nr_cols = 1
if ($nr_cols < 1);
my $nr_rows = ($nr_items + $nr_cols - 1) / $nr_cols;



if ($nr_rows < $min_rows)
{
$nr_cols = ( $nr_items + 1 ) / $min_rows;
$nr_cols = 1
if ($nr_cols < 1);
$nr_rows = ($nr_items + $nr_cols - 1) / $nr_cols;



}





my $l_margin_spaces = ' ' x $l_margin;
if ($nr_cols > 1)
{
for (my $r = 0; $r < $nr_rows; $r++)
{
my $out = $l_margin_spaces;
for (my $c = 0; $c < $nr_cols; $c++)
{
my $item = $items_ref->[$r + $nr_rows * $c];
$out .= $separator if ($c != 0);
$item = ''
if (!defined $item);
$out .= sprintf "%-${max_item_l}s", $item;
}
push @out_lines, $out;
}
} else
{
@out_lines = map { "$l_margin_spaces$_" } @{$items_ref};
}

return @out_lines;
}





sub FORMAT_table($$$$@)
{
my ($width,			# 0 = term-width, <0 = term_width - $width, undef == anylength
$l_margin,		# size
$separator,		# string
$formats_ref,		# May be undef. Formats: L R
@row_refs,		# rows that are undef are left (and generated) undef
) = @_;
my @out_lines;

return ()
if (@row_refs == 0);

$width = get_width( $width);
my $table_width = $width - $l_margin;
my $separator_l = length $separator;




my @widths;
foreach my $ref (@row_refs)
{
if (defined $ref)
{
my $i = 0;
foreach my $cell (@{$ref})
{
my $length = length $cell;

if (defined $widths[$i])
{
$widths[$i] = $length
if ($length > $widths[$i]); # && defined $ref->[$i+1]);
} else
{
$widths[$i] = $length;
}
$i++;
}
$ref = [ @{$ref} ];	# copy the row, because we are going to modify it
}
}
my $nr_cols = scalar @widths;
my $last_col = $nr_cols - 1;


my @formats = (defined $formats_ref) ? @{$formats_ref} : map { 'L' } 0..$last_col;
if (@formats < $nr_cols)
{
while (@formats < $nr_cols) { push @formats, 'L'; }
}





my $new_table_width = -$separator_l;
map { $new_table_width += ($_ + $separator_l) } @widths;


if ($new_table_width > $table_width)
{
my $width_minus_last = $new_table_width - ($widths[$last_col]);
my $last_width = $table_width - $width_minus_last;
$widths[$last_col] = $last_width if ($last_width > 3);
}





foreach my $row_ref (@row_refs)
{
if (defined $row_ref)
{
my @sub_row_refs;
for (my $i = 0; $i < $nr_cols; $i++)
{
my $item = $row_ref->[$i];
my $col_width = $widths[$i];
if (defined $item && $item ne '')
{

if (length( $item) > $col_width) # && defined $row_ref->[$i+1])
{
my $r = 0;
map { $sub_row_refs[$r++]->[$i] = $_ } ENV_split_lines( $col_width, $item);
} else
{
$sub_row_refs[0]->[$i] = $item;
}
}
}
foreach my $sub_row_ref (@sub_row_refs)
{
my $line = ' ' x $l_margin;
for (my $i = 0; $i < $nr_cols; $i++)
{
my $item = $sub_row_ref->[$i];
$item = ''
if (!defined $item);
my $item_l = length $item;
my $col_width = $widths[$i];
my $format = $formats[$i];
if ($format eq 'L')
{
$line .= sprintf "%-${col_width}.${item_l}s", $item;	    # max_with.width
} else
{
$line .= sprintf "%${col_width}.${item_l}s", $item;	    # max_with.width
}
$line .= $separator unless ($i == $last_col);
}
$line =~ s/\s+$//;	    #remove trailing white-space
push @out_lines, $line;
}
} else
{
push @out_lines, undef;
}
}

return @out_lines;
}




sub FORMAT_indent($$@)
{
my ($width,			# 0 = term-width, <0 = term_width - $width, undef == anylength
$l_margin,		# size
@row_ref_refs,		# [ [ $indent, $text ], ... ]
) = @_;
my @out_lines;

return ()
if (@row_ref_refs == 0);

$width = get_width( $width);
my $usable_width = $width - $l_margin;

foreach my $ref (@row_ref_refs)
{
my ($indent, $text) = @{$ref};
my $lead = ' ' x ($l_margin + $indent);
my $col_width = $usable_width - $l_margin - $indent;
if (length($text) > $col_width)
{
push @out_lines, map { "$lead$_" } ENV_split_lines( $col_width, $text);
} else
{
push @out_lines, "$lead$text";
}
}

return @out_lines;
}




sub FORMAT_hanging($$$$)
{
my ($width,			# 0 = term-width, <0 = term_width - $width, undef == anylength
$l_margin,		# size
$indent,		# size
$text,
) = @_;
my @out_lines;

$width = get_width( $width);
my $usable_width = $width - $l_margin;
my $lead = ' ' x $l_margin;
if (length( $text) > $usable_width)
{



my $ri = rindex( $text, ' ', $usable_width);
my $part;
if ($ri >= 0)
{
$part = substr( $text, 0, $ri);
$text = substr( $text, $ri + 1);
} else
{
$part = substr( $text, 0, $usable_width);
$text = substr( $text, $usable_width);
}
push @out_lines, "$lead$part";




$usable_width = $width - $l_margin - $indent;
$lead = ' ' x ($l_margin + $indent);
push @out_lines, map { "$lead$_" } ENV_split_lines( $usable_width, $text);
} else
{
push @out_lines, "$lead$text";
}

return @out_lines;
}




sub get_width($)
{
my ($width) = @_;

if (defined $width)
{
if ($width <= 0)
{
$width = ENV_get_term_size() + $width;  # negative so acutally subtract!
}
$width--;   # cater for 1/2 characters
} else
{
$width = 1000;		       #(temp)
}

return $width;
}

1;
