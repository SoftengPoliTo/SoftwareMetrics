#=================================================
#
#   gbssys.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbssys;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSSYS_init
GBSSYS_submit
);
}




use glo::env;
use glo::spit;
use glo::format;
use glo::list;
use glo::struct;
use mod::validate;
use mod::steps;
use mod::gbsjob;
use mod::gbsglo;




sub GBSSYS_init($$$$$$$$);
sub GBSSYS_submit($$);

sub analyze_steps($);
sub display_steps();
sub get_files_opt();








my $JOBTYPE;		    # 'build', 'make', 'audit', 'tool'

my $IGNORE_ERRORS;	    # bool
my $BUILDS_REF;	    # may be undef
my $AUDITS_REF;		    # may be undef
my $FILES_REF;		    # may be undef
my $FOREGROUND;		    # bool
my $SUBMIT_REF,		    # [ $DELAY # bool , $MAIL  # bool, $NOTIFY # bool, $COMMENT # string]
my $WAIT;		    # bool

my $IS_FOR_BUILD = 0;
my $IS_FOR_AUDIT = 0;
my $IS_FOR_TOOL  = 0;
my $JOBNAME;			# "gbssys$JOBTYPE"




my $ORG_BUILDS = '';
my $ORG_AUDITS = '';
my @EXPANDED_BUILDS;
my @EXPANDED_AUDITS;

my @STEPS_ORDER;    # Allowed steps
my %STEPS;












sub GBSSYS_init($$$$$$$$)
{
($JOBTYPE,			# 'build', 'make', 'audit' or 'tool'
$IGNORE_ERRORS,
$BUILDS_REF,		# may be undef
$AUDITS_REF,		# may be undef
$FILES_REF,		# may be undef
$FOREGROUND,
$SUBMIT_REF,		# [ $DELAY, $MAIL, $NOTIFY, $COMMENT ]
$WAIT,
) = @_;




if ($JOBTYPE eq 'build' or $JOBTYPE eq 'make')
{
$IS_FOR_BUILD = 1;
} elsif ($JOBTYPE eq 'audit')
{
$IS_FOR_AUDIT = 1;
} else  # $JOBTYPE eq 'tool'
{
$IS_FOR_TOOL = 1;
}




$JOBNAME = "gbssys$JOBTYPE";




if (defined $BUILDS_REF)
{

my $builds = join( ',', @{$BUILDS_REF});
if ($builds ne '*' && $builds ne '-,*')
{
$ORG_BUILDS = $builds;
}
}
if ($IS_FOR_BUILD || $IS_FOR_AUDIT)
{
@EXPANDED_BUILDS = VALIDATE_builds( $BUILDS_REF);
} else  # $IS_FOR_TOOL
{
@EXPANDED_BUILDS = ('-');
}




if (defined $AUDITS_REF)
{

my $audits_or_tools = join( ',', @{$AUDITS_REF});
if ($audits_or_tools ne '*')
{
$ORG_AUDITS = $audits_or_tools;
}
}
if ($IS_FOR_AUDIT)
{
@EXPANDED_AUDITS = grep( $_ ne '-', VALIDATE_audits( $AUDITS_REF));
} else  # $IS_FOR_BUILD, $IS_FOR_TOOL
{
@EXPANDED_AUDITS = ('-');
}

@STEPS_ORDER = ();
%STEPS = ();
}





sub GBSSYS_submit($$)
{
my ($step_names_ref,    # [0] may be '?'
$opts_ref,	    # selection of relevant options
) = @_;
my $rc = 0;




if (@{$step_names_ref} == 1 && $step_names_ref->[0] eq '?')
{
ENV_say( 1, "Showing steps...");
display_steps();
ENV_exit( 0);
}
ENV_say( 1, "Steps: @{$step_names_ref}")
if (@{$step_names_ref});




@STEPS_ORDER = STEPS_get_stepnames( $JOBTYPE);

map { $STEPS{$_} = [ STEPS_get_step_data( $_) ] } @STEPS_ORDER;





my @steps;
if ("@{$step_names_ref}" eq 'ALL')
{
@steps = @STEPS_ORDER;
} else
{
@steps = analyze_steps( $step_names_ref);
}




my @selection_order;

my %selections;


{



my %dir_test_commands = (
audit => sub { GBSGLO_subsystem_does_audit( $_[0], $_[2], $_[1]) },	# $subsys, $audit, $build
tool  => sub { return 1 },
build => sub { GBSGLO_subsystem_does_build( $_[0], $_[1]) },	# $subSys, $build
make  => sub { GBSGLO_subsystem_does_build( $_[0], $_[1]) },	# $subsys, $build
);
my $dir_test_command = $dir_test_commands{$JOBTYPE};

foreach my $step (@steps)
{

my ($command_data_refs_ref, $tool, $exec, $do_build, $do_audit) = @{$STEPS{$step}};




my $nr_commands = @{$command_data_refs_ref};
my $subsys = ($nr_commands > 0 || $tool ne '') ? '' : $step;
my $must_force_execute = ($exec eq 'FORCE') ? '1' : '0';
my $step_data_ref = [ $step, $subsys, $tool, $must_force_execute, $command_data_refs_ref ];
my $must_command = ($IS_FOR_AUDIT) ? $do_audit : ($IS_FOR_TOOL) ? $do_audit : $do_build;

if ($tool eq '')
{

foreach my $build (@EXPANDED_BUILDS)
{
foreach my $audit (@EXPANDED_AUDITS)
{
my $must_submit = 0;
if ($subsys ne '')
{
$must_submit = $dir_test_command->( $subsys, $build, $audit);
} else # command)
{
$must_submit = $must_command;
}

if ($must_submit)
{
my $key = "$build/$audit";
push @selection_order, $key
if (!LIST_contains_str( $key, \@selection_order));
push @{$selections{$key}}, $step_data_ref;
}
}
}
} else
{
my $key = "$tool/-";
push @selection_order, $key
if (!LIST_contains_str( $key, \@selection_order));
push @{$selections{$key}}, $step_data_ref;
}
}
}




{



if ($FOREGROUND)
{
GBSJOB_init( $JOBNAME, undef);
} else
{
GBSJOB_init( $JOBNAME, $SUBMIT_REF);
}




my @options = (@{$opts_ref}, get_files_opt());  # Add FILES (--files=...)




my $job_count = 0;
foreach my $key (@selection_order)
{

my ($build_or_tool, $audit) = split( '/', $key);
my $step_data_refs_ref = $selections{$key};







my @lines = STRUCT_encode( $step_data_refs_ref);
my $tmp_filespec = SPIT_tmp_file_nl( "${JOBNAME}_${build_or_tool}_${audit}", \@lines);
my @exec_args = ($tmp_filespec, @options);

GBSJOB_sub( $build_or_tool, $audit, [ @exec_args ]);
$job_count++;
}




if ($job_count > 0)
{
ENV_say( 1, "Submitting $job_count jobs");
GBSJOB_run();
$rc = GBSJOB_wait()
if ($WAIT);
} else
{
ENV_sig( W => "Nothing to submit");
}
}

return $rc;
}




sub analyze_steps($)
{
my ($step_names_ref,
) = @_;
my @steps;

my $error_count = 0;
my @specified_steps = @{$step_names_ref};
my @all_possible_steps = STEPS_get_stepnames( undef);
my @aliases = STEPS_get_aliasnames();

my @new_step_refs;

if (@specified_steps == 0)
{



@new_step_refs = map { [ $_, 0 ] } @STEPS_ORDER;
} else
{
my $i = 0;
my %step_indices = map { $_ => $i++ } @STEPS_ORDER;
my %aliases = map { $_ => 1 } @aliases;
my @short_steps;
if (@specified_steps == 1 && LIST_contains_str( $specified_steps[0], \@aliases))
{



my $alias = $specified_steps[0];
my ($alias_steps_ref, $build) = STEPS_get_alias_data( $alias);
ENV_say( 1, "Alias $alias -> @{$alias_steps_ref} ($build)");
push @short_steps, @{$alias_steps_ref};
my $alias_build = $build;
if ($ORG_BUILDS eq '' || $alias_build eq '')
{
if ($alias_build ne '')
{
@EXPANDED_BUILDS = ($alias_build);
}
} else
{
ENV_sig( E => "Cannot specify --builds=$ORG_BUILDS if Build ($alias_build) is specified in Alias");
$error_count++;
}
} else
{



@short_steps = @specified_steps;
}




{
my $steps = "@short_steps";
if (substr( $steps, 0, 1) eq '-')
{
ENV_sig( EE => "Cannot start Steps-list with '-'");
} elsif (substr( $steps, -1, 1) eq '-')
{
ENV_sig( EE => "Cannot end Steps-list with '-'");
} elsif ($steps =~ /-\s+-/)
{
ENV_sig( EE => "Cannot specify subsequent '-' ( - - )");
}
}




foreach my $step (@short_steps)
{
if ($step ne '-')
{
if ($step eq '.')
{
$step = $GBS::SUBSYS;
}
if (!exists $step_indices{$step})
{
if (exists $aliases{$step})
{
ENV_sig( E => "Step '$step' is an Alias. You can only specify a single Alias");
} elsif (LIST_contains_str( $step, \@all_possible_steps))
{
ENV_sig( E => "Step '$step' cannot be used in the $JOBNAME context");
} else
{
ENV_sig( E => "Step '$step' unknown");
}
$error_count++;
}
}
}

if ($error_count == 0)
{



my $step_index = -1;
while (@short_steps)
{
my $step = shift @short_steps;

if ($step eq '-')
{
my $next_specified_step = shift @short_steps;
my $next_specified_index = $step_indices{$next_specified_step};

if ($next_specified_index > $step_index)
{
for (my $i = $step_index + 1; $i < $next_specified_index; $i++)
{
push @new_step_refs, [ $STEPS_ORDER[$i], 0 ];
}
push @new_step_refs, [ $next_specified_step, 1 ];
$step_index = $next_specified_index;
} else
{
ENV_sig( E => "Step '- $next_specified_step' already specified or invalid Step order");
$error_count++;
}
} else
{
my $next_step_index = $step_indices{$step};
if ($next_step_index > $step_index)
{
push @new_step_refs, [ $step, 1 ];
$step_index = $step_indices{$step};
} else
{
ENV_sig( E => "Step '$step' already specified or invalid Step order");
$error_count++;
}
}
}
}
}





if ($error_count == 0)
{
my %new_steps = map { @{$_} } @new_step_refs;


foreach my $step (@STEPS_ORDER)
{
my $exec = $STEPS{$step}->[2];
if ($exec eq 'ALWAYS' || $exec eq 'FORCE')
{
push @steps, $step;
} elsif ($exec eq 'SPECIFY')
{
my $explicit_specified = $new_steps{$step};
if (defined $explicit_specified && $explicit_specified)
{
push @steps, $step;
} else
{

}
} else	# SELECT
{
push @steps, $step
if (exists $new_steps{$step});
}
}
}

if ($error_count > 0)
{
ENV_say( 1, "Error(s) found");
ENV_say( 0,
"    All Steps    : @all_possible_steps",
"    Context Steps: @STEPS_ORDER",
"    Aliases      : @aliases",
"  Use '$JOBNAME ?' to show all steps");
ENV_exit();
}


return @steps;
}




sub display_steps()
{
my @command_refs;
my @tool_refs;




{
my @row_refs = ( [ 'Step', 'Exec', 'Type', 'Audits', 'Builds' ] );

foreach my $stepname (STEPS_get_stepnames( undef))
{
my ($command_data_refs_ref, $tool, $exec, $do_build, $do_audit) = STEPS_get_step_data( $stepname);


my $nr_commands = @{$command_data_refs_ref};
my $type;
my $audits_comma_list = '';
my $builds_comma_list = '';
if ($nr_commands == 0 && $tool eq '')
{
my $subsys = $stepname;
$type = GBSGLO_subsystem_type( $subsys);
$audits_comma_list = join( ',', GBSGLO_subsystem_audits( $subsys))
if ($do_audit);
$builds_comma_list = join( ',', GBSGLO_subsystem_builds( $subsys))
if ($do_build);
} else
{
if ($nr_commands > 0)
{
$type = 'Command';
my $this_stepname = $stepname;
foreach my $ref (@{$command_data_refs_ref})
{
push @command_refs, [ $this_stepname, "@{$ref->[1]}" ];   # $command_items_ref
$this_stepname = '...';
}
} elsif ($tool ne '')
{
$type = 'Tool';
push @tool_refs, [ $stepname, $tool ];
} else
{
ENV_sig( F => "No type for STEP '$stepname'");
}
$audits_comma_list = $GBS::ALL_AUDITS
if ($do_audit);
$builds_comma_list = $GBS::ALL_BUILDS
if ($do_build);
}
push @row_refs, [ $stepname, $exec, $type, $audits_comma_list, $builds_comma_list ];
}

ENV_say( 0, "- Steps for $GBS::ROOT_PATH:",
FORMAT_table( 0, 2, '  ', undef, @row_refs));
}




if (@command_refs)
{
my @row_refs = ( [ 'Step', 'Command' ], @command_refs );
ENV_say( 0, '',
"- Commands for $GBS::ROOT_PATH:",
FORMAT_table( 0, 2, '  ', undef, @row_refs));
}




if (@tool_refs)
{
my @row_refs = ( [ 'Step', 'Tool' ], @tool_refs );
ENV_say( 0, '',
"- Tools for $GBS::ROOT_PATH:",
FORMAT_table( 0, 2, '  ', undef, @row_refs));
}




{
my @row_refs = ([ 'Alias', 'Build', 'Steps' ]);
foreach my $aliasname (STEPS_get_aliasnames())
{
my ($stepnames_ref, $build) = STEPS_get_alias_data( $aliasname);
push @row_refs, [ $aliasname, $build, "@{$stepnames_ref}" ];
}
if (@row_refs > 1)
{
ENV_say( 0, '',
"- Aliases for $GBS::ROOT_PATH:",
FORMAT_table( 0, 2, '	', undef, @row_refs));
} else
{
ENV_say( 0, '',
"- No Aliases for $GBS::ROOT_PATH");
}
}
}




sub get_files_opt()
{
my $files;	    # return in array context

if (wantarray && defined $FILES_REF && @{$FILES_REF})
{
my $gbs_component = $GBS::COMPONENT;
my @files;
foreach my $cfs (@{$FILES_REF})
{
my ($comp) = $cfs =~ /(.*):/;
if ($comp)
{
if ($comp eq '.')
{
ENV_sig( EE => "No current Component (--files=$cfs)")
if ($gbs_component eq '');
$cfs = $gbs_component . substr( $cfs, 1);
ENV_say( 1, "--files set to '$cfs'");
}
} else
{
$cfs = "*:$cfs";
ENV_say( 1, "--files set to '$cfs'");
}
push @files, $cfs;
}
$files = '--files=' . join( ',', @files);
return ($files);
} else
{
return ();
}
}

1;


