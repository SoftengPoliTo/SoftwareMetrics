#=================================================
#
#   struct.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::struct;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
STRUCT_encode
STRUCT_decode
);
}




use glo::env;




sub STRUCT_encode($);
sub STRUCT_decode($);

sub encode($$);








sub STRUCT_encode($)
{
my ($items_ref,
) = @_;
my @lines;



my $level = 0;
@lines = encode( 0, $items_ref);


return @lines;
}





sub encode($$)
{
my ($level,
$item_or_ref,
) = @_;
my @lines;

if (defined $item_or_ref)
{
if (ref $item_or_ref)
{
$level++;
if (ref $item_or_ref eq 'ARRAY')
{
push @lines, '[';
foreach my $this_item_or_ref (@{$item_or_ref})
{
push @lines, encode( $level, $this_item_or_ref);
}
push @lines, ']';
} elsif (ref $item_or_ref eq 'SCALAR')
{
push @lines, '\\';
push @lines, encode( $level, $item_or_ref);
} elsif (ref $item_or_ref eq 'HASH')
{
ENV_sig( F => "'HASH' not implemented yet");
} else
{
push @lines,".$item_or_ref";
}
$level--;
} else
{
push @lines, ".$item_or_ref";
}
} else
{
push @lines, 'x';
}

return @lines;
}




sub STRUCT_decode($)
{
my ($lines_ref,
) = @_;
my $struct_ref;



my @struct_items;
my @current_refs = ( \@struct_items);
my $level = 0;
foreach my $line (@{$lines_ref})
{
my $marker = substr( $line, 0, 1);
my $item = substr( $line, 1);
if ($marker eq '.')	    # scalar
{
push @{$current_refs[$level]}, $item;
} elsif ($marker eq 'x')    # undef
{
push @{$current_refs[$level]}, undef;
} elsif ($marker eq '\\')   # ref scalar
{
push @{$current_refs[$level]}, \$item;
} elsif ($marker eq '[')    # ref array start
{
my $new_array_ref = [];
push @{$current_refs[$level]}, $new_array_ref;
$level++;
$current_refs[$level] = $new_array_ref;
} elsif ($marker eq ']')    # ref array end
{
$level--;
} else
{
ENV_sig( F => "Invalid marker '$marker'", $line);
}
}
$struct_ref = $struct_items[0];



return $struct_ref;
}

1;


