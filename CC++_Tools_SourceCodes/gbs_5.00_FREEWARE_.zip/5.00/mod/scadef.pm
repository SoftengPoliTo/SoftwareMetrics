#=================================================
#
#   scadef.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::scadef;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SCADEF_get_severity_text
SCADEF_read
SCADEF_metric_is_enabled
SCADEF_get_section_items
SCADEF_get_levels
SCADEF_get_levels_by_level
);
}




use glo::env;
use mod::gbsenv;
use mod::gbssfile;
use mod::gbsfileglo;
use mod::scamet;




sub SCADEF_read($);
sub SCADEF_get_severity_text($);
sub SCADEF_metric_is_enabled($$);
sub SCADEF_get_section_items($$@);
sub SCADEF_get_levels($);
sub SCADEF_get_levels_by_level($);

sub read_scadef($);
sub do_path_spec($$$$$);
sub do_format($$$$$);
sub do_level($$$$$);
sub do_special($$$$$);
sub do_metric($$$$$);
sub do_exit_helpfiles($@);




my $CUR_SCADEF = '';	# plugin_name
my $CUR_SCADEF_REF;

my %SCAS = ();




















my @SEVERITY_TEXTS = qw( Info Warning Fatal);


















my %SETUP_DEFS = (
NICE_NAME	    => [ 'ss' , undef,     0, 1,     1,			 undef, undef ],
VIA_FORMAT	    => [ 'av' , ['%s',''], 0, 2,     undef,		 undef, undef ],
);

my %HELPFILES_DEF = (
PATH	    => [ 'ss' , undef,	   0, 1,     1,		\&do_path_spec,	undef ],    # default filled later
MAIN_FILE	    => [ 'ss' , undef,	   0, 1,     1,			 undef, undef ],
);

my %OPTION_FORMATS_DEFS = (
QUIET_FORMAT    => [ 'ss' , undef,	   0, undef, undef,        \&do_format, undef ],
COMPILER_FORMAT => [ 'ss' , undef,	   0, undef, undef,        \&do_format, undef ],
);

my %LEVELS_DEFS = (
LEVEL	    => [ 'pa' , [],	   0, undef,     2,         \&do_level, undef ],
);

my %MESSAGES_DEFS = (
SPECIAL	    => [ 'pa' , [],	   0, undef,     1,       \&do_special, undef ],
);
my %METRICS_DEFS = (
ENABLE	    => [ 'ps' , [],	   0, undef,   [1],        \&do_metric, undef ],
);










my %SECTION_DEFS = (
SETUP	    => [ 'N', 0, 1, 0,  \%SETUP_DEFS,		undef,  undef ],
HELPFILES	    => [ 'N', 0, 1, 0,	\%HELPFILES_DEF,	undef,	\&do_exit_helpfiles ],
OPTION_FORMATS  => [ 'N', 0, 1, 0,  \%OPTION_FORMATS_DEFS,	undef,  undef ],
LEVELS	    => [ 'N', 0, 1, 0,  \%LEVELS_DEFS,		undef,  undef ],
MESSAGES	    => [ 'N', 0, 1, 0,  \%MESSAGES_DEFS,	undef,  undef ],
METRICS	    => [ 'N', 1, 0, 0,  \%METRICS_DEFS,		undef,  undef ],
);




sub SCADEF_get_severity_text($)
{
my ($severity_index) = @_;

return $SEVERITY_TEXTS[$severity_index];
}




sub SCADEF_read($)
{
my ($audit_plugin) = @_;
my $struct_id;

read_scadef( $audit_plugin)
if ($CUR_SCADEF ne $audit_plugin);

$struct_id = "audit/$audit_plugin";

return $struct_id;
}




sub SCADEF_metric_is_enabled($$)
{
my ($audit_plugin,
$metric,
) = @_;
my $is_enabled;	    # bool: 1 = enabled, 0 = not-enabled

read_scadef( $audit_plugin)
if ($CUR_SCADEF ne $audit_plugin);

$is_enabled = (exists $CUR_SCADEF_REF->{'.'}->{ENABLED_METRICS}->{$metric}) ? 1 : 0;

return $is_enabled;
}




sub SCADEF_get_section_items($$@)
{
my ($audit_plugin,
$section,
@items,
) = @_;
my @values = ();

read_scadef( $audit_plugin)
if ($CUR_SCADEF ne $audit_plugin);

return GBSSFILE_get_section_items( $CUR_SCADEF_REF, $section, @items);
}





sub SCADEF_get_levels($)
{
my ($audit_plugin,
) = @_;





read_scadef( $audit_plugin)
if ($CUR_SCADEF ne $audit_plugin);

return @{GBSSFILE_get_section_items( $CUR_SCADEF_REF, 'LEVELS', 'LEVEL')};
}





sub SCADEF_get_levels_by_level($)
{
my ($audit_plugin,
) = @_;
my %levels_by_level;


read_scadef( $audit_plugin)
if ($CUR_SCADEF ne $audit_plugin);

my @msg_level_refs = @{GBSSFILE_get_section_items( $CUR_SCADEF_REF, 'LEVELS', 'LEVEL')};


%levels_by_level = map { $_->[0] => $_ } @msg_level_refs;		# $level

return %levels_by_level;
}




sub read_scadef($)
{
my ($audit_plugin) = @_;

$CUR_SCADEF = $audit_plugin;
$CUR_SCADEF_REF = $SCAS{$CUR_SCADEF};
if (!defined $CUR_SCADEF_REF)
{
$SCAS{$CUR_SCADEF} = {};
$CUR_SCADEF_REF = $SCAS{$CUR_SCADEF};




my $sca_file = "$GBS::SCRIPTS_PATH/plugins/audit/$audit_plugin/scadef.gbs";
my @inc_path = ( "$GBS::SYSAUDIT_PATH/$CUR_SCADEF",
$GBS::SYSAUDIT_PATH);
GBSSFILE_parse( $CUR_SCADEF_REF, $sca_file, \@inc_path, \%SECTION_DEFS);


}
}




sub do_path_spec($$$$$)
{
my ($section,	# HELPFILES
$subsection,	# empty
$item,		# PATH
$values_ref,	# ($path)
$func_par,
) = @_;

my $path  = $values_ref->[0];

$path = ENV_perl_paths_noquotes( ENV_expand_envs( $path));

return ($path);
}




sub do_format($$$$$)
{
my ($section,	# OPTION_FORMATS
$subsection,	# empty
$item,		# QUIET
$values_ref,	# ([ $sub_key, @sub_values ], ...)
$func_par,
) = @_;

my $format  = $values_ref->[0];

GBSFILEGLO_sig( EE => "Format must contain '%s'")
if ($format !~ /%s/);

return ($format);
}




sub do_level($$$$$)
{
my ($section,	# LEVELS
$subsection,	# empty
$item,		# LEVEL
$values_ref,	# ([ $sub_key, @sub_values ], ...)
$func_par,
) = @_;

my @value_refs = @{$values_ref};
foreach my $ref (@value_refs)
{
my ($level, $severity, $text) = @{$ref};

GBSFILEGLO_sig( EE => "Level must be numeric ($level).")
if ($level !~ /^\d+$/);

GBSFILEGLO_sig( EE => "Syntax is <level> => I|W|F <text>")
if ($severity !~ /^[IWF]$/);
push @{$ref}, index( 'IWF', $severity);	    # $severity_index

}

return @value_refs;
}




sub do_special($$$$$)
{
my ($section,	# MESSAGES
$subsection,	# empty
$item,		# SPECIAL
$values_ref,	# ([ $sub_key, @sub_values ], ...)
$func_par,
) = @_;

my @value_refs = @{$values_ref};
foreach my $ref (@value_refs)
{
my ($msg_id, $text) = @{$ref};



}

return @value_refs;
}




sub do_metric($$$$$)
{
my ($section,	# METRICS
$subsection,	# empty
$item,		# ENABLE
$values_ref,	# [ @values ]
$func_par,
) = @_;

my @values = @{$values_ref};
foreach my $value (@values)
{

GBSFILEGLO_sig( EE => "Invalid Metric mnemonic '$value'")
if (!SCAMET_name_is_valid( $value));
GBSFILEGLO_sig( EE => "Duplicate Metric mnemonic '$value'")
if (exists $CUR_SCADEF_REF->{'.'}->{ENABLED_METRICS}->{$value});

$CUR_SCADEF_REF->{'.'}->{ENABLED_METRICS}->{$value} = 1;
}

return @values;
}




sub do_exit_helpfiles($@)
{
my ($section,   # HELPFILES
@args
);

if (!defined $CUR_SCADEF_REF->{HELPFILES}->{PATH})
{
$CUR_SCADEF_REF->{HELPFILES}->{PATH} = GBSENV_get_gbs_plugin_path( audit => $CUR_SCADEF);

}
}

1;


