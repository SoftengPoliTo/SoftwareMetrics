#=================================================
#
#   scope.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::scope;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SCOPE_read
SCOPE_get_components
SCOPE_get_includes
);
}





use mod::gbsfile;




sub SCOPE_read($$;$);
sub SCOPE_get_components($$);
sub SCOPE_get_includes($$@);

sub read_scope($);











my %SCOPE_CACHE;





sub SCOPE_read($$;$)
{
my ($subsys,
$component,
$force_read,	    # Optional
) = @_;

my $subsys_comp = "$subsys/$component";
read_scope( $subsys_comp)
if ($force_read || !exists $SCOPE_CACHE{$subsys_comp});
}




sub SCOPE_get_components($$)
{
my ($subsys,
$component,
) = @_;

my $subsys_comp = "$subsys/$component";
read_scope( $subsys_comp)
if (!exists $SCOPE_CACHE{$subsys_comp});

return @{$SCOPE_CACHE{$subsys_comp}};
}




sub SCOPE_get_includes($$@)
{
my ($subsys,
$component,
@sub_dirs
) = @_;
my @scope_dirs;

my $subsys_comp = "$subsys/$component";
read_scope( $subsys_comp)
if (!exists $SCOPE_CACHE{$subsys_comp});

foreach my $component (@{$SCOPE_CACHE{$subsys_comp}})
{
foreach my $sub_dir (@sub_dirs)
{
push @scope_dirs, "../../$component$sub_dir";
}
}


return @scope_dirs;
}




sub read_scope($)
{
my ($subsys_comp,	    # = "$subsys/$component"
) = @_;
my @components;

my ($subsys, $component) = split( '/', $subsys_comp);

my $gbs_comp_path = "$GBS::ROOT_PATH/dev/$subsys/comp";
my $scope_file = "$gbs_comp_path/$component/scope";

if (GBSFILE_open( $scope_file, 0, undef, $GBS::BUILD))
{
my $line = GBSFILE_get_line();
while ($line)
{

if (-d "$gbs_comp_path/$line")
{
push @components, $line;
}  else
{
GBSFILE_sig( EE => "No such Component '$line'");
}
$line = GBSFILE_get_line();
}
}
$SCOPE_CACHE{$subsys_comp} = [ @components ];
}

1;

