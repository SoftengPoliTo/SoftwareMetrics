
class MainClass
{
		//TODO marker is here
		//ToDo
		//FIXME is here
		//FixMe is here
		/*TBD is here*/
		//HACK is here
		//XXX is here

	int main()
	{
		//TODO marker is here
		//ToDo
		//FIXME is here
		//FixMe is here
		/*TBD is here*/
		//HACK is here
		//XXX is here
		//All here: TODO,ToDo,FIXME,FixMe,TBD,HACK,XXX
		// no hereTODOss
		// no hereTODO
		// no TODOss
		//TOBEDONE
		
		char a[] = "TODO string TOBEDONE";
	}

		//All here: TODO,ToDo,FIXME,FixMe,TBD,HACK,XXX
		// no hereTODOss
		// no hereTODO
		// no TODOss
		//TOBEDONE
}
