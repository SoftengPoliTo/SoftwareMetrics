#=================================================
#
#   gbsbgscasum.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSBGSCASUM @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::args;
use mod::gbsenv;
use mod::gbsbgglo;
use mod::scasum;




sub do_scasum($$);
sub get_command_args();








my $BATCH_NAME = '';	# reference to be used in logging. E.g.:  gbsaudit_post
my $COMPONENT;		# will be '-'
my $GBSBGJOB_SCRIPT_SPEC;	# main input-file






$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);

get_command_args();
GBSBGGLO_init( $BATCH_NAME, $COMPONENT);	# sets CWD to SUSBSYS ($COMPONENT eq '-')
$RC = GBSBGGLO_main( $GBSBGJOB_SCRIPT_SPEC, [ SCASUM => \&do_scasum ]);

ENV_exit( $RC);




END
{
ENV_print_end_msg( 0);
}




sub do_scasum($$)
{
my ($file,		    # not used
$sum_filespec,
) = @_;
my $rc = 0;


SCASUM_init( $sum_filespec);

SCASUM_run();

return $rc;
}




sub get_command_args()
{
($BATCH_NAME,
$COMPONENT,
$GBSBGJOB_SCRIPT_SPEC,
) = ARGS_get( 3, 'perl gbsbgscasum.pl <BATCH_NAME> <COMPONENT> <gbg_script>', undef);

}


