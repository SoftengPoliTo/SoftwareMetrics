

const unsigned int c = 3;
unsigned int c = 3;
int c = 3;


int main(int a = 1, int b = -2)
{
	const unsigned int c = 3;

	for (int i = 0; i < 100; ++i)
	{
		// modified
	}
	while (1)
	{
		a = 4;
	}
}

int simple_func()
{
	const unsigned int c = c;
}

int added()
{

}

int added2()
{

}
