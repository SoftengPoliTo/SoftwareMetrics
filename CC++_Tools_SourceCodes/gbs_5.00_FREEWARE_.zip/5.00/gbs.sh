#!must_be_sourced
#
#   gbs.sh
#
#   keep this file for backward compatability           TBR!!
#

. $GBS_SCRIPTS_PATH/gbsinit.sh $*

## EOF ##
