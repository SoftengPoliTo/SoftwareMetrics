#=================================================
#
#   exec.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::exec;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
EXEC_run
EXEC_batch_init
EXEC_batch_run
EXEC_batch_queue
EXEC_batch_wait
);
}




use glo::env;
use glo::proc;
use glo::slurp;
use mod::gbscmd;




sub EXEC_run($$);
sub EXEC_batch_init($);
sub EXEC_batch_run($);
sub EXEC_batch_queue($);
sub EXEC_batch_wait();

sub dispatch();
sub handle_completion($$);




my $IGNORE_ERRORS;

my $NR_QUEUED = 0;	# nr jobs queued for running
my $NEXT_QUEUE_INDEX = 0;
my $MAX_RUNNING = 2;	# --jobs=...
my $NR_RUNNING = 0;	# nr current running jobs

my @QUEUE_REFS;



my %PID_DATA;


my $BATCH_RC = 0;

my @UNDELETABLES;







sub EXEC_run($$)
{
my ($command_file_name,	# e,g,: gbssub.pl
$args_ref,
) = @_;


my $command = "$GBS::SCRIPTS_PATH/$command_file_name";

return ENV_system( [ $command, @{$args_ref} ], undef);
}




sub EXEC_batch_init($)
{
my ($jobs) = @_;

$MAX_RUNNING = $jobs;
ENV_whisper( 1, "MaxJobs=$MAX_RUNNING");
$IGNORE_ERRORS = ENV_getenv( 'GBS_IGNORE_ERRORS');
}




sub EXEC_batch_run($)
{
my ($command_items_ref,
) = @_;
my $rc;

ENV_say( 1, "-->");
my $batch_command_ref = GBSCMD_get_batch_command_ref( $command_items_ref);
$rc = ENV_system( $batch_command_ref, undef);
ENV_say( 1, "<--");

return $rc;
}




sub EXEC_batch_queue($)
{
my ($command_items_ref,
) = @_;
my $queued = 0;		    # 1 = queued, 0 == not queued because of failed steps

if ($BATCH_RC == 0 || $IGNORE_ERRORS)
{
my $full_command = ENV_prepare_command( GBSCMD_get_batch_command_ref( $command_items_ref));
push @QUEUE_REFS, [ $#QUEUE_REFS + 1, 0, $full_command, '', -1, -1 ];
$NR_QUEUED++;

dispatch();
$queued = 1;
} else
{
ENV_say( 1, "Exec skipped because of previous error(s)");
}

return $queued;
}




sub dispatch()
{

while ($NR_QUEUED > 0 && $NR_RUNNING < $MAX_RUNNING)
{
my $index = $NEXT_QUEUE_INDEX++;

my $queue_ref = $QUEUE_REFS[$index];

my $log_file = ENV_get_tmp_spec( "exec_log_$index");
my $full_command = $queue_ref->[2];	    # $full_command
$queue_ref->[3] = $log_file;		    # $log_file
my $pid = PROC_spawn( $full_command, $log_file);
$PID_DATA{$pid} = $queue_ref;
$queue_ref->[1] = 1;			    # $state = running
$queue_ref->[4] = $pid;			    # pid

$NR_RUNNING++;
$NR_QUEUED--;




{
my ($pid, $rc) = PROC_waitpid_test( -1);

if ($pid != -1 && $pid != 0)
{
handle_completion( $pid, $rc);
}
}
}
}




sub EXEC_batch_wait()
{
my $rc;

while ($NR_QUEUED > 0 || $NR_RUNNING > 0)
{
if ($NR_RUNNING > 0)
{
my ($pid, $this_rc) = PROC_waitpid(-1);

handle_completion( $pid, $this_rc);
}
if ($NR_QUEUED > 0)
{
if ($BATCH_RC == 0 || $IGNORE_ERRORS)
{
dispatch();
} else
{
$NR_QUEUED = 0;
}
}
}
$rc = $BATCH_RC;




$BATCH_RC = 0;
$NEXT_QUEUE_INDEX = 0;
@QUEUE_REFS = ();
%PID_DATA = ();
if (@UNDELETABLES)
{
my $nr_files = @UNDELETABLES;
ENV_say( 1, "Deleting $nr_files locked logfile(s)...");
$nr_files -= unlink (@UNDELETABLES);
ENV_say( 1, "Still $nr_files logfile(s) remaining undeletable!")
if ($nr_files > 0);
@UNDELETABLES = ();
}

ENV_say( 1, "Completed ($rc)")
if ($rc != 0);

return $rc;
}




sub handle_completion($$)
{
my ($pid,
$rc,
) = @_;

$BATCH_RC = $rc if ($rc > $BATCH_RC);
my $queue_ref = $PID_DATA{$pid};


$queue_ref->[1] = 2;		# $state = done
$queue_ref->[5] = $rc;		# $rc
$NR_RUNNING--;

my $log_file = $PID_DATA{$pid}->[3];
ENV_say( 1, "-->");
ENV_print( 0, SLURP_file_raw( $log_file));	# print the logfile. We cannot use ENV_say because the lines are already formatted
ENV_say( 1, "<--");
if (!unlink( $log_file))
{
ENV_say( 1, "Cannot delete '$log_file', will try later (rc=$rc)");
push @UNDELETABLES, $log_file;
}
}

1;


