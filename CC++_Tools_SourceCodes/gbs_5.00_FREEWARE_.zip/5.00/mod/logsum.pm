#=================================================
#
#  logsum.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::logsum;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
LOGSUM_write
LOGSUM_read
LOGSUM_reset
LOGSUM_get_os_root_spec
LOGSUM_get_os_logfile_spec
LOGSUM_update_logfile_spec
);
}




use glo::env;
use glo::spit;
use glo::slurp;
use glo::time;
use mod::gbsres;




sub LOGSUM_write($$);
sub LOGSUM_read($);
sub LOGSUM_reset();
sub LOGSUM_get_os_root_spec($);
sub LOGSUM_get_os_logfile_spec($);
sub LOGSUM_update_logfile_spec($$);

sub write_logsum($);
sub read_logsum($);







my $OS_ROOT_SPEC_I = 3;
my $OS_LOGFILE_SPEC_I = 4;










my $EOF_I = 15;

my $NR_ITEMS = 16;  # includes <<EOF>>




my $CUR_FILESPEC = '';
my @CUR_ITEMS;




















sub LOGSUM_write($$)
{
my ($sum_logfile_spec,	# must end with '.log.sum'
$sum_ref,		# @ITEMS    (without <<EOF>>)
) = @_;


@CUR_ITEMS = @{$sum_ref};
my $nr_items = @CUR_ITEMS;
if ($nr_items == $NR_ITEMS)
{

} elsif ($nr_items == $NR_ITEMS -1)
{
$CUR_ITEMS[$EOF_I] = '<<EOF>>';
$nr_items++;
} else
{
ENV_sig( F => $sum_logfile_spec, "- Invalid nr items: $nr_items ($NR_ITEMS)");
}

write_logsum( $sum_logfile_spec);

if (defined wantarray)
{
return (wantarray) ? @CUR_ITEMS : join( "\t", @CUR_ITEMS);
}
}




sub LOGSUM_read($)
{
my ($sum_logfile_spec,	# must end with '.log.sum'
) = @_;


read_logsum( $sum_logfile_spec);

if (defined wantarray)
{
return (wantarray) ? @CUR_ITEMS : join( "\t", @CUR_ITEMS);
}
}




sub LOGSUM_reset()
{
$CUR_FILESPEC = '';
@CUR_ITEMS = ();
}




sub LOGSUM_get_os_root_spec($)
{
my ($sum_logfile_spec) = @_;


read_logsum( $sum_logfile_spec);

return $CUR_ITEMS[ $OS_ROOT_SPEC_I];
}




sub LOGSUM_get_os_logfile_spec($)
{
my ($sum_logfile_spec) = @_;


read_logsum( $sum_logfile_spec);

return $CUR_ITEMS[ $OS_LOGFILE_SPEC_I];
}




sub LOGSUM_update_logfile_spec($$)
{
my ($sum_logfile_spec,
$logfile_spec,
) = @_;

read_logsum( $sum_logfile_spec);
$CUR_ITEMS[ $OS_LOGFILE_SPEC_I] = ENV_os_paths( $logfile_spec);
write_logsum( undef);
}




sub read_logsum($)
{
my ($sum_logfile_spec,	# must end with '.log.sum'
) = @_;

if ($sum_logfile_spec ne $CUR_FILESPEC)
{
@CUR_ITEMS = SLURP_file( $sum_logfile_spec);
$CUR_FILESPEC = $sum_logfile_spec;

my $changed = 0;
my ($jobname, $build_or_tool, $audit, $date_time) = GBSRES_split_logfile_spec( $sum_logfile_spec, 'W');
if (defined $date_time)
{
my $os_root_path = '';
my $os_logfile = '';
if ($sum_logfile_spec =~ m!^(.*)/silo/.gbs/gbssum/!)
{
$os_root_path = ENV_os_paths( $1);
} else
{
$os_logfile = ENV_os_paths( $sum_logfile_spec);
}
my $time_start = TIME_unpack( $date_time);
my @fill_values = ( $jobname, $build_or_tool, '', $os_root_path, $os_logfile, $time_start,
'', '', '', 'START', -1, $audit,
$date_time, '', '', '<<EOF>>');



foreach my $i (0 .. $EOF_I)
{
my $item = $CUR_ITEMS[$i];
if (!defined $item || $item eq '' || $item eq '<<EOF>>')
{
my $fill_value = $fill_values[$i];
if (!defined $item || $item ne $fill_value)
{
$CUR_ITEMS[$i] = $fill_value;
$changed++;
ENV_say( 2, "$sum_logfile_spec:")
if ($changed == 1);
ENV_say( 2, "- Added item [$i]: $fill_value");
}
}
}
}

write_logsum( undef)
if ($changed);
}
}




sub write_logsum($)
{
my ($sum_logfile_spec,	# undef or must end with '.log.sum'
) = @_;

$CUR_FILESPEC = $sum_logfile_spec
if (defined $sum_logfile_spec);
SPIT_file_nl( $CUR_FILESPEC, \@CUR_ITEMS);
}

1;
