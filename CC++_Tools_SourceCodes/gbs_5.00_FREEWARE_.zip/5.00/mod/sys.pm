#=================================================
#
#   sys.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::sys;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SYS_read
SYS_skiptypes
SYS_validate_option
SYS_set_envs
SYS_app_items
);
}




use glo::env;
use mod::gbsfile;




sub SYS_read();
sub SYS_skiptypes($);
sub SYS_validate_option($$);
sub SYS_set_envs();
sub SYS_app_items();

sub read_file($);
sub variable_section(@);
sub variable_line($);
sub env_default($);
sub env_value($);
sub env_values($);
sub add_env_value($$);
sub variable_end();
sub exclude_section(@);








my %ENVVAR_DEFS = (

DEFAULT => [ \&env_default ],
VALUE   => [ \&env_value ],
VALUES  => [ \&env_values ],
);

my %SECTIONS = (

VARIABLE	=> [ \&variable_section, \&variable_line, \&variable_end ],	# APP EnvVar. Added to ENVVARS
EXCLUDE	=> [ \&exclude_section, undef, undef ],				# Added to SKIPTYPES
);




my $CUR_ROOT_PATH = '';

my %ENVVARS;


my @ENVVAR_NAMES;

my @SKIPTYPES;





my $CUR_VAR;
my @CUR_VALUE_NAMES;




sub SYS_read()
{
read_file( $GBS::ROOT_PATH);
}




sub SYS_skiptypes($)
{
my ($root_path) = @_;

read_file( $root_path)
if ($root_path ne $CUR_ROOT_PATH);


return @SKIPTYPES;
}




sub SYS_validate_option($$)
{
my ($name,		# GBS_APP_*
$value_name,	# GBS_APP_<name>
) = @_;
my ($is_ok, $new_value_name) = ( 1, $value_name);

read_file( $GBS::ROOT_PATH)
if ($GBS::ROOT_PATH ne $CUR_ROOT_PATH);

if (!exists( $ENVVARS{$name}))
{
$is_ok = 0;
$new_value_name = "Invalid key, must be one of: (@ENVVAR_NAMES)";
} else
{
my ($default_name, @value_refs) = @{$ENVVARS{$name}};
my @value_names = map( $_->[0], @value_refs);

if (!grep($_ eq $value_name, @value_names))
{
$is_ok = 0;
$new_value_name = "Invalid value '$value_name', must be one of: (@value_names)";
}
}

return ($is_ok, $new_value_name);
}




sub SYS_set_envs()
{
read_file( $GBS::ROOT_PATH)
if ($GBS::ROOT_PATH ne $CUR_ROOT_PATH);

foreach my $env_name (@ENVVAR_NAMES)
{
ENV_whisper( 1, "APP EnvVar: $env_name");

my ($default_name, @value_refs) = @{$ENVVARS{$env_name}};
my $value_name = ENV_getenv( $env_name);
if ($value_name eq '')
{
$value_name = $default_name;
$ENV{$env_name} = $value_name;
}
my $value;
foreach my $ref (@value_refs)
{
if ($ref->[0] eq $value_name)
{
$value = $ref->[1];
last;
}
}
if (defined $value)
{
$ENV{"${env_name}_VALUE"} = $value;
ENV_say( 1, "** $env_name=$value_name, ${env_name}_VALUE=$value")
if ($value_name ne $default_name);
} else
{
$ENV{"${env_name}_VALUE"} = '';
ENV_say( 1, "** $env_name=$value_name")
if ($value_name ne $default_name);
}
}
}




sub SYS_app_items()
{
my @row_refs;

read_file( $GBS::ROOT_PATH)
if ($GBS::ROOT_PATH ne $CUR_ROOT_PATH);

if (@ENVVAR_NAMES)
{
push @row_refs, [ qw( Name Cur-Value Default Possible-Values) ];
foreach my $key (@ENVVAR_NAMES)
{
my ($default_name, @value_refs) = @{$ENVVARS{$key}};
my @values = map( $_->[0], @value_refs);
my $cur_value = ENV_getenv( $key);
push @row_refs, [ $key, $cur_value, $default_name, "@values" ];
}
}

return @row_refs;
}




sub read_file($)
{
my ($root_path) = @_;




%ENVVARS = ();
@ENVVAR_NAMES = ();
@SKIPTYPES = ();




$CUR_ROOT_PATH = $root_path;
my $cur_sys_file = "$CUR_ROOT_PATH/sys/sys";

GBSFILE_open( $cur_sys_file, 1, undef, undef);




my $var_name;
my $line = GBSFILE_get_line();
while ($line)
{

GBSFILE_sig( EE => "section-line expected")
if ($line =~ /^\s/);
my ($section, @rest) = split( ' ', $line);
my $section_ref = $SECTIONS{$section};
GBSFILE_sig( EE => "Invalid section '$section'")
if (!defined $section_ref);
my ($section_function, $line_function, $end_function) = @{$section_ref};




&$section_function( @rest);




if (defined $line_function)
{
$line = GBSFILE_get_line();
while ($line && $line =~ /^\s/)
{

&$line_function( $line);
$line = GBSFILE_get_line();
}
} else
{
$line = GBSFILE_get_line();
}




&$end_function()
if (defined $end_function);
}


}




sub variable_section(@)
{
my ($name,
@rest
) = @_;

GBSFILE_sig( EE => "One variable name exepected ($name @rest)")
if (@rest );
GBSFILE_sig( EE => "Name '$name' may not end with '_VALUE'")
if (substr( $name, 6) eq '_VALUE');
$CUR_VAR = "GBS_APP_$name";
$ENVVARS{$CUR_VAR} = [ '' ];
push @ENVVAR_NAMES, $CUR_VAR;
@CUR_VALUE_NAMES = ();
}




sub variable_line($)
{
my ($line,
) = @_;

my ($key, $value) = $line =~ /^\s+(\S+)\s*=\s*(.*)$/;
GBSFILE_sig( EE => "Format must be '<space><keyword> = <value>'") if (!defined $key);
my $def_ref = $ENVVAR_DEFS{$key};
if (defined $def_ref)
{
my ($function) = @{$def_ref};
&$function( $value);
} else
{
GBSFILE_sig( EE => "Unknown keyword '$key'");
}
}




sub env_default($)
{
my ($value) = @_;

my $cur_default = $ENVVARS{$CUR_VAR}->[0];
GBSFILE_sig( EE => "Default '$value' was already specified ($cur_default)")
if ($cur_default);
$ENVVARS{$CUR_VAR}->[0] = $value;
}




sub env_value($)
{
my ($value_string) = @_;

my ($value_name, $value) = $value_string =~ /^(.*?)\s*=>\s*(.*)$/;
GBSFILE_sig( EE => "Syntax is ' VALUE = <value_name> => <value_string>'")
if (!defined $value_name);

add_env_value( $value_name, $value);
}




sub env_values($)
{
my ($value_names) = @_;

my @value_names = split( ' ', $value_names);

map { add_env_value( $_, undef) } @value_names;
}




sub add_env_value($$)
{
my ($value_name,
$value,
) = @_;


if (grep( $_ eq $value_name, @CUR_VALUE_NAMES))
{
GBSFILE_sig( EE => "Value_name '$value_name' already specified", "(@CUR_VALUE_NAMES)");
} else
{
push @{$ENVVARS{$CUR_VAR}}, [ $value_name, $value ];
push @CUR_VALUE_NAMES, $value_name;
}
}




sub variable_end()
{
GBSFILE_sig( EE => "No values defined for '$CUR_VAR'")
if (!@CUR_VALUE_NAMES);

my $default_name = $ENVVARS{$CUR_VAR}->[0];
if ($default_name)
{
GBSFILE_sig( EE => "No mathing value_name for default '$default_name'", "(@CUR_VALUE_NAMES)")
if (!grep( $default_name eq $_, @CUR_VALUE_NAMES));
} else
{
$ENVVARS{$CUR_VAR}->[0] = $CUR_VALUE_NAMES[0];
}
@CUR_VALUE_NAMES = ();
}




sub exclude_section(@)
{
push @SKIPTYPES, @_;
}

1;

