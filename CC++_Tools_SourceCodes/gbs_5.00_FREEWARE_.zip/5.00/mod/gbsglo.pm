#=================================================
#
#   gbsglo.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbsglo;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSGLO_system_audits
GBSGLO_system_builds
GBSGLO_system_tools
GBSGLO_subsystems
GBSGLO_subsystem_refs
GBSGLO_subsystem_exists
GBSGLO_subsystems_full_gbs
GBSGLO_subsystems_non_gbs
GBSGLO_subsystem_is_full_gbs
GBSGLO_subsystems_for_build
GBSGLO_subsystems_for_audit
GBSGLO_subsystems_for_tool
GBSGLO_subsystem_does_build
GBSGLO_subsystem_does_audit
GBSGLO_subsystem_does_tool
GBSGLO_subsystem_type
GBSGLO_subsystem_builds
GBSGLO_subsystem_audits
GBSGLO_subsystem_tools
GBSGLO_components
GBSGLO_component_exists
GBSGLO_components_for_build
GBSGLO_components_for_audit
GBSGLO_component_does_build
GBSGLO_component_does_audit
GBSGLO_component_builds
GBSGLO_component_audits
GBSGLO_glob
GBSGLO_validate_spec
GBSGLO_select_dirs
GBSGLO_select_specs
GBSGLO_exclude_specs
GBSGLO_short_filespecs
GBSGLO_find_root_path
GBSGLO_split_gbs_spec
);
}




use glo::env;
use glo::slurp;
use mod::ssprop;




sub GBSGLO_system_audits();
sub GBSGLO_system_builds();
sub GBSGLO_system_tools();
sub GBSGLO_subsystems(;$);
sub GBSGLO_subsystem_refs();
sub GBSGLO_subsystem_exists($$);
sub GBSGLO_subsystems_full_gbs();
sub GBSGLO_subsystems_non_gbs();
sub GBSGLO_subsystem_is_full_gbs($;$);
sub GBSGLO_subsystems_for_build($);
sub GBSGLO_subsystems_for_audit($$);
sub GBSGLO_subsystems_for_tool($);
sub GBSGLO_subsystem_does_build($$);
sub GBSGLO_subsystem_does_audit($$$);
sub GBSGLO_subsystem_does_tool($$);
sub GBSGLO_subsystem_type($);
sub GBSGLO_subsystem_builds($);
sub GBSGLO_subsystem_audits($);
sub GBSGLO_subsystem_tools($);
sub GBSGLO_components(;$$);
sub GBSGLO_component_exists($$$);
sub GBSGLO_components_for_build($$);
sub GBSGLO_components_for_audit($$$);
sub GBSGLO_component_does_build($$$);
sub GBSGLO_component_does_audit($$$$);
sub GBSGLO_component_builds($$);
sub GBSGLO_component_audits($$);
sub GBSGLO_glob($);
sub GBSGLO_validate_spec($);
sub GBSGLO_select_dirs(@);
sub GBSGLO_select_specs(@);
sub GBSGLO_exclude_specs(@);
sub GBSGLO_short_filespecs(@);
sub GBSGLO_find_root_path($);
sub GBSGLO_split_gbs_spec($);








sub GBSGLO_system_audits()
{
my @all_dirs;		# array or scalar (comma-list)

foreach my $spec (ENV_glob "$GBS::ROOT_PATH/sysaudit/*/audit.gbs")
{
my $struct = (split( '/', $spec))[-2]; # get the parent_dir name
push @all_dirs, $struct;
}

return (wantarray) ? @all_dirs : join( ',', @all_dirs);
}




sub GBSGLO_system_builds()
{
my @all_dirs;		# array or scalar (comma-list)

foreach my $spec (ENV_glob "$GBS::ROOT_PATH/sysbuild/*/build.gbs")
{
my $struct = (split( '/', $spec))[-2]; # get the parent_dir name
push @all_dirs, $struct;
}

return (wantarray) ? @all_dirs : join( ',', @all_dirs);
}




sub GBSGLO_system_tools()
{
my @all_dirs;		# array or scalar (comma-list)

foreach my $spec (ENV_glob "$GBS::ROOT_PATH/systool/*/tool.gbs")
{
my $struct = (split( '/', $spec))[-2]; # get the parent_dir name
push @all_dirs, $struct;
}

return (wantarray) ? @all_dirs : join( ',', @all_dirs);
}




sub GBSGLO_subsystems(;$)
{
my ($root_path,
) = @_;

$root_path = $GBS::ROOT_PATH
if (!defined $root_path);

return GBSGLO_select_dirs( SLURP_dir_dirs( "$root_path/dev", 0));
}




sub GBSGLO_subsystem_refs()
{
my @refs;	# [ $subsys, $ss_type ]

foreach my $subsys (@GBS::ALL_SUBSYSTEMS)
{
push @refs, [ $subsys, SSPROP_get_type( undef, $subsys) ];
}

return @refs;
}





sub GBSGLO_subsystem_exists($$)
{
my ($root_path, # may be undef (== current root)
$subsys,    # case sensitive!
) = @_;
my $exists;

$root_path = $GBS::ROOT_PATH
if (!defined $root_path);

$exists = grep( $_ eq $subsys, GBSGLO_select_dirs( SLURP_dir_dirs( "$root_path/dev", 0)));


return $exists;
}




sub GBSGLO_subsystems_full_gbs()
{
return grep( SSPROP_is_full_gbs( undef, $_), @GBS::ALL_SUBSYSTEMS);
}




sub GBSGLO_subsystems_non_gbs()
{
return grep( ! SSPROP_is_full_gbs( undef, $_), @GBS::ALL_SUBSYSTEMS);
}




sub GBSGLO_subsystem_is_full_gbs($;$)
{
my ($subsys,
$root_path,	# optional.
) = @_;


$root_path = undef
if (defined $root_path && $root_path eq $GBS::ROOT_PATH);

return SSPROP_is_full_gbs( $root_path,  $subsys);
}




sub GBSGLO_subsystems_for_build($)
{
my ($build) = @_;


return grep( -e "$GBS::ROOT_PATH/dev/$_/build/$build", @GBS::ALL_SUBSYSTEMS);
}




sub GBSGLO_subsystems_for_audit($$)
{
my ($audit,
$build,    # may be undef
) = @_;


if (defined $build)
{
return grep( -e "$GBS::ROOT_PATH/dev/$_/audit/$audit/$build", @GBS::ALL_SUBSYSTEMS);
} else
{
return grep( -e "$GBS::ROOT_PATH/dev/$_/audit/$audit", @GBS::ALL_SUBSYSTEMS);
}
}




sub GBSGLO_subsystems_for_tool($)
{
my ($tool) = @_;


return grep( -e "$GBS::ROOT_PATH/dev/$_/tool/$tool", @GBS::ALL_SUBSYSTEMS);
}




sub GBSGLO_subsystem_does_build($$)
{
my ($subsys,
$build,
) = @_;

return (-e "$GBS::ROOT_PATH/dev/$subsys/build/$build") ? 1 : 0;
}




sub GBSGLO_subsystem_does_audit($$$)
{
my ($subsys,
$audit,
$build,
) = @_;

return (-e "$GBS::ROOT_PATH/dev/$subsys/audit/$audit/$build") ? 1 : 0;
}




sub GBSGLO_subsystem_does_tool($$)
{
my ($subsys,
$tool,
) = @_;

return (-e "$GBS::ROOT_PATH/dev/$subsys/tool/$tool") ? 1 : 0;
}




sub GBSGLO_subsystem_type($)
{
my ($subsys) = @_;
my $ss_type;	    # 'GBS', 'MSVS', 'make', 'Other'

$ss_type = SSPROP_get_type( undef, $subsys);

return $ss_type;
}





sub GBSGLO_subsystem_builds($)
{
my ($subsys) = @_;
my @builds;

@builds = SLURP_dir_dirs( "$GBS::ROOT_PATH/dev/$subsys/build", 0);
@builds = grep { exists $GBS::BUILDS{$_} } @builds;

return @builds;
}





sub GBSGLO_subsystem_audits($)
{
my ($subsys) = @_;
my @audits;

@audits = SLURP_dir_dirs( "$GBS::ROOT_PATH/dev/$subsys/audit", 0);
@audits = grep { exists $GBS::AUDITS{$_} } @audits;

return @audits;
}





sub GBSGLO_subsystem_tools($)
{
my ($subsys) = @_;
my @tools;

@tools = SLURP_dir_dirs( "$GBS::ROOT_PATH/dev/$subsys/tool", 0);
@tools = grep { exists $GBS::TOOLS{$_} } @tools;

return @tools;
}




sub GBSGLO_components(;$$)
{
my ($subsys,	# Optional
$root_path,	# Optional
) = @_;


$subsys = $GBS::SUBSYS
if (!defined $subsys);
$root_path = $GBS::ROOT_PATH
if (!defined $root_path);

return GBSGLO_select_dirs( SLURP_dir_dirs( "$root_path/dev/$subsys/comp", 0));
}





sub GBSGLO_component_exists($$$)
{
my ($root_path, # may be undef (== current root)
$subsys,    #case sensitive!
$component, #case sensitive!
) = @_;
my $exists;

$root_path = $GBS::ROOT_PATH
if (!defined $root_path);

$exists = grep( $_ eq $component, GBSGLO_select_dirs( SLURP_dir_dirs( "$root_path/dev/$subsys/comp", 0)));


return $exists;
}




sub GBSGLO_components_for_build($$)
{
my ($subsys,
$build,
) = @_;
my @components;

if (GBSGLO_subsystem_does_build( $subsys, $build))
{
@components = grep( -e "$GBS::ROOT_PATH/dev/$subsys/comp/$_/bld/$build", GBSGLO_components( $subsys));
}

return @components;
}




sub GBSGLO_components_for_audit($$$)
{
my ($subsys,
$audit,
$build,
) = @_;
my @components;

if (GBSGLO_subsystem_does_audit( $subsys, $audit, $build))
{
@components = grep( -e "$GBS::ROOT_PATH/dev/$subsys/comp/$_/aud/$audit/$build" &&
-e "$GBS::ROOT_PATH/dev/$subsys/comp/$_/bld/$build", GBSGLO_components( $subsys));
}

return @components;
}




sub GBSGLO_component_does_build($$$)
{
my ($subsys,
$component,
$build,
) = @_;

if (GBSGLO_subsystem_does_build( $subsys, $build))
{
return (-e "$GBS::ROOT_PATH/dev/$subsys/comp/$component/bld/$build") ? 1 : 0;
} else
{
return 0;
}
}




sub GBSGLO_component_does_audit($$$$)
{
my ($subsys,
$component,
$audit,
$build,
) = @_;

if (GBSGLO_subsystem_does_audit( $subsys, $audit, $build))
{
return (-e "$GBS::ROOT_PATH/dev/$subsys/comp/$component/aud/$audit/$build" &&
-e "$GBS::ROOT_PATH/dev/$subsys/comp/$component/bld/$build" ) ? 1 : 0;
} else
{
return 0;
}
}





sub GBSGLO_component_builds($$)
{
my ($subsys,
$component,
) = @_;
my @builds;

foreach my $build (@GBS::BUILDS)
{
push @builds, $build
if (GBSGLO_component_does_build( $subsys, $component, $build));
}

return @builds;
}




sub GBSGLO_component_audits($$)
{
my ($subsys,
$component,
) = @_;
my @audits;

my %audits;
foreach my $audit (@GBS::AUDITS)
{
foreach my $build (@GBS::BUILDS)
{
$audits{$audit} = 1
if (GBSGLO_component_does_audit( $subsys, $component, $audit, $build));
}
}
@audits = sort keys %audits;

return @audits;
}





sub GBSGLO_glob($)
{
my ($glob_string) = @_;	# May be a PATH
my @specs;

foreach my $spec (ENV_glob( $glob_string))
{
push @specs, $spec
unless (grep( $spec =~ $_, @GBS::SKIPTYPES));
}

return @specs;
}





sub GBSGLO_validate_spec($)
{
my ($spec) = @_;  	# path, dir, filespec or file


return (grep( $spec =~ $_, @GBS::SKIPTYPES)) ? 0 : 1;
}





sub GBSGLO_select_dirs(@)
{

my @out_dirs;

my $not_dir_chars_qm = quotemeta ':&()<>^;|,*? .';
@out_dirs = grep( $_ !~ /[$not_dir_chars_qm]/, @_);



return @out_dirs;
}





sub GBSGLO_select_specs(@)
{

my @out;


foreach my $spec (@_)
{
push @out, $spec unless (grep( $spec =~ $_, @GBS::SKIPTYPES));
}

return @out;
}





sub GBSGLO_exclude_specs(@)
{

my @out;


foreach my $file (@_)
{
push @out, $file if (grep( $file =~ $_, @GBS::SKIPTYPES));
}

return @out;
}




sub GBSGLO_short_filespecs(@)
{

my @short_filespecs;

my $gbs_root_qm = quotemeta( $GBS::ROOT_PATH);
my $gbs_scripts_qm = quotemeta( $GBS::SCRIPTS_PATH);
my @root_path_qms = grep $_, ($gbs_root_qm, $gbs_scripts_qm);

foreach my $filespec (@_)
{
if ($filespec)	    # may be undef
{
my $short_filespec = $filespec;
foreach my $root_path_qm (@root_path_qms)
{
last
if ($short_filespec =~ s/^$root_path_qm/\$GBS_ROOT_PATH/);
}
push @short_filespecs, $short_filespec;
} else
{
push @short_filespecs, $filespec;
}
}

return (wantarray) ? @short_filespecs : $short_filespecs[0];
}





sub GBSGLO_find_root_path($)
{
my ($filespec) = @_;	# Abs dir- or file- spec
my $root_path = '';

$root_path = $filespec;
$root_path =~ s!/[^/]*$!!
if (-f $root_path);

while ($root_path ne '' && !-f "$root_path/system.gbs" && !-d "$root_path/dev")
{
$root_path = ''
if ($root_path !~ s!/[^/]*$!!);
}


return $root_path;
}




sub GBSGLO_split_gbs_spec($)
{
my ($filespec) = @_;
my ($root_path, $subsys, $component, $remain) = ( '', '', '', '' );

my $gbs_root_path = $GBS::ROOT_PATH;
if ($gbs_root_path ne '' && ENV_is_in_path( $filespec, $gbs_root_path))
{
$root_path = $gbs_root_path;
} else
{
$root_path = GBSGLO_find_root_path( $filespec);	    # Search backwards for /system.gbs and /dev
}

if ($root_path ne '')
{
if ($filespec =~ m!$root_path/dev/([^/]+)/comp/([^/]+)! && -d "$root_path/dev/$1/comp/$2")
{
$subsys = $1;
$component = $2;
$remain = substr( $filespec, length( "$root_path/dev/$subsys/comp/$component"));
} elsif ($filespec =~ m!$root_path/dev/([^/]+)! && -d "$root_path/dev/$1")
{
$subsys = $1;
$remain = substr( $filespec, length( "$root_path/dev/$subsys"));
} else
{
$remain = substr( $filespec, length( $root_path));
}
$remain = substr( $remain, 1)
if (substr( $remain, 0, 1) eq '/');
}


return ($root_path, $subsys, $component, $remain);
}

1;


