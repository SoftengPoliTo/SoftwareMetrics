#=================================================
#
#   banner.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::banner;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
BANNER_box
BANNER_lines
BANNER_print
);
}




use glo::env;
use glo::time;
use glo::format;




sub BANNER_box($$$);
sub BANNER_lines($$$);
sub BANNER_print($$);








my %BANNERS = (

JOB		=> [ '===', '=', undef, 0, 0, ],	# logfile
SYSTEM	=> [ '***', '*', '*',   1, 1, ],	# System
SUBSYS	=> [ '---', '-', '-',   1, 1, ],	# SubSystem
COMPONENT	=> [ '*',   '',  '',    0, 0, ],	# Component
FILE	=> [ '',    '',  '-',   0, 0, ],	# File
NOTE	=> [ '**',  '',  undef, 0, 0, ],	# Note
FAIL	=> [ '###', '#', '#',   1, 0, ],	# FAil
);




sub BANNER_box($$$)
{
my ($top_side,	# vertical. mirrored at the bottom. nr chars == nr_lines, '' = none
$left_side,	# mirrored at the right. '' = fill with spaces
$texts_ref,	# [ $text, ... ] or [ [ @table_text ], ...
) = @_;
my @lines;

my $max_fill = 0;
map { $max_fill = length( $_) if (length( $_) > $max_fill) } @{$texts_ref};
my $max_cols = $max_fill + 2 * length( $left_side);

my $right_side = join( '', reverse( split( '', $left_side)));

my @top_chars = split( '', $top_side);


foreach my $top_char (@top_chars)
{
push @lines, $top_char x $max_cols;
}


foreach my $line (@{$texts_ref})
{
push @lines, $left_side . $line . ' ' x ($max_fill - length( $line)) . $right_side;
}


foreach my $top_char (reverse @top_chars)
{
push @lines, $top_char x $max_cols;
}

return @lines;
}




sub BANNER_lines($$$)
{
my ($l_margin,
$level,		# JOB SYSTEM, SUBSYS, COMPONENT, FILE, NOTE
$texts_ref,
) = @_;
my @lines;

$texts_ref = [ $texts_ref ]
if (!ref $texts_ref);

my $ref = $BANNERS{$level};
ENV_sig( F => "Invalid level $level")
if (!defined $ref);
my ($lead, $border, $sep, $padding, $do_time_stamp) = @{$ref};
my $max_text_width = ENV_get_term_size() - $l_margin;
my $lead_l = length( $lead);
my $border_l = ($border eq '') ? 0 : $max_text_width - $lead_l;
my $body_lead = ($lead eq '') ? '' : "$lead ";




push @lines, $sep
if (defined $sep);
push @lines, $lead . $border x $border_l;
push @lines, $lead
if ($padding);




if ($do_time_stamp)
{
my @text_refs = map { (ref $_) ? [ '', @{$_} ] : [ '', $_ ] } @{$texts_ref};
my $now = TIME_time2num();



$text_refs[0]->[0] = "$now -";
my @table_lines = FORMAT_table( -($lead_l + 1), 0, ' ', undef, @text_refs);
push @lines, map { "$lead $_" } @table_lines;
} else
{




my @text_refs = map { (ref $_) ? [ @{$_} ] : (defined $_) ? [ $_ ] : undef }  @{$texts_ref};
my @table_lines = FORMAT_table( -($lead_l + 1), 0, ' ', undef, @text_refs);

push @lines, map { (defined $_) ? "$lead $_" : $lead . $border x $border_l } @table_lines;











}




push @lines, $lead
if ($padding);
push @lines, $lead . $border x $border_l;

return @lines;
}




sub BANNER_print($$)
{
my ($level,
$texts_ref,
) = @_;

ENV_say( 0, BANNER_lines( 0, $level, $texts_ref));
}

1;


