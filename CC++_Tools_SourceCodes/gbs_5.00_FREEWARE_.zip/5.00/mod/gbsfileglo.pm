#=================================================
#
#   gbsfileglo.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbsfileglo;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSFILEGLO_select_usr_gbs
GBSFILEGLO_open_file
GBSFILEGLO_get_line
GBSFILEGLO_get_line_ref
GBSFILEGLO_close_file
GBSFILEGLO_build_line_select
GBSFILEGLO_get_paths
GBSFILEGLO_sig
GBSFILEGLO_file_sig
GBSFILEGLO_get_line_info
);
}




use glo::env;
use glo::slurp;
use glo::path;
use mod::gbsglo;




sub GBSFILEGLO_select_usr_gbs($);
sub GBSFILEGLO_open_file($$$$$);
sub GBSFILEGLO_get_line();
sub GBSFILEGLO_get_line_ref();
sub GBSFILEGLO_close_file();
sub GBSFILEGLO_build_line_select($$);
sub GBSFILEGLO_get_paths();
sub GBSFILEGLO_sig($@);
sub GBSFILEGLO_file_sig($$@);
sub GBSFILEGLO_get_line_info($);

sub find_usr_gbs($$);
sub read_file($);
sub next_line();
sub search_path($);
sub search_gbs_path($$);
sub build_select($$$);




my @ALL_DIRECTIVES = ( '.include', '.plugin', '.eol_comment', '.builds', '.exit');




my $MAIN_FILE_SPEC;
my $PLUGIN_NAME;		# must remain alive until a new file is read
my $PLUGIN_PATH;		# must remain alive until a new file is read
my $PLUGINS_ROOT_PATH;
my @USED_FILE_PATHS;		# must remain alive until a new file is read
my @INC_PATHS;
my $BUILD;
my $ALLOW_BUILDS_DIRECTIVE;

my $EOL_COMMENT_ENABLED = 0;	# .eol_comment

my %INCLUDED_FILES;		# prevents recursive includes


my @DEPENDENCIES;

my @FILE_REFS;			# stack for included files

my $CUR_FILE_REF;

my $CUR_LINE_REFS_REF;


my %GBS_FILES;





sub GBSFILEGLO_select_usr_gbs($)
{
my ($spec,			# with or without .gbs or .usr
) = @_;
my ($filespec, $type);	# undef == does not exist

if ($spec =~ /\.(gbs|usr)$/)
{
if (-e $spec)
{
$type = ".$1";
if ($type eq '.usr')
{
ENV_say( 1, '*** Using .usr file:', "*** $spec");

}
$filespec = $spec;
}
return (wantarray) ? ($filespec, $type) : $filespec;

} else
{
my $spec_without_type = $spec;
if (exists( $GBS_FILES{$spec_without_type}))
{
$filespec = $GBS_FILES{$spec_without_type};
} else
{
my $usr_spec = "$spec_without_type.usr";
if (PATH_file_exists( $usr_spec))
{
$filespec = $usr_spec;
ENV_say( 1, '*** Using .usr file:', "*** $usr_spec");

} else
{
$filespec = "$spec_without_type.gbs";
$filespec = undef
if (!PATH_file_exists( $filespec))
}
$GBS_FILES{$spec_without_type} = $filespec;
}
if (wantarray)
{
if (defined $filespec)
{
$type = substr( $filespec, -4, 4);
}
return ($filespec, $type);

} else
{
return $filespec;
}
}
}




sub find_usr_gbs($$)
{
my ($file_name,	    	    	# without .gbs or .usr
$path_ref,
) = @_;
my $filespec;

foreach my $dir (@{$path_ref})
{
$filespec = GBSFILEGLO_select_usr_gbs( "$dir/$file_name");
last if (defined $filespec);
}

return $filespec;
}

















sub GBSFILEGLO_open_file($$$$$)
{
(   $MAIN_FILE_SPEC,	    # full file-spec
my $inc_paths_ref,		    # in application. May be undef. Enables .include
$PLUGINS_ROOT_PATH,	    # e.g: $GBS_SCRIPTS_PATH/plugins/build. May be undef. Enables .plugin
$BUILD,			    # used for build_line_select. May be undef. Enables build_line_select
$ALLOW_BUILDS_DIRECTIVE	    # Bool. Enables .builds
) = @_;







@INC_PATHS = (defined $inc_paths_ref) ? @{$inc_paths_ref} : ();

$EOL_COMMENT_ENABLED = 0;

%INCLUDED_FILES = ();
$PLUGIN_NAME = ENV_parent_dir( $MAIN_FILE_SPEC, -2);
$PLUGIN_PATH = '';
@USED_FILE_PATHS = ();
@DEPENDENCIES = ();

$CUR_FILE_REF = undef;
read_file( $MAIN_FILE_SPEC);
}





sub GBSFILEGLO_get_line()
{
my $line;

my $again;
do
{
$again = 0;
($line, my $line_type, my $type_data1, my $type_data2) = next_line();
if (defined $line)
{

if ($line_type eq '=')
{

} elsif ($line_type eq '>')
{

push @FILE_REFS, $CUR_FILE_REF;
read_file( $type_data1);
$again = 1;
} elsif ($line_type eq '<')
{

$CUR_FILE_REF = pop @FILE_REFS;
$CUR_LINE_REFS_REF = $CUR_FILE_REF->[3];    # $line_refs_ref
$again = 1;
} elsif ($line_type eq 'X')   # skip
{

$again = 1;
} else
{
ENV_sig( F => "impossible else, line_type='$line_type'");
}
} else
{

}
} while ($again);

return $line;
}





sub GBSFILEGLO_get_line_ref()
{
my $line_ref;








my $again;
do
{
$again = 0;
my ($line, $line_type, $type_data1, $type_data2) = next_line();
if (defined $line)
{

if ($line_type eq '=')
{
$line_ref = [ $line, $CUR_FILE_REF->[1], $CUR_FILE_REF ];   # $next_index
} elsif ($line_type eq '>')
{

$line_ref = [ [ $line, $line_type, $type_data1, $type_data2 ], $CUR_FILE_REF->[1], $CUR_FILE_REF ];   # $next_index
push @FILE_REFS, $CUR_FILE_REF;
read_file( $type_data1);
} elsif ($line_type eq '<')
{

$line_ref = [ [ $line, $line_type, $type_data1, $type_data2 ], $CUR_FILE_REF->[1], $CUR_FILE_REF ];   # $next_index
$CUR_FILE_REF = pop @FILE_REFS;
$CUR_LINE_REFS_REF = $CUR_FILE_REF->[3];    # $line_refs_ref

} elsif ($line_type eq 'X')   # skip
{

$again = 1;
} else
{
ENV_sig( F => "Impossible else, line_type='$line_type'");
}
} else
{

}
} while ($again);

return $line_ref;
}




sub GBSFILEGLO_close_file()
{





@INC_PATHS = ();
%INCLUDED_FILES = ();
@FILE_REFS = ();
$CUR_LINE_REFS_REF = undef;

return wantarray ? ( $PLUGIN_NAME, [ GBSFILEGLO_get_paths() ], [ @DEPENDENCIES ] ) : [ @DEPENDENCIES ];
}




sub read_file($)
{
my ($filespec,		# we know the file exists
) = @_;


{



my @line_refs;
{
my $full_line = '';
my $line_nr = 0;
foreach my $line (SLURP_file( $filespec))
{
$line_nr++;
next if ($line eq '' || substr( $line, 0, 1) eq '#');
if ($full_line ne '')
{
$line =~ s/^\s+//;		# remove leading spaces
$full_line .= $line;
} else
{
$full_line = $line;
}
if ($full_line =~ /\s+\\$/)	# line ends with '<space>\'
{
$full_line =~ s/\s+\\$/ /;	# replace '<spaces>\' by 1 space
} else
{
push @line_refs, [ $full_line, $line_nr, undef ];
$full_line = '';
}
}
if ($full_line ne '')
{


push @line_refs, [ "$full_line \\", $line_nr, undef ];
}

}

my $nr_lines = @line_refs;
$CUR_LINE_REFS_REF = [ @line_refs ];
$CUR_FILE_REF = [ $filespec, 0, $nr_lines, $CUR_LINE_REFS_REF ];
}

$INCLUDED_FILES{$filespec} = 1;

push @DEPENDENCIES, $filespec
if (! grep( $_ eq $filespec, @DEPENDENCIES));

my $dir = ENV_split_spec_p( $filespec);
push @USED_FILE_PATHS, $dir
if (! grep( $_ eq $dir, @USED_FILE_PATHS));

}




sub next_line()
{
my ($line, $line_type, $type_data1, $type_data2) = ( '', '', '', '');









my $next_index = $CUR_FILE_REF->[1];
ENV_stackdump() if (!defined $next_index);
$line = $CUR_LINE_REFS_REF->[$next_index]->[0];	# $line
$CUR_FILE_REF->[1]++;				# $next_index

if (!defined $line)
{
if (@FILE_REFS > 0)
{




$line_type = '<';	    # retuning from include
$line = '';
} else
{



$line_type = 'X';	    # skip line
}
} else
{
my $must_handle_this_line = 1;




if ($EOL_COMMENT_ENABLED && index( $line, '#') >= 0)
{
$line =~ s/^(.*?)\s+#\s.*$/$1/;

$CUR_LINE_REFS_REF->[$next_index]->[2] = $line;    # $reduced_line
$must_handle_this_line = 0
if ($line eq '');
}




if ($must_handle_this_line && defined $BUILD)
{
my ($application_part, $selected) = GBSFILEGLO_build_line_select( $line, $BUILD);
if ($selected)
{
$line = $application_part;
$CUR_LINE_REFS_REF->[$next_index]->[2] = $line;    # $reduced_line
} else
{
$must_handle_this_line = 0;

}
}

if (!$must_handle_this_line)
{
$line_type = 'X';	    # skip line
} elsif (substr($line, 0, 1) eq '.')
{



if ($line =~ /^\.plugin\s+(.+)$/)
{



GBSFILEGLO_sig( EE => '.plugin directive not allowed in this type of file')
if (!defined $PLUGINS_ROOT_PATH);
my $plugin = $1;
my $plugin_path = PATH_search_file( $plugin, [ $PLUGINS_ROOT_PATH, @INC_PATHS ]);
if ($plugin_path eq '')
{
my @short_path_specs = GBSGLO_short_filespecs( @INC_PATHS, $PLUGINS_ROOT_PATH);
GBSFILEGLO_sig( EE => "Could not find plugin '$plugin' in:", @short_path_specs);
}
if ($PLUGIN_PATH eq '')
{
$PLUGIN_NAME = $plugin;
$PLUGIN_PATH = $plugin_path;
push @INC_PATHS, $PLUGIN_PATH
if (!grep( $_ eq $PLUGIN_PATH, @INC_PATHS));
} else
{
GBSFILEGLO_sig( EE => "Plugin '$plugin' was already set to '$PLUGIN_PATH'")
if ($plugin_path ne $PLUGIN_PATH );
}
$line_type = 'X';	# skip line
} elsif ($line =~ /^\.include\s+(.+)$/)
{



GBSFILEGLO_sig( EE => '.include directive not allowed in this type of file')
if (!@INC_PATHS);
my $inc_file = $1;
my $fc = substr( $inc_file, 0, 1);
my $fci = index( "<\"'", $fc);
if ($fci >= 0)
{
my $lc = substr( ">\"'", $fci, 1);
$inc_file = substr( $inc_file, 1, -1)
if (substr( $inc_file, -1, 1) eq $lc);
}
GBSFILEGLO_sig( EE => "'..' not allowed in .include")
if ($inc_file =~ /\.\./);
GBSFILEGLO_sig( EE => "Absolute file path not allowed in .include")
if (ENV_is_abs_path( $inc_file));
my $inc_filespec;

if (defined $PLUGINS_ROOT_PATH)
{

my ($inc_dir, $inc_name, $inc_type) = ENV_split_spec_pnt( $inc_file);
my $dir_and_name = ($inc_dir) ? "$inc_dir/$inc_name" : $inc_name;
GBSFILEGLO_sig( EE => "Can only .include <name_spec>.gbs file ($inc_file)")
if ($inc_type ne '.gbs');
$inc_filespec = search_gbs_path( $dir_and_name, $fc);
} else
{
GBSFILEGLO_sig( EE => "Directory specification not allowed in this .include ($inc_file)")
if ($inc_file =~ m!(/|\\)!);
$inc_filespec = search_path( $inc_file);
}


GBSFILEGLO_sig( EE => "Recursive include! ($inc_filespec)")
if ($INCLUDED_FILES{$inc_filespec});
$line_type = '>';
$type_data1 = $inc_filespec;
$type_data2 = $inc_file;
} elsif ($line =~ /^\.eol_comment\s+(.+)$/)
{



my $on_or_off = $1;
if (lc $on_or_off eq 'enable')
{
$EOL_COMMENT_ENABLED = 1;
} elsif (lc $on_or_off eq 'disable')
{
$EOL_COMMENT_ENABLED = 0;
} else
{
GBSFILEGLO_sig( EE => "Value ($on_or_off) mut be either 'enable' or 'disable'");
}
$line_type = 'X';	# skip line
} elsif ($line =~ /^\.builds(.+)$/)
{



GBSFILEGLO_sig( EE => '.builds directive not allowed in this type of file')
if (!$ALLOW_BUILDS_DIRECTIVE);
my $rest = $1;
my ($op, $value) = $rest =~ /^(=|!=)(.+)$/;
GBSFILEGLO_sig( EE => "Syntax is '.builds[=|!=]<build|build_comma_list>'")
if (!defined $op);

my @wild_builds = split( ',', $value);
my $build_selected = build_select( $BUILD, $op, \@wild_builds);
{
my $selected = ($build_selected) ? 'selected' : 'NOT selected';

}
if ($build_selected)
{
$line_type = 'X';	# skip line
} else
{
$CUR_FILE_REF->[1] = $CUR_FILE_REF->[2];  # $next_index = $nr_lines (stop processing)
$line = 'DUMMY';
$line_type = '=';   # normal line
}
} elsif ($line =~ /^\.exit$/)
{



GBSFILEGLO_sig( W => "Premature exit of file - OK if just testing");
$CUR_FILE_REF->[1] = $CUR_FILE_REF->[2];  # $next_index = $nr_lines
$line_type = 'X';  	# skip line
} elsif ($line =~ /^\.end$/)
{



$CUR_FILE_REF->[1] = $CUR_FILE_REF->[2];  # $next_index = $nr_lines
$line_type = 'X';  	# skip line
} else
{
GBSFILEGLO_sig( EE => "Invalid directive. Allowed: @ALL_DIRECTIVES");
}
} else
{



$line_type = '=';	    # normal line
}
}

return ( $line, $line_type, $type_data1, $type_data2 );
}




sub GBSFILEGLO_build_line_select($$)
{
my ($line,
$this_build,
) = @_;
my ($application_part, $selected);

($application_part, my $build_op, my $build_part) = $line =~ /(.*)\s+(==|!=)\s([\w\s*?]+)$/;
if (defined $build_part)
{
$application_part =~ s/\s+$//;	    # remove trailing whites


my @wild_builds = split( ' ', $build_part);
$selected = build_select( $this_build, $build_op, \@wild_builds);
} else
{
$application_part = $line;
$selected = 1;
}

return ($application_part, $selected);
}




sub GBSFILEGLO_get_paths()
{
my @file_paths = @USED_FILE_PATHS;

push @file_paths, $PLUGIN_PATH
if ($PLUGIN_PATH && !grep( $_ eq $PLUGIN_PATH, @file_paths));


return @file_paths;
}







sub GBSFILEGLO_sig($@)
{
my ($sig,		# <severity><action> IWEF  EC
@lines_or_refs
) = @_;

my $file_info_ref = [ undef, GBSFILEGLO_get_line_info( undef) ];	    # the first undef is $prefix



ENV_file_sig( $sig => $file_info_ref, @lines_or_refs);
}







sub GBSFILEGLO_file_sig($$@)
{
my ($sig,		# <severity><action> IWEF  XC
$line_ref,	# as returned by GBSFILEGLO_get_line_ref or undef for current line or '' if unknown
@lines_or_refs
) = @_;

my $file_info_ref = [ undef, GBSFILEGLO_get_line_info( $line_ref) ];



ENV_file_sig( $sig => $file_info_ref, @lines_or_refs);
}




sub GBSFILEGLO_get_line_info($)
{
my ($line_ref) = @_;    # as returned by GBSFILEGLO_get_line_ref or undef for current line or '' if unknown
my ($src, $file, $line_nr, $line, $opt_reduced_line);   # do not change order: used by ENV_file_sig

my $file_ref;
my $next_index;
if (defined $line_ref)
{
(undef, $next_index, $file_ref) = @{$line_ref};
} else
{
$file_ref = $CUR_FILE_REF;
$next_index = $CUR_FILE_REF->[1];		# $next_index;
}
if (ref $file_ref)
{
($src, $file) = GBSGLO_short_filespecs( $MAIN_FILE_SPEC, $file_ref->[0]);
my $cur_index = $next_index - 1;
my $line_refs_ref = $file_ref->[3];	    # $line_refs_ref
($line, $line_nr, $opt_reduced_line) = @{$line_refs_ref->[$cur_index]};
$opt_reduced_line = undef
if (defined $opt_reduced_line && $opt_reduced_line eq $line);

if (defined $opt_reduced_line)
{
return ($src, $file, $line_nr, $line, $opt_reduced_line);
} else
{
return ($src, $file, $line_nr, $line);
}
} else
{
return ( '', '', 0, '');
}
}




sub search_path($)
{
my ($file,
) = @_;
my $filespec;

$filespec = PATH_search_file( $file, \@INC_PATHS);
if (!$filespec)
{
my @short_path_specs = GBSGLO_short_filespecs( @INC_PATHS);
GBSFILEGLO_sig( EE => "Could not find '$file' in:", @short_path_specs);
}

return $filespec;
}




sub search_gbs_path($$)
{
my ($file,	    # dir + file_name, without .gbs or .usr
$fc,	    # < or " or other
) = @_;
my $filespec;

if ($fc eq '<')
{

$filespec = GBSFILEGLO_select_usr_gbs( "$PLUGIN_PATH/$file");
GBSFILEGLO_sig( EE => "Could not find '$file.gbs(.usr)' in '$PLUGIN_PATH'")
if (!$filespec);
} else
{

$filespec = find_usr_gbs( $file, \@INC_PATHS);
if (!$filespec)
{
my @short_path_specs = GBSGLO_short_filespecs( @INC_PATHS);
GBSFILEGLO_sig( EE => "Could not find '$file.gbs(.usr)' in:", @short_path_specs);
}
}

return $filespec;
}




sub build_select($$$)
{
my ($this_build,
$operator,		# = == ! !=
$wild_builds_ref,
) = @_;
my $selected;

my @non_matches;
my @builds = ENV_wildcards( $wild_builds_ref, \@GBS::ALL_BUILDS, \@non_matches);
GBSFILEGLO_sig( EE => "No such Build(s) '@non_matches'")
if (@non_matches);
if (substr( $operator, 0, 1) eq '=')
{
$selected = grep( $this_build eq $_, @builds);
} else
{
$selected = !grep( $this_build eq $_, @builds);
}

return $selected;
}

1;


