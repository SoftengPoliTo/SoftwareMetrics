#=================================================
#
#   proc.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::proc;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
PROC_at
PROC_at_show
PROC_spawn_detached
PROC_spawn_detached_xterm
PROC_spawn_terminal
PROC_spawn
PROC_wait
PROC_waitpid
PROC_waitpid_test
PROC_kill
);
}




use POSIX qw(:errno_h :sys_wait_h);









use glo::env;
use glo::shell;




sub PROC_at($$$$$);
sub PROC_at_show();
sub PROC_spawn_detached($$);
sub PROC_spawn_detached_xterm($$$;$$$);
sub PROC_spawn_terminal($;$$$);
sub PROC_spawn($$);
sub PROC_wait();
sub PROC_waitpid($);
sub PROC_waitpid_test($);
sub PROC_kill($);

sub background_command($);





my $IS_WIN32 = ENV_is_win32();




sub PROC_at($$$$$)
{
my ($command_items_ref,
$name,			# jobname
$delay,			# now | [=+]hh:mm
$must_mail,		# bool
$os_log_filespec,
) = @_;



my $os_command = SHELL_at( $command_items_ref, $name, $delay, $must_mail, $os_log_filespec);
if ($IS_WIN32)
{
$os_command = "start \"$name\" /I /MIN cmd /k \"$os_command\"";
}

ENV_system( $os_command, 0);
}





sub PROC_at_show()
{
if ($IS_WIN32)
{

} else
{
my $rc = ENV_system( SHELL_at_show(), [0, 1]);
ENV_sig( W => "'\\atq' returned rc=$rc. This seems to happen sometimes without known reason...")
if ($rc != 0);
}
}





sub PROC_spawn_detached($$)
{
my ($command_items_ref, # list
$oks_ref,	    # allowed return-codes (undef == nocheck)
) = @_;
my $rc = 0;



my $command_line = ENV_prepare_command( $command_items_ref);

if ($IS_WIN32)
{
$command_line = "start \"\" /MIN $command_line";

$rc = ENV_system( $command_line, $oks_ref);
} else #assume LUNIX
{
my $full_command = background_command( $command_line);

$rc = ENV_system( $full_command, $oks_ref);
}

return $rc;
}





sub PROC_spawn_detached_xterm($$$;$$$)
{
my ($command_items_ref,	# may be undef
$xtitle,
$pause,
$geometry_ref,		# Optional [ $cols, $rows, $x, $y ]. Default = [ 100, 50 ]
$colour_ref,		# Optional [ $fg, $bg ]. Default = [ blue, white ]
$icon,			# Optional
) = @_;



my ($cols, $rows, $x, $y) = ENV_deref( $geometry_ref);
($cols, $rows) = SHELL_get_geometry( $cols, $rows);		# fill in the defaults

my ($fg, $bg) = ENV_deref( $colour_ref);
my ($fgc, $bgc) = SHELL_get_term_color_codes( $fg, $bg);

my $full_command;
my $command_to_execute = ENV_join_quoted_space( ENV_prepare_command( $command_items_ref));
if ($IS_WIN32)
{



my $script_file = ENV_get_tmp_spec( 'spawn_detached') . '.bat';
my $os_script_file = ENV_os_paths( $script_file);
my $pause = ($pause) ? 'pause' : ':: pause';
my @lines = (
'echo OFF',
"title $xtitle",
"color ${bgc}${fgc}",
"mode con: cols=$cols lines=$rows",
$command_to_execute,
$pause,
"start \"\" /B cmd /C del \"$os_script_file\" & exit",  # delete the tmp file
);
ENV_spit_file( $script_file, \@lines, 1, F => '>');	    # 1 == $must_add_nl
$full_command = "start \"$xtitle\" \"$script_file\"";

} else #assume LUNIX
{



my $geometry = "${cols}x${rows}";
$geometry .= "+$x+$y"
if (defined $x);
$command_to_execute =~ s/"/\\"/g;

my $pause = ($pause) ? SHELL_pause() : '';
$pause =~ s/"/\\"/g;
$full_command = "xterm -T \"$xtitle\" -fg $fgc -bg $bgc -geometry $geometry -e \"$command_to_execute;$pause\"";
$full_command = background_command( $full_command);

}

ENV_system( $full_command, 0);
}





sub PROC_spawn_terminal($;$$$)
{
my ($xtitle,
$geometry_ref,		# Optional [ $cols, $rows, $x, $y ]. Default = [ 100, 50 ]
$colour_ref,		# Optional [ $fg, $bg ]. Default = [ blue, white ]
$icon,			# Optional
) = @_;



my ($fg, $bg) = ENV_deref( $colour_ref);
my ($fgc, $bgc) = SHELL_get_term_color_codes( $fg, $bg);

my ($cols, $rows, $x, $y) = ENV_deref( $geometry_ref);
($cols, $rows) = SHELL_get_geometry( $cols, $rows);

my $full_command;
if ($IS_WIN32)
{
$xtitle = ' '
if ($xtitle eq '');	# Causes "Not enough storage is available to process this command"
$full_command = "start \"$xtitle\" cmd /T:${bgc}${fgc} /K \"mode con: cols=$cols lines=$rows\"";


} else #assume LUNIX
{
my $geometry = "${cols}x${rows}";
$geometry .= "+$x+$y"
if (defined $x);
$full_command = "xterm -T \"$xtitle\" -fg $fgc -bg $bgc -geometry $geometry}";
$full_command = background_command( $full_command);

}

ENV_system( $full_command, 0);
}





sub background_command($)
{
my ($command_line,
) = @_;
my $full_command;

my $logfile = (ENV_is_debug()) ? ENV_get_tmp_spec( 'nohup.out') : undef;    # undef = /dev/nul

$full_command = "nohup $command_line";
$full_command = SHELL_redirect_stdout_stderr( $full_command, $logfile, 1);
$full_command = SHELL_redirect_stdin( $full_command, undef);		    # undef = /dev/nul
$full_command = SHELL_run_background( $full_command);



return $full_command;
}






sub PROC_spawn($$)
{
my ($command_items_ref,		# ADT
$log_file,		# undef = do redirect
) = @_;
my $pid = 0;

ENV_debug( 1, "PROC_spawn:");

do
{
$pid = fork;
if (defined $pid)
{
if ($pid == 0)
{



ENV_debug( 1, "PROC_spawn: fork child");
ENV_exec( $command_items_ref, $log_file);
} else
{



ENV_debug( 1, "PROC_spawn: fork parent: child_pid=$pid");
}
} else
{
if ($! == EAGAIN)		# $OS_ERROR
{



my $command_line = ENV_prepare_command( $command_items_ref);
ENV_sig( W => "fork 'exec $command_line' failed",
"- $!",
"- Retry after 5 seconds");
sleep( 5);
} else
{
ENV_sig( F => "Unable to fork: $!");
}
}
} while (!defined $pid);

return $pid;
}






sub PROC_wait()
{
my ($r_pid, $rc);

ENV_debug( 1, "PROC_wait");
$r_pid = wait();
ENV_debug( 1, "- r_pid=$r_pid");

if ($r_pid != -1)
{
$rc = ENV_rc_status( $?, 'wait');
} else
{
$rc = -1;
}

return ($r_pid, $rc);
}






sub PROC_waitpid($)
{
my ($pid) = @_;	    # -1 == wait for any (is equal to PROC_Wait)
my $rc = 0;

ENV_debug( 1, "PROC_waitpid pid=$pid");
my $r_pid = waitpid( $pid, 0);
ENV_debug( 1, "- r_pid=$r_pid");

if ($r_pid != -1)
{
$rc = ENV_rc_status( $?, "$r_pid=waitpid $pid, 0");
} else
{
$rc = -1;
}

return (wantarray ? ($r_pid, $rc) : $rc);
}







sub PROC_waitpid_test($)
{
my ($pid) = @_;	# -1 == wait for any.
my $rc = 0;

ENV_debug( 1, "PROC_waitpid_test pid=$pid");
my $r_pid = waitpid( $pid, WNOHANG);
ENV_debug( 1, "- r_pid=$r_pid");

if ($r_pid != -1 && $r_pid != 0)
{
$rc = ENV_rc_status( $?, "waitpid_test $r_pid, " . WNOHANG);
} else
{
$rc = -1;
}

return (wantarray ? ($r_pid, $rc) : $rc);
}





sub PROC_kill($)
{
my ($pid) = @_;
my $killed = 0;	    # bool

ENV_debug( 1, "$$ PROC_kill pid=$pid");

if ($IS_WIN32)
{
my $command = "TASKKILL /F /T /PID $pid";





my ($rc, $stdout) = ENV_backtick( $command, undef, 1);
if ($rc == 0 || $stdout =~ /^SUCCESS.*with PID $pid .*/m)
{
$killed = 1;
}
ENV_debug( 1, "PROC_kill rc = $rc", $stdout, "killed=$killed");
} else  # $IS_LINUX
{
my $command = "kill -TERM $pid";
my $rc = ENV_system( $command, undef);
if ($rc == 0)
{
$killed = 1;
}
ENV_debug( 1, "PROC_kill rc=$rc, killed=$killed");
}

return $killed;
}

1;
