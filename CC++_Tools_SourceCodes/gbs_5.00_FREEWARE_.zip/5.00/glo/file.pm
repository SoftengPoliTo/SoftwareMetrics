#=================================================
#
#   file.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::file;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
FILE_mtime
FILE_find
FILE_recurse_tree
FILE_parse_tree
FILE_replicate_tree
FILE_del_tree
FILE_copy_template
FILE_copy_translate
FILE_replicate
FILE_move
FILE_del_dirs
FILE_del_files
);
}




use glo::env;
use glo::slurp;
use glo::spit;




sub FILE_mtime($);
sub FILE_find($$$$);
sub FILE_parse_tree($$$$);
sub FILE_recurse_tree($$$);
sub FILE_replicate_tree($$$$);
sub FILE_del_tree($$$$);
sub FILE_copy_template($$;@);
sub FILE_copy_translate($$;@);
sub FILE_replicate($$);
sub FILE_move($$$);
sub FILE_del_dirs($$);
sub FILE_del_files($$);

sub find($);
sub parse_tree($$);
sub replicate_tree($$);
sub copy_file($$);
sub my_mkdir($);
sub recurse_tree($);
sub del_tree($$);
sub init_recurse($$$$);
sub match_found($);
sub must_ignore($);
sub other_types($);
sub exit_recurse();














































my $FUNC_REF;		# $state = $func_ref->( $level, $is_dir, $path_spec, $name);
my @FIND_REGEXPS;	# regexps
my @IGNORE_REGEXPS;	# regexps
my $VERBOSE_LEVEL;	# 0 = nothing, 1 = ignore, 2 = directories, 3 = files, 4 = dir + files, 5 = max
my $RECURSING;		# BOOL
my $NR_DIRS_CREATED;
my $NR_FILES_COPIED;
my $NR_DIRS_DELETED;
my $NR_FILES_DELETED;
my $NR_TOTAL_SCANNED;

my $DEFAULT_MODE = oct(751);    # u=rwx g=rx o=x






sub FILE_mtime($)
{
my ($file_or_path_spec) = @_;
my $mtime;



$mtime = (stat( $file_or_path_spec))[9];	# $mtime
ENV_sig( F => "'stat' of file '$file_or_path_spec' failed")
if (!defined $mtime);

return $mtime;
}




sub FILE_find($$$$)
{
my ($path_spec,
$find_ref,	    # [ regexp, ... ] or $regexp. May be undef
$ignore_ref,	    # [ regexp, ... ] or $regexp. May be undef
$verbose_level,	    # 0 = nothing, 1 = ignore, 2 = directories, 3 = files, 4 = dir + files, 5 = max
) = @_;
my @found_files;

init_recurse( undef, $find_ref, $ignore_ref, $verbose_level);

if (!must_ignore( $path_spec))
{
push @found_files, find( $path_spec);
}

exit_recurse();

return @found_files;
}





sub find($)
{
my ($path_spec,
) = @_;
my @found_files;

if ($VERBOSE_LEVEL >= 2)
{
if ($path_spec eq '.')
{
ENV_say( 1, " Search Dir ./...");
} else
{
ENV_say( 1, " Search Dir $path_spec...");
}
}
foreach my $entry (SLURP_dir_all( $path_spec, 0))
{
if (!must_ignore( $entry))
{
my $entry_spec = "$path_spec/$entry";
if (-d $entry_spec)
{
if (match_found( $entry_spec))
{
push @found_files, $entry_spec;
}
push @found_files, find( $entry_spec);
} elsif (-f _)
{
if (match_found( $entry_spec))
{
ENV_say( 1, "  Found File $entry_spec")
if ($VERBOSE_LEVEL >= 3);
push @found_files, $entry_spec;
}
} else
{
other_types( $entry_spec);
}
}
}

return @found_files;
}




sub FILE_parse_tree($$$$)
{
my ($path_spec,
$func_ref,	    # $state = $func_ref->( $level, $is_dir, $path_spec, $name);

$ignore_ref,	    # [ regexp, ... ] or $regexp. May be undef
$verbose_level,	    # 0 = nothing, 1 = ignore, 2 = directories, 3 = files, 4 = dir + files, 5 = max
) = @_;
my $last_state;

init_recurse( $func_ref, undef, $ignore_ref, $verbose_level);

if (!must_ignore( $path_spec))
{
parse_tree( 0, $path_spec);
}

exit_recurse();
}





sub parse_tree($$)
{
my ($level,
$path_spec,
) = @_;
my $state = 0;		# 0 == continue, 1 = stop this_dir (next), 2 = total stop

$level++;
foreach my $entry (SLURP_dir_all( $path_spec, 0))
{
if (!must_ignore( $entry))
{
my $entry_spec = "$path_spec/$entry";
if (-d $entry_spec)
{
ENV_say( 1, " From  Dir $entry_spec...")
if ($VERBOSE_LEVEL >= 2);
$state = $FUNC_REF->( $level, 1, $path_spec, $entry);
$state = parse_tree( $level, $entry_spec)
if ($state == 0);
} elsif (-f _)
{
ENV_say( 1, " From File $entry_spec")
if ($VERBOSE_LEVEL >= 3);
$state = $FUNC_REF->( $level, 0, $path_spec, $entry);
} else
{
other_types( $entry_spec);
}
last
if ($state > 0);
}
}
$state = 0
if ($state == 1);

return $state;
}




sub FILE_recurse_tree($$$)
{
my ($path_spec,
$ignore_ref,	    # [ regexp, ... ] or $regexp. May be undef
$verbose_level,	    # 0 = nothing, 1 = ignore, 2 = directories, 3 = files, 4 = dir + files, 5 = max
) = @_;
my @entry_refs;	    # [ F or D, $full_spec ]

init_recurse( undef, undef, $ignore_ref, $verbose_level);

if (!must_ignore( $path_spec))
{
@entry_refs = recurse_tree( $path_spec);
}

exit_recurse();

return @entry_refs;
}





sub recurse_tree($)
{
my ($path_spec,
) = @_;
my (@file_refs, @path_refs);

foreach my $entry (SLURP_dir_all( $path_spec, 0))
{
if (!must_ignore( $entry))
{
my $entry_spec = "$path_spec/$entry";
if (-d $entry_spec)
{
ENV_say( 1, " From Dir $entry_spec...")
if ($VERBOSE_LEVEL >= 2);
push @path_refs, [ 'D', $entry_spec ];
push @path_refs, recurse_tree( $entry_spec);
} elsif (-f _)
{
ENV_say( 1, " From File $entry_spec")
if ($VERBOSE_LEVEL >= 3);
push @file_refs, [ 'F', $entry_spec ];
} else
{
other_types( $entry_spec);
}
}
}

return (@file_refs, @path_refs);
}




sub FILE_replicate_tree($$$$)
{
my ($from_path_spec,
$to_path_spec,
$ignore_ref,	    # [ regexp, ... ] or $regexp. May be undef
$verbose_level,	    # 0 = nothing, 1 = ignore, 2 = directories, 3 = files, 4 = dir + files, 5 = max
) = @_;


init_recurse( undef, undef, $ignore_ref, $verbose_level);




my_mkdir( $to_path_spec)
if (! -d $to_path_spec);

replicate_tree( $from_path_spec, $to_path_spec); # recurse

exit_recurse();

return ($NR_DIRS_CREATED, $NR_FILES_COPIED, $NR_DIRS_DELETED, $NR_FILES_DELETED);
}





sub replicate_tree($$)
{
my ($from_path_spec,
$to_path_spec,
) = @_;




my %to_items = map { $_ => 1 } SLURP_dir_all( $to_path_spec, 0);




foreach my $item (SLURP_dir_all( $from_path_spec, 0))
{
if (!must_ignore( $item))
{
my $from_spec = "$from_path_spec/$item";
my $to_spec = "$to_path_spec/$item";
if (-d $from_spec)
{



ENV_say( 1, " From  Dir $from_spec...")
if ($VERBOSE_LEVEL >= 2);
if ($to_items{$item})
{
if (-f $to_spec)
{
FILE_del_files( W => $to_spec);
my_mkdir( $to_spec);
} else
{
;	# dir exists
}
delete $to_items{$item};
} else
{
my_mkdir( $to_spec);
}
replicate_tree( $from_spec, $to_spec); # recurse
} elsif (-f _)
{



ENV_say( 1, " From File $from_spec")
if ($VERBOSE_LEVEL >= 3);
if ($to_items{$item})
{
if (-f $to_spec)
{
FILE_replicate( $from_spec, $to_spec);
} else	# item is dir
{
del_tree( W => $to_spec);
FILE_del_dirs( W => $to_spec);
copy_file( $from_spec, $to_spec);
}
delete $to_items{$item};
} else
{
copy_file( $from_spec, $to_spec);
}
} else
{
other_types( $from_spec);
}
}
}




foreach my $item (keys %to_items)
{
my $to_spec = "$to_path_spec/$item";
if (-d $to_spec)
{
del_tree( W => $to_spec);
FILE_del_dirs( W => $to_spec);
} else
{
FILE_del_files( W => $to_spec);
}
}
}







sub FILE_del_tree($$$$)
{
my ($sig_on_error,		# opt. '', 'EE', etc. Default == 'W'
$from_path_spec,
$top_exclude_re_ref,	# may be undef
$verbose_level,		# 0 = nothing, 1 = ignore, 2 = directories, 3 = files, 4 = dir + files, 5 = max
) = @_;


$sig_on_error = 'W'
if (!defined $sig_on_error);

my @top_exclude_re = ENV_deref( $top_exclude_re_ref);


init_recurse( undef, undef, undef, $verbose_level);

foreach my $item (SLURP_dir_all( $from_path_spec, 1))
{
if (!grep( $item =~ $_, @top_exclude_re))
{
my $from_spec = "$from_path_spec/$item";
$NR_TOTAL_SCANNED++;
if (-d $from_spec)
{
if (!-l $from_spec)    # do not follow symbolic links
{
del_tree( $sig_on_error => $from_spec);
}

FILE_del_dirs( $sig_on_error => $from_spec);
} else
{

FILE_del_files( $sig_on_error => $from_spec);
}
} else
{
ENV_say( 1, "Skipped $from_path_spec/$item")
if ($verbose_level >= 1);
}
}

exit_recurse();

return (wantarray) ? ($NR_DIRS_DELETED, $NR_FILES_DELETED, $NR_TOTAL_SCANNED) : [ $NR_DIRS_DELETED, $NR_FILES_DELETED, $NR_TOTAL_SCANNED ];
}





sub del_tree($$)
{
my ($sig_on_error,		#  '', 'EE', etc.
$from_path_spec
) = @_;

foreach my $item (SLURP_dir_all( $from_path_spec, 1))
{
my $from_spec = "$from_path_spec/$item";
$NR_TOTAL_SCANNED++;
if (-d $from_spec)
{
if (!-l $from_spec)    # do not follow symbolic links
{
del_tree( $sig_on_error => $from_spec);
}

FILE_del_dirs( $sig_on_error => $from_spec);
} else
{

FILE_del_files( $sig_on_error => $from_spec);
}
}
}




sub init_recurse($$$$)
{
my ($func_ref,	    # $state = $func_ref->( $level, $is_dir, $path_spec, $name);
$find_ref,	    # [ regexp, ... ] or $regexp. May be undef
$ignore_ref,	    # [ regexp, ... ] or $regexp. May be undef
$verbose_level,	    # 0 = nothing, 1 = ignore, 2 = directories, 3 = files, 4 = dir + files, 5 = max
) = @_;

$FUNC_REF = $func_ref;
@FIND_REGEXPS = ();
@FIND_REGEXPS = ENV_deref( $find_ref);

@IGNORE_REGEXPS = ();
@IGNORE_REGEXPS = ENV_deref( $ignore_ref);

$VERBOSE_LEVEL = $verbose_level;

$RECURSING = 1;
$NR_DIRS_CREATED = 0;
$NR_FILES_COPIED = 0;
$NR_DIRS_DELETED = 0;
$NR_FILES_DELETED = 0;
$NR_TOTAL_SCANNED = 0;
}




sub match_found($)
{
my ($file_path_spec) = @_;
my $found = 1;

if (@FIND_REGEXPS)
{
$found = grep( $file_path_spec =~ $_, @FIND_REGEXPS);
}

return $found;
}




sub must_ignore($)
{
my ($file_path_spec) = @_;
my $ignore = 0;

if (@IGNORE_REGEXPS)
{
my ($file) = ENV_split_spec_f( $file_path_spec);
if (grep( $file =~ $_, @IGNORE_REGEXPS))
{
ENV_say( 1, "Ignored $file_path_spec")
if ($VERBOSE_LEVEL >= 1);
$ignore = 1;
}
}

return $ignore;
}





sub other_types($)
{
my ($entry_spec) = @_;

if (-l $entry_spec)
{
ENV_sig( E => "Symbolic links not supported",
"'$entry_spec'");
} else
{
ENV_sig( E => "Unknown Fil/Dir type",
"'$entry_spec'");
}
}




sub exit_recurse()
{
$FUNC_REF = undef;
@FIND_REGEXPS = ();
@IGNORE_REGEXPS = ();
$VERBOSE_LEVEL = undef;

$RECURSING = 0;
}




sub FILE_replicate($$)
{
my ($in_file,
$out_file,
) = @_;
my $replicated = 0;    	    # 0 = not replicated (already ok), 1 = replicated




if (!ENV_file_is_same( $in_file, $out_file))
{
ENV_copy_file( $in_file, $out_file, 'F');   # $exit_on_error = 1
$replicated = 1;
}

return $replicated;
}




sub copy_file($$)
{
my ($in_file,
$out_file,
) = @_;

ENV_copy_file( $in_file, $out_file, 'F');   # $exit_on_error = 1

$NR_FILES_COPIED++
if ($RECURSING);
}





sub FILE_move($$$)
{
my ($old_spec,
$new_spec,
$verbose_level,		# 0 = nothing, 1 = ignore, 2 = directories, 3 = files, 4 = dir + files, 5 = max
) = @_;

ENV_sig( F => "MOVE: file/dir '$old_spec' does not exist")
if (!-e $old_spec);




if (!rename( $old_spec, $new_spec))
{



my $is_copied = 0;
my $is_deleted = 0;
if (-f $old_spec)
{
$is_copied = FILE_replicate( $old_spec, $new_spec);
if ($is_copied)
{
$is_deleted = FILE_del_files( W => $old_spec);
}
} else
{
$is_copied = FILE_replicate_tree( $old_spec, $new_spec, undef, $verbose_level);
if ($is_copied)
{
$is_deleted = FILE_del_tree( W => $old_spec, undef, $verbose_level);
}
}
if (!$is_copied || !$is_deleted)
{
ENV_sig( F => "Cannot move file/dir: '$old_spec'",
"                   -> '$new_spec'",
"- $!");
}
}
}




sub my_mkdir($)
{
my ($path_spec_or_ref,
) = @_;
my $count = 0;

my $path_ref = (ref $path_spec_or_ref) ? $path_spec_or_ref : [ $path_spec_or_ref ];
foreach my $path_spec (@{$path_ref})
{
if (!-d $path_spec)
{
ENV_mkdir( $path_spec, $DEFAULT_MODE);
$count++;
}
}

$NR_DIRS_CREATED += $count
if ($RECURSING);

return $count;
}





sub FILE_del_dirs($$)
{
my ($sig_on_error,		# opt. '', 'EE', etc. Default == 'W'
$path_spec_or_ref
) = @_;
my $count = 0;

$sig_on_error = 'W'
if (!defined $sig_on_error);
my @dirs = (ref $path_spec_or_ref) ? @{$path_spec_or_ref} : ($path_spec_or_ref);

foreach my $path_spec (@dirs)
{
if (rmdir $path_spec)
{
$count++;
} else
{
chmod oct(777), $path_spec;
if (rmdir $path_spec)
{
$count++;
} else
{
ENV_sig( $sig_on_error => "Unable to remove dir '$path_spec'", "- $!");
}
}
}

$NR_DIRS_DELETED += $count
if ($RECURSING);

return $count;
}




sub FILE_del_files($$)
{
my ($sig_on_error,		# opt. '', 'EE', etc. Default == 'W'
$file_or_ref
) = @_;
my $count = 0;

$sig_on_error = 'W'
if (!defined $sig_on_error);
my @files = (ref $file_or_ref) ? @{$file_or_ref} : ($file_or_ref);

$count = unlink( @files);
if ($count != @files)
{
$count = 0;
foreach my $file (@files)
{
chmod oct(777), $file;
if (unlink $file)
{
$count++;
} else
{
ENV_sig( $sig_on_error => "Unable to remove file '$file'", "- $!");
}
}
}

$NR_FILES_DELETED += $count
if ($RECURSING);

return $count;
}




sub FILE_copy_template($$;@)
{
my ($from_spec,	# template-file
$to_spec,	# out-file
@translate,	# ($token, $value) or ($token, [@insert_lines]), ...
) = @_;



my @lines = SLURP_file( $from_spec);

while (@translate)
{



my $token = shift @translate;
my $value = shift @translate;

if (!defined $value)
{



ENV_trace( "Delete lines with token %$token%");
@lines = grep( $_ !~ /%$token%/, @lines);
} elsif (ref $value)
{



my $nr_value_lines = @{$value};
my $i = 0;
do
{
if ($lines[$i] eq "%$token%")
{
splice( @lines, $i, 1, @{$value});	# insert lines
$i += $nr_value_lines;
} else
{
$i++;
}
} while ($i < @lines);
} else
{



foreach my $line (@lines)
{
$line =~ s/%$token%/$value/g;
}
}
}

SPIT_file_nl( $to_spec, \@lines);
}




sub FILE_copy_translate($$;@)
{
my ($from_spec,	# in-file
$to_spec,	# out-file
@translate,	# ($token, $value) or ($token, [@insert_lines]), ...
) = @_;

my @lines = SLURP_file( $from_spec);
my @out_lines;

push @translate, ( $from_spec, $to_spec );	    # substitute the filespec
while (@translate)
{



my $token = shift @translate;
my $value = shift @translate;


if (ref $value)
{




my $nr_value_lines = @{$value};
my $i = 0;
do
{
if ($lines[$i] eq $token)
{
splice( @lines, $i, 1, @{$value});
$i += $nr_value_lines;
} else
{
$i++;
}
} while ( $i < @lines);
} else
{



my $q_token = quotemeta $token;
foreach my $line (@lines)
{
$line =~ s/\b$q_token\b/$value/g;
}
}
}

SPIT_file_nl( $to_spec, \@lines);
}

1;

