#!/bin/bash
#=================================================
#  define.sh <rel> <command> [<command_arg> ...]
#
#   Called by a GBS shortcut, via pre_define.sh
#   Called by gbsexit
#
#   - Call $HOME/.gbs/boot.sh
#   - Call $GBS_BASE_PATH/gbscmd - if present
#   - Call $GBS_BASE_PATH/setup.bat
#   - Define the main gbs commands or Execute the command
#
#   - Args:
#     <rel>:     'cur', 'beta' or actual version
#     <command>: 'gbs', 'perl', 'source' or 'exec'
#
#   GBS Startup:    gbs $*
#   GBS Setup:	    source gbssetup.sh $*
#   GBS Uninstall:  perl gbsuninstall.pl $*
#   GBS Help:	    ** Direct, does not use define.sh
#=================================================

\echo "DEFINE_: $*"

#
#   Handle Args
#
GBS_ARG_REL=$1; shift
GBS_ARG_COMMAND=$1; shift
GBS_ARG_COMMAND_ARGS=$*
set --
[[ $GBS_ARG_COMMAND == "" ]] && GBS_ARG_COMMAND=gbs

#
#  Setup Colors	    Fg=34=Blue, Bg=97+10=White,
#  Setup Geometry   Not possible in bash
#
echo -n -e "\e[34;107m";

#
#   Set GBS_BOOT_PATH, GBS_BASE_PATH and GBS_PERL_CMD
#
\source "$HOME/.gbs/boot.sh"

#
#   Execute gbscmd.sh if exist
#
\export GBS_LOGIN_FILE="$GBS_BASE_PATH/gbscmd.sh"
if [ -e $GBS_LOGIN_FILE ]
then
    \echo DEFINE_: Executing $GBS_LOGIN_FILE...
    \source $GBS_LOGIN_FILE
fi
unset GBS_LOGIN_FILE

#
#   Execute profile
#	Defines GBS_SCRIPTS_ROOT, GBS_SCRIPTS_REL, GBS_SCRIPTS_PATH and more
#
\source "$GBS_BASE_PATH/profile.sh"

#
#   Adjust GBS_SCRIPTS_REL
#
\echo "DEFINE_: Current GBS version is '$GBS_SCRIPTS_REL'"
if [[ "$GBS_ARG_REL" == "cur" ]]
then
    GBS_WANTED_REL=$GBS_SCRIPTS_REL
elif [[ "$GBS_ARG_REL" == "beta" ]]
then
    GBS_WANTED_REL="beta"
else
    GBS_WANTED_REL=$GBS_ARG_REL
fi

if [[ $GBS_WANTED_REL != "" && -e "$GBS_SCRIPTS_ROOT/$GBS_WANTED_REL" ]]
then
    #
    #	Set GBS_SCRIPTS_REL and GBS_SCRIPTS_PATH
    #
    [[ $GBS_SCRIPTS_REL != $GBS_WANTED_REL ]] && \echo "DEFINE_: GBS version set to '$GBS_WANTED_REL'"
    \export GBS_SCRIPTS_REL=$GBS_WANTED_REL
    \export GBS_SCRIPTS_PATH="$GBS_SCRIPTS_ROOT/$GBS_SCRIPTS_REL"

    #
    #	Select the command
    #
    if [[ $GBS_ARG_COMMAND == "gbs" ]]
    then
	#
	#  Define 'gbs' commands
	#
	eval "function gbs          { \source \"$GBS_SCRIPTS_PATH/gbsinit.sh\" \$*; }"
	eval "function gbsgui       { \source \"$GBS_SCRIPTS_PATH/gbsguiinit.sh\" \$*; }"
	eval "function gbshelp      { $GBS_PERL_CMD \"$GBS_SCRIPTS_PATH/gbshelp.pl\" \$*; }"
	eval "function gbssetup     { \source \"$GBS_SCRIPTS_PATH/gbssource.sh\" gbssetup.pl \$*; }"
	eval "function gbsuninstall { $GBS_PERL_CMD \"$GBS_SCRIPTS_PATH/gbsuninstall.pl\" \$*; }"

	\echo "DEFINE_: GBS commands defined:"
	\echo "         gbs"
	\echo "         gbsgui         - Needs Tkx (experimental)"
	\echo "         gbshelp"
	\echo "         gbssetup"
	\echo "         gbsuninstall"
	\echo "-"
	\echo "DEFINE_: Type 'gbs' to startup GBS $GBS_ARG_REL[$GBS_SCRIPTS_REL]"
    else
	#
	#  Execute the specified command
	#
	\echo "DEFINE_: Executing $GBS_ARG_COMMAND $GBS_ARG_COMMAND_ARGS..."
	if [[ $GBS_ARG_COMMAND == perl ]]
	then
	    $GBS_PERL_CMD $GBS_SCRIPTS_PATH/$GBS_ARG_COMMAND_ARGS
	elif [[ $GBS_ARG_COMMAND == source ]]
	then
	    \source $GBS_SCRIPTS_PATH/$GBS_ARG_COMMAND_ARGS
	elif [[ $GBS_ARG_COMMAND == exec ]]
	then
	    $GBS_SCRIPTS_PATH/$GBS_ARG_COMMAND_ARGS
	else
	    \echo "DEFINE_: **ERROR** Invalid command '$GBS_ARG_COMMAND' (perl source exec)"
	    \echo "         define $GBS_ARG_REL $GBS_ARG_COMMAND $GBS_ARG_COMMAND_ARGS"
	fi
    fi
else
    \echo "DEFINE_: GBS Version '$GBS_ARG_REL[$GBS_SCRIPTS_REL]' does not exist - Cannot continue with GBS"
fi

#
#   Cleanup
#
unset GBS_ARG_REL
unset GBS_ARG_COMMAND
unset GBS_ARG_COMMAND_ARGS
unset GBS_WANTED_REL

#   End

#  **EOF**
