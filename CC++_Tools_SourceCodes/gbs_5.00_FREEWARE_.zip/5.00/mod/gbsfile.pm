#=================================================
#
#   gbsfile.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbsfile;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSFILE_open
GBSFILE_get_line
GBSFILE_get_dependencies
GBSFILE_sig
);
}




use glo::env;
use mod::gbsfileglo;




sub GBSFILE_open($$$$);
sub GBSFILE_get_line();
sub GBSFILE_get_dependencies();
sub GBSFILE_sig($@);




my @DEPENDENCIES;












sub GBSFILE_open($$$$)
{
my ($filespec,	    # if specific .type: not generic and existence was checked
$must_exist,
$inc_paths_ref,	    # in application
$build,	    # OPT: Invokes build-line-selection. undef == no selection
) = @_;
my $full_filespec;	    # undef if does not exist




@DEPENDENCIES = ();




my ($path, $file_name, $filetype) = ENV_split_spec_pnt( $filespec);
if ($filetype ne '')
{
$full_filespec = (-e $filespec) ? $filespec : undef;
} else
{
$full_filespec = GBSFILEGLO_select_usr_gbs( $filespec);
}





if (defined $full_filespec)
{
GBSFILEGLO_open_file( $full_filespec, $inc_paths_ref, undef, $build, 0);
} else
{
ENV_sig( F => "File '$path/$file_name.gbs' does not exist")
if ($must_exist);
}


return $full_filespec;
}




sub GBSFILE_get_line()
{
my $line;

$line = GBSFILEGLO_get_line();
if (!defined $line)
{
@DEPENDENCIES = @{GBSFILEGLO_close_file()};
}

return $line;
}




sub GBSFILE_get_dependencies()
{
return @DEPENDENCIES;
}







sub GBSFILE_sig($@)
{
my ($sig,		# <severity><action> IWEF  EC
@lines_or_refs
) = @_;

GBSFILEGLO_sig( $sig => @lines_or_refs);
}

1;


