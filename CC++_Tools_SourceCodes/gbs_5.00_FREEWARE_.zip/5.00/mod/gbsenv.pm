#=================================================
#
#   gbsenv.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbsenv;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSENV_init
GBSENV_scripts_path
GBSENV_gbs_root_path
GBSENV_setenv
GBSENV_setalias
GBSENV_setfunction
GBSENV_changed_setenv_commands
GBSENV_write_result_script
GBSENV_gbs_is_active
GBSENV_mode_is_interactive
GBSENV_mode_is_background
GBSENV_mode_is_foreground
GBSENV_doing_audit
GBSENV_doing_build
GBSENV_doing_tool
GBSENV_is_integrator
GBSENV_is_administrator
GBSENV_gui_available
GBSENV_is_predefined_env
GBSENV_get_custom_envs
GBSENV_get_envs_to_reset
GBSENV_get_plugin_envs
GBSENV_get_gbs_plugin_path
);
}




use glo::env;
use glo::spit;
use glo::shell;
use mod::gbsenvs;




sub GBSENV_init($);
sub GBSENV_scripts_path();
sub GBSENV_gbs_root_path();
sub GBSENV_setenv($$;$);
sub GBSENV_setalias($$);
sub GBSENV_setfunction($$);
sub GBSENV_changed_setenv_commands($);
sub GBSENV_write_result_script($$);
sub GBSENV_gbs_is_active();
sub GBSENV_mode_is_interactive();
sub GBSENV_mode_is_foreground();
sub GBSENV_mode_is_background();
sub GBSENV_doing_audit();
sub GBSENV_doing_build();
sub GBSENV_doing_tool();
sub GBSENV_is_integrator();
sub GBSENV_is_administrator();
sub GBSENV_gui_available();
sub GBSENV_is_predefined_env($);
sub GBSENV_get_custom_envs();
sub GBSENV_get_envs_to_reset();
sub GBSENV_get_plugin_envs($);
sub GBSENV_get_gbs_plugin_path($$);




my $IS_INTEGRATOR;	    # Do not initialize!
my $IS_ADMINISTRATOR;	    # Do not initialize!
my $GUI_AVAILABLE;	    # Do not initialize!









my %PREDEFINED_ENVS = map { $_ => 1} qw(
GBS_PLATFORM
GBS_SHELL_FILETYPE
GBS_PERL_PATH
GBS_XTITLE
GBS_BASE_PATH
GBS_BOOT_PATH
);







my @CUSTOM_ENVS = qw(
GBS_TEMPLATES_PATH
GBS_MAKE
GBS_SUBMIT
GBS_SUBWIN
GBS_BATCH
GBS_BG_NOTIFIER
);









my %EXCLUDE_ENVS = (
GBS_ABT_NAME	=> 1,
GBS_EXEC_ID		=> 1,
GBS_EXEC_LEVEL	=> 1,
GBSDEBUG_VERBOSE	=> 1,
);





my @USER_ENVS = qw(
);





my @ALIAS_REFS;

my @FUNCTION_REFS;





BEGIN
{



my $gbs_exec_id = ENV_getenv( 'GBS_EXEC_ID');
if ($gbs_exec_id eq '')
{


if (!ENV_getenv( 'GBS_PROMPT_SEPARATOR_PRINTED'))
{
ENV_print_separator_line();	    # Prompt separator line
ENV_setenv( GBS_PROMPT_SEPARATOR_PRINTED => 1);
}
}




foreach my $env (qw( GBS_SCRIPTS_ROOT GBS_SCRIPTS_REL GBS_SCRIPTS_PATH GBS_BOOT_PATH GBS_BASE_PATH))
{
ENV_sig( E => "EnvVar $env not set. Cannot continue")
if (ENV_getenv( $env) eq '');
}




ENV_set_application( 'GBS', 'Generic Build Support', '<GBS_SCRIPTS_PATH>', undef, '<GBS_BASE_PATH>', '<GBS_PERL_CMD>');








my $gbs_exec_level;
if ($gbs_exec_id eq '')
{



$gbs_exec_id = join( '_', ENV_get_hostname(), time, $$);    # Set ExecId to hostname + time + pid
$ENV{GBS_EXEC_ID} = $gbs_exec_id;			    # Will be excluded in-context
$gbs_exec_level = 0;					    # Set the ExecLevel
} else
{
$gbs_exec_level = ENV_getenv( 'GBS_EXEC_LEVEL');
$gbs_exec_level++;					    # Increase the ExecLevel
}
$ENV{GBS_EXEC_LEVEL} = $gbs_exec_level;			    # Will be excluded in-context




GBSENVS_init();





ENV_set_background_term_size()
if ($GBS::EXEC_MODE eq 'BACKGROUND');




{
my %abt_names = (

GBSAUDIT	    => 'audit',
GBSAUDITSUM	    => 'audit',
GBSBUILD	    => 'build',
GBSMAKE	    => 'build',
GBSMAKEMAKE	    => 'build',
GBSSYSAUDIT	    => 'audit',
GBSSYSAUDITBG   => 'audit',
GBSSYSBUILD	    => 'build',
GBSSYSBUILDBG   => 'build',
GBSSYSMAKE	    => 'build',
GBSSYSMAKEBG    => 'build',
GBSSYSTOOL	    => 'tool',
GBSSYSTOOLBG    => 'tool',
GBSSWB	    => 'build',
GBSSWA	    => 'audit',
GBSSWT	    => 'tool',
CPPTESTMAINT    => 'audit',
PCLINTMAINT	    => 'audit',
PRQAMAINT	    => 'audit',
);
my $program_name = ENV_get_main_name();	    # Uppercase
my $abt_name = $abt_names{$program_name};
$abt_name = ''
if (!defined $abt_name);

if ($abt_name ne $GBS::ABT_NAME)
{
if ($GBS::ABT_NAME eq '' && $abt_name ne '')
{




ENV_setenv( GBS_ABT_NAME => $abt_name);
$GBS::ABT_NAME = $abt_name;
} else
{

}
}
}




{
my $must_beep;
if ($GBS::BEEPS eq '' || $GBS::BEEPS eq 'YES' || $GBS::BEEPS eq 'ON')
{
$must_beep = 1;
} elsif ($GBS::BEEPS eq 'NO' || $GBS::BEEPS eq 'OFF')
{
$must_beep = 0;
} else
{
ENV_sig( E => "Invalid value for 'GBS_BEEPS' ($GBS::BEEPS).",
"Must be one of (YES, NO, ON, OFF)");
$must_beep = 1;
}
ENV_enable_beeps( $must_beep);
}
}






sub GBSENV_init($)
{
my ($abt_name,  # undef (=keep current, which may be ''), 'audit', 'build' or 'tool'
) = @_;

if (defined $abt_name)
{
my @allowed_values = ( qw( audit build tool) );
ENV_sig( F => "Invalid abt_name '$abt_name'. Must be one of (@allowed_values) or undef")
if (! grep( $abt_name eq $_, @allowed_values));
ENV_sig( F => "Invalid value of GBS::ABT_NAME ($GBS::ABT_NAME) - must be $abt_name")
if ($GBS::ABT_NAME ne $abt_name);
}
}






sub GBSENV_scripts_path()
{
return ENV_get_application_scripts_path();
}






sub GBSENV_gbs_root_path()
{
return $GBS::ROOT_PATH;
}





sub GBSENV_setenv($$;$)
{
my ($name,
$value_or_ref,
$must_set_global_variable,	    # Bool, optional
) = @_;
my $value;

if ($name =~ /^GBS_.+_(PATH|ROOT)$/)
{
$value = ENV_setenv_os_path( $name, $value_or_ref);
} else
{
$value = ENV_setenv( $name => $value_or_ref);
}
if ($must_set_global_variable)
{
$name =~ s/^GBS_//;
ENV_set_global_variables( $name, $value_or_ref)
}


return $value;
}




sub GBSENV_setalias($$)
{
my ($name,
$value,	    # may be undef (for deletion)
) = @_;

push @ALIAS_REFS, [ $name, $value ];
}




sub GBSENV_setfunction($$)
{
my ($name,
$values_ref,	    # may be undef (for deletion)
) = @_;

push @FUNCTION_REFS, [ $name, $values_ref ];
}





sub GBSENV_changed_setenv_commands($)
{
my ($must_log,
) = @_;
my @commands;





foreach my $ref (ENV_get_changed_envs())
{
my ($name, $value) = @{$ref};
next
if ($EXCLUDE_ENVS{$name});


push @commands, SHELL_setenv( $name, $value);
if ($must_log)
{
$value = 'undef'
if (!defined $value);
ENV_say( 0, "  $name => $value");
}
}





foreach my $ref (@ALIAS_REFS)
{
my ($name, $value) = @{$ref};

push @commands, SHELL_setalias( $name, $value);
if (defined $value)
{
ENV_say( 0, "  alias $name => $value")
if ($must_log);
} else
{
ENV_say( 0, "  alias $name => undef")
if ($must_log);
}
}





foreach my $ref (@FUNCTION_REFS)
{
my ($name, $values_ref) = @{$ref};

push @commands, SHELL_setfunction( $name, $values_ref);
if (defined $values_ref)
{


} else
{


}
}

return @commands;
}







sub GBSENV_write_result_script($$)
{
my ($lines_ref,
$must_print,	# Debugging
) = @_;

my $filespec = ENV_getenv( 'GBS_RESULT_FILE');	    # e.g.: .../GBSSWR_RESULT_RANDY9_5756.bat
if ($filespec eq '')
{
ENV_sig( F => "EnvVar 'GBS_RESULT_FILE' is not defined");
} elsif ($filespec eq 'NONE')
{

if ($must_print)
{
ENV_say( 0, map { "NONE: $_" } @{$lines_ref});
}
} else
{
if ($must_print)
{
ENV_say( 0, "Filespec=$filespec:");
ENV_say( 0, map { "- $_" } @{$lines_ref});
ENV_say( 0, '- EOF');
}
SPIT_script_file_nl( $filespec, $lines_ref);
}
}




sub GBSENV_gbs_is_active()
{
return ($GBS::EXEC_MODE eq '') ? 0 : 1;
}









sub GBSENV_mode_is_interactive()
{
return ($GBS::EXEC_MODE eq 'INTERACTIVE') ? 1 : 0;
}





sub GBSENV_mode_is_foreground()
{
return ($GBS::EXEC_MODE eq 'FOREGROUND') ? 1 : 0;
}





sub GBSENV_mode_is_background()
{
return ($GBS::EXEC_MODE eq 'BACKGROUND') ? 1 : 0;
}





sub GBSENV_doing_audit()
{
return !!($GBS::ABT_NAME eq 'audit');
}





sub GBSENV_doing_build()
{
return !!($GBS::ABT_NAME eq 'build');
}





sub GBSENV_doing_tool()
{
return !!($GBS::ABT_NAME eq 'tool');
}





sub GBSENV_is_integrator()
{
if (!defined $IS_INTEGRATOR)
{
if (@GBS::INTEGRATOR)
{
$IS_INTEGRATOR = grep( ENV_wildcard( $_, $GBS::SYSTEM_NAME), @GBS::INTEGRATOR) ? 1 : 0;
} else
{
$IS_INTEGRATOR = 0;
}
}

return $IS_INTEGRATOR;
}





sub GBSENV_is_administrator()
{
if (!defined $IS_ADMINISTRATOR)
{
if (@GBS::ADMINISTRATOR)
{
$IS_ADMINISTRATOR = grep( ENV_wildcard( $_, $GBS::SYSTEM_NAME), @GBS::ADMINISTRATOR) ? 1 : 0;
} else
{
$IS_ADMINISTRATOR = 0;
}
}

return $IS_ADMINISTRATOR;
}





sub GBSENV_gui_available()
{
if (!defined $GUI_AVAILABLE)
{
$GUI_AVAILABLE = ($GBS::GUI eq 'Tkx') ? 1 : 0;
}
return $GUI_AVAILABLE;
}




sub GBSENV_is_predefined_env($)
{
my ($env) = @_;

return (exists( $PREDEFINED_ENVS{$env}) ? 1 : 0);
}




sub GBSENV_get_custom_envs()
{
return @CUSTOM_ENVS;    # E.g: GBS_TEMPLATES_PATH, GBS_MAKE, GBS_SUBMIT, GBS_SUBWIN, GBS_NOTIFIER

}




sub GBSENV_get_envs_to_reset()
{
my @env_names;




push @env_names, grep( /^GBSEXT_/, keys( %ENV));




push @env_names, grep( ENV_getenv( $_) ne '', @CUSTOM_ENVS);     # E.g: GBS_TEMPLATES_PATH, GBS_MAKE, GBS_SUBMIT, GBS_SUBWIN, GBS_NOTIFIER





foreach my $env_name (keys %ENV)
{
if (substr( $env_name, 0, 10) eq 'GBS_FLAGS_' ||
grep $env_name eq $_, @USER_ENVS)
{
my $old_value = $ENV{$env_name};
if ($old_value ne '' && $old_value ne '""')
{
ENV_say( 1, "$env_name: '$old_value'=>''");
push @env_names, $env_name;
}
}
}


return @env_names;
}




sub GBSENV_get_plugin_envs($)
{
my ($plugin_name) = @_;
my ($plugin_rel, $plugin_path) = ();

my $plugin_env_name = uc $plugin_name;
$plugin_rel = ENV_getenv( "GBSEXT_${plugin_env_name}_REL");

if (wantarray)
{
$plugin_path = ENV_getenv_perl_path( "GBSEXT_${plugin_env_name}_PATH");
return ($plugin_rel, $plugin_path);
} else
{
return $plugin_rel;
}
}




sub GBSENV_get_gbs_plugin_path($$)
{
my ($plugin_type,	# audit, build or tool
$plugin_name,
) = @_;
my $gbs_plugin_path;

ENV_sig( F => "Invalid plugin_type ($plugin_type)")
if (!grep( $plugin_type eq $_, qw( audit build tool)));

my ($plugin_rel, $plugin_path) = GBSENV_get_plugin_envs( $plugin_name);
if ($plugin_rel eq '' || $plugin_rel eq '')
{
my $plugin_type_name = ucfirst $plugin_type;
ENV_sig( E => "Plugin GBSEXT_... EnvVar(s) not defined for $plugin_type_name plugin $plugin_name");
$plugin_path = '';
} else
{
my $gbs_plugin_root = ENV_getenv_perl_path( 'GBS_PLUGIN_ROOT');
$gbs_plugin_path = "$gbs_plugin_root/$plugin_type/$plugin_name/$plugin_rel";
ENV_mkpath( $gbs_plugin_path);
}

return $gbs_plugin_path;
}

1;


