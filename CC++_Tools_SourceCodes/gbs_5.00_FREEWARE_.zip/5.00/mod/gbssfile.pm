#=================================================
#
#   gbssfile.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbssfile;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSSFILE_parse
GBSSFILE_get_section_item_names
GBSSFILE_get_section_items
GBSSFILE_get_subsection_item_names
GBSSFILE_get_subsection_items
GBSSFILE_get_subsection_subitem_names
GBSSFILE_get_subsection_subitems
GBSSFILE_set_init_envs
);
}




use glo::env;
use glo::path;
use glo::check;
use mod::gbsfileglo;




sub GBSSFILE_parse($$$$);
sub GBSSFILE_get_section_item_names($$);
sub GBSSFILE_get_section_items($$@);
sub GBSSFILE_get_subsection_item_names($$$);
sub GBSSFILE_get_subsection_items($$$@);
sub GBSSFILE_get_subsection_subitem_names($$$$);
sub GBSSFILE_get_subsection_subitems($$$$@);
sub GBSSFILE_set_init_envs($);

sub init_struct($);
sub init_sub_section($@);
sub process_item($$$);
sub type_string($$);
sub type_integer($$);
sub type_bool($$);
sub type_arrow($$);
sub type_command($$);
sub type_format($$);
sub type_via_format($$);
sub constr_range($$);
sub constr_select($$);
sub constr_type($$);
sub store_scalar($$);
sub store_array($$);
sub store_pusharray($$);
sub store_hash($$);
sub validate_nr_args($$$);
sub get_failed($@);








my $IS_WIN32 = ENV_is_win32();

my %PLUGIN_LOCATIONS = (

audit   => 'audit',
scadef  => 'audit',
steps   => 'tool',
build   => 'build',
tool    => 'tool',
);

my %VALUE_TYPE_FUNCS = (
s	=> \&type_string,
i	=> \&type_integer,
b	=> \&type_bool,
a	=> \&type_arrow,
c	=> \&type_command,
f	=> \&type_format,
v	=> \&type_via_format,
);

my %VALUE_CONSTR_FUNCS = (
' ' => \sub {},			# do nothing
r   => \&constr_range,		# constr_data: minmax ref (integer values)
s   => \&constr_select,		# constr_data: ref to values-hash or -array (string values)
t	=> \&constr_type,		# constr_data: undef
);

my %STORE_TYPE_FUNCS = (
s	=> \&store_scalar,
a	=> \&store_array,
p	=> \&store_pusharray,
h	=> \&store_hash,
);

my %BOOL_VALUES = (
0	    => 0,
1	    => 1,
NO	    => 0,
YES	    => 1,
ON	    => 0,
OFF	    => 1,
TRUE    => 0,
FALSE   => 1,
);




my $STRUCT_REF;
my $STRUCT_FILE_NAME;	# build, audit, tool, steps, scadef
my $STRUCT_LOC;		# sysbuild, sysaudit, systool, sys, audit
my $STRUCT_NAME;	# $build, $audit, $tool, 'steps', $plugin_name
my $PLUGINS_ROOT_PATH;	# "$GBS::SCRIPTS_PATH/plugins/$plugin_location

my $CUR_SECTION;
my $CUR_SECTION_REF;
my $CUR_SUB_SECTION;
my $CUR_SUB_SECTION_REF;
my $CUR_ITEM;
my $SECTION_PREFIX;

my %STRUCT_REFS;




















sub GBSSFILE_parse($$$$)
{
my ($struct_ref,		# OUT: Ref to HASH. here the results go. May be undef
$filespec,		# without .type if .usr also allowed





$inc_path_ref,		# IN: ONLY: audit.gbs, scadef.pm, build.gbs, tool.gbs - NOT: steps.gbs
$sections_ref,		# IN: definition of syntax
) = @_;


my $full_filespec = GBSFILEGLO_select_usr_gbs( $filespec);    # .gbs or .usr

ENV_sig( F => "File '$filespec.gbs|.usr' does not exist")
if (!defined $full_filespec);

$STRUCT_REF = $struct_ref;
init_struct( $sections_ref);




$STRUCT_FILE_NAME = ENV_split_spec_n( $full_filespec);  # build, audit, tool, steps
if ($STRUCT_FILE_NAME eq 'steps')
{
$STRUCT_LOC = 'sys';
$STRUCT_NAME = 'steps';
} else
{
my @dirs = split( '/', $filespec);
$STRUCT_LOC = $dirs[-3];
$STRUCT_NAME = $dirs[-2];
}

$STRUCT_REF->{'.'}->{STRUCT_FILE_NAME} = $STRUCT_FILE_NAME;
$STRUCT_REF->{'.'}->{STRUCT_NAME} = $STRUCT_NAME;
$STRUCT_REF->{'.'}->{STRUCT_LOC} = $STRUCT_LOC;

$STRUCT_REFS{"$STRUCT_LOC/$STRUCT_NAME"} = $STRUCT_REF;




{
my $plugin_location = $PLUGIN_LOCATIONS{$STRUCT_FILE_NAME};	# $plugin_location
$PLUGINS_ROOT_PATH = (defined $plugin_location) ? "$GBS::SCRIPTS_PATH/plugins/$plugin_location" : undef;
GBSFILEGLO_open_file( $full_filespec, $inc_path_ref, $PLUGINS_ROOT_PATH, undef, 0);
}




$CUR_SECTION = '';
$CUR_SUB_SECTION = '';
$CUR_ITEM = '';
$SECTION_PREFIX = '';
my %sections_count = map { $_ => 0 } keys %{$sections_ref};

my $line = GBSFILEGLO_get_line();
while (defined $line)
{




GBSFILEGLO_sig( EE => "Section-line expected")
if ($line =~ /^\s/);
($CUR_SECTION, my $section_value) = split( ' ', $line, 2);  # split on any whitespaces
$SECTION_PREFIX = $CUR_SECTION;
$section_value = ''
if (!defined $section_value);
my $section_def_ref = $sections_ref->{$CUR_SECTION};
GBSFILEGLO_sig( EE => "Invalid section '$CUR_SECTION'")
if (!defined $section_def_ref);

$STRUCT_REF->{$CUR_SECTION} = {}
if (!defined $STRUCT_REF->{$CUR_SECTION});	# Create empty hash
$CUR_SECTION_REF = $STRUCT_REF->{$CUR_SECTION};
$CUR_SUB_SECTION = '';
$CUR_SUB_SECTION_REF = undef;
$CUR_ITEM = '';

my ($sec_type, $min_occur, $max_occur, $nr_args, $defs_ref, $section_entry_func, $section_exit_func) = @{$section_def_ref};
$sections_count{$CUR_SECTION}++;
my $is_subsection = ($sec_type eq 'S') ? 1 : 0;

if ($max_occur)
{
GBSFILEGLO_sig( EE => "Maximum of $max_occur occurences of '$CUR_SECTION' allowed ($sections_count{$CUR_SECTION})")
if ($sections_count{$CUR_SECTION} > $max_occur);
}
my @section_values;
if (defined $nr_args)
{
@section_values = split( ' ', $section_value);  # split on any whitespaces
validate_nr_args( $CUR_SECTION, scalar @section_values, $nr_args);
} else
{
$section_values[0] = $section_value;
}


if ($is_subsection)
{
my %subsections = map { $_ => 1 } keys (%{$CUR_SECTION_REF});
foreach my $subsection (@section_values)
{
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: SubSection name cannot be '.'")
if ($subsection eq '.');
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: SubSection name ($subsection) already defined")
if (exists $subsections{$subsection});
$subsections{$subsection} = 1;
}
}




@section_values = &$section_entry_func( $CUR_SECTION, [ @section_values ])
if (defined $section_entry_func);




init_sub_section( $defs_ref, @section_values)
if ($is_subsection);




{
my %items_count = map { $_ => 0 } keys %{$defs_ref};


$line = GBSFILEGLO_get_line();
my $last_order = 0;
while (defined $line && $line =~ /^\s/)
{




($CUR_ITEM, my $value) = $line =~ /^\s+(\S+)\s*=\s*(.*)$/;
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: Item Format must be '<space><keyword> = <value>'")
if (!defined $CUR_ITEM);
my $def_ref = $defs_ref->{$CUR_ITEM};
if (defined $def_ref)
{
my $order = $def_ref->[3];
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: Wrong order for '$CUR_ITEM'. Must be placed earlier")
if (defined $order && $order < $last_order);

process_item( $is_subsection, $def_ref, $value);

$last_order = $order;
$items_count{$CUR_ITEM}++;
} else
{
GBSFILEGLO_sig( E => "$SECTION_PREFIX: Unknown Item: '$CUR_ITEM'");
}
$line = GBSFILEGLO_get_line();
}




foreach my $item (keys %{$defs_ref})
{
next if (!$defs_ref->{$item}->[2]);    # $is_mandatory
GBSFILEGLO_sig( E => "$SECTION_PREFIX: Item '$item' (mandatory) is missing")
if ($items_count{$item} == 0);
}
}




&$section_exit_func( $CUR_SECTION, [ @section_values ])
if (defined $section_exit_func);
}




foreach my $section (keys %{$sections_ref})
{
my $min_occur = $sections_ref->{$section}->[1];
if ($min_occur)
{
GBSFILEGLO_sig( W => "At least $min_occur occurences of '$section' needed")
if ($sections_count{$section} < $min_occur);
}
}




my ($plugin_name, $used_file_paths_ref, $dependencies_ref) = GBSFILEGLO_close_file();
$STRUCT_REF->{'.'}->{PLUGIN_NAME} = $plugin_name;
$STRUCT_REF->{'.'}->{SEARCH_PATH} = $used_file_paths_ref;
$STRUCT_REF->{'.'}->{DEPENDENCIES} = $dependencies_ref;





}




sub init_struct($)
{
my ($sections_ref,
) = @_;

%{$STRUCT_REF} = ();

while (my ($section, $section_ref) = each( %{$sections_ref}))
{
my ($sec_type, undef, undef, undef, $defs_ref, ) = @{$section_ref};
ENV_sig( F => "Undefined defs_ref in Section $section")
if (!defined $defs_ref);
$STRUCT_REF->{$section} = {};

if ($sec_type ne 'S')
{
while (my ($item, $item_ref) = each( %{$defs_ref}))
{
$STRUCT_REF->{$section}->{$item} = ENV_clone( $item_ref->[1])	# default
}
} else
{
$STRUCT_REF->{$section}->{'.'}->{'ORDER'} = [];
}
}

}




sub init_sub_section($@)
{
my ($defs_ref,
@section_values,
)= @_;

$CUR_SUB_SECTION = shift @section_values;
$SECTION_PREFIX = "$CUR_SECTION ($CUR_SUB_SECTION)";


$CUR_SECTION_REF->{$CUR_SUB_SECTION} = {}
if (!defined $CUR_SECTION_REF->{$CUR_SUB_SECTION});
$CUR_SUB_SECTION_REF = $CUR_SECTION_REF->{$CUR_SUB_SECTION};

foreach my $item (keys %{$defs_ref})
{
my $default = $defs_ref->{$item}->[1];	# $default
$STRUCT_REF->{$CUR_SECTION}->{$CUR_SUB_SECTION}->{$item} = ENV_clone( $default);
}
$STRUCT_REF->{$CUR_SECTION}->{$CUR_SUB_SECTION}->{'.'}->{DEPENDENCIES} = [];

$STRUCT_REF->{$CUR_SECTION}->{'.'}->{ORDER} = []
if (!defined $STRUCT_REF->{$CUR_SECTION}->{'.'}->{ORDER});
push @{$STRUCT_REF->{$CUR_SECTION}->{'.'}->{ORDER}}, $CUR_SUB_SECTION;

foreach my $subsection (@section_values)
{
$CUR_SECTION_REF->{$subsection} = $CUR_SUB_SECTION_REF;
push @{$STRUCT_REF->{$CUR_SECTION}->{'.'}->{ORDER}}, $subsection;
}

}




sub process_item($$$)
{
my ($is_subsection,
$def_ref,
$value,
) = @_;

my ($item_type, undef, undef, undef, $nr_args, $item_function, $constr_arg) = @{$def_ref};
my ($store_type, $value_type, $value_constr) = split( //, $item_type);
my @values;




{
my $value_type_func = $VALUE_TYPE_FUNCS{$value_type};   # type_string, type_integer, type_command, etc
ENV_sig( F => "Value_type '$value_type' not implemented")
if (!defined $value_type_func);
@values = $value_type_func->( $value, $nr_args);
}




if ($value_constr)
{
my $value_constr_func = $VALUE_CONSTR_FUNCS{$value_constr}; # const_range, const_select, etc
ENV_sig( F => "Value_constr '$value_constr' not implemented")
if (!defined $value_constr_func);
$value_constr_func->( [ @values ], $constr_arg);
}




if (defined $item_function)
{
@values = $item_function->( $CUR_SECTION, $CUR_SUB_SECTION, $CUR_ITEM, [ @values ], $constr_arg);
}




{
my $store_type_func = $STORE_TYPE_FUNCS{$store_type};   # scalar, array, push, hash
ENV_sig( F => "Store_type '$store_type' not implemented")
if (!defined $store_type_func);
my $item_ref = ($is_subsection) ? $CUR_SUB_SECTION_REF : $CUR_SECTION_REF;
$store_type_func->( $item_ref, \@values);
}
}




sub type_string($$)
{
my ($value_string,
$nr_args,
) = @_;
my @values;

if (defined $nr_args)
{
@values = ENV_split_quoted_space( $value_string);
validate_nr_args( $CUR_ITEM, scalar @values, $nr_args);
} else
{
$values[0] = $value_string;
}

return @values;
}




sub type_integer($$)
{
my ($value_string,
$nr_args,
) = @_;
my @values;

@values = type_string( $value_string, $nr_args);	# convert to array and check nr args
foreach my $value (@values)
{
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: Value '$value' must be an integer")
if ($value !~ /^[-+]?\d+$/);
$value *= 1;
}

return @values;
}




sub type_bool($$)
{
my ($value_string,
$nr_args,
) = @_;
my @values;

@values = type_string( $value_string, $nr_args);	# convert to array and check nr args
foreach my $value (@values)
{
my $new_value = $BOOL_VALUES{$value};
if (defined $new_value)
{
$value = $new_value;
} else
{
my @valid_bool_values = sort keys %BOOL_VALUES;
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: Value '$value' must be one of the Bool values '@valid_bool_values'");
}
}

return @values;
}




sub type_arrow($$)
{
my ($value_string,
$nr_args,
) = @_;
my @value_refs; # ([ $sub_key, @sub_values ], ...)


my ($sub_keys, $sub_value) = $value_string =~ /^(.*?)\s*=>\s*(.*)$/;
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: Syntax is ' $CUR_ITEM = <name>... => <value_string>'")
if (!defined $sub_keys);

my @sub_values = type_string( $sub_value, $nr_args);    # convert to array and check nr args

foreach my $sub_key (split( ' ', $sub_keys))	    # split on any whitespaces
{
push @value_refs, [ $sub_key, @sub_values ];
}

return @value_refs;
}








sub type_command($$)
{
my ($command_sequence,  # file may be prefixed with '@', '>' or '.'
$nr_args,
) = @_;


my ($command_type, $command_items_ref, $ok_values, $exec_condition, $pos_arg_tokens);


my ($spec_command_or_file,	# file may be prefixed with '@', '>' or '.'
$ok_values_org,
$exec_condition_org
) = reverse split( /\s*;\s*/, $command_sequence, 3);








my @command = ENV_split_quoted_space( $spec_command_or_file);

{
my $exec = $command[0];
my $fc = substr( $exec, 0, 1);
if ($fc eq '@' || $fc eq '>' || $fc eq '.')
{






my $script_file_spec;
$command_type = 'S';  # script command
$exec = substr( $exec, 1);
$exec .= $GBS::SHELL_FILETYPE
if ($exec !~ /\.sh$|\.bat$|\.cmd$|\.pl$/);

if ($fc eq '@')
{
my @used_file_paths = GBSFILEGLO_get_paths();
$script_file_spec = PATH_search_file( $exec, \@used_file_paths);
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: Command-file '$exec' not found in",
"(@used_file_paths)",
$spec_command_or_file)
if ($script_file_spec eq '');
} elsif ( $fc eq '>')
{
$script_file_spec = "$PLUGINS_ROOT_PATH/$exec";
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: Command-file '$script_file_spec' does not exist",
"Specified: '$exec'",
$spec_command_or_file)
if (!-e $script_file_spec);
} else	# ($fc eq '.')
{
$script_file_spec = "$GBS::SCRIPTS_PATH/$exec";
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: Command-file '$script_file_spec' does not exist",
"Specified: '$exec'",
$spec_command_or_file)
if (!-e $script_file_spec);
}
$command[0] = $script_file_spec;

push @{$CUR_SUB_SECTION_REF->{'.'}->{DEPENDENCIES}}, $script_file_spec;
} elsif ($exec =~ /^ECHO\s+(.*)$/)
{



$command_type = 'B';	# direct builtin command
my $value = (defined $1) ? $1 : '';
@command = (ECHO => $value);

} elsif ($exec =~ /^SET\s+(.*)$/)
{



$command_type = 'B';	# direct builtin command
my ($name, $value) = $1 =~ /^([A-Z_]+)\s*=\s*(.*)$/;
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: Invalid SET command. 'SET <name> = <value>",
$spec_command_or_file)
if (!defined $value);
@command = (SET => $name, $value);
} else
{



$command_type = 'D';	# direct command
}

validate_nr_args( $CUR_ITEM, scalar @command, $nr_args);

$pos_arg_tokens = '0';
if ($command_type ne 'B') 	# direct builtin command (e.g.: echo)
{
if ($IS_WIN32)
{
my $nr_pos_arg_tokens = () = $spec_command_or_file =~ /%(\*|\d)/g;	    # %* or %1 - %9
if ($nr_pos_arg_tokens > 0)
{
$pos_arg_tokens = $pos_arg_tokens = "$nr_pos_arg_tokens%";		    # %
} else
{
$nr_pos_arg_tokens = () = $spec_command_or_file =~ /\$(\*|\d)/g;	    # $* or $1 - $9
$pos_arg_tokens = "$nr_pos_arg_tokens\$"				    # \$
if ($nr_pos_arg_tokens > 0);
}
} else  # Linux
{
my $nr_pos_arg_tokens = () = $spec_command_or_file =~ /\$(\*|\d)/g;	    # $* or $1 - $9
$pos_arg_tokens = "$nr_pos_arg_tokens\$"				    # \$
if ($nr_pos_arg_tokens > 0);
}
}
}




{
if (defined $ok_values_org && $ok_values_org ne '')
{
my @values = split( /\s*,\s*/, $ok_values_org);
my @new_values;
foreach my $value (@values)
{
my ($min_value, undef, $max_value) = $value =~ /^(\d+)(\s*-\s*(\d+))?$/;
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: Invalid ok-value syntax ($value)")
if (!defined $min_value);
$max_value = $min_value
if (!defined $max_value);
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: min_value ($min_value) > ($max_value)")
if ($min_value > $max_value);
push @new_values, $min_value..$max_value;
}
$ok_values = "@new_values";
} else
{
$ok_values = '0';
}
}




{
if (defined $exec_condition_org)
{
if ($exec_condition_org =~ /^(!)?\s*exists\s+(.*)$/i)
{


my $not = $1;
my $filespec = $2;
{
my $full_filespec = ENV_dequote( ENV_perl_paths( ENV_expand_envs( $filespec)));
my $error_text = CHECK_filespec( undef, $full_filespec, 0);	    # Do not check exists
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: $full_filespec", $error_text)
if (defined $error_text);
}
my $cond = (defined $not) ? 0 : 1;
$exec_condition = "F$cond$filespec";
} elsif ($exec_condition_org =~ /^([A-Z_]+)\s+(=|!=|==)\s+(.*)$/)
{


my $var_name = $1;
my $cond = substr( $2, 0, 1);
my $value = $3;
$cond = ($cond eq '=') ? 1 : 0;
$exec_condition = "V$cond$var_name=$value";
} else
{
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: Invadid precondition syntax ($exec_condition_org).",
"Must be: [!] exists <filespec>",
"Or:      <VARIABLE_NAME_UPPERCASE> [=|==|!=] <value>");
}
} else
{
$exec_condition = '-';
}
}

$command_items_ref = [ @command ];

return [ $command_type, $command_items_ref, $ok_values, $exec_condition, $pos_arg_tokens ];
}




sub type_format($$)
{
my ($value_string,
$nr_args,
) = @_;

my ($env_type,		    # FILE or LIST (default)
$format);

if ($value_string =~ /^\w+/)
{
if ($value_string =~ /^(\w+)\s+(.+)/)
{
$env_type = $1;
$format = $2;
if ($env_type eq 'VARIABLE')
{
$env_type = 'LIST';
GBSFILEGLO_sig( I => "'VARIABLE' replaced by 'LIST'");
} else
{
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: Type '$env_type' must be 'LIST' or 'FILE'")
if ($env_type ne 'LIST' && $env_type ne 'FILE');
}
} else
{
GBSFILEGLO_sig( EE => "Syntax = [ type ] printf_format");
}
} else
{
$env_type = 'LIST';
$format = $value_string;
}
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: Format must contain '%s'")
if ($format !~ /%s/);


return ($env_type, $format );
}




sub type_via_format($$)
{
my ($value_string,
$nr_args,
) = @_;





my ($format,	    # %s, -via %s, @%s, ...
$type);		    # empty or .type

if ($value_string =~ /^(.*%s)(.*)$/)
{
$format = $1;
$type = $2;
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: If 'type' is specified ($type) if must contain a ',' (DOT)")
if ($type ne '' && $type !~ /\./);
} else
{
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: Via Format must contain '%s'")
}


return ( $format, $type );
}




sub constr_range($$)
{
my ($values_ref,
$constr_data_ref,	# [ value, [ min, max ], ... ]
) = @_;

foreach my $value (@{$values_ref})
{
my $error_text = CHECK_int_range( undef, $value, $constr_data_ref);
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: $error_text")
if (defined $error_text);
}
}




sub constr_select($$)
{
my ($values_ref,
$constr_data_ref,	# possible_values_ref (hash or array
) = @_;

if (ref $constr_data_ref eq 'HASH')
{
foreach my $value (@{$values_ref})
{
if (!exists $constr_data_ref->{$value})
{
my @possible_values = keys %$constr_data_ref;
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: Value '$value' must be one of (@possible_values)");
}
}
} else
{
foreach my $value (@{$values_ref})
{
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: Value '$value' must be one of (@{$constr_data_ref})")
if (!grep( $_ eq $value, @{$constr_data_ref}));
}
}
}




sub constr_type($$)
{
my ($values_ref,
$constr_data,	# undef
) = @_;

foreach my $value (@{$values_ref})
{
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: Type ($value) must contain '.'")
if ($value !~ /\./);
}
}




sub store_scalar($$)
{
my ($item_ref,
$values_ref,
) = @_;


$item_ref->{$CUR_ITEM} = $values_ref->[0];
}




sub store_array($$)
{
my ($item_ref,
$values_ref,
) = @_;


$item_ref->{$CUR_ITEM} = [ @{$values_ref} ];	# must clone
}




sub store_pusharray($$)
{
my ($item_ref,
$values_ref,
) = @_;


push @{$item_ref->{$CUR_ITEM}},  @{$values_ref};
}




sub store_hash($$)
{
my ($item_ref,
$values_ref,
) = @_;



foreach my $ref (@{$values_ref})
{
my ($sub_key, @sub_values) = @{$ref};
GBSFILEGLO_sig( EE => "Duplicate key: $sub_key")
if (exists $item_ref->{$CUR_ITEM}->{$sub_key} &&
@{$item_ref->{$CUR_ITEM}->{$sub_key}} > 0);
$item_ref->{$CUR_ITEM}->{$sub_key} = [ @sub_values];
}

}




sub validate_nr_args($$$)
{
my ($itemword,
$nr_elements,
$nr_args_or_ref,
) = @_;

if (defined $nr_args_or_ref)
{
my $error_text = CHECK_int_range( "Nr of $itemword items", $nr_elements, [ $nr_args_or_ref ]);
GBSFILEGLO_sig( EE => "$SECTION_PREFIX: $error_text")
if (defined $error_text);
}
}




sub GBSSFILE_get_section_item_names($$)
{
my ($struct_ref,	# or $struct_id ("$STRUCT_LOC/$STRUCT_NAME")
$section,
) = @_;
my @values = ();

$struct_ref = $STRUCT_REFS{$struct_ref}
if (!ref $struct_ref);

return (wantarray) ? sort keys %{$struct_ref->{$section}} : undef;
}




sub GBSSFILE_get_section_items($$@)
{
my ($struct_ref,	# or $struct_id ("$STRUCT_LOC/$STRUCT_NAME")
$section,
@items,
) = @_;
my @values = ();

$struct_ref = $STRUCT_REFS{$struct_ref}
if (!ref $struct_ref);


foreach my $item (@items)
{
my $value = $struct_ref->{$section}->{$item};
get_failed( $struct_ref, $section, $item)
if (!defined $value && !exists $struct_ref->{$section}->{$item});
push @values, $value;
}
if (@items == 1)
{
return (wantarray) ? @{$values[0]} : $values[0];
} else
{
return @values;
}
}




sub GBSSFILE_get_subsection_item_names($$$)
{
my ($struct_ref,	# or $struct_id ("$STRUCT_LOC/$STRUCT_NAME")
$section,
$subsection,
) = @_;
my @values = ();

$struct_ref = $STRUCT_REFS{$struct_ref}
if (!ref $struct_ref);

return (wantarray) ? sort keys %{$struct_ref->{$section}->{$subsection}} : undef;
}




sub GBSSFILE_get_subsection_items($$$@)
{
my ($struct_ref,	# or $struct_id ("$STRUCT_LOC/$STRUCT_NAME")
$section,
$subsection,
@items,
) = @_;
my @values = ();

$struct_ref = $STRUCT_REFS{$struct_ref}
if (!ref $struct_ref);


foreach my $item (@items)
{
my $value = $struct_ref->{$section}->{$subsection}->{$item};
get_failed( $struct_ref, $section, $subsection, $item)
if (!defined $value && !exists $struct_ref->{$section}->{$subsection}->{$item});
push @values, $value;
}
if (@items == 1)
{
return (wantarray) ? @{$values[0]} : $values[0];
} else
{
return @values;
}
}




sub GBSSFILE_get_subsection_subitem_names($$$$)
{
my ($struct_ref,	# or $struct_id ("$STRUCT_LOC/$STRUCT_NAME")
$section,
$subsection,
$sub_item,
) = @_;
my @values = ();

$struct_ref = $STRUCT_REFS{$struct_ref}
if (!ref $struct_ref);

return (wantarray) ? sort keys %{$struct_ref->{$section}->{$subsection}->{$sub_item}} : undef;
}




sub GBSSFILE_get_subsection_subitems($$$$@)
{
my ($struct_ref,	# or $struct_id ("$STRUCT_LOC/$STRUCT_NAME")
$section,
$subsection,
$item,
@subitems,
) = @_;
my @values = ();

$struct_ref = $STRUCT_REFS{$struct_ref}
if (!ref $struct_ref);


foreach my $subitem (@subitems)
{
my $value = $struct_ref->{$section}->{$subsection}->{$item}->{$subitem};
get_failed( $struct_ref, $section, $subsection, $item, $subitem)
if (!defined $value && !exists $struct_ref->{$section}->{$subsection}->{$item}->{$subitem});
push @values, $value;
}
if (@subitems == 1)
{
return (wantarray) ? @{$values[0]} : $values[0];
} else
{
return @values;
}
}




sub get_failed($@)
{
my ($struct_ref,	# or $struct_id ("$STRUCT_LOC/$STRUCT_NAME")
@keys,
) = @_;

$struct_ref = $STRUCT_REFS{$struct_ref}
if (!ref $struct_ref);



my $struct_file_uc = uc $struct_ref->{'.'}->{STRUCT_FILE_NAME};
my $struct_name = $struct_ref->{'.'}->{STRUCT_NAME};
foreach my $key (@keys)
{
$key = "->{$key}";
}

ENV_sig( F => "No such ${struct_file_uc}{$struct_name}" . join( '', @keys));
}





sub GBSSFILE_set_init_envs($)
{
my ($struct_ref,	# or $struct_id ("$STRUCT_LOC/$STRUCT_NAME")
) = @_;

$struct_ref = $STRUCT_REFS{$struct_ref}
if (!ref $struct_ref);



{



my @keys = ($IS_WIN32) ? qw( SET_W SET) : qw( SET_X SET);
foreach my $key (@keys)
{
my $set_refs_ref = $struct_ref->{INIT}->{$key};
if (defined $set_refs_ref)
{
foreach my $ref (@{$set_refs_ref})
{
my ($name, $value) = @{$ref};

$value = ENV_expand_envs( $value);
ENV_sig( EE => "No match for EnvVar in $key $name = $value")
if ($value =~ /%|\$/);
$value = ENV_os_paths( ENV_perl_paths_noquotes( $value));
ENV_setenv( $name => $value );

}
}
}
}

{



my $setpath_refs_ref = $struct_ref->{INIT}->{SETPATH};
if (defined $setpath_refs_ref)
{
foreach my $ref (@{$setpath_refs_ref})
{
my ($name, @values) = @{$ref};

foreach my $value (@values)
{

if ($value eq $name || $value eq "%$name%" || $value eq "\$$name")
{

$value = ENV_os_paths( ENV_getenv( $name));
} else
{
$value = ENV_expand_envs( $value);
ENV_sig( EE => "No match for EnvVar '$value'", "in SETPATH $name = @values")
if ($value =~ /%|\$/);
$value = ENV_perl_paths_noquotes( $value);
$value = ENV_os_paths( $value);
}

}
my $new_value = ENV_join_path( \@values);	# ';' or ':'
ENV_setenv( $name => $new_value );

}
}
}




{
my $bin_dir = $struct_ref->{INIT}->{BIN_DIR};
my $plugin_name_uc = uc $struct_ref->{'.'}->{PLUGIN_NAME};
my $plugin_path = ENV_getenv_perl_path( "GBSEXT_${plugin_name_uc}_PATH");
my $plugin_bin_path = ($bin_dir eq '') ? $plugin_path : "$plugin_path/$bin_dir";
ENV_setenv_os_path( "GBSEXT_${plugin_name_uc}_BIN_PATH" => $plugin_bin_path);

}
}

1;


