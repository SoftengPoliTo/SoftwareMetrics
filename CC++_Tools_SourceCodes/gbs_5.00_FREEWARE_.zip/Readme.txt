-------------------------------------------------------------------------
GBS
Generic Build Support                         www.GenericBuildSupport.com
Developed by Randy Marques of Randy Marques Consultancy
Randy@RandyMarques.com                               www.RandyMarques.com
-------------------------------------------------------------------------

Several versions of GBS can be installed in a GBS_SCRIPTS_ROOT directory.
The latest build is always installed under the plain <version> directory.
e.g.: 2.02
This is called the Current Build. It will be overwritten with every
install.
Specific Builds are installed under <version>_<build> directory.
e.g.:
                        +- 2.01
                        +- 2.01_2006-11-23
      any_root -+- GBS -+- 2.02
                        +- 2.02_2007-08-05
                        +- 2.02_2007-09-15
<--GBS_SCRIPTS_ROOT-->     <---GBS_SCRIPTS_REL--->
<-----------------GBS_SCRIPTS_PATH--------------->

This script only installs GBS (possibly on a central location).
To be able to use GBS, each user must 'setup' GBS. You will be prompted
after the install. That tells GBS which version to use and fixes your
environment so that you can run GBS (shortcuts, etc.).

Prerequisites:
1. You must have Perl installed and in the PATH or referred to by
   GBS_PERL_PATH.  
2. Decide where GBS will be installed (GBS_SCRIPTS_ROOT).

Instructions for Install:
1. Unzip the file to a new temporary directory (NOT where you want to
   install GBS).
2. cd to this directory.
3. On Windows:
       Run Install.bat
   On Unix/Linux:
       Set the properties of Install.sh to executable
           (chmod u+x Install.sh)
       Run ./Install.sh
4. Answer the questions.
   For most questions you can assume the default. (between [])
   You will need a 'SITE-ID'. This identifies your physical location
   uniquely in case you work multisite. For single use, the default
   (HOME) will do fine.
5. When done, make sure the new temporary directory is deleted.

Instructions for Setup:
If not executed during Install:
1. cd to <GBS_SCRIPTS_ROOT>/<wanted_version>.
2. Run _gbssetup.bat (Windows) or _gbssetup.sh (Unix/Linux) and answer
   questions.
   This needs to be done only once per GBS user.
   Once GBS is installed you can use the command gbssetup to change your
   setup.

Notes:
1. Subsequent installs can be run with -q flag (quiet). This will run the
   script without human intervention assuming all defaults to be correct.
2. To proceed with GBS it is strongly recommended to read at least the
   Quickstart which can be found on the GBSHelp pages on the website.
   (Also available after Install and Setup)

WinZip Wizard:
On Windows you can use the WinZip Wizard:
 1. DoubleClick on the zip-file.
 2. Make sure you run in Wizard mode and Click 'Next'.
 3. Choose 'Unzip or Install' and Click 'Next'.
 4. Make sure you will not unzip to the directory where you want to
    install GBS.
 5. Enable 'Display file icons after unzipping'.
 6. You can use 'View Zip Documentation' to read this text.
 7. Click 'Unzip Now'.
 8. After the file is unzipped a 'Windows Explorer' window will appear.
 9. Double-click on 'Install.bat' and answer the questions. GBS is
    installed.
10. Close the WinZip wizard by clicking on 'Finish'.

*EOF*

