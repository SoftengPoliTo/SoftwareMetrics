#=================================================
#
#  gbsguiexec.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package gui::gbsguiexec;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSGUIEXEC_init
GBSGUIEXEC_direct
GBSGUIEXEC_prompt
);
}




use Tkx;

use glo::env;
use glo::types;
use glo::genopt_parse;
use glo::tkxform;
use mod::gbscmd;
use mod::run;
use gui::gbsguirf;




sub GBSGUIEXEC_init($);
sub GBSGUIEXEC_direct($$$);
sub GBSGUIEXEC_prompt($$$);

sub do_execute($);
sub execute_command($$$);
sub general_execute($$);
sub get_options($);
sub parse_args($$);








my %COMMAND_DEF_REFS = (


gbsaudit	=> [ 1, 0, 0, \&GBSGUIRF_exec ],
gbsbg	=> [ 1, 1, 0, \&GBSGUIRF_exec_xterm ],
gbsbldcheck	=> [ 1, 0, 0, \&GBSGUIRF_exec ],
gbsedit	=> [ 1, 0, 0, \&GBSGUIRF_exec ],
gbsexport	=> [ 1, 0, 0, \&GBSGUIRF_exec ],
gbsbuild	=> [ 1, 0, 0, \&GBSGUIRF_exec ],
gbshelp	=> [ 1, 0, 1, \&GBSGUIRF_exec_detached ],
gbsmaint	=> [ 1, 1, 0, \&GBSGUIRF_exec_xterm ],
gbsmake	=> [ 1, 0, 0, \&GBSGUIRF_exec ],
gbsmakemake	=> [ 1, 0, 0, \&GBSGUIRF_exec ],
gbssetup	=> [ 1, 1, 0, \&GBSGUIRF_exec_xterm ],
gbsscm	=> [ 1, 1, 0, \&GBSGUIRF_exec_xterm ],
gbsscm_	=> [ 1, 1, 0, \&GBSGUIRF_exec ],
gbsshow	=> [ 1, 0, 0, \&GBSGUIRF_exec ],
gbssilo	=> [ 1, 0, 0, \&GBSGUIRF_exec ],
gbsstats	=> [ 1, 0, 0, \&GBSGUIRF_exec ],
gbsswa	=> [ 1, 0, 0, \&GBSGUIRF_exec_xterm ],
gbsswb	=> [ 1, 0, 0, \&GBSGUIRF_exec_xterm ],
gbsswc	=> [ 1, 0, 0, \&GBSGUIRF_exec_xterm ],
gbsswr	=> [ 1, 0, 0, \&GBSGUIRF_exec_xterm ],
gbsswr_	=> [ 1, 0, 0, \&GBSGUIRF_exec ],
gbssws	=> [ 1, 0, 0, \&GBSGUIRF_exec_xterm ],
gbsswt	=> [ 1, 0, 0, \&GBSGUIRF_exec_xterm ],
gbssysall	=> [ 1, 0, 0, \&GBSGUIRF_exec ],
gbssysaudit => [ 1, 0, 0, \&GBSGUIRF_exec ],
gbssysbuild => [ 1, 0, 0, \&GBSGUIRF_exec ],
gbssysmake  => [ 1, 0, 0, \&GBSGUIRF_exec ],
gbssystool  => [ 1, 0, 0, \&GBSGUIRF_exec ],
gbswhich	=> [ 1, 0, 0, \&GBSGUIRF_exec ],
gbsxref	=> [ 1, 0, 1, \&GBSGUIRF_exec_detached ],
bgpids	=> [ 2, 0, 0, \&GBSGUIRF_exec ],
detab	=> [ 2, 0, 0, \&GBSGUIRF_exec ],
filerep	=> [ 2, 0, 0, \&GBSGUIRF_exec ],
fixeol	=> [ 2, 0, 0, \&GBSGUIRF_exec ],
pgrep	=> [ 2, 0, 0, \&GBSGUIRF_exec ],
proto	=> [ 2, 0, 0, \&GBSGUIRF_exec ],
wordrep	=> [ 2, 0, 0, \&GBSGUIRF_exec ],
execute	=> [ 0, 1, 0, \&general_execute ],
navigate	=> [ 0, 1, 0, \&general_execute ],
terminal	=> [ 0, 1, 0, \&general_execute ],
GBS		=> [ 0, 1, 0, \&general_execute ],

);




my $RF;		    # Right Frame

my %COMMAND_REFS;



my %OPTIONS_REFS;





sub GBSGUIEXEC_init($)
{
($RF,
) = @_;
}




sub GBSGUIEXEC_direct($$$)
{
my ($menu_entry_name,
$command_name,
$arg_or_ref,
) = @_;



my $args_ref = (defined $arg_or_ref) ? (ref $arg_or_ref) ? $arg_or_ref : [ $arg_or_ref ] : [];
execute_command( $menu_entry_name, $command_name, $args_ref);
}




sub GBSGUIEXEC_prompt($$$)
{
my ($menu_entry_name,
$command_expression,	# command, command fixed_args, command %arg_nr
$arg_or_ref,		# may be undef
) = @_;



my ($command_name, @fixed_args) = split( ' ', $command_expression);

my $mnem_refs_ref;
my $mnem_hash_ref;
my $flag_prefix;
my $help_text_ref;
my $extra_text_ref;

if (!exists $COMMAND_REFS{$menu_entry_name})
{
my @mnem_refs;
$mnem_refs_ref = \@mnem_refs;
my %mnem_hash;

$mnem_hash_ref = \%mnem_hash;




my $options_command_name = $command_name;
$options_command_name =~ s/_$//;    # Remove possible trailing '_'
get_options( $options_command_name)
if (!exists $OPTIONS_REFS{$options_command_name});
($flag_prefix, my ($mnems_order_ref, $items_by_mnem_ref), $help_text_ref, $extra_text_ref) = @{$OPTIONS_REFS{$options_command_name}};



foreach my $mnem (@{$mnems_order_ref})
{
my ($mnem, $opt_name, $type_spec, $default, $item_help_or_ref) = @{$items_by_mnem_ref->{$mnem}};
$mnem = (substr( $mnem, 0, 1) eq '<') ? $mnem : "$flag_prefix$mnem";
my $arg_value;
my $mnem_ref = [ \$arg_value, $mnem, $opt_name, $type_spec, $default, $item_help_or_ref ];
push @mnem_refs, $mnem_ref;
$mnem_hash{$mnem} = $mnem_ref;
}
$COMMAND_REFS{$menu_entry_name} = [ $command_name, $mnem_refs_ref, $mnem_hash_ref, $flag_prefix, $help_text_ref, $extra_text_ref];
} else
{
($command_name, $mnem_refs_ref, $mnem_hash_ref, $flag_prefix, $help_text_ref, $extra_text_ref) = @{$COMMAND_REFS{$menu_entry_name}};
}




if (defined $arg_or_ref)
{
my @args = @{$arg_or_ref};
unshift @args, @fixed_args;	# put fixed_args in front



my %array_items;

foreach my $ref (parse_args( $flag_prefix, \@args))
{
my ($mnem, $new_arg_value, $arg_type) = @{$ref};




my $this_mnem = $mnem;
my $mnem_ref = $mnem_hash_ref->{$this_mnem};
if (substr( $mnem, 0, 1) eq '<' && ! defined $mnem_ref)
{
$this_mnem = '<*>';
$mnem_ref = $mnem_hash_ref->{$this_mnem};
}
ENV_sig( F => "Unknown mnem '$mnem' ($this_mnem)")
if (!defined $mnem_ref);
my ($mnem_value_ref, undef, $opt_name, $type_spec) = @{$mnem_ref};

my $occur = substr( $type_spec, 1, 1);
if ($occur eq 's')
{
$$mnem_value_ref = $new_arg_value;
} else
{
if (exists $array_items{$this_mnem})
{
$$mnem_value_ref = "$$mnem_value_ref $new_arg_value";
} else
{
$$mnem_value_ref = $new_arg_value;
$array_items{$this_mnem} = 1;
}
}
}
}
TKXFORM_dialogue( $TKX::MW, $menu_entry_name, $mnem_refs_ref, \&do_execute, undef, $help_text_ref, $extra_text_ref);	# modal

return; # Needed to prevent "Use of uninitialized value in subroutine entry at C:/MyPrograms/Perl64/v5.16/lib/Tkx.pm line 347."
}




sub do_execute($)
{
my ($menu_entry_name,
) = @_;

my @args;
foreach my $ref (TKXFORM_get_changed_values( $menu_entry_name))
{
my ($arg_value, $mnem, $opt_name, $type_spec, $default) = @{$ref};

my ($type, $occur) = TYPES_split( $type_spec);

if (substr( $mnem, 0, 1) eq '<')
{



if ($occur eq 's')
{
push @args, ENV_encode( $arg_value);
} else
{
push @args, split( ' ', $arg_value);
}
} else
{



if ($type eq 'b')
{
my $plus_minus = ($arg_value eq '1') ? '' : '-';
push @args, "$mnem$plus_minus";
} else	# 'i', 's' and 't'
{
push @args, "$mnem=$arg_value"
if ($arg_value ne '');
}
}
}


my ($command_name) = @{$COMMAND_REFS{$menu_entry_name}};
execute_command( $menu_entry_name, $command_name, \@args);
}




sub execute_command($$$)
{
my ($menu_entry_name,
$command_expression,		# command, command fixed_args, command %arg_nr
$args_ref,
) = @_;


my ($command_name, @fixed_args) = split( ' ', $command_expression);
if (exists $COMMAND_DEF_REFS{$command_name})
{
my ($command_type, $is_interactive, $is_detached, $exec_func) = @{$COMMAND_DEF_REFS{$command_name}};

my @args = @{$args_ref};
unshift @args, @fixed_args;

$command_name =~ s/_$//;    # Remove possible trailing '_'
if ($command_type > 0)
{



my $full_command = ENV_prepare_command( GBSCMD_get_gbs_command( $command_name, \@args));

$exec_func->( "$command_name @args", $full_command);
} else
{



$exec_func->( "$command_name @args", $command_name, \@args);
}
} else
{
ENV_sig( E => "Menu-Entry-Name: $menu_entry_name: Command '$command_name' not supported");
}
}




sub general_execute($$)
{
my ($command,
$command_name,		    # execute navigate terminal GBS
$args_ref,		    # rel file_spec (followed by args)
) = @_;



$command =~ s/%20/ /g;
if ($command_name eq 'execute')
{
my $command_line = "@{$args_ref}";
$command_line =~ s/%20/ /g;
GBSGUIRF_exec( $command, $command_line);
} elsif ($command_name eq 'GBS')
{
my $start_path = ENV_parent_path( $GBS::ROOT_PATH);
RUN_gbs( $start_path);
} else  # navigate or terminal
{
my $dirspec = $args_ref->[0];
$dirspec =~ s/%20/ /g;
$dirspec = ENV_split_spec_p( $dirspec)
if (-f $dirspec);
$dirspec = '.'
if ($dirspec eq '');
if ($command_name eq 'navigate')
{
RUN_navigator( $dirspec);
} elsif ($command_name eq 'terminal')
{
RUN_terminal( $dirspec, '');
} else
{
ENV_sig( F => "command_name '$command_name' must be one of (execute navigate terminal)");
}
}
}




sub get_options($)
{
my ($command_name,
) = @_;

my $command_type = $COMMAND_DEF_REFS{$command_name}->[0];
if ($command_type > 0)
{



my $command_path = $GBS::SCRIPTS_PATH;
$command_path .= '/StandAlone'
if ($command_type eq 2);
my $filespec = "$command_path/$command_name.pl";

my ($flag_prefix,	# default = '--'
$prog_names_ref,    # this is the name of the program, with aliasses
$items_refs_ref,    # [ [ $mnem, $opt_name, $type_spec, $default, $item_help_or_ref ], ... ]
$help_text_ref,	# this is the general help-text. NOT optional
$extra_text_ref,    # this is the (optional) aditional help-text
$conf_item_refs_ref,
$env_items_ref
) = GENOPT_PARSE_file( $filespec, 1);	# 0 = general environment

my @mnems_order;
my %items_by_mnems;


foreach my $item_ref (@{$items_refs_ref})
{
my $mnem = $item_ref->[0];
$items_by_mnems{$mnem} = $item_ref;
push @mnems_order, $mnem;
}

$OPTIONS_REFS{$command_name} = [ $flag_prefix, \@mnems_order, \%items_by_mnems, $help_text_ref, $extra_text_ref ];
} else
{



my @mnems_order = ( '<*>' );
my %items_by_mnems = (
'<*>' => [ '<*>', 'args', 'sso', '', 'Arguments' ],
);
my $help_text_ref = [ 'No help available'];
$OPTIONS_REFS{$command_name} = [ '-', \@mnems_order, \%items_by_mnems, $help_text_ref, undef ];
}

}




sub parse_args($$)
{
my ($flag_prefix,
$arg_or_ref,
) = @_;
my @arg_refs;


my $args_ref = (ref $arg_or_ref) ? $arg_or_ref : [ $arg_or_ref ];
my $pos_count = 0;
foreach my $arg (@{$args_ref})
{
my $mnem;
my $arg_value;
my $arg_type;
if (substr( $arg, 0, 2) eq $flag_prefix)
{
if ($arg =~ /^($flag_prefix\w+)=(.*)$/)
{
$mnem = $1;
$arg_value = $2;
$arg_type = 's';
} elsif ($arg =~ /^($flag_prefix\w+)(-|\+|$)$/)
{
$mnem = $1;
$arg_value = ($2 eq '') ? '1' : $2;
$arg_type = 'b';
} else
{
ENV_sig( F => "Invalid arg '$arg' (@{$args_ref})");
}
} else
{
$arg = ''
if ($arg eq '""');
$pos_count++;
$mnem = "<$pos_count>";
$arg_value = $arg;
$arg_type = 's';
}
push @arg_refs, [ $mnem, $arg_value, $arg_type ];
}


return @arg_refs;
}

1;
