#=================================================
#
#  gbsguiswr.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package gui::gbsguiswr;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSGUISWR_popup
);
}




use Tkx;

use glo::env;
use glo::list;
use glo::spit;
use glo::shell;
use glo::tkx;
use glo::tkxglo;
use glo::tkxtoplevel;
use glo::tkxselect;
use glo::tkxmessage;
use mod::gbsdb;
use mod::roots;
use mod::rootsglo;
use mod::gbscmd;
use gui::gbsguirf;




sub GBSGUISWR_popup($$);

sub execute_switch_root($);












my $TEST_MODE;	    # --t




sub GBSGUISWR_popup($$)
{
(my $menu_name,
$TEST_MODE,
) = @_;



if (ROOTS_get_nr() > 0)
{



my $this_tl;
my ($x, $y) = TKX_winfo_pointerxy( $TKX::MW);
$this_tl = TKXTOPLEVEL_new( $TKX::MW,
"GBSGUI: $menu_name",		# Title
[ undef, undef, $x + 10, $y ],	# geometry
1,					# transient
sub { $this_tl->g_destroy(); },
);




my @root_path_refs;
foreach my $ref (ROOTSGLO_get_root_path_refs( 1))
{
my @menu_line_items = @{$ref};


push @root_path_refs, [ @menu_line_items ];
}

my $default_root_path = $GBS::ROOT_PATH;
$default_root_path = GBSDB_last_root_get()
if ($default_root_path eq '');
my $default_index = LIST_firstidx_ref_str( $default_root_path, \@root_path_refs, 1);

my $help_line = ROOTSGLO_get_helpline();
my @formats = ( qw( L L L L ) );
my @heads = ( qw( Type Location Version Name) );
TKXSELECT_list( $this_tl, 'Select Location', $help_line,
\@formats, \@heads, \@root_path_refs, $default_index, 1,    # 1 == single row select mode
\&execute_switch_root);
TKXTOPLEVEL_show( $this_tl);
} else
{
TKXMESSAGE_ok( $menu_name, 'warning', 'No Roots in Roots-List');
}
}




sub execute_switch_root($)
{
my ($selection_ref,
) = @_;

my ($type, $root_path, $version, $name) = @{$selection_ref};



my ($width, $height, $x, $y) = TKX_geometry( $TKX::MW);
($width, $height, $x, $y) = TKXGLO_geo_adjust_window( [ $width, $height, $x + 15, $y + 15 ]);

my $tmp_filespec = ENV_get_tmp_spec( 'gbsguiswr') . ENV_shell_filetype();
my @lines;

push @lines, GBSCMD_get_full_gbs_command( 'gbsswr', $root_path);
{
my @args;


push @args, '--geo=' . join( ',', ($width, $height, $x, $y));
my $gbsgui_command = GBSCMD_get_full_gbs_command( gbsgui => [ @args ]);

push @lines, SHELL_conditional_eq( GBS_RC => 0, "$gbsgui_command");
}
if (!$TEST_MODE)
{
push @lines, SHELL_conditional_ne( GBS_RC => 0, SHELL_echo_failed());
}

push @lines, SHELL_conditional_eq( GBS_RC => 0, SHELL_delete_and_exit( $tmp_filespec, undef, undef));

push @lines, 'exit';
SPIT_script_file_nl( $tmp_filespec, \@lines);

$tmp_filespec = ENV_enquote( $tmp_filespec);
if ($TEST_MODE)
{
GBSGUIRF_exec_xterm( "gbsswr $root_path", $tmp_filespec);

} else
{

GBSGUIRF_exec_xterm( "gbsswr $root_path", $tmp_filespec);
}
}

1;
