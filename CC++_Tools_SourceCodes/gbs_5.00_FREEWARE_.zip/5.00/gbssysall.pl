#=================================================
#
#   gbssysall.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSSYSALL @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::genopt;
use mod::gbsenv;
use mod::gbsoptenv;
use mod::validate;
use mod::gbscmd;














$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ '<*>',    'steps',	  'sao',      "", "Steps and/or Aliases. <empty> == all select steps, 'ALL' == force all steps, '?' == show steps" ],
[ 'i' ,	    'ignore_errors', 'bso',    0, "Continue generation after error(s)" ],
[ 'vs',	    'view_sum',	  'bso',       1, "View summary at completion" ],
[ 'audits', 'audits',	  "saos.,$GBS::AUDITS", '*', "(wild-)Audits to run. '' or '*' == All, '.' == Current" ],
[ 'builds', 'builds',	  "saos.,$GBS::BUILDS", '*', "(wild-)Builds to Build. '' or '*' == All, '.' == Current" ],
[ 'tools',  'tools',	  "saos.,$GBS::TOOLS",  '*', "(wild-)Tools to Execute. '' or '*' == All, '.' == Current, '-' == None" ],
[ 'files',  'files',	  'sao', '*:*.*', "Files to audit" ],
[ 'make',   'make',	  'bso',       0, "Run gbssysmake instead of gbssysbuild" ],
[ 'fg',	    'foreground', 'bso',       0, "Runs in the foreground if set" ],
[ 'at',	    'delay',	  'tso',   'now', "Starting time (10:20), delta (+10:10) or now" ],
[ 'sm',	    'mail',	  'bso',       0, "Send mail on completion" ],
[ 'n',	    'notify',	  'bso',       1, "Notify user on completion (bg/nowait only)" ],
[ 'wait',   'wait',	  'bso',       0, "Wait for completion of bg jobs" ],
[ 'jobs',   'jobs',  'isor1..9',       2, 'Max nr parallel jobs within a submitted job' ],
[ 'c',	    'comment',	  'sso',      "", 'Comments - will be shown in Summary - Specify %20 for space' ],
);
my @genconflicts = (
[ [ fg   => 1 ], '=' => 'at', '=' => 'sm', '=' => 'n' ],
[ [ wait => 1 ], '=' => 'n' ],
);
my @genenvs = qw( LOG_PATH FLAGS_* APP_* );
GENOPT_set_optdefs( 'gbssysall', \@genopts,
'Execute gbssysbuild/gbssysmake, gbssysaudit and gbssystool commands',
'Commands are only executed if applicable');
GENOPT_set_conflicts( \@genconflicts);
GENOPT_set_envdefs( \&GBSOPTENV_set, \&GBSOPTENV_print, \@genenvs);
GENOPT_parse();
}





my @TOOLS = GENOPT_get( 'tools');

my $MAKE = GENOPT_get( 'make');












VALIDATE_root();

my @COMMAND_REFS = (

[ Builds  => gbssysbuild => undef,	    [ qw( make audits tools view_sum ) ] ],
[ Audits  => gbssysaudit => undef,	    [ qw( make tools ) ] ],
[ Tools   => gbssystool  => \@TOOLS,    [ qw( make audits builds tools files ) ] ],
);
if ($MAKE)
{
$COMMAND_REFS[0]->[1] = 'gbssysmake';
}

foreach my $ref (@COMMAND_REFS)
{
my ($name, $command, $atts_ref, $excludes_ref) = @{$ref};
my $envvar_name = uc "GBS_$name";

if (ENV_getenv( $envvar_name))
{
if (!defined $atts_ref || "@{$atts_ref}" ne '-')
{
ENV_say( 1, "$command...");
my @args = GENOPT_get_changed( $excludes_ref);

my $rc = ENV_system( GBSCMD_get_gbs_command( $command, \@args), undef);
$RC = $rc
if ($rc > $RC);
}
} else
{
ENV_say( 1, "No $name defined");
}
}




ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
}


