#=================================================
#
#   proto.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;









sub do_C_file($$);
sub do_C_sub($);
sub do_perl_file($$);
sub dbg_print_lines($$);
sub handle_arguments();
sub usage();
sub env_say($@);




my $RC = 0;
my $MAIN_NAME_UC;
my $PREFIX;
my $PREFIX_;
my $IS_WIN32;
my $XTERM_WIDTH;
my $XTERM_HEIGHT;

BEGIN
{
$| = 1;							# $OUTPUT_AUTOFLUSH
($MAIN_NAME_UC) = map { uc $_ } "/$0" =~ m!.*[/\\](.+)\.!;	# Extract filename and make it uppercase
$PREFIX = $MAIN_NAME_UC;
$PREFIX_ = ' ' x (length( $PREFIX) + 1);
$IS_WIN32 = ($^O eq 'MSWin32');
$XTERM_WIDTH = 100;
$XTERM_HEIGHT = 50;
if (-t STDOUT)
{
if ($IS_WIN32)
{
require Win32::Console;
import  Win32::Console;
($XTERM_WIDTH, $XTERM_HEIGHT) = Win32::Console->new()->Size();
} else
{
($XTERM_HEIGHT, $XTERM_WIDTH) = split( / /, qx(stty size));
}
}




CORE::say( '=' x ($XTERM_WIDTH - 5) . '');
}




my %PERL_BUILTIN = (
BEGIN   => 1,
CHECK   => 1,
INIT    => 1,
END     => 1,
);









=optdoc
use glo::genopt;












{
my @genopts = (
[ '<*>', 'files',  'sso', "*.c,*.cpp,*.oc,*.pl,*.pm", "Files to be parsed" ],
);
GENOPT_set_flag_prefix( '-');
GENOPT_set_optdefs( 'proto', \@genopts,
'Generate function-prototypes for C, C++ and Perl',
undef);
GENOPT_parse();
}
=cut

my @files;
if (@ARGV == 1 && $ARGV[0] =~ /^--?(h|help)$/)
{
usage();
exit 0;
}
handle_arguments();

if (scalar @files > 0)
{
env_say( 1, "Files: @files");

foreach my $file (@files)
{
(my $filetype) = $file =~ /(\.[^\.]*$)/;
my $file_name = substr( $file, 0, -length $filetype);

if ($filetype eq '.c' || $filetype eq '.cpp' || $filetype eq '.oc')
{
do_C_file( $file_name, $filetype);
} elsif ($filetype eq '.pl' || $filetype eq '.pm')
{
do_perl_file( $file_name, $filetype);
} else
{
env_say( 2, "Filetype '$filetype' not supported");
}
}

} else
{
env_say( 1, "Nothing to prototype\a");
$RC = 1;
}
exit $RC;




END
{
env_say( 1, ($?) ? "Failed ($?)" : "Done");
}




sub do_C_file($$)
{
my ($file_name,
$filetype,
) = @_;

my $file = "$file_name$filetype";

env_say( 1, "Processing $file...");

my $lines;
local $/ = undef;		    # $INPUT_RECORD_SEPARATOR
open( my $in_fh, '<', $file) || die "$PREFIX: Unable to open src '$file', $!\n ";
$lines = <$in_fh>;
close $in_fh;
$/ = '\n';			    # $INPUT_RECORD_SEPARATOR






{
no warnings;
$lines =~ s!/\*[^*]*\*+([^/*][^*]*\*+)*/|//[^\n]*|("(\\.|[^"\\])*"|'(\\.|[^'\\])*'|.[^/"'\\]*)!$2!gs;
}






$lines =~ s/^[ \t\r]*#[^\n]*\n/#\n/gm;






my @subs = $lines =~ /
[^;\}] 		# end of previous statement
\s*			# optional whitespace
(			# capture begin
[:\s\w\*\[\]]+ 	# return-types and function-name
\(			# (
[\s\w\(\)\*\,\[\]]*	# optional arguments
\)			# )
)			# capture end
\s*			# optional whitespace
\{			# {
/gxs;

my $output_file = "$file.proto";

if (scalar @subs > 0)
{
my $global_count = 0;
my $static_count = 0;


open( my $out_fh, '>', $output_file) || die "Unable to create $output_file\n $!\n ";

CORE::say( $out_fh "/*=====================================================================**");
CORE::say( $out_fh "**\tG L O B A L    F U N C T I O N - P R O T O T Y P E S ");
CORE::say( $out_fh "**=====================================================================*/");
my @statics;
foreach my $sub (@subs)
{
if ($sub =~ /^static\s/)
{
push @statics, $sub;
} elsif ($sub =~ /^(if|while|switch|for)/)
{
env_say( 2, "SKIP: $sub");
} else
{
map { CORE::say( $out_fh $_) } do_C_sub($sub);
$global_count++;
}
}

CORE::say( $out_fh "");
CORE::say( $out_fh "/*=====================================================================**");
CORE::say( $out_fh "**\tL O C A L    F U N C T I O N - P R O T O T Y P E S ");
CORE::say( $out_fh "**=====================================================================*/");
foreach my $sub (@statics)
{

map { CORE::say( $out_fh $_) } do_C_sub($sub);
$static_count++;
}

close $out_fh;
env_say( 1, "Created $output_file (global=$global_count,static=$static_count)");
} else
{
env_say( 1, "No functions found: file not created");
if (-f $output_file)
{
unlink $output_file;
env_say( 2, "Existing file deleted");
}
}

}




sub do_C_sub($)
{
my ($line) = @_;
my @lines;




@lines = split /[ \t]*\n/, $line;





@lines = grep $_ ne '', @lines;





$lines[-1] = "$lines[-1];";




if (scalar @lines > 1)
{
push @lines, '';
}

return @lines;
}




sub do_perl_file($$)
{
my ($file_name,
$filetype,
) = @_;

my $file = "$file_name$filetype";

env_say( 1, "Processing $file...");

my $lines;
$/ = undef;			# $INPUT_RECORD_SEPARATOR
open( my $in_fh, '<', $file) || die "$PREFIX: Unable to open src '$file', $!\n ";
$lines = <$in_fh>;
close $in_fh;
$/ = '\n';			# $INPUT_RECORD_SEPARATOR







$lines =~ s/#[^\n]*//gs;






my @subs = $lines =~ /\s+ sub \s+ ( \w+ ( \s* \( [^\)]* \) | ) ) \s* \{/gxs;


my @exports;
my ($exports) = $lines =~ /\@EXPORT\s*=\s*qw\s*\(([^\)]*)\)\s*;/;
@exports = split ' ', $exports if (defined $exports);


my $output_file = "$file.proto";
if (scalar @subs > 0)
{
my $count = 0;

my @subs_e;
my @subs_l;
while (@subs)
{
my $sub = shift @subs;
my $args = shift @subs;
my $sub_name = ($args) ? substr( $sub, 0, - (length $args)) : $sub;

if (!$PERL_BUILTIN{$sub_name})
{
if (grep $sub_name eq $_, @exports)
{
push @subs_e, $sub;
} else
{
push @subs_l, $sub;
}
}
}


open( my $out_fh, '>', $output_file) || die "Unable to create $output_file\n $!\n ";

CORE::say( $out_fh "#======================================================");
CORE::say( $out_fh "#   Prototypes");
CORE::say( $out_fh "#======================================================");
if (@subs_e)
{
foreach my $sub (@subs_e)
{

CORE::say( $out_fh "sub $sub;");
$count++;
}

CORE::say( $out_fh "") if (@subs_l);
}
foreach my $sub (@subs_l)
{

CORE::say( $out_fh "sub $sub;");
$count++;
}
close $out_fh;
env_say( 1, "Created $output_file ($count)");
} else
{
env_say( 1, "No functions found: file not created");
if (-f $output_file)
{
unlink $output_file;
CORE::say( "	  Existing file deleted");
}
}
}




sub dbg_print_lines($$)
{
my ($file_ref,
$count,
) = @_;

my @lines = split( '\n', $$file_ref, $count);
pop @lines;
env_say( 0, @lines);
}




sub handle_arguments()
{
foreach my $arg_list (@ARGV)
{
if (substr( $arg_list, 0, 1) eq '-')
{
usage();
exit 9;
} else
{
foreach my $arg (split( /,/, $arg_list))
{
push @files, ($arg =~ /[*?]/) ? glob( $arg) : $arg;	    # glob if ($arg contains wildcard)
}
}
}
}




sub usage()
{
env_say( 1, "Usage: proto [ *.c | *.cpp | *.oc | *.pl | *.pm ]...");
}




sub env_say($@)
{
my ($indent,    # 0 = no prefix, 1 = $prefix, 2 = $prefix_ - Negative = prefix_level - 1
@lines_and_or_refs
) = @_;

my @lines = map { (ref $_) ? @{$_} : $_ } @lines_and_or_refs;
if ($indent == 0)
{
map { CORE::say( $_) } @lines;
} else
{
if (abs( $indent) == 1)
{
my $first_line = shift @lines;
CORE::say( "$PREFIX: $first_line");
}
map { CORE::say( "$PREFIX_ $_") } @lines;
}
}


