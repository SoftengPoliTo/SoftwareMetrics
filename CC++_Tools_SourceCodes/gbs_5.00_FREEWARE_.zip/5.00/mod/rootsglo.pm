#=================================================
#
#   rootsglo.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::rootsglo;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
ROOTSGLO_print_root_cols
ROOTSGLO_get_helpline
ROOTSGLO_get_root_path_menu_refs
ROOTSGLO_get_root_path_refs
);
}




use glo::env;
use glo::format;
use mod::gbscheck;
use mod::system;
use mod::roots;




sub ROOTSGLO_print_root_cols();
sub ROOTSGLO_get_helpline();
sub ROOTSGLO_get_root_path_menu_refs();
sub ROOTSGLO_get_root_path_refs($);








my $HELP_LINE = "'='=Added, *=Other_Platform, +=Multiple_Platforms, x=Not_exist, ?=Invalid-Not GBS";








sub ROOTSGLO_print_root_cols()
{
ENV_say( 2, $HELP_LINE);
ENV_say( 0, FORMAT_table( undef, 2, ' ', undef, ROOTSGLO_get_root_path_refs( 1)));
}




sub ROOTSGLO_get_helpline()
{
return $HELP_LINE;
}




sub ROOTSGLO_get_root_path_menu_refs()
{
my ($want_refs,
) = @_;
my @menu_refs;


my @root_path_refs = ROOTSGLO_get_root_path_refs( 1);



my @menu_texts = FORMAT_table( undef, 0, ' ', undef, @root_path_refs);
foreach my $ref (ROOTSGLO_get_root_path_refs( 1))
{
my ($fc, $root_path, $root_version, $system_name) = @{$ref};
my $menu_text = shift @menu_texts;
$root_version = substr( $root_version, 1, -1 )	    # remove [ and ]
if ($root_version ne '');
push @menu_refs, [ $menu_text, $root_path, $fc, $system_name, $root_version ];
}


return @menu_refs;
}




sub ROOTSGLO_get_root_path_refs($)
{
my ($printable,
) = @_;
my @root_path_refs;






foreach my $root_path (ROOTS_get_all())	# Perl path nospace
{

my $menu_text = '';
my $fc = 'x';		    # Missing
my $system_name = '';
my $root_version = '';
if (-e $root_path)
{
$fc = '?';			# Not GBS Root (invalid)
if (GBSCHECK_system( $root_path))
{
$fc = '=';		# Valid GBS Root
my ($for_current_platform, $for_other_platform) = GBSCHECK_system_platform( $root_path);
if ($for_current_platform)
{
$fc = ($for_other_platform) ? '+' : '=';	# + = Both platfoms
} else
{
$fc = ($for_other_platform) ? '*' : '?';	# * = Only Other platform
}
}
if ($fc ne '?')
{
($system_name, $root_version) = SYSTEM_get_system_info( $root_path);
if (!defined $system_name)
{
$system_name = '';
$fc = '?';
}
if (!defined $root_version)
{
$root_version = '';
$fc = '?';
}
}
$root_version = "[$root_version]"
if ($printable);
}
push @root_path_refs, [ $fc, $root_path, $root_version, $system_name ];
}


return @root_path_refs;
}

1;
