#=================================================
#
#   swb.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::swb;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SWB_validate_dirs
SWB_set
);
}




use glo::env;
use mod::gbsenvs;
use mod::gbsenv;
use mod::gbsglo;
use mod::gbsrc;
use mod::plugin;
use mod::build;




sub SWB_validate_dirs($$$$);
sub SWB_set($$);








sub SWB_validate_dirs($$$$)
{
my ($root_path,
$subsys,
$component,
$build,
) = @_;
my $new_build = $build;	    # '' if not valid


if ($subsys ne '')
{



my $gen_path = "$root_path/dev/$subsys/build";
if (-d "$gen_path/$build")
{



if ($component ne '' && GBSGLO_subsystem_is_full_gbs( $subsys, $root_path))
{
my $bld_path = "$root_path/dev/$subsys/comp/$component/bld";
if (!-d "$bld_path/$build")
{
ENV_sig( W => "Component '$component' does not generate for Build '$build'");
$new_build = '';
}
}
} else
{
ENV_sig( W => "SubSystem '$subsys' does not generate for Build '$build'");
$new_build = '';
}
}

return $new_build;
}




sub SWB_set($$)
{
my ($build,	# build or ''
$must_write,	# bool
) = @_;
my $old_build = $GBS::BUILD;







if ($build eq '')
{
GBSENVS_set_build( 1);
} else
{
GBSENVS_set_build( 1, '',
[ BUILD	    => $build,
BUILD_PLUGIN => PLUGIN_get_abt_plugin_name( $build),
]);
}

BUILD_set_bld_envs( $build);




if ($must_write && GBSENV_mode_is_interactive())
{
GBSRC_write_root( build => $build);
GBSRC_write_subsys( $GBS::SUBSYS, build => $build)
if ($GBS::SUBSYS ne '');
}

return $old_build;
}

1;


