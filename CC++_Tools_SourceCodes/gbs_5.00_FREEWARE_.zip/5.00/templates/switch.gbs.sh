#=================================================
#   File:        %FILE%
#   Path:        %PATH%
#   System Name: %SYSTEM_NAME%
#=================================================
SWITCH_RC=0
if [[ $1 = "entry" ]]
then
    #
    #	set items
    #

    if [[ $GBS_SITE = "%SITE%" ]]
    then
	#
	#   %SITE%
	#

	#
	#   Version Control
	#
	#export GBSEXT_CC_PATH=PATH
	#export GBSEXT_CCM_PATH=PATH
	#export GBSEXT_GIT_PATH=PATH
	#export GBSEXT_SVN_PATH=PATH

	#
	#   Builds
	#
	#export GBSEXT_LGNU_CPP_ROOT=/usr/lib/gcc/x86_64-linux-gnu
	#export GBSEXT_LGNU_GCC_ROOT=/usr/lib/gcc/x86_64-linux-gnu

	#
	#   Audits
	#
	#export GBSEXT_QAC_ROOT=/apl/cadappl_linux_ia32/qac
	#export GBSEXT_QACPP_ROOT=/apl/cadappl_linux_ia32/qac++

	#
	#   Tools
	#

	#
	#   GBS Settings
	#

	true

    elif [[ $GBS_SITE = "OTHER" ]]
    then
	#
	#   OTHER
	#

	true
    else
	echo "SWITCH.GBS: *****"
	echo "SWITCH.GBS: ** Unknown Site $GBS_SITE"
	echo "SWITCH.GBS: ** Must be one of '%SITE% OTHER'"
	echo "SWITCH.GBS: *****"
	SWITCH_RC=1
    fi
    #
    #	Builds
    #
    if [[ $SWITCH_RC = 0 ]]
    then
	#
	#   Builds
	#
	#export GBSEXT_LGNU_CPP_REL=7.3.0
	#export GBSEXT_LGNU_CPP_PATH=$GBSEXT_LGNU_CPP_ROOT/$GBSEXT_LGNU_CPP_REL

	#export GBSEXT_LGNU_GCC_REL=7.3.0
	#export GBSEXT_LGNU_GCC_PATH=$GBSEXT_LGNU_GCC_ROOT/$GBSEXT_LGNU_GCC_REL

	#
	#   Audits
	#
	#set GBSEXT_QAC_REL=8.1-R
	#set GBSEXT_QAC_PATH=$GBSEXT_QAC_ROOT-$GBSEXT_QAC_REL

	#set GBSEXT_QACPP_REL=3.0-R
	#set GBSEXT_QACPP_PATH=$GBSEXT_QACPP_ROOT-$GBSEXT_QACPP_REL

	#
	#   Tools
	#

	true
    fi
elif [[ $1 = "exit" ]]
then
    #
    #	unset items
    #

    true
else
    echo "SWITCH.GBS: *****"
    echo "SWITCH.GBS: ** switch.gbs.sh: Usage = . switch.gbs.sh [ entry | exit ]"
    echo "SWITCH.GBS: *****"
    SWITCH_RC=1
fi

[[ $SWITCH_RC = 1 ]] && export GBS_RC=1
unset SWITCH_RC

##EOF##
