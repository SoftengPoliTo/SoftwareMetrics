#=================================================
#
#   switch.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::switch;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SWITCH_entry
SWITCH_exit
);
}




use glo::env;
use glo::shell;
use glo::slurp;
use mod::gbsenv;




sub SWITCH_entry();
sub SWITCH_exit();

sub find_switch_files($);
sub run_and_get_context($$);
sub parse_envvars($);
sub parse_win32($);
sub parse_linux($);
sub delta_values($$$);




my $IS_WIN32 = ENV_is_win32();
my $IS_LINUX = ENV_is_linux();




sub SWITCH_entry()
{
my $rc;





my @filespecs = find_switch_files( 'EE');

$rc = run_and_get_context( entry => \@filespecs);




my @path_env_names = grep( /^GBSEXT_.*_(PATH|ROOT)$/, keys %ENV);
foreach my $env_name (@path_env_names)
{
my $perl_path = ENV_getenv_perl_path( $env_name);
if ($perl_path ne '' && $perl_path ne 'PATH'&& !-d $perl_path)
{
my $os_path = ENV_getenv( $env_name);
ENV_sig( W => "Path '$env_name' => '$os_path'",
"- Does not exist (defined in switch.gbs or switch.usr)");
}
}

return $rc;
}




sub SWITCH_exit()
{
my $rc;




my @filespecs = reverse find_switch_files( 'W');

$rc = run_and_get_context( exit => \@filespecs);

return $rc;
}




sub find_switch_files($)
{
my ($sig_or_error,
) = @_;
my @files;

foreach my $switch_file ('switch.gbs', 'switch.usr')
{
my $switch_spec = ENV_command_filespec( "$GBS::ROOT_PATH/$switch_file");
if (-f $switch_spec)
{
push @files, $switch_spec;
}
}

ENV_sig( $sig_or_error => "No switch.gbs(.bat/.sh) file found in '$GBS::ROOT_PATH'")
if (@files == 0);

return @files;
}




sub run_and_get_context($$)
{
my ($entry_or_exit,	    # 'entry' or 'exit'
$filespecs_ref,
) = @_;
my $rc;

my @lines;
my $env_names_filespec = ENV_get_tmp_spec( 'GBS_ENV_NAMES');






push @lines, SHELL_redirect_stdout( SHELL_printenv(), $env_names_filespec, 0);	    # EnvVars
push @lines, SHELL_redirect_stdout( SHELL_echo( 0, '***'), $env_names_filespec, 1);
push @lines, SHELL_redirect_stdout( SHELL_printalias(), $env_names_filespec, 1);	    # Function/Macros
push @lines, SHELL_redirect_stdout( SHELL_printfunction(), $env_names_filespec, 1)	    # Aliases
if ($IS_LINUX);
push @lines, SHELL_redirect_stdout( SHELL_echo( 0, '***'), $env_names_filespec, 1);




foreach my $switch_spec (@{$filespecs_ref})
{
if ($switch_spec =~ /switch\.usr\./)
{
my $short_switch_spec = substr( $switch_spec, length( $GBS::ROOT_PATH) + 1);
push @lines, SHELL_echo( 0, "*** Executing System $GBS::SYSTEM_NAME $short_switch_spec $entry_or_exit ***");
}
push @lines, SHELL_source( $switch_spec, $entry_or_exit);
}




push @lines, SHELL_redirect_stdout( SHELL_printenv(), $env_names_filespec, 1);		# EnvVars
push @lines, SHELL_redirect_stdout( SHELL_echo( 0, '***'), $env_names_filespec, 1);
push @lines, SHELL_redirect_stdout( SHELL_printalias(), $env_names_filespec, 1);		# Function/Macros
push @lines, SHELL_redirect_stdout( SHELL_printfunction(), $env_names_filespec, 1)		# Aliases
if ($IS_LINUX);





my $command = SHELL_and( \@lines);
if ($IS_WIN32)
{
$rc = ENV_system( $command, undef);
} else
{
$command = ENV_enquote( $command);
$command = "bash -c $command";
($rc, my $stdout) = ENV_backtick( $command, undef, 1);	# Use backtick to prevent startup of new shell in Linux
print( $stdout);
}
if ($rc == 0)
{



my @part_lines_refs = ( [], [], [], []);	# pre_envvars, pre-aliases, post-envvars, post-aliases
my $i = 0;  # prealiases
foreach my $line (SLURP_file( $env_names_filespec))
{

if ($line eq '***')
{
$i++;
} else
{
push @{$part_lines_refs[$i]}, $line;
}
}
ENV_sig( E => "GBS_ENV_NAMES file ($env_names_filespec) contains errors (i=$i)")
if ($i != 3);
unlink $env_names_filespec;









{
my @pre_envvar_refs  = parse_envvars( $part_lines_refs[0]);
my @post_envvar_refs = parse_envvars( $part_lines_refs[2]);


my @delta_env_refs = delta_values( envvar => \@pre_envvar_refs, \@post_envvar_refs);





map { ENV_setenv( $_->[0], $_->[1]->[0]); } @delta_env_refs;	# $name, $values_ref

if ($entry_or_exit eq 'entry')
{

my @new_names = grep( $_ !~ /^GBSEXT_/, map { $_->[0] } @delta_env_refs);

ENV_setenv( GBS_SWITCH_ENVVARS => \@new_names);
} else
{

my @new_names = ENV_getenv( 'GBS_SWITCH_ENVVARS');

map { ENV_setenv( $_, undef) } @new_names;
ENV_setenv( GBS_SWITCH_ENVVARS => undef);
}
}




{
my @pre_alias_refs  = ($IS_WIN32) ? parse_win32( $part_lines_refs[1]) : parse_linux( $part_lines_refs[1]);
my @post_alias_refs = ($IS_WIN32) ? parse_win32( $part_lines_refs[3]) : parse_linux( $part_lines_refs[3]);


my @delta_refs = delta_values( alias => \@pre_alias_refs, \@post_alias_refs);





my @delta_alias_refs;
my @delta_function_refs;	    # Linux only
foreach my $ref (@delta_refs)
{
if ($ref->[0] =~ /(.*)\s*\(/)
{
$ref->[0] = $1;		    # $name	(remove the () )
push @delta_function_refs, $ref;
} else
{
push @delta_alias_refs, $ref;
}
}
map { GBSENV_setalias( $_->[0], $_->[1]->[0]); } @delta_alias_refs;
map { GBSENV_setfunction( $_->[0], $_->[1]); } @delta_function_refs;    # Linux only

if ($entry_or_exit eq 'entry')
{

my @new_alias_names = map { $_->[0] } @delta_alias_refs;

ENV_setenv( GBS_SWITCH_ALIASES => \@new_alias_names);
if ($IS_LINUX)
{

my @new_function_names = map { $_->[0] } @delta_function_refs;

ENV_setenv( GBS_SWITCH_FUNCTIONS => \@new_function_names);
}
} else  # $entry_or_exit eq 'exit'
{

my @new_alias_names = ENV_getenv( 'GBS_SWITCH_ALIASES');

map { GBSENV_setalias( $_, undef) } @new_alias_names;
ENV_setenv( GBS_SWITCH_ALIASES => undef);
if ($IS_LINUX)
{

my @new_function_names = ENV_getenv( 'GBS_SWITCH_FUNCTIONS');

map { GBSENV_setfunction( $_, undef) } @new_function_names;
ENV_setenv( GBS_SWITCH_FUNCTIONS => undef);
}
}
}
} else
{
ENV_sig( E => 'Execution of switch.gbs failed.',
'EnvVar GBS_SITE is not properly set?')
}

return $rc;
}




sub parse_envvars($)
{
my ($lines_ref,
) = @_;
my @envvar_refs;


foreach my $line (@{$lines_ref})
{
my ($name, $value) = split( '=', $line, 2);
push @envvar_refs, [ $name, [ $value ] ];
}

return @envvar_refs;
}





sub parse_win32($)
{
my ($lines_ref,
) = @_;
my @alias_refs;


foreach my $line (@{$lines_ref})
{
my ($name, $value) = split( '=', $line, 2);
push @alias_refs, [ $name, [ $value ] ];
}

return @alias_refs;
}






sub parse_linux($)
{
my ($lines_ref,
) = @_;
my @alias_refs;





my @lines;
while (@{$lines_ref})
{
my $line = shift @{$lines_ref};
while (substr( $line, -1, 1) eq '\\')
{
$line =~ s/\\$/ /;				# replace trailing '\' by ' '
my $next_part = shift @{$lines_ref};
$next_part =~ s/^\s+//;			# remove leading spaces
$line .= $next_part;
}
push @lines, $line;
}





while (@lines)
{
my $line = shift @lines;
if (substr( $line, 0, 5) eq 'alias')
{
my ($name, $value) = split( '=', substr( $line, 6), 2);
push @alias_refs, [ $name, [ $value ] ];
} else	# functionname
{
my $name = $line;
my @values;
$line = shift (@lines);
while (defined $line && $line ne '}')
{
push @values, $line;
$line = shift (@lines);
}
push @values, $line;
push @alias_refs, [ $name, [ @values ] ];
}
}


return @alias_refs;
}




sub delta_values($$$)
{
my ($name,			# envvar or alias
$pre_values_ref,	#  [ [ $name, $values_ref ], ... ]
$post_values_ref,	#  [ [ $name, $values_ref ], ... ]
) = @_;
my @delta_value_refs;

my %old_values = map { $_->[0], $_->[1] } @{$pre_values_ref};


my @new_value_refs;
my @changed_value_refs;
my @same_value_refs;
my @deleted_value_refs;
foreach my $ref (@{$post_values_ref})   # post-values
{
my ($name, $values_ref) = @{$ref};
my $old_values_ref = $old_values{$name};
if (defined $old_values_ref)
{
if ("@{$values_ref}" ne "@{$old_values_ref}")
{
push @changed_value_refs, [ $name, $values_ref ];
} else
{
push @same_value_refs, [ $name, $values_ref ];
}
delete $old_values{$name};
} else
{
push @new_value_refs, [ $name, $values_ref ];
}
}
@deleted_value_refs = map { [ $_ => undef ] } keys %old_values;





@delta_value_refs = (@new_value_refs, @changed_value_refs, @deleted_value_refs);

return @delta_value_refs;
}

1;


