#=================================================
#
#   list.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::list;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
LIST_contains_str
LIST_firstidx_str
LIST_firstidx_ref_str
LIST_unique
LIST_is_eq_str
);
}








sub LIST_contains_str($$);
sub LIST_firstidx_str($$);
sub LIST_firstidx_ref_str($$$);
sub LIST_unique($);
sub LIST_is_eq_str($$);








sub LIST_contains_str($$)
{
my ($item,
$list_ref
) = @_;
my $found = 0;

foreach my $list_item (@{$list_ref})
{
if (defined $list_item && $list_item eq $item)
{
$found = 1;
last;
}
}

return $found;
}




sub LIST_firstidx_str($$)
{
my ($item,
$list_ref
) = @_;
my $index = -1;

my $nr_items = scalar @{$list_ref};
for (my $i = 0; $i < $nr_items; $i++)
{
my $list_item = $list_ref->[$i];
if (defined $list_item && $list_item eq $item)
{
$index = $i;
last;
}
}

return $index;
}




sub LIST_firstidx_ref_str($$$)
{
my ($item,
$list_refs_ref,
$ref_index
) = @_;
my $index = -1;

my $nr_items = scalar @{$list_refs_ref};
for (my $i = 0; $i < $nr_items; $i++)
{
my $list_item = $list_refs_ref->[$i]->[$ref_index];
if (defined $list_item && $list_item eq $item)
{
$index = $i;
last;
}
}

return $index;
}






sub LIST_unique($)
{
my ($list_ref) = @_;   # In/Out


my %seen;
if (wantarray)
{
return grep { ! $seen{ $_ }++ } @{$list_ref};
} else
{
@{$list_ref} = grep { ! $seen{ $_ }++ } @{$list_ref};
}
}





sub LIST_is_eq_str($$)
{
my ($list1_ref,
$list2_ref,
) = @_;
my $is_equal = 0;

if (@{$list1_ref} == @{$list2_ref})
{
$is_equal = 1;
my $nr_items = @{$list1_ref};
for (my $i = 0; $i < $nr_items; $i++)
{
if ($list1_ref->[$i] ne $list2_ref->[$i])
{
$is_equal = 0;
last;
}
}
}

return $is_equal;
}

1;
