#=================================================
#
#   tkxtoplevel.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::tkxtoplevel;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
TKXTOPLEVEL_new
TKXTOPLEVEL_show
TKXTOPLEVEL_hide
);
}




use Tkx;


use glo::tkx;
use glo::tkxglo;




sub TKXTOPLEVEL_new($$$$$@);
sub TKXTOPLEVEL_show($);
sub TKXTOPLEVEL_hide($);
















sub TKXTOPLEVEL_new($$$$$@)
{
my ($mw,			    # Main window
$title,
$geometry_ref,		    # [ $width, $height, $x, $y ]
$transient,		    # Bool. Default = 1. Transient == connected to main
$delete_window_command,
@args,			    # Args for new_toplevel widget
) = @_;
my $toplevel;

$toplevel = $mw->new_toplevel( @args);
$toplevel->g_wm_withdraw();

$toplevel->g_wm_title( $title);

my $icon_photo = TKXGLO_photo( 'icon' );
if (defined $icon_photo)
{
$toplevel->g_wm_iconphoto( $icon_photo);
}
if (defined $geometry_ref)
{
my ($width, $height, $x, $y) = @{$geometry_ref};
TKX_geometry( $toplevel, $width, $height, $x, $y);
}
if (defined $delete_window_command)
{
$toplevel->g_wm_protocol( WM_DELETE_WINDOW => $delete_window_command );
}
if (!defined $transient || $transient == 1)
{
$toplevel->g_wm_transient( $mw);
}

return $toplevel;
}




sub TKXTOPLEVEL_show($)
{
my ($toplevel,
) = @_;

$toplevel->g_wm_deiconify();
$toplevel->g_raise();
$toplevel->g_focus();
}




sub TKXTOPLEVEL_hide($)
{
my ($toplevel,
) = @_;

$toplevel->g_wm_withdraw();
}

1;

