#=================================================
#
#   makemake.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::makemake;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
MAKEMAKE_main
);
}




use glo::env;
use glo::spit;
use glo::path;
use glo::depend;
use mod::gbsglo;
use mod::gbsfileglo;
use mod::flincs;
use mod::glkb;
use mod::build;
use mod::fspec;




sub MAKEMAKE_main(;@);

sub makecompmake($);
sub get_file_dependencies();
sub depend_glkb();
sub get_gbs_dependencies();
sub generate_rule($$$$);
sub heading(@);
sub set_includes();
sub find_file_rel($);
sub warning($$@);
sub error($$@);
sub prepare_filespecs(@);








my @STUBS_PATHS;

my %SRCS;

my %BLDS;


my %SRC_TYPES_DATA;










my $COMPONENT;
my $COMPONENT_PATH;
my $CWD;
my %GBS_DEPEND;


my %GBSFILES;	    # cache for processed gbsfile-contents


my %ABS_INCPATH_CACHE;  # cache for abs include-paths (used by DEPEND_.. functions)


my %INCPATHS_CACHE;	    # cache for include-paths




my %FOUND_FILES;     # cache for found includes






my @INCPATH_REFS;	# from %INCPATHS_CACHE: contains the include-path for the current file [ type, name ]
my @ABS_INCPATHS;	# from %ABS_INCPATH_CACHE: contains the include-path for the current file

my $SRC_FILE;		# name.type
my $SRC_TYPE;		# .type
my $SRC_GEN_TYPE;	# gen | asm | c | glb | glk | glt
my $SRC_FILE_SPEC;	# $CWD/$SRC_FILE
my $SRC_SHORT_FILE_SPEC;

my %EXTERNALS;


my %UNRESOLVED;





my $ERROR_COUNT;
my $WARNING_COUNT;




my $COMMENT_RE_ASM = qr!^\s*[;*/#].*!;
my $INCLUDE_RE_ASM = qr!^\s*#\s*include\s+([<"]?)(.+)[>"]?!;
my %DEFAULT_RE = (

asm =>  [ $INCLUDE_RE_ASM, $COMMENT_RE_ASM],
c	=>  [ '',	       '' ],
gen =>  [ '',	       '' ],
glb =>  [ '',	       '' ],
glk =>  [ '',	       '' ],
glt =>  [ '',	       '' ],
);




sub MAKEMAKE_main(;@)
{
my @components = @_;
my $rc = 0;

%SRCS = ();
%BLDS = ();
$CWD = ENV_cwd();
$ERROR_COUNT = 0;
$WARNING_COUNT = 0;
%SRC_TYPES_DATA = ();

@STUBS_PATHS = FLINCS_get_stubs_incs();

foreach my $src_type (BUILD_get_src_types( $GBS::BUILD))
{
my ($type, $include_re, $comment_re) = BUILD_get_src_items( $GBS::BUILD, $src_type, 'TYPE');
$include_re = $DEFAULT_RE{$type}->[0]
if ($include_re eq '');
$comment_re = $DEFAULT_RE{$type}->[1]
if ($comment_re eq '');
$SRC_TYPES_DATA{$src_type}->{TYPE} = $type;
$SRC_TYPES_DATA{$src_type}->{INCLUDE_RE} = $include_re;
$SRC_TYPES_DATA{$src_type}->{COMMENT_RE} = $comment_re;
$SRC_TYPES_DATA{$src_type}->{OUT_TYPES} = BUILD_get_src_items( $GBS::BUILD, $src_type, 'OUT_TYPES');
$SRC_TYPES_DATA{$src_type}->{OUT_FILES} = BUILD_get_src_items( $GBS::BUILD, $src_type, 'OUT_FILES');
$SRC_TYPES_DATA{$src_type}->{UNIX_TYPE_SEARCH} =
(BUILD_get_src_items( $GBS::BUILD, $src_type, 'INC_SEARCH_STYLE') eq 'UNIX') ? 1 : 0;
}

my @allcomp = GBSGLO_components_for_build( $GBS::SUBSYS, $GBS::BUILD);
my %selcomp;
if (@components)
{
%selcomp = map { $_ => 1 } @components;
ENV_say( 1, "MakeMake SubSystem '${GBS::SUBSYS}::(@components)' for Build '$GBS::BUILD'...");
} else
{
%selcomp = map { $_ => 1 } @allcomp;
ENV_say( 1, "MakeMake SubSystem '$GBS::SUBSYS' for Build '$GBS::BUILD'...");
}

if (%selcomp)
{



my $saved_cwd = $CWD;
foreach my $component (@allcomp)
{
$COMPONENT = $component;
$COMPONENT_PATH = "$GBS::COMP_PATH/$COMPONENT";
$CWD = ENV_chdir( "$COMPONENT_PATH/src");
my @all_src_files = sort( glob( '*.*'));

my @src_file_refs;
foreach my $file (GBSGLO_select_specs( @all_src_files))
{

if ($file =~ /\s/)
{
ENV_sig( W => "File: '$COMPONENT:$file': No spaces in filename allowed. File Skipped");
next;
}
my ($file_name, $filetype) = ENV_split_spec_nt( $file);
$SRC_FILE = "$file_name$filetype";
$SRC_TYPE = $filetype;
$SRC_GEN_TYPE = undef;
$SRC_FILE_SPEC = "$CWD/$SRC_FILE";
$SRC_SHORT_FILE_SPEC = GBSGLO_short_filespecs( $SRC_FILE_SPEC);
if (exists $SRC_TYPES_DATA{$filetype})
{
push @src_file_refs, [ $file_name, $filetype ];
foreach my $out_type (@{$SRC_TYPES_DATA{$filetype}->{OUT_TYPES}})
{
my $bld_file = $file_name . $out_type;
$BLDS{$COMPONENT}->{$bld_file} = 1;

}
foreach my $bld_file (@{$SRC_TYPES_DATA{$filetype}->{OUT_FILES}})
{
$BLDS{$COMPONENT}->{$bld_file} = 1;

}
} else
{
error( undef, undef,
"Unknown file-type ($filetype) - Skipped");
}
}
$SRCS{$component} = [ @src_file_refs ];
}





my @allgencomp;
my @compmakefiles;
foreach my $component (@allcomp)
{
$COMPONENT = $component;





my $compmakefile = "$GBS::COMP_PATH/$COMPONENT/bld/$GBS::BUILD.mk";
if (exists $selcomp{$COMPONENT} || ! -f $compmakefile)
{
$COMPONENT_PATH = "$GBS::COMP_PATH/$COMPONENT";
$CWD = ENV_chdir( "$COMPONENT_PATH/src");
makecompmake( $compmakefile);
}
push @allgencomp, $COMPONENT;
push @compmakefiles, $compmakefile;
}
ENV_chdir( $saved_cwd)
if ($CWD ne $saved_cwd);




my $makefile = FSPEC_gbsmake_file( "$GBS::SUBSYS_PATH/build", $GBS::BUILD);
my @lines;




my $now = localtime();
push @lines, heading( "File:\t$makefile",
"SubSys:\t$GBS::SUBSYS",
"Generated:\t$now",
'');
push @lines, '';




@compmakefiles = prepare_filespecs( @compmakefiles);
push @lines, map { "include $_" } @compmakefiles;




push @lines, '';
push @lines, heading( 'All components');
push @lines, generate_rule( [ 'ALL' ], '', \@allgencomp, 0);




push @lines,  '';
push @lines, heading( 'Dummy Make-Build');
push @lines, generate_rule( [ 'ALWAYS' ], '', [], 0);




push @lines, '';
push @lines, '### EOF ###';




ENV_whisper( 1, "Writing SubSys '$makefile'...");
SPIT_file_nl( $makefile, \@lines);
} else
{
ENV_sig( W => "No components for this Build - Nothing generated");
}

ENV_say( 0, '')
if (%UNRESOLVED || %EXTERNALS);

if (%UNRESOLVED)
{
ENV_say( 1, "Unresolved:");
foreach my $file (sort( keys %UNRESOLVED))
{
my $count = $UNRESOLVED{$file};
ENV_say( 0, "    $file: $count ref(s)");
}
}
if (%EXTERNALS)
{
ENV_say( 1, "Unresolved externals:");
foreach my $file (sort( keys %EXTERNALS))
{
my $count = $EXTERNALS{$file};
ENV_say( 0, "    $file: $count ref(s)");
}
}
if ($WARNING_COUNT > 0)
{
ENV_say( 1, "Nr of Warnings: $WARNING_COUNT");
}
if ($ERROR_COUNT > 0)
{
ENV_say( 1, "Nr of Errors: $ERROR_COUNT");
$rc = 1 if ($rc < 1);
}

return $rc;
}




sub makecompmake($)
{
my ($compmakefile) = @_;

ENV_say( 1, "MakeCompMake '$COMPONENT'...");
my $src_path = "$COMPONENT_PATH/src";
my $bld_path = "$COMPONENT_PATH/bld/$GBS::BUILD";




%GBS_DEPEND = ();
%GBSFILES = ();
%INCPATHS_CACHE = ();
%ABS_INCPATH_CACHE = ();
%FOUND_FILES = ();




my @mk_lines;
my @xref_lines;

my $now = localtime();
push @mk_lines, heading( "File:\t$GBS::BUILD.mk",
"Component:\t$COMPONENT",
"SubSys:\t$GBS::SUBSYS",
"Generated:\t$now",
'');

my %dup_mk_targets;
my @all_out_files;
foreach my $src_file_ref (@{$SRCS{$COMPONENT}})
{
my ($file_name, $filetype) = @{$src_file_ref};
$SRC_FILE = "$file_name$filetype";
$SRC_TYPE = $filetype;
$SRC_GEN_TYPE = $SRC_TYPES_DATA{$SRC_TYPE}->{TYPE};
$SRC_FILE_SPEC = "$CWD/$SRC_FILE";
$SRC_SHORT_FILE_SPEC = GBSGLO_short_filespecs( $SRC_FILE_SPEC);




my @out_types = @{$SRC_TYPES_DATA{$SRC_TYPE}->{OUT_TYPES}};
my @out_files = @{$SRC_TYPES_DATA{$SRC_TYPE}->{OUT_FILES}};
my $out_type = $out_types[0];





push @mk_lines, '';
my @make_targets = map { "$file_name$_" } @out_types;
push @make_targets, @out_files;
foreach my $make_target (@make_targets)
{
if (exists $dup_mk_targets{$make_target})
{
error( undef, undef,
"Duplicate Make-Target: $make_target");
} else
{
$dup_mk_targets{$make_target} = 1;
}
}
push @mk_lines, heading( "$SRC_FILE -> @make_targets");




my $gen_command = "gbsbuild $COMPONENT:$SRC_FILE";




my @depend_line_refs = get_file_dependencies();





my @depend_lines = map { $_->[1] } @depend_line_refs;	    # $file




@make_targets = map { "$bld_path/$_" } @make_targets;
push @mk_lines, generate_rule( [ @make_targets ], $gen_command, \@depend_lines, 1);
push @all_out_files, "$bld_path/$file_name$out_type";




foreach my $ref (@depend_line_refs)
{
my ($inc_level, $file) = @{$ref};
next if ($inc_level < 0);			# comment
push @xref_lines, "$inc_level $file";
}
}

push @mk_lines, '';
push @mk_lines, heading( "All files for component $COMPONENT");
push @mk_lines, generate_rule( [ $COMPONENT ], '', \@all_out_files, 0);

push @mk_lines, '';
push @mk_lines, '### EOF ###';




ENV_whisper( 1, "Writing $COMPONENT '$compmakefile'...");
SPIT_file_nl( $compmakefile, \@mk_lines);
my $reffile = "$COMPONENT_PATH/bld/$GBS::BUILD.ref";
ENV_whisper( 1, "Writing $COMPONENT '$reffile'...");
SPIT_file_nl( $reffile, \@xref_lines);

return;
}





sub get_file_dependencies()
{
my ($file) = @_;
my @file_refs;





set_includes();	# @INCPATH_REFS & @ABS_INCPATHS

push @file_refs, [ 0, $SRC_FILE_SPEC ];
my ($nr_errors, $nr_warnings, @depend_refs);
if (BUILD_is_glkb_type( $SRC_GEN_TYPE))	# glb glk glt
{
($nr_errors, $nr_warnings, @depend_refs) = depend_glkb();
} elsif ($SRC_GEN_TYPE eq 'c')		# c
{
my $is_unix_type_search = $SRC_TYPES_DATA{$SRC_TYPE}->{UNIX_TYPE_SEARCH};
($nr_errors, $nr_warnings, @depend_refs) = DEPEND_c( $SRC_FILE_SPEC, $is_unix_type_search,
\@ABS_INCPATHS, \@STUBS_PATHS, undef);
} else					# gen asm
{
my $comment_re = $SRC_TYPES_DATA{$SRC_TYPE}->{COMMENT_RE};
my $include_re = $SRC_TYPES_DATA{$SRC_TYPE}->{INCLUDE_RE};
($nr_errors, $nr_warnings, @depend_refs) = DEPEND_line( $comment_re, $include_re, $SRC_FILE_SPEC, \@ABS_INCPATHS, \@STUBS_PATHS, undef);
}

if ($nr_errors > 0)
{
ENV_say( 1, "$nr_errors error(s) found while parsing '$COMPONENT:$SRC_FILE'");
push @file_refs, [ 1, 'ALWAYS' ];
push @file_refs, [ -3, "# ALWAYS: $SRC_FILE - parser found $nr_errors error(s)" ];
$ERROR_COUNT += $nr_errors;
}

if ($nr_warnings > 0)
{
foreach my $ref (@depend_refs)
{
my ($level, $found, $line_nr, $inc_type, $inc_name, $inc_filespec) = @{$ref};

if ($found eq 'N')
{
($found, $inc_filespec) = find_file_rel( $inc_name);
if ($found ne 'N')
{

$ref->[1] = $found;
$ref->[5] = $inc_filespec;
$nr_warnings--;
}
}
}
ENV_say( 1, "$nr_warnings warning(s) found while processing '$COMPONENT:$SRC_FILE'")
if ($nr_warnings > 0);
}

foreach my $ref (@depend_refs)
{
my ($level, $found, $line_nr, $inc_type, $inc_name, $inc_filespec) = @{$ref};

if ($found eq 'F')
{


push @file_refs, [ $level, $inc_filespec ];
} elsif ($found eq 'S')
{

my $short_inc_filespec = GBSGLO_short_filespecs( $inc_filespec);
push @file_refs, [ -1, "# $inc_name found in $short_inc_filespec" ];
} elsif ($found eq 'N')
{

my $calling_filespec = $inc_filespec;
my $short_calling_filespec = GBSGLO_short_filespecs( $calling_filespec);






my $go_soft = ((!ENV_is_in_path( $calling_filespec, $GBS::ROOT_PATH)) ||
ENV_is_in_path( $calling_filespec, "$GBS::ROOT_PATH/ext"));
if ($go_soft)
{
if (exists $EXTERNALS{$inc_name})
{
$EXTERNALS{$inc_name}++;
} else
{
$EXTERNALS{$inc_name} = 1;
warning( $calling_filespec, $line_nr,
"gen: Unable to locate '$inc_name' (external)",
'File skipped',
'Further messages suppressed',
map { "- $_->[1]" } @INCPATH_REFS,
);
}

push @file_refs, [ -1, "# Unable to locate (external) '$inc_name' from $short_calling_filespec($line_nr)" ];
} else
{
$UNRESOLVED{$inc_name}++;
warning( $calling_filespec, $line_nr,
"gen: Unable to locate '$inc_name'",
'Possibly a conditional or generated file',
'Source will regenerate ALWAYS');
push @file_refs, [ 1, 'ALWAYS' ];

push @file_refs, [ -2, "# ALWAYS: Unable to locate: '$inc_name' from $short_calling_filespec($line_nr)" ];
}
} else
{
ENV_sig( F => "Invalid 'found' ($found'");
}
}

return @file_refs;
}




sub depend_glkb()
{
my ($nr_errors, $nr_warnings, @depend_refs);







GLKB_parse( $SRC_FILE, $GBS::BUILD, $COMPONENT);
( $nr_errors, $nr_warnings, my @in_line_refs ) = GLKB_get_dependencies();




foreach my $ref (@in_line_refs)
{
my ($inc_level, $file, $org_file, $line_ref) = @{$ref};
my (undef, $inc_file, $line_nr, undef) = GBSFILEGLO_get_line_info( $line_ref);



my ($found, $spec);
if (ENV_is_abs_path_perl( $file))	    # ABS path
{




$found = 'F';
$spec = $file;
} elsif ($file !~ m!/!) 		    # pure file (no dirspec)
{





($found, $spec) = find_file_rel( $file);
} else					    # other relative path
{




my $found_file = '';
foreach my $inc_path_ref (@INCPATH_REFS)
{
if ($inc_path_ref->[0] eq 'P')
{
my $dir = $inc_path_ref->[1];

my $search_file = "$dir/$file";
if (PATH_file_exists( $search_file))
{
$found_file = $search_file;
last;
}
}
}
if ($found_file ne '')
{
$found = 'F';
$spec = $found_file;
} else
{



if ($file =~ m!^\.\.?/!)	# starts with ./ or ../
{
$found = 'F';
$spec = ENV_canonicalize_paths( "$CWD/$file");
} else
{
$found = 'N';
$spec = $inc_file;
}
}
}

push @depend_refs, [ $inc_level, $found, $line_nr, '', $org_file, $spec ];

}

return ($nr_errors, $nr_warnings, @depend_refs);
}




sub get_gbs_dependencies()
{


if (!exists $GBS_DEPEND{$SRC_TYPE})
{
my @files;




{
my $key = "F$SRC_TYPE";
if (!exists $GBSFILES{$key})
{
my @flag_files = ( FLINCS_get_flags_files( $SRC_TYPE, $COMPONENT),
BUILD_get_sysflags_file( $GBS::BUILD, $SRC_TYPE));
@flag_files = grep( PATH_file_exists( $_), ENV_perl_paths_noquotes( @flag_files));
$GBSFILES{$key} = [ @flag_files ];
}
push @files, @{$GBSFILES{$key}};
}




{
my $key = "I$SRC_TYPE";
if (!exists $GBSFILES{$key})
{
my @inc_files = ( FLINCS_get_incs_files( $SRC_TYPE, $COMPONENT),
BUILD_get_sysincs_file( $GBS::BUILD, $SRC_TYPE));
@inc_files = grep( PATH_file_exists( $_), @inc_files);
$GBSFILES{$key} = [ @inc_files ];
}
push @files, @{$GBSFILES{$key}};
}




foreach my $file ( "$COMPONENT_PATH/scope",
"$GBS::SYSBUILD_PATH/sysbuild")
{
my $gbs_or_usr_file = GBSFILEGLO_select_usr_gbs( $file);
push @files, $gbs_or_usr_file
if (defined $gbs_or_usr_file);
}
push @files, BUILD_get_dependencies( $GBS::BUILD, $SRC_TYPE);	    # build.gbs and command_file(s)

$GBS_DEPEND{$SRC_TYPE} = [ @files ];
}

return @{$GBS_DEPEND{$SRC_TYPE}};
}




sub generate_rule($$$$)
{
my ($make_targets_ref,
$gen_command,
$dependencies_ref,
$must_add_gbs_dependencies,
) = @_;
my @lines;




foreach my $make_target (@{$make_targets_ref})
{
$make_target = prepare_filespecs( $make_target);
push @lines, "$make_target : \\";
}




my @comments;
foreach my $depend (@{$dependencies_ref})
{
if (substr( $depend, 0, 1) eq '#')
{
push @comments, $depend;
} else
{
$depend = prepare_filespecs($depend);
push @lines, "  $depend \\";
}
}
if ($must_add_gbs_dependencies)
{
foreach my $depend (get_gbs_dependencies())
{
$depend = prepare_filespecs( $depend);
push @lines, "  $depend \\";
}
}




$lines[-1] = substr( $lines[-1], 0, -2);




push @lines, "\t$gen_command"
if ($gen_command ne '');




push @lines, @comments;

return \@lines;
}




sub heading(@)
{
my (@items
) = @_;
my @lines;

push @lines, '#=========================================================';
foreach my $item (@items)
{
if ($item eq '')
{
push @lines, '#';
} else
{
push @lines, "#   $item";
}
}
push @lines, '#=========================================================';

return \@lines;
}





sub set_includes()
{
my $key = "$COMPONENT:$SRC_TYPE";

if (exists $INCPATHS_CACHE{$key})
{
@INCPATH_REFS = @{ $INCPATHS_CACHE{$key} };
@ABS_INCPATHS = @{ $ABS_INCPATH_CACHE{$key} };

} else
{

@ABS_INCPATHS = ENV_abs_paths( $CWD, [ FLINCS_get_incs( $SRC_TYPE, $COMPONENT),   # inc
FLINCS_get_sysincs( $SRC_TYPE)]);	  # sysinc
foreach my $path (@ABS_INCPATHS)
{
ENV_sig( EE => 'Include path does not exist',
"- $path")
if (!-d $path);
}
$ABS_INCPATH_CACHE{$key} = [ @ABS_INCPATHS ];

@INCPATH_REFS = ();
foreach my $dir (@ABS_INCPATHS)
{
if ($dir =~ m!$GBS::COMP_PATH/([^/]+)/bld/$GBS::BUILD!)
{
push @INCPATH_REFS, [ 'C', $1 ];
} else
{

push @INCPATH_REFS, [ 'P', $dir ];
}
}

$INCPATHS_CACHE{$key} = [ @INCPATH_REFS ];
}
}








sub find_file_rel($)
{
my ($file) = @_;
my ($found, $spec);


my $file_key = "$SRC_TYPE>$file";
my $found_ref = $FOUND_FILES{$file_key};
if (defined $found_ref)
{
($found, $spec) = @{$found_ref};
} else
{



my $found_file = '';
foreach my $inc_path_ref (@INCPATH_REFS)
{
if ($inc_path_ref->[0] eq 'C')
{
my $component = $inc_path_ref->[1];

if (exists $BLDS{$component}->{$file})
{
$found_file = "$GBS::COMP_PATH/$component/bld/$GBS::BUILD/$file";

last;
}
} else	# $inc_path_ref->[0] eq 'P'
{
my $dir = $inc_path_ref->[1];

my $search_file = "$dir/$file";
if (PATH_file_exists( $search_file))
{
$found_file = $search_file;
last;
}
}
}
if ($found_file ne '')
{
$found = 'F';
$spec = $found_file;
} else
{



foreach my $stub_location (@STUBS_PATHS)
{
if (PATH_file_exists( "$stub_location/$file"))
{
my $short_spec = GBSGLO_short_filespecs( "$stub_location/$file");
$found_file = $short_spec;
last;
}
}
if ($found_file ne '')
{
$found = 'S';
$spec = $found_file;
} else
{
$found = 'N';
$spec = '';
}
}
$FOUND_FILES{$file_key} = [ $found, $spec ];
}

return ($found, $spec);
}




sub warning($$@)
{
my ($file,		# may be undef
$line_nr,	# may be undef
@texts
) = @_;

$WARNING_COUNT++;
$file = GBSGLO_short_filespecs( $file)
if (defined $file);
ENV_file_sig( W => [ undef, $SRC_SHORT_FILE_SPEC, $file, $line_nr, '' ], \@texts);
}




sub error($$@)
{
my ($file,		# may be undef
$line_nr,	# may be undef
@texts
) = @_;

$ERROR_COUNT++;
$file = GBSGLO_short_filespecs( $file)
if (defined $file);
ENV_file_sig( E => [ undef, $SRC_SHORT_FILE_SPEC, $file, $line_nr, '' ], \@texts);
}




sub prepare_filespecs(@)
{
my @list = (@_);



@list = ENV_os_paths( @list);


return wantarray ? @list : $list[0];
}

1;


