#=================================================
#
#   scmgit.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
#   File states:
#    -2 => 'NO-FILE',
#    -1 => 'NOT-CCM',
#     0 => 'CHECKED-IN',
#     1 => 'CHECKED-OUT',
#=================================================
package glo::scmgit;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SCMGIT_init
SCMGIT_connect
SCMGIT_cache_states
SCMGIT_get_states
SCMGIT_checkout
SCMGIT_uncheckout
SCMGIT_checkin
SCMGIT_remove
SCMGIT_move
SCMGIT_add_dirs
SCMGIT_add_files
SCMGIT_get_ignore
SCMGIT_set_ignore
SCMGIT_setup
);
}




use File::Path;
use glo::env;
use glo::slurp;
use glo::spit;
use glo::file;


ENV_whisper( 1, "Loading Git Plugin...");




sub SCMGIT_init($$);
sub SCMGIT_connect($$$);
sub SCMGIT_cache_states($);
sub SCMGIT_get_states($);
sub SCMGIT_checkout($);
sub SCMGIT_uncheckout($);
sub SCMGIT_checkin($);
sub SCMGIT_remove($);
sub SCMGIT_move($);
sub SCMGIT_add_dirs($);
sub SCMGIT_add_files($);
sub SCMGIT_get_ignore($);
sub SCMGIT_set_ignore($$);
sub SCMGIT_setup($$$);

sub exec_init($);
sub exec_version();
sub exec_info($);
sub exec_status($);
sub exec_full_status_recurse();
sub exec_commit($);
sub exec_checkout($);
sub exec_reset($);
sub exec_delete($);
sub exec_move($$);
sub exec_add($$);
sub exec_config($$$);

sub extract_state($$);
sub update_gitignore($$);




my $APP_NAME;
my $APP_ROOT_PATH;
my $APP_ROOT_PATH_L;


my $EXEC_OS = 'git';

my %FSTATES;

my $ALL_STATES_ARE_CACHED = 0;




sub SCMGIT_init($$)
{
($APP_NAME,
$EXEC_OS) = @_;
}





sub SCMGIT_connect($$$)
{
(undef,		    # REPOSITORY
$APP_ROOT_PATH,
undef) = @_;	    # DATA
my ($repos_root_path, $internal_path, $connect_texts_ref);

$APP_ROOT_PATH_L = length $APP_ROOT_PATH;
$connect_texts_ref = exec_version();

($repos_root_path, $internal_path) = exec_info( $APP_ROOT_PATH);


%FSTATES = ();	    # clear previous file-states
$ALL_STATES_ARE_CACHED = 0;



return ($repos_root_path, $internal_path, $connect_texts_ref);
}




sub SCMGIT_cache_states($)
{
my ($force_reread,	    # bool
) = @_;

if ($force_reread || !$ALL_STATES_ARE_CACHED)
{
%FSTATES = ();	    # clear previous file-states
foreach my $ref (exec_full_status_recurse())
{
my ($states_6, $filespec) = @{$ref};
my $scm_state = extract_state( $states_6, $filespec);
$FSTATES{$filespec} = $scm_state;
}
}
$ALL_STATES_ARE_CACHED = 1;


}








sub SCMGIT_get_states($)
{
my ($spec_refs_ref,	    # [ [ $spec, $state ], ... ]
) = @_;






my @specs;	    # files not in cache
foreach my $spec_ref (@{$spec_refs_ref})
{
my ($spec, $state) = @{$spec_ref};

if (defined $state)	    # $state may be -2 (no such file/dir)
{

} else
{

$state = $FSTATES{$spec};
if (defined $state)
{

$spec_ref->[1] = $state;	# $state
} else
{
if ($ALL_STATES_ARE_CACHED)
{



$spec_ref->[1] = -1;	# $state = Not SCM

} else
{
push @specs, $spec;
}
}
}
}




if (@specs)
{



my @paths;
my @files;
foreach my $element (@specs)
{
if (-d $element)
{
push @paths, "$element/.gitignore";
} else
{
push @files, $element;
}
}




if (@files)
{
foreach my $ref (exec_status( \@files))
{
my ($states, $filespec) = @{$ref};
my $scm_state = extract_state( $states, $filespec);

$FSTATES{$filespec} = $scm_state;
}
}




if (@paths)
{
foreach my $ref (exec_status( \@paths))
{
my ($states, $ignore_filespec) = @{$ref};
my $scm_state = extract_state( $states, $ignore_filespec);

my $dir_spec = substr( $ignore_filespec, 0, -11);

$FSTATES{$dir_spec} = $scm_state;
}
}
}




foreach my $spec_ref (@{$spec_refs_ref})
{
my ($spec, $state) = @{$spec_ref};
$spec_ref->[1] = $FSTATES{$spec}
if (!defined $state)
}


}




sub SCMGIT_checkout($)
{
my ($rel_specs_ref) = @_;

ENV_chmod( 'u+w', @{$rel_specs_ref});

map { $FSTATES{$_} = 1 } @{$rel_specs_ref}; # checkout
}




sub SCMGIT_checkin($)
{
my ($rel_specs_ref) = @_;

exec_commit( $rel_specs_ref);
ENV_chmod( 'ugo-w', @{$rel_specs_ref});
map { $FSTATES{$_} = 0 } @{$rel_specs_ref}; # checkin
}




sub SCMGIT_uncheckout($)
{
my ($rel_specs_ref) = @_;

exec_checkout( $rel_specs_ref);		# TBR?
exec_reset( $rel_specs_ref);		# TBR?
ENV_chmod( 'ugo-w', @{$rel_specs_ref});
map { $FSTATES{$_} = 0 } @{$rel_specs_ref}; # checkin
}




sub SCMGIT_remove($)
{
my ($rel_specs_ref) = @_;

ENV_chmod( 'u+w', @{$rel_specs_ref});
exec_delete( $rel_specs_ref);
map { rmtree( $_, 0, 1) } @{$rel_specs_ref};
map { $FSTATES{$_} = -1 } @{$rel_specs_ref}; # notscm
}




sub SCMGIT_move($)
{
my ($pair_refs_ref) = @_;

foreach my $ref (@{$pair_refs_ref})
{
my ($old_spec, $new_spec) = @{$ref};
ENV_chmod( 'u+w', $old_spec);
exec_move( $old_spec, $new_spec);
$FSTATES{$old_spec} = -1;	# notscm
$FSTATES{$new_spec} = 1;    	# checkout
}
}




sub SCMGIT_add_dirs($)
{
my ($dir_refs_ref) = @_;	    #	[ $dir, $ignores_ref ]

my @dir_specs;
my @ignore_dirspecs;
foreach my $ref (@{$dir_refs_ref})
{
my ($dir, $ignores_ref) = @{$ref};
ENV_mkdir( $dir, oct(777))
if (!-d $dir);
push @dir_specs, $dir;






my $ignore_spec = "$dir/.gitignore";
if (update_gitignore( $ignore_spec, $ignores_ref))
{
push @ignore_dirspecs, $ignore_spec;
}
}

exec_add( \@ignore_dirspecs, 1);		# force ignored files

map { $FSTATES{$_} = 1 } (@dir_specs, @ignore_dirspecs); # checkout
}




sub SCMGIT_add_files($)
{
my ($files_ref) = @_;

map { ENV_touch_file( $_) if (!-f $_) } @{$files_ref};
exec_add( $files_ref, 0);			# do not force ignored files
map { $FSTATES{$_} = 1 } @{$files_ref}; # checkout
}




sub SCMGIT_get_ignore($)
{
my ($dir,		# 1 dir only!
) = @_;
my @ignores;	# match: * = any string, ? = any single, [xx] = subset, [!xx] = non subset

my $ignore_spec = "$dir/.gitignore";
if (-e $ignore_spec)
{
@ignores = SLURP_file( $ignore_spec);
}

return @ignores;
}




sub SCMGIT_set_ignore($$)
{
my ($dirs_ref,
$ignores_ref,
) = @_;

my @ignore_dirspecs;
foreach my $path (@{$dirs_ref})
{

my $ignore_spec = "$path/.gitignore";
if (update_gitignore( $ignore_spec, $ignores_ref))
{
push @ignore_dirspecs, $ignore_spec;
}
}
exec_add( \@ignore_dirspecs, 1)		# force ignored files
if (@ignore_dirspecs);

map { $FSTATES{$_} = 1 } @ignore_dirspecs; # checkout
}




sub SCMGIT_setup($$$)
{
my ($app_root_path,
$default_scms_repository_path,
$default_scms_data,
) = @_;
my ($scms_repository_path, $scms_data) = ( '', '');

ENV_whisper( 1, exec_version());
if (-e "$app_root_path/.git")
{



ENV_say( 1, 'Already under Git:');
($scms_repository_path, $scms_data) = exec_info( $app_root_path);
ENV_say( 2, "$scms_repository_path => $scms_data");
} else
{



exec_init( $app_root_path);
($scms_repository_path, $scms_data) = exec_info( $app_root_path);
exec_config( $app_root_path, 'core.autocrlf' => 'false');	# disable LF <=> CRLF conversions
}




my $ignore_spec = "$app_root_path/.gitignore";
if (update_gitignore( $ignore_spec, []))
{
my $saved_app_root_path = $APP_ROOT_PATH;
$APP_ROOT_PATH = $app_root_path;
exec_add( [ $ignore_spec ], 1);
$APP_ROOT_PATH = $saved_app_root_path;
}

return ( $scms_repository_path, $scms_data );
}










sub exec_init($)
{
my ($app_root_path) = @_;

my $command = "$EXEC_OS init $app_root_path";
ENV_system( $command, [0]);
}








sub exec_version()
{
my @connect_texts;

my @stdout;
my $command = ENV_join_quoted_space( $EXEC_OS, '--version');
ENV_run3( $command, undef, [0], \@stdout, undef);
if ($stdout[0] !~ /^git version/)
{
ENV_say( 0, @stdout);
ENV_sig( EE => "Failed to start Git session");
}
@connect_texts = @stdout;

return [ @connect_texts];
}








sub exec_info($)
{
my ($app_root_path) = @_;
my ($repos_root_path, $branch) = ( '', '');




{
my $stdout;
my $command = ENV_join_quoted_space( $EXEC_OS, '-C', $app_root_path,
qw( remote -v));
my $rc = ENV_run3( $command, undef, [0], \$stdout, undef);
$repos_root_path = ($stdout) ? $stdout : 'Local Repository';

}




{
my @stdout;
my $command = ENV_join_quoted_space( $EXEC_OS, '-C', $app_root_path,
qw( branch));
my $rc = ENV_run3( $command, undef, [0], \@stdout, undef);

$branch = 'master';
foreach my $line (@stdout)
{
if (substr( $line, 0, 1) eq '*')
{
$branch = substr( $line, 2);
last;
}
}

}

return ($repos_root_path, $branch);
}







sub exec_full_status_recurse()
{
my (@status_refs);	    # ( [ $states, $filespec ])

my @stdout;
my $stderr;
my $command = ENV_join_quoted_space( $EXEC_OS, '-C', $APP_ROOT_PATH,
'status', '--porcelain', '-u', 'all', '--ignored', $APP_ROOT_PATH);
my $rc = ENV_run3( $command, undef, [0], \@stdout, \$stderr);
ENV_print( 0, "STDERR: $stderr")
if ($stderr);



my @all_spec_refs = FILE_recurse_tree( $APP_ROOT_PATH, undef, 0);


my @all_rel_spec_refs;


foreach my $ref (FILE_recurse_tree( $APP_ROOT_PATH, undef, 0))
{
my ($type, $spec) = @{$ref};
if ($type eq 'F' && $spec =~ /\.gitignore$/)
{

next;
}
my $rel_spec = (length $spec > $APP_ROOT_PATH_L ) ? substr( $spec, $APP_ROOT_PATH_L + 1) : '';
$rel_spec .= '/.gitignore'
if ($type eq 'D');
push @all_rel_spec_refs, [ $type, $rel_spec ];
}

if (@stdout)
{
my %states = map { $_ => '  ' } map { $_->[1] } @all_rel_spec_refs;	    # Assume tracked


foreach my $line (@stdout)
{

my $state = substr( $line, 0, 2);
my $rel_spec = substr( $line, 3);
$states{$rel_spec} = $state;
}
foreach my $ref (@all_rel_spec_refs)
{
my ($type, $rel_spec) = @{$ref};
my $states = $states{$rel_spec};
if ($type eq 'D')
{
$states = '??'
if ($states eq '  ' && !-e "$APP_ROOT_PATH/$rel_spec");
$rel_spec = substr( $rel_spec, 0, -11);		    # remove .gitignore
}
push @status_refs, [ $states, $rel_spec ];
}
} else
{



foreach my $ref (@all_rel_spec_refs)
{
my ($type, $rel_spec) = @{$ref};
my $states = '  ';		# Assume tracked
if ($type eq 'D')
{
$states = '??'
if ($states eq '  ' && !-e "$APP_ROOT_PATH/$rel_spec");
$rel_spec = substr( $rel_spec, 0, -11);		    # remove .gitignore
}
push @status_refs, [ $states, $rel_spec ];
}
}


return @status_refs;
}








sub exec_status($)
{
my ($rel_specs_ref,	    # files/dirs MUST exist!
) = @_;
my (@status_refs);	    # ( [ $states, $filespec ])



my @stdout;
my $stderr;
my $command = ENV_join_quoted_space( $EXEC_OS, '-C', $APP_ROOT_PATH,
'status', '--porcelain', '-u', 'all', '--ignored');
my $rc = ENV_run3( $command, $rel_specs_ref, [0], \@stdout, \$stderr);
ENV_print( 0, "STDERR: $stderr")
if ($stderr);

if (@stdout)
{
my %states = map { $_ => '  ' } @{$rel_specs_ref};	    # Assume all tracked

foreach my $line (@stdout)
{

my $state = substr( $line, 0, 2);
my $rel_spec = substr( $line, 3);
$states{$rel_spec} = $state;
}
foreach my $rel_spec (@{$rel_specs_ref})
{
my $states = $states{$rel_spec};
$states = '??'
if ($states eq '  ' && $rel_spec =~ /\.gitignore$/ && !-e "$APP_ROOT_PATH/$rel_spec");
push @status_refs, [ $states, $rel_spec ];
}
} else
{



foreach my $rel_spec (@{$rel_specs_ref})
{
my $states = '  ';		# Assume tracked
$states = '??'
if ($rel_spec =~ /\.gitignore$/ && !-e "$APP_ROOT_PATH/$rel_spec");
push @status_refs, [ $states, $rel_spec ];
}
}


return @status_refs;
}











sub exec_commit($)
{
my ($rel_specs_ref) = @_;


my $command = ENV_join_quoted_space( $EXEC_OS, '-C', $APP_ROOT_PATH,
'commit', '-m', "Checkin by $APP_NAME");
ENV_run3( $command, $rel_specs_ref, [0], undef, undef);
}









sub exec_checkout($)
{
my ($rel_specs_ref) = @_;

my $command = ENV_join_quoted_space( $EXEC_OS, '-C', $APP_ROOT_PATH,
qw( checkout --));
ENV_run3( $command, $rel_specs_ref, [0], undef, undef);
}









sub exec_reset($)
{
my ($rel_specs_ref) = @_;

my $command = ENV_join_quoted_space( $EXEC_OS, '-C', $APP_ROOT_PATH,
qw( reset --));
ENV_run3( $command, $rel_specs_ref, [0], undef, undef);
}








sub exec_delete($)
{
my ($rel_specs_ref) = @_;


my $command = ENV_join_quoted_space( $EXEC_OS, '-C', $APP_ROOT_PATH,
qw( rm -q --force));
ENV_run3( $command, $rel_specs_ref, [0], undef, undef);
}








sub exec_move($$)
{
my ($old_spec,
$new_spec,
) = @_;


my $command = ENV_join_quoted_space( $EXEC_OS, '-C', $APP_ROOT_PATH,
qw( mv));
ENV_run3( $command, [$old_spec, $new_spec], [0], undef, undef);
}








sub exec_add($$)
{
my ($rel_specs_ref,
$must_force,	    # Bool
) = @_;

my $command = ENV_join_quoted_space( $EXEC_OS, '-C', $APP_ROOT_PATH,
qw( add));
$command .= ' -f'
if ($must_force);
my $stderr;
ENV_run3( $command, $rel_specs_ref, [0], undef, \$stderr);
ENV_print( 0, "STDERR: $stderr")
if ($stderr);
}







sub exec_config($$$)
{
my ($app_root_path,
$item,		    # e.g: core.autocrlf
$value,		    # e.g: false
) = @_;


my $command = ENV_join_quoted_space( $EXEC_OS, '-C', $app_root_path,
'config', $item, $value);
ENV_run3( $command, undef, [0], undef, undef);
}











































sub extract_state($$)
{
my ($states,	    #XY
$filespec,
) = @_;
my $scm_state;	    # -1 = NotSCM, 0 = Checked_in, 1 = CheckedOut

my $state_x = substr( $states, 0, 1);
my $state_y = substr( $states, 1);
if ($states eq '??' || $states eq '!!' || $state_x eq 'D')
{
$scm_state = -1;			# Not SCM
} elsif ($states eq '  ' || $state_x eq 'A' || $state_x eq 'M')
{
$scm_state = 1;				# Checked Out;
} else
{
$scm_state = (-w $filespec) ? 1 : 0;	# Checked Out : Checked In
}

return $scm_state;
}





sub update_gitignore($$)
{
my ($ignore_spec,	    # "$path/.gitignore"
$ignores_ref,
) = @_;
my $is_new_file = 0;    # Bool

if (-e $ignore_spec)
{
ENV_hide_file( $ignore_spec, 0);		# unhide
my @lines = SLURP_file( $ignore_spec);
if ("@lines" ne "@{$ignores_ref}")
{
ENV_backup_file( $ignore_spec, '.sav', 'E');	# no exit on error
SPIT_file_nl( $ignore_spec, $ignores_ref);

}
} else
{
SPIT_file_nl( $ignore_spec, $ignores_ref);
$is_new_file = 1;

}
ENV_hide_file( $ignore_spec, 1);			# hide

return $is_new_file;
}

1;

