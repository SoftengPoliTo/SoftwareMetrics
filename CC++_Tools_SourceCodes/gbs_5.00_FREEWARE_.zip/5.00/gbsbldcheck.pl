#=================================================
#
#   gbsbldcheck.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSBLDCHECK @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::genopt;
use mod::gbsenv;
use mod::gbsglo;
use mod::build;
use mod::validate;




sub check_subsys($);
sub check_component($$);
sub check_file($$$);





my $CUR_BUILD;






$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ '<*>', 'subsystems',  'sao', "", "Specific SubSystems" ],
[ 'm' , 'max_missing',  'iso', 20, "Cancel SubSys check after this many missing files" ],
[ 'builds', 'builds', 'sao', '', "(wild-)Builds to Build-Check. '' or '*' == All, '.' == Current" ],
);
GENOPT_set_optdefs( 'gbsbldcheck', \@genopts,
'Check if all files have generated',
undef);
GENOPT_parse();
}
my @ARGS_SUBSYSTEMS = GENOPT_get( 'subsystems');
my $MAX_MISSING = GENOPT_get( 'max_missing');
my @BUILDS = GENOPT_get( 'builds');




VALIDATE_root();
@BUILDS = ('*') if (!@BUILDS);
@BUILDS = VALIDATE_builds( \@BUILDS);
ENV_say( 1, "BUILDS = @BUILDS");

my @SRC_TYPES;
my %BLD_TYPES;
my %BLD_FILES;

my @MISSING_REFS;





foreach my $build (@BUILDS)
{
ENV_say( 1, "BUILD = $build");
$CUR_BUILD = $build;





my @subsystems;
if (@ARGS_SUBSYSTEMS)
{



foreach my $subsys (@ARGS_SUBSYSTEMS)
{
if ($subsys eq '.')
{
$subsys = $GBS::SUBSYS;
ENV_sig( EE => "No current SubSystem")
if ($subsys eq '');
}
ENV_sig( EE => "No such SubSystem: '$subsys")
if (! defined $GBS::ALL_SUBSYSTEMS{$subsys});
ENV_sig( EE => "SubSystem '$subsys' not Full GBS")
if (!GBSGLO_subsystem_is_full_gbs( $subsys));
if (GBSGLO_subsystem_does_build( $subsys, $build))
{
push @subsystems, $subsys;
} else
{
ENV_sig( W => "SubSystem '$subsys' does not generate for Build '$build'");
}
}
} else
{



foreach my $subsys (@GBS::ALL_SUBSYSTEMS)
{
if (GBSGLO_subsystem_is_full_gbs( $subsys))
{
push @subsystems, $subsys;
} else
{
ENV_say( 1, "SubSystem '$subsys' is not Full GBS - Skipped")
}
}
}




@SRC_TYPES = BUILD_get_src_types( $build);
%BLD_TYPES = ();
foreach my $src_type (@SRC_TYPES)
{
$BLD_TYPES{$src_type} = [ BUILD_get_src_items( $build, $src_type, 'OUT_TYPES') ];
$BLD_FILES{$src_type} = [ BUILD_get_src_items( $build, $src_type, 'OUT_FILES') ];
}




ENV_say( 1, "Begin $build");
my $build_checked = 0;
my $missing = 0;
subsystems: foreach my $subsys (@subsystems)
{
if (GBSGLO_subsystem_does_build( $subsys, $build))
{
ENV_say( 1, "  SubSystem: $subsys...");
$missing += check_subsys( $subsys);
$build_checked = 1;
} else
{

}
if ($missing > $MAX_MISSING)
{
ENV_sig( E => "More than $MAX_MISSING missing files in this SubSystem and Build ($build). SubSys Check cancelled!");
last subsystems;
}
}
ENV_say( 1, "$build: Missing: $missing file(s)");
if ($build_checked)
{
push @MISSING_REFS, [$build, $missing ];
} else
{
push @MISSING_REFS, [$build, undef ];
}
}




ENV_say( 1, "Verdict:");
foreach my $ref (@MISSING_REFS)
{
my ($build, $missing) = @{$ref};
ENV_print( 2, "Build: '$build': ");
if (defined $missing)
{
if ($missing > 0)
{
my $at_least = ($missing < $MAX_MISSING) ? '' : 'At least ';
ENV_say( 0, "Failed. $at_least$missing file(s) missing");
$RC = 2;
} else
{
ENV_say( 0, 'OK');
}
} else
{
ENV_say( 0, 'Not Checked');
$RC = 1;
}
}

ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
}




sub check_subsys($)
{
my ($subsys) = @_;
my $missing = 0;

foreach my $component (GBSGLO_components( $subsys))
{
if (GBSGLO_component_does_build( $subsys, $component, $CUR_BUILD))
{
$missing += check_component( $subsys, $component);
} else
{
ENV_say( 1, "    Component '$component' does not generate for build '$CUR_BUILD' - Skipped");
}
}

return $missing;
}




sub check_component($$)
{
my ($subsys,
$component,
) = @_;
my $missing = 0;

my $src_dir = "$GBS::ROOT_PATH/dev/$subsys/comp/$component/src";
ENV_chdir( $src_dir);
foreach my $src_file (glob '*.*')
{
$missing += check_file( $subsys, $component, $src_file);
last if ($missing > $MAX_MISSING);
}

return $missing;
}




sub check_file($$$)
{
my ($subsys,
$component,
$src_file,
) = @_;
my $missing = 0;

my ($name, $src_type) = ENV_split_spec_nt( $src_file);
my $src_spec = "${component}: $src_file";
if (GBSGLO_exclude_specs( $src_file))
{
ENV_say( 1, "    File '$src_spec' excluded");
} elsif (!grep $src_type eq $_, @SRC_TYPES)
{
ENV_sig( W => "Invalid src-type in file '$src_spec'");
} else
{

my $bld_build_path = "$GBS::ROOT_PATH/dev/$subsys/comp/$component/bld/$CUR_BUILD";
my $bld_prefix = "$bld_build_path/$name";




my @out_types = @{$BLD_TYPES{$src_type}};
my $primary_out_type = $out_types[0];
if (-f "$bld_prefix$primary_out_type")
{
foreach my $out_type (@out_types[1..$#out_types])
{

if (!-f "$bld_prefix$out_type")
{
ENV_say( 1, "    $src_spec  => Secondary Bld ($name$out_type) not found ($CUR_BUILD)");
$missing++;
}
}
} else
{
ENV_say( 1, "    $src_spec  => Primary Bld ($primary_out_type) not found ($CUR_BUILD)");
$missing++;
}




foreach my $out_file (@{$BLD_FILES{$src_type}})
{

if (!-f "$bld_build_path/$out_file")
{
ENV_say( 1, "    $CUR_BUILD: '$src_spec'  => Bld File ($out_file) not found");
$missing++;
}
}
}
return $missing;
}


