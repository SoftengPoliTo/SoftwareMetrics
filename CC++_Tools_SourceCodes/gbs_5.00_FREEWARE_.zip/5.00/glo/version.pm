#=================================================
#
#   version.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
#
#   Contrary to what the name suggests, fhis file controls the build.dat file
#   It was originaly called build.pm. The name was too ambiguous and was renamed to version.pm.
#   For the sake of backwards compatibility the name of the file was *not* changed to version.dat
#
#=================================================
package glo::version;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
VERSION_get_version_dir
VERSION_get_version
VERSION_get_version_date
VERSION_get_show_version
VERSION_get_lic
VERSION_version_2_full_version
VERSION_full_version_2_version
VERSION_get_all_versions
VERSION_get_all_file_specs
VERSION_get_full_version
VERSION_file_read
VERSION_file_write
);
}




use glo::env;
use glo::time;
use glo::slurp;
use glo::spit;




sub VERSION_get_version_dir();
sub VERSION_get_version();
sub VERSION_get_version_date();
sub VERSION_get_show_version();
sub VERSION_get_lic();
sub VERSION_version_2_full_version($$);
sub VERSION_full_version_2_version($);
sub VERSION_get_all_versions($);
sub VERSION_get_all_file_specs($);
sub VERSION_get_full_version($);
sub VERSION_file_read($);
sub VERSION_file_write($$$$$$$$);

sub get_version_data();







my $APPLICATION;	# [0] ALL	Do not initialize!	e.g.: GBS
my $VERSION_DIR;	# [1] ALL	Do not initialize!
my $VERSION;		# [2] ALL	Do not initialize!
my $VERSION_DATE;	# [3] ALL	Do not initialize!	DEV: # comment. REL: Actual date
my $APPLICATION_NAME;	# [4] ALL	Do not initialize!	e.g,: Generic Build Support
my @DEV_EXCLUDE_DIRS;	# [5] DEV	Do not initialize!
my @DEV_EXCLUDE_FILES;	# [6] DEV	Do not initialize!
my $LICN;		# [5] REL	Do not initialize!
my $LICS;		# [6] REL	Do not initialize!

my $APP_SCRIPTS_PATH;	# Do not initialize!
my $LICE;		# Do not initialize!
my $LICD;		# Do not initialize!




sub VERSION_get_version_dir()
{
get_version_data()
if (!defined $VERSION_DATE);

return $VERSION_DIR;
}




sub VERSION_get_version()
{
get_version_data()
if (!defined $VERSION_DATE);

return $VERSION;
}




sub VERSION_get_version_date()
{
get_version_data()
if (!defined $VERSION_DATE);

return $VERSION_DATE;
}




sub VERSION_get_show_version()
{
my $show_version;

get_version_data()
if (!defined $VERSION_DATE);

my $parent_dir = ENV_parent_dir( $APP_SCRIPTS_PATH, -1);
if ($parent_dir ne $VERSION || $VERSION_DIR ne $VERSION)
{
$show_version = "$VERSION/$VERSION_DIR/$parent_dir";
} else
{
$show_version = $VERSION;
}
$show_version .= " [ $VERSION_DATE ]";

return $show_version;
}




sub VERSION_get_lic()
{
get_version_data()
if (!defined $VERSION_DATE);

return wantarray ?($LICS, $LICN, $LICE, $LICD) : $LICN;
}




sub get_version_data()
{
$APP_SCRIPTS_PATH = ENV_get_application_scripts_path();



($APPLICATION, $VERSION_DIR, $VERSION, $VERSION_DATE, $APPLICATION_NAME, my @rest) = VERSION_file_read( $APP_SCRIPTS_PATH);





my $app_name = ENV_get_application_name();
ENV_sig( F => "Application_name mismatch: BUILD=$APPLICATION, ENV=$app_name")
if ($APPLICATION ne $app_name);




if (substr( $VERSION_DATE, 0, 1) eq '#')
{



my @now = localtime;
$VERSION_DATE = sprintf( "%4d-%02d-%02d", $now[5] + 1900, $now[4] + 1, $now[3]);
ENV_whisper( 1, "$APPLICATION Development - Version_Date set to $VERSION_DATE");
@DEV_EXCLUDE_DIRS = split( ',', $rest[0]);
@DEV_EXCLUDE_FILES = split( ',', $rest[1]);
($LICN, $LICS) = ('3k37333x3l3837363m3m3byo6k6e6l7xomld6k7o7k7y6y73oml36f6e737y6c7l6k6e637x', '2009-01-01');







} else
{	#


($LICN, $LICS) = @rest;
ENV_sig( EE => "Invalid build.dat. Cannot continue")
if (!defined $LICS);


$LICN = '3m3byl686x73omlc6x636y6e736yom686k73om6o6yoml86k636b6y6lok'
if (length( $LICN) < 10);
}
$LICN=~tr/klmoxy/140295/;$LICN=~s/([a-fA-F0-9][a-fA-F0-9])/chr(hex($1))/eg;
($LICE, $LICN) = split( ';', $LICN);
$LICD = ($LICE - time) / (60 * 60 * 24);
$LICE = TIME_time2numdate( $LICE);

}





sub VERSION_version_2_full_version($$)
{
my ($app_version,			# 2.02
$app_version_date,		# 2008-09-12
) = @_;
my $app_build;			# 202080912

$app_build = $app_version . substr( $app_version_date, 2);
$app_build =~ s/\.//;
$app_build =~ s/-//g;

return $app_build;
}






sub VERSION_full_version_2_version($)
{
my ($app_build) = @_;
my ($app_version, $app_version_date);

if ($app_build)
{
$app_version = substr( $app_build, 0, -8) . '.' . substr( $app_build, -8, 2);

$app_version_date = substr( $app_build, -6, 6);
my (@parts) = $app_version_date =~ /(\d\d)/g;
$app_version_date = '20' . join( '-', @parts);
return (wantarray) ? ($app_version, $app_version_date) : "$app_version [$app_version_date]";
} else
{
return (wantarray) ? ('', '') : '';
}
}





sub VERSION_get_all_versions($)
{
my ($app_scripts_path) = @_;  # ENV_getenv_perl_path( 'GBS_SCRIPTS_PATH');
my @versions;

my @dirs = SLURP_dir_dirs( $app_scripts_path, 0);
@versions = grep( -f "$app_scripts_path/$_/build.dat", @dirs);

return @versions;
}




sub VERSION_get_all_file_specs($)
{
my ($app_scripts_path) = @_;  # ENV_getenv_perl_path( 'GBS_SCRIPTS_PATH');

return ENV_glob( "$app_scripts_path/*.??_20*/build.dat");
}




sub VERSION_get_full_version($)
{
my ($application_root_path,  # get from VERSION_get_all_file_specs
) = @_;

my (undef, undef, $version, $version_date) = VERSION_file_read( $application_root_path);

return VERSION_version_2_full_version( $version, $version_date);
}






sub VERSION_file_read($)
{
my ($application_root_path,
) = @_;


my $in_build_filespec = "$application_root_path/build.dat";

ENV_sig( EE => "'build.dat' does not exist in '$application_root_path'",
'CWD?')
if (!-e $in_build_filespec);

if (wantarray)
{
return (SLURP_file( $in_build_filespec));
} else
{
return $in_build_filespec;
}
}




sub VERSION_file_write($$$$$$$$)
{
my ($build_path,
$application,	    # e.g.: GBS
$version_dir,	    # e.g.: beta
$version,	    # e.g.: 3.00
$version_date,	    # YYYY-MM-DD
$application_name,  # e.g.: Generic Build Support
$licn,		    # encrypted
$lics,		    # YYYY-MM-DD
) = @_;
my $out_build_filespec = "$build_path/build.dat";

chmod( 0755, $out_build_filespec);    # u:rwx go:rx
SPIT_file_nl( $out_build_filespec, [ $application, $version_dir, $version, $version_date, $application_name, ($licn, $lics) ] );
chmod( 0555, $out_build_filespec);    # ugo:rwx

return $out_build_filespec;
}

1;
