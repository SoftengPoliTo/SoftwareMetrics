#=================================================
#
#   tkxmenu.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::tkxmenu;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
TKXMENU_main_add
TKXMENU_popup_add
TKXMENU_popup_post
TKXMENU_enable_item
);
}




use Tkx;

use glo::env;
use glo::tkxmessage;




sub TKXMENU_main_add($@);
sub TKXMENU_popup_add($$@);
sub TKXMENU_popup_post($$$);
sub TKXMENU_enable_item($$$);

sub add_menu($$$);
sub add_entries($$@);
sub not_implemented($);












my %MENU_WIDGETS;





sub TKXMENU_main_add($@)
{
my ($parent,
@menu_refs	# [ $menu_label, ( [ $command_label_or_ref, $entry_ref, $command, @command_args ], ... ), ... ]


) = @_;
my $menu_widget;


Tkx::option_add( "*tearOff", 0);	# disable TearOff

$menu_widget = $parent->new_menu;
$MENU_WIDGETS{menu_bar} = $menu_widget;
$parent->configure( -menu => $menu_widget);

foreach my $menu_ref (@menu_refs)
{
add_menu( $menu_widget, menu_bar => $menu_ref);
}

return $menu_widget;
}




sub TKXMENU_popup_add($$@)
{
my ($parent,
$toplevel_label,
@command_refs	# ( [ $command_label_or_ref, $entry_ref, $command, @command_args ], ... )


) = @_;
my $menu_widget;


$menu_widget = $parent->new_menu( -tearoff => 0);
my $menu_id = $toplevel_label;
$MENU_WIDGETS{$menu_id} = $menu_widget;

add_entries( $menu_widget, $menu_id, @command_refs);


return $menu_widget;
}





sub add_menu($$$)
{
my ($parent,
$parent_name,
$menu_ref,
) = @_;

my ($menu_label, @command_refs) = @{$menu_ref};


my $menu_widget = $parent->new_menu;
my $menu_id = "$parent_name/$menu_label";
$MENU_WIDGETS{$menu_id} = $menu_widget;
$parent->add_cascade( -menu => $menu_widget, -label => $menu_label);

add_entries( $menu_widget, $menu_id, @command_refs);
}





sub add_entries($$@)
{
my ($menu_widget,
$menu_id,
@command_refs,
) = @_;


my $entry_nr = 0;
foreach my $command_items_ref (@command_refs)
{
my ($command_label_or_ref, $entry_ref, $command, @command_args) = @{$command_items_ref};
if (! defined $command_label_or_ref)
{
$menu_widget->add_separator();
} else
{
my $command_label;
my @add_command_args;
if (ref $command_label_or_ref)
{
($command_label, my $accelerator) = @{$command_label_or_ref};
push @add_command_args, -accelerator => $accelerator;
} else
{
$command_label = $command_label_or_ref;
}
if (!defined $command)
{
$menu_widget->add_command( -label => "[ $command_label ]",
-command => [ \&not_implemented, $command_label, @command_args ],
@add_command_args,

);
} elsif (ref $command eq 'ARRAY')
{
add_menu( $menu_widget, $menu_id, $command_items_ref);
} else  # ref $command eq 'CODE')
{
$menu_widget->add_command( -label => $command_label,
-command => [ $command, $command_label, @command_args ],
@add_command_args,
);




if (defined $entry_ref)
{
if (ref $entry_ref eq 'SCALAR')
{
$$entry_ref = [ $menu_id, $command_label, $entry_nr ];
} elsif (ref $entry_ref eq 'ARRAY')
{
push @{$entry_ref}, [ $menu_id, $command_label, $entry_nr ];
} else
{
ENV_sig( F => "Invalid entry_ref for command_label '$command_label'");
}
}
}
}
$entry_nr++;
}
}




sub TKXMENU_popup_post($$$)
{
my ($menu_widget,
$x,
$y,
) = @_;

$menu_widget->post( $x, $y);
}




sub TKXMENU_enable_item($$$)
{
my ($menu_id,
$entry_nr_or_label,
$enable,    # bool. If undef: query only
) = @_;
my $old_state;



my $menu_widget = $MENU_WIDGETS{$menu_id};
if (defined wantarray)
{
$old_state = ($menu_widget->entrycget( $entry_nr_or_label, '-state') eq 'normal') ? 1 : 0;

}
if (defined $enable)
{
my $state = ($enable) ? 'normal' : 'disabled';
$menu_widget->entryconfigure( $entry_nr_or_label, -state => $state);
}

return $old_state;
}




sub not_implemented($)
{
my ($menu_label,
) = @_;

TKXMESSAGE_ok( "GBSGUI - $menu_label", 'error', 'Not implemented yet');
}

1;

