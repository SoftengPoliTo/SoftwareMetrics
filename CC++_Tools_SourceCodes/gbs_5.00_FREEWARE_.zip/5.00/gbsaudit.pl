#=================================================
#
#   gbsaudit.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSAUDIT @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::time;
use glo::genopt;
use mod::gbsenv;
use mod::gbsres;
use mod::gbsoptenv;
use mod::validate;
use mod::swa;
use mod::swb;

use mod::gbsexec;
use mod::gbsbgjob;
use mod::exec;
use mod::cfo;
use mod::gfl;
use mod::sys;
use mod::plugin;






sub do_audit();
sub do_summary();
sub get_datetime();




my $NOW = time();




my $MUST_SHOW_STDOUT = 0;






$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( 'audit');













{
my @genopts = (
[ '<*>',    'comp_file_opts',   'sam',			    '', "src-files and AUDIT-options. ALL = *:*.*" ],
[ 'i',      'ignore_errors',    'bso',			     0, "Continue auditing after error(s)" ],
[ 'stdout', 'show_stdout',	'bso',			     1, "Show errorlines (0 when not interactive)" ],
[ 'vs',     'view_sum',		'bso',			     1, "View summary at completion" ],
[ 'audit',  'audit_name',	"ssos.,$GBS::AUDITS",	   '.', "Audit to run" ],
[ 'build',  'build_name',	"ssos.,$GBS::BUILDS",	   '.', "Build Environment" ],
[ 'aud',    'run_audit', 	'bso',			     1, "Run audit" ],
[ 'sum',    'run_summary',	'bso',			     1, "Create summary" ],
[ 'caller', 'caller',		'ssosgbsaudit,gbssysaudit', 'gbsaudit', 'Internal use.' ],
[ 'jobs',   'jobs',		'isor1..9',		     2, 'Max. nr. parallel jobs' ],
);
my @genenvs = qw( LOG_PATH MODE FLAGS_* APP_* );
GENOPT_set_optdefs( 'gbsaudit', \@genopts,
'Perform an AUDIT on one or more files',
'Summary files are written to $GBS_LOG_PATH. View with gbssilo');
GENOPT_set_envdefs( \&GBSOPTENV_set, \&GBSOPTENV_print, \@genenvs);
GENOPT_parse();
}
my @COMP_FILE_OPTS = GENOPT_get( 'comp_file_opts');
my $IGNORE_ERRORS = GENOPT_get( 'ignore_errors');
my $SHOW_STDOUT = GENOPT_get( 'show_stdout');
my $MUST_VIEW_SUM = GENOPT_get( 'view_sum');		    ## noperlcheck
my $AUDIT_NAME = GENOPT_get( 'audit_name');
my $BUILD_NAME = GENOPT_get( 'build_name');
my $MUST_DO_AUDIT = GENOPT_get( 'run_audit');
my $MUST_DO_SUM = GENOPT_get( 'run_summary');
my $CALLER = GENOPT_get( 'caller');
my $JOBS = GENOPT_get( 'jobs');




ENV_setenv( GBS_IGNORE_ERRORS => $IGNORE_ERRORS);
$MUST_SHOW_STDOUT = (GBSENV_mode_is_interactive() && $SHOW_STDOUT) ? 1 : 0;
ENV_setenv( GBS_AUDIT_OPTIONS => [ $MUST_SHOW_STDOUT ]);











VALIDATE_subsys_full_gbs();	# Also validates: GBS, Root and SubSys








$AUDIT_NAME = VALIDATE_audits( $AUDIT_NAME);
$BUILD_NAME = VALIDATE_builds( $BUILD_NAME);
if (GBSENV_mode_is_interactive())
{



if ($BUILD_NAME ne $GBS::BUILD)
{
SWB_set( $BUILD_NAME, 1);
}

if ($AUDIT_NAME ne $GBS::AUDIT)
{
SWA_set( $AUDIT_NAME, 1);
}

VALIDATE_build();
VALIDATE_audit( $AUDIT_NAME);




SYS_set_envs();
PLUGIN_setup( 'build');
PLUGIN_setup( 'audit');
}

VALIDATE_subsys_audit();
VALIDATE_build();
VALIDATE_audit( $AUDIT_NAME);





{
GBSBGJOB_batch_init( $JOBS);
my $this_rc = do_audit();
GBSBGJOB_batch_finish();
$RC = $this_rc
if ($this_rc > $RC);
if ($CALLER eq 'gbsaudit')		# Audit + Summary
{



if ($MUST_DO_SUM)
{
my $this_rc = do_summary();
$RC = $this_rc
if ($this_rc > $RC);
}
}
}






ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
}




sub do_audit()
{
my $rc = 0;

my $nr_cfo = CFO_parse_audit( \@COMP_FILE_OPTS);
if ($nr_cfo > 0)
{
if ($MUST_DO_AUDIT)
{
ENV_whisper( 1, "Executing 'Audit'...");




$rc = GBSEXEC_audit( $nr_cfo, $IGNORE_ERRORS);
$RC = $rc
if ($rc > $RC);
} else
{
ENV_say( 1, "$GBS::AUDIT: Skipped (--aud-)");
}





my $this_gfl = GFL_new( $GBS::AUDIT, [ get_datetime() ]);
GFL_put_subsys( $this_gfl, $GBS::SUBSYS, undef);
foreach my $order_ref (CFO_get_items())	    # Only the first one is used for audits
{

foreach my $comp_ref (@{$order_ref})
{
my ($component, $files_ref, $opts_ref) = @{$comp_ref};

GFL_put_component( $this_gfl, $component, undef);
GFL_put_files( $this_gfl, $files_ref);
}
}
GFL_write( $this_gfl);
} else
{
ENV_sig( W => "Nothing to do for $GBS::AUDIT");
}
return $rc;
}




sub do_summary()
{
my $rc;

my @gbsauditsum_opts = ( grep( $_ =~ /^--(i|stdout|sum|vs)/, @ARGV));

$rc = EXEC_run( 'gbsauditsum.pl' => [ gbsaudit => @gbsauditsum_opts ]);

return $rc;
}




sub get_datetime()
{
my $audit_datetime_packed;

if (GBSENV_mode_is_background())
{



my $gbs_logfile = ENV_getenv( 'GBS_LOGFILE');
ENV_sig( F => "GBS_LOGFILE not set in background!")
if ($gbs_logfile eq '');
my (undef, undef, undef, $numtime_packed) = GBSRES_split_logfile_spec( $gbs_logfile);
$audit_datetime_packed = $numtime_packed;
} else
{
$audit_datetime_packed = TIME_time2num_packed( $NOW);
}

return $audit_datetime_packed;
}


