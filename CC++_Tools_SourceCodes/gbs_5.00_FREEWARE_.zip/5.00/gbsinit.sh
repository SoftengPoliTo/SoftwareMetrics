#!must_be_sourced
#
#   gbsinit.sh [ --rel=<rel> ] [ --noroot ]
#
GBS_RC=0

#
#	Set GBS_PID
#
\export GBS_PID=$$

#
#	Run gbsinit
#
source $GBS_SCRIPTS_PATH/gbssource.sh gbsinit.pl $*

\set --
\bash -c "exit $GBS_RC" # set $?

## EOF ##
