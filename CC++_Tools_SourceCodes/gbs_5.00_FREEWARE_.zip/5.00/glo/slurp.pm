#=================================================
#
#   slurp.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::slurp;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SLURP_dir_all
SLURP_dir_all_paths
SLURP_dir_dirs
SLURP_dir_dir_paths
SLURP_dir_files
SLURP_dir_file_paths
SLURP_dir_tree
SLURP_dir_tree_path
SLURP_file
SLURP_file_raw
SLURP_file_head
SLURP_file_full
);
}




use glo::env;




sub SLURP_dir_all($$);
sub SLURP_dir_all_paths($$);
sub SLURP_dir_dirs($$);
sub SLURP_dir_dir_paths($$);
sub SLURP_dir_files($$);
sub SLURP_dir_file_paths($$);
sub SLURP_dir_tree($$);
sub SLURP_dir_tree_path($$);
sub SLURP_file($);
sub SLURP_file_raw($);
sub SLURP_file_head($$);
sub SLURP_file_full($$$);

sub read_file_recurse($);








sub SLURP_dir_all($$)
{
my ($dir_path,
$include_dot_files,
) = @_;


return ENV_readdir( $dir_path, $include_dot_files);
}




sub SLURP_dir_all_paths($$)
{
my ($dir_path,
$include_dot_files,
) = @_;


return map( "$dir_path/$_", ENV_readdir( $dir_path, $include_dot_files));
}




sub SLURP_dir_dirs($$)
{
my ($dir_path,
$include_dot_files,
) = @_;


return grep( -d "$dir_path/$_", ENV_readdir( $dir_path, $include_dot_files));
}




sub SLURP_dir_dir_paths($$)
{
my ($dir_path,
$include_dot_files,
) = @_;


return map( "$dir_path/$_", grep( -d "$dir_path/$_", ENV_readdir( $dir_path, $include_dot_files)));
}




sub SLURP_dir_files($$)
{
my ($dir_path,
$include_dot_files,
) = @_;


return grep( -f "$dir_path/$_", ENV_readdir( $dir_path, $include_dot_files));
}




sub SLURP_dir_file_paths($$)
{
my ($dir_path,
$include_dot_files,
) = @_;


return map( "$dir_path/$_", grep( -f "$dir_path/$_", ENV_readdir( $dir_path, $include_dot_files)));
}







sub SLURP_dir_tree($$)
{
my ($dir_path,
$include_dot_files,
) = @_;
my @all_anyfile_refs;

foreach my $dir_entry (SLURP_dir_all( $dir_path, $include_dot_files))
{
my $full_spec = "$dir_path/$dir_entry";
if (-d $full_spec)
{
push @all_anyfile_refs, [ 1, $dir_entry ];
push @all_anyfile_refs, map { [ $_->[0], "$dir_entry/$_->[1]" ] } SLURP_dir_tree( $full_spec, $include_dot_files);
} else
{
push @all_anyfile_refs, [ 0, $dir_entry ];
}
}

return @all_anyfile_refs;
}







sub SLURP_dir_tree_path($$)
{
my ($dir_path,
$include_dot_files,
) = @_;
my @all_anyfile_refs;

foreach my $item (SLURP_dir_all( $dir_path, $include_dot_files))
{
my $spec = "$dir_path/$item";
if (-d $spec)
{
push @all_anyfile_refs, [ 1, $spec ];
push @all_anyfile_refs, SLURP_dir_tree_path( $spec, $include_dot_files);
} elsif (-f _)
{
push @all_anyfile_refs, [ 0, $spec ];
}
}


return @all_anyfile_refs;
}





sub SLURP_file($)
{
my ($filespec,
) = @_;


if (wantarray)
{
my @lines = ENV_slurp_file( $filespec, 'F');
map s/\s+$//, @lines;		  #remove trailing whitespace

return @lines;
} else
{
return ENV_slurp_file( $filespec, 'F');
}
}






sub SLURP_file_raw($)
{
my ($filespec,
) = @_;


if (wantarray)
{
return ENV_slurp_file( $filespec, 'F');
} else
{
ENV_sig( F => "Cannot call 'SLURP_file_raw' in scalar context");
}
}





sub SLURP_file_head($$)
{
my ($filespec,
$max_lines,	# 0 == whole file!
) = @_;


if (wantarray)
{
my @lines = ENV_slurp_file( $filespec, 'F', '<', $max_lines);
map s/\s+$//, @lines;		  #remove trailing whitespace

return @lines;
} else
{
return ENV_slurp_file( $filespec, 'F', '<', $max_lines);
}
}

my $COMMENT_RE;
my $INCLUDE_RE;
my %DUP_INCLUDE_SPECS;







sub SLURP_file_full($$$)
{
my ($filespec,
$comment_re,	# E.g.: /^#/
$include_re,	# May be undef. E.g.: /^#\s*include\s+([<"]?)(.+)[>"]?/
) = @_;
my @lines;

$COMMENT_RE = $comment_re;
$INCLUDE_RE = $include_re;
@lines = read_file_recurse( $filespec);
%DUP_INCLUDE_SPECS = ();

return @lines;
}




sub read_file_recurse($)
{
my ($filespec) = @_;
my @lines;

foreach my $line (SLURP_file( $filespec))
{
next if ($line eq '' || $line =~ $COMMENT_RE);

if (defined $INCLUDE_RE && $line =~ $INCLUDE_RE)
{

my $include_file_raw = $1;
my $include_file = ENV_expand_envs( $include_file_raw);
my $include_filespec = ENV_perl_canon_paths( $include_file);
if (-e $include_file)
{

if (! exists $DUP_INCLUDE_SPECS{$include_filespec})
{
$DUP_INCLUDE_SPECS{$include_filespec} = 1;
push @lines, read_file_recurse( $include_filespec);	    # recurse
} else
{
my @error_lines = ("Circular inclusion of: '$include_filespec'");
push @error_lines, "- Original line: '$line'",
"- Called from: '$filespec'";
ENV_sig( EE => @error_lines);
}
} else
{
my @error_lines = ("No such include file: '$include_filespec'");
my $dir_path = ENV_split_spec_p( $include_filespec);
push @error_lines, "- Directory ($dir_path) does not exist"
if (!-e $dir_path);
push @error_lines, "- Original line: '$line'",
"- Called from: '$filespec'";
ENV_sig( EE => @error_lines);
}
} else
{
push @lines, $line;
}
}

return @lines;
}

1;
