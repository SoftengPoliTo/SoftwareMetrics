#=================================================
#
#   gbsfilecom.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbsfilecom;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSFILECOM_validate_path

GBSFILECOM_expand_command_data_refs
GBSFILECOM_exec
);
}




use glo::env;
use glo::list;
use glo::format;
use mod::gbsenv;
use mod::gbsfile;




sub GBSFILECOM_validate_path($);

sub GBSFILECOM_expand_command_data_refs($$$);
sub GBSFILECOM_exec($$);

sub prepare_command($);
sub handle_ok_values($$);








my $IS_WIN32 = ENV_is_win32();
my $MUST_PRINT_COMMANDS;




INIT
{

$MUST_PRINT_COMMANDS = ( ENV_set_verbose() || ! GBSENV_mode_is_interactive() ) ? 1 : 0;

}




my %LIST_ENVVARS = (
GBS_INCS		=> 1,
GBS_SYSINCS		=> 1,
GBS_FLAGS		=> 1,
GBS_SYSFLAGS	=> 1,
GBS_GLKB		=> 1,
GBS_AUDIT_FLAGS	=> 1,
);




sub GBSFILECOM_validate_path($)
{
my ($path) = @_;
my $full_path;

if (ENV_is_abs_path( $path))
{
my $abs_path_not_allowed = 1;
if (!$IS_WIN32)	# IS_LINUX
{
$abs_path_not_allowed = 0
if (substr( $path, 0, 5) eq '/usr/' ||
$path eq '/lib');
}
GBSFILE_sig( E => "Absolute path not allowed, use EnvVar from switch.gbs")
if ($abs_path_not_allowed);
}

$full_path = ENV_perl_paths_noquotes( ENV_expand_envs( $path));
GBSFILE_sig( E => "No such directory:", "'$full_path'")
if (!-d $full_path);				    # && substr( $full_path, 0, 5) ne '/usr/');
GBSFILE_sig( E => "Must be derrived Abs Path:", "'$full_path'")
if (!ENV_is_abs_path_perl( $full_path));


return $full_path;
}














sub GBSFILECOM_expand_command_data_refs($$$)
{
my ($command_data_refs_ref,

$pos_args_ref,	    # Build:  [ $file_name, $in_filespec, $out_filespec, $out_file_dir, $out_filetype ]



$gen_args_ref,	    # Flags from OPTIONS + @command_line_flags
) = @_;
my @command_data_refs;




my @pos_args = ENV_os_paths( ENV_deref( $pos_args_ref));
my @gen_args = ENV_deref( $gen_args_ref);


foreach my $command_data_ref (@{$command_data_refs_ref})
{
my ($command_type, $command_items_ref, $ok_values, $exec_condition, $pos_arg_tokens) = @{$command_data_ref};


my @command_items = @{$command_items_ref};
if ($pos_arg_tokens ne '0')
{
my $pos_par_token = substr( $pos_arg_tokens, 1);	    # % or $




{
my $gen_par_token = "$pos_par_token*";		    # %* or $*
my $index = LIST_firstidx_str( $gen_par_token, \@command_items);
if ($index >= 0)
{

splice( @command_items, $index, 1, @gen_args);
}
}




$pos_par_token = '\$'
if ($pos_par_token eq '$');
for (my $i = 1; $i <= @pos_args; $i++)
{
foreach my $command_item (@command_items)
{
$command_item =~ s/$pos_par_token$i/$pos_args[$i-1]/g;
}
$exec_condition =~ s/$pos_par_token$i/$pos_args[$i-1]/g;
}
} else
{
if ($command_type ne 'B')	    # direct builtin (e.g. echo)
{
push @command_items, @pos_args, @gen_args;
}
}

push @command_data_refs, [ $command_type, [ @command_items ], $ok_values, $exec_condition, $pos_arg_tokens ];
}

return @command_data_refs;
}




sub GBSFILECOM_exec($$)
{
my ($must_print_commands,	    # scripts should print their own command(s). '-' == undef
$command_data_refs_ref,	    # [ [ $command_type, $command_items_ref, $ok_values, $exec_condition, $pos_arg_tokens ], ... ]

) = @_;
my $rc = 0;



my $nr_commands = @{$command_data_refs_ref};
my $count = 0;
foreach my $ref (@{$command_data_refs_ref})
{


$count++;
ENV_whisper( 0, '.')
if ($count != 1);
my ($command_type, $command_items_ref, $ok_values, $exec_condition) = @{$ref};





my $must_exec = 1;
if ($exec_condition ne '-')
{
my $type = substr( $exec_condition, 0, 1);	# F or V
my $cond = substr( $exec_condition, 1, 1);	# 0 or 1
if ($type eq 'F')
{
my $filespec = substr( $exec_condition, 2);
$filespec = ENV_expand_envs( ENV_dequote( $filespec));
my $exists = (-e $filespec) ? 1 : 0;

$must_exec = ($cond == $exists);
$exec_condition = "File exists ($filespec != $cond)";
} elsif ($type eq 'V')
{
my ($name, $value) = split( '=', substr( $exec_condition, 2), 2);
my $actual_value = ENV_getenv( $name);
$actual_value = ENV_expand_envs( $actual_value);
my $equal = ($actual_value eq $value) ? 1 : 0;

$must_exec = ($cond == $equal);
$exec_condition = "EnvVar ($name==$value) != $cond";
} else
{
ENV_sig( F => "Invalid exec_condition type ($type)");
}
}
if ($must_exec)
{



my @command_items = @{$command_items_ref};
if ($command_type eq 'B')	# direct builtin (e.g. echo)
{



if ($command_items[0] eq 'ECHO')
{

my $value = ENV_expand_envs( $command_items[1]);
ENV_say( 0, $value);
} elsif ($command_items[0] eq 'SET')
{

my $value = ENV_expand_envs( $command_items[2]);
ENV_setenv( $command_items[1] => $value);
} else
{
ENV_sig( F => 'Invalid Special Command',
"@command_items");
}
} elsif ($command_type eq 'D' || $command_type eq 'S')  # direct or script
{



my $full_command = prepare_command( \@command_items);

my $say_command_line = ($nr_commands == 1) ? $full_command : "$count:$full_command";
my $rc_ok;

if ($MUST_PRINT_COMMANDS)
{
if ($must_print_commands eq '1' || ($must_print_commands eq '-' && $command_type eq 'D'))
{
ENV_say( 0, FORMAT_hanging( 0, 0, 2, $say_command_line));
}
$rc = ENV_system( $full_command, undef);





$rc_ok = handle_ok_values( $rc, $ok_values);
} else
{
($rc, my $stdouterr) = ENV_backtick( $full_command, undef, 1);   # include stderr





$rc_ok = handle_ok_values( $rc, $ok_values);
if (!$rc_ok)
{
if ($must_print_commands eq '1' || ($must_print_commands eq '-' && $command_type eq 'D'))
{
ENV_say( 0, FORMAT_hanging( 0, 0, 2, $say_command_line));
}
}
ENV_print( 0, $stdouterr);
}

if ($rc_ok)
{
$rc = 0;
} else
{
last;
}
} else
{
ENV_sig( F => "Invalid command_type '$command_type'");
}
} else
{
my $text = "Skipped because of pre-condition: $exec_condition";
if ($nr_commands == 1)
{
ENV_say( 0, $text);
} else
{
ENV_say( 0, "$count:$text");
}
}
}

return $rc;
}




sub prepare_command($)
{
my ($command_items_ref,
) = @_;
my @full_command_items;

@full_command_items = ENV_prepare_command( $command_items_ref);

my @envvar_re = ( '\$\w+', '\$\{[^\}]+\}' );	# $word and ${word}	(Windows & Linux)
unshift @envvar_re, '\%\w+\%'			# %word%		(Windows)
if ($IS_WIN32);
my $envvar_re = join( '|', @envvar_re);


foreach my $item (@full_command_items)
{

$item = ENV_enquote( ENV_glob( $item))		    # #  ~/ or ~username/	(Linux)
if (substr( $item, 0, 1) eq '~');
my @full_envvars = $item =~ /$envvar_re/g;

my $gbs_list_variable_count = 0;
foreach my $full_envvar (@full_envvars)
{



my ($envvar_name) = $full_envvar =~ /(\w+)/;

my $envvar_value = $ENV{$envvar_name};
if (defined $envvar_value)
{

my $full_envvar_qm = quotemeta $full_envvar;
$item =~ s/$full_envvar_qm/$envvar_value/;
$gbs_list_variable_count++
if (exists $LIST_ENVVARS{$envvar_name});
}
}
$item = ENV_enquote( $item)
if ($gbs_list_variable_count == 0);

$item =~ s/"\s*"//;				# Remove empty strings


}

return (wantarray) ? @full_command_items :  "@full_command_items";
}




sub handle_ok_values($$)
{
my ($rc,
$ok_values,	# space-separated ok_values (string)
) = @_;
my $rc_ok;



if ($ok_values eq '0')
{
$rc_ok = ($rc == 0)
} else
{
my @ok_values = split( ' ', $ok_values);
$rc_ok = grep( $_ == $rc, @ok_values);
}

return $rc_ok;
}

1;


