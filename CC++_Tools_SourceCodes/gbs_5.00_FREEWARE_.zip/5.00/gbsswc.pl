#=================================================
#
#   gbsswc.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSSWC @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::shell;
use glo::ask;
use glo::genopt;
use mod::gbsenv;
use mod::gbscmd;
use mod::gbsask;
use mod::run;
use mod::validate;
use mod::swglo;
use mod::swset;








my $CWD = ENV_cwd();

my $CANCELLED = 0;






$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ '<1>',	'component',		'sso',	'', "Component: '' == ASK, '-' == none, '.' == current" ],
[ 'build',	'build',		'sso',	'', "Build: '-' == none, '.' == current" ],
[ 'audit',	'audit',	        'sso',  '', "Audit. '-' == none, '.' == current" ],
[ 'new',	'create_new_component', 'bso',	 0, "Create a new Component" ],
[ 'nocd',	'no_cd',		'bso',   0, "Do not 'cd' to the selected directories "],
);
my @genconflicts = (
[ [ new => 1],	    '=', '<1>', '=', 'build' ],
[ [ '<1>' => '' ],  '=', 'build', '=', 'audit' ],
);
GENOPT_set_optdefs( [ 'gbsswc', 'swc' ], \@genopts,
'Set and/or Create new Current Component',
undef);
GENOPT_set_conflicts( \@genconflicts);
GENOPT_parse();
}
my $COMPONENT = GENOPT_get( 'component');
my $BUILD = GENOPT_get( 'build');
my $AUDIT = GENOPT_get( 'audit');
my $NEW = GENOPT_get( 'create_new_component');
my $NO_CD = GENOPT_get( 'no_cd');




VALIDATE_subsys_full_gbs();




if (!$NEW && @GBS::ALL_COMPONENTS == 0)
{
if (ASK_YN( "No Component(s) defined for this SubSystem. Create now?", 'Y') eq 'Y')
{
$NEW = 1;
}
}




if ($NEW)
{
$COMPONENT = RUN_gbsnew( 'new_component', $COMPONENT);
if ($COMPONENT eq '')
{
$COMPONENT = '.';
$CANCELLED = 1;
} else
{
ENV_say( 1, "Current Component is $COMPONENT");
}
}

if (!$CANCELLED)
{



if ($COMPONENT eq '')
{
$COMPONENT = GBSASK_component( $GBS::SUBSYS);
$COMPONENT = ''
if ($COMPONENT eq '');
}

SWSET_component( $COMPONENT, $BUILD, $AUDIT);    # Also sets $GBS::component, build & audit








{
my $new_cwd = ($NO_CD) ? $CWD : SWGLO_new_cwd( $GBS::ROOT_PATH, $GBS::SUBSYS, $GBS::COMPONENT);

my @lines;
if (ENV_get_changed_envs() || $new_cwd ne $CWD)
{



push @lines, GBSENV_changed_setenv_commands( 0);




push @lines, SWGLO_set_title( $GBS::ROOT_PATH, $GBS::SUBSYS, $GBS::COMPONENT);




push @lines, SHELL_cd( $new_cwd);
}

push @lines, GBSCMD_get_full_gbs_command( gbsshow => '--brief');

GBSENV_write_result_script( \@lines, 0);
}
}

ENV_exit( $RC);




END
{
ENV_print_end_msg( 0);
}


