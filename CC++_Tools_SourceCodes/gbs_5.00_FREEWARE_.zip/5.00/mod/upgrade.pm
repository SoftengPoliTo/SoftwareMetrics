#=================================================
#
#   upgrade.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::upgrade;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
UPGRADE_main
);
}




use glo::env;
use glo::ask;
use glo::scm;
use glo::file;
use glo::slurp;
use mod::gbsenv;
use mod::system;
use mod::gbsscm;
use mod::gbsglo;
use mod::fix;
use mod::scmsmaint;
use mod::gbsrc;
use mod::build;




sub UPGRADE_main($$$);

sub upgrade_400_401();
sub upgrade_401_500();
sub update_system_root_version();





my @UPGRADE_REFS = (
[ qw( 2.00 3.00) ],
[ qw( 3.00 3.01) ],
[ qw( 3.01 4.00) ],


);




sub UPGRADE_main($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref
) = @_;



ENV_say( 1, "This ROOT   version is $GBS::ROOT_VERSION",	    # e.g: 4.01
"Current GBS version is $GBS::VERSION");	    # e.g: 5:00
if ($GBS::ROOT_VERSION lt '2.00')  # format: "R.VV"
{
ENV_sig( E => "Root Version $GBS::ROOT_VERSION way too old. Cannot upgrade.",
'You will have to create a new Root/System and fill it with data from this Root/System');
} else
{
my $must_use_older_gbs = 0;
foreach my $ref (@UPGRADE_REFS)
{
my ($first_version, $last_version) = @{$ref};
if ($GBS::ROOT_VERSION lt $last_version)
{
ENV_say( 1, "Must upgrade $first_version to $last_version using GBS $last_version first",
'You can temporarily switch to another version of GBS by starting a new GBS Window',
"or 'gbsexit' the current and then start the wanted version of GBS with the command",
"'gbs --rel=<version>' or 'gbs --rel=?'",
"Add '--noroot' to prevent gbs switching to a root");
$must_use_older_gbs = 1;
}
}

my $ans;
if ($must_use_older_gbs)
{
ENV_sig( EE => "Root Version $GBS::ROOT_VERSION is too old, use previous version of GBS to upgrade");
} else
{
if ($GBS::VERSION gt $GBS::ROOT_VERSION)
{
ENV_say( 1, "Version mismatch.",
"Please read the release notes for any actions to be performed.",
"You may wish to exit this function in order to fix things first.",
"If you proceed with the Upgrade, this function will:",
"- Make the changes in the directory/file structure",
"- Check and repair the GBS system file(s)",
"- Check and repair the directory structure (as a final check)",
"- Set the ROOT-version to the current GBS version.",
"Make sure you have an UNMODIFIED work-area.",
"Immediately execute 'swr .' after the upgrade!",
"Immediately Checkin/Commit/Consolidate the work-area after the upgrade!");
$ans = ASK_YN( 'Upgrade?', 'Y');
} elsif ($GBS::VERSION eq $GBS::ROOT_VERSION)
{
ENV_say( 1, "Root-Version is Up-to-date");
$ans = ASK_YN( 'Force last Upgrade again?', 'N');
} else
{
ENV_sig( EE => "This GBS version is too old for this Root version");
}
}

if ($ans eq 'Y')
{
GBSSCM_preset( 0);
GBSSCM_connect();




upgrade_400_401()
if ($GBS::ROOT_VERSION eq '4.00');
upgrade_401_500();




my $ok = FIX_structure();




if ($GBS::VERSION ne $GBS::ROOT_VERSION)
{
if ($ok)
{
if (ASK_YN( 'Set ROOT-version?', 'Y') eq 'Y')
{
update_system_root_version();
}
} else
{
ENV_sig( W => 'Cannot update Root-Version: Missing/Incomplete files/directories');
}
}
ENV_say( 1, "*** You MUST run 'swr .' before continuing with other GBS commands! ***");
}
}

return;
}




sub upgrade_400_401()
{
ENV_say( 1, "Upgrading 4.00 to 4.01...");




ENV_say( 2, 'Relocating SubSystem .gbsrc...');

foreach my $subsys (@GBS::ALL_SUBSYSTEMS)
{

my $old_filespec = "$GBS::ROOT_PATH/dev/$subsys/comp/.gbsrc";
if (-e $old_filespec)
{
if (-e $old_filespec)
{
my $filespec = "$GBS::ROOT_PATH/dev/$subsys/.gbsrc";
if (-e $filespec)
{
unlink $old_filespec;

} else
{
rename $old_filespec, $filespec;

}
}
}
}
}




sub upgrade_401_500()
{
ENV_say( 1, "Upgrading 4.01 to 5.00...");




ENV_say( 2, 'Fixing ignore(s) of .gbsrc...');

foreach my $subsys (@GBS::ALL_SUBSYSTEMS)
{




my $subsys_dirspec = "$GBS::ROOT_PATH/dev/$subsys";
my $comp_dirspec = "$GBS::ROOT_PATH/dev/$subsys/comp";
my @paths = grep( -d $_, ( $subsys_dirspec, $comp_dirspec ));
SCMSMAINT_fix_ignore( \@paths, 0)
if (@paths);
}




ENV_say( 2, '.gbsrc...');
GBSRC_write_root();
foreach my $subsys (@GBS::ALL_SUBSYSTEMS)
{
GBSRC_write_subsys( $subsys);
}




ENV_say( 2, 'system.gbs...');
ENV_say( 3, 'Updated')
if (SYSTEM_fix( $GBS::ROOT_PATH));




ENV_say( 2, 'Renaming systools and tools directories...');
{
if (-e "$GBS::ROOT_PATH/systools" && ! -e "$GBS::ROOT_PATH/systool")
{
ENV_say( 3, "SCM Move $GBS::ROOT_PATH/systools");
SCM_move( [ "$GBS::ROOT_PATH/systools", "$GBS::ROOT_PATH/systool" ], 0, 0);  # 0 == pre_validated, 0 == verbose_level
}
foreach my $subsys (@GBS::ALL_SUBSYSTEMS)
{
my $path = "$GBS::ROOT_PATH/dev/$subsys";
if (-e "$path/tools")
{
ENV_say( 3, "SCM Move $path/tools");
SCM_move( [ "$path/tools", "$path/tool" ], 0, 0);  # 0 == pre_validated, 0 == verbose_level
}
}
}




ENV_say( 2, 'Moving GBS export.gbs/.usr files...');
foreach my $subsys (GBSGLO_subsystems_full_gbs())
{
my $from_path = "$GBS::ROOT_PATH/dev/$subsys/build";
my $to_path   = "$GBS::ROOT_PATH/dev/$subsys";
if (-e "$from_path/export.gbs")
{
ENV_say( 3, "SCM Move $subsys export.gbs");
SCM_move( [ "$from_path/export.gbs", "$to_path/export.gbs" ], 0, 0);  # 0 == pre_validated, 0 == verbose_level
}
if (-e "$from_path/export.usr")
{
ENV_say( 3, "Move $subsys export.usr");
ENV_rename( "$from_path/export.usr", "$to_path/export.usr");
}
}




ENV_say( 2, 'Renaming target.gbs to build.gbs...');
foreach my $target_spec (ENV_glob( "$GBS::SYSBUILD_PATH/*/target.*"))
{
my ($path, undef, $type) = ENV_split_spec_pnt( $target_spec);
if ($type eq '.gbs' || $type eq '.usr')
{
my $build_spec = "$path/build$type";
ENV_say( 3, "Rename $target_spec => build$type");
if ($type eq '.gbs')
{
SCM_move( [ $target_spec, $build_spec ], 0, 0);  # 0 == pre_validated, 0 == verbose_level
} else  # $type eq '.usr'
{
ENV_rename( $target_spec, $build_spec);
}
}
}




ENV_say( 2, 'Updating build.gbs files...');
foreach my $build_spec (ENV_glob( "$GBS::SYSBUILD_PATH/*/build.*"))
{
my ($path, undef, $type) = ENV_split_spec_pnt( $build_spec);
if ($type eq '.gbs' || $type eq '.usr')
{
ENV_say( 3, "Update $build_spec");
my $lines = SLURP_file( $build_spec);
my $changed = 0;
$changed += $lines =~ s/target\./build\./msg;
$changed += $lines =~ s/TARGET\./BUILD\./msg;
if ($changed)
{
my @lines = split( "\n", $lines);
SCM_store_file( $build_spec, \@lines);
ENV_say( 4, "...modified ($changed)");
}
}
}





ENV_say( 2, 'Collecting files...');
my %glkb_types;
foreach my $build (@GBS::ALL_BUILDS)
{
foreach my $src_type (BUILD_get_src_types( $build))
{
my ($type) = BUILD_get_src_items( $build, $src_type, 'TYPE');
$glkb_types{$src_type} = 1
if (BUILD_is_glkb_type( $type));
}
}
my @glkb_types = map { substr( $_, 1) } keys %glkb_types;
my $file_types = join( '|', qw( gbs usr bat sh mk), @glkb_types);
my @file_specs = FILE_find( $GBS::ROOT_PATH, "\\.($file_types)\$", undef, 1);


ENV_say( 3, 'Processing files...');
foreach my $filespec (@file_specs)
{
next
if ($filespec =~ /\/(hist|base|last)_.*?\.gbs$/ ||
$filespec =~ /\/ssprop.gbs$/);

my $lines = SLURP_file( $filespec);
if ($lines =~ /(target|CASE_GEN)/i)
{
ENV_say( 3, $filespec);
my $changed = 0;
$changed += $lines =~ s/\bGBS_TARGET/GBS_BUILD/msg;
if ($filespec !~ /\.mk$/)
{
$changed += $lines =~ s/\btarget/build/msg;
$changed += $lines =~ s/\bTarget/Build/msg;
$changed += $lines =~ s/\bTARGET/BUILD/msg;
}
if ($filespec =~ /gbssub\.(bat|sh)$/)
{
$changed += $lines =~ s/\bgen\b/build/msg;
$changed += $lines =~ s/\bCASE_GEN\b/CASE_BUILD/msg;
$changed += $lines =~ s/\bGEN\b/BUILD/msg;
}
if ($changed)
{
my @lines = split( "\n", $lines);
SCM_store_file( $filespec, \@lines);
ENV_say( 4, "...modified ($changed)");
}
}
}




ENV_say( 2, 'Relocating templates directory...');
if (-d "$GBS::SYSBUILD_PATH/templates" && !-d "$GBS::SYS_PATH/templates")
{
ENV_say( 3, "SCM Move 'SYSBUILD/templates' to 'SYS/templates'...");
SCM_move( [ "$GBS::SYSBUILD_PATH/templates", "$GBS::SYS_PATH/templates" ], 0, 0);  # 0 == pre_validated, 0 == verbose_level
}




ENV_say( 2, 'bld_incs_*.gbs to sysincs_*.gbs...');
foreach my $from_spec (ENV_glob( "$GBS::SYSBUILD_PATH/*/bld_incs_*.*"))
{
my ($path, $from_file, $type) = ENV_split_spec_pnt( $from_spec);
if ($type eq '.gbs' || $type eq '.usr')
{
my $to_file = $from_file;
$to_file =~ s/bld_incs/sysincs/;
my $to_spec = "$path/$to_file$type";
ENV_say( 3, "Rename $from_spec => $to_file$type");
if ($type eq '.gbs')
{
SCM_move( [ $from_spec, $to_spec ], 0, 0);  # 0 == pre_validated, 0 == verbose_level
} else  # $type eq '.usr'
{
ENV_rename( $from_spec, $to_spec);
}
}
}




ENV_say( 2, 'bld_flags_*.gbs to sysflags_*.gbs...');
foreach my $from_spec (ENV_glob( "$GBS::SYSBUILD_PATH/*/bld_flags_*.*"))
{
my ($path, $from_file, $type) = ENV_split_spec_pnt( $from_spec);
if ($type eq '.gbs' || $type eq '.usr')
{
my $to_file = $from_file;
$to_file =~ s/bld_flags/sysflags/;
my $to_spec = "$path/$to_file$type";
ENV_say( 3, "Rename $from_spec => $to_file$type");
if ($type eq '.gbs')
{
SCM_move( [ $from_spec, $to_spec ], 0, 0);  # 0 == pre_validated, 0 == verbose_level
} else  # $type eq '.usr'
{
ENV_rename( $from_spec, $to_spec);
}
}
}

}




sub update_system_root_version()
{
ENV_say( 1, "Updating ROOT version to $GBS::VERSION...");
SYSTEM_put( $GBS::ROOT_PATH, root_version => $GBS::VERSION);
SYSTEM_write();    # Includes backup and SCM_checkout
GBSENV_setenv( GBS_ROOT_VERSION => $GBS::VERSION, 1);
}

1;
