#=================================================
#
#   os_linux.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
#   Documentation:
#=================================================
package glo::os_linux;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
OS_beep
OS_get_terminal_size
OS_get_os_name
OS_get_hostname
OS_get_uname
OS_get_userid
OS_get_cwd
OS_long_path_name
OS_copy_file
OS_hide_file
OS_get_desktop_path
OS_get_startmenu_path
OS_get_programs_path
OS_get_user_path
OS_is_administrator
);
}




use glo::env;




sub OS_beep();
sub OS_get_terminal_size();
sub OS_get_os_name();
sub OS_get_hostname();
sub OS_get_uname();
sub OS_get_userid();
sub OS_get_cwd();
sub OS_long_path_name($);
sub OS_copy_file($$);
sub OS_hide_file($$);
sub OS_get_desktop_path($);
sub OS_get_startmenu_path($);
sub OS_get_programs_path($);
sub OS_get_user_path($);
sub OS_is_administrator();








my ($USER_HOME) = glob( '~');




my $OS_NAME;
my $HOSTNAME;
my ($UNAME_OS, $UNAME_HOST, @UNAME_REST);
my $USERID;

my   $USER_DESKTOP_PATH;
my $SYSTEM_DESKTOP_PATH;
my   $USER_STARTMENU_PATH;
my $SYSTEM_STARTMENU_PATH;
my   $USER_PROGRAMS_PATH;
my $SYSTEM_PROGRAMS_PATH;
my   $USER_USER_PATH;
my $SYSTEM_USER_PATH;






sub OS_beep()
{
my $result;

return $result;
}




sub OS_get_terminal_size()
{
my ($width, $height);

($height, $width) = split( / /, qx(stty size));

return (wantarray) ? ($width, $height) : $width;
}









sub OS_get_os_name()
{
if (! defined $OS_NAME)
{
$OS_NAME = 'Linux';			# TBS needs more work...
}

return $OS_NAME;
}




sub OS_get_hostname()
{
if (! defined $HOSTNAME)
{
chomp( $HOSTNAME = `hostname 2> /dev/null`);
$HOSTNAME = $^O
if (!$HOSTNAME);
}

return $HOSTNAME;
}





sub OS_get_uname()
{
if (!defined $UNAME_OS)
{
my $text = `uname -a`;
chomp $text;
($UNAME_OS, $UNAME_HOST, @UNAME_REST) = split( ' ', $text);
}


return ($UNAME_OS, $UNAME_HOST, @UNAME_REST);
}





sub OS_get_userid()
{
if (!defined $USERID)
{
$USERID = getpwuid($>);
}

return $USERID;
}




sub OS_get_cwd()
{
my $pwd;

$pwd = `pwd`;
chomp $pwd;

return $pwd;
}






sub OS_long_path_name($)
{
my ($path,
) = @_;


return $path;
}




sub OS_copy_file($$)
{
my ($in_file,
$out_file,
) = @_;
my ($rc, $command, $fail_reason);




chmod oct(777), $out_file;				    # -f does not seem to work always on shared folders
$command = "\\cp -p -f \"$in_file\" \"$out_file\"";	    # -p = preserve, -f = force
$rc = system( $command) >> 8;

$fail_reason = $!
if ($rc != 0);

return ($rc, $command, $fail_reason);
}




sub OS_hide_file($$)
{
my ($filespec,
$must_hide,    # 0 = unhide, 1 = hide, undef = test-only
) = @_;
my $old_state;



if (defined $must_hide)
{
$old_state = $must_hide;
} else
{
$old_state = ( $filespec =~  m!(/|^)\.[^/]+$! ) ? 1 : 0;
}

return $old_state;
}




sub OS_get_desktop_path($)
{
my ($system_item) = @_;

if ($system_item)
{
if (!defined $SYSTEM_DESKTOP_PATH)
{
$SYSTEM_DESKTOP_PATH = undef;	    # TBS
}
return $SYSTEM_DESKTOP_PATH;
} else
{
if (!defined $USER_DESKTOP_PATH)
{
$USER_DESKTOP_PATH = $ENV{XDG_DESKTOP_DIR};	# defined by calling $(XDG_CONFIG_HOME)/user-dirs.dirs
($USER_DESKTOP_PATH) = glob( '~/Desktop')	# in .gbs/startup.sh
if (!defined $USER_DESKTOP_PATH);	# http://www.freedesktop.org/wiki/Software/xdg-user-dirs/

}
return $USER_DESKTOP_PATH;
}
}




sub OS_get_startmenu_path($)
{
my ($system_item) = @_;

if ($system_item)
{
if (!defined $SYSTEM_STARTMENU_PATH)
{
$SYSTEM_STARTMENU_PATH = '/usr/share/applications';
}
return $SYSTEM_STARTMENU_PATH;
} else
{
if (!defined $USER_STARTMENU_PATH)
{
foreach my $path ( '~/Programs', '~/.local/share/applications')
{
my ($this_path) = glob( $path);
if (-d $this_path)
{
$USER_STARTMENU_PATH = $this_path;
last;
}
}
if (!defined $USER_STARTMENU_PATH)
{
$USER_STARTMENU_PATH = '~/.local/share/applications';
ENV_mkdir( $USER_STARTMENU_PATH, undef, 'F');
}
}
return $USER_STARTMENU_PATH;
}
}






sub OS_get_programs_path($)
{
my ($system_item) = @_;

if ($system_item)
{
if (!defined $SYSTEM_PROGRAMS_PATH)
{
$SYSTEM_PROGRAMS_PATH = '/usr/local/bin';
}
return $SYSTEM_PROGRAMS_PATH;
} else
{
if (!defined $USER_PROGRAMS_PATH)
{
$USER_PROGRAMS_PATH = glob( '~/bin');
}
return $USER_PROGRAMS_PATH;
}
}






sub OS_get_user_path($)
{
my ($system_item) = @_;

if ($system_item)
{
if (!defined $SYSTEM_USER_PATH)
{
$SYSTEM_USER_PATH = $USER_HOME; # glob( '~')
}
return $SYSTEM_USER_PATH;
} else
{
if (!defined $USER_USER_PATH)
{
$USER_USER_PATH = $USER_HOME; # glob( '~')
}
return $USER_USER_PATH;
}
}




sub OS_is_administrator()
{
return ($> == 0) ? 1 : 0;	    # $EFFECTIVE_USER_ID;
}

1;

