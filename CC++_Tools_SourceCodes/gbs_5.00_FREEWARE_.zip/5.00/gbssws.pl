#=================================================
#
#   gbssws.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSSWS @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::shell;
use glo::ask;
use glo::genopt;
use mod::gbsenv;
use mod::gbscmd;
use mod::gbsask;
use mod::run;
use mod::validate;
use mod::swset;
use mod::swglo;








my $CWD = ENV_cwd();

my $CANCELLED = 0;






$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ '<1>',	'subsystem',	     'sso',    '', "SubSystem. '' == ASK, '-' == none, '.' == current" ],
[ '<2>',	'component',	     'sso',    '', "Component. '-' == none, '.' == current" ],
[ 'build',	'build',	     'sso',    '', "Build. '-' == none, '.' == current" ],
[ 'audit',	'audit',	     'sso',    '', "Audit. '-' == none, '.' == current" ],
[ 'new',	'create_new_subsys', 'bso',     0, "Create a new SubSystem" ],
[ 'nocd',	'no_cd',	     'bso',     0, "Do not 'cd' to the selected directories "],
);
my @genconflicts = (
[ [ new => 1 ],	'=', '<1>', '=', '<2>', '=', 'build' ],
[ [ '<1>' => '-' ], '=', '<2>' ],
[ [ '<1>' => '' ],  '=', 'build', '=', 'audit' ],
);
GENOPT_set_optdefs( [ 'gbssws', 'sws' ], \@genopts,
'Set and/or Create new Current SubSystem',
undef);
GENOPT_set_conflicts( \@genconflicts);
GENOPT_parse();
}
my $SUBSYS = GENOPT_get( 'subsystem');
my $COMPONENT = GENOPT_get( 'component');
my $BUILD = GENOPT_get( 'build');
my $AUDIT = GENOPT_get( 'audit');
my $NEW = GENOPT_get( 'create_new_subsys');
my $NO_CD = GENOPT_get( 'no_cd');




VALIDATE_root();




if (!$NEW && @GBS::ALL_SUBSYSTEMS == 0)
{
if (ASK_YN( "No Subsystem(s) defined. Create now?", 'Y') eq 'Y')
{
$NEW = 1;
}
}




if ($NEW)
{
$SUBSYS = RUN_gbsnew( 'new_subsys', $SUBSYS);
if ($SUBSYS eq '')
{
$SUBSYS = '.';
$CANCELLED = 1;
} else
{
ENV_say( 1, "Current SubSys is $SUBSYS");
$COMPONENT = '-';
}
}

if (!$CANCELLED)
{



if ($SUBSYS eq '')
{
$SUBSYS = GBSASK_subsys();
$SUBSYS = ''
if ($SUBSYS eq '');
}
SWSET_subsys( $SUBSYS, $COMPONENT, $BUILD, $AUDIT);    # Also sets $GBS::subsys, component, build & audit









{
my $new_cwd = ($NO_CD) ? $CWD : SWGLO_new_cwd( $GBS::ROOT_PATH, $GBS::SUBSYS, $GBS::COMPONENT);

my @lines;
if (ENV_get_changed_envs() || $new_cwd ne $CWD)
{



push @lines, GBSENV_changed_setenv_commands( 0);




push @lines, SWGLO_set_title( $GBS::ROOT_PATH, $GBS::SUBSYS, $GBS::COMPONENT);




push @lines, SHELL_cd( $new_cwd);
}

push @lines, GBSCMD_get_full_gbs_command( gbsshow => '--brief');

GBSENV_write_result_script( \@lines, 0);
}
}

ENV_exit( $RC);




END
{
ENV_print_end_msg( 0);
}


