#=================================================
#
#   gbsmaint.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSMAINT @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::ask;
use glo::genopt;
use mod::gbsenv;
use mod::gbsglo;
use mod::gbscleanup;
use mod::fix;
use mod::owners;
use mod::maint;
use mod::user;
use mod::intgrtr;
use mod::admin;




sub needs_gbs_root_path($$$);









my @MAIN_MENU_ITEMS = (
[ "Audits Handling",
\&needs_gbs_root_path, \&MAINT_audits_handling ],
[ "Cleanup ",
\&needs_gbs_root_path, \&GBSCLEANUP_main ],
[ "Map Network Drives (Linux<->WIN32)",
\&MAINT_map_network_drives ],
[ "Not used",
sub { ENV_say( 1, "Not used!") } ],
[ "User Tools",
\&needs_gbs_root_path, \&USER_main ],
[ "Integrator Tools",
\&needs_gbs_root_path, \&INTGTR_main ],
[ "Administrator Tools",
\&needs_gbs_root_path, \&ADMIN_main ],
[ "Check/Fix GBS Directory Structure",
\&needs_gbs_root_path, \&FIX_main ],
[ "'Owners-file' Maintenance",
\&needs_gbs_root_path, \&OWNERS_maintenance ]
);






$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ '<1>', 'menu_entry_1', "isor1..9", 0, "Primary menu entry for single immediate execution" ],
[ '<2>', 'menu_entry_2', "iso>0",    0, "Secondary menu entry for single immediate execution" ],
[ '<3>', 'menu_entry_3', "iso>0",    0, "3rd menu entry for single immediate execution" ],
[ '<4>', 'menu_entry_4', "iso>0",    0, "4th menu entry for single immediate execution" ],
[ '<5>', 'menu_entry_5', "iso>0",    0, "5th menu entry for single immediate execution" ],
);
GENOPT_set_optdefs( 'gbsmaint', \@genopts,
[ 'Allow user to execute General Maintenance functions',
' 1. Audits Handling',
' 2. Cleanup',
' 3. Map Network Drives (unix<->win32)',
' 5. User Tools',
' 6. Integrator Tools',
' 7. Administrator Tools',
' 8. Check/Fix GBS Directory Structure',
' 9. Owners-file Maintenance',
],
undef
);
GENOPT_parse();
}
my @MENU_ENTRIES = grep( $_ != 0, map { scalar GENOPT_get( "menu_entry_$_") } 1..5);

ENV_pushd( undef);

if ($GBS::COMPONENT ne '')
{
ENV_chdir( "$GBS::COMPONENT_PATH/src");
} elsif ($GBS::SUBSYS ne '')
{
ENV_chdir( $GBS::SUBSYS_PATH);
} elsif ($GBS::ROOT_PATH ne '')
{
ENV_sig( W => "No current SubSystem");
ENV_chdir( $GBS::ROOT_PATH);
} else
{
ENV_sig( W => "No current Root/System. You are on your own!");
}

if ($GBS::ROOT_PATH ne '' && $GBS::SUBSYS ne '' && !GBSGLO_subsystem_is_full_gbs( $GBS::SUBSYS))
{
ENV_sig( I => "Current Subsystem ($GBS::SUBSYS) is not full-GBS",
"Not all Functions may be available");
}




{
ENV_say( 1, "General GBS Maintenance");

ASK_menu( 'Select function to perform',
\@MAIN_MENU_ITEMS, [ @MENU_ENTRIES ]);
}




ENV_popd();




{
if (ENV_get_changed_envs())
{
my @lines;
push @lines, GBSENV_changed_setenv_commands( 0);

GBSENV_write_result_script( \@lines, 0);
}
}

ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
}




sub needs_gbs_root_path($$$)
{
my ($menu_entry,
$data_ref,		# function to execute
$entries_ref
) = @_;

if ($GBS::ROOT_PATH eq '')
{
ENV_sig( W => 'This function requires a current Root/System');
} else
{
$data_ref->( $menu_entry, undef, $entries_ref);
}
}


