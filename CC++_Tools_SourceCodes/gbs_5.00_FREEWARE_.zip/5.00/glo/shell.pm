#=================================================
#
#   shell.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::shell;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SHELL_conditional_eq
SHELL_conditional_ne
SHELL_cd
SHELL_delete_files
SHELL_delete_dirs
SHELL_echo
SHELL_echo_failed
SHELL_exit
SHELL_exit_rc
SHELL_exit_value
SHELL_delete_and_exit
SHELL_pause
SHELL_concat
SHELL_and
SHELL_or
SHELL_redirect_stdin
SHELL_redirect_stdout
SHELL_redirect_stderr
SHELL_redirect_stdout_stderr
SHELL_run_background
SHELL_setenv
SHELL_printenv
SHELL_setalias
SHELL_printalias
SHELL_setfunction
SHELL_printfunction
SHELL_setrc
SHELL_source
SHELL_batch_header
SHELL_at
SHELL_at_show
SHELL_xtitle
SHELL_xcolor
SHELL_get_term_color_codes
SHELL_xgeometry
SHELL_get_geometry
);
}




use glo::env;




sub SHELL_conditional_eq($$@);
sub SHELL_conditional_ne($$@);
sub SHELL_cd($);
sub SHELL_delete_files(@);
sub SHELL_delete_dirs(@);
sub SHELL_echo($@);
sub SHELL_echo_failed();
sub SHELL_exit($;$);
sub SHELL_exit_rc($);
sub SHELL_exit_value($$);
sub SHELL_delete_and_exit($$;$);
sub SHELL_pause();
sub SHELL_concat($);
sub SHELL_and($);
sub SHELL_or($);
sub SHELL_redirect_stdin($$);
sub SHELL_redirect_stderr($$;$);
sub SHELL_redirect_stdout($$;$);
sub SHELL_redirect_stdout_stderr($$;$);
sub SHELL_run_background($);
sub SHELL_setenv($$);
sub SHELL_printenv();
sub SHELL_setalias($$);
sub SHELL_printalias();
sub SHELL_setfunction($$);
sub SHELL_printfunction();
sub SHELL_setrc();
sub SHELL_batch_header();
sub SHELL_source($;@);
sub SHELL_at($$$$$);
sub SHELL_at_show();
sub SHELL_xtitle($);
sub SHELL_xcolor($$);
sub SHELL_get_term_color_codes($$);
sub SHELL_xgeometry($$);
sub SHELL_get_geometry($$);

sub get_esc_color_codes($$);
sub escape_os_text($);
sub init_app();




my $SPREFIX = ENV_get_main_name() . '*: ';
my $SPREFIX_ = ' ' x length( $SPREFIX);

my $IS_WIN32 = (ENV_is_win32());


my ($MAX_COL, $MAX_ROW) = ENV_get_term_size_default();	    # 100, 60

my $NULL_DEVICE = ($IS_WIN32) ? 'NUL' : '/dev/null';

my $APP;		# e.g.: GBS
my $APP_RC;		# "${APP}_RC";
my $MUST_DEBUG_SCRIPTS;	# bool. depends on ${$APP}DEBUG_SCRIPTS e.g.: GBSDEBUG_SCRIPTS









my %COLORS = (

black	    => [ qw( 0 30 rgb:0/0/0 ) ],
red		    => [ qw( 4 31 rgb:a/0/0 ) ],
green	    => [ qw( 2 32 rgb:0/a/0 ) ], #  Lime
brown	    => [ qw( 6 33 rgb:a/5/0 ) ],
blue	    => [ qw( 1 34 rgb:0/0/a ) ],
magenta	    => [ qw( 5 35 rgb:a/0/a ) ], #  Purple/Fuchsia
cyan	    => [ qw( 3 36 rgb:0/a/a ) ], #  Aqua
light_gray	    => [ qw( 7 37 rgb:a/a/a ) ],
dark_gray	    => [ qw( 8 90 rgb:5/5/5 ) ],
light_red	    => [ qw( C 91 rgb:f/5/5 ) ],
light_green     => [ qw( A 92 rgb:5/f/5 ) ],
yellow	    => [ qw( E 93 rgb:f/f/5 ) ],
light_blue	    => [ qw( 9 94 rgb:5/5/f ) ],
light_magenta   => [ qw( D 95 rgb:f/5/f ) ],
light_cyan	    => [ qw( B 96 rgb:5/f/f ) ],
white	    => [ qw( F 97 rgb:f/f/f ) ],
);





sub SHELL_conditional_eq($$@)
{
my ($env_var,
$value,
@commands) = @_;

if ($IS_WIN32)
{
@commands = map { "if [%$env_var%]==[$value] $_"  } @commands;
} else
{
@commands = map { "[[ \$$env_var == $value ]] && $_" } @commands;
}
return @commands;
}





sub SHELL_conditional_ne($$@)
{
my ($env_var,
$value,
@commands) = @_;

if ($IS_WIN32)
{
@commands = map { "if NOT [%$env_var%]==[$value] $_"  } @commands;
} else
{
@commands = map { "[[ \$$env_var != $value ]] && $_" } @commands;
}
return @commands;
}





sub SHELL_cd($)
{
my ($path) = @_;

$path = ENV_enquote( $path);
if ($IS_WIN32)
{
$path =~ tr!/!\\!;
return ( "cd /D $path\\ > NUL");
} else
{
return ( "\\cd $path");
}
}




sub SHELL_delete_files(@)
{
my (@files) = @_;

@files = ENV_enquote( @files);
if ($IS_WIN32)
{
@files = ENV_os_paths( @files);
return ( "del /F /Q @files" );
} else
{
return ( "\\rm -f @files" );
}
}




sub SHELL_delete_dirs(@)
{
my (@dirs) = @_;

@dirs = ENV_enquote( @dirs);
if ($IS_WIN32)
{
@dirs = ENV_os_paths( @dirs);
return ( "rmdir /S /Q @dirs" );
} else
{
return ( "\\rm -rf @dirs" );
}
}





sub SHELL_echo($@)
{
my ($indent,    # 0 = no prefix, 1 = $prefix, 2 = $prefix_ 3+ = indent
@in_lines,
) = @_;
my @shell_lines;

ENV_sig( F => "SHELL_echo: indent ($indent) not numeric")
if ($indent !~ /^\d+$/);

my $prefix;
my $prefix_;
if ($indent == 0)
{
$prefix = '';
$prefix_ = '';
} elsif ($indent == 1)
{
$prefix = $SPREFIX;
$prefix_ = $SPREFIX_;
} elsif ($indent == 2)
{
$prefix = $SPREFIX_;
$prefix_ = $prefix;
} else  # $indent 3+
{
$prefix = $SPREFIX_ . (' ' x ($indent - 3) * 2);
$prefix_ = $prefix;
}

if ($IS_WIN32)
{
foreach my $line (@in_lines)
{
$line =~ s/\s*$//;			# remove trailing whitespace
$line = escape_os_text( $line);	# escape special characters
push @shell_lines, "echo($prefix$line";
$prefix = $prefix_;
}
} else
{
foreach my $line (@in_lines)
{
push @shell_lines, "\\echo \"$prefix$line\"";
$prefix = $prefix_;
}
}

return wantarray ? @shell_lines : $shell_lines[0];
}





sub SHELL_echo_failed()
{
my $beep = (ENV_beeps_are_enabled()) ? "\a" : '';

init_app()
if (!defined $APP);

if ($IS_WIN32)
{
return SHELL_echo( 1, "Failed (%$APP_RC%)$beep" );
} else
{
return SHELL_echo( 1, "Failed (\$$APP_RC)$beep" );
}
}





sub SHELL_exit($;$)
{
my ($sourced,	    # Linux only
$rc,
) = @_;
my @lines;

my $exit_arg = (defined $rc) ? " $rc" : '';
if ($IS_WIN32)
{
push @lines, "exit$exit_arg";
} else
{
if ($sourced)
{
push @lines, "\\return$exit_arg";
} else
{
push @lines, "\\exit$exit_arg";
}
}
return @lines;
}





sub SHELL_exit_rc($)
{
my ($sourced,	    # Linux only
) = @_;
my @lines;

init_app()
if (!defined $APP);

if ($IS_WIN32)
{
push @lines, "exit /B %$APP_RC%";
} else
{
if ($sourced)
{
push @lines, "\\return \$$APP_RC";
} else
{
push @lines, "\\exit \$$APP_RC";
}
}
return @lines;
}





sub SHELL_exit_value($$)
{
my ($sourced,	    # Linux only
$exit_code,
) = @_;
my @lines;

if ($IS_WIN32)
{
push @lines, "exit /B $exit_code";
} else
{
if ($sourced)
{
push @lines, "\\return $exit_code";
} else
{
push @lines, "\\exit $exit_code";
}
}
return @lines;
}





sub SHELL_delete_and_exit($$;$)
{
my ($tmp_filespec,
$sourced,	    # Linux only
$rc,
) = @_;
my @lines;

my $exit_arg = (defined $rc) ? " $rc" : '';
if ($IS_WIN32)
{
$tmp_filespec = '%~f0'
if (!defined $tmp_filespec);
$tmp_filespec = ENV_enquote( $tmp_filespec);
$tmp_filespec =~ tr!/!\\!;
push @lines, "start /b \"\" cmd /c del $tmp_filespec & exit$exit_arg";
} else
{

push @lines, "trap \"rm -f \"\"$tmp_filespec\"\"\" exit";
if ($sourced)
{
push @lines, "\\return$exit_arg";
} else
{
push @lines, "\\exit$exit_arg";
}
}



return @lines;
}




sub SHELL_concat($)
{
my ($commands_ref,
) = @_;


if ($IS_WIN32)
{
return join( ' & ', @{$commands_ref});
} else
{
return join( ' ; ', @{$commands_ref});
}
}




sub SHELL_or($)
{
my ($commands_ref,
) = @_;


return join( ' || ', @{$commands_ref});
}




sub SHELL_and($)
{
my ($commands_ref,
) = @_;


return join( ' && ', @{$commands_ref});
}




sub SHELL_pause()
{
return ($IS_WIN32) ? 'pause' : 'read -r -p "Press <ENTER> to continue . . ." key;';
}




sub SHELL_redirect_stdin($$)
{
my ($command_or_ref,
$file_from,	# undef == NULL-device
) = @_;
my @commands = ENV_deref( $command_or_ref);

$file_from = (!defined $file_from) ? $NULL_DEVICE : ENV_enquote( $file_from);

foreach my $command (@commands)
{
$command .= " < $file_from";
}

return (@commands == 1) ? $commands[0] : @commands;
}




sub SHELL_redirect_stdout($$;$)
{
my ($command_or_ref,
$file_to,	# undef == NULL-device
$append,	# bool. optional. undef == no
) = @_;
my @commands = ENV_deref( $command_or_ref);

$file_to = (!defined $file_to) ? $NULL_DEVICE : ENV_enquote( $file_to);
my $redirect = ($append) ? '>>' : '>';

foreach my $command (@commands)
{
$command .= " $redirect $file_to";
$redirect = '>>';
}

return (@commands == 1) ? $commands[0] : @commands;
}




sub SHELL_redirect_stderr($$;$)
{
my ($command_or_ref,
$file_to,	# undef == NULL-device
$append,	# bool. optional. undef == no
) = @_;
my @commands = ENV_deref( $command_or_ref);

$file_to = (!defined $file_to) ? $NULL_DEVICE : ENV_enquote( $file_to);
my $redirect = ($append) ? '>>' : '>';

foreach my $command (@commands)
{
$command .= " $redirect $file_to 2>";
$redirect = '>>';
}

return (@commands == 1) ? $commands[0] : @commands;
}




sub SHELL_redirect_stdout_stderr($$;$)
{
my ($command_or_ref,
$file_to,	# undef == NULL-device
$append,	# bool. optional. undef == no
) = @_;
my @commands = ENV_deref( $command_or_ref);

$file_to = (!defined $file_to) ? $NULL_DEVICE : ENV_enquote( $file_to);
my $redirect = ($append) ? '>>' : '>';

foreach my $command (@commands)
{
$command .= " $redirect $file_to 2>&1";
$redirect = '>>';
}

return (@commands == 1) ? $commands[0] : @commands;
}





sub SHELL_run_background($)
{
my ($command_or_ref,
) = @_;
my @commands = ENV_deref( $command_or_ref);

foreach my $command (@commands)
{
$command .= ' &';
}

return (@commands == 1) ? $commands[0] : @commands;
}




sub SHELL_setenv($$)
{
my ($name,
$value,		# undef == unset
) = @_;
my $command;


if (defined $value)
{
$value = escape_os_text( $value);	# escape special characters
if ($IS_WIN32)
{
$value =~ s/%(\d)%/%%$1%%/g;	    # Embed %EnvVarName%
$command = "set $name=$value";
} else
{
$value =~ s/\$(\d)/\\\$$1/g;	    # Embed $0-$9 when placed inside ".."


if (substr( $value, 0, 1) eq '"' ||
substr( $value, 0, 1) eq "'")
{

} else
{
if ($value =~ /\s/)
{
$value = "\"$value\"";
}
}
$command = "\\export $name=$value";
}
} else
{
if ($IS_WIN32)
{
return ( "set $name=" );
} else
{
return ( "\\unset $name" );
}
}


return ($command);
}




sub SHELL_printenv()
{
if ($IS_WIN32)
{
return ( 'set' );
} else
{
return ( "\\printenv" );
}
}





sub SHELL_setalias($$)
{
my ($name,
$value,		    # undef == delete
) = @_;

if (defined $value)
{
if ($IS_WIN32)
{
return ( "doskey $name=$value \$*" );
} else
{
return ( "\\alias $name=$value" );
}
} else
{
if ($IS_WIN32)
{
return ( "doskey $name=" );
} else
{
return ( "\\unalias $name" );
}
}
}




sub SHELL_printalias()
{

if ($IS_WIN32)
{
return 'doskey /macros';
} else
{
return 'alias';
}
}





sub SHELL_setfunction($$)
{
my ($name,
$line_or_ref,	    # undef == delete
) = @_;
my @bash_lines;

if (defined $line_or_ref)
{
if (ref $line_or_ref)
{
push @bash_lines, "function $name ()";
push @bash_lines, @{$line_or_ref};
} else
{
push @bash_lines, "function $name { $line_or_ref; }";
}
} else
{
push @bash_lines, "\\unset -f $name";
}

return @bash_lines;
}





sub SHELL_printfunction()
{
return 'declare -f';
}




sub SHELL_setrc()
{
init_app()
if (!defined $APP);

if ($IS_WIN32)
{
return ("set $APP_RC=%ERRORLEVEL%");
} else
{
return ("$APP_RC=\$?");
}
}





sub SHELL_batch_header()
{
init_app()
if (!defined $APP);

if ($IS_WIN32)
{
my $on_or_off = ($MUST_DEBUG_SCRIPTS) ? 'ON' : 'OFF';
return ( "\@ECHO $on_or_off",
"if not defined $APP_RC set $APP_RC=0" );
} else
{
return ( ($MUST_DEBUG_SCRIPTS) ? '#!/bin/bash -xv' : '#!/bin/bash' );
}
}




sub SHELL_source($;@)
{
my ($file,
@args
) = @_;

my @command_items = ENV_enquote( $file, @args);
if ($IS_WIN32)
{
$command_items[0] =~ tr!/!\\!;
return ( "call @command_items" );
} else
{
return ( ". @command_items" );
}
}




sub SHELL_at($$$$$)
{
my ($command_items_ref,
$name,			# jobname
$delay,			# now | [=+]hh:mm
$mail,			# bool
$os_log_filespec,
) = @_;
my $full_command;

if ($IS_WIN32)
{



if ($delay eq 'now' || $delay eq '')
{
$delay = '+00:00';
}
if (substr($delay,0,1) eq '=')
{
my ($sec, $min, $hour) = localtime();
my ($hours, $minutes) = split (':', substr($delay,1));
my $d_hours = $hours - $hour;
my $d_minutes = $minutes - $min;
if ($d_minutes < 0)
{
$d_hours--;
$d_minutes = 60 + $d_minutes;
}
$d_hours = 24 + $d_hours if ($d_hours < 0);
$delay = "+$d_hours:$d_minutes";
}
my ($hours, $minutes) = split (':', substr($delay,1));
my $time = $hours * 60 + $minutes;




if ($mail)
{
ENV_sig( W => 'submit: mail option is not implemented for Windows');
}

my $app_scripts_path = ENV_get_application_scripts_path();
my $winat_filespec = ENV_os_paths( "$app_scripts_path/glo/winat.bat");
$os_log_filespec = ENV_encode( $os_log_filespec);
my @command_items = ENV_encode( ENV_prepare_command( $command_items_ref));
$full_command = "\"$winat_filespec\" \"$name\" $time $mail $os_log_filespec @command_items";

} else # Assume LUNIX
{



my $at_options;

if ($delay eq 'now' || $delay eq '')
{
$at_options = 'now';
} elsif (substr($delay,0,1) eq '=')
{
$at_options = substr($delay,1);
} elsif (substr($delay,0,1) eq '+')
{
my ($hours, $minutes) = split (':', substr($delay,1));
$minutes += $hours * 60;
$at_options = "now + $minutes minutes";
} else
{
ENV_sig( EE => "submit: Invalid delay: $delay");
}




if ($mail)
{
$at_options = "-m $at_options";
}




my $command = ENV_prepare_command( $command_items_ref);
$command = SHELL_redirect_stdout_stderr( $command, $os_log_filespec);	#     "> $file_to 2>&1"
$command = ENV_enquote( $command);
$full_command = "\\cd; \\at $at_options <<EOF\nbash -c $command\nEOF\n";

}
ENV_debug( 1, "SHELL_at: $full_command");

return $full_command;
}




sub SHELL_at_show()
{
if ($IS_WIN32)
{
return ( "REM -- No 'at' function on WIN32");
} else # Assume LUNIX
{
return ( "\\atq");
}
}




sub SHELL_xtitle($)
{
my ($title) = @_;
my $line;

if ($IS_WIN32)
{
$line = "TITLE $title";
} else
{





$line = "printf \"\e]0;$title\a\"";
}


return $line;
}




sub SHELL_xcolor($$)
{
my ($fg,
$bg
) = @_;
my $command_line;

my ($fgc, $bgc) = get_esc_color_codes( $fg, $bg);
if ($IS_WIN32)
{
$command_line = "COLOR $bgc$fgc";
} else
{

$command_line = "printf \"\e[${fgc};${bgc}m\"";
}

return $command_line;
}




sub get_esc_color_codes($$)
{
my ($fg,
$bg,
) = @_;
my ($fgc, $bgc);

$fg = 'blue' if (!defined $fg);
$bg = 'white' if (!defined $bg);

my @code_refs;
foreach my $color ($fg, $bg)
{
my $code_ref = $COLORS{lc $color};
ENV_sig( F => "Unknown color: '$color'")
if (!defined $code_ref);
push @code_refs, $code_ref;
}
if ($IS_WIN32)
{
$fgc = $code_refs[0]->[0];  # $esc_cmd
$bgc = $code_refs[1]->[0];  # $esc_cmd
} else
{
$fgc = $code_refs[0]->[1];	    #$esc_xterm
$bgc = $code_refs[1]->[1] + 10;	    #$exc_xterm
}
return ($fgc, $bgc);
}




sub SHELL_get_term_color_codes($$)
{
my ($fg,
$bg,
) = @_;
my ($fgc, $bgc);

$fg = 'blue' if (!defined $fg);
$bg = 'white' if (!defined $bg);

my @code_refs;
foreach my $color ($fg, $bg)
{
my $code_ref = $COLORS{lc $color};
ENV_sig( F => "Unknown color: '$color'")
if (!defined $code_ref);
push @code_refs, $code_ref;
}
if ($IS_WIN32)
{
$fgc = $code_refs[0]->[0];  # $esc_cmd
$bgc = $code_refs[1]->[0];  # $esc_cmd
} else  # IS_LINUX
{
$fgc = $code_refs[0]->[2];  #xterm
$bgc = $code_refs[1]->[2];  #xterm
}
return ($fgc, $bgc);
}




sub SHELL_xgeometry($$)
{
my ($width,		    # May be undef
$height,	    # May be undef
) = @_;
my $command_line;

($width, $height) = SHELL_get_geometry( $width, $height);

if ($IS_WIN32)
{
$command_line = "mode con cols=$width lines=$height";
} else
{
$command_line = "printf ''";	    # not possible - do nothing";
}


return $command_line;
}




sub SHELL_get_geometry($$)
{
my ($width,		# May be undef
$height,	# May be undef
) = @_;


$width = $MAX_COL
if (!defined $width);
$height = $MAX_ROW
if (!defined $height);

return ($width, $height);
}




sub escape_os_text($)
{
my ($text) = @_;
my $new_text = $text;

if ($IS_WIN32)
{
my $dos_special_chars = '()<>|&^';
$new_text =~ s/([$dos_special_chars])/^$1/g;	# escape special characters
} else
{
my $unix_special_chars = '\\\\()<>|';
$new_text =~ s/([$unix_special_chars])/\\$1/g;	# escape special characters
}


return $new_text;
}




sub init_app()
{
$APP = ENV_get_application_name();	# e.g.: GBS
$APP_RC = "${APP}_RC";
my $appdebug_scripts = "${APP}DEBUG_SCRIPTS";	# e.g.: 'GBSDEBUG_SCRIPTS'
$MUST_DEBUG_SCRIPTS	= ENV_getenv_bool( $appdebug_scripts);
}

1;

