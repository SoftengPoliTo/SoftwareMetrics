#=================================================
#
#   gbshelp.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSHELP @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::genopt;
use mod::gbsenv;
use mod::run;














my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
);
GENOPT_set_optdefs( 'gbshelp', \@genopts,
'Present help on GBS in HTML browser',
undef);
GENOPT_parse();
}




RUN_browser( "$GBS::SCRIPTS_PATH/doc/index.html");




ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
}

