#=================================================
#
#   gbswhich.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSWHICH @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::list;
use glo::genopt;
use glo::format;
use mod::gbsenv;
use mod::gbsglo;
use mod::fspec;
use mod::ssprop;
use mod::scope;
use mod::flincs;
use mod::plugin;
use mod::build;
use mod::audit;
use mod::scadef;
use mod::tool;
use mod::sys;
use mod::validate;
use mod::gbsoptenv;
use mod::gbssfile;




sub handle_plain($);
sub handle_subsys($);
sub handle_component($);
sub handle_build($);
sub handle_audit($);
sub handle_tool($);
sub handle_find($);
sub handle_search($);
sub handle_show($);
sub validate($$$$);

sub do_plain();
sub do_subsys($);
sub do_component($$);
sub do_build();
sub do_build_type($);
sub do_audit($);
sub do_audit_type($$);
sub do_tool($);
sub show_section_items($$$);
sub show_subsection_items($$$$);
sub show_value($$);
sub show_commands($);
sub do_find($$$$);
sub do_search($$);
sub init_build_types();








my @SUB_DIRS = qw( inc loc bld dat opt sav ALL );

my @INIT_ORDER = qw( SET SET_W SET_X SETPATH BIN_DIR );
my @SETUP_ORDER = qw( NICE_NAME VIA_FORMAT );




my $IS_FULL_GBS = ($GBS::SSTYPE eq 'GBS') ? 1 : 0;




my @ALL_SRC_TYPES;
my @ALL_INC_TYPES;
my @ALL_BLD_TYPES;
my %BLD_TYPES;	#key = src_type, value = [ @bld_types_refs ]
my %SRC_TYPES;	#key = bld_type, value = [ @src_types ]






$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ '<1>',    'what',	    'ssos,?,subsys,comp,component,build,audit,tool,find,search',  '', "Specify" ],
[ '<*>',    'what_args',    'sao',							  '', "'what'-dependent" ],
);
my @genenvs = qw( FLAGS_* );
GENOPT_set_optdefs( 'gbswhich', \@genopts,
'Show Build and Audit data. Lookup header-files, sub-files',
[ 'subsys',
'component',
'build',
'build <src_file_type>',
'build <bld_file_type>',
'build .glkb',
'audit',
'audit  <src_file_type>',
'tool',
'find   <include_file> <find_method>',
'search <source_file>',
'search <subdir>/<file>',
],
);
GENOPT_set_envdefs( \&GBSOPTENV_set, \&GBSOPTENV_print, \@genenvs);
GENOPT_parse();
}
my $WHAT = GENOPT_get( 'what');
my @WHAT_ARGS = GENOPT_get( 'what_args');




if ($GBS::ROOT_PATH ne '')
{
VALIDATE_root();

if ($GBS::COMPONENT ne '')
{
ENV_chdir( "$GBS::ROOT_PATH/dev/$GBS::SUBSYS/comp/$GBS::COMPONENT/src");
}
}




my %WHATS = (

''		=> [ \&handle_plain,	    0,	    0,	, ''	],
subsys	=> [ \&handle_subsys,       [0, 1], 1,	, 'subsys [<subsys>]'	],
component	=> [ \&handle_component,    [0, 2], 1,	, 'component [<subsys>] [<component>]'	],
build	=> [ \&handle_build,	    [0, 1], 1,	, 'build [<src_type>|<bld_type>|.glkb]' ],
audit	=> [ \&handle_audit,	    [0, 2], 1,	, 'audit [<audit>] [<src_type>]' ],
tool	=> [ \&handle_tool,	    [0, 1], 1,	, 'tool [<tool>]'   ],
find	=> [ \&handle_find,	    2,	    1,	, 'find <file_to_find> <file_type_for_find_method>' ],
search	=> [ \&handle_search,	    1,	    1,	, 'search [<sub_dir>]/<file>'	],
'?'		=> [ \&handle_show,	    0,	    0,  , ''],
);
$WHATS{comp} = $WHATS{component};

my $what_ref = $WHATS{$WHAT};
if (defined $what_ref)
{
my ($func, $min_max_arg_ref, $needs_root, $syntax) = @{$what_ref};
$syntax = "Syntax = $syntax";
if ($needs_root)
{
ENV_sig( EE => "This function ($WHAT) needs a current root")
if ($GBS::ROOT_PATH eq '');
}
my $nr_args = @WHAT_ARGS;
if (ref $min_max_arg_ref)
{
my ($min_arg, $max_arg) = @{$min_max_arg_ref};
ENV_sig( EE => "Nr args ($nr_args) for '$WHAT' must be between $min_arg and $max_arg",
$syntax)
if ($nr_args < $min_arg || $nr_args > $max_arg);

} else
{
ENV_sig( EE => "Nr args ($nr_args) for '$WHAT' must be $min_max_arg_ref",
$syntax)
if ($nr_args != $min_max_arg_ref);
}
$func->( $syntax);
} else
{
ENV_sig( EE => "Invalid what '$WHAT'");
}




ENV_exit( $RC);




END
{
ENV_print_end_msg(1);
}




sub handle_plain($)
{
my ($syntax,
) = @_;

do_plain();
}




sub handle_subsys($)
{
my ($syntax,
) = @_;




my $subsys = $GBS::SUBSYS;
if (@WHAT_ARGS == 1)
{
$subsys = $WHAT_ARGS[0];
}
$subsys = validate( SubSys => $subsys, \@GBS::ALL_SUBSYSTEMS, $syntax);




do_subsys( $subsys);
}




sub handle_component($)
{
my ($syntax,
) = @_;




my ($subsys, $component) = ($GBS::SUBSYS, $GBS::COMPONENT);
if (@WHAT_ARGS == 1)
{
$component = $WHAT_ARGS[0];
} elsif (@WHAT_ARGS == 2)
{
($subsys, $component) = @WHAT_ARGS;
}
$subsys = validate( SubSys => $subsys, \@GBS::ALL_SUBSYSTEMS, $syntax);

if (GBSGLO_subsystem_is_full_gbs( $subsys))
{
$component = validate( "'$subsys' Component" => $component, [ GBSGLO_components( $subsys) ], $syntax);
} else
{
ENV_sig( EE => "This function is only possible for Full GBS SubSystems",
$syntax);
}




do_component( $subsys, $component);
}




sub handle_build($)
{
my ($syntax,
) = @_;




my $type = '';
if (@WHAT_ARGS == 1)
{
$type = $WHAT_ARGS[0];
}




if ($type eq '')
{
VALIDATE_build_no_subsys();
do_build();
} else
{
VALIDATE_build();
my @all_src_types = BUILD_get_src_types( $GBS::BUILD);
my @all_bld_types = BUILD_get_bld_types( $GBS::BUILD);
validate( 'Build type', $type, [ @all_src_types, @all_bld_types, '.glkb' ], $syntax);
do_build_type( $type);
}
}




sub handle_audit($)
{
my ($syntax,
) = @_;




my ($audit, $type) = ($GBS::AUDIT, '');
if (@WHAT_ARGS == 1)
{
if (substr( $WHAT_ARGS[0], 0, 1) eq '.')
{
$type = $WHAT_ARGS[0];
} else
{
$audit = $WHAT_ARGS[0];
}
} elsif (@WHAT_ARGS == 2)
{
($audit, $type) = @WHAT_ARGS;
}

$audit = validate( Audit => $audit, \@GBS::ALL_AUDITS, $syntax);




if ($type eq '')
{
do_audit( $audit);
} else
{
my @src_types = AUDIT_get_src_types( $audit);
validate( 'Audit src_type', $type, \@src_types, $syntax);
do_audit_type( $audit, $type);
}
}




sub handle_tool($)
{
my ($syntax,
) = @_;

my $tool = $GBS::TOOL;
if (@WHAT_ARGS == 1)
{
$tool = $WHAT_ARGS[0];
}

$tool = validate( Tool => $tool, \@GBS::ALL_TOOLS, $syntax);

do_tool( $tool);
}




sub handle_find($)
{
my ($syntax,
) = @_;




my ($file_to_find, $find_type) = @WHAT_ARGS;
my ($dir, $name, $type) = ENV_split_spec_pnt( $file_to_find);
my $file = "$name$type";

VALIDATE_build();
ENV_sig( EE => "This function is only possible for full GBS SubSystems",
$syntax)
if (!$IS_FULL_GBS);

ENV_sig( EE => "Cannot specify '$dir/",
$syntax)
if ($dir ne '');
ENV_sig( EE => "Must specify 'name.type' in first parameter",
$syntax)
if ($name eq '' || $type eq '');




do_find( $file, $name, $type, $find_type);
}




sub handle_search($)
{
my ($syntax,
) = @_;




my $file_spec = $WHAT_ARGS[0];
my ($dir, $name, $type) = ENV_split_spec_pnt( $file_spec);
my $file = "$name$type";
ENV_sig( EE => "This function is only possible for full GBS SubSystems")
if (!$IS_FULL_GBS);
VALIDATE_build();
init_build_types();




if ($dir eq '')
{



ENV_sig( EE => "This function is only possible for full GBS SubSystems")
if (!$IS_FULL_GBS);
VALIDATE_build();
if (grep $_ eq $type, @ALL_SRC_TYPES)
{
do_search( 'src', $file);
} elsif (grep $_ eq $type, @ALL_BLD_TYPES)
{
do_search( 'bld' ,$file);
} else
{
ENV_sig( EE => "Do not know how to search '$file_spec'");
}
} else
{



ENV_sig( EE => "Sub-dir ($dir) must be one of '@SUB_DIRS'")
if (!LIST_contains_str( $dir, \@SUB_DIRS));
do_search( $dir, $file);
}
}




sub handle_show($)
{
my ($syntax,
) = @_;

ENV_say( 1, 'What:',
'<empty>, subsys, comp, build, audit, tool, find, search');
}




sub validate($$$$)
{
my ($nice_name,	# Audit, Tool, etc
$value,
$values_ref,	# GBS::BUILDS, etc
$syntax,
) = @_;


my @all_values = @{$values_ref};
if ($value eq '')
{
if (@all_values == 1)
{
$value = $all_values[0];
ENV_sig( I => "Single $nice_name '$value' assumed");
} else
{
ENV_sig( EE => "No current $nice_name (@all_values)",
$syntax);
}
} else
{
ENV_sig( EE => "No such $nice_name '$value' (@all_values)",
$syntax)
if (!LIST_contains_str( $value, \@all_values));
}

return $value;
}




sub do_plain()
{
my @row_refs;

if ($GBS::ROOT_PATH ne '')
{
init_build_types();

ENV_sig( W => "This Build ($GBS::BUILD) has no sources defined (gbsedit build.gbs)")
if (!@ALL_SRC_TYPES);

ENV_say( 1, "Overview");

push @row_refs, [ 'src_types', "@ALL_SRC_TYPES" ];
push @row_refs, [ 'inc_types', "@ALL_INC_TYPES" ];
push @row_refs, [ 'bld_types', "@ALL_BLD_TYPES" ];
push @row_refs, [ 'skiptypes', "@GBS::SKIPTYPES" ];




push @row_refs, [ 'Builds', "@GBS::BUILDS" ];
push @row_refs, [ 'All Builds', "@GBS::ALL_BUILDS" ];
push @row_refs, [ 'Cur. Build', $GBS::BUILD ];




if (@GBS::AUDITS)
{
my $heading = 'Audits';
foreach my $audit (@GBS::AUDITS)
{
my $plugin = PLUGIN_get_abt_plugin_name( $audit);
my $plugin_rel = PLUGIN_get_main_envs( $plugin);
my @in_types = AUDIT_get_src_types( $audit);
push @row_refs, [ $heading, "$audit [$plugin ($plugin_rel)] (@in_types)" ];
$heading = '';
}
push @row_refs, [ 'Cur. Audit', $GBS::AUDIT ];
} else
{
push @row_refs, [ 'Audits', '' ];
}
push @row_refs, [ 'All Audits', "@GBS::ALL_AUDITS" ];




if (@GBS::TOOLS)
{
my $heading = 'Tools';
foreach my $tool (@GBS::TOOLS)
{
my $plugin = PLUGIN_get_abt_plugin_name( $tool);
my $plugin_rel = PLUGIN_get_main_envs( $plugin);
my ($value_name, @values) = TOOL_get_action( $tool);
push @row_refs, [ $heading, "$tool [$plugin ($plugin_rel)] ($value_name => @values)" ];
$heading = '';
}
} else
{
push @row_refs, [ 'Tools', '' ];
}
push @row_refs, [ 'All Tools', "@GBS::ALL_TOOLS" ];




{
push @row_refs, [ 'Cur. Build', $GBS::BUILD ];
if ($GBS::BUILD)
{
my @opt_row_refs = BUILD_option_items( $GBS::BUILD);
my @opt_lines = FORMAT_table( -2, 0, ' ', undef, @opt_row_refs);
map { push @row_refs, [ '', $_ ] } @opt_lines;
}
}




{
my @app_row_refs = SYS_app_items();
if (@app_row_refs)
{
my @app_lines = FORMAT_table( -2, 0, ' ', undef, @app_row_refs);
push @row_refs, [ 'Appl. Envs', shift @app_lines ];
map { push @row_refs, [ '', $_ ] } @app_lines;
} else
{
push @row_refs, [ 'Appl. Envs', 'None' ];
}
}




{
my @gbsext_envs = grep( /^GBSEXT_.+_PATH$/, keys( %ENV));
if (@gbsext_envs)
{
my @gbsext_env_refs = map { [ ' ', $_, '=>' , ENV_getenv( $_) ] } @gbsext_envs;
map { $_->[0] = 'x' if ($_->[3] ne 'PATH' && ! -d ENV_perl_paths_noquotes($_->[3])) } @gbsext_env_refs;
my @app_lines = FORMAT_table( -2, 0, ' ', undef, @gbsext_env_refs);
push @row_refs, [ 'GBSEXT_Paths', shift @app_lines ];
map { push @row_refs, [ '', $_ ] } @app_lines;
} else
{
push @row_refs, [ 'GBSEXT_Paths', 'None' ];
}
}
} else
{
ENV_say( 1, "No current Root");
}




{
my @path = ENV_split_path( ENV_getenv( 'PATH'));
my $head = 'PATH';
foreach my $path (@path)
{
if ($path =~ /%/)
{
my $exp_path = ENV_expand_envs( $path);
my $lead = (-d $exp_path) ? ' ' : 'x';
push @row_refs, [ $head, "$lead $exp_path ($path)" ];
} else
{
my $lead = (-d $path) ? ' ' : 'x';
push @row_refs, [ $head, "$lead $path" ];
}
$head = '';
}
}




{
my ($os, $user, @rest) = ENV_uname();
push @row_refs, [ "SysInfo", "$os [@rest]" ];
push @row_refs, [ "Node", $user ];
}




my @lines = FORMAT_table( 0, 2, ': ', undef, @row_refs);
ENV_say( 0, \@lines);

}




sub do_subsys($)
{
my ($subsys,
) = @_;

my $gbs_subsys_path = "$GBS::ROOT_PATH/dev/$subsys";
my $ss_type = SSPROP_get_type( undef, $subsys);




ENV_say( 0, "SubSys '$subsys':");
my @row_refs;

push @row_refs, [ 'Type', $ss_type ];

my @builds = GBSGLO_subsystem_builds( $subsys);
my @audits =  GBSGLO_subsystem_audits( $subsys);

push @row_refs, [ 'Builds', "@builds" ];
foreach my $build (@builds)
{
my @build_audits;
foreach my $audit (@audits)
{
push @build_audits, $audit
if (GBSGLO_subsystem_does_audit( $subsys, $audit, $build))
}
push @row_refs, [ '', "$build (@build_audits)" ]
if (@build_audits);
}

push @row_refs, [ 'Audits', "@audits" ];
foreach my $audit (@audits)
{
my @audit_builds;
foreach my $build (@builds)
{
push @audit_builds, $build
if (GBSGLO_subsystem_does_audit( $subsys, $audit, $build))
}
push @row_refs, [ '', "$audit (@audit_builds)" ]
if (@audit_builds);
}

my @tools =  GBSGLO_subsystem_tools( $subsys);
push @row_refs, [ 'Tools', "@tools" ];

ENV_say( 0, FORMAT_table( 0, 2, ': ', undef, @row_refs));
}




sub do_component($$)
{
my ($subsys,
$component,
) = @_;

my $gbs_subsys_path = "$GBS::ROOT_PATH/dev/$subsys";

ENV_say( 0, "Subsys '$subsys', Component '$component':");
my @row_refs;

my @builds = GBSGLO_component_builds( $subsys, $component);
my @audits =  GBSGLO_component_audits( $subsys, $component);

push @row_refs, [ 'Builds', "@builds" ];
foreach my $build (@builds)
{
my @build_audits;
foreach my $audit (@audits)
{
push @build_audits, $audit
if (GBSGLO_component_does_audit( $subsys, $component, $audit, $build))
}
push @row_refs, [ '', "$build (@build_audits)" ]
if (@build_audits);
}

push @row_refs, [ 'Audits', "@audits" ];
foreach my $audit (@audits)
{
my @audit_builds;
foreach my $build (@builds)
{
push @audit_builds, $build
if (GBSGLO_component_does_audit( $subsys, $component, $audit, $build))
}
push @row_refs, [ '', "$audit (@audit_builds)" ]
if (@audit_builds);
}

my @scope_dirs = SCOPE_get_components( $subsys, $component);
push @row_refs, [ "Scope ($GBS::BUILD)", "@scope_dirs" ];

ENV_say( 0, FORMAT_table( 0, 2, ': ', undef, @row_refs));
}




sub do_build()
{
my @row_refs;

ENV_say( 1, "Build: $GBS::BUILD");

init_build_types();

ENV_sig( W => "This Build ($GBS::BUILD) has no sources defined (gbsedit build.gbs)")
if (!@ALL_SRC_TYPES);




{
my $plugin_rel = PLUGIN_get_main_envs( $GBS::BUILD_PLUGIN);
push @row_refs, [ 'Plugin', '=', "$GBS::BUILD_PLUGIN ($plugin_rel)" ];
}
push @row_refs, [ 'src_types', '=', "@ALL_SRC_TYPES" ];
push @row_refs, [ 'inc_types', '=', "@ALL_INC_TYPES" ];
push @row_refs, [ 'bld_types', '=', "@ALL_BLD_TYPES" ];

my @option_refs = BUILD_get_options( $GBS::BUILD, 0);





{
my @defaults;
foreach my $ref (@option_refs)
{
my ($opt_name, $default_value_name) = @{$ref};
push @defaults, "$opt_name = $default_value_name";
}
push @row_refs, [ 'Options Defaults', '=', join( ', ', @defaults) ];
}

my $struct_id = BUILD_read( $GBS::BUILD);




push @row_refs, show_section_items( $struct_id, 'SETUP', \@SETUP_ORDER);




push @row_refs, show_section_items( $struct_id, 'INIT', \@INIT_ORDER);




my @lines = FORMAT_table( 0, 2, ' ', undef, @row_refs);
ENV_say( 0, \@lines);
}




sub do_build_type($)
{
my ($type,
) = @_;

ENV_say( 1, "Type '$type':");

init_build_types();

my $is_src_type = grep( $type eq $_, @ALL_SRC_TYPES);
my $is_bld_type = grep( $type eq $_, @ALL_BLD_TYPES);
if (!($is_src_type || $is_bld_type || $type eq '.glkb'))
{
if (GBSGLO_exclude_specs( "any$type"))
{
ENV_say( 0, "  Excluded src type '$type'");
} else
{
ENV_sig( W => "Unknown src/bld type '$type'");
$RC = 1;
}
}

my $struct_id = BUILD_read( $GBS::BUILD);

PLUGIN_set_init_envs( $GBS::BUILD);
if ($is_src_type)
{
my $src_type = $type;	    # make more readable
my @row_refs;




{
my $plugin_rel = PLUGIN_get_main_envs( $GBS::BUILD_PLUGIN);
push @row_refs, [ 'Build', '=', "$GBS::BUILD [$GBS::BUILD_PLUGIN ($plugin_rel)]" ];
}

my @BUILD_SRC_ORDER = qw( TYPE ORDER SRC_ABS_PATH INC_TYPES OUT_TYPES OPT_OUT_TYPES OUT_FILES
GLKB INCLUDE_INC INCLUDE_BLD INC_FORMAT SYSINC_FORMAT INC_ABS_PATH
INC_SEARCH_STYLE FLAG_FORMAT SYSFLAG_FORMAT
MODE OPT DEBUGGER MAP MULTI_SRC COMMAND);
push @row_refs, show_subsection_items( $struct_id, 'SRC', $type, \@BUILD_SRC_ORDER);

my $uc_type = uc substr( $src_type, 1);
my @out_types = @{BUILD_get_src_items( $GBS::BUILD, $src_type, 'OUT_TYPES')};




push @row_refs, [ "GBS_BLD_$uc_type", '=', $out_types[0] ];

if ($IS_FULL_GBS)
{
my @option_refs = BUILD_get_options( $GBS::BUILD, 0);





{
my @defaults;
foreach my $ref (@option_refs)
{
my ($opt_name, $default_value_name) = @{$ref};
push @defaults, "$opt_name = $default_value_name";
}
push @row_refs, [ 'Options Defaults', '=', join( ', ', @defaults) ];
}




push @row_refs, [ 'Includes Tree', '=', '' ];
my @incsfile_refs = FLINCS_get_incs_tree( $src_type, $GBS::COMPONENT);
my $separator_printed = 0;
foreach my $ref (@incsfile_refs)
{
my ($filespec, $type, $lines_ref) = @{$ref};
$filespec = GBSGLO_short_filespecs( $filespec);
if ($type eq 'B' && !$separator_printed)
{
push @row_refs, [ '', '', '--' ];
$separator_printed = 1;
}
push @row_refs, [ '', '', $filespec ];
map { push @row_refs, [ '', '', "  $_" ] }
GBSGLO_short_filespecs( @{$lines_ref});
}




push @row_refs, [ 'Flags Tree', '=', '' ];
my @flagsfile_refs = FLINCS_get_flags_tree( $src_type, $GBS::COMPONENT);
$separator_printed = 0;
foreach my $ref (@flagsfile_refs)
{
my ($filespec, $type, $lines_ref) = @{$ref};
$filespec = GBSGLO_short_filespecs( $filespec);
if ($type eq 'B' && !$separator_printed)
{
push @row_refs, [ '', '', '--' ];
$separator_printed = 1;
}
push @row_refs, [ '', '', $filespec ];
if (@{$lines_ref} < 6)
{
map { push @row_refs, [ '', '', "  $_" ] } @{$lines_ref};
} else
{
my @lines = @{$lines_ref};
my $between = @lines - 6;
map { push @row_refs, [ '', '', "  $_" ] } @lines[0..2];
push @row_refs, [ '', '', "  ...($between)" ];
map { push @row_refs, [ '', '', "  $_" ] } @lines[-3..-1];
}
}




my @flags = FLINCS_get_flags( $src_type, $GBS::COMPONENT);
my $flags = ENV_join_quoted_space( @flags);
push @row_refs, [ 'Gen Flags', '=', $flags ];




my $key = "GBS_FLAGS_$uc_type";
my $gbs_flags = ENV_getenv( $key );
push @row_refs, [ $key, '=', $gbs_flags ];
} else
{
push @row_refs, [ '**No more info**', ':', "SubSys '$GBS::SUBSYS' is non Full GBS" ];
}

my @lines = FORMAT_table( 0, 2, ' ', undef, @row_refs);
ENV_say( 0, "Src type:");
ENV_say( 0, \@lines);
}

if ($is_bld_type)
{
my $bld_type = $type;		# make more readable
ENV_say( 0, "  ----")
if ($is_src_type);
my @src_types = @{$SRC_TYPES{ $bld_type}};
ENV_say( 0, "Bld type:");
ENV_say( 0, "  Source(s)\t= @src_types");
}

if ($type eq '.glkb')		# fixed - nonexistng type
{
my @row_refs;




my @search_paths = FLINCS_get_incs( '.glkb', $GBS::COMPONENT);
push @row_refs, [ 'Search Path', '=', '' ];
map { push @row_refs, [ '', '', $_ ] } @search_paths;

ENV_say( 0, "GLKB type:");
ENV_say( 0, FORMAT_table( 0, 2, ' ', undef, @row_refs));
}
}




sub do_audit($)
{
my ($audit,
) =@_;

my @row_refs;

my $plugin = PLUGIN_get_abt_plugin_name( $audit);
my $plugin_rel = PLUGIN_get_main_envs( $plugin);
my @all_src_types = AUDIT_get_src_types( $audit);

ENV_sig( W => "This Audit ($audit) has no sources defined (gbsedit audit.gbs)")
if (!@all_src_types);

ENV_say( 1, "Audit: $audit");

my $struct_id = AUDIT_read( $audit);




push @row_refs, [ 'Plugin', '=', "$plugin ($plugin_rel)" ];
push @row_refs, [ 'src_types', '=', "@all_src_types" ];




push @row_refs, show_section_items( $struct_id, 'SETUP', \@SETUP_ORDER);




push @row_refs, show_section_items( $struct_id, 'CONFIG', undef);




push @row_refs, show_section_items( $struct_id, 'INIT', \@INIT_ORDER);




push @row_refs, show_section_items( $struct_id, 'SUMMARY', undef);




push @row_refs, show_section_items( $struct_id, 'MAINT', undef);




{
my @lines = FORMAT_table( 0, 2, ' ', undef, @row_refs);
ENV_say( 0, \@lines);
}




if ( -e FSPEC_scadef( $plugin)) #	$GBS::SCRIPTS_PATH/plugins/audit/$audit_plugin/scadef
{
ENV_say( 1, "Audit: $audit: scadef: $plugin");
@row_refs = ();

my $struct_id = SCADEF_read( $plugin);




push @row_refs, show_section_items( $struct_id, 'SETUP', \@SETUP_ORDER);




push @row_refs, show_section_items( $struct_id, 'HELPFILES', undef);

push @row_refs, show_section_items( $struct_id, 'OPTION_FORMATS', undef);

push @row_refs, show_section_items( $struct_id, 'LEVELS', undef);

push @row_refs, show_section_items( $struct_id, 'MESSAGES', undef);

push @row_refs, show_section_items( $struct_id, 'METRICS', undef);




my @lines = FORMAT_table( 0, 2, ' ', undef, @row_refs);
ENV_say( 0, \@lines);
}
}




sub do_audit_type($$)
{
my ($audit,
$type,
) = @_;

ENV_say( 1, "Audit: $audit, Type '$type':");

my $plugin = PLUGIN_get_abt_plugin_name( $audit);
my $plugin_rel = PLUGIN_get_main_envs( $plugin);
my @all_src_types = AUDIT_get_src_types( $audit);

my $struct_id = AUDIT_read( $audit);
my $src_type = $type;	    # make more readable
my @row_refs;

my ($out_types_ref, $out_files_ref) =
AUDIT_get_src_items( $audit, $src_type, qw( OUT_TYPES OUT_FILES));
my $uc_type = uc substr( $src_type, 1);




{
push @row_refs, [ 'Audit', '=', "$audit [$plugin ($plugin_rel)]" ];
}

my @AUDIT_SRC_ORDER = qw( OUT_TYPES INC_FORMAT SYSINC_FORMAT FLAG_FORMAT SYSFLAG_FORMAT
MULTI_SRC COMMAND );
push @row_refs, show_subsection_items( $struct_id, 'SRC', $src_type, \@AUDIT_SRC_ORDER);





my @lines = FORMAT_table( 0, 2, ' ', undef, @row_refs);
ENV_say( 0, "Src type:");
ENV_say( 0, \@lines);
}




sub do_tool($)
{
my ($tool,
) = @_;

ENV_say( 1, "Tool: $tool");
my @row_refs;

my $plugin = PLUGIN_get_abt_plugin_name( $tool);
my $plugin_rel = PLUGIN_get_main_envs( $plugin);
my $struct_id = TOOL_read( $tool);




push @row_refs, [ 'Plugin', '=', "$plugin ($plugin_rel)" ];




push @row_refs, show_section_items( $struct_id, 'SETUP', \@SETUP_ORDER);




push @row_refs, show_section_items( $struct_id, 'INIT', \@INIT_ORDER);




push @row_refs, show_section_items( $struct_id, 'RUN', undef);




my @lines = FORMAT_table( 0, 2, ' ', undef, @row_refs);
ENV_say( 0, \@lines);
}




sub show_section_items($$$)
{
my ($struct_id,		# "$STRUCT_LOC/$STRUCT_NAME"
$section,
$names_order_ref,	# May be undef
) = @_;
my @row_refs;




my @names_order;
if (defined $names_order_ref)
{
my %names = map { $_ => 1 } GBSSFILE_get_section_item_names( $struct_id, $section);
foreach my $name (@{$names_order_ref})
{
push @names_order, $name;
delete $names{$name};
}
push @names_order, sort keys %names;
} else
{
@names_order = GBSSFILE_get_section_item_names( $struct_id, $section);
}




push @row_refs, [ $section ];
foreach my $item (@names_order)
{
my $value = GBSSFILE_get_section_items( $struct_id, $section, $item);
if ($item eq 'COMMAND')
{
push @row_refs, show_commands( $value);
} else
{
push @row_refs, show_value( $item, $value);
}
}

return @row_refs;
}




sub show_subsection_items($$$$)
{
my ($struct_id,		# "$STRUCT_LOC/$STRUCT_NAME"
$section,
$section_value,
$names_order_ref,	# May be undef
) = @_;
my @row_refs;




my @names_order;
if (defined $names_order_ref)
{
my %names = map { $_ => 1 } GBSSFILE_get_subsection_item_names( $struct_id, $section, $section_value);
foreach my $name (@{$names_order_ref})
{
push @names_order, $name;
delete $names{$name};
}
push @names_order, sort keys %names;
} else
{
@names_order = GBSSFILE_get_subsection_item_names( $struct_id, $section, $section_value);
}




push @row_refs, [ "$section $section_value" ];
foreach my $item (@names_order)
{

my $value = GBSSFILE_get_subsection_items( $struct_id, $section, $section_value, $item);
if ($item eq 'COMMAND')
{
push @row_refs, show_commands( $value);
} else
{
push @row_refs, show_value( $item, $value);
}
}

return @row_refs;
}




sub show_value($$)
{
my ($item,
$value,
) = @_;
my @row_refs;

if (ref $value)
{
if (ref $value eq 'ARRAY')
{
if (ref $value->[0])
{
foreach my $ref (@{$value})
{
my @values = @{$ref};
my $name = shift @values;
push @row_refs, [ "  $item", '=', "$name => @values" ];
}
} else
{
my @values = @{$value};

push @row_refs, [ "  $item", '=', join( ',', @values) ]
if ("@values" !~ /^\s*$/);
}
} elsif (ref $value eq 'HASH')
{
my @keys = sort keys %{$value};
if (@keys)
{
my @values;
foreach my $key (@keys)
{
my $sub_value = $value->{$key};
if (ref $sub_value eq 'ARRAY')
{
push @values, "$key=(@{$sub_value})";
}
}
push @row_refs, [ "  $item", '=', "@values" ];
}
} else
{
ENV_whisper( 1, "Skipped $item " . ref $value);
}
} else
{
push @row_refs, [ "  $item", '=', $value ]
if (defined $value && $value ne '');
}

return @row_refs;
}




sub show_commands($)
{
my ($cmd_data_refs_ref
) = @_;
my @row_refs;

my $count = 1;
foreach my $command_data_ref (@{$cmd_data_refs_ref})
{

my ($command_type, $command_items_ref, $ok_values, $exec_condition) = @{$command_data_ref};


my $command_type_text = ($command_type eq 'S') ? '*Script' : '*Direct';
push @row_refs, [ "  Command-$count", '=', $command_type_text ];
push @row_refs, [ '', '', "@{$command_items_ref}" ];
push @row_refs, [ '', '', "*OK-values = $ok_values" ]
if ($ok_values ne '0');
if ($exec_condition ne '-')
{
my $operator = substr( $exec_condition, 0, 2);
my $operand = substr( $exec_condition, 2);
if ($operator eq 'F1')
{
$exec_condition = "Exists '$operand'";
} elsif ($operator eq 'F0')
{
$exec_condition = "!Exists '$operand'";
} elsif ($operator eq 'V1')
{
$exec_condition = "EnvVar '$operand'";
} elsif ($operator eq 'V0')
{
$exec_condition = "!EnvVar '$operand'";
} else
{
ENV_sig( F => "Unknown exec_condition operator '$operator'",
"  $exec_condition");
}
push @row_refs, [ '', '', "*Exec-Cond = $exec_condition" ];
}
$count++;
}

return @row_refs;
}




sub do_find($$$$)
{
my ($file,
$name,
$type,
$find_type,
) = @_;

ENV_say( 1, "Find '$file' by '$find_type':");




PLUGIN_set_init_envs( $GBS::BUILD);
my @bld_paths = FLINCS_get_incs( $find_type, $GBS::COMPONENT);
push @bld_paths, FLINCS_get_sysincs( $find_type);
push @bld_paths, "$GBS::ROOT_PATH/sysbuild/makemake_stubs/ALL";
push @bld_paths, "$GBS::ROOT_PATH/sysbuild/makemake_stubs/$GBS::BUILD";

@bld_paths = ENV_perl_paths_noquotes( @bld_paths);




my $count = 0;
my $file_found = 0;
if (@bld_paths)
{
my @row_refs;
foreach my $dir (@bld_paths)
{
if (-d $dir)
{
my $spec = "$dir/$file";
if (-f $spec)
{
push @row_refs, [ '=>', $spec];
$file_found = 1;
$count++;
} else
{
push @row_refs, [ '', $dir];
}
} else
{
push @row_refs, [ 'xx', $dir];
}
}
ENV_say( 0, FORMAT_table( 0, 2, ' ', undef, @row_refs));
ENV_say( 0, "  ** File '$file' not found in paths")
if (!$file_found);
}
ENV_say( 1, "File '$file': $count match(es)");
}




sub do_search($$)
{
my ($dir,
$file,
) = @_;

my $search = $dir;
$search = "bld/$GBS::BUILD"
if ($search eq 'bld');
ENV_say( 1, "Search '$file' in $search':");

$search = '*'
if ($dir eq 'ALL');

my $root_path_l = length $GBS::ROOT_PATH;
my $count = 0;
my @found_files = ENV_glob(  "$GBS::ROOT_PATH/dev/*/comp/*/$search/$file");
push @found_files, ENV_glob( "$GBS::ROOT_PATH/dev/*/comp/*/bld/*/$file")
if ($dir eq 'ALL');
if (@found_files)
{
map { ENV_say( 0, "  ..." . substr( $_, $root_path_l)) } @found_files;
$count = @found_files;
}
ENV_say( 1, "File '$dir/$file': $count match(es)");
}




sub init_build_types()
{



@ALL_SRC_TYPES = BUILD_get_src_types( $GBS::BUILD);
@ALL_INC_TYPES = BUILD_get_inc_types( $GBS::BUILD);
@ALL_BLD_TYPES = BUILD_get_bld_types( $GBS::BUILD);
foreach my $src_type (@ALL_SRC_TYPES)
{
my @bld_types = BUILD_get_src_items( $GBS::BUILD, $src_type, 'OUT_TYPES' );
$BLD_TYPES{$src_type} = [ @bld_types ];


push @{$SRC_TYPES{ shift @bld_types }}, "$src_type (Primary)";
map { push @{$SRC_TYPES{$_}}, $src_type } @bld_types;
}
}


