#!must_be_sourced
#=================================================
#   File:     %FILE%
#   Path:     %PATH%
#   Location: %LOCATION%
#=================================================

echo "GBSALL*: Setup GBS Development environment (%LOCATION%) ***"

#    Place your stuff here...

### EOF ###

