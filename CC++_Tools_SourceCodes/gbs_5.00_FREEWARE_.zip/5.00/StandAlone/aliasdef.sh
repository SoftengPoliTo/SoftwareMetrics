#
#   aliasdef.sh
#   Define GBS StandAlonefunctions
#   This file must be sourced with . (dot)
#
#   List all functions:		declare -f
#   List all function names:	declare -F
#   List function x:		declare -f x
#
#
#   StandAlone
#
function bgpids { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/StandAlone/bgpids.pl $* ; }
function detab { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/StandAlone/detab.pl $* ; }
function filerep { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/StandAlone/filerep.pl $* ; }
function fixeol { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/StandAlone/fixeol.pl $* ; }
function pgrep { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/StandAlone/pgrep.pl $* ; }
function proto { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/StandAlone/proto.pl $* ; }
function win2unix { $GBS_SCRIPTS_PATH/StandAlone/win2unix.sh $* ; }
function wordrep { $GBS_PERL_CMD $GBS_SCRIPTS_PATH/StandAlone/wordrep.pl $* ; }

