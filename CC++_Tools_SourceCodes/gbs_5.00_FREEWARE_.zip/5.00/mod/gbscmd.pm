#=================================================
#
#   gbscmd.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbscmd;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSCMD_get_full_gbs_command
GBSCMD_get_gbs_command
GBSCMD_get_base_command
GBSCMD_get_boot_command
GBSCMD_get_shortcut_command
GBSCMD_get_batch_command_ref
GBSCMD_get_submit_command_ref
GBSCMD_get_subwin_command_ref
GBSCMD_get_os_command
GBSCMD_get_env_command
GBSCMD_set_xtitle
GBSCMD_bg_notifier
GBSCMD_scripts_path_changed
GBSCMD_get_level
);
}




use glo::env;
use glo::shell;
use mod::gbsenv;




sub GBSCMD_get_full_gbs_command($$);
sub GBSCMD_get_gbs_command($$);
sub GBSCMD_get_base_command($@);
sub GBSCMD_get_boot_command($@);
sub GBSCMD_get_shortcut_command($;$$);
sub GBSCMD_get_batch_command_ref($);
sub GBSCMD_get_submit_command_ref($$$);
sub GBSCMD_get_subwin_command_ref($$);
sub GBSCMD_get_os_command($);
sub GBSCMD_get_env_command($$;$);
sub GBSCMD_set_xtitle($);
sub GBSCMD_bg_notifier();
sub GBSCMD_scripts_path_changed();
sub GBSCMD_get_level($);

sub get_build_env($);
sub substitute_args($$$$);




my $IS_WIN32 = ENV_is_win32();
my $IS_LINUX = !$IS_WIN32;

my %ENV_COMMAND_REFS;	    # Cache. Do not inilialize!


my %BUILD_ENVS;





my $WINDIR = ENV_getenv( 'WINDIR');
my $DEFAULT_WIN32_BROWSER   = 'start "" %1%';
my $DEFAULT_WIN32_EDITOR    = "start \"\" \"$WINDIR\\notepad.exe\" %1%";
my $DEFAULT_WIN32_NAVIGATOR = "start \"\" \"$WINDIR\\explorer.exe\" %1%";

my $DEFAULT_LUNIX_BROWSER   = 'firefox $1 &';
my $DEFAULT_LINUX_EDITOR    = 'gedit $1 &';
my $DEFAULT_LINUX_NAVIGATOR = 'xdg-open $1 &';

my %GEN_DEFS = (

GBS_BROWSER	    => [ undef,    $DEFAULT_WIN32_BROWSER,	$DEFAULT_LUNIX_BROWSER ],
GBS_EDITOR	    => [ 'EDITOR', $DEFAULT_WIN32_EDITOR,	$DEFAULT_LINUX_EDITOR ],
GBS_VIEWER	    => [ undef,    $DEFAULT_WIN32_EDITOR,	'less $1' ],
GBS_NAVIGATOR   => [ undef,    $DEFAULT_WIN32_NAVIGATOR,	$DEFAULT_LINUX_NAVIGATOR ],
);

my $OS_GBS_SCRIPTS_PATH = ENV_getenv( 'GBS_SCRIPTS_PATH');
my %GBS_COMMAND_REFS = (



gbs		    => [ 'S', 0, 1, 4, '' ],
gbsaudit	    => [ 'p', 0, 0, 3, '' ],
gbsauditsum	    => [ 'p', 0, 0, 1, '' ],
gbsbg	    => [ 'p', 0, 0, 1, '' ],
gbsbldcheck	    => [ 'p', 0, 0, 1, '' ],
gbsedit	    => [ 's', 0, 0, 4, '' ],
gbsexit	    => [ 's', 0, 1, 0, '' ],
gbsexport	    => [ 'p', 0, 0, 4, '' ],
gbsbuild	    => [ 'p', 0, 0, 3, '' ],
gbsgui	    => [ 'p', 1, 0, 0, '' ],
gbsgui_tkx	    => [ 'p', 1, 0, 0, '' ],
gbshelp	    => [ 'p', 0, 0, 0, '' ],
gbsjob	    => [ 'p', 0, 0, 0, '' ],
gbslocate	    => [ 'S', 0, 1, 4, '' ],
gbsmaint	    => [ 's', 0, 1, 0, '' ],
gbsmake	    => [ 'p', 0, 0, 3, '' ],
gbsmakemake	    => [ 'p', 0, 0, 2, '' ],
gbsman	    => [ 'd', 0, 0, 0, '', [ more => "$OS_GBS_SCRIPTS_PATH/gbsman.txt" ] ],
gbsnew	    => [ 'p', 0, 1, 4, '' ],			#, '' ], case!
gbsscm	    => [ 'p', 0, 0, 4, '' ],
gbssetup	    => [ 's', 0, 1, 0, '' ],
gbsshow	    => [ 'p', 0, 0, 4, '' ],
gbssilo	    => [ 'p', 0, 0, 1, '' ],
gbsstart	    => [ 'p', 0, 1, 4, '' ],
gbsstart_here   => [ 'p', 0, 1, 4, '' ],
gbsstats	    => [ 'p', 0, 0, 1, '' ],
gbsswa	    => [ 's', 0, 1, 4, '' ],
gbsswb	    => [ 's', 0, 1, 4, '' ],
gbsswc	    => [ 's', 0, 1, 4, '' ],
gbsswr	    => [ 's', 0, 1, 4, '' ],
gbssws	    => [ 's', 0, 1, 4, '' ],
gbsswt	    => [ 's', 0, 1, 4, '' ],
gbssysall	    => [ 'p', 0, 0, 2, '' ],
gbssysaudit	    => [ 'p', 0, 0, 2, '' ],
gbssysbuild	    => [ 'p', 0, 0, 2, '' ],
gbssysmake	    => [ 'p', 0, 0, 2, '' ],
gbssystool	    => [ 'p', 0, 0, 2, '' ],
gbsuninstall    => [ 'p', 0, 1, 0, '' ],
gbswhich	    => [ 'p', 0, 0, 1, '' ],
gbsxref	    => [ 'p', 1, 0, 0, '' ],
gbsxref_tkx	    => [ 'p', 1, 0, 0, '' ],
notify	    => [ 'p', 0, 0, 4, '' ],
notify_tkx	    => [ 'p', 1, 0, 0, '' ],
bgpids	    => [ 'p', 0, 0, 0, '/StandAlone' ],
detab	    => [ 'p', 0, 0, 0, '/StandAlone' ],
filerep	    => [ 'p', 0, 0, 0, '/StandAlone' ],
fixeol	    => [ 'p', 0, 0, 0, '/StandAlone' ],
pgrep	    => [ 'p', 0, 0, 0, '/StandAlone' ],
proto	    => [ 'p', 0, 0, 0, '/StandAlone' ],
win2unix	    => [ 'p', 0, 0, 0, '/StandAlone' ],
wordrep	    => [ 'p', 0, 0, 0, '/StandAlone' ],
);

my %GBS_BASE_COMMANDS = (

gbsinit	    => 1,
);

my %GBS_BOOT_COMMANDS = (

boot	    => 1,
define	    => 1,
gbsstart	    => 1,
gbsstart_here   => 1,
);

my %OS_COMMANDS = (

echo	=> 1,
make	=> 0,
more	=> 1,
tail	=> 0,
);




sub GBSCMD_get_full_gbs_command($$)
{
my ($name,
$arg_or_args_ref,   # May be undef
) = @_;
my $command_line;

my $command_items_ref = GBSCMD_get_gbs_command( $name, $arg_or_args_ref);

$command_line = ENV_prepare_command( $command_items_ref);


return $command_line;
}




sub GBSCMD_get_gbs_command($$)
{
my ($name,		    # e.g: gbsaudit
$arg_or_args_ref,   # May be undef
) = @_;
my @command_items;

my @args = ENV_deref( $arg_or_args_ref);





@args = ENV_encode( @args)
if (substr( $name, 0, 3) eq 'gbs');





my $ref = $GBS_COMMAND_REFS{$name};

ENV_sig( F => "No such GBS command '$name'")
if (! defined $ref);

my ($command_type, $needs_gui, $must_be_sourced, undef, $sub_dir) = @{$ref};


my $path = $GBS::SCRIPTS_PATH . $sub_dir;
if ($command_type eq 'p')		# perl
{
push @command_items, "$path/$name.pl";
} elsif ($command_type eq 's')	# script
{
push @command_items, 'source'
if ($IS_LINUX);
push @command_items, "$path/gbssource$GBS::SHELL_FILETYPE", "$name.pl";
} elsif ($command_type eq 'S')	# script
{
push @command_items, 'source'
if ($IS_LINUX);
push @command_items, "$path/$name$GBS::SHELL_FILETYPE";
} elsif ($command_type eq 'd')	# defined
{
push @command_items, @{$ref->[5]};	# $special_command_ref
} else
{
ENV_sig( F => "Impossible command_type '$command_type'");
}
push @command_items, @args;

ENV_sig( E => "*** Cannot startup $name ***",
"- Perl Tkx Package is not available")
if ($needs_gui && !GBSENV_gui_available());



return (wantarray) ? @command_items : \@command_items;
}





sub GBSCMD_get_base_command($@)
{
my ($name,
@args,
) = @_;
my $command;

ENV_sig( F => "No such GBS Base command '$name'")
if (! exists $GBS_BASE_COMMANDS{$name});

my @command_items;

push @command_items, "$GBS::BASE_PATH/$name$GBS::SHELL_FILETYPE", @args;
$command = ENV_prepare_command( \@command_items);

return $command;
}





sub GBSCMD_get_boot_command($@)
{
my ($name,
@args,
) = @_;
my $command;

ENV_sig( F => "No such GBS Boot command '$name'")
if (! exists $GBS_BOOT_COMMANDS{$name});

my @command_items;

push @command_items, "$GBS::BOOT_PATH/$name$GBS::SHELL_FILETYPE", @args;
$command = ENV_prepare_command( \@command_items);

return $command;
}

my $SHORTCUT_TITLE_FORMAT = 'GBS %s [%s]';
my $COMMAND_SPEC = ($IS_WIN32) ? "$ENV{WINDIR}\\system32\\cmd.exe" : 'xterm';
my $WIN32_SHORTCUT_ARGS_FORMAT = '/K %s';
my $LINUX_SHORTCUT_ARGS_FORMAT = '-title "GBS xterm" -geometry 100x40+100+100 -bg white -fg darkblue -sb -ls -e "bash %s; bash -login"';

my $SHORTCUT_ARGS_FORMAT = ($IS_WIN32) ? $WIN32_SHORTCUT_ARGS_FORMAT : $LINUX_SHORTCUT_ARGS_FORMAT;

my $SETUP_ACTION = ($IS_WIN32) ? 'exec gbssetup.bat' : 'source gbssetup.sh';
my $UNINSTALL_ACTION = 'perl gbsuninstall.pl';
my %SHORTCUT_REFS = (

Startup	=> [ 'Application', 'gbs',		'Startup a GBS Command Window [%s]' ],
Help	=> [ 'Link',	    'doc/index.html',	'Startup the GBS Help [%s]' ],
Setup	=> [ 'Application', $SETUP_ACTION,     	'Startup the GBS Setup function [%s]' ],
Uninstall	=> [ 'Application', $UNINSTALL_ACTION,  'Startup the GBS Uninstall function [%s]' ],
);





sub GBSCMD_get_shortcut_command($;$$)
{
my ($shortcut_name,		    # Startup Help Setup Uninstall
$gbs_scripts_path,	    # Optional. Default = $GBS::SCRIPTS_PATH
$shortcut_rel,		    # Optional. cur or beta.
) = @_;
my ($shortcut_title, $shortcut_type, $command_spec, $command_args);



$gbs_scripts_path = $GBS::SCRIPTS_PATH
if (!defined $gbs_scripts_path);
my $gbs_rel = ENV_parent_dir( $gbs_scripts_path, -1);
$shortcut_rel = ($gbs_rel =~ /beta/) ? 'beta' : 'cur'
if (!defined $shortcut_rel);

$shortcut_title = sprintf( $SHORTCUT_TITLE_FORMAT, $shortcut_name, $shortcut_rel);

if (wantarray)
{
($shortcut_type, my $action, my $comment) = @{$SHORTCUT_REFS{$shortcut_name}};
if ($shortcut_type eq 'Application')
{
my $define_file = ($IS_WIN32) ? 'define.bat' : 'pre_define.sh';
my $os_define_spec = ENV_enquote( ENV_os_paths( "$GBS::BOOT_PATH/$define_file"));    # Note: shortcuts do no expand EnvVars

$command_spec = $COMMAND_SPEC;		    # cmd/xterm
$command_args = sprintf( $SHORTCUT_ARGS_FORMAT, "$os_define_spec $shortcut_rel $action");
} else	# $shortcut_type eq 'Link'
{
$command_spec = "$gbs_scripts_path/$action";
$command_args = '';
}


return ($shortcut_title, $shortcut_type, $command_spec, $command_args);
} else
{
return $shortcut_title;
}
}








sub GBSCMD_get_batch_command_ref($)
{
my ($command_items_ref,	# $command_name, @ags
) = @_;
my $batch_cmd_ref;



my $gbs_batch = get_build_env( 'GBS_BATCH');
if ($gbs_batch ne '')
{
my $command_line = ENV_prepare_command( $batch_cmd_ref);
$batch_cmd_ref = ENV_split_quoted_space( $gbs_batch);
substitute_args( $batch_cmd_ref, '1', $command_line, 1);
} else
{
$batch_cmd_ref = $command_items_ref;
}

return $batch_cmd_ref;
}








sub GBSCMD_get_submit_command_ref($$$)
{
my ($command_heading,
$job_file_spec,
$os_log_file,
) = @_;
my $submit_cmd_ref;


$submit_cmd_ref = GBSCMD_get_gbs_command( gbsjob => $job_file_spec);
my $gbs_submit = get_build_env( 'GBS_SUBMIT');
if ($gbs_submit ne '')
{
my $command_line = ENV_prepare_command( $submit_cmd_ref);
$submit_cmd_ref = ENV_split_quoted_space( $gbs_submit);
substitute_args( $submit_cmd_ref, '1', $command_line, 1);
substitute_args( $submit_cmd_ref, '2', $command_heading, 0);
substitute_args( $submit_cmd_ref, '3', $os_log_file, 0);
}



return $submit_cmd_ref;
}








sub GBSCMD_get_subwin_command_ref($$)
{
my ($command_heading,
$job_file_spec) = @_;
my $subwin_cmd_ref;

$subwin_cmd_ref = GBSCMD_get_gbs_command( gbsjob => $job_file_spec);
my $gbs_subwin = get_build_env( 'GBS_SUBWIN');
if ($gbs_subwin ne '')
{
my $command_line = ENV_prepare_command( $subwin_cmd_ref);
$subwin_cmd_ref = ENV_split_quoted_space( $gbs_subwin);
substitute_args( $subwin_cmd_ref, '1', $command_line, 1);
substitute_args( $subwin_cmd_ref, '2', $command_heading, 0);
}



return $subwin_cmd_ref;
}




sub GBSCMD_get_os_command($)
{
my ($unix_builtin_command) = @_;	# e.g.: make more echo tail
my $os_command;

$os_command = get_build_env( 'GBS_' . uc $unix_builtin_command);
if ($os_command eq '')
{
my $is_same = $OS_COMMANDS{$unix_builtin_command};
if (defined $is_same)
{
if ($IS_WIN32)
{
$os_command = ($is_same) ? $unix_builtin_command : "$OS_GBS_SCRIPTS_PATH/win32utils/$unix_builtin_command.exe";
} else
{
$os_command = $unix_builtin_command;
}
} else
{
ENV_sig( F => "Unknown os command '$unix_builtin_command'");
}
}

$os_command =~ s!/!\\!g
if ($IS_WIN32);

return $os_command;
}




sub GBSCMD_get_env_command($$;$)
{
my ($env_name,	    # GBS_VIEWER, GBS_BROWSER, GBS_EDITOR, GBS_NAVIGATOR
$filespec,
$options_or_ref,    # may be undef or ''
) = @_;
my @command_items;


my @options = ENV_deref( $options_or_ref);
@options = ()
if ("@options" eq '');




my $env_command_ref = $ENV_COMMAND_REFS{$env_name};

if (defined $env_command_ref)
{
@command_items = @{$env_command_ref};
} else
{
my $command_line = ENV_getenv( $env_name);
if ($command_line eq '')
{



my ($sec_env_name, $win_default, $unix_default) = @{$GEN_DEFS{$env_name}};

$command_line = ENV_getenv( $sec_env_name)
if (defined $sec_env_name);
$command_line = ($IS_WIN32) ? $win_default : $unix_default
if ($command_line eq '');
}

@command_items = ENV_split_quoted_space( $command_line);
$ENV_COMMAND_REFS{$env_name} = [ @command_items ];
}





$filespec = ENV_os_paths( $filespec);
substitute_args( \@command_items, '1', $filespec, 1);
if (@options)
{
if ($IS_WIN32)
{
push @command_items, @options;
} else
{
my $last_item = $command_items[-1];
if ($last_item eq '&')
{
$command_items[-1] = shift @options;
push @command_items, @options, '&';
} else
{
push @command_items, @options;
}
}
}
@command_items = ENV_enquote( @command_items);


return (wantarray) ? @command_items : "@command_items";
}




sub GBSCMD_set_xtitle($)
{
my ($title) = @_;
my @commands;

if (ENV_is_interactive() && ! ENV_is_gui())
{
$title =~ s!/!\\!g
if ($IS_WIN32);
@commands = SHELL_xtitle( $title);
}


return @commands;
}





sub GBSCMD_bg_notifier()
{
my $gbs_bg_notifier = get_build_env( 'GBS_BG_NOTIFIER');

return $gbs_bg_notifier;
}




sub get_build_env($)
{
my ($base_env) = @_;
my $env_value;

my $env_name;
my $gbs_build = uc $GBS::BUILD;
my $gbs_audit = uc $GBS::AUDIT;

my $key = join( '_', $base_env, $gbs_build, $gbs_audit);
my $ref = $BUILD_ENVS{$key};
if (defined $ref)
{
($env_name, $env_value) = @{$ref};

} else
{
my @envs;
if ($gbs_audit ne '')
{
push @envs, "${base_env}_${gbs_build}_${gbs_audit}";
push @envs, "${base_env}_${gbs_audit}";
} else
{
push @envs, "${base_env}_${gbs_build}";
}
push @envs, "${base_env}";

$env_name = '';
foreach my $env (@envs)
{

$env_value = ENV_getenv( $env);
if ($env_value ne '')
{
$env_name = $env;
last;
}
}
if ($env_name ne '')
{
ENV_say( 1, "$env_name EnvVar defined");
$BUILD_ENVS{$key} = [ $env_name, $env_value ];
}
}

return $env_value;
}




sub substitute_args($$$$)
{
my ($strings_ref,	    # IN & OUT!
$name,
$value,
$is_mandatory,
) = @_;


my $token_name = ($IS_WIN32) ? "\%$name\%" : "\$$name";
my $token = quotemeta $token_name;
my $count = 0;

foreach my $string (@{$strings_ref})
{
$count += $string =~ s/$token/$value/g;
}

if ($count == 0 && $is_mandatory)
{
ENV_sig( EE => "Argument '$token_name' required in string '@{$strings_ref}'");
}
}




sub GBSCMD_scripts_path_changed()
{
$OS_GBS_SCRIPTS_PATH = ENV_getenv( 'GBS_SCRIPTS_PATH');
}





sub GBSCMD_get_level($)
{
my ($command,	# e.g.: gbsbuild
) = @_;
my $level;	#   $level: 0 = 0, 1 = boot, 2 = subsys 3 = component 4 = any

my $ref = $GBS_COMMAND_REFS{$command};

if (defined $ref)
{
$level = $ref->[3];
} else
{
ENV_sig( F => "Unknowmn GBS command '$command'");
}

return $level;
}

1;


