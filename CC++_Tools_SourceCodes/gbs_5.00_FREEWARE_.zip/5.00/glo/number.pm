#=================================================
#
#   number.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::number;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
NUMBER_set_locale
NUMBER_format_numeric
NUMBER_format_monetary
);
}




use POSIX;





sub NUMBER_set_locale($$);
sub NUMBER_format_numeric($);
sub NUMBER_format_monetary($);




my $DECIMAL_POINT = ',';
my $THOUSANDS_SEP = '.';
{

my $locale_values_ref = POSIX::localeconv();

$DECIMAL_POINT = $locale_values_ref->{mon_decimal_point}
if (exists $locale_values_ref->{mon_decimal_point});
$THOUSANDS_SEP = $locale_values_ref->{mon_thousands_sep}
if (exists $locale_values_ref->{mon_thousands_sep});
}




sub NUMBER_set_locale($$)
{
my ($decimal_point,	    # undef == OK
$thousands_sep,	    # undef == OK
) = @_;
my ($old_decimal_point, $old_thousands_sep) = ( $DECIMAL_POINT, $THOUSANDS_SEP );

$DECIMAL_POINT = $decimal_point
if (defined $decimal_point);
$THOUSANDS_SEP = $thousands_sep
if (defined $thousands_sep);

return ($old_decimal_point, $old_thousands_sep);
}




sub NUMBER_format_numeric($)
{
my ($number,    # integer
) = @_;
my $sign = '';
my $string;


if ($number < 0)
{
$number = abs($number);
$sign = '-';
}
$string = "$number";

if ($THOUSANDS_SEP && $number >= 1000)
{

$string = '0' x (3 - (length( $string) % 3)) . $string;


$string = join( $THOUSANDS_SEP, grep {$_ ne ''} split( /(...)/, $string));


$string =~ s/^0+\Q$THOUSANDS_SEP\E?//;

$string = '0'
if ($string eq '');
}

return "$sign$string";
}




sub NUMBER_format_monetary($)
{
my ($number,    # integer with assumed decimalpoint
) = @_;
my $string;

return $string;
}

1;
