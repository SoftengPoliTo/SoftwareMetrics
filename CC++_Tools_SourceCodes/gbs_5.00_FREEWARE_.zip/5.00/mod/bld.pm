#=================================================
#
#   bld.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::bld;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
BLD_init
BLD_get_commands
);
}




use glo::env;
use mod::gbsenv;
use mod::build;
use mod::audit;
use mod::bldopt;
use mod::gbsbgjob;
use mod::fspec;




sub BLD_init();
sub BLD_get_commands($$$);

sub get_commands($$$$);
sub delete_out_files($$$$$);








my $MAP_FILE_TYPE = '.map';




my $SCADEF_IS_PRESENT;

my $FOR_AUDIT;
my $VIA_FORMAT;





my @OUT_TYPES;
my @OPT_OUT_TYPES;
my @OUT_FILES;





sub BLD_init()
{
my $options_banner;


$FOR_AUDIT = GBSENV_doing_audit();

$options_banner = BLDOPT_init();

if ($FOR_AUDIT)
{
$SCADEF_IS_PRESENT = (-e FSPEC_scadef( $GBS::AUDIT_PLUGIN)) ? 1 : 0;
($VIA_FORMAT, undef) = AUDIT_get_section_items( $GBS::AUDIT, SETUP => 'VIA_FORMAT');
} else
{
($VIA_FORMAT, undef) = BUILD_get_section_items( $GBS::BUILD, SETUP => 'VIA_FORMAT');
}

return $options_banner;
}







sub BLD_get_commands($$$)
{
my ($component,
$in_files_ref,
$command_line_flags_ref,
) = @_;
my @bgjob_refs;

my %files_by_type;

foreach my $in_file (@{$in_files_ref})
{
my ($file_name, $src_type) = ENV_split_spec_nt( $in_file);

push @{$files_by_type{$src_type}}, $file_name;
}

foreach my $src_type (sort keys %files_by_type)
{
push @bgjob_refs, get_commands( $component, $src_type, $files_by_type{$src_type}, $command_line_flags_ref);
}

return @bgjob_refs;
}






sub get_commands($$$$)
{
my ($component,
$src_type,
$in_file_names_ref,
$command_line_flags_ref,
) = @_;
my @bgjob_refs;




my $src_dir = "$GBS::COMP_PATH/$component/src";

my $out_file_path;
my $gen_type;
my $out_filetype;
my $map_file_spec;
my $src_abs_path;	    # bool
my $gen_type_verb;
my $unix_style_search;  # bool
my $glkb_type;	    # 'LIST' or 'FILE'
my ($multi_src_type, $multi_src_printf_string);
if ($FOR_AUDIT)
{
$out_file_path	= "../aud/$GBS::AUDIT/$GBS::BUILD";
$gen_type	= '';
$out_filetype	= AUDIT_get_primary_out_type( $GBS::AUDIT, $src_type);
$src_abs_path	= 0;
$gen_type_verb	= 'Auditing';

$unix_style_search = (BUILD_get_src_items( $GBS::BUILD, $src_type, 'INC_SEARCH_STYLE') eq 'UNIX') ? 1 : 0;
$glkb_type	   = undef;	# not used
($multi_src_type, $multi_src_printf_string) = AUDIT_get_src_items( $GBS::AUDIT, $src_type, 'MULTI_SRC');

@OUT_TYPES	= AUDIT_get_src_items( $GBS::AUDIT, $src_type, 'OUT_TYPES');
@OPT_OUT_TYPES	= ();
@OUT_FILES	= AUDIT_get_src_items( $GBS::AUDIT, $src_type, 'OUT_FILES');
if ($SCADEF_IS_PRESENT)
{
push @OUT_TYPES,	 qw( .garg .gerr .gmet .gout .html );
push @OPT_OUT_TYPES, qw( .log.html );
}
} else
{
$out_file_path	= "../bld/$GBS::BUILD";
$gen_type	= BUILD_get_src_items( $GBS::BUILD, $src_type, 'TYPE')->[0];
$out_filetype	= BUILD_get_primary_bld_type( $GBS::BUILD, $src_type);
$src_abs_path	= BUILD_get_src_items( $GBS::BUILD, $src_type, 'SRC_ABS_PATH');
$gen_type_verb	= BUILD_get_type_verb( $gen_type);	# E.g.: Compiling, Linking

$unix_style_search = undef;	# not used
($glkb_type)	   = BUILD_get_src_items( $GBS::BUILD, $src_type, 'GLKB'); # undef if not glkb
($multi_src_type, $multi_src_printf_string) = BUILD_get_src_items( $GBS::BUILD, $src_type, 'MULTI_SRC');

@OUT_TYPES	= BUILD_get_src_items( $GBS::BUILD, $src_type, 'OUT_TYPES');
@OPT_OUT_TYPES	= BUILD_get_src_items( $GBS::BUILD, $src_type, 'OPT_OUT_TYPES');
@OUT_FILES	= BUILD_get_src_items( $GBS::BUILD, $src_type, 'OUT_FILES');
}




{
my @env_def_refs = BLDOPT_get_envs_settings( $GBS::SUBSYS, $component, $src_type);

foreach my $ref (@env_def_refs)	# ( sysflags flags incs sysincs)
{
my ($envvar_name, @envvar_values) = @{$ref};
push @bgjob_refs, GBSBGJOB_set( $envvar_name => "@envvar_values");

}
}

my $src_files;
foreach my $file_name (@{$in_file_names_ref})
{



my $src_file;
my $glkb_out_filespec;
my @out_del_files;
my @pos_args;
my @gen_args;
if ($multi_src_type eq 'NO')
{
$src_file = "$file_name$src_type";
$src_files = $src_file;
my $in_filespec = ENV_enquote( ($src_abs_path) ? "$src_dir/$src_file" : $src_file);
my $out_file_name = ($FOR_AUDIT) ? $src_file : $file_name;
my $out_file_base = "$out_file_path/$out_file_name";
my $out_filespec = "$out_file_base$out_filetype";
$glkb_out_filespec = $out_filespec;




@out_del_files = delete_out_files( $gen_type, $file_name, $src_type, $out_file_path, $out_filetype);




@pos_args = ($file_name, $in_filespec, $out_filespec, $out_file_path, $out_filetype);

my $map_file_spec = ($gen_type eq 'glk') ? "$out_file_base$MAP_FILE_TYPE" : undef;
@gen_args = ( @{$command_line_flags_ref}, BLDOPT_get_options_flags( $src_type, $map_file_spec) );




push @bgjob_refs, GBSBGJOB_echo( "** $gen_type_verb ${GBS::SUBSYS}:$component:$src_file to $GBS::BUILD:$file_name$out_filetype...");
} else	# ($multi_src_type eq 'YES' or 'COMMA_LIST')
{



@out_del_files = map { delete_out_files( $gen_type, $_, $src_type, $out_file_path, $out_filetype) } @{$in_file_names_ref};




my @plain_file_specs = map { "$_$src_type" } @{$in_file_names_ref};
my @file_specs = @plain_file_specs;
@file_specs = map { ENV_enquote( "$src_dir/$_") } @file_specs
if ($src_abs_path);
@file_specs = map { sprintf( $multi_src_printf_string, $_) } @file_specs
if ($multi_src_printf_string);
my $file_specs;
if ($multi_src_type eq 'YES')
{
$file_specs = "@file_specs";
} else  # 'COMMA_LIST'
{
$file_specs = join( ',', @file_specs);
}
$src_files = "@plain_file_specs";

@pos_args = ('file_name', "\"$file_specs\"", 'out_filespec', $out_file_path, $out_filetype);

@gen_args = ( @{$command_line_flags_ref}, BLDOPT_get_options_flags( $src_type, undef) );




push @bgjob_refs, GBSBGJOB_echo( "** $gen_type_verb ${GBS::SUBSYS}:$component:",
"   @plain_file_specs",
"   to $GBS::BUILD...");
}

my $command_data_refs_ref;

if ($FOR_AUDIT)
{
$command_data_refs_ref = AUDIT_get_src_command_data_refs_exp(  $GBS::AUDIT,  $src_type, \@pos_args, \@gen_args);
} else
{
$command_data_refs_ref = BUILD_get_src_command_data_refs_exp( $GBS::BUILD, $src_type, \@pos_args, \@gen_args);
}




if ($FOR_AUDIT)
{
if ($SCADEF_IS_PRESENT)
{



push @bgjob_refs, GBSBGJOB_sca( $src_files, $unix_style_search, undef, $command_data_refs_ref);
} else
{



push @bgjob_refs, GBSBGJOB_exec( $src_files, undef, \@out_del_files, $command_data_refs_ref); # $must_print_commands
}
} else
{
if (defined $glkb_type)
{
my $glkb_args_ref = [ $glkb_type, $src_file, $glkb_out_filespec, $VIA_FORMAT ];
push @bgjob_refs, GBSBGJOB_glkb( $src_files, undef, $glkb_args_ref, \@out_del_files, $command_data_refs_ref);	    # $must_print_commands
} else
{
push @bgjob_refs, GBSBGJOB_exec( $src_files, undef, \@out_del_files, $command_data_refs_ref);			    # $must_print_commands
}
}
last
if ($multi_src_type ne 'NO');
}

return @bgjob_refs;
}





sub delete_out_files($$$$$)
{
my ($gen_type,
$file_name,
$src_type,
$out_file_path,
$out_filetype,
) = @_;
my @out_del_files;

my $out_file_base = "$out_file_path/$file_name",
my $out_keep_file;
if ($FOR_AUDIT)
{
$out_keep_file	= "$out_file_base.gout"
if ($SCADEF_IS_PRESENT);
} else
{
if ($gen_type eq 'glk')
{
$out_keep_file = "$out_file_base$MAP_FILE_TYPE";
} elsif ($gen_type eq 'glt')
{
$out_keep_file = "$out_file_base$out_filetype";	    # .log file
} else
{

}
}




@out_del_files  = map { "$out_file_base$_" } (@OUT_TYPES, @OPT_OUT_TYPES);
push @out_del_files, map { "$out_file_path/$_" } @OUT_FILES;
push @out_del_files, $out_keep_file
if (defined $out_keep_file);


unlink @out_del_files;




@out_del_files = grep( $_ ne $out_keep_file, @out_del_files)
if (defined $out_keep_file);



return @out_del_files;
}

1;

