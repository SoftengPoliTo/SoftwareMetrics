#=================================================
#
#   profile.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::profile;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
PROFILE_open
PROFILE_get_all
PROFILE_get
PROFILE_set
PROFILE_add_to_list
PROFILE_remove_from_list
PROFILE_write
PROFILE_close
);
}




use glo::env;
use glo::list;
use glo::slurp;
use glo::spit;
use glo::shell;




sub PROFILE_open($);
sub PROFILE_get_all();
sub PROFILE_get($);
sub PROFILE_set($$);
sub PROFILE_add_to_list($$);
sub PROFILE_remove_from_list($$);
sub PROFILE_write();
sub PROFILE_close($);

sub verify_file_open($);








my $IS_WIN32 = ENV_is_win32();
my $IS_DEVELOPMENT = ENV_is_development();

my $GBS_SCRIPTS_PATH_VALUE = ($IS_WIN32) ? '%GBS_SCRIPTS_ROOT%\%GBS_SCRIPTS_REL%' :
'"$GBS_SCRIPTS_ROOT/$GBS_SCRIPTS_REL"';



my @DATA_ORDER_REFS = (


[ GBS_SCRIPTS_ROOT	=> 1 ],
[ GBS_SCRIPTS_REL	=> 0 ],
[ GBS_SCRIPTS_PATH  => 1 ],	    # Fixed with $$GBS_SCRIPTS_PATH_VALUE
[ GBS_SITE        	=> 0 ],
[ GBS_LOG_PATH   	=> 1 ],	    # Keep for old releases
[ GBS_LOG_ROOT   	=> 1 ],
[ GBS_EDITOR     	=> 2 ],
[ GBS_BROWSER     	=> 2 ],
[ GBS_VIEWER     	=> 2 ],
[ GBS_NAVIGATOR    	=> 2 ],
[ GBS_BEEPS     	=> 0 ],
[ GBS_ADMINISTRATOR => 0 ],
[ GBS_INTEGRATOR    => 0 ],
);
my %DATA_DEFS = map { $_->[0] => $_->[1] } @DATA_ORDER_REFS;


my @DATA_DEFAULT_REFS = (

[ GBS_BEEPS     	=> 'YES' ],
);




my $FILE_IS_OPEN = 0;




my $GBS_PROFILE_FILE = '';		    # $GBS::BASE_PATH/profile.dat
my %DATA_VALUES;

my $FILE_MODIFIED;




sub PROFILE_open($)
{
my ($base_path) = @_;	# GBS::BASE_PATH if not defined
my $exists = 0;

verify_file_open( 0);




$base_path = ENV_getenv_perl_path( 'GBS_BASE_PATH')
if (!defined $base_path);
$GBS_PROFILE_FILE = "$base_path/profile$GBS::SHELL_FILETYPE";
%DATA_VALUES = map { $_ => ''} keys %DATA_DEFS;
$DATA_VALUES{GBS_SCRIPTS_PATH} = $GBS_SCRIPTS_PATH_VALUE;
$FILE_MODIFIED = 0;

if (-f $GBS_PROFILE_FILE)
{



my $setenv_re = ($IS_WIN32) ? qr/^s*set\s+([^=]+)=(.*)$/ :
qr/^s*\\?export\s+([^=]+)="?([^"]*)"?$/;
my $comment_re = ($IS_WIN32) ? qr/^::/ :
qr/\s*#/;

$exists = 1;

foreach my $line (SLURP_file( $GBS_PROFILE_FILE))
{
next if ($line eq '' || $line =~ $comment_re);
my ($name, $value) = $line =~ $setenv_re;
if (defined $name)
{
my $type = $DATA_DEFS{$name};
if (defined $type)
{

if ($type == 1)	    # os_filespec
{
$value = ENV_perl_canon_paths( $value);
} elsif ($type == 2)    # exec definition
{
$value = ENV_perl_canon_paths( $value);
if ($IS_WIN32)
{
$value =~ s/%%(\d+)%%/%$1%/g;	    # %%1%% -> %1% (set by SHELL_setenv)
} else
{
$value =~ s/\\\$(\d+)/\$$1/g;	    # \$1   -> $1 (set by SHELL_setenv)
}
}

$DATA_VALUES{$name} = $value;
} else
{
ENV_sig( E => "Invalid EnvVar name '$name'", $GBS_PROFILE_FILE, $line);
}
} else
{
ENV_sig( E => "Invalid line", $GBS_PROFILE_FILE, $line);
}
}
} else
{



foreach my $ref (@DATA_DEFAULT_REFS)
{
my ($envname, $default) = @{$ref};
$DATA_VALUES{$envname} = $default;
}
$FILE_MODIFIED = 1;
}
$FILE_IS_OPEN = 1;

return $exists;
}




sub PROFILE_get_all()
{
verify_file_open( 1);

return %DATA_VALUES;
}




sub PROFILE_get($)
{
my ($env_name) = @_;
my $value = $DATA_VALUES{$env_name};

verify_file_open( 1);

ENV_sig( F => "No such key '$env_name}")
if (!defined $value);

return $value;
}




sub PROFILE_set($$)
{
my ($env_name,
$value,
) = @_;
my $old_value = $DATA_VALUES{$env_name};

verify_file_open( 1);

ENV_sig( F => "No such key '$env_name'")
if (!defined $old_value);

if ($env_name eq 'GBS_SCRIPTS_PATH')
{
ENV_sig( F => "You cannot set GBS_SCRIPTS_PATH ($value)");
} elsif ($env_name eq 'GBS_SCRIPTS_REL')
{
if ($value eq 'beta')
{
if ($IS_DEVELOPMENT)
{
ENV_sig( W => "Changing GBS_REL_PATH to '$value' in Development");
} else
{
ENV_sig( F => "You cannot set GBS_REL_PATH to '$value'");
}
}
}

$DATA_VALUES{$env_name} = $value;
$FILE_MODIFIED = 1
if ($value ne $old_value);

return $old_value;
}




sub PROFILE_add_to_list($$)
{
my ($env_name,
$value,
) = @_;
my $old_value = $DATA_VALUES{$env_name};

verify_file_open( 1);

ENV_sig( F => "No such key '$env_name}")
if (!defined $old_value);
ENV_sig( F => "You cannot add GBS_SCRIPTS_PATH ($value)")
if ($env_name eq 'GBS_SCRIPTS_PATH');

my @values = split( ',', $old_value);
my @new_values = LIST_unique( [ @values, $value ]);
if ("@new_values" ne "@values")
{
$DATA_VALUES{$env_name} = join( ',', sort @new_values);
$FILE_MODIFIED = 1;
}

return $old_value;
}




sub PROFILE_remove_from_list($$)
{
my ($env_name,
$value,
) = @_;
my $old_value = $DATA_VALUES{$env_name};

verify_file_open( 1);

ENV_sig( F => "No such key '$env_name}")
if (!defined $old_value);
ENV_sig( F => "You can only remove GBS_ADMINISTRATOR or INTEGRATOR ($value)")
if ($env_name ne 'GBS_ADMINISTRATOR' && $env_name ne 'GBS_INTEGRATOR');

my @values = split( ',', $old_value);
my @new_values = grep( $_ ne $value, @values);
if (@new_values != @values)
{
$DATA_VALUES{$env_name} = join( ',', @new_values);
$FILE_MODIFIED = 1;
}

return $old_value;
}




sub PROFILE_write()
{
my $was_modified = $FILE_MODIFIED;

verify_file_open( 1);

if ($FILE_MODIFIED)
{



$DATA_VALUES{GBS_SCRIPTS_PATH} = $GBS_SCRIPTS_PATH_VALUE;

ENV_whisper( 1, "Writing $GBS_PROFILE_FILE...");
my $comment = ($IS_WIN32) ? '::' : '# ';
my @lines;
push @lines,
$comment,
"$comment  $GBS_PROFILE_FILE",
"$comment  Define GBS EnvVars",
$comment;
foreach my $ref (@DATA_ORDER_REFS)
{
my ($name, $type) = @{$ref};
my $value = $DATA_VALUES{$name};
if ($type == 1 || $type == 2)
{
$value = ENV_os_paths( $value);
}
push @lines, SHELL_setenv( $name, $value);
}
push @lines,
$comment,
"$comment EOF";

foreach my $line (@lines)
{
$line =~ s/s\+$//;	    # remove trailing blanks
}

SPIT_file_nl( $GBS_PROFILE_FILE, \@lines);
$FILE_MODIFIED = 0;
}

return $was_modified;
}




sub PROFILE_close($)
{
my ($must_write) = @_;
my $was_modified = $FILE_MODIFIED;

verify_file_open( 1);

if ($must_write)
{
PROFILE_write();
}

$GBS_PROFILE_FILE = '';
%DATA_VALUES = ();
$FILE_IS_OPEN = 0;

return $was_modified;
}




sub verify_file_open($)
{
my ($wanted_state) = @_;

if ($wanted_state != $FILE_IS_OPEN)
{
my $state = qw( Closed Open)[$FILE_IS_OPEN];
ENV_sig( F => "Profile File '$GBS_PROFILE_FILE' is $state");
}

return;
}

1;
