#=================================================
#
#   path.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::path;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
PATH_search_file
PATH_file_exists
);
}








sub PATH_search_file($$);
sub PATH_file_exists($);




my %FILES;







sub PATH_search_file($$)
{
my ( $file,
$dirs_ref,
) = @_;
my $found_spec = '';

foreach my $dir (@{$dirs_ref})
{
my $spec = "$dir/$file";
if (PATH_file_exists( $spec))
{
$found_spec = $spec;
last;
}
}

return $found_spec;
}




sub PATH_file_exists($)
{
my ($filespec) = @_;
my $exists = 0;

$exists = $FILES{$filespec};
if (!defined $exists)
{
$exists = (-e $filespec) ? 1 : 0;
$FILES{$filespec} = $exists;
}

return $exists;
}

1;
