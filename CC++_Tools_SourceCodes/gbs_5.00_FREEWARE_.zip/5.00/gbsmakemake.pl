#=================================================
#
#   gbsmakemake.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSMAKEMAKE @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::genopt;
use mod::gbsenv;
use mod::gbsglo;
use mod::validate;
use mod::makemake;














$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( 'build');













{
my @genopts = (
[ '<*>',    'components',	'sao', "", ". == current component, <empty> == all" ],
[ 'i',	    'ignore_errors',	'bso',  0, "Continue generation after error(s)" ],
);
GENOPT_set_optdefs( 'gbsmakemake', \@genopts,
'Make make-file(s) for the current SubSystem',
undef);
GENOPT_parse();
}
my @COMPONENTS = GENOPT_get( 'components');
my $IGNORE_ERRORS = GENOPT_get( 'ignore_errors');




ENV_setenv( GBS_IGNORE_ERRORS => $IGNORE_ERRORS);




VALIDATE_subsys_full_gbs();
VALIDATE_build();




my @SELCOMP;
{
if (@COMPONENTS)
{
ENV_sig( W => "Makemake of single component(s) may compromise the integrity of the 'make'.");
my %dup_components;
foreach my $component (@COMPONENTS)
{
if ($component eq '.')
{
$component = ENV_getenv( "GBS_COMPONENT");
ENV_sig( EE => "No current component")
if ($component eq '');
} else
{
ENV_sig( EE => "No such component '$component'")
if (! defined $GBS::ALL_COMPONENTS{$component});
}

if (GBSGLO_component_does_build( $GBS::SUBSYS, $component, $GBS::BUILD))
{
if (exists $dup_components{$component})
{
ENV_say( 1, "Duplicate Component '$component' - Skipped");
} else
{
push @SELCOMP, $component;
$dup_components{$component} = 1;
}
} else
{
ENV_sig( W => "Component '$component' does not generate for Build '$GBS::BUILD' - Skipped");
}
}
}
}





$RC = MAKEMAKE_main( @SELCOMP);




ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
}


