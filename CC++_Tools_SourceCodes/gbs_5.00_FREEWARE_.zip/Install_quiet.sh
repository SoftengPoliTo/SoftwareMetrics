#!/bin/bash
#
#   Install_quiet.sh
#       Must NOT be sourced
#      --site=<site>
#      --verbose-
#	--help
#

chmod ugo+x Install.sh
./Install.sh --q $*

###EOF###

