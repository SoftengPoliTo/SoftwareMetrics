#!must_be_sourced
#
#   _gbssetup.sh
#	Alias for gbssetup.sh.
#	Used for initial setup of GBS
#	Makes sure command is on top of list
#	You MUST cd to This directory (GBS_SCRIPTS_PATH) to call this
#	This file MUST be SOURCED with DOT ( . _gbssetup.sh)
#

\echo "_GBSSETUP_:"
\echo "_GBSSETUP_: Setup a GBS environment (Initial)"
\echo "_GBSSETUP_:"
\echo

#
#   Sanity Checks
#
\mkdir -p -v $HOME/tmp		    # make sure ~/tmp exists

#
#   Sanity Check: Assert Install Dir
#
if [[ ! -e ./_gbssetup.sh || ! -e ./glo || ! -e ./plugins || ! -e ./build.dat ]]
then
    \echo "_GBSSETUP_: Fatal Error: You are not in the proper Install directory"
else
    #
    #   Setup
    #
    if [[ $GBS_PID == '' ]]
    then
	#
	#   Set GBS_BOOT_PATH, GBS_BASE_PATH and GBS_PERL_CMD
	#
	\source "$HOME/.gbs/boot.sh"

	#
	#   Execute profile if it exists
	# 	Defines GBS_SCRIPTS_ROOT, GBS_SCRIPTS_REL, GBS_SCRIPTS_PATH and more
	#
	[[ -e "$GBS_BASE_PATH/profile.sh" ]] && \source "$GBS_BASE_PATH/profile.sh"

	#
	#   Determine GBS_SCRIPTS_PATH possibly overwriting the current one
	#
	\unset GBS_SCRIPTS_OK
	gbs_dir=`pwd`
	#\echo "CWD=$gbs_dir"
	gbs_dir=${gbs_dir%/}    	    	#remove (trailing) slash (/)
	if [[ -f $gbs_dir/build.dat && -f $gbs_dir/gbssetup.pl ]]
	then
	    \export GBS_SCRIPTS_PATH=$gbs_dir
	    \echo "_GBSSETUP_: GBS_SCRIPTS_PATH set to $GBS_SCRIPTS_PATH"
	    GBS_SCRIPTS_OK=1
	else
	    \echo "_GBSSETUP_: Not in proper GBS setup directory ($gbs_dir)"
	    GBS_SCRIPTS_OK=0
	fi
	\unset gbs_dir

	if [[ $GBS_SCRIPTS_OK == 1 ]]
	then
	    #
	    #	Setup GBS_PID
	    #
	    \export GBS_PID=$$

	    #
	    #   Run gbssetup
	    #
	    \export GBS_INITIAL_SETUP=1
	    source $GBS_SCRIPTS_PATH/gbssource.sh gbssetup.pl $*
	    \unset GBS_INITIAL_SETUP

	    #
	    #   Cleanup
	    #
	    \unset GBS_PID
	fi
	\unset GBS_SCRIPTS_OK
    else
	\echo "_GBSSETUP_: ** GBS is already running. Use 'gbssetup' command **"
	\export GBS_RC=1
    fi
fi

#
#   Completion
#
read -p "Hit <Enter> to finish (and maybe close window): "

\set --
\bash -c "exit $GBS_RC" # set $?
###EOF###
