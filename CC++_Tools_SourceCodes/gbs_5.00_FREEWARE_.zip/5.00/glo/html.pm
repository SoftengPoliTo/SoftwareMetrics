#=================================================
#
#   html.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
#
#   Based on HTML 4.01
#   <!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
#
#   http://www.w3.org/TR/html401/
#
#=================================================
package glo::html;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
HTML_map
HTML_doc_s
HTML_doc_e
HTML_body_s
HTML_body_e
HTML_anchor
HTML_llink
HTML_link
HTML_img
HTML_hr
HTML_br
HTML_ul
HTML_ol
HTML_li
HTML_dl
HTML_dt
HTML_dd
HTML_table
HTML_table_s
HTML_table_e
HTML_tr
HTML_trth
HTML_trtd
HTML_th
HTML_td
HTML_p
HTML_div
HTML_span
HTML_h
HTML_bold
HTML_bold_txt
HTML_italic
HTML_italic_txt
HTML_code
HTML_code_txt
HTML_text
HTML_pre_s
HTML_pre_txt
HTML_pre_e
);
}




use glo::env;




sub HTML_map(@);
sub HTML_doc_s($$;@);
sub HTML_doc_e();
sub HTML_body_s(@);
sub HTML_body_e();
sub HTML_anchor($$);
sub HTML_llink($$;$);
sub HTML_link($$;$);
sub HTML_img($;@);
sub HTML_hr(@);
sub HTML_table($$$;@);
sub HTML_table_s(@);
sub HTML_table_e();
sub HTML_tr(@);
sub HTML_trth(@);
sub HTML_trtd(@);
sub HTML_th(@);
sub HTML_td(@);
sub HTML_br(@);
sub HTML_ul(@);
sub HTML_ol(@);
sub HTML_li(@);
sub HTML_dl(@);
sub HTML_dt(@);
sub HTML_dd(@);
sub HTML_p(@);
sub HTML_div(@);
sub HTML_span(@);
sub HTML_h($@);
sub HTML_bold(@);
sub HTML_bold_txt(@);
sub HTML_italic(@);
sub HTML_italic_txt(@);
sub HTML_code(@);
sub HTML_code_txt(@);
sub HTML_text(@);
sub HTML_pre_s(@);
sub HTML_pre_txt(@);
sub HTML_pre_e();

sub table_rows($$$$);
sub generic_global($@);
sub generic_global_txt($@);
sub assert_attrs($$);
sub map_url($$);
sub fix_name($);
sub join_content(@);
sub indent($);




my $APPLICATION_NAME;
my $APPLICATION_LONGNAME;

my %MAPS;

my @MAP_KEYS;


my $HTML_FILE_PATH;
my $INDENT_LVL;
my @FILE_ITEMS_REFS;	# [ $HTML_FILE_PATH, $INDENT_LVL  ]







my %ALIGN_3_VALS    = map { $_ => 1 } qw( left center right );
my %ALIGN_4_VALS    = map { $_ => 1 } qw( left center right justify);
my %ALIGN_5_VALS    = map { $_ => 1 } qw( left center right justify char );
my %ALIGN_IMG_VALS  = map { $_ => 1 } qw( bottom middle top left right );
my %CLEAR_VALS	    = map { $_ => 1 } qw( left all right none );
my %FRAME_VALS	    = map { $_ => 1 } qw( void above below hsides vsides lhs rhs box border );
my %RULES_VALS	    = map { $_ => 1 } qw( none groups rows cols all );
my %SCOPE_VALS	    = map { $_ => 1 } qw( row col rowgroup colgroup );
my %TARGET_VALS	    = map { $_ => 1 } qw( _blank _self _parent _top );
my %VALIGN_VALS	    = map { $_ => 1 } qw( top middle bottom baseline );













my %TYPES = (
abbr	=> 't', 	    # TD, TH
align_3	=> \%ALIGN_3_VALS,  # HR, TABLE
align_4	=> \%ALIGN_4_VALS,  # DIV, SPAN, Hx, P
align_5	=> \%ALIGN_5_VALS,  # COL, COLGROUP, TBODY, TD, TFOOT, TH, THEAD, TR
align_img	=> \%ALIGN_IMG_VALS,# IMG
alt 	=> 't', 	    # APPLET, IFRAME, IMG, INPUT, OBJECT
axis	=> 't', 	    # TD, TH
base	=> 't',		    # DOC
bgcolor	=> 'c', 	    # TABLE, TD, TH, TD, BODY
border_table=> 'n', 	    # TABLE
border_img	=> 'l', 	    # IMG, OBJECT
cellpadding => 'l', 	    # TABLE
cellspacing => 'l', 	    # TABLE
description	=> 't',		    # HEAD
char	=> 's', 	    # COL, COLGROUP, TBODY, TD, TFOOT, TH, THEAD, TR
charoff	=> 'l', 	    # COL, COLGROUP, TBODY, TD, TFOOT, TH, THEAD, TR
class	=> 't', 	    # NOT { BASE, BASEFONT, HEAD, HTML, META, PARAM, SCRIPT, STYLE, TITLE }
clear	=> \%CLEAR_VALS,    # BR
colspan	=> 'n', 	    # TD TH
css 	=> 'u', 	    # DOC
cssprint	=> 'u',		    # DOC
favicon 	=> 'u', 	    # DOC
frame	=> \%FRAME_VALS,    # TABLE
headers	=> 'i', 	    # TD TH
height_l	=> 'l', 	    # IFRAME, IMG, OBJECT, APPLET
height_n	=> 'n', 	    # TD TH
href	=> 'u', 	    # A, AREA, LINK, BASE
hspace	=> 'n', 	    # APPLET, IMG, OBJECT
id		=> 'i', 	    # NOT { BASE, HEAD, HTML, META, SCRIPT, STYLE, TITLE }
keywords	=> 't',		    # HEAD
name_a	=> 't', 	    # A
noshade	=> '',		    # HR
nowrap	=> '',		    # TD TH
rowspan	=> 'n', 	    # TD TH
rules	=> \%RULES_VALS,    # TABLE
scope	=> \%SCOPE_VALS,    # TD TH
script	=> 'u',		    # DOC
size_n	=> 'n', 	    # HR
src 	=> 'u', 	    # SCRIPT, INPUT, FRAME, IFRAME, IMG
style	=> 't', 	    # NOT { BASE, BASEFONT, HEAD, HTML, META, PARAM, SCRIPT, STYLE, TITLE }
summary	=> 't', 	    # TABLE
target	=> \%TARGET_VALS,   # A, AREA, BASE, FORM, LINK
text	=> 'c', 	    # BODY
title	=> 't', 	    # NOT { BASE, BASEFONT, HEAD, HTML, META, PARAM, SCRIPT, STYLE }
valign	=> \%VALIGN_VALS,   # COL, COLGROUP, TBODY, TD, TFOOT, TH, THEAD, TR
vspace	=> 'n', 	    # APPLET, IMG, OBJECT
width_n	=> 'n', 	    # TD, TH, PRE
width_l	=> 'l', 	    # HR, IFRAME, IMG, OBJ, TABLE, APPLET,
);





my %DOC = (
css			=> '',
cssprint		=> '',
style		=> '',
script		=> '',
favicon		=> '',
target_frame_name	=> 'base',
description		=> '',
keywords		=> '',
);

my %BODY = (
id	    => '',
class   => '',
style   => '',
bgcolor => '',
text    => '',	 # deprecated
);

my %A = (
id	    => '',
class   => '',
style   => '',
target  => '',


);

my %IMG = (
id		=> '',
class	=> '',
style	=> '',

alt 	=> '',
title	=> '',
align	=> 'align_img',
width	=> 'width_l',
height	=> 'height_n',
border	=> 'border_img',
hspace	=> '',
vspace	=> '',
);

my %HR = (
id		=> '',
class	=> '',
style	=> '',
title	=> '',
align	=> 'align_3',
noshade	=> '',
size	=> 'size_n',
width	=> 'width_l',
);

my %TABLE = (
id		=> '',
class	=> '',
style	=> '',
title	=> '',
summary	=> '',
width	=> 'width_l',
bgcolor	=> '',
frame	=> '',
rules	=> '',
border	=> 'border_table',
cellspacing => '',
cellpadding => '',
align	=> 'align_3',	    #deprecated
);

my %TR = (
id		=> '',
class	=> '',
style	=> '',
title	=> '',
align	=> 'align_5',
char	=> '',
charoff	=> '',
valign	=> '',
);

my %THTD = (
id		=> '',
class	=> '',
style	=> '',
title	=> '',
headers	=> '',
scope	=> '',
abbr	=> '',
axis	=> '',
rowspan	=> '',
colspan	=> '',
nowrap	=> '',		# deprecated
width	=> 'width_l',	# deprecated
heigth	=> 'heigth_n',	# deprecated
bgcolor	=> '',
align	=> 'align_5',
char	=> '',
charoff	=> '',
valign	=> '',
);

my %BR = (
id		=> '',
class	=> '',
style	=> '',
title	=> '',
clear	=> '',		# deprecated
);

my %GLOBAL = (
id		=> '',		# generic set
class	=> '',		# generic set
style	=> '',		# generic set
title	=> '',		# generic set
);




my %HTML_CHARS = (

'&'	=> '&amp;',	# ampersand
'>'	=> '&gt;',	# greater than
'<'	=> '&lt;',	# less than
'"'	=> '&quot;',	# double quote


chr(0)  => '&lt;NUL&gt;',
chr(1)  => '&lt;SOH&gt;',
chr(2)  => '&lt;STX&gt;',
chr(3)  => '&lt;ETX&gt;',
chr(4)  => '&lt;EOT&gt;',
chr(5)  => '&lt;ENQ&gt;',
chr(6)  => '&lt;ACK&gt;',
chr(7)  => '&lt;BEL&gt;',	# \a
chr(8)  => '&lt;BS&gt;',	# \b


chr(11) => '&lt;VT&gt;',
chr(12) => '&lt;FF&gt;',	# \f
chr(13) => '&lt;CR&gt;',	# \r
chr(14) => '&lt;SO&gt;',
chr(15) => '&lt;SI&gt;',
chr(16) => '&lt;DLE&gt;',
chr(17) => '&lt;DC1&gt;',
chr(18) => '&lt;DC2&gt;',
chr(19) => '&lt;DC3&gt;',
chr(20) => '&lt;DC4&gt;',
chr(21) => '&lt;NAK&gt;',
chr(22) => '&lt;SYN&gt;',
chr(23) => '&lt;ETB&gt;',
chr(24) => '&lt;CAN&gt;',
chr(25) => '&lt;EM&gt;',
chr(26) => '&lt;SUB&gt;',
chr(27) => '&lt;ESC&gt;',	# \e
chr(28) => '&lt;FS&gt;',
chr(29) => '&lt;GS&gt;',
chr(30) => '&lt;RS&gt;',
chr(31) => '&lt;US&gt;',

chr(127) => '&lt;DEL&gt;',


'�'	=> '&AElig;',	# capital AE diphthong (ligature)
'�'	=> '&Aacute;',	# capital A, acute accent
'�'	=> '&Acirc;',	# capital A, circumflex accent
'�'	=> '&Agrave;',	# capital A, grave accent
'�'	=> '&Aring;',	# capital A, ring
'�'	=> '&Atilde;',	# capital A, tilde
'�'	=> '&Auml;',	# capital A, dieresis or umlaut mark
'�'	=> '&Ccedil;',	# capital C, cedilla
'�'	=> '&ETH;',	# capital Eth, Icelandic
'�'	=> '&Eacute;',	# capital E, acute accent
'�'	=> '&Ecirc;',	# capital E, circumflex accent
'�'	=> '&Egrave;',	# capital E, grave accent
'�'	=> '&Euml;',	# capital E, dieresis or umlaut mark
'�'	=> '&Iacute;',	# capital I, acute accent
'�'	=> '&Icirc;',	# capital I, circumflex accent
'�'	=> '&Igrave;',	# capital I, grave accent
'�'	=> '&Iuml;',	# capital I, dieresis or umlaut mark
'�'	=> '&Ntilde;',	# capital N, tilde
'�'	=> '&Oacute;',	# capital O, acute accent
'�'	=> '&Ocirc;',	# capital O, circumflex accent
'�'	=> '&Ograve;',	# capital O, grave accent
'�'	=> '&Oslash;',	# capital O, slash
'�'	=> '&Otilde;',	# capital O, tilde
'�'	=> '&Ouml;',	# capital O, dieresis or umlaut mark
'�'	=> '&THORN;',	# capital THORN, Icelandic
'�'	=> '&Uacute;',	# capital U, acute accent
'�'	=> '&Ucirc;',	# capital U, circumflex accent
'�'	=> '&Ugrave;',	# capital U, grave accent
'�'	=> '&Uuml;',	# capital U, dieresis or umlaut mark
'�'	=> '&Yacute;',	# capital Y, acute accent
'�'	=> '&aacute;',	# small a, acute accent
'�'	=> '&acirc;',	# small a, circumflex accent
'�'	=> '&aelig;',	# small ae diphthong (ligature)
'�'	=> '&agrave;',	# small a, grave accent
'�'	=> '&aring;',	# small a, ring
'�'	=> '&atilde;',	# small a, tilde
'�'	=> '&auml;',	# small a, dieresis or umlaut mark
'�'	=> '&ccedil;',	# small c, cedilla
'�'	=> '&eacute;',	# small e, acute accent
'�'	=> '&ecirc;',	# small e, circumflex accent
'�'	=> '&egrave;',	# small e, grave accent
'�'	=> '&eth;',	# small eth, Icelandic
'�'	=> '&euml;',	# small e, dieresis or umlaut mark
'�'	=> '&iacute;',	# small i, acute accent
'�'	=> '&icirc;',	# small i, circumflex accent
'�'	=> '&igrave;',	# small i, grave accent
'�'	=> '&iuml;',	# small i, dieresis or umlaut mark
'�'	=> '&ntilde;',	# small n, tilde
'�'	=> '&oacute;',	# small o, acute accent
'�'	=> '&ocirc;',	# small o, circumflex accent
'�'	=> '&ograve;',	# small o, grave accent
'�'	=> '&oslash;',	# small o, slash
'�'	=> '&otilde;',	# small o, tilde
'�'	=> '&ouml;',	# small o, dieresis or umlaut mark
'�'	=> '&szlig;',	# small sharp s, German (sz ligature)
'�'	=> '&thorn;',	# small thorn, Icelandic
'�'	=> '&uacute;',	# small u, acute accent
'�'	=> '&ucirc;',	# small u, circumflex accent
'�'	=> '&ugrave;',	# small u, grave accent
'�'	=> '&uuml;',	# small u, dieresis or umlaut mark
'�'	=> '&yacute;',	# small y, acute accent
'�'	=> '&yuml;',	# small y, dieresis or umlaut mark


'�'	=> '&copy;',	# copyright sign
'�'	=> '&reg;',	# registered sign
"\240" => '&nbsp;',	# non breaking space


'�'	=> '&iexcl;',
'�'	=> '&cent;',
'�'	=> '&pound;',
'�'	=> '&curren;',
'�'	=> '&yen;',
'�'	=> '&brvbar;',
'�'	=> '&sect;',
'�'	=> '&uml;',
'�'	=> '&ordf;',
'�'	=> '&laquo;',
'�'	=> '&not;',
'�'	=> '&shy;',
'�'	=> '&macr;',
'�'	=> '&deg;',
'�'	=> '&plusmn;',
'�'	=> '&sup1;',
'�'	=> '&sup2;',
'�'	=> '&sup3;',
'�'	=> '&acute;',
'�'	=> '&micro;',
'�'	=> '&para;',
'�'	=> '&middot;',
'�'	=> '&cedil;',
'�'	=> '&ordm;',
'�'	=> '&raquo;',
'�'	=> '&frac14;',
'�'	=> '&frac12;',
'�'	=> '&frac34;',
'�'	=> '&iquest;',
'�'	=> '&times ;',
'�'	=> '&divide;',
);





my @COLOR_NAMES = qw( aqua black blue fuchsia gray green lime maroon navy olive orange purple red silver teal white yellow);
my %COLOR_NAMES = map { $_ => 1 } @COLOR_NAMES;




my %FORMATS = (
L	=>  [ align => 'left' ],
C	=>  [ align => 'center' ],
R	=>  [ align => 'right' ],
J	=>  [ align => 'justify' ],
T	=>  [ valign => 'top' ],
M	=>  [ valign => 'middle' ],
B	=>  [ valign => 'bottom' ],
N	=>  [ nowrap => '' ],
);




sub HTML_map(@)
{
my @map_refs = @_;	#   [$win_dir, $unix_dir ]...

foreach my $ref (@map_refs)
{
my ($win_dir, $unix_dir) = @{$ref};

$win_dir =~ s!\\!/!g;


if (ENV_is_win32())
{
$MAPS{$win_dir} = $unix_dir;
push @MAP_KEYS, $win_dir;
} else
{
$MAPS{$unix_dir} = $win_dir;
push @MAP_KEYS, $unix_dir;
}
}
map { ENV_debug( 1, "MAP $_ -> $MAPS{$_}"); } @MAP_KEYS;
}




sub HTML_doc_s($$;@)
{
my ($document_filespec,
$title,
$head_comments,	    # may be undef
%attrs,		    # css, cssprint, style, script, favicon, target_frame_name, description, keywords
) = @_;
my @lines;



($APPLICATION_NAME, $APPLICATION_LONGNAME) = ENV_get_application_name()
if (!defined $APPLICATION_NAME);

push @FILE_ITEMS_REFS, [ $HTML_FILE_PATH, $INDENT_LVL ];
$HTML_FILE_PATH = ENV_split_spec_p( ENV_abs_paths( undef, $document_filespec));
$INDENT_LVL = 0;

assert_attrs( \%attrs, \%DOC);

push @lines, '<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">';
push @lines, "<!-- $document_filespec -->";
push @lines, $head_comments
if (defined $head_comments);
push @lines, '<html lang="en">';
push @lines, '<head>';
$INDENT_LVL++;
push @lines, indent( '<meta http-equiv="Content-Type" content="text/html; charset=utf-8">');
push @lines, indent( '<meta http-equiv="content-language" content="en">');
push @lines, indent( '<title>' . HTML_text( $title) . '</title>');
if ($attrs{css})
{
my $css_file = $attrs{css};
my $html = '<link rel="stylesheet" href="{url}" type="text/css">';
$html = map_url( $css_file, $html);
push @lines, indent( $html);
}
if ($attrs{cssprint})
{
my $css_file = $attrs{cssprint};
my $html = '<link rel="stylesheet" href="{url}" type="text/css" media="print">';
$html = map_url( $css_file, $html);
push @lines, indent( $html);
}
if ($attrs{style})
{
push @lines, indent( '<style type="text/css">');
$INDENT_LVL++;
map { push @lines, indent( $_) } split( /\s*\n\s*/, $attrs{style});
$INDENT_LVL--;
push @lines, indent( '</style>');
}
if ($attrs{script})
{
my $script_file = $attrs{script};
my $html = '<script src="{url}"></script>';
$html = map_url( $script_file, $html);
push @lines, indent( $html);
}
if ($attrs{favicon})
{
my $favicon_file = $attrs{favicon};
my $html = '<link rel="shortcut icon" href="{url}" type="image/x-icon">';
$html = map_url( $favicon_file, $html);
push @lines, indent( $html);
}
if ($attrs{target_frame_name})
{
my $target_frame_name = $attrs{target_frame_name};
my $html = "<base target=\"$target_frame_name\">";
push @lines, indent( $html);
}

my $for_the_web = 0;
foreach my $meta_name ( qw( description keywords))
{
if ($attrs{$meta_name})
{
push @lines, indent( "<meta name=\"$meta_name\" content=\"$attrs{$meta_name}\">");
$for_the_web = 1;
}
}
if ($for_the_web)
{
push @lines, indent( '<meta name="robots" content="index, follow">');
push @lines, indent( '<meta name="rating" content="general">');
push @lines, indent( '<meta name="author" content="Randy Marques">');
}
push @lines, indent( "<meta name=\"generator\" content=\"$APPLICATION_LONGNAME ($APPLICATION_NAME)\">");
push @lines, indent( '<meta name="copyright" content="Copyright 2015-2025">');






push @lines, indent( '<meta name="skype_toolbar" content="skype_toolbar_parser_compatible">');

$INDENT_LVL--;
push @lines, indent( '</head>');


return @lines;
}




sub HTML_doc_e()
{
($HTML_FILE_PATH, $INDENT_LVL) = @{ pop @FILE_ITEMS_REFS };

return '</html>';
}





sub HTML_body_s(@)
{
my $attrs_ref = (defined $_[0] && ref($_[0]) eq "HASH") ? shift : {};

my @tagname_and_attrs = 'body';
push @tagname_and_attrs, assert_attrs( $attrs_ref, \%BODY)
if (%{$attrs_ref});

return "<@tagname_and_attrs>";
}




sub HTML_body_e()
{
return '</body>';
}




sub HTML_anchor($$)
{
my ($anchor,
$text,
) = @_;

return '<a name="' . fix_name( $anchor) . "\">$text</a>";
}






sub HTML_llink($$;$)
{
my $attrs_ref = (defined $_[0] && ref($_[0]) eq "HASH") ? shift : {};
my ($anchor,
$text,
) = @_;

$text = '' if (!defined $text);

my @tagname_and_attrs = 'a';
push @tagname_and_attrs, assert_attrs( $attrs_ref, \%A)
if (%{$attrs_ref});

return "<@tagname_and_attrs href=\"#" . fix_name( $anchor) . "\">$text</a>";
}





sub HTML_link($$;$)
{
my $attrs_ref = (defined $_[0] && ref($_[0]) eq "HASH") ? shift : {};
my ($url,
$text,
) = @_;

$text = '' if (!defined $text);

my @tagname_and_attrs = '<a href="{url}"';
push @tagname_and_attrs, assert_attrs( $attrs_ref, \%A)
if (%{$attrs_ref});

return map_url( $url, "@tagname_and_attrs>$text</a>");
}




sub HTML_img($;@)
{
my ($url,
%attrs,
) = @_;

my @tagname_and_attrs = 'img src="{url}"';
push @tagname_and_attrs, assert_attrs( \%attrs, \%IMG)
if (%attrs);

my $html = "<@tagname_and_attrs>";

return map_url( $url, $html);
}




sub HTML_hr(@)
{
my %attrs = @_;

my @tagname_and_attrs = 'hr';
push @tagname_and_attrs, assert_attrs( \%attrs, \%HR)
if (%attrs);

return "<@tagname_and_attrs>";
}




sub HTML_table($$$;@)
{
my ($formats_ref,	    # all start with '-' followed by optional format char(s). Refer to FORMATS
$heads_ref,	    # may be undef
$row_refs_ref,	    # may be undef ??
@attrs,
) = @_;
my @lines;

my @formats = (defined $formats_ref) ? @{$formats_ref} : ();
my @heads = (defined $heads_ref) ? @{$heads_ref} : ();
$row_refs_ref = [ [] ] if (!defined $row_refs_ref || !defined $row_refs_ref->[0]);

my $nr_formats = @formats;
my $nr_heads = @heads;

my $nr_cols = $nr_formats;
$nr_cols = $nr_heads
if ($nr_heads > $nr_cols);
$nr_cols = @{$row_refs_ref->[0]}
if (@{$row_refs_ref->[0]} > $nr_cols);





my @row_formats;
if (@formats && grep( /^-/, @formats) == @formats)
{
foreach my $f (split( '', substr( $formats[0], 1)))
{
if (grep( /$f/, @formats) == scalar @formats)
{

push @row_formats, @{$FORMATS{$f}};
foreach my $format (@formats)
{
$format =~ s/$f//;
}
}
}
}




for (my $i = 0; $i < $nr_cols; $i++)
{
my $format = $formats[$i];
if (defined $format)
{
if ($format eq '')
{
$format = {};
} elsif (substr( $format, 0, 1) eq '-')
{
my @attrs;
foreach my $f (split( '', substr($format, 1)))
{

push @attrs, @{$FORMATS{$f}};
}
$format = { @attrs };
} else
{
$format = { $format };
}
$formats[$i] = $format;
} else
{
$formats[$i] = {};
}
}

push @lines, HTML_table_s( @attrs);




if (defined $heads_ref)
{
push @lines, HTML_tr( @row_formats);
push @lines, table_rows( $heads_ref, [ @formats ], $nr_cols, \&HTML_th);
}




foreach my $row_ref (@{$row_refs_ref})
{

push @lines, HTML_tr( @row_formats);
push @lines, table_rows( $row_ref, [ @formats ], $nr_cols, \&HTML_td);
}
push @lines, HTML_table_e();


return (wantarray) ? @lines : "@lines";
}




sub table_rows($$$$)
{
my ($row_ref,
$format_refs_ref,
$nr_cols,
$cell_func,
) = @_;
my @lines;

my $i = 0;
do
{
my $cell = $row_ref->[$i];
my $format_ref = $format_refs_ref->[$i];

my %format = %{$format_ref};
$i++;
my $colspan = 1;
while ($i < $nr_cols && !defined $row_ref->[$i])
{
$i++;
$colspan++;
}

$cell = '&nbsp;' if (!defined $cell);
if ($colspan > 1)
{
$format{colspan} = $colspan;
}
if (ref $cell)
{
my $cell_format_ref = $cell->[0];
map { $format{$_} = $cell_format_ref->{$_} } keys %{$cell_format_ref};
$cell = $cell->[1];
}
push @lines, &$cell_func( \%format, $cell);
} while ($i < $nr_cols);

return @lines;
}




sub HTML_table_s(@)
{
my %attrs = @_;
my $html;

my @tagname_and_attrs = 'table';
push @tagname_and_attrs, assert_attrs( \%attrs, \%TABLE)
if (%attrs);

$html = indent( "<@tagname_and_attrs>");
$INDENT_LVL += 3;

return $html;
}




sub HTML_table_e()
{
$INDENT_LVL -= 3;

return indent( '</table>');
}




sub HTML_tr(@)
{
my %attrs = @_;
my $html;

my @tagname_and_attrs = 'tr';
push @tagname_and_attrs, assert_attrs( \%attrs, \%TR)
if (%attrs);

$INDENT_LVL -= 2;
$html = indent( "<@tagname_and_attrs>");
$INDENT_LVL += 2;

return $html;
}





sub HTML_trth(@)
{
my $attrs_ref = (defined $_[0] && ref($_[0]) eq "HASH") ? shift : {};
my $html;

my @tagname_and_attrs = 'tr><th';
push @tagname_and_attrs, assert_attrs( $attrs_ref, \%THTD)
if (%{$attrs_ref});

my $content = join_content( @_);
$content = '&nbsp;' if ($content eq '');

$INDENT_LVL -= 2;
$html = indent( "<@tagname_and_attrs>$content");
$INDENT_LVL += 2;

return $html;
}





sub HTML_trtd(@)
{
my $attrs_ref = (defined $_[0] && ref($_[0]) eq "HASH") ? shift : {};
my $html;

my @tagname_and_attrs = 'tr><td';
push @tagname_and_attrs, assert_attrs( $attrs_ref, \%THTD)
if (%{$attrs_ref});

my $content = join_content( @_);
$content = '&nbsp;' if ($content eq '');

$INDENT_LVL -= 2;
$html = indent( "<@tagname_and_attrs>$content");
$INDENT_LVL += 2;

return $html;
}





sub HTML_th(@)
{
my $attrs_ref = (defined $_[0] && ref($_[0]) eq "HASH") ? shift : {};
my $html;

my @tagname_and_attrs = 'th';
push @tagname_and_attrs, assert_attrs( $attrs_ref, \%THTD)
if (%{$attrs_ref});

my $content = join_content( @_);
$content = '&nbsp;' if ($content eq '');

$INDENT_LVL--;
$html = indent( "<@tagname_and_attrs>$content");
$INDENT_LVL++;

return $html;
}





sub HTML_td(@)
{
my $attrs_ref = (defined $_[0] && ref($_[0]) eq "HASH") ? shift : {};
my $html;

my @tagname_and_attrs = 'td';
push @tagname_and_attrs, assert_attrs( $attrs_ref, \%THTD)
if (%{$attrs_ref});

my $content = join_content( @_);
$content = '&nbsp;' if ($content eq '');

$INDENT_LVL--;
$html = indent( "<@tagname_and_attrs>$content");
$INDENT_LVL++;

return $html;
}




sub HTML_br(@)
{
my %attrs = @_;

my @tagname_and_attrs = 'br';
push @tagname_and_attrs, assert_attrs( \%attrs, \%BR)
if (%attrs);

return "<@tagname_and_attrs>";
}





sub HTML_ul(@)
{
return generic_global( 'ul', @_);
}





sub HTML_ol(@)
{
return generic_global( 'ol', @_);
}





sub HTML_li(@)
{
my $html;

$INDENT_LVL++;
$html = "\n" . indent( generic_global( 'li', @_));
$INDENT_LVL--;

return $html;
}





sub HTML_dl(@)
{
return generic_global( 'dl', @_);
}





sub HTML_dt(@)
{
my $html;

$INDENT_LVL++;
$html = "\n" . indent( generic_global( 'dt', @_));
$INDENT_LVL--;

return $html;
}





sub HTML_dd(@)
{
my $html;

$INDENT_LVL++;
$html = "\n" . indent( generic_global( 'dd', @_));
$INDENT_LVL--;

return $html;
}





sub HTML_p(@)
{
return generic_global( 'p', @_);
}





sub HTML_h($@)
{
my $level = shift;

return generic_global( "h$level", @_);
}





sub HTML_div(@)
{
return generic_global( 'div', @_);
}





sub HTML_span(@)
{
return generic_global( span => @_);
}




sub HTML_bold(@)
{
return generic_global( b => @_);
}




sub HTML_bold_txt(@)
{
return generic_global_txt( b => @_);
}




sub HTML_italic(@)
{
return generic_global( i => @_);
}




sub HTML_italic_txt(@)
{
return generic_global_txt( i => @_);
}




sub HTML_code(@)
{
return generic_global( code => @_);
}




sub HTML_code_txt(@)
{
return generic_global_txt( code => @_);
}




sub HTML_text(@)
{
my $text = join_content( @_);

$text =~ s/([^\t\n !#\$%(-;=?-~])/$HTML_CHARS{$1} || sprintf '&#x%X;', ord($1)/ge;

$text =~ s/(\n)/<br>/g;			    # replace \n by <br>
$text =~ s/( {2,})/'&nbsp;' x length $1/ge;	    # replace 2 and more spaces by &nbsp;
$text =~ s/^ /&nbsp;/;			    # replace single leading space by &nbsp;
$text =~ s/ $/&nbsp;/;			    # replace single trailing space by &nbsp;

return $text;
}




sub HTML_pre_s(@)
{
my %attrs = @_;

$attrs{style} = "margin-top:0;margin-bottom:0"
if (!$attrs{style});

my @tagname_and_attrs = 'pre';
push @tagname_and_attrs, assert_attrs( \%attrs, \%GLOBAL)
if (%attrs);

return "<@tagname_and_attrs>";
}




sub HTML_pre_txt(@)
{
my $text = join_content( @_);

$text =~ s/([^\t\n !#\$%(-;=?-~])/$HTML_CHARS{$1} || sprintf '&#x%X;', ord($1)/ge;


return $text;
}




sub HTML_pre_e()
{
return '</pre>';
}





sub generic_global($@)
{
my $tagname = shift;
my $attrs_ref = (defined $_[0] && ref($_[0]) eq "HASH") ? shift : {};


my @tagname_and_attrs = "$tagname";
push @tagname_and_attrs, assert_attrs( $attrs_ref, \%GLOBAL)
if (%{$attrs_ref});

my $content = join_content(@_);
if ($content eq '')
{
$content = '&nbsp;';
} elsif (index( $content, "\n" ) >= 0)
{
$content .= "\n";
}

return "<@tagname_and_attrs>$content</$tagname>";
}





sub generic_global_txt($@)
{
my $tagname = shift;
my $attrs_ref = (defined $_[0] && ref($_[0]) eq "HASH") ? shift : {};


my @tagname_and_attrs = "$tagname";
push @tagname_and_attrs, assert_attrs( $attrs_ref, \%GLOBAL)
if (%{$attrs_ref});

my $content = HTML_text( @_);
$content = '&nbsp;' if ($content eq '');

return "<@tagname_and_attrs>$content</$tagname>";
}




sub assert_attrs($$)
{
my ($i_ref,	    # specified attributes
$def_ref,   # allowed attributes
) = @_;
my @attrs;

my @def_keys = keys %{$def_ref};	    # For error-messages
foreach my $attr (keys %{$i_ref})
{



my $attr_type = $def_ref->{$attr};
ENV_sig( F => "No such attribute '$attr' (@def_keys)")
if (!defined $attr_type);
$attr_type = $attr
if ($attr_type eq '');
my $attr_type_value = $TYPES{$attr_type};
ENV_sig( F => "No TYPE for attr '$attr_type'")
if (!defined $attr_type_value);


my $value = $i_ref->{$attr};
if (defined $value)
{
if (ref $attr_type_value)		    # { allowed values ]
{
if (!exists $attr_type_value->{$value})
{
my @attr_type_values = sort keys %{$attr_type_value};
ENV_sig( F => "'$attr=$value' Invalid value (@attr_type_values)")
}
push @attrs, "$attr=\"$value\"";
} elsif ($attr_type_value eq '')	    # boolean (no value)
{
ENV_sig( F => "'$attr=$value' No value assignent allowed")
if (defined $value && $value ne '' && $value ne '1');
push @attrs, $attr;
} else
{
if ($attr_type_value eq 't')	    # text (convert special characters)
{
$value = HTML_text( $value);
} elsif ($attr_type_value eq 'l')   # length (number or number%)
{
ENV_sig( F => "'$attr=>$value' must be number (%)")
if ( $value !~ /^\d+%?$/);
} elsif ($attr_type_value eq 'n')   # number
{
ENV_sig( F => "'$attr=>$value' must be number")
if ( $value !~ /^\d+$/);
} elsif ($attr_type_value eq 'u')   # url
{
$value =~ s/ /%20/g;
} elsif ($attr_type_value eq 'c')   # color (color_name or hex_number or rgb_number)
{

my $lc_value = lc $value;
if (substr( $lc_value, 0, 1) eq '#')
{
ENV_sig( F => "'$attr=>$value': Invalid hexadecimal color notation")
if ($lc_value !~ /^#[0-9abcdef]{6}$/);
} elsif (substr( $lc_value, 0, 4) eq 'rgb(')
{
ENV_sig( F => "'$attr=>$value': Invalid rgb color notation")
if ($lc_value !~ /^rgb\(\d+,\d+,\d+\)$/);
} else
{
ENV_sig( F => "'$attr=>$value': Invalid color name. Must be one of:",
"  @COLOR_NAMES")
if (!exists $COLOR_NAMES{$lc_value});
}
} elsif ($attr_type_value eq 'i')   # id (Start with aplha, then alpha_num - _ : .)
{
ENV_sig( F => "'$attr=>$value' must Start with aplha, then alpha_num - _ : .")
if ( $value !~ /^[a-zA-Z][a-zA-Z0-9_:.-]*$/);
} elsif ($attr_type_value eq 's')   # single character
{
ENV_sig( F => "'$attr=>$value' must be single char")
if (length $value != 1);
} else
{
ENV_sig( F => "Unknown TYPE '$attr_type_value' for '$attr'");
}
push @attrs, "$attr=\"$value\"";
}
}
}

return @attrs;
}




sub map_url($$)
{
my ($url,
$html,	    # contains '{url}' where the converted $url must be inserted
) = @_;





if ($url =~ m!^http://!)
{




$html =~ s/{url}/$url/;
} else
{
$url = ENV_perl_paths_noquotes( $url);


if (ENV_is_abs_path_perl( $url))
{



$url = ENV_rel_paths( $HTML_FILE_PATH, $url);

}
if (ENV_is_abs_path_perl( $url))
{



if (@MAP_KEYS)
{



my $win_url = $url;
my $unix_url = $url;
my $this_url = $url;




my $found_key;
my $remainder;
foreach my $key (@MAP_KEYS)
{
if ($url =~ /^$key(.*)/)
{
$found_key = "$key";
$remainder = $1;
last;
}
}

if (defined $found_key)
{

my $other_url = "$MAPS{$found_key}$remainder";
if (ENV_is_win32())
{
$unix_url = $other_url;


} else
{
$win_url = $other_url;

}


(my $win_html = $html) =~ s!{url}!file://$win_url!g;
(my $unix_html = $html) =~ s!{url}!file://$unix_url!g;
(my $this_html = $html) =~ s!{url}!file://$this_url!g;

$html = "<SCRIPT type=\"text/javascript\" LANGUAGE=\"JavaScript\"> <!--\n".
"	 if (navigator.userAgent.indexOf('Win') != -1)\n" .
"	   document.write('$win_html');\n" .
"	 else\n" .
"	   document.write('$unix_html');\n" .
"	 //-->\n" .
"  </SCRIPT>\n" .
"  <NOSCRIPT>$this_html</NOSCRIPT>\n";
} else
{
ENV_sig( E => "No MAPping found for '$url' in (@MAP_KEYS)\n");
$url = "file://$url";
$html =~ s/{url}/$url/;
}

} else
{



$url = "file://$url";
$html =~ s/{url}/$url/;
}
} else
{





$html =~ s/{url}/$url/;
}
}



return $html;
}




sub fix_name($)
{
my ($name) = @_;

$name =~ s/ /%20/g;

return $name;
}




sub indent($)
{
my ($cell) = @_;

$INDENT_LVL = 0
if (!defined $INDENT_LVL);
my $indent = '  ' x $INDENT_LVL;
$cell =~ s/\n/\n$indent/g;

return "$indent$cell";
}





sub join_content(@)
{
my $content = '';
foreach my $text_or_ref (@_)
{
if (ref $text_or_ref)
{
$content .= join( '', @{$text_or_ref});
} else
{
$content .= $text_or_ref;
}
}

return $content;
}

1;
