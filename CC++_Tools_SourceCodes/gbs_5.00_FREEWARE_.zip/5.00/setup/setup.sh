#!must_be_sourced!
#=================================================
#   setup.sh <wanted_rel>
#   Common part for gbsstart.sh and gbsstart.sh (batch)
#   - Run profile.sh
#   - Adjust the GBS_SCRIPTS_REL (if applicable)
#=================================================

#
#   Handle Args
#
GBS_SETUP_REL=$1
set --

#
#   Execute profile
#
#\echo "SETUP_: Executing $GBS_BASE_PATH/profile.sh..."
\source "$GBS_BASE_PATH/profile.sh"

#
#   Adjust GBS_SCRIPTS_REL
#
[[ $GBS_SCRIPTS_REL != '' ]] && \echo "SETUP_: Current GBS version is '$GBS_SCRIPTS_REL'"
if [[ "$GBS_SETUP_REL" != cur && "$GBS_SETUP_REL" != "$GBS_SCRIPTS_REL" ]]
then
    if [[ -e "$GBS_SCRIPTS_ROOT/$GBS_SETUP_REL" ]]
    then
	\export GBS_SCRIPTS_REL=$GBS_SETUP_REL
	\echo "SETUP_: GBS Version set to '$GBS_SCRIPS_REL'"
    else
	\echo "SETUP_: GBS Version '$GBS_SETUP_REL' does not exist"
    fi
fi

#
#   Cleanup
#
unset GBS_SETUP_REL

#   End

#  **EOF**
