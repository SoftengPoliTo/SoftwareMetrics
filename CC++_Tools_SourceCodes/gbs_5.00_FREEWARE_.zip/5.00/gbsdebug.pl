#=================================================
#
#   gbsdebug.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSDEBUG @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::ask;
use glo::genopt;
use mod::gbsenv;




sub enable_debug($$$);
sub do_enable(@);
sub disable_debug($$$);
sub do_disable($);
sub disable_all_debug($$$);
sub show_current_debug_values();




my @DEBUG_ENVVARS;
my %DEBUG_ENVVARS;







$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ '<1>', 'selector',    'ssos1,2,3,show,enable,disable', 0,   "Menu entry for single immediate execution or enable/disable" ],
[ '<2>', 'debug_name',  'sso',                          '',   "Value to enable/disable" ],
[ 'app', 'application', 'ssosGBS,TOOLS,PRQA,CPPTEST',   'GBS', "Application to debug. E.g.: GBS TOOLS" ],
);
GENOPT_set_optdefs( 'gbsdebug', \@genopts,
[ 'Enable and Disable Debug',
' 1. Enable Debug',
' 2. Disable Debug',
' 3. Disable All Debug',
],
undef);
GENOPT_parse();
}
my $SELECTOR = GENOPT_get( 'selector');
my $DEBUG_NAME =  GENOPT_get( 'debug_name');
my $APPLICATION =  GENOPT_get( 'application');

my @MENU_ENTRIES;

my $DIRECT_ACTION;	    # enable or disable

if ($SELECTOR =~ /^\d$/)
{
ENV_sig( EE => "Cannot specify second argument '$DEBUG_NAME' with direct Menu selection ($SELECTOR)")
if ($DEBUG_NAME ne '');
@MENU_ENTRIES = grep( $_ != 0, ($SELECTOR)) ;
} else
{
if ($SELECTOR eq 'show')
{
ENV_sig( EE => "Cannot specify second argument ($DEBUG_NAME) for '$SELECTOR'")
if ($DEBUG_NAME ne '');
} else
{
ENV_sig( EE => "Must specify second argument for '$SELECTOR'")
if ($DEBUG_NAME eq '');
}
$DIRECT_ACTION = $SELECTOR;
}


my $APP_DEBUG_ = "${APPLICATION}DEBUG_";




{
ENV_say( 1, "$APPLICATION Debug");




foreach my $envvar (sort( grep( /^$APP_DEBUG_/ , keys %ENV)))
{
my $value = ENV_getenv( $envvar);
if ($value eq '1')
{
push @DEBUG_ENVVARS, $envvar;
} elsif ($value eq '0')
{

} elsif (uc( substr( $value, 0, 1)) eq 'Y')
{
push @DEBUG_ENVVARS, $envvar;
ENV_setenv( $envvar => '1');
} else
{
ENV_setenv( $envvar => '0');
}
}
%DEBUG_ENVVARS = map { $_ => '1' } @DEBUG_ENVVARS;





if (defined $DIRECT_ACTION)
{
if ($DIRECT_ACTION eq 'show')
{

} else
{
my $envvar = uc $DEBUG_NAME;
$envvar =~ s/^$APP_DEBUG_//;
$envvar =~ s/^DEBUG_//;
if ($DIRECT_ACTION eq 'enable')
{
do_enable( $envvar);
} else # ($DIRECT_ACTION eq 'disable')
{
do_disable( $envvar);
}
}
show_current_debug_values();
} else
{
show_current_debug_values();

my @main_menu_items = (
[ "Enable Debug",		\&enable_debug ],
[ "Disable Debug",		\&disable_debug ],
[ "Disable All Debug",	\&disable_all_debug ],
);

ASK_menu( 'Select function to perform', \@main_menu_items, [ @MENU_ENTRIES ]);

show_current_debug_values()
if ($SELECTOR eq '0');
}
}








{
if (ENV_get_changed_envs())
{
my @lines;
push @lines, GBSENV_changed_setenv_commands( 0);

GBSENV_write_result_script( \@lines, 0);	# $print_result
}
}

ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
}




sub enable_debug($$$)
{
my ($menu_list_entry_nr,
$args_ref,
$entries_ref,
) = @_;

my @possible_values = qw( <None> <module> <file> ALL FILE SCRIPTS PREFIX VERBOSE <other>);
my $index = ASK_index_from_menu( '', -1, undef, [ @possible_values ]);
my $envvar = $possible_values[$index];
my @envvars;
if ($envvar eq 'ALL')
{
push @envvars, qw( ALL FILE PREFIX VERBOSE);
} elsif ($envvar eq 'FILE' || $envvar eq 'PREFIX' || $envvar eq 'VERBOSE')
{
push @envvars, $envvar;
} elsif ($envvar eq '<file>' || $envvar eq '<module>')
{
ENV_pushd( $GBS::SCRIPTS_PATH);
my $search_type = ($envvar eq '<file>') ? '.pl' : '.pm';
my @files = (glob( "*$search_type"), glob( "*/*$search_type"));
@files = grep( $_ !~ m!^templates/!, @files);			    # skip anything from templates-dir
my $index = ASK_index_from_menu( '', -1, undef, [ '<None>', @files ]);
if ($index > 0)
{
$envvar = uc substr( $files[$index - 1], 0, -3);
$envvar =~ s!^.*/!!;					    # remove possible dir_path
push @envvars, $envvar;
}
ENV_popd();
} elsif ($envvar eq '<other>')
{
$envvar = uc ASK_file( "Enter $APP_DEBUG_* Envvar to Enable", '', 0, 0, '');   # length, $must_exist, $path
$envvar =~ s/^$APP_DEBUG_//;
$envvar =~ s/^DEBUG_//;
push @envvars, $envvar;
}

if (@envvars)
{
do_enable( @envvars);
}

show_current_debug_values();
}




sub do_enable(@)
{
my (@envvars) = @_;	# <module> <file> ALL FILE PREFIX VERBOSE <other>

foreach my $envvar (@envvars)
{
$envvar = "$APP_DEBUG_$envvar";
if (exists( $DEBUG_ENVVARS{$envvar}) && $DEBUG_ENVVARS{$envvar} eq '1')
{
ENV_say( 1, "==> EnvVar $envvar is already enabled");
} else
{
ENV_setenv( $envvar => '1');
$DEBUG_ENVVARS{$envvar} = '1';
@DEBUG_ENVVARS = sort( keys %DEBUG_ENVVARS);
}
}
}





sub disable_debug($$$)
{
my ($menu_list_entry_nr,
$args_ref,
$entries_ref,
) = @_;

if (@DEBUG_ENVVARS)
{
my $envvar = ASK_value_from_menu( '', -1, undef, [ '<None>', @DEBUG_ENVVARS ]);
if ($envvar ne '<None>')
{
$envvar =~ s/^$APP_DEBUG_//;	    # Remove $APP_DEBUG_
do_disable( $envvar);
}
show_current_debug_values();
} else
{
ENV_say( 1, 'No Debugs to Disable');
}

}




sub do_disable($)
{
my ($envvar) = @_;

$envvar = "$APP_DEBUG_$envvar";
if (!exists( $DEBUG_ENVVARS{$envvar}) || $DEBUG_ENVVARS{$envvar} eq '0')
{
ENV_say( 1, "==> EnvVar $envvar is already disabled");
} else
{
ENV_setenv( $envvar => '0');
delete $DEBUG_ENVVARS{$envvar};
@DEBUG_ENVVARS = grep( $_ ne $envvar, @DEBUG_ENVVARS);
}
}





sub disable_all_debug($$$)
{
my ($menu_list_entry_nr,
$args_ref,
$entries_ref,
) = @_;

foreach my $envvar (@DEBUG_ENVVARS)
{
ENV_setenv( $envvar => '0');
}
%DEBUG_ENVVARS = ();
@DEBUG_ENVVARS = ();

show_current_debug_values();
}



sub show_current_debug_values()
{
if (@DEBUG_ENVVARS)
{
ENV_say( 1, 'Enabled Debugs are:',
"@DEBUG_ENVVARS");
} else
{
ENV_say( 1, 'No Debugs Enabled');
}
}


