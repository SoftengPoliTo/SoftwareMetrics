#=================================================
#
#   glkb.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::glkb;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GLKB_parse
GLKB_get_lines
GLKB_get_dependencies
);
}




use glo::env;
use glo::path;
use mod::build;
use mod::scope;
use mod::flincs;
use mod::gbsglo;
use mod::gbsfileglo;




sub GLKB_parse($$$);
sub GLKB_get_lines();
sub GLKB_get_dependencies();

sub get_glkb_items($$);
sub get_depend_items($$);
sub find_embedded_include($);
sub parse_file();
sub process_line($$);
sub find_include_file($);
sub get_includes();
sub extract_abs_filespec($);
sub validate_compfile($$$);
sub error_ref($@);
sub print_error($$);
sub dbg_print_parses();









my @PARSES_ORDER;
my %PARSES;












my %INCPATHS;	    # cache for include-paths





my $BUILD = '';
my %BUILD_COMPS;




my $COMPONENT = '';
my $SRC_DIR;
my @INCPATH;
my %SCOPE_COMPS;    # includes own scope




my $SRC_FILE_SPEC = '';
my $SRC_FILE;

my $INC_ABS_PATH;
my @UNIXLIB_GLB_TYPES;

my $NR_WARNINGS;
my $NR_ERRORS;
my $INC_LEVEL;








sub GLKB_parse($$$)
{
my ($file,			#input-file
$build,
$component,
) = @_;

if ($BUILD ne $build)
{
$BUILD = $build;
$COMPONENT = '';

%BUILD_COMPS = map { $_ => 1 } GBSGLO_components_for_build( $GBS::SUBSYS, $BUILD);
}

{
my $src_type = ENV_split_spec_t( $file);
@UNIXLIB_GLB_TYPES = BUILD_get_unixlib_glb_types( $BUILD, $src_type);
$INC_ABS_PATH = BUILD_get_src_items( $BUILD, $src_type, 'INC_ABS_PATH');
}

if ($component ne $COMPONENT)
{
$COMPONENT = $component;
$SRC_DIR = "$GBS::COMP_PATH/$COMPONENT/src";
@INCPATH = get_includes();
%SCOPE_COMPS = map { $_ => 1 } SCOPE_get_components(  $GBS::SUBSYS, $COMPONENT);
$SCOPE_COMPS{$COMPONENT} = 1;
}



$SRC_FILE = $file;
$SRC_FILE_SPEC = "$SRC_DIR/$SRC_FILE";

parse_file();

dbg_print_parses()
if (ENV_is_debug());
}





sub GLKB_get_lines()
{


$NR_WARNINGS = 0;
$NR_ERRORS = 0;

return ( $NR_ERRORS, $NR_WARNINGS, get_glkb_items( $SRC_FILE_SPEC, '' ) );
}





sub get_glkb_items($$)
{
my ($file,
$line_ref,
) = @_;
my @lines;


my ($filespec, @error_texts) = find_include_file( $file);
if ($filespec ne '')
{
foreach my $item_ref (@{$PARSES{$filespec}})
{
my ($type, @args) = @{$item_ref};

if ($type eq '>')	    # include
{
my ($spec, $line_ref) = @args;
push @lines, get_glkb_items( $spec, $line_ref);	    # recurse
} elsif ($type eq 'E')  # error
{
my ($texts_ref, $line_ref) = @args;
print_error( $line_ref, $texts_ref);
} elsif ($type eq 'G')  # gbsbuild item
{
my $line = shift @args;

push @lines, $line;
} elsif ($type eq 'C')  # Component:File
{
my ($component, $file, $line_ref) = @args;
$component = $COMPONENT if ($component eq '.');
if (validate_compfile( $component, $file, $line_ref))
{
if ($INC_ABS_PATH)
{
push @lines, "$GBS::COMP_PATH/$component/bld/$BUILD/$file";
} else
{
if ($component eq $COMPONENT)
{
push @lines, "../bld/$BUILD/$file";
} else
{
push @lines, "../../$component/bld/$BUILD/$file";
}
}
}
} elsif ($type eq '=')  # rel_filespec. Find file in .include path
{
my ($line_parts_ref, $line_ref) = @args;
my @items;
foreach my $item (@{$line_parts_ref})
{
my ($found_spec, $new_item, @error_texts) = find_embedded_include( $item);
if (defined $found_spec)	    # match was found
{
if ($found_spec eq '')	    # file was not found
{
print_error( $line_ref, \@error_texts);
} else
{
push @items, $new_item;
}
} else
{
push @items, $item;
}
}
push @lines, "@items";
} elsif ($type eq 'F')		    # Dependency file
{

} else
{
ENV_sig( F => "glbk: invalid gen type ($type)");
}
}
} else
{
print_error( $line_ref, \@error_texts);
}


return @lines;
}









sub GLKB_get_dependencies()
{




$NR_WARNINGS = 0;
$NR_ERRORS = 0;
$INC_LEVEL = 0;

my @line_refs = get_depend_items( $SRC_FILE_SPEC, '' );


return ( $NR_ERRORS, $NR_WARNINGS, @line_refs);
}






sub get_depend_items($$)
{
my ($file,
$line_ref,
) = @_;
my @line_refs;	# [ $inc_level, $file, $org_file, $line_ref ]


my ($filespec, @error_texts) = find_include_file( $file);
if ($filespec ne '')
{

$INC_LEVEL++;
foreach my $item_ref (@{$PARSES{$filespec}})
{
my ($type, @args) = @{$item_ref};
if ($type eq '>')		# include
{
my ($spec, $line_ref) = @args;

push @line_refs, get_depend_items( $spec, $line_ref);	# recurse
} elsif ($type eq 'E')	# error
{
my ($texts_ref, $line_ref) = @args;
print_error( $line_ref, $texts_ref);
} elsif ($type eq 'F')	# filespec
{
my ($filespec, $org_file, $line_ref) = @args;

push @line_refs, [ $INC_LEVEL, $filespec, $org_file, $line_ref ];
} elsif ($type eq 'C')	# component:file
{
my ($component, $file, $line_ref) = @args;

$component = $COMPONENT
if ($component eq '.');
if (validate_compfile( $component, $file, $line_ref))
{
push @line_refs, [ $INC_LEVEL, "$GBS::COMP_PATH/$component/bld/$BUILD/$file", "$component:$file", $line_ref ];
}
} elsif ($type eq '=')	# rel_filespec. Find file in .include path
{
my ($line_parts_ref, $line_ref) = @args;

foreach my $item (@{$line_parts_ref})
{
my ($found_spec, $new_item, @error_texts) = find_embedded_include( $item);
if (defined $found_spec)	    # match was found
{
if ($found_spec eq '')	    # file was not found
{
push @line_refs, [ $INC_LEVEL, $new_item ];
} else
{

push @line_refs, [ $INC_LEVEL, $found_spec, $item, $line_ref ];
}
}
}
} elsif ($type eq 'G')		    # Gen item
{

} else
{
ENV_sig( F => "glbk: invalid depend type ($type)");
}
}
$INC_LEVEL--;
} else
{
print_error( $line_ref, \@error_texts);
}

return @line_refs;
}






sub find_embedded_include($)
{
my ($item) = @_;
my ($found_spec, $new_item, @error_texts);


$new_item = $item;
if ($new_item =~ s!(\w+\.\w+)!{ ($found_spec, @error_texts) = find_include_file( $1); $found_spec; } !e)
{
$new_item = $1
if ($found_spec eq '');

} else
{
$new_item = $item;

}

return ($found_spec, $new_item, @error_texts);
}





sub parse_file()
{
my $cur_parse_ref;
my @parse_refs;

GBSFILEGLO_open_file( $SRC_FILE_SPEC, \@INCPATH, undef, $BUILD, 1);
push @PARSES_ORDER, $SRC_FILE_SPEC;
$PARSES{$SRC_FILE_SPEC} = $cur_parse_ref = [];



my $line_ref;
$line_ref = GBSFILEGLO_get_line_ref();
while (defined $line_ref)
{
my $line = $line_ref->[0];
if (ref $line)
{
my ($line, $line_type, $type_data1, $type_data2) = @{$line};

if ($line_type eq '>')	# include
{
my $include_filespec = $type_data1;
my $inc_file = $type_data2;
push @{$cur_parse_ref}, [ '>', $include_filespec, $line_ref ];

push @parse_refs, $cur_parse_ref;

if ($PARSES{$include_filespec})
{

$cur_parse_ref = undef;	    # already parsed
} else
{
push @PARSES_ORDER, $include_filespec;
$PARSES{$include_filespec} = $cur_parse_ref = [];
push @{$cur_parse_ref}, [ 'F', $include_filespec, $inc_file, $line_ref ];
}
} elsif ($line_type eq '<')
{

$cur_parse_ref = pop @parse_refs;
} else
{

}
} else
{




if ($line eq 'DUMMY')
{
push @{$cur_parse_ref}, [ 'G', 'DUMMY' ];
} else
{
push @{$cur_parse_ref}, process_line( $line, $line_ref);

}
}
$line_ref = GBSFILEGLO_get_line_ref();
}
}











sub process_line($$)
{
my ($line,			#input_line
$line_ref,
) = @_;
my @glkb_refs;


my $first_char = substr( $line, 0, 1);
if ($first_char eq '$' || $first_char eq '%')
{



my $file = ENV_expand_envs( $line);
if ($INC_ABS_PATH)
{
push @glkb_refs, [ 'G', ENV_abs_paths( $SRC_DIR, $file) ];
} else
{
push @glkb_refs, [ 'G', ENV_shortest_paths( $SRC_DIR, $file) ];
}
push @glkb_refs, [ 'F', $file, $line, $line_ref ];
} else
{
push @glkb_refs, error_ref( $line_ref, "Absolute paths not allowed - Use Env. Variable")
if (ENV_is_abs_path( $line));

my $exp_line = ENV_expand_envs( $line);
if (ENV_is_option( $exp_line)) # '-' or '/')
{



push @glkb_refs, [ 'G', $exp_line ];
if (@UNIXLIB_GLB_TYPES && substr( $exp_line, 0, 2) eq '-l')
{
my $libname = substr( $exp_line, 2);

map { push @glkb_refs, [ 'F', "lib$libname$_", "$libname$_", $line_ref ] } @UNIXLIB_GLB_TYPES;
} else
{
foreach my $item (split ' ', $exp_line)
{
my $filespec = extract_abs_filespec( $item);
push @glkb_refs, [ 'F' , $filespec, $item, $line_ref ]
if ($filespec ne '');
}
}
} elsif ($first_char eq '^')
{



$exp_line = substr( $exp_line, 1);
push @glkb_refs, [ 'G', $exp_line ];
} elsif ($first_char eq '+')
{



$exp_line = substr( $exp_line, 1);
push @glkb_refs, [ 'G', $exp_line ];
if ($exp_line !~ m!(/|\\)!)
{
push @glkb_refs, [ 'F', $exp_line, $exp_line, $line_ref ]
if ($exp_line =~ /.+\..+/);
} else
{
my $filespec = extract_abs_filespec( $exp_line);


push @glkb_refs, [ 'F', $filespec, $exp_line, $line_ref ]
if ($filespec ne '');
}
} elsif ($first_char eq '=')
{



$exp_line = substr( $exp_line, 1);
my @exp_line = split( ' ', $exp_line);
push @glkb_refs, [ '=', [ @exp_line ], $line_ref ];
} else
{



my @outs;
my @objects = split( ' ', $exp_line);
foreach my $object (@objects)
{
my ($comp, $file) = split( ':', $object);
if (!defined $file)
{
$file = $comp;
$comp = '.';
}
my @files = split( ',', $file);
map { push @glkb_refs, [ 'C', $comp, $file, $line_ref ] } @files;
}
}
}

return @glkb_refs;
}




sub find_include_file($)
{
my ($file) = @_;
my ($filespec, @error_texts) = ( '', () );

if (ENV_is_abs_path_perl( $file))
{
if (PATH_file_exists( $file))
{
$filespec = $file;
} else
{
push @error_texts, "File '$file' not found";
}
} else
{
my $spec = PATH_search_file( $file, \@INCPATH);
if ($spec ne '')
{
$filespec = $spec;
} else
{
push @error_texts, "File '$file' not found in Include-Path:";
push @error_texts, map { "- $_"} @INCPATH;
ENV_sig( F => "File '$file' not found in Include-Path: @INCPATH");
}
}

return ($filespec, @error_texts);
}




sub get_includes()
{
my @inc_path;

my $key = $COMPONENT;
if (exists $INCPATHS{$key})
{
@inc_path = @{ $INCPATHS{$key} };

} else
{

@inc_path = FLINCS_get_incs( '.glkb', $COMPONENT);
foreach my $dir (@inc_path)
{

$dir = ENV_canonicalize_paths( "$SRC_DIR/$dir")
if (!ENV_is_abs_path_perl( $dir));
}

$INCPATHS{$key} = [ @inc_path ];
}
return @inc_path;
}




sub extract_abs_filespec($)
{
my ($item) = @_;
my $spec = '';

if ($item =~ m!^[-a-zA-Z0-9_]*(\./|\.\./|/|[a-zA-Z]:|\.\\|\.\.\\)(.+\.[^/.]+$)!)
{
if (defined $1)
{

$spec = "$1$2";

}
}

return $spec;
}




sub validate_compfile($$$)
{
my ($component,
$file,
$line_ref,
) = @_;
my $is_ok = 1;




if (!exists( $SCOPE_COMPS{$component}))
{
$is_ok = 0;
if (!exists( $GBS::ALL_COMPONENTS{$component}))
{
print_error( $line_ref, "No such Component '$component'");
} else
{
print_error( $line_ref, "Component '$component' not in scope");
}
} else
{
if (!exists( $BUILD_COMPS{$component}))
{
print_error( $line_ref, "Component '$component' does not generate for Build '$BUILD'");
$is_ok = 0;
}
}




if ($is_ok)
{
my $name = ENV_split_spec_n( $file);
my @src_files = ENV_glob( "$GBS::COMP_PATH/$component/src/$name.*");

if (!@src_files)
{
print_error( $line_ref, "No Source for file '$file' in Component '$component'");
$is_ok = 0;
}
}

return $is_ok;
}




sub error_ref($@)
{
my ($line_ref,
@texts,
) = @_;

$NR_ERRORS++;
return [ 'E', [ @texts ], $line_ref ];
}




sub print_error($$)
{
my ($line_ref,
$texts_ref,
) = @_;

$NR_ERRORS++;


GBSFILEGLO_file_sig( E => $line_ref, $texts_ref);
}




sub dbg_print_parses()
{
ENV_say( 1, "*** DBG START ***");
foreach my $file (@PARSES_ORDER)
{
ENV_say( 0, "FILE: $file");
my $glkb_refs_ref = $PARSES{$file};
foreach my $glkb_ref (@{$glkb_refs_ref})
{
my ($type, @rest) = @{$glkb_ref};
if ($type eq '>')
{

my @line_info = GBSFILEGLO_get_line_info( $rest[1]);
ENV_say( 0, "  $type $rest[0]",
"    [@line_info]");
} elsif ($type eq 'C' ||
$type eq 'F')
{


my @line_info = GBSFILEGLO_get_line_info( $rest[2]);
ENV_say( 0, "  $type $rest[0] $rest[1]",
"    [@line_info]");
} elsif ($type eq 'E' ||
$type eq '=')
{


my @line_info = GBSFILEGLO_get_line_info( $rest[1]);
ENV_say( 0, "  $type [@{$rest[0]}]",
"    [@line_info]");
} elsif ($type eq 'G')
{

ENV_say( 0, "  $type $rest[0]");
} else
{
ENV_sig( F => "Invalid type '$type'");
}
}
}
ENV_say( 1, "*** DBG END ***");

}

1;
