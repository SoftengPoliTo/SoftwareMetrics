#=================================================
#
#   scamsg.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::scamsg;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SCAMSG_init
SCAMSG_add_msg
SCAMSG_write_file
SCAMSG_read_file
SCAMSG_get_msg_ids
SCAMSG_get_msgs_and_levels
SCAMSG_msg_exists
SCAMSG_get_msg_data
SCAMSG_get_msg_data_element
);
}




use glo::env;
use glo::spit;
use glo::slurp;
use glo::flock;




sub SCAMSG_init($);
sub SCAMSG_add_msg($);
sub SCAMSG_write_file($);
sub SCAMSG_read_file();
sub SCAMSG_get_msg_ids();
sub SCAMSG_get_msgs_and_levels();
sub SCAMSG_msg_exists($);
sub SCAMSG_get_msg_data($);
sub SCAMSG_get_msg_data_element($$);








my $GBS_PLUGIN_PATH;	    # $GBS::PLUGIN_ROOT/$PLUGIN_NAME/$PLUGIN_REL

my $MSG_FILESPEC;	    # $GBS_PLUGIN_PATH/msg.txt
my @MSG_REFS;

my %MSG_REFS;

my $MSG_FILE_CHANGED;




sub SCAMSG_init($)
{
my ($GBS_PLUGIN_PATH,
) = @_;

$MSG_FILESPEC  = "$GBS_PLUGIN_PATH/msg.txt";

return $MSG_FILESPEC;
}






sub SCAMSG_add_msg($)
{
my ($msg_ref,   # [ $msg_id, $level, $level_text, $msg_text, $help_file_url, $severity, $severity_index ]
) = @_;


my $msg_id = $msg_ref->[0];
push @MSG_REFS, $msg_ref;
$MSG_REFS{$msg_id} = $msg_ref;
$MSG_FILE_CHANGED = 1;
}





sub SCAMSG_write_file($)
{
my ($force_write,
) = @_;


if ($MSG_FILE_CHANGED || $force_write)
{
ENV_say( 1, "Writing SCA Msg file...");

my @lines;
foreach my $msg_id (sort keys %MSG_REFS)
{
push @lines, join( "\t", @{$MSG_REFS{$msg_id}});
}
my $fh = FLOCK_ex_wait( "$MSG_FILESPEC.lck");
SPIT_file_nl( $MSG_FILESPEC, \@lines);
FLOCK_unlock( $fh);
}
$MSG_FILE_CHANGED = 0;

return $MSG_FILESPEC;
}





sub SCAMSG_read_file()
{
my $fh = FLOCK_sh_wait( "$MSG_FILESPEC.lck");
@MSG_REFS = map { [ split( "\t", $_) ] } SLURP_file( $MSG_FILESPEC);
FLOCK_unlock( $fh);
%MSG_REFS = map { $_->[0] => $_ } @MSG_REFS;
$MSG_FILE_CHANGED = 0;
}




sub SCAMSG_get_msg_ids()
{
my @msg_ids;

foreach my $ref (@MSG_REFS)
{
push @msg_ids, $ref->[0];	# $msg_id, $level
}

return @msg_ids;
}




sub SCAMSG_get_msgs_and_levels()
{
my @msg_level_refs;	    # [ $msg_id, $level ]

foreach my $ref (@MSG_REFS)
{
push @msg_level_refs, [ $ref->[0], $ref->[1]];	# $msg_id, $level
}

return @msg_level_refs;
}




sub SCAMSG_msg_exists($)
{
my ($msg_id) = @_;


return (exists $MSG_REFS{$msg_id}) ? 1 : 0;
}




sub SCAMSG_get_msg_data($)
{
my ($msg_id) = @_;



return (wantarray) ? @{$MSG_REFS{$msg_id}} : $MSG_REFS{$msg_id};
}





sub SCAMSG_get_msg_data_element($$)
{
my ($msg_id,
$index,
) = @_;


return $MSG_REFS{$msg_id}->[$index];
}

1;


