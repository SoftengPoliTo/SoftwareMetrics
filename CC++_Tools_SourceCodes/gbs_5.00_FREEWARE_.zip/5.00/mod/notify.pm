#=================================================
#
#   notify.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::notify;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
NOTIFY_submit
NOTIFY_get_lines
);
}




use glo::env;
use glo::list;
use glo::proc;
use glo::banner;
use mod::gbsenv;
use mod::gbscmd;
use mod::run;




sub NOTIFY_submit($$$$);
sub NOTIFY_get_lines($$$$);

sub get_xterm_data($$$);








sub NOTIFY_submit($$$$)
{
my ($command_heading,	# $gbssys_command ($build_or_tool / $audit)
$rc,
$logfile,
$state,
) = @_;


ENV_whisper( 1, "Notify user (if present)");
if (GBSENV_gui_available())
{
RUN_tkx( notify_tkx => 0, [ $command_heading, $rc, $logfile, $state ]);
} else
{
my @lines = NOTIFY_get_lines( $command_heading, $rc, $logfile, $state);
my ($title, $geometry_ref, $colour_ref, $icon) = get_xterm_data( $command_heading, $rc, \@lines);
PROC_spawn_detached_xterm( GBSCMD_get_gbs_command( notify => [ $command_heading, $rc, $logfile, $state ]),
$title, 0, $geometry_ref, $colour_ref, $icon);	# no pause
}
}




sub NOTIFY_get_lines($$$$)
{
my ($command_heading,	# $gbssys_command ($build_or_tool / $audit)
$rc,
$logfile_spec,
$state,
) = @_;
my @lines;

push @lines, "Batch Job  : $command_heading $state-END",
"Exit-Status: $rc",
"Logfile    : $logfile_spec";

if ($rc == 0)
{
@lines = BANNER_box( '-', '| ', \@lines);
} else
{
@lines = BANNER_box( '#', '## ', \@lines);
}



return @lines;
}





sub get_xterm_data($$$)
{
my ($command_heading,	# $gbssys_command ($build_or_tool / $audit)
$rc,
$lines_ref		# Must be result of NOTIFY_get_lines
) = @_;
my ($title, $geometry_ref, $colour_ref, $icon);




$title = "GBS: Notify $command_heading";




{
my ($cols, $rows);
my ($x, $y);

my ($gbssys_command, $build_or_tool, $audit) = $command_heading =~ m!^(.+) \((.+) / (.+)\)$!;
if ($gbssys_command eq 'gbssysbuild' ||
$gbssys_command eq 'gbssysmake')
{
my $b_index = LIST_firstidx_str( $build_or_tool, \@GBS::BUILDS);

$x = 90 + 0 + $b_index * 10;
$y = 50 + 0 + $b_index * 10;
} elsif ($gbssys_command eq 'gbssysaudit')
{
my $a_index = LIST_firstidx_str( $build_or_tool, \@GBS::AUDITS);

my $b_index = LIST_firstidx_str( $build_or_tool, \@GBS::BUILDS);

$x = 90 +  0 + $a_index * 10;
$y = 50 + 20 + $a_index * 10 + $b_index * 10;
} else	#($gbssys_command eq 'gbssystool')
{
my $t_index = LIST_firstidx_str( $build_or_tool, \@GBS::TOOLS);

$x = 90 +  0 + $t_index * 10;
$y = 50 + 40 + $t_index * 10;
}

$cols = length( $lines_ref->[0]) + 1;   # \n
$rows = @{$lines_ref} + 2;		# 1 ASK + 1 extra

$geometry_ref = [ $cols, $rows, $x, $y ];
}




{
my ($fg, $bg);
if ($rc == 0)
{
$fg = 'black';
$icon = "$GBS::SCRIPTS_PATH/doc/images/gbs.gif";
} else
{
$fg = 'light_red';
$icon = "$GBS::SCRIPTS_PATH/doc/images/gbs_test.gif";
}
$bg = 'white';

$colour_ref = [ $fg, $bg ];
}

return ($title, $geometry_ref, $colour_ref, $icon);
}

1;


