#=================================================
#
#   swset.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::swset;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SWSET_subsys
SWSET_component
SWSET_build
SWSET_audit
SWSET_tool
);
}




use glo::env;
use mod::gbsglo;
use mod::swglo;
use mod::sws;
use mod::swc;
use mod::swb;
use mod::swa;
use mod::swt;




sub SWSET_subsys($$$$);
sub SWSET_component($$$);
sub SWSET_build($);
sub SWSET_audit($);
sub SWSET_tool($);








sub SWSET_subsys($$$$)
{
my ($subsys,	# '' (default), '-' (none), number or name
$component,	# '' (default), '-' (none), number or name
$build,	# '' (default), '-' (none), number or name
$audit,		# '' (default), '-' (none), number or name
) = @_;
my $new_subsys;	# '' (none) or subsys_name




$new_subsys = SWGLO_validate_subsys( $subsys);
my $new_component = ($new_subsys eq '') ? '' : SWGLO_validate_component( $new_subsys, $component);
my $new_build = SWGLO_validate_build( $new_subsys, $new_component, $build);
my $new_audit = SWGLO_validate_audit( $new_subsys, $new_component, $new_build, $audit);





if ($new_subsys ne $GBS::SUBSYS)
{
SWC_set( $new_subsys, '', 0);	# Clear Current Component

my $must_write = ($new_subsys ne '' || $subsys eq '-');
SWS_set( $new_subsys, $must_write);
}

{
my $must_write = ($new_component ne '' || $component eq '-');
SWC_set( $new_subsys, $new_component, $must_write);
}

if ($new_build ne $GBS::TOOL)
{
SWB_set( $new_build, 1);
}
if ($new_audit ne $GBS::AUDIT)
{
SWA_set( $new_audit, 1);
}




ENV_sig( W => "No current SubSystem")
if ($new_subsys eq '' && $subsys ne '-');
ENV_sig( W => "No current Component")
if ($new_component eq '' && GBSGLO_subsystem_is_full_gbs( $new_subsys) && $component ne '-');
ENV_sig( W => "No current Build")
if ($new_build eq '' && $build ne '-');

return $new_subsys;
}




sub SWSET_component($$$)
{
my ($component,	# '' (default), '-' (none), number or name
$build,	# '' (default), '-' (none), number or name
$audit,		# '' (default), '-' (none), number or name
) = @_;
my $new_component;	# '' (none) or component_name




$new_component = SWGLO_validate_component( $GBS::SUBSYS, $component);
my $new_build = SWGLO_validate_build( $GBS::SUBSYS, $new_component, $build);
my $new_audit = SWGLO_validate_audit( $GBS::SUBSYS, $new_component, $new_build, $audit);





if ($new_component ne $GBS::COMPONENT)
{
my $must_write = ($new_component ne '' || $component eq '-');
SWC_set( $GBS::SUBSYS, $new_component, $must_write);
}

if ($new_build ne $GBS::TOOL)
{
SWB_set( $new_build, 1);
}
if ($new_audit ne $GBS::AUDIT)
{
SWA_set( $new_audit, 1);
}




ENV_sig( W => "No current Component")
if ($new_component eq '' && $component ne '-');
ENV_sig( W => "No current Build")
if ($new_build eq '' && $build ne '-');

return $new_component;
}




sub SWSET_build($)
{
my ($build,	# '' (default), '-' (none), number or name
) = @_;
my $new_build;	# '' (none) or build_name




$new_build = SWGLO_validate_build( $GBS::SUBSYS, $GBS::COMPONENT, $build);





if ($new_build ne $GBS::BUILD)
{
my $must_write = $new_build ne '' || $build eq '-';
SWB_set( $new_build, $must_write);
}




ENV_sig( W => "No current Build")
if ($new_build eq '' && $build ne '-');

return $new_build;
}




sub SWSET_audit($)
{
my ($audit,	# '' (default), '-' (none), number or name
) = @_;
my $new_audit;	# '' (none) or audit_name




$new_audit = SWGLO_validate_audit( $GBS::SUBSYS, $GBS::COMPONENT, $GBS::BUILD, $audit);





if ($new_audit ne $GBS::AUDIT)
{
my $must_write = $new_audit ne '' || $audit eq '-';
SWA_set( $new_audit, $must_write);
}




ENV_sig( W => "No current Audit")
if ($new_audit eq '' && $audit ne '-');

return $new_audit;
}




sub SWSET_tool($)
{
my ($tool,	# '' (default), '-' (none), number or name
) = @_;
my $new_tool;	# '' (none) or tool_name




$new_tool = SWGLO_validate_tool( $GBS::SUBSYS, $tool);




if ($new_tool ne $GBS::TOOL)
{
my $must_write = $new_tool ne '' || $tool eq '-';
SWT_set( $new_tool, $must_write);
}




ENV_sig( W => "No current Tool")
if ($new_tool eq '' && $tool ne '-');

return $new_tool;
}

1;


