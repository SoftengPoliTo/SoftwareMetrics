#=================================================
#
#   plg.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::plg;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
PLG_get_plugin_names
PLG_get_plugins
PLG_get_plugin_data
);
}




use glo::env;
use glo::slurp;




sub PLG_get_plugin_names($$);
sub PLG_get_plugins($);
sub PLG_get_plugin_data($$$);




my $PLATFORM = (ENV_is_win32()) ? 'win32' : 'linux';











my $GBS_PLUGINS_PATH = "$GBS::SCRIPTS_PATH/plugins";

my @PLUGIN_DEFS = (

[ 'Function',    'IU'    ],
[ 'Command',     'RDCE'  ],
[ 'Ask_default', 'YN+'  ],
);
my %COMMAND_NR_ARGS = (

R =>    [ 1, 1 ],		    # install script
D =>    [ 1, 1 ],		    # directory
C =>    [ 1, 2 ],		    # from [to]
E =>    [ 1, undef ],	    # text
);























sub PLG_get_plugin_names($$)
{
my ($plugin_type,		# 'audit', 'build' or 'tool'
$get_all_platforms,	# Bool
) = @_;
my @plugin_names;

$plugin_type = ($plugin_type eq 'build') ? 'build' : ($plugin_type eq 'tool') ? 'tool' : 'audit';
my @plugin_files = sort ( ENV_glob( "$GBS_PLUGINS_PATH/$plugin_type/*.plg"));
if ($get_all_platforms)
{
foreach my $filespec (@plugin_files)
{
my $plugin_dir = ENV_split_spec_n( $filespec);
push @plugin_names, $plugin_dir;
}
} else
{
foreach my $filespec (@plugin_files)
{
my ($platforms, $description) = SLURP_file_head( $filespec, 2);
my @platforms = split( ' ', $platforms);
if (grep( $PLATFORM eq $_, @platforms))
{
my $plugin_dir = ENV_split_spec_n( $filespec);
push @plugin_names, $plugin_dir;
}
}
}

return @plugin_names;
}




sub PLG_get_plugins($)
{
my ($plugin_type) = @_;	# 'audit', 'build' or 'tool'
my @plugin_refs;


my @plugin_files = ( ENV_glob( "$GBS_PLUGINS_PATH/$plugin_type/*.plg") );
foreach my $filespec (sort @plugin_files)
{
my ($platforms, $description) = SLURP_file_head( $filespec, 2);
my @platforms = split( ' ', $platforms);
if (grep( $PLATFORM eq $_, @platforms))
{
my $plugin_dir = ENV_split_spec_n( $filespec);
push @plugin_refs, [ $plugin_dir, $description ];
}
}

return @plugin_refs;
}




sub PLG_get_plugin_data($$$)
{
my ($plugin_dir,
$plugin_type,	    # 'audit', 'build' or 'tool'
$install_or_update, # 'I' or 'U'
) = @_;
my @data_refs;





my $plugin_path = "$GBS_PLUGINS_PATH/$plugin_type";
my $plugin_filespec = "$plugin_path/$plugin_dir.plg";
my $from_path = "$plugin_path/$plugin_dir";

my (undef, undef, undef, @install_lines) = SLURP_file( $plugin_filespec);




foreach my $line (@install_lines)
{



next
if ($line eq '' || substr( $line, 0, 1) eq '#');


ENV_sig( F => "Line does not start with '-'", $line)
if (substr( $line, 0, 1) ne '-');
my ($mnem, @args) = split( ' ', substr( $line, 1));
ENV_sig( F => "Command must contain 3 characters (-$mnem)", $line)
if (length( $mnem) != 3);
my @mnem_chars;
foreach my $i (0..2)
{
my $mnem_char = substr( $mnem, $i, 1);
my ($name, $values, @max_args) = @{$PLUGIN_DEFS[$i]};
my $index = index( $values, $mnem_char);
ENV_sig( F => "$name ($mnem_char) must be one of '$values'", $line)
if ($index < 0);
push @mnem_chars, $mnem_char;
}
my ($func, $command, $ask_default) = @mnem_chars;
my ($min_arg, $max_arg) = @{$COMMAND_NR_ARGS{$command}};
ENV_sig( F => "'$command' requires at least $min_arg arguments (@args)", $line)
if ($min_arg && @args < $min_arg);
ENV_sig( F => "'$command' requires at most $max_arg arguments (@args)", $line)
if ($max_arg && @args > $max_arg);




if ($command eq 'C')	    # Copy Files    <from_file> [ <to_file> ]
{



my ($from_file, $to_file) = @args;	    # names may contain dirs!
if (ENV_is_wildcard( $from_file) && $to_file)
{
ENV_sig( F => "Cannot specify 'file-to' ($to_file) with wildcards ($from_file)", $line);
}
} elsif ($command eq 'R')   # Run Script    <script_name> + <script_spec>
{



my $script = $args[0];
my $script_spec = "$from_path/$script";
ENV_sig( F => "Install script '$script_spec' not found", $line)
if (!-f $script_spec);
$args[1] = $script_spec;
} elsif ($command eq 'D')   # Create Directory	<rel_directory_name>
{
} else # ($command eq 'E')  # Echo <@text> => <$text>
{
@args = ("@args");
}

if ($func eq $install_or_update)
{
push @data_refs, [ $func, $command, $ask_default, @args ];

}
}

return @data_refs;
}

1;
