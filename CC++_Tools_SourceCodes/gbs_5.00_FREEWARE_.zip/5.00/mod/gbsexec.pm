#=================================================
#
#   gbsexec.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbsexec;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSEXEC_gen
GBSEXEC_audit
);
}




use glo::env;
use mod::cfo;
use mod::bld;
use mod::gbsbgjob;




sub GBSEXEC_gen($$);
sub GBSEXEC_audit($$);

sub execute($$$);












my $OPTIONS_BANNER;






sub GBSEXEC_gen($$)
{
my ($nr_cfo,
$must_ignore_errors,
) = @_;
my $rc = 0;




$OPTIONS_BANNER = BLD_init();	# Also sets: GBS_BLD_*, GBS_MODE, GBS_OPT, etc.




$rc = execute( 'gbsbuild', $nr_cfo, $must_ignore_errors);

return $rc;
}





sub GBSEXEC_audit($$)
{
my ($nr_cfo,
$must_ignore_errors,
) = @_;
my $rc = 0;




$OPTIONS_BANNER = BLD_init();	# Also sets: GBS_AUDIT_envs




$rc = execute( 'gbsaudit', $nr_cfo, $must_ignore_errors);

return $rc;
}




sub execute($$$)
{
my ($batch_name,		    # gbsbuild gbsaudit
$nr_cfo,
$must_ignore_errors,	    # bool
) = @_;
my $rc = 0;

ENV_say( 1, "** $OPTIONS_BANNER");




my @pre_options = CFO_get_pre_options();




my $must_stop = 0;
foreach my $order_ref (CFO_get_items())
{

last
if ($must_stop);
foreach my $comp_ref (@{$order_ref})
{
my ($component, $files_ref, $opts_ref) = @{$comp_ref};


ENV_chdir( "$GBS::COMP_PATH/$component/src");
my $is_queued;

{

my @bgjob_refs = BLD_get_commands( $component, $files_ref, [ @pre_options, @{$opts_ref} ]);
$is_queued = GBSBGJOB_batch_queue( $batch_name, $component, \@bgjob_refs);
}
if (!$is_queued && !$must_ignore_errors)
{
$must_stop = 1;
last;
}
}
my $this_rc = GBSBGJOB_batch_wait();
$rc = $this_rc
if ($this_rc > $rc);
last
if ($rc != 0 && !$must_ignore_errors);
}

return $rc;
}

1;

