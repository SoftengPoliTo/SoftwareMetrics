#=================================================
#
#   gbssysaudit.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSSYSAUDIT @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::genopt;
use mod::gbsenv;
use mod::gbsoptenv;
use mod::validate;
use mod::gbssys;














$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( 'audit');













{
my @genopts = (
[ '<*>',    'steps',	    'sao',      "", "Steps and/or Aliases. <empty> == all select steps, 'ALL' == force all steps, '?' == show steps" ],
[ 'i' ,	    'ignore_errors', 'bso',      0, "Continue generation after error(s)" ],
[ 'vs',	    'view_sum',	    'bso',       1, "View summary at completion" ],
[ 'audits', 'audits',	    "saos.,$GBS::AUDITS", '*', "(wild-)Audits to run. '' or '*' == All, '.' == Current" ],
[ 'builds', 'builds',	    "saos.,$GBS::BUILDS", '*', "(wild-)Builds to Build. '' or '*' == All, '.' == Current" ],
[ 'files',  'files',	    'sao', '*:*.*', "Files to audit" ],
[ 'aud',    'run_audit',    'bso',       1, "Run audit" ],
[ 'sum',    'run_summary',  'bso',       1, "Create summary" ],
[ 'fg',	    'foreground',   'bso',       0, "Runs in the foreground if set" ],
[ 'at',	    'delay',	    'tso',   'now', "Starting time (10:20), delta (+10:10) or now" ],
[ 'sm',	    'mail',	    'bso',       0, "Send mail on completion" ],
[ 'n',	    'notify',	    'bso',       1, "Notify user on completion (bg/nowait only)" ],
[ 'wait',   'wait',         'bso',       0, "Wait for completion of bg jobs" ],
[ 'jobs',   'jobs',    'isor1..9',       2, 'Max nr parallel jobs within a submitted job' ],
[ 'c',	 'comment',	    'sso',      "", 'Comments - will be shown in Summary - Specify %20 for space' ],
);
my @genconflicts = (
[ [ fg   => 1 ], '=' => 'at', '=' => 'sm', '=' => 'n' ],
[ [ wait => 1 ], '=' => 'n' ],
[ [ sum  => 0 ], [ '=' => vs => 1 ] ],
);
my @genenvs = qw( LOG_PATH FLAGS_* APP_* );
GENOPT_set_optdefs( 'gbssysaudit', \@genopts,
'Perform an AUDIT on part of or whole System',
'Summary files are written to $GBS_SILO_PATH/audits. View with gbssilo');
GENOPT_set_conflicts( \@genconflicts);
GENOPT_set_envdefs( \&GBSOPTENV_set, \&GBSOPTENV_print, \@genenvs);
GENOPT_parse();
}
my @STEPS = GENOPT_get( 'steps');
my $IGNORE_ERRORS = GENOPT_get( 'ignore_errors');
my $MUST_VIEW_SUM = GENOPT_get( 'view_sum');		## noperlcheck
my @AUDITS = GENOPT_get( 'audits');
my @BUILDS = GENOPT_get( 'builds');
my @FILES = GENOPT_get( 'files');

my $DO_AUDIT = GENOPT_get( 'run_audit');		## noperlcheck
my $DO_SUM = GENOPT_get( 'run_summary');		## noperlcheck
my $FOREGROUND = GENOPT_get( 'foreground');
my $DELAY = GENOPT_get( 'delay');
my $MAIL = GENOPT_get( 'mail');
my $NOTIFY = GENOPT_get( 'notify');
my $WAIT = GENOPT_get( 'wait');
my $JOBS = GENOPT_get( 'jobs');				## noperlcheck
my $COMMENT = GENOPT_get( 'comment');




$NOTIFY = 0
if ($WAIT);

{



VALIDATE_root();




GBSSYS_init(
'audit',
$IGNORE_ERRORS,
\@BUILDS,
\@AUDITS,
\@FILES,
$FOREGROUND,
[ $DELAY, $MAIL, $NOTIFY, $COMMENT ],
$WAIT,
);




my @excludes = qw( steps builds audits files delay wait comment foreground );	# Passed in GBSSYS_init or explicit (STEPS)
my @opts = GENOPT_get_changed( \@excludes );    # Get the not-default options
$RC = GBSSYS_submit( \@STEPS, \@opts);
}




ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
}


