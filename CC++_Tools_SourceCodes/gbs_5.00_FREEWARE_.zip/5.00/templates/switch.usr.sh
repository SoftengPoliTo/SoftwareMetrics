#=================================================
#   File:        %FILE%
#   Path:        %PATH%
#   System Name: %SYSTEM_NAME%
#=================================================
SWITCH_RC=0
if [[ $1 = "entry" ]]
then
    #
    #	set items
    #	executed AFTER switch.gbs entry
    #
    true
elif [[ $1 = "exit" ]]
then
    #
    #	unset items
    #
    #	executed BEFORE switch.gbs exit
    true
else
    echo "SWITCH.GBS: *****"
    echo "SWITCH.GBS: ** switch.usr.sh: Usage = . switch.usr.sh [ entry | exit ]"
    echo "SWITCH.GBS: *****"
    SWITCH_RC=1
fi

[[ $SWITCH_RC = 1 ]] && export GBS_RC=1
unset SWITCH_RC

##EOF##
