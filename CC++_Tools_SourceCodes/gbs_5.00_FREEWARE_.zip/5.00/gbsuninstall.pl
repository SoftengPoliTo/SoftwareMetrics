#=================================================
#
#   gbsuninstall.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright © 2010-2020 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSUNINSTALL @ARGV") if ($ENV{GBSDEBUG_FILE});




use 5.016_003;
use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::slurp;
use glo::genopt;
use glo::ask;
use glo::format;
use mod::gbsenv;
use mod::settings;
use mod::profile;




sub do_action($);
sub do_ask();
sub do_all();
sub do_full();
sub do_others();
sub do_versions();
sub uninstall_version($);
sub get_versions($);




my $IS_DEVELOPMENT = ENV_is_development();




my %ACTIONS = (

ask		=> [ 0, \&do_ask ],
all		=> [ 0, \&do_all ],
full	=> [ 0, \&do_full ],
others	=> [ 0, \&do_others ],
versions	=> [ 1, \&do_versions ],
);

my $CURRENT_INDICATOR = ' (current)';
my $CURRENT_INDICATOR_QM = quotemeta $CURRENT_INDICATOR;




my $INTERACTIVE = 0;
my $CURRENT_VERSION_DELETED = 0;
my $NR_VERSIONS_NOT_DELETED = 0;
my $GBS_IS_ACTIVE;






$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ '<1>',  'action',	'ssos?,all,others,full,versions',   '',  'Action. Default is interactive ask'   ],
[ '<*>',  'versions',   'sao',				    '',  'Versions  List'			    ],
);
GENOPT_set_optdefs( 'gbsuninstall', \@genopts,
'Uninstall GBS version(s).',
undef);
GENOPT_parse();
}
my $ACTION = GENOPT_get( 'action');
my @LIST = GENOPT_get( 'versions');




$GBS_IS_ACTIVE = GBSENV_gbs_is_active();

if (!$GBS_IS_ACTIVE)	    # GBS::FULL_VERSION == ''
{
ENV_say( 1, 'No Current version');
} elsif ($GBS::FULL_VERSION eq $GBS::SCRIPTS_REL)
{
ENV_say( 1, "Current version is '$GBS::SCRIPTS_REL'");
} else
{
ENV_say( 1, "Current version is '$GBS::SCRIPTS_REL' ($GBS::FULL_VERSION)");
}

if ($ACTION eq '')
{
$ACTION = 'ask';
$INTERACTIVE = 1;
}

if ($ACTION eq '?')
{
ENV_say( 1, 'Actions: ask all others full versions');
} else
{
my $action_ref = $ACTIONS{ $ACTION };
if (defined $action_ref)
{
my ($list_required, $function_ref) = @{$action_ref};
if ($list_required)
{
ENV_sig( EE => 'Version(s) required')
if (@LIST == 0);
} else
{
ENV_sig( EE => "Version(s) (@LIST) not allowed")
if (@LIST != 0);
}




$function_ref->();
} else
{
ENV_sig( F => "Invalid action '$ACTION'");
}
}




ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
}




sub do_ask()
{
my @all_versions = get_versions( 1);
ENV_say( 1, 'Installed GBS versions:');
ENV_say( 0, FORMAT_cols( 0, 2, ' | ', 2, \@all_versions));

my @main_menu_items = (
[ 'Uninstall Full                (Includes current and GBS_BASE)',  sub { do_action( \&do_full) }     ],
[ 'Uninstall All Versions        (Includes current)',		    sub { do_action( \&do_all) }      ],
[ 'Uninstall All Other Versions  (Not current)',		    sub { do_action( \&do_others) }   ],
[ 'Uninstall Specific Versions',				    sub { do_action( \&do_versions) } ],
);
ASK_menu( 'Select function to perform', \@main_menu_items, undef);
}




sub do_action($)
{
my ($func_ref,
) = @_;

$func_ref->();

if ($CURRENT_VERSION_DELETED)
{
ENV_sig( W => 'Current Version deleted.',
'You cannot continue with GBS');
ENV_exit( $RC);
}
}




sub do_full()
{
ENV_say( 1, 'Uninstall Full')
if (!$INTERACTIVE);




do_all();

if ($NR_VERSIONS_NOT_DELETED == 0)
{
ENV_say( 1, 'Uninstalling GBS Environment...');




ENV_say( 2, "Delete: $GBS::SCRIPTS_ROOT");
if ($IS_DEVELOPMENT)
{
ENV_say( 1, "Simulate Delete of $GBS::SCRIPTS_ROOT");
} else
{
unlink "$GBS::SCRIPTS_ROOT/Readme.txt";
ENV_rmdir( $GBS::SCRIPTS_ROOT, 1, 'E');
}




if ($GBS::SCRIPTS_ROOT =~ m!/RMC/GBS$!)
{
my $rmc_path = ENV_parent_path( $GBS::SCRIPTS_ROOT);	    # remove /GBS
ENV_say( 2, "Delete: $rmc_path");
if ($IS_DEVELOPMENT)
{
ENV_say( 1, "Simulate Delete of $rmc_path");
} else
{
if (ENV_dir_count( $rmc_path, 'E') == 0)
{
ENV_rmdir( $rmc_path, 1, 'E');
}
}
}





SETTINGS_uninstall_gbs();
} else
{
ENV_say( 1, 'Not all versions deleted');
}
}




sub do_all()
{
ENV_say( 1, 'Uninstall All Versions')
if (!$INTERACTIVE);

map { uninstall_version( $_) } get_versions(1);
}




sub do_others()
{
ENV_say( 1, 'Uninstall Other Versions')
if (!$INTERACTIVE);

my @all_versions = grep ( $_ ne $GBS::SCRIPTS_REL, get_versions(1) );
map { uninstall_version( $_) } @all_versions;
}




sub do_versions()
{
my @all_versions = get_versions(1);

if (@all_versions)
{
if ($INTERACTIVE)
{
my @all_versions = get_versions(1);
my $version;
do
{
$version = ASK_value_from_menu( '', -1, undef, [ '<Exit>', @all_versions ]);
if ($version ne '<Exit>')
{
uninstall_version( $version);
@all_versions = get_versions(1);

}
} while ($version ne '<Exit>' && @all_versions);
} else
{
ENV_say( 1, 'Uninstall Specific Versions');




foreach my $version (@LIST)
{
ENV_sig( EE => "Version '$version' does not exist. Valid versions are:", @all_versions)
if (!-d "$GBS::SCRIPTS_ROOT/$version");
}




map { uninstall_version( $_) } @LIST;
}
} else
{
ENV_say( 1, "No versions found in '$GBS::SCRIPTS_ROOT'");
}
}




sub uninstall_version($)
{
my ($version) = @_;

$version =~ s/$CURRENT_INDICATOR_QM$//;

if ($INTERACTIVE && ! ($version eq $GBS::SCRIPTS_REL && $GBS_IS_ACTIVE))
{
if ($version eq $GBS::SCRIPTS_REL)
{
ENV_say( 1, "Uninstalling $version CURRENT...");
$CURRENT_VERSION_DELETED = 1;




PROFILE_open( $GBS::BASE_PATH);
PROFILE_set( GBS_SCRIPTS_REL => '');
PROFILE_close( 1);	    # 1 == must_write
} else
{
ENV_say( 1, "Uninstalling $version...");
}




my $version_path = "$GBS::SCRIPTS_ROOT/$version";
ENV_say( 2, "Delete: $version_path");
if ($IS_DEVELOPMENT)
{
ENV_say( 2, '- Simulate Delete');
} else
{
ENV_rmtree( $version_path, 1, 1, 'E');	    # do not delete top-dir, force_delete
}




SETTINGS_uninstall_version( $version);
} else
{
$NR_VERSIONS_NOT_DELETED++;
ENV_sig( W => "Cannot uninstall current version ($version)",
"Execute 'gbsexit' and then try again");
}
}








sub get_versions($)
{
my ($add_current_indicator,	# bool	TBS Remove? allways 1?
) = @_;

my @all_versions;

@all_versions = grep( /^(\d+\.\d\d[\d_-]*|beta[\d_-]*)$/, SLURP_dir_dirs( $GBS::SCRIPTS_ROOT, 0));
if ($add_current_indicator)
{
foreach my $version (@all_versions)
{
if ($GBS_IS_ACTIVE && $version eq $GBS::SCRIPTS_REL)
{
$version = "$version$CURRENT_INDICATOR";
last;
}
}
}

return @all_versions;
}


