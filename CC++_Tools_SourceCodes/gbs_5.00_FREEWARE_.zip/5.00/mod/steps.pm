#=================================================
#
#   steps.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::steps;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
STEPS_read
STEPS_get_stepnames
STEPS_get_step_data
STEPS_get_aliasnames
STEPS_get_alias_data

STEPS_get_subsystems_order
);
}




use glo::env;
use glo::slurp;
use mod::gbsglo;
use mod::gbssfile;
use mod::gbsfileglo;
use mod::fspec;




sub STEPS_read();
sub STEPS_get_stepnames($);
sub STEPS_get_step_data($);
sub STEPS_get_aliasnames();
sub STEPS_get_alias_data($);

sub STEPS_get_subsystems_order($);

sub read_steps();
sub step_entry($$);
sub do_step_command($$$$$);
sub do_step_tool($$$$$);
sub step_exit($$);
sub alias_entry($$);
sub do_alias_steps($$$$$);
sub do_alias_build($$$$$);




my $STEPS_READ = 0;




my $CUR_SUBSYS;








my @STEP_NAMES_ORDER;




my @ALIAS_NAMES_ORDER;




my %ALL_EXEC = (
SELECT  => 1,	# Will be executed if selected
SPECIFY => 1,	# Will only be executed if explicitly specifed
ALWAYS => 1,	# Will always be executed, not if job fails
FORCE   => 1,	# Will always be executed, even if job fails
);

my %STEPS;



























my %STEP_DEFS = (
EXEC	    => [ 'sss', 'SELECT',  0, 2,     1,  undef,	            \%ALL_EXEC ],
TOOL	    => [ 'ss' , '',	   0, 1, undef,  \&do_step_tool,    undef      ],
COMMAND	    => [ 'pc' , [],        0, 1, undef,  \&do_step_command, undef      ],
BUILD	    => [ 'sb' , 1,         0, 3,   [1],  undef,		    undef      ],
AUDIT	    => [ 'sb' , 1,	   0, 3,   [1],  undef,		    undef      ],
);

my %ALIAS_DEFS = (
STEPS	    => [ 'as' , [],        0, undef,   [1],  \&do_alias_steps,  undef ],
BUILD	    => [ 'ss' , '',	   0, undef,     1,  \&do_alias_build, undef ],
);










my %SECTION_DEFS = (
STEP     => [ 'S', 1, 0,   1, \%STEP_DEFS,  \&step_entry,  \&step_exit ],
ALIAS    => [ 'S', 0, 0,   1, \%ALIAS_DEFS, \&alias_entry, undef ],
);




sub STEPS_read()
{
read_steps();
}




sub STEPS_get_stepnames($)
{
my ($jobtype) = @_;		# undef (all), build, make, audit, tool

read_steps()
if (!$STEPS_READ);

if (defined $jobtype)
{
my @names;
if ($jobtype eq 'build' || $jobtype eq 'make')
{
foreach my $stepname (@STEP_NAMES_ORDER)
{
my $step_ref = $STEPS{STEP}->{$stepname};
push @names, $stepname
if ($step_ref->{BUILD});
}
} elsif ($jobtype eq 'audit')
{
foreach my $stepname (@STEP_NAMES_ORDER)
{
my $step_ref = $STEPS{STEP}->{$stepname};
push @names, $stepname
if ($step_ref->{AUDIT});
}
} else	#($jobtype eq 'tool')
{
foreach my $stepname (@STEP_NAMES_ORDER)
{
my $step_ref = $STEPS{STEP}->{$stepname};
push @names, $stepname
if ($step_ref->{TOOL} ne '');
}
}
return @names;
} else
{
return @STEP_NAMES_ORDER;
}
}





sub STEPS_get_step_data($)
{
my ($stepname) = @_;
my @data;




read_steps()
if (!$STEPS_READ);

my $step_ref = $STEPS{STEP}->{$stepname};
if (defined $step_ref)
{



foreach my $key (qw( COMMAND TOOL EXEC BUILD AUDIT ))
{
my $value = $step_ref->{$key};
$value = ''
if (!defined $value);
push @data, $value;
}
}

return @data;
}




sub STEPS_get_aliasnames()
{
read_steps()
if (!$STEPS_READ);

return @ALIAS_NAMES_ORDER;
}





sub STEPS_get_alias_data($)
{
my ($aliasname) = @_;
my @data;


read_steps()
if (!$STEPS_READ);

my $alias_ref = $STEPS{ALIAS}->{$aliasname};
if (defined $alias_ref)
{
foreach my $key (qw( STEPS BUILD ))
{
push @data, $alias_ref->{$key};
}
}

return @data;
}




sub read_steps()
{
my $full_filespec = FSPEC_steps( 'steps', $GBS::ROOT_PATH);    # .gbs or .usr
if (-e $full_filespec)
{



GBSSFILE_parse( \%STEPS, $full_filespec, undef, \%SECTION_DEFS);




foreach my $subsys (@GBS::ALL_SUBSYSTEMS)
{
if (!exists $STEPS{STEP}->{$subsys})
{
ENV_sig( EE => "SubSystem: '$subsys' is not specified in any STEP.",
"Please 'gbsedit steps.gbs|.usr' and add the SubSystem.");
}
}
foreach my $tool (@GBS::TOOLS)
{
my $found = 0;
foreach my $step (@STEP_NAMES_ORDER)
{
if ($STEPS{STEP}->{$step}->{TOOL} eq $tool)
{
$found = 1;
last;
}
}
if (!$found)
{
ENV_sig( EE => "Tool: '$tool' is not specified in any STEP.",
"Please 'gbsedit steps.gbs|.usr' and add the Tool.");
}
}


} else
{



my @lines;




if (@GBS::ALL_SUBSYSTEMS)
{
foreach my $step (@GBS::ALL_SUBSYSTEMS)
{



my %step = map { $_ => $STEP_DEFS{$_}->[1] } keys %STEP_DEFS;	# $default
$STEPS{STEP}->{$step} = \%step;
push @{$STEPS{STEP}->{'.'}->{ORDER}}, $step;
push @STEP_NAMES_ORDER, $step;
}
if (@STEP_NAMES_ORDER > 1)
{
my $nr_subsys = @GBS::ALL_SUBSYSTEMS;
push @lines, "SubSystems ($nr_subsys) will be taken in alphabetical order...";
}
}




if (@GBS::TOOLS)
{
foreach my $tool (@GBS::TOOLS)
{



my %step = map { $_ => $STEP_DEFS{$_}->[1] } keys %STEP_DEFS;	# $default
$step{TOOL} = $tool;
$step{AUDIT} = 0;
$step{BUILD} = 0;
my $step_name = $tool;
my $count = 0;
while (exists $STEPS{STEP}->{$step_name})
{
$count++;
$step_name = $tool . "_$count";
}
$STEPS{STEP}->{$step_name} = \%step;
push @{$STEPS{STEP}->{'.'}->{ORDER}}, $step_name;
push @STEP_NAMES_ORDER, $step_name;
}
if (@GBS::TOOLS > 1)
{
my $nr_tools = @GBS::TOOLS;
push @lines, "Tools ($nr_tools) will be taken in alphabetical order...";
}
}

ENV_say( 1, "No 'steps.gbs' defined", @lines)
if (@lines);
}



$STEPS_READ = 1;
}




sub step_entry($$)
{
my ($section,	# STEP
$args_ref,	# $stepname
) = @_;

my $stepname =  $args_ref->[0];





GBSFILEGLO_sig( EE => "Invalid stepname '$stepname'")
if ($stepname eq '-' || $stepname eq 'ALL');




if (exists $GBS::ALL_SUBSYSTEMS{$stepname})
{
$CUR_SUBSYS = $stepname;
} else
{
$CUR_SUBSYS = '';
}
push @STEP_NAMES_ORDER, $stepname;

return ( $stepname );
}




sub do_step_command($$$$$)
{
my ($section,	    # STEP
$subsection,	    # $step_name
$item,		    # COMMAND
$values_ref,	    # [$command_type, $command_items_ref, $ok_values, $exec_condition, $pos_arg_tokens];

$constr_arg,
) = @_;




my (undef, $command_items_ref, undef, undef) = @{$values_ref};
GBSFILEGLO_sig( EE => "Cannot specify COMMAND for SubSystem STEP '$subsection'", "(@{$command_items_ref})")
if ($CUR_SUBSYS ne '');

return @{$values_ref};
}




sub do_step_tool($$$$$)
{
my ($section,	    # STEP
$subsection,	    # $step_name
$item,		    # TOOL
$values_ref,	    # $tool_name
$constr_arg,
) = @_;
my $value = $values_ref->[0];
GBSFILEGLO_sig( EE => "Cannot specify TOOL for a SubSystem STEP '$subsection'", "($value)")
if ($CUR_SUBSYS ne '');
GBSFILEGLO_sig( EE => "No such Tool: $value")
if (!exists $GBS::ALL_TOOLS{$value});

return $value;
}




sub step_exit($$)
{
my ($section,	# STEP
$args_ref,	# $stepname
) = @_;

my ($stepname) = @{$args_ref};




if ($CUR_SUBSYS eq '' &&
!defined $STEPS{STEP}->{$stepname}->{COMMAND} &&
!defined $STEPS{STEP}->{$stepname}->{TOOL})
{
GBSFILEGLO_sig( EE => "COMMAND or TOOL required after non-SubSystem STEP (STEP=$stepname)");
}

}




sub alias_entry($$)
{
my ($section,	# ALIAS
$args_ref,	# $aliasname
) = @_;

my $aliasname = $args_ref->[0];




GBSFILEGLO_sig( EE => "Invalid aliasname '$aliasname'")
if ($aliasname eq '-' || $aliasname eq 'ALL');

push @ALIAS_NAMES_ORDER, $aliasname;

return ($aliasname);
}




sub do_alias_steps($$$$$)
{
my ($section,   # ALIAS
$subsection,# $alias_name
$item,	    # STEPS
$values_ref,
$constr_arg,
) = @_;



my @steps = @{$values_ref};
my @step_names_order = @STEP_NAMES_ORDER;
foreach my $step (@steps)
{
next if ($step eq '-');
GBSFILEGLO_sig( EE => "No such step '$step'")
if (!exists $STEPS{STEP}->{$step});

while (@step_names_order && $step ne $step_names_order[0])
{
shift @step_names_order;
}
GBSFILEGLO_sig( EE => "Wrong step-sequence for step '$step' (@STEP_NAMES_ORDER)")
if (!@step_names_order);
}

return @steps;
}




sub do_alias_build($$$$$)
{
my ($section,   # ALIAS
$subsection,# $alias_name
$item,	    # BUILD
$value_ref,
$constr_arg,
) = @_;



my $value = $value_ref->[0];
GBSFILEGLO_sig( EE => "No such Build: $value")
if (!exists $GBS::ALL_BUILDS{$value});

return $value;
}








sub STEPS_get_subsystems_order($)
{
my ($root_path,
) = @_;
my @subsys_order;




my @all_subsystems = GBSGLO_subsystems( $root_path);
my $full_filespec = FSPEC_steps( 'steps', $root_path);
if (-e $full_filespec)
{
my %all_subsystems = map { $_ => 1 } @all_subsystems;
my @lines = grep( $_ !~ /^\s/,
SLURP_file_full( $full_filespec, qr/^#/, undef)); # separate line to satisfy perlxref
foreach my $line (@lines)
{

my ($step_name) = $line =~ /^STEP\s+(.*)/;
if (defined $step_name && exists $all_subsystems{$step_name})
{
push @subsys_order, $step_name;
delete $all_subsystems{$step_name};
}
}
my @remaining_subsys = keys %all_subsystems;
if (@remaining_subsys)
{
push @subsys_order, @remaining_subsys;
ENV_sig( W => "SubSystem(s) '@remaining_subsys' do not appear in 'steps.gbs'",
"Temporarily added at end",
"Please use 'gbsedit steps.gbs' to add the missing SubSystem(s)");
}
} else
{
@subsys_order = @all_subsystems;
}


return @subsys_order;
}

1;


