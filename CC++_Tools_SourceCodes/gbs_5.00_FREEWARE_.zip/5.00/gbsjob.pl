#=================================================
#
#   gbsjob.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSJOB @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::args;
use glo::time;
use glo::slurp;
use glo::banner;
use glo::version;
use mod::gbsenv;
use mod::gbsres;
use mod::bgnotifier;
use mod::notify;
use mod::gbssyssum;
use mod::gbscmd;




sub do_job();
sub finish($);
sub trap_sig($);
sub write_summary($$);
sub cpu_usage();
sub read_job_file();
sub get_command_args();








my @SANITY_REFS = (


[ 'Use of uninitialized value',		    '.' ],
[ 'Useless use of a variable in void context',  '.' ],
[ 'ARRAY\(0x[0-9a-f]+\)',			    'ARRAY(0xXXXXXXX)' ],
[ 'Subroutine \w+ redefined',   'Subroutine <subroutine> redefined' ],
);







my $JOB_FILE;




my (
$SUBMODE,			    # Fixed: 'SUBWIN' or 'SUBMIT'
$GBSSYS_COMMAND,		    # Fixed: gbssysbuild, gbssysmake, gbssysaudit, gbssystool
$BUILD_OR_TOOL,		    # Vary
$AUDIT,			    # Vary: may be '-'
$DATE_TIME,			    # Fixed
$OS_LOGFILE_SPEC,		    # Vary: '-' or logfile
$MUST_DISPLAY_NOTIFY_MSG,	    # Fixed
$OS_ROOT_PATH,		    # Fixed
$DISPLAY,			    # Fixed
$COMMAND_ARGS,		    # Fixed E.g.: --builds=test,mingw*
$COMMENT,			    # Fixed
@EXEC_ARGS,			    # Vary. E.g.: gbssysbuildbg begin bart superglo non_gbs copy_export --files=*:*.*
);
my $COMMAND_HEADING;
my $LOGFILE_SPEC;
my $ROOT_PATH;




my $TIME_START;
my $TIME_END = $$;		# PID during START
my $TIME_DIFF = '';		# Empty during START

my @TIMER_START;    # ($clock, $user, $system, $cuser, $csystem) in seconds
my @TIMER_END;	    # ($clock, $user, $system, $cuser, $csystem) in seconds
my @TIMER_DIFF;     # ($clock, $user, $system, $all)

my $UNAME;
{
my ($os, $host, @rest) = ENV_uname();
$UNAME = "$host ($os [@rest])";
}

my $TITLE = GBSRES_title();
my ($LICS, $LICN, $LICE) = VERSION_get_lic();






$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);


get_command_args();

read_job_file();
$COMMAND_HEADING = "$GBSSYS_COMMAND ($BUILD_OR_TOOL / $AUDIT)";
if ($OS_LOGFILE_SPEC eq '-')
{
$ENV{GBS_EXEC_MODE} = 'FOREGROUND';
} else
{
$ENV{GBS_EXEC_MODE} = 'BACKGROUND';
ENV_set_background_term_size();
}




$RC = do_job();




ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);

}




sub do_job()
{
my $rc = 0;

@TIMER_START = ( time, times );
$TIME_START = TIME_time2num( $TIMER_START[0]);
my $gbs_show_version = VERSION_get_show_version();

BANNER_print( 'JOB', [
[ '',         $TITLE ],
undef,
[ 'VERSION:', "$gbs_show_version" ],
[ 'LICENSE:', "$LICN ($LICS/$LICE)" ],
[ 'START:',   $TIME_START ],
[ 'JOB:',     $COMMAND_HEADING ],
[ 'PID:',     $$ ],
[ 'HOST:',    $UNAME ],
[ 'ROOT:',    $OS_ROOT_PATH ],
[ 'EXEC:',    "@EXEC_ARGS" ],
[ 'LOGFILE:', $OS_LOGFILE_SPEC ],
[ 'DISPLAY:', $DISPLAY ],
[ 'ARGS:',    $COMMAND_ARGS ],
[ 'COMMENT:', $COMMENT ],
] );

if ($OS_LOGFILE_SPEC ne '-')
{
write_summary( 'START', 0);
BGNOTIFIER_start( $GBSSYS_COMMAND, $DATE_TIME, $BUILD_OR_TOOL, $AUDIT, $OS_LOGFILE_SPEC);
}
$ENV{GBS_LOGFILE} = $OS_LOGFILE_SPEC;
$ENV{DISPLAY} = $DISPLAY;
$ENV{GBS_PID} = $$;
$ENV{GBS_EXEC_ID} = '';
$ENV{GBS_JOB_ARGS} = $COMMAND_ARGS;




map { $SIG{$_} = \&trap_sig } qw( HUP INT KILL TERM);



my @exec_args = ENV_enquote( @EXEC_ARGS);




ENV_chdir( $ROOT_PATH);
my @command_args = ( '!!', '-' );		# Root == current, Subsys == None
if ($GBSSYS_COMMAND =~ /audit/)
{
push @command_args, ("--build=$BUILD_OR_TOOL", "--audit=$AUDIT", "--tool=-");
} elsif ($GBSSYS_COMMAND =~ /tool/)
{
push @command_args, ("--build=-", "--audit=-", "--tool=$BUILD_OR_TOOL");
} else  # build or make
{
push @command_args, ("--build=$BUILD_OR_TOOL", "--audit=-", "--tool=-");
}
push @command_args, "--exec=@exec_args";





my $command_items_ref = GBSCMD_get_gbs_command( gbsstart => \@command_args ) ;


$rc = ENV_system( $command_items_ref, undef);




finish( $rc);
unlink( $JOB_FILE);

return $rc;
}




sub finish($)
{
my ($rc) = @_;

ENV_say( 0,  "-");

my $state;
if ($rc == -1)
{
ENV_say( 0, "*******************",
"*** JOB KILLED  ***",
"*******************");
$state = 'KILLED';
} else
{
if ($OS_LOGFILE_SPEC ne '-' && ENV_is_development())
{



ENV_say( 1, 'Performing Sanity Check...');
my $log_lines = SLURP_file( $LOGFILE_SPEC);
foreach my $ref (@SANITY_REFS)
{
my ($re, $text) = @{$ref};
$re = $re . ' at .* line \d+\.';
my @error_lines = $log_lines =~ /$re/g;
if (@error_lines > 0)
{
my $nr_occur = @error_lines;
my $this_text = ($text eq '.') ? $re : $text;
foreach my $line (@error_lines)
{
$line = "    $line";
}
ENV_sig( E => '##', "##  Found $nr_occur occurrence(s) of '$this_text'", '##' , @error_lines);
$rc = 9;
}
}
}

if ($rc == 0)
{
$state = 'NORMAL';
} else # $rc > 0
{
$state = 'FAILED';
}
}

@TIMER_END = ( time, times );
$TIME_END = TIME_time2num( $TIMER_END[0]);
my $cpu_usage = cpu_usage();		# sets $TIME_DIFF and @TIMER_DIFF
my $display = ENV_getenv( 'DISPLAY');

if ($OS_LOGFILE_SPEC ne '-')
{
BGNOTIFIER_end( $state, $rc);
write_summary( $state, $rc);
}

if ($MUST_DISPLAY_NOTIFY_MSG)
{
NOTIFY_submit( $COMMAND_HEADING, $rc, $OS_LOGFILE_SPEC, $state);
}

ENV_say( 0,  "=");
BANNER_print( 'JOB', [
[ '',         $TITLE ],
undef,
[ 'LICENSE:', "$LICN ($LICS/$LICE)" ],
[ 'START:',   $TIME_START ],
[ 'END:',     $TIME_END ],
[ 'ELAPSED:', $TIME_DIFF ],
[ 'JOB:',     $COMMAND_HEADING ],
[ 'ROOT:',    $OS_ROOT_PATH ],
[ 'EXEC:',    "@EXEC_ARGS" ],
[ 'LOGFILE:', $OS_LOGFILE_SPEC ],
[ 'USAGE:',   $cpu_usage ],
[ 'STATUS:',  "$state ($rc)" ],
[ 'DISPLAY:', $display ],
[ 'ARGS:',    $COMMAND_ARGS ],
[ 'COMMENT:', $COMMENT ],
] );

if ($SUBMODE eq 'SUBWIN')
{


}
}




sub trap_sig($)
{
my ($sig) = @_;

ENV_say( 1, "Signal: $sig");

finish( -1);
ENV_exit( 8);
}




sub write_summary($$)
{
my ($state,	# START NORMAL FAILED KILLED
$rc,
) = @_;




my @summary_items = (
$GBSSYS_COMMAND,
$BUILD_OR_TOOL,
$UNAME,
$OS_ROOT_PATH,
$OS_LOGFILE_SPEC,
$TIME_START,
$TIME_END,		    # PID with START
$TIME_DIFF,		    # empty with START
"@TIMER_DIFF",		    # empty with START
$state,			    # START NORMAL FAILED KILLED
$rc,
$AUDIT,
$DATE_TIME,
$COMMAND_ARGS,
$COMMENT,
);


if ($state eq 'START')
{
GBSSYSSUM_start( \@summary_items);
} else
{
GBSSYSSUM_finish( \@summary_items);
}
}




sub cpu_usage()
{
my $text;
no integer;

my @diff;
for ( my $i = 0; $i < 5; $i++)
{
$diff[$i] = $TIMER_END[$i] - $TIMER_START[$i];
}


my ($c, $pu, $ps, $cu, $cs) = @diff;
my $cpu_s = $ps + $cs;
my $cpu_u = $pu + $cu;
my $cpu_a = $cpu_s + $cpu_u;

$TIME_DIFF = TIME_deltatime2num( $c);
$text = sprintf "Clock: %s, System: %.2f, User: %.2f, Total: %.2f",
"$c ($TIME_DIFF)", $cpu_s, $cpu_u, $cpu_a;
@TIMER_DIFF = ($c, $cpu_s, $cpu_u, $cpu_a);

use integer;
return $text;
}




sub read_job_file()
{
(
$SUBMODE,
$GBSSYS_COMMAND,
$BUILD_OR_TOOL,
$AUDIT,
$DATE_TIME,
$OS_LOGFILE_SPEC,
$MUST_DISPLAY_NOTIFY_MSG,
$OS_ROOT_PATH,
$DISPLAY,
$COMMAND_ARGS,
$COMMENT,
@EXEC_ARGS,
) = SLURP_file( $JOB_FILE);

ENV_sig( F => "Invalid job-file '$JOB_FILE'")
if (@EXEC_ARGS == 0);
ENV_sig( F => "Invalid mode '$SUBMODE'")
if ($SUBMODE ne 'SUBMIT' && $SUBMODE ne 'SUBWIN');

$LOGFILE_SPEC = ENV_perl_paths( $OS_LOGFILE_SPEC);
$ROOT_PATH = ENV_perl_paths( $OS_ROOT_PATH);
}




sub get_command_args()
{
($JOB_FILE,
) = ARGS_get( 1, 'perl gbsjob.pl <job-file>', undef, 1);	# $must_decode
}


