#=================================================
#
#   swt.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::swt;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SWT_validate_dirs
SWT_set
);
}




use glo::env;
use mod::gbsenvs;
use mod::gbsenv;
use mod::gbsrc;
use mod::plugin;




sub SWT_validate_dirs($$$$);
sub SWT_set($$);








sub SWT_validate_dirs($$$$)
{
my ($root_path,
$subsys,
$component,
$tool,
) = @_;
my $new_tool = $tool;


if ($subsys ne '')
{



my $gen_dir = "$root_path/dev/$subsys/tool";
if (!-d "$gen_dir/$tool")
{
ENV_sig( W => "SubSystem '$subsys' does not execute for Tool '$tool'");
$new_tool = '';
}
}

return $new_tool;
}




sub SWT_set($$)
{
my ($tool,
$must_write,
) = @_;
my $old_tool = $GBS::TOOL;






if ($tool eq '')
{
GBSENVS_set_tool( 1);
} else
{
GBSENVS_set_tool( 1, '',
[ TOOL	    => $tool,
TOOL_PLUGIN   => PLUGIN_get_abt_plugin_name( $tool),
]);
}




GBSRC_write_root( tool => $tool)
if ($must_write && GBSENV_mode_is_interactive());

return $old_tool;
}

1;


