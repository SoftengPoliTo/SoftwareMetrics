#=================================================
#
#   gbsbgglo.pm
#
#=================================================
#   This src_files is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::gbsbgglo;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
GBSBGGLO_init
GBSBGGLO_main
GBSBGGLO_set
GBSBGGLO_exec
GBSBGGLO_handle_rc
);
}




use glo::env;
use glo::time;
use glo::slurp;
use glo::struct;
use mod::gbsenvs;
use mod::gbsfilecom;
use mod::fail;




sub GBSBGGLO_init($$);
sub GBSBGGLO_main($$);
sub GBSBGGLO_set($$);
sub GBSBGGLO_exec($$$$);
sub GBSBGGLO_handle_rc($$$$);

sub do_banner(@);
sub do_echo(@);
sub do_glkb($$$$@);
sub do_sca($$$@);
sub do_scasum($$);
sub banner($$@);
sub print_fail_msg($);




my $GBS_IGNORE_ERRORS = $ENV{GBS_IGNORE_ERRORS};




my $BATCH_NAME = '';	# To be used in logging. E.g.: gbsbuild, gbsgen_post, gbsaudit, gbsaudit_post




my $FAIL_COUNT = 0;

my $CWD;	    # filled from $GBSBGJOB_SCRIPT_SPEC src_files




my %FUNCTIONS = (

BANNER  => \&do_banner,	# $first_line, @lines
ECHO    => \&do_echo,	# @lines
SET     => \&GBSBGGLO_set, 	# $name, $value
EXEC    => \&GBSBGGLO_exec,	# $src_files, $must_print_commands, $out_files_ref, $command_data_refs_ref
GLKB    => \&do_glkb,	# $src_files, $must_print_commands, $glkb_args, $out_files_ref, $command_data_refs_ref
SCA	    => \&do_sca,	# $src_files, $unix_style_search, $out_files_ref, $command_data_refs_ref
SCASUM  => \&do_scasum,	# $src_files, $sum_filespec
);




sub GBSBGGLO_init($$)
{
my ($batch_name,
$component,	    # may be '-'
) = @_;




$BATCH_NAME = uc $batch_name;
{
my ($os, $host) = ENV_uname();
ENV_whisper( 1, "$BATCH_NAME: Running on $host ($os)");
}




if ($component eq '' || $component eq '-')
{
GBSENVS_set_component( 1);
$CWD = ENV_chdir( $GBS::SUBSYS_PATH);
} else
{
banner( '*', "SubSys: $GBS::SUBSYS - Component: $component");

if ($component ne $GBS::COMPONENT)
{
my $new_component_path = "$GBS::COMP_PATH/$component";
GBSENVS_set_component( 1, $new_component_path,
[ COMPONENT	    => $component,
COMPONENT_PATH    => $new_component_path,
]);
}
$CWD = ENV_chdir( $GBS::SRC_PATH);
}
}




sub GBSBGGLO_main($$)
{
my ($gbsbg_script_spec,
$func_ref,		# [ $key, $function ]
) = @_;
my $rc = 0;




{
my ($key, $function) = @{$func_ref};
ENV_sig( F => "Invalid function-key '$key'")
if (!exists $FUNCTIONS{$key});
$FUNCTIONS{$key} = $function;
}





my @lines = SLURP_file( $gbsbg_script_spec);

my $gbsbg_refs_ref = STRUCT_decode( \@lines);
my @gbsbg_refs = @{$gbsbg_refs_ref};


my $remaining_lines = @gbsbg_refs;
foreach my $ref (@gbsbg_refs)
{
my ($name, $item_or_items_ref) = @{$ref};
my $function = $FUNCTIONS{$name};





my $this_rc = $function->( @{$item_or_items_ref});
$rc = $this_rc if ($this_rc > $rc);
if ($this_rc != 0)
{
print_fail_msg( $remaining_lines);
last if (!$GBS_IGNORE_ERRORS);
}
$remaining_lines--;
}

ENV_unlink( $gbsbg_script_spec, 1, 'W');	# Force

return $rc;
}




END
{
my $rc = $?;

my $rc_txt;
if ($rc == 0)
{
$rc_txt = 'Completed';
} else
{
$rc_txt = "Unsuccessful ($rc)";
$rc_txt .= " (Count: $FAIL_COUNT)"
if ($FAIL_COUNT > 0);
}
ENV_say( 1, "$BATCH_NAME: $rc_txt");
}




sub do_banner(@)
{
my ($first_line,
@lines
) = @_;

banner( '*', $first_line, @lines);

return 0;
}




sub do_echo(@)
{
my (@lines) = @_;

ENV_say( 1, @lines);

return 0;
}




sub GBSBGGLO_set($$)
{
my ($name,
$value,
) = @_;
$value = '' if (!defined $value);


$value = ' '
if ($value eq '');
$ENV{$name} = $value;

return 0;
}




sub GBSBGGLO_exec($$$$)
{
my ($src_files_or_ref,
$must_print_commands,	# scripts should print their own command(s). '-' == undef
$out_files_ref,		# List
$command_data_refs_ref,	# [ [ $command_type, $command_items_ref, $ok_values, $exec_condition, $pos_arg_tokens ], ... ]

) = @_;
my $rc = 0;



my $src_files_ref = (ref $src_files_or_ref) ? $src_files_or_ref : [ $src_files_or_ref ];




$rc = GBSFILECOM_exec( $must_print_commands, $command_data_refs_ref );
if ($rc == 0)
{
ENV_whisper( 0, '-');
} else
{
GBSBGGLO_handle_rc( $rc, $src_files_ref, 'exec', $out_files_ref);
}

return $rc;
}




sub GBSBGGLO_handle_rc($$$$)
{
my ($rc,
$src_files_ref,
$sub_command,
$out_files_ref,
) = @_;


if ($rc > 0)
{
ENV_say( 1, "$BATCH_NAME: ### Failed ($rc) ***");
FAIL_log( $sub_command, $rc, $GBS::SUBSYS, $GBS::COMPONENT, "@{$src_files_ref}");
$FAIL_COUNT++;




foreach my $out_file (@{$out_files_ref})
{

if (-f $out_file)
{
ENV_whisper( 1, "  Deleting '$out_file'...");
unlink $out_file;
}
}
}
ENV_whisper( 0, '-');

return $rc
}




sub do_glkb($$$$@)
{
my ($src_file,
$must_print_commands,
$glkb_args,	    # "$gen_type $glkb_type $glkb_file $out_filespec"
$out_files_ref,	    # List
@command_line,
) = @_;


ENV_sig( F => 'GLKB_func not defined');


}





sub do_sca($$$@)
{
my ($src_files,
$unix_style_search,	# bool
$out_files_ref,		# List
$command_data_refs_ref,	# [ [ $command_type, $command_items_ref, $ok_values, $exec_condition, $pos_arg_tokens ], ... ]
) = @_;


ENV_sig( F => 'SCA_func not defined');


}





sub do_scasum($$)
{
my ($src_files,
$sum_filespec,
) = @_;


ENV_sig( F => 'SCASUM_func not defined');


}




sub banner($$@)
{
my ($pre_char,
$first_line,
@other_lines
) = @_;

my $pre = $pre_char x 3;
my $time_stamp = TIME_time2num();
my $time_stamp_indent = ' ' x length( $time_stamp);
ENV_say( 1, $pre);
ENV_say( 1, "$pre $time_stamp - $first_line");
map { ENV_say( 1, "$pre $time_stamp_indent - $_") } @other_lines;
ENV_say( 1, $pre);
}




sub print_fail_msg($)
{
my ($nr_remaining_lines) = @_;

my ($title, $sub_line);

$title = $BATCH_NAME;

if ($nr_remaining_lines > 0)
{
if ($GBS_IGNORE_ERRORS)
{
$sub_line = "Continuing with remaining commands";
} else
{
$sub_line = "Remaining commands will be skipped";
}
} else
{
$sub_line = "No Remaining commands";
}
banner( '#', "$title: ### FAILED ###",
$sub_line);
}

1;


