#!/bin/bash
#
#   run_mozilla
#	usage: run_mozilla <browser> [<file_spec>...]
#
#   author: Randy Marques
#
#set -x

if [[ $1 == '' ]]
then
    echo "RUN_MOZILLA_: Usage is run_mozilla <browser> [<file_spec>...]"
    exit 9
fi

browser=$1 ; shift
echo "RUN_MOZILLA_: $browser"
for file in $*
do
    echo "  $file"
done

#
#   Initialize
#
cwd=`pwd`
host_file=~/.${browser}_runhost1
if [[ $GBS_BROWSER_PATH == '' ]]
then
    command=$browser
else
    command=$GBS_BROWSER_PATH/$browser
    echo "RUN_MOZILLA_: $browser"
fi

#
#   Define function 'add_file'
#
function add_file {
    #set -x
    file=$1
    if [[ $file != /* ]]
    then
	file=$cwd/$file
    fi
    if [[ -f $file ]]
    then
	echo "RUN_MOZILLA_: Adding $file..."
	eval $command -remote "'openFile($file,new-tab)'"
	rc=$?
	if [[ $rc != 0 ]]
	then
	    echo "RUN_MOZILLA_: Retry $file..."
	    eval $command -remote "'openFile($file,new-tab)'"
	    rc=$?
	    if [[ $rc != 0 ]]
	    then
		sleep 3
		echo "RUN_MOZILLA_: Re-Retry $file..."
		eval $command -remote "'openFile($file,new-tab)'"
		rc=$?
	    fi
	fi
    else
	echo "RUN_MOZILLA_: No such file '$file'"
    fi
}

#
#   Execute mozilla for each file
#
if [ -s $host_file ]
then
    #
    #	Mozilla already running
    #	Add file-requests to the running mozilla
    #
    echo "RUN_MOZILLA_: Connecting..."
    if [[ $1 == '' ]]
    then
	#
	#   No files: Startup only one new empty window
	#
	$command -remote 'xfeDoCommand(openBrowser)'
	rc=$?
	if [[ $rc != 0 ]]
	then
	    echo 'RUN_MOZILLA_: Retry...'
	    $command -remote 'xfeDoCommand(openBrowser)'
	    rc=$?
	fi
	if [[ $rc != 0 ]]
	then
	    echo "RUN_MOZILLA_: Connect failed ($rc). Deleting '$host_file'"
	    rm $host_file
	fi
    else
	#
	#   Startup all windows
	#
	for file in $*
	do
	    add_file $file
	done
    fi
else
    #
    #	Mozilla is not yet running
    #	Start Mozilla and optionally add file requests if more than 1 file
    #
    echo "RUN_MOZILLA_: Starting $1..."

    #
    #	Startup Mozilla (with empty window or with first file)
    #
    if [[ $1 != '' ]]
    then
	first_file=$1
	shift
    fi
    (uname -n > $host_file ; $command $first_file ; rm $host_file) &
    rc=$?

    if [[ $1 != '' ]]
    then
	#
	#   Delay so that mozilla can get settled in
	#
	$command -remote 'ping()' 2> /dev/null

	#
	#   Startup the other windows
	#
	for file in $*
	do
	    add_file $file
	done
    fi
fi

echo "RUN_MOZILLA_: Done ($rc)"
exit

####EOF###
