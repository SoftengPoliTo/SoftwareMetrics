#=================================================
#
#   fixeol.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;









sub usage();
sub env_say($@);




my $RC = 0;
my $MAIN_NAME_UC;
my $PREFIX;
my $PREFIX_;
my $IS_WIN32;
my $XTERM_WIDTH;
my $XTERM_HEIGHT;

BEGIN
{
$| = 1;							# $OUTPUT_AUTOFLUSH
($MAIN_NAME_UC) = map { uc $_ } "/$0" =~ m!.*[/\\](.+)\.!;	# Extract filename and make it uppercase
$PREFIX = $MAIN_NAME_UC;
$PREFIX_ = ' ' x (length( $PREFIX) + 1);
$IS_WIN32 = ($^O eq 'MSWin32');
$XTERM_WIDTH = 100;
$XTERM_HEIGHT = 50;
if (-t STDOUT)
{
if ($IS_WIN32)
{
require Win32::Console;
import  Win32::Console;
($XTERM_WIDTH, $XTERM_HEIGHT) = Win32::Console->new()->Size();
} else
{
($XTERM_HEIGHT, $XTERM_WIDTH) = split( / /, qx(stty size));
}
}




CORE::say( '=' x ($XTERM_WIDTH - 5) . '');
}














=optdoc
use glo::genopt;












{
my @genopts = (
[ '<*>', 'files', 'sam', "", "Files to process" ],
);
GENOPT_set_flag_prefix( '-');
GENOPT_set_optdefs( 'fixeol', \@genopts,
'Fix EndOfLine characters of specified file(s) according to the invoking Operating System',
undef);
GENOPT_parse();
}
=cut

if (@ARGV == 1 && $ARGV[0] =~ /^--?(h|help)$/)
{
env_say( 1, "Fix EndOfLine characters of specified file(s) according to the invoking Operating System");
usage();
exit 0;
} else
{
if (scalar @ARGV == 0 || substr( $ARGV[0], 0, 1) eq '-')
{
usage();
exit 9;
}
}




my @all_files;
if ($^O eq 'MSWin32')
{
foreach my $file (@ARGV)
{
if ($file =~ /[*?]/)
{
my @files = glob $file;
if (scalar @files)
{
push @all_files, @files;
} else
{
push @all_files, $file;
}
} else
{
push @all_files, $file;
}
}
} else
{
@all_files = @ARGV;
}




foreach my $file (@all_files)
{
env_say( 1, $file);
if ( open( my $in_fh, '<', $file))
{
my @lines = <$in_fh>;
close $in_fh;
foreach my $line (@lines)
{
$line =~ s/\s+$//;	    #remove trailing white-space
$line .= "\n";
}
if (open( my $out_fh, '>', $file))
{
print( $out_fh @lines);
close $out_fh;
} else
{
die "$PREFIX: Unable to create file '$file'\n- $!\n";
}
} else
{
warn "$PREFIX: Unable to open file '$file'\n- $!\n";
$RC = 1;
}
}

exit 0;




END
{
env_say( 1, ($?) ? "Failed ($?)" : "Done");
}




sub usage()
{
env_say( 1, "usage is: fixeol <file-spec> [<file-spec>]...");
}




sub env_say($@)
{
my ($indent,    # 0 = no prefix, 1 = $prefix, 2 = $prefix_ - Negative = prefix_level - 1
@lines_and_or_refs
) = @_;

my @lines = map { (ref $_) ? @{$_} : $_ } @lines_and_or_refs;
if ($indent == 0)
{
map { CORE::say( $_) } @lines;
} else
{
if (abs( $indent) == 1)
{
my $first_line = shift @lines;
CORE::say( "$PREFIX: $first_line");
}
map { CORE::say( "$PREFIX_ $_") } @lines;
}
}


