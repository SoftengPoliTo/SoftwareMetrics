#=================================================
#
#   winat.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*WINAT @ARGV") if ($ENV{GBSDEBUG_FILE});





use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::args;
use glo::banner;
use glo::time;




sub mylog($);
sub numtime($);
sub get_command_args();




my ($JOBNAME,
$DELAY,	    # in minutes
$MAIL,	    # Boolean. Not used
$OS_LOG_FILESPEC,
$COMMAND,
@COMMAND_ARGS);

my $RC = 0;

$| = 1;           # $OUTPUT_AUTOFLUSH






{
get_command_args();

BANNER_print( 'JOB', [ "GBS Batch Job - $JOBNAME" ]);
mylog( "Job Name: $JOBNAME");

if ($DELAY > 0)
{
my $delay = numtime( $DELAY * 60);
mylog( "Waiting $DELAY minute(s) till $delay...");
sleep( $DELAY * 60);
}

mylog( 'Starting');



$OS_LOG_FILESPEC = ENV_enquote( $OS_LOG_FILESPEC);
@COMMAND_ARGS = ENV_enquote( @COMMAND_ARGS);
my $command_line = "$COMMAND @COMMAND_ARGS > $OS_LOG_FILESPEC 2>&1";
ENV_say( 0, $command_line);
mylog( "Redirecting output to logfile")
if ($command_line =~ />/);

mylog( "Busy...");
$RC = ENV_system( $command_line, undef);

mylog( "Done ($RC)");
if ($RC >= 0)
{
my $tail_command;
if (ENV_is_win32())
{
$tail_command = "powershell -command \"& {Get-Content $OS_LOG_FILESPEC | Select-Object -last 100}\"";
} else	# Linux
{
$tail_command = "tail -n 100 $OS_LOG_FILESPEC";
}
ENV_system( $tail_command, undef);
}


}




exit $RC;




END
{
ENV_print_end_msg( 1);
}




sub mylog($)
{
my ($line,
) = @_;

my $now = numtime( 0);
ENV_say( 1, "$now: $line");
}




sub numtime($)
{
my ($delta,	    #	minutes
) = @_;


my $time = time() + $delta;
return TIME_time2num( $time);
}




sub get_command_args()
{
($JOBNAME,
$DELAY,
$MAIL,
$OS_LOG_FILESPEC,
$COMMAND,
@COMMAND_ARGS) = ARGS_get( [5], 'winat <jobname> <delay> <mail> <os_log_filepsec> <command> [<args>...]', undef, 1);
}


