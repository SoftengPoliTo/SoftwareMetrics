#=================================================
#
#   tkxevent.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::tkxevent;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
TKXEVENT_bind_delete_window
TKXEVENT_bind_destroy
TKXEVENT_bind_visibility
TKXEVENT_bind_map
TKXEVENT_bind_key_return
TKXEVENT_bind_key_escape
TKXEVENT_bind_key
TKXEVENT_bind_key_ctrl
TKXEVENT_bind_mouse_left_click_1
TKXEVENT_bind_mouse_left_click_2
TKXEVENT_bind_mouse_right_click_1
TKXEVENT_bind_listbox_select
TKXEVENT_bind_combobox_selected
TKXEVENT_bind_treeview_select
);
}




use Tkx;





sub TKXEVENT_bind_delete_window($$@);

sub TKXEVENT_bind_destroy($$@);

sub TKXEVENT_bind_visibility($$@);
sub TKXEVENT_bind_map($$@);
sub TKXEVENT_bind_key_return($$@);
sub TKXEVENT_bind_key_escape($$@);
sub TKXEVENT_bind_key($$$@);
sub TKXEVENT_bind_key_ctrl($$$@);
sub TKXEVENT_bind_mouse_left_click_1($$@);
sub TKXEVENT_bind_mouse_left_click_2($$@);
sub TKXEVENT_bind_mouse_right_click_1($$@);

sub TKXEVENT_bind_listbox_select($$@);
sub TKXEVENT_bind_combobox_selected($$@);
sub TKXEVENT_bind_treeview_select($$@);

sub call_function_2($$$$@);









sub TKXEVENT_bind_delete_window($$@)
{
my ($mw_widget,
$function,		    # function->( $widget, @function_args)
@function_args,		    # Optional
) = @_;

return $mw_widget->g_wm_protocol( 'WM_DELETE_WINDOW' => [ $function, $mw_widget, @function_args ] );
}





sub TKXEVENT_bind_destroy($$@)
{
my ($widget,
$function,		    # function->( $widget, @function_args)
@function_args,		    # Optional
) = @_;

return $widget->g_bind( '<Destroy>', [ $function, $widget, @function_args ]);
}





sub TKXEVENT_bind_visibility($$@)
{
my ($widget,
$function,		    # function->( $widget, @function_args)
@function_args,		    # Optional
) = @_;

return $widget->g_bind( '<Visibility>', [ $function, $widget, @function_args ]);
}





sub TKXEVENT_bind_map($$@)
{
my ($widget,
$function,		    # function->( $widget, @function_args)
@function_args,		    # Optional
) = @_;

return $widget->g_bind( '<Map>', [ $function, $widget, @function_args ]);
}





sub TKXEVENT_bind_key_return($$@)
{
my ($widget,
$function,		    # function->( $widget, '<Return>', @function_args)
@function_args,		    # Optional
) = @_;

my $sequence = '<Return>';

return $widget->g_bind( $sequence, [ $function, $widget, $sequence, @function_args ]);
}





sub TKXEVENT_bind_key_escape($$@)
{
my ($widget,
$function,		    # function->( $widget, '<Escape>', @function_args)
@function_args,		    # Optional
) = @_;

my $sequence = '<Escape>';

return $widget->g_bind( $sequence, [ $function, $widget, $sequence, @function_args ]);
}





sub TKXEVENT_bind_key($$$@)
{
my ($widget,
$key,
$function,		    # function->( $widget, $sequence, @function_args)
@function_args,		    # Optional
) = @_;

my $sequence = "<$key>";

return $widget->g_bind( $sequence, [ $function, $widget, $sequence, @function_args ]);
}





sub TKXEVENT_bind_key_ctrl($$$@)
{
my ($widget,
$key,
$function,		    # function->( $widget, $sequence, @function_args)
@function_args,		    # Optional
) = @_;

my $sequence = "<Control-$key>";

return $widget->g_bind( $sequence, [ $function, $widget, $sequence, @function_args ]);
}





sub TKXEVENT_bind_mouse_left_click_1($$@)
{
my ($widget,
$function,		    # function->( $widget, $x, $y, @function_args)
@function_args,		    # Optional
) = @_;

return $widget->g_bind( '<Button-1>',
[ \&call_function_2, Tkx::Ev( '%X', '%Y'), $function, $widget, @function_args ]);
}





sub TKXEVENT_bind_mouse_left_click_2($$@)
{
my ($widget,
$function,		    # function->( $widget, $x, $y, @function_args)
@function_args,		    # Optional
) = @_;

return $widget->g_bind( '<Double-Button-1>',
[ \&call_function_2, Tkx::Ev( '%X', '%Y'), $function, $widget, @function_args ]);
}





sub TKXEVENT_bind_mouse_right_click_1($$@)
{
my ($widget,
$function,		    # function->( $widget, $x, $y, @function_args)
@function_args,		    # Optional
) = @_;

return $widget->g_bind( '<Button-3>',
[ \&call_function_2, Tkx::Ev( '%X', '%Y'), $function, $widget, @function_args ]);
}





sub TKXEVENT_bind_listbox_select($$@)
{
my ($lb_widget,
$function,		    # function->( $lb_widget, @function_args)
@function_args,		    # Optional
) = @_;

return $lb_widget->g_bind( '<<ListboxSelect>>', [ $function, $lb_widget, @function_args ]);
}





sub TKXEVENT_bind_combobox_selected($$@)
{
my ($cb_widget,
$function,		    # function->( $cb_widget, @function_args)
@function_args,		    # Optional
) = @_;

return $cb_widget->g_bind( '<<ComboboxSelected>>', [ $function, $cb_widget, @function_args ]);
}





sub TKXEVENT_bind_treeview_select($$@)
{
my ($cb_widget,
$function,		    # function->( $cb_widget, @function_args)
@function_args,		    # Optional
) = @_;

return $cb_widget->g_bind( '<<TreeviewSelect>>', [ $function, $cb_widget, @function_args ]);
}




sub call_function_2($$$$@)
{
my ($ev1,
$ev2,
$function,
$widget,
@function_args,
) = @_;


return $function->( $widget, $ev1, $ev2, @function_args);
}

1;

