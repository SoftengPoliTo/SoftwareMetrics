#=================================================
#
#   flincs.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::flincs;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
FLINCS_read_incs_file
FLINCS_read_flags_file
FLINCS_get_incs
FLINCS_get_incs_files
FLINCS_get_incs_tree
FLINCS_get_sysincs
FLINCS_get_stubs_incs
FLINCS_get_flags
FLINCS_get_flags_files
FLINCS_get_flags_tree
FLINCS_get_sysflags
);
}




use glo::env;
use mod::build;
use mod::gbsfileglo;
use mod::gbsfile;
use mod::gbsfilecom;
use mod::scope;




sub FLINCS_read_incs_file($;$);
sub FLINCS_read_flags_file($;$);
sub FLINCS_get_incs($$);
sub FLINCS_get_incs_files($$);
sub FLINCS_get_incs_tree($$);
sub FLINCS_get_sysincs($);
sub FLINCS_get_stubs_incs();
sub FLINCS_get_flags($$);
sub FLINCS_get_flags_tree($$);
sub FLINCS_get_flags_files($$);
sub FLINCS_get_sysflags($);

sub ext_files($$);
sub get_scope_path($);




my %INCS_CACHE;


my %FLAGS_CACHE;





sub FLINCS_read_incs_file($;$)
{
my ($filespec,
$force_read,	    # Optional
) = @_;


if (!exists $INCS_CACHE{$filespec} || $force_read)
{
ENV_whisper( 1, "Reading Incs: $filespec");
my @lines;
if (GBSFILE_open( $filespec, 0, undef, undef))
{
my $line = GBSFILE_get_line();
while ($line)
{

$line = GBSFILECOM_validate_path( $line);
push @lines, $line;
$line = GBSFILE_get_line();
}
}
$INCS_CACHE{$filespec} = [ @lines ];
}

return @{$INCS_CACHE{$filespec}};
}




sub FLINCS_read_flags_file($;$)
{
my ($filespec,
$force_read,	    # Optional
) = @_;


if (!exists $INCS_CACHE{$filespec} || $force_read)
{
ENV_whisper( 1, "Reading Flags: $filespec");
GBSFILE_open( $filespec, 1, undef, undef);
my @lines;
my $line = GBSFILE_get_line();
while ($line)
{
$line = ENV_expand_envs( $line);
if (ENV_is_option( $line))
{



my $opt = substr( $line, 0, 2);
GBSFILE_sig( EE => "'$opt' flags not allowed in GBS FLAG Files")
if (substr( $opt , 1, 1) eq 'I' || substr( $opt , 1, 1) eq 'L')
}
push @lines, $line;
$line = GBSFILE_get_line();
}
$FLAGS_CACHE{$filespec} = [ @lines ];
}

return @{$FLAGS_CACHE{$filespec}}
}




sub FLINCS_get_incs($$)
{
my ($src_type,
$component,	    # '' = for non-gbs subsys
) = @_;
my @includes;

foreach my $ref (FLINCS_get_incs_tree( $src_type, $component))
{
my (undef, $type, $lines_ref) = @{$ref};
push @includes, @{$lines_ref}
if (index( 'LSE', $type) >= 0);
}


return @includes;
}







sub FLINCS_get_incs_tree($$)
{
my ($src_type,
$component,	    # '' = for non-gbs subsys
) = @_;
my @incsfile_refs;

my $src_type_name = substr( $src_type, 1);
my $file = "incs_$src_type_name";

my $is_glkb_type;
my $include_inc;
my $include_bld;
if ($src_type eq '.glkb')  # .include in glkb files
{
$is_glkb_type = 0;
$include_inc = 1;
$include_bld = 0;
} elsif (BUILD_is_src_type( $GBS::BUILD, $src_type))
{
(my $gen_type, $include_inc, $include_bld) =
BUILD_get_src_items( $GBS::BUILD, $src_type, qw( TYPE INCLUDE_INC INCLUDE_BLD));
$is_glkb_type = (substr( $gen_type, 0, 2) eq 'gl');
} else
{
ENV_sig( EE => "Unknown src_type '$src_type'");
}

if ($component && !$is_glkb_type)
{



my @includes = ($include_inc) ? ( "../loc", "../inc" ) : ();
push @includes, "../bld/$GBS::BUILD" if ($include_bld);
push @incsfile_refs, [ 'Local', 'L', [ @includes ] ];




my @subdirs;
push @subdirs, '/inc' if ($include_inc);
push @subdirs, "/bld/$GBS::BUILD" if ($include_bld);
my @lines = SCOPE_get_includes( $GBS::SUBSYS, $component, @subdirs);
push @incsfile_refs, [ 'scope.gbs', 'S', [ @lines ] ];
}




foreach my $filespec (reverse( ext_files( $component, $file)))
{
my @lines = FLINCS_read_incs_file( $filespec);
push @incsfile_refs, [ $filespec, 'E', [ @lines ] ];
}




my $filespec = BUILD_get_sysincs_file( $GBS::BUILD, $src_type);
if ($filespec)
{
my @lines = FLINCS_read_incs_file( $filespec);
push @incsfile_refs, [ $filespec, 'B', [ @lines ] ];
}




if (!$is_glkb_type)
{
my @includes;
my $filespec;
$filespec = "$GBS::ROOT_PATH/sysbuild/makemake_stubs/ALL";
push @includes, $filespec if (-s $filespec);

$filespec = "$GBS::ROOT_PATH/sysbuild/makemake_stubs/$GBS::BUILD";
push @includes, $filespec if (-s $filespec);

push @incsfile_refs, [ 'makemake_stubs', 'M', [ @includes ] ]
if (@includes);
}

return @incsfile_refs;
}




sub FLINCS_get_incs_files($$)
{
my ($src_type,
$component,	    # '' = for non-gbs subsys
) = @_;


my $src_type_name = substr( $src_type, 1);
my $file = "incs_$src_type_name";

return reverse( ext_files( $component, $file));
}




sub FLINCS_get_sysincs($)
{
my ($src_type) = @_;
my @includes;

my @files = BUILD_get_sysincs_file( $GBS::BUILD, $src_type);
@includes = map { FLINCS_read_incs_file( $_) } @files;


return @includes;
}




sub FLINCS_get_stubs_incs()
{
my @includes;

@includes = ( "$GBS::ROOT_PATH/sysbuild/makemake_stubs/ALL",
"$GBS::ROOT_PATH/sysbuild/makemake_stubs/$GBS::BUILD",
"$GBS::SCRIPTS_PATH/plugins/build/ALL/makemake_stubs",
);
push @includes, "$GBS::SCRIPTS_PATH/plugins/build/$GBS::BUILD_PLUGIN/makemake_stubs"
if ($GBS::BUILD_PLUGIN ne '');


return @includes;
}




sub FLINCS_get_flags($$)
{
my ($src_type,
$component,	    # '' = for non-gbs subsys
) = @_;
my @flags;

my @files = FLINCS_get_flags_files( $src_type, $component);
push @flags, map { FLINCS_read_flags_file( $_) } @files;


return @flags;
}







sub FLINCS_get_flags_tree($$)
{
my ($src_type,
$component,
) = @_;
my @flagsfile_refs;

my $src_type_name = substr( $src_type, 1);
my $file = "flags_$src_type_name";

foreach my $filespec (ext_files( $component, $file))
{
my @lines = FLINCS_read_flags_file( $filespec);
push @flagsfile_refs, [ $filespec, 'E', [ @lines ] ];
}
my $filespec = BUILD_get_sysflags_file( $GBS::BUILD, $src_type);
if ($filespec)
{
my @lines = FLINCS_read_flags_file( $filespec);
push @flagsfile_refs, [ $filespec, 'B', [ @lines ] ];
}

return @flagsfile_refs;
}




sub FLINCS_get_flags_files($$)
{
my ($src_type,
$component,	    # '' = for non-gbs subsys
) = @_;


my $src_type_name = substr( $src_type, 1);
my $file = "flags_$src_type_name";

return ext_files( $component, $file);
}




sub FLINCS_get_sysflags($)
{
my ($src_type) = @_;
my @flags;

my @files = BUILD_get_sysflags_file( $GBS::BUILD, $src_type);
push @flags, map { FLINCS_read_flags_file( $_) } @files;

return @flags;
}




sub ext_files($$)
{
my ($component,	# '' = for non-gbs subsys
$file,	    	# without .gbs
) = @_;
my @files;

foreach my $path (get_scope_path( $component))
{
my $filespec = GBSFILEGLO_select_usr_gbs( "$path/$file");
push @files, $filespec
if ( defined $filespec);
}


return @files;
}




sub get_scope_path($)
{
my ($component) = @_;  # '' = for non-gbs subsys
my @dirs;

my $subsys_path = "$GBS::ROOT_PATH/dev/$GBS::SUBSYS";

@dirs = ( "$GBS::ROOT_PATH/sysbuild",
"$GBS::ROOT_PATH/sysbuild/$GBS::BUILD",
"$subsys_path/build",
"$subsys_path/build/$GBS::BUILD",
);

if ($component ne '')
{
my $gbs_component_path = "$subsys_path/comp/$component";

push @dirs,
"$gbs_component_path/opt",
"$gbs_component_path/opt/$GBS::BUILD";
}

return @dirs;
}

1;

