#=================================================
#
#   gbsmake.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSMAKE @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::spit;
use glo::genopt;
use mod::gbsenv;
use mod::swb;
use mod::gbscmd;
use mod::exec;
use mod::validate;
use mod::gbsoptenv;
use mod::fspec;
use mod::cfo;
use mod::gbsbgjob;
use mod::makemake;
use mod::make;




sub easter_egg(@);










$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( 'build');













{
my @genopts = (
[ '<*>',    'comp_file_opts',   'sao',   '', "bld files to make with 'make' options. ALL = *:*.*" ],
[ 'r',	    'reverse_type',	'bso',    0, "Specify source-types instead of build-types" ],
[ 'i',      'ignore_errors',    'bso',    0, "Continue generation after error(s)" ],
[ 'build',  'build_name',	"ssos.,$GBS::BUILDS", '.', "Build to run" ],
[ 'smm',    'start_makemake',   'bso',    0, "Pre-generate the make-file" ],
[ 'export', 'run_gbsexport',    'bso',    0, "Run 'gbsexport' on completion" ],
[ 'mm',     'run_makemake',	'bso',    0, "Run 'makemake' on completion" ],
[ 'jobs',   'jobs',	   'isor1..9',    2, 'Max nr parallel jobs' ],
);
my @genenvs = qw( DEBUGGER MODE OPT MAP FLAGS_* APP_* );
GENOPT_set_optdefs( 'gbsmake', \@genopts,
"'make' one or more files",
undef);
GENOPT_set_envdefs( \&GBSOPTENV_set, \&GBSOPTENV_print, \@genenvs);
GENOPT_parse();
}
my @COMP_FILE_OPTS = GENOPT_get( 'comp_file_opts');
my $REVERSE_TYPE = GENOPT_get( 'reverse_type');
my $IGNORE_ERRORS = GENOPT_get( 'ignore_errors');
my $BUILD_NAME = GENOPT_get( 'build_name');
my $START_MAKEMAKE = GENOPT_get( 'start_makemake');
my $RUN_GBSEXPORT = GENOPT_get( 'run_gbsexport');
my $RUN_MAKEMAKE = GENOPT_get( 'run_makemake');
my $JOBS = GENOPT_get( 'jobs');

my $GEN_ALL = (@COMP_FILE_OPTS || @COMP_FILE_OPTS > 0 && $COMP_FILE_OPTS[0] eq '*:*.*') ? 1 : 0;

easter_egg( @COMP_FILE_OPTS);




ENV_setenv( GBS_IGNORE_ERRORS => $IGNORE_ERRORS);




VALIDATE_subsys_full_gbs();	# Also validates: GBS, Root and SubSys

$BUILD_NAME = VALIDATE_builds( $BUILD_NAME);
if (GBSENV_mode_is_interactive())
{



if ($BUILD_NAME ne $GBS::BUILD)
{
SWB_set( $BUILD_NAME, 1);
}
}

VALIDATE_build();

my $makefile = ENV_rel_paths( '.', FSPEC_gbsmake_file( $GBS::BUILD_PATH, $GBS::BUILD));




if ($START_MAKEMAKE || !-e $makefile)
{
ENV_whisper( 1, "Pre MakeMake...");
$RC = MAKEMAKE_main();
if ($RC != 0)
{
my $text = 'Pre MakeMake (--smm) failed!';
if ($IGNORE_ERRORS)
{
ENV_sig( E => $text);
} else
{
ENV_sig( EE => $text);
}
}
}

ENV_sig( EE => "No Makefile generated for this Build ($GBS::BUILD)")
if ( !-e $makefile);




my $NR_CFO = CFO_parse_make( \@COMP_FILE_OPTS, $REVERSE_TYPE);
my @GBSGEN_OPTIONS = CFO_get_pre_options();




my @filespecs;
if ($NR_CFO == 0)
{
ENV_print( 1, "No make-build(s) specified - ");
if ($GBS::COMPONENT eq '')
{
@filespecs = ('ALL');
ENV_say( 0, "'ALL' assumed");
} else
{
@filespecs = ($GBS::COMPONENT);
ENV_say( 0, "Current Component ($GBS::COMPONENT) assumed");
}
} else
{



my ($order_ref) = CFO_get_items();	    # For make only the first entry is used

foreach my $comp_ref (@{$order_ref})
{
my ($component, $files_ref, $opts_ref) = @{$comp_ref};
my @files = @{$files_ref};
if (@files)
{
my $rel_bld_build_path = "$GBS::SUBSYS_PATH/comp/$component/bld/$GBS::BUILD";
map { push @filespecs, "$rel_bld_build_path/$_" } @files;
} else
{
push @filespecs, $component;
}
}
}





{
my @stdout_lines;
if (1)
{



my $makefile = FSPEC_gbsmake_file( $GBS::BUILD_PATH, $GBS::BUILD);
ENV_whisper( 1, "Executing GBS 'make'...",
" $makefile",
"  IGNORE_ERRORS=$IGNORE_ERRORS",
map { "  $_" } @filespecs
);
my $nr_errors;
($nr_errors, @stdout_lines) = MAKE_main( $makefile, $IGNORE_ERRORS, \@filespecs);
} else
{



my $make = GBSCMD_get_os_command( 'make');

my @flags_make;
push @flags_make, ENV_getenv( 'GBS_FLAGS_MAKE');
push @flags_make, '-k' if ($IGNORE_ERRORS);
push @flags_make, '-n',	    # No execution mode. Print commands, do not execute
'-r',	    # do not use standard make-rules
'-f',	    # next arg is make-file
ENV_os_paths( $makefile);
my @b_files = ENV_os_paths( @filespecs);

my $command_items_ref = [ $make, @flags_make, @b_files ];




ENV_whisper( 1, "Executing 'make'...",
"  @flags_make",
"  @b_files");
my $rc = ENV_run3( $command_items_ref, undef, [ 0, 1, 2 ], \@stdout_lines, undef);
ENV_sig( EE => "'make' failed (rc=$rc)")
if ($rc != 0);
}




my @make_lines;
foreach my $line (@stdout_lines)
{
next if ($line eq '');

if ($line =~ /^gbsbuild (.+)/)
{
push @make_lines, $1;    # gbsbuild lines from 'make'
} else
{
ENV_say( 0, "$line");    # other lines from 'make'
}
}

if (@make_lines)
{
ENV_say( 1, "Executing 'gbsbuild'...");
my $gbsgen_file = SPIT_tmp_file_nl( 'gbsmake_gbsgen.tmp', \@make_lines);




my @gbsgen_opts;
push @gbsgen_opts, @GBSGEN_OPTIONS;
push @gbsgen_opts, "--inc=$gbsgen_file";
push @gbsgen_opts, '--i' if ($IGNORE_ERRORS);
push @gbsgen_opts, '--export' if ($RUN_GBSEXPORT);
push @gbsgen_opts, "--jobs=$JOBS";
$RC = EXEC_run( 'gbsbuild.pl', \@gbsgen_opts);
unlink $gbsgen_file;

if ($RUN_MAKEMAKE && ($RC == 0 || $IGNORE_ERRORS))
{
ENV_whisper( 1, "Post MakeMake...");
my $this_rc = MAKEMAKE_main();
$RC = $this_rc if ($this_rc > $RC);
if ($this_rc != 0)
{
ENV_sig( E => "Post MakeMake (--mm) failed!");
}
}
} else
{
ENV_say( 1, "Nothing to do");
if ($RUN_GBSEXPORT)
{
my @bgjob_refs;
my @all_comps = CFO_get_components();
my @texts = ("Explicit: gbsexport");
if ($GEN_ALL)
{
push @bgjob_refs, GBSBGJOB_banner( 'gbsexport ALL');
} else
{
push @bgjob_refs, GBSBGJOB_banner( "gbsexport for Component(s): @all_comps");
}


my @gbsexport_opts;
push @gbsexport_opts, grep( -e "$GBS::COMP_PATH/$_/export.gbs", @all_comps)
if (!$GEN_ALL);
push @gbsexport_opts, '--i'
if ($IGNORE_ERRORS);

my $command_items_ref = GBSCMD_get_gbs_command( gbsexport => \@gbsexport_opts);
$RC = ENV_system( $command_items_ref, undef);
}
}
}




ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
}




sub easter_egg(@)
{
if (scalar @_ == 2 && $_[0] eq 'my' && $_[1] eq 'day')
{
ENV_say( 0, "*******************************",
"** DO YOU FEEL LUCKY TODAY,  **",
"** PUNK?                     **",
"*******************************");
ENV_beep();
ENV_exit();
}
}


