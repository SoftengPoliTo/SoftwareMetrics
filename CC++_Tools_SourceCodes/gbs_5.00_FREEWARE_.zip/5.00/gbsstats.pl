#=================================================
#
#   gbsstats.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSSTATS @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::genopt;
use glo::number;
use glo::slurp;
use glo::html;
use glo::spit;
use glo::list;
use glo::time;
use mod::gbsenv;
use mod::gbsglo;
use mod::validate;
use mod::build;
use mod::audit;
use mod::gbssilo;
use mod::gbshtml;
use mod::run;




sub init_stats();
sub collect_data();
sub collect_gbs_subsys($);
sub collect_gbs_usr_recurse($$);
sub collect_subdir_recurse($$$);
sub collect_non_gbs_subsys($$);
sub count_files($);
sub count_lines($);
sub create_stats_file();
sub print_row($$);
sub is_text_file($$);
sub is_gbs_file($);




my @SUBDIRS = qw( src loc inc opt dat sav);

my @TEXT_FILE_TYPES = ( qw( .c .cpp .j .gbs .h .hpp .inl .mk .sh .bat .pl .xml .txt .text .usr .cmd .html ), '.c#');
my @BIN_FILE_TYPES = qw( .o .obj .exe .e .zip );
my @IGN_FILE_TYPES = qw( .lastbuildstate .log .tmp .sav);
my @SCM_FILE_TYPES = qw( .scc .keep .contrib .unloaded );
my %FILE_TYPES = map { $_ => 1 } @TEXT_FILE_TYPES;
map { $FILE_TYPES{$_} = 0 } @BIN_FILE_TYPES, @IGN_FILE_TYPES, @SCM_FILE_TYPES;



my %SCM_FILE_TYPES = map { $_ => 1 } @SCM_FILE_TYPES;

my $NOW_DATETIME = TIME_time2num();




my %GBS_FILE_NAMES = map { $_ => 1 } qw( audit export owners scope steps sys system build tool);
my @GBS_FILE_NAME_PREFIX_REFS = map { [ $_, length $_ ] } qw( sysflags_ sysincs_ flags_ incs_ sca_ );


my $IS_WIN32 = ENV_is_win32();

my $LEVEL = 0;
my $SECTION;




my @ROOT_GBS_TOTALS;





my @DEF_REFS = (

[ sys	=> 1, 0, undef,	    undef ],
[ sysaudit	=> 1, 0, 'AUDIT',   undef ],
[ sysbuild	=> 1, 0, 'BUILD',  'makemake_stubs' ],
[ systool	=> 1, 0, 'TOOL',    undef ],
[ res	=> 0, 1, undef,	    undef ],
[ ext	=> 0, 0, undef,	    undef ],
);
my @DATA_REFS = (




);




my ($NR_DEV_DIRS, $NR_DEV_FILES);
my $NR_ALL_SUBS;
my %NR_ALL_SUBS_TYPES;

my $NR_GBS_SUBS;




my @SUBSYS_GBS_TOTALS;


my %SUBSYS_ABT_GBS_TOTALS;






my $NR_GBS_COMPS = 0;
my %COMP_FILE_TOTALS;	    # .gbs & .usr


my %SUBDIR_FILE_TYPE_TOTALS;


my %GBS_SUBDIR_TOTALS = map { $_ => [ undef, 0, undef ] } @SUBDIRS;






my %NON_GBS_TOTALS;

my %NON_GBS_FILE_TYPE_TOTALS;





my %FILE_TYPE_TOTALS;





my $NR_GBS_LICENCE_FILES = 0;
my $NR_GBS_LICENCE_LINES;
my $NR_NON_GBS_LICENCE_FILES = 0;
my $NR_NON_GBS_LICENCE_LINES;






$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ 'lines',  'count_lines',  'bso',   0, "Count lines in src, inc and loc" ],
[ 'cs',     'create_stats', 'bso',   1, "Create the HTML Statistics" ],
[ 'vi',     'view_index',   'bso',   1, "View index in HTML browser" ],
);
GENOPT_set_optdefs( 'gbsstats', \@genopts,
'Show GBS System Statistics',
undef);
GENOPT_parse();
}
my $COUNT_LINES = GENOPT_get( 'count_lines');
my $CREATE_STATS = GENOPT_get( 'create_stats');
my $VIEW_INDEX = GENOPT_get( 'view_index');




VALIDATE_root();

my $GBS_STATS_PATH = "$GBS::SILO_PATH/statistics";
my $GBS_STATS_FILE = "$GBS_STATS_PATH/index.html";




{



GBSHTML_init( 'application');	    # Use Silo




if ($CREATE_STATS)
{
init_stats();
collect_data();
create_stats_file();

GBSSILO_create_index();
}




RUN_browser( $GBS_STATS_FILE)
if ($VIEW_INDEX);
}




ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
}




sub init_stats()
{
my @known_text_files;
push @known_text_files, map { BUILD_get_src_types( $_) } @GBS::ALL_BUILDS;
push @known_text_files, map { AUDIT_get_src_types( $_) } @GBS::ALL_AUDITS;

map { $FILE_TYPES{$_} = 1 } @known_text_files;


if ($COUNT_LINES)
{
$NR_GBS_LICENCE_LINES = 0;
$NR_NON_GBS_LICENCE_LINES = 0;
}
}




sub collect_data()
{
ENV_say( 1, "Collecting data...");




@ROOT_GBS_TOTALS = collect_gbs_usr_recurse( $GBS::ROOT_PATH, 0);





foreach my $ref (@DEF_REFS)
{
my ($dir, $contains_gbs, $subsys, $att_name, $remarks) = @{$ref};
my ($name, $count_ref, $att_ref, $nr_subsys, $gbs_files_ref);




my $path = "$GBS::ROOT_PATH/$dir";

$name = uc $dir;

$count_ref = [ count_files( $path), undef, $remarks ];

if (defined $att_name)
{
my ($nr_win32_att, $nr_linux_att) = ( 0, 0 );
my $att_s = $att_name . 'S';
my @all_att = ENV_getenv( "GBS_ALL_$att_s");
my $nr_all_att = @all_att;
my @this_att = ENV_getenv( "GBS_$att_s");
my $nr_this_att = @this_att;
my $nr_other_att = $nr_all_att - $nr_this_att;
$nr_win32_att = ($IS_WIN32) ? $nr_this_att : $nr_other_att;
$nr_linux_att = (!$IS_WIN32) ? $nr_this_att : $nr_other_att;
$att_ref = [ $att_name, $nr_win32_att, $nr_linux_att ];
}

if ($contains_gbs)
{
$gbs_files_ref = [ collect_gbs_usr_recurse( $path, 1) ];
}

if ($subsys)
{
$nr_subsys = GBSGLO_select_dirs( SLURP_dir_dirs( $path, 0));
}

push @DATA_REFS, [ $name, $count_ref, $att_ref, $nr_subsys, $gbs_files_ref ];
}





ENV_say( 1, "Total dev...");
($NR_DEV_DIRS, $NR_DEV_FILES) = count_files( "$GBS::ROOT_PATH/dev");





ENV_say( 1, "SubSystems...");

foreach my $ref (GBSGLO_subsystem_refs())
{
my ($subsys, $ss_type) = @{$ref};

ENV_whisper( 2, "SubSys $subsys - $ss_type...");
$NR_ALL_SUBS++;
$NR_ALL_SUBS_TYPES{$ss_type}++;
my $subsys_path = "$GBS::ROOT_PATH/dev/$subsys";




my $index = 0;
foreach my $ref (collect_gbs_usr_recurse( $subsys_path, 0)) 	# .gbs and .usr
{
my ($filetype, $nr_files, $nr_lines, @remarks) = @{$ref};
if (defined $nr_files)
{
$SUBSYS_GBS_TOTALS[$index]->[0] = $filetype;
$SUBSYS_GBS_TOTALS[$index]->[1] += $nr_files;
if ($COUNT_LINES)
{
$SUBSYS_GBS_TOTALS[$index]->[2] += $nr_lines;
}
push @{$SUBSYS_GBS_TOTALS[$index]->[3]}, @remarks;
$index++;
}
}

foreach my $dir (qw( AUDIT BUILD TOOLS))
{
my $lc_dir = lc $dir;
my @gbs_usr_count_refs = collect_gbs_usr_recurse( "$subsys_path/$lc_dir", 1);
foreach my $ref (@gbs_usr_count_refs)	# .gbs and .usr
{
my ($filetype, $nr_files, $nr_lines, @remarks) = @{$ref};
if (defined $nr_files)
{
$SUBSYS_ABT_GBS_TOTALS{$dir}->{$filetype}->[1] += $nr_files;
if ($COUNT_LINES)
{
$SUBSYS_ABT_GBS_TOTALS{$dir}->{$filetype}->[2] += $nr_lines;
}
push @{$SUBSYS_ABT_GBS_TOTALS{$dir}{$filetype}->[3]}, @remarks;
}
}
}

if ($ss_type eq 'GBS')
{



$NR_GBS_SUBS++;
collect_gbs_subsys( $subsys);
} else
{



collect_non_gbs_subsys( $subsys, $ss_type);
}
}
}




sub collect_gbs_subsys($)
{
my ($subsys) = @_;

my @comps = GBSGLO_components( $subsys);
$NR_GBS_COMPS += @comps;
foreach my $comp (@comps)
{
my $component_path = "$GBS::ROOT_PATH/dev/$subsys/comp/$comp";




my @gbs_usr_count_refs = collect_gbs_usr_recurse( $component_path, 0);
foreach my $ref (@gbs_usr_count_refs)	# .gbs and .usr
{
my ($filetype, $nr_files, $nr_lines, @remarks) = @{$ref};
if (defined $nr_files)
{
$COMP_FILE_TOTALS{$filetype}->[1] += $nr_files;
if ($COUNT_LINES)
{
$COMP_FILE_TOTALS{$filetype}->[2] += $nr_lines;
}
push @{$COMP_FILE_TOTALS{$filetype}->[3]}, @remarks;
}
}




foreach my $subdir (@SUBDIRS)
{
my $is_licence_subdir = ($subdir eq 'src' || $subdir eq 'loc' || $subdir eq 'inc') ? 1 : 0;
collect_subdir_recurse( $subdir, "$component_path/$subdir", $is_licence_subdir);
}
}
}




sub collect_gbs_usr_recurse($$)
{
my ($path,
$must_recurse,	    # bool
) = @_;
my @gbs_usr_count_refs = (
[ '.gbs', undef, undef ],    # $type, $nr_files, $nr_lines, @remarks
[ '.usr', undef, undef ],    # $type, $nr_files, $nr_lines, @remarks
);

foreach my $filespec_or_path (GBSGLO_glob( "$path/*"))	    # no SKIPTYPES
{

if (-d $filespec_or_path)
{


if ($must_recurse)
{
my $path = $filespec_or_path;
my @this_gbs_usr_count_refs = collect_gbs_usr_recurse( $path, 1);
for (my $i = 0; $i < 2; $i++)
{
my (undef, $this_nr_files, $this_nr_lines, @this_remarks) = @{$this_gbs_usr_count_refs[$i]};

$gbs_usr_count_refs[$i]->[1] += $this_nr_files
if (defined $this_nr_files);
$gbs_usr_count_refs[$i]->[2] += $this_nr_lines
if (defined $this_nr_lines);
push @{$gbs_usr_count_refs[$i]}, @this_remarks;
}
}
} else
{



my $filespec = $filespec_or_path;
my ($file_name, $filetype) = ENV_split_spec_nt( $filespec);
my $index = ($filetype eq '.gbs') ? 0 : ($filetype eq '.usr') ? 1 : -1;
if ($index >= 0)
{
if (is_gbs_file( $file_name))
{

$gbs_usr_count_refs[$index]->[1]++;
$FILE_TYPE_TOTALS{$filetype}->[1]++;
if ($COUNT_LINES)
{
my $nr_lines = count_lines( $filespec);
$gbs_usr_count_refs[$index]->[2] += $nr_lines;
$FILE_TYPE_TOTALS{$filetype}->[2] += $nr_lines;
}
push @{$gbs_usr_count_refs[$index]}, $file_name;
}
}
}
}

return @gbs_usr_count_refs;
}




sub collect_subdir_recurse($$$)
{
my ($subdir,
$subdir_path,
$is_licence_subdir,
) = @_;

foreach my $filespec_or_path (GBSGLO_glob( "$subdir_path/*"))	    # no SKIPTYPES
{

if (-d $filespec_or_path)
{



my $path = $filespec_or_path;
my $dir = ENV_parent_dir( $path, -1);

collect_subdir_recurse( "$subdir/$dir", $path, $is_licence_subdir);
} else
{



my $filespec = $filespec_or_path;
my $filetype = ENV_split_spec_t( $filespec);
if (!exists $SCM_FILE_TYPES{$filetype})
{

$SUBDIR_FILE_TYPE_TOTALS{$subdir}->{$filetype}->[1]++;
$GBS_SUBDIR_TOTALS{$subdir}->[1]++;
$FILE_TYPE_TOTALS{$filetype}->[1]++;
$NR_GBS_LICENCE_FILES++
if ($is_licence_subdir);
if ($COUNT_LINES && is_text_file( $filetype, $filespec))
{
my $nr_lines = count_lines( $filespec);
$SUBDIR_FILE_TYPE_TOTALS{$subdir}->{$filetype}->[2] += $nr_lines;
$GBS_SUBDIR_TOTALS{$subdir}->[2] += $nr_lines;
$FILE_TYPE_TOTALS{$filetype}->[2] += $nr_lines;
$NR_GBS_LICENCE_LINES += $nr_lines
if ($is_licence_subdir);
}
if (substr( $subdir, 0, 3) eq 'opt' && ($filetype eq '.gbs' || $filetype eq '.usr'))
{
my $file_name = ENV_split_spec_n( $filespec);
push @{$SUBDIR_FILE_TYPE_TOTALS{$subdir}->{$filetype}->[3]}, $file_name
if (is_gbs_file( $file_name));
}
} else
{

}
}
}
}




sub collect_non_gbs_subsys($$)
{
my ($subsys,
$ss_type,	# Not GBS. MSVS, make, Other
) = @_;

my $subsys_path = "$GBS::ROOT_PATH/dev/$subsys/app";
foreach my $ref (SLURP_dir_tree( $subsys_path, 0)) # [ $is_dir, $rel_file_or_dir ]
{
if ($ref->[0])	    # $is_dir
{
$NON_GBS_TOTALS{$ss_type}->[0]++;
} else		    # is file
{
$NON_GBS_TOTALS{$ss_type}->[1]++;
my $filespec = "$subsys_path/$ref->[1]";
my $filetype = ENV_split_spec_t( $filespec);
if (is_text_file( $filetype, $filespec))
{
$NON_GBS_FILE_TYPE_TOTALS{$ss_type}->{ $filetype}->[1]++;	# $nr_files
$FILE_TYPE_TOTALS{ $filetype}->[1]++;		# $nr_files
$NR_NON_GBS_LICENCE_FILES++;
if ($COUNT_LINES)
{
my $nr_lines = count_lines( $filespec);
$NON_GBS_FILE_TYPE_TOTALS{$ss_type}->{ $filetype}->[2] += $nr_lines;
$FILE_TYPE_TOTALS{ $filetype}->[2] += $nr_lines;
$NR_NON_GBS_LICENCE_LINES += $nr_lines;
}
}
}
}
}




sub create_stats_file()
{
ENV_say( 1, "Creating Silo Statistics...");

ENV_mkdir( $GBS_STATS_PATH);
my @lines;




my $title = "Silo - $GBS::SYSTEM_NAME [$GBS::ROOT_PARENT] - Statistics";

push @lines, GBSHTML_doc_start( $GBS_STATS_FILE, $title, 1, '', undef); # $want_scripts, $body_class, $target_frame_name
push @lines, GBSHTML_doc_top( [ $title, HTML_link( '../index.html', HTML_bold( 'Silo Home')) ],
([ "Date: $NOW_DATETIME", '', ''],
));




{



push @lines, HTML_br();




my @row_refs;




$LEVEL = 0;
$SECTION = 'TOP';

foreach my $ref (@ROOT_GBS_TOTALS)	# .gbs and .usr
{
my ($filetype, $nr_files, $nr_lines, @remarks) = @{$ref};
if (defined $nr_files)
{
push @row_refs, print_row( "Files $filetype", [ undef, $nr_files, $nr_lines, [ @remarks ] ]);
}
}
push @row_refs, [ $LEVEL, '--', '', '' ];




$LEVEL++;
foreach my $ref (@DATA_REFS)
{
my ($name, $count_ref, $att_ref, $nr_subsys, $gbs_files_ref) = @{$ref};




$SECTION = $name;
push @row_refs, print_row( 'All dirs and files', $count_ref);

if (defined $att_ref)
{
my ($att_name, $nr_win32_att, $nr_linux_att) = @{$att_ref};
my $nice_name = ucfirst( lc $att_name) . 's';
push @row_refs, print_row( "All $nice_name", [ $nr_win32_att + $nr_linux_att ]);
push @row_refs, print_row( "Win32 $nice_name", [ $nr_win32_att ])
if ($nr_win32_att > 0);
push @row_refs, print_row( "Linux $nice_name", [ $nr_linux_att ])
if ($nr_linux_att > 0);
}

if (defined $nr_subsys)
{
push @row_refs, print_row( 'SubSystems', [ $nr_subsys ]);
}

if (defined $gbs_files_ref)
{
foreach my $ref (@{$gbs_files_ref})	# .gbs and .usr
{
my ($filetype, $nr_files, $nr_lines, @remarks) = @{$ref};
if (defined $nr_files)
{
push @row_refs, print_row( "Files $filetype", [ undef, $nr_files, $nr_lines, [ @remarks ] ]);
}
}
}
push @row_refs, [ $LEVEL, '--', '', '' ];
}

$SECTION = 'DEV';
push @row_refs, print_row( 'All dirs and files', [ $NR_DEV_DIRS, $NR_DEV_FILES ]);
push @row_refs, print_row( 'SubSystems', [ $NR_ALL_SUBS ]);
foreach my $ss_type (sort keys %NR_ALL_SUBS_TYPES)
{
my $count = $NR_ALL_SUBS_TYPES{$ss_type};
push @row_refs, print_row( "$ss_type SubSystems", [ $count ]);
}
push @row_refs, [ $LEVEL, '--', '', '' ];

$LEVEL++;
$SECTION = 'SUBSYS';




my $rows_printed = 0;
foreach my $ref (@SUBSYS_GBS_TOTALS)	# .gbs and .usr
{
my ($filetype, $nr_files, $nr_lines, $remarks_ref) = @{$ref};
if (defined $nr_files)
{
push @row_refs, print_row( "Files $filetype", [ undef, $nr_files, $nr_lines, $remarks_ref ]);
$rows_printed = 1;
}
}


foreach my $dir (qw( AUDIT BUILD TOOLS))
{
$SECTION = "SUBSYS $dir";
foreach my $filetype (sort keys %{$SUBSYS_ABT_GBS_TOTALS{$dir}})
{
my $ref = $SUBSYS_ABT_GBS_TOTALS{$dir}->{$filetype};
push @row_refs, print_row( "Files $filetype", $ref);
$rows_printed = 1;
}
}
push @row_refs, [ $LEVEL, '--', '', '' ]
if ($rows_printed);




if ($NR_GBS_SUBS > 0)
{
$SECTION = 'SUBSYS GBS';




push @row_refs, print_row( 'GBS Components', [ $NR_GBS_COMPS ]);
foreach my $filetype (sort keys %COMP_FILE_TOTALS)
{
my $ref = $COMP_FILE_TOTALS{$filetype};
push @row_refs, print_row( "Files $filetype", $ref);
}





my @subdirs;
my @subdir_keys = keys %GBS_SUBDIR_TOTALS;
foreach my $subdir (@SUBDIRS)
{
push @subdirs, sort( grep ( $_ =~ /^$subdir/, @subdir_keys));
}

push @row_refs, map { print_row( "Files $_", $GBS_SUBDIR_TOTALS{$_}) } @subdirs;




if (keys %FILE_TYPE_TOTALS)
{
push @row_refs, [ $LEVEL, '--', '', '' ];
foreach my $subdir (@subdirs)
{
foreach my $filetype ( sort( keys %{$SUBDIR_FILE_TYPE_TOTALS{$subdir}}))
{
my $count_ref = $SUBDIR_FILE_TYPE_TOTALS{$subdir}->{$filetype};
push @row_refs, print_row( "Files $subdir $filetype", $count_ref);
}
}
}
push @row_refs, [ $LEVEL, '--', '', '' ];
}





foreach my $ss_type (sort keys %NON_GBS_TOTALS)
{
$SECTION = "SUBSYS $ss_type";
push @row_refs, print_row( 'dirs / files', $NON_GBS_TOTALS{$ss_type});
push @row_refs, map { print_row( "Files $_", $NON_GBS_FILE_TYPE_TOTALS{$ss_type}->{$_}) } sort( keys %{$NON_GBS_FILE_TYPE_TOTALS{$ss_type}});
push @row_refs, [ $LEVEL, '--', '', '' ];
}




$LEVEL++;
$SECTION = 'Totals';
push @row_refs, map { print_row( "Files $_", $FILE_TYPE_TOTALS{$_}) } sort( keys %FILE_TYPE_TOTALS);
push @row_refs, [ $LEVEL, '--', '', '' ];




$LEVEL++;
$SECTION = 'License';
{
push @row_refs, print_row( 'GBS Totals', [ '', $NR_GBS_LICENCE_FILES, $NR_GBS_LICENCE_LINES, 'src+inc+loc' ]);
push @row_refs, print_row( 'Non GBS Totals', [ '', $NR_NON_GBS_LICENCE_FILES, $NR_NON_GBS_LICENCE_LINES, undef]);
my $nr_licence_files = $NR_GBS_LICENCE_FILES + $NR_NON_GBS_LICENCE_FILES;
my $nr_licence_lines = ($COUNT_LINES) ? $NR_GBS_LICENCE_LINES + $NR_NON_GBS_LICENCE_LINES : undef;
push @row_refs, print_row( 'Totals', [ '', $nr_licence_files, $nr_licence_lines, 'src+inc+loc + NonGBS' ]);
}




push @lines, HTML_table( [ qw( -R - - -R -R -R - ) ],
[ qw( Lvl Section Item Nr-Dirs Nr-Files Nr-Lines Remarks) ],
\@row_refs, border => 1, class => 'sortable border1');
}




push @lines, GBSHTML_doc_bottom();
push @lines, GBSHTML_doc_end();

SPIT_file_nl( $GBS_STATS_FILE, \@lines);
ENV_say( 1, "Created Silo Statistics");

}




sub count_files($)
{
my ($dir) = @_;
my ($nr_dirs, $nr_files) = (0,0);

foreach my $ref (SLURP_dir_tree( $dir, 0)) # [ $is_dir, $file_or_dir ]
{
if ($ref->[0])
{
$nr_dirs++;
} else
{
$nr_files++;
}
}

return ($nr_dirs, $nr_files);
}




sub count_lines($)
{
my ($file) = @_;
my $nr_lines;

my $lines = SLURP_file( $file);
$nr_lines = () = $lines =~ /\n/g;	    # count the newlines

return $nr_lines;
}




sub print_row($$)
{
my ($item,
$count_ref,	# [ $nr_dirs, $nr_files, $nr_lines, $remarks/$remarks_ref ]
) = @_;
my $row_ref;

my @counts = @{$count_ref};
if (ref $counts[3])
{
my @remarks = LIST_unique( $counts[3]);
$counts[3] = "@remarks";
} elsif (!defined $counts[3])
{
$counts[3] = '';
}
for (my $i = 0; $i < 3; $i++)
{
if (defined $counts[$i])
{
$counts[$i] = NUMBER_format_numeric( $counts[$i])
if ($counts[$i] ne '');
} else
{
$counts[$i] = '';
}
}
$row_ref = [ $LEVEL, $SECTION, $item, @counts]; # ($nr_dirs, $nr_files, $nr_lines, $remarks)

return $row_ref;
}




sub is_text_file($$)
{
my ($filetype,	# '' == OK
$filespec,
) = @_;
my $is_text_file;

$is_text_file = $FILE_TYPES{$filetype};
if (!defined $is_text_file)
{
if ($filetype eq '')
{
my $lc_file_name = lc ENV_split_spec_n( $filespec);
if ($lc_file_name eq 'makefile')
{
$is_text_file = 1;
} else
{
$is_text_file = (-T $filespec) ? 1 : 0;
}
} else
{
$is_text_file = (-T $filespec) ? 1 : 0;
$FILE_TYPES{$filetype} = $is_text_file;

}
}

return $is_text_file;
}




sub is_gbs_file($)
{
my ($file_name) = @_;
my $is_gbs_file = 0;

if (exists $GBS_FILE_NAMES{$file_name})
{
$is_gbs_file = 1;
} else
{
foreach my $ref (@GBS_FILE_NAME_PREFIX_REFS)
{
my ($prefix, $p_length) = @{$ref};	    if (substr( $file_name, 0, $p_length) eq $prefix)
{
$is_gbs_file = 1;
last;
}
}
}

return $is_gbs_file;
}


