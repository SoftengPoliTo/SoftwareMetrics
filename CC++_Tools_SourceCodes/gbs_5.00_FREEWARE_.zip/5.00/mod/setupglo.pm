#=================================================
#
#   setupglo.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::setupglo;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
SETUPGLO_check_first_invocation
SETUPGLO_ask_site
SETUPGLO_ask_log_root
);
}




use glo::env;
use glo::ask;
use glo::slurp;
use mod::gbsenv;
use mod::profile;




sub SETUPGLO_check_first_invocation();
sub SETUPGLO_ask_site($);
sub SETUPGLO_ask_log_root($);








sub SETUPGLO_check_first_invocation()
{
if ($GBS::SITE eq '' || $GBS::LOG_ROOT eq '')
{







ENV_say( 0, '');
ENV_say( 1, "*** Welcome to GBS ***",
'');
map { ENV_say( 0, "  $_"); } SLURP_file( "$GBS::SCRIPTS_PATH/licence.txt");
ENV_say( 0, '');
if (ASK_YN( 'I agree with the above', 'N') eq 'N')
{
ENV_say( 1, "Cannot proceed");
ENV_exit( 1);
}
ENV_say( 0, '');




ENV_say( 1, "Some essential data is needed. You need to supply that first:",
'');
PROFILE_open( undef);
if ($GBS::SITE eq '')
{
my $gbs_site = SETUPGLO_ask_site( '');
GBSENV_setenv( GBS_SITE => $gbs_site, 1);
PROFILE_set( GBS_SITE => $gbs_site);
}
if ($GBS::LOG_ROOT eq '')
{
my $gbs_log_root = SETUPGLO_ask_log_root( '');
GBSENV_setenv( GBS_LOG_ROOT => $gbs_log_root, 1);
PROFILE_set( GBS_LOG_ROOT => $gbs_log_root);
}
PROFILE_close( 1);	# $must write
}
}




sub SETUPGLO_ask_site($)
{
my ($default_site,
) = @_;
my $new_site;

$default_site = 'HOME'
if ($default_site eq '');

ENV_say( 1, "Enter your Site-ID (pref. 3 letter IATA Airport Code)");
$new_site = ASK_word( 'Site-Id', $default_site, [ 3, 20 ]);

return $new_site;
}





sub SETUPGLO_ask_log_root($)
{
my ($default_log_path,
) = @_;
my $new_log_path;

$default_log_path = ENV_perl_paths_noquotes( ENV_get_user_path( 0)) . '/GBSLog'	# %MYDOCUMENTS% or ~/
if ($default_log_path eq '');

my $again;
do
{
$again = 0;
$new_log_path = ASK_path( 'LogRoot', $default_log_path, -1, 0);
if (!-d $new_log_path)
{
ENV_say( 1, "Directory does not exist");
if (ASK_YN( 'Create?', 'Y') eq 'Y')
{
if (!mkdir( $new_log_path))
{
ENV_beep();
ENV_say( 2, "- Unable to create '$new_log_path'",
"- $!");
$again = 1;
}
} else
{
ENV_beep();
ENV_say( 2, "- Directory must exist");
$again = 1;
}
}
} while ($again);

return $new_log_path;
}

1;


