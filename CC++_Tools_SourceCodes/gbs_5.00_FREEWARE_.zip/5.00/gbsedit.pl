#=================================================
#
#   gbsedit.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSEDIT @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::list;
use glo::ask;
use glo::genopt;
use glo::scm;
use mod::gbsenv;
use mod::gbsglo;
use mod::gbsscm;
use mod::gbsask;
use mod::plugin;
use mod::plg;
use mod::validate;
use mod::dirstruct;
use mod::floc;
use mod::templates;
use mod::gbsedit;




sub do_dialogue();
sub do_filespec();
sub do_the_edit();
sub pre_create_abt();
sub pre_create_gbsall();
sub pre_create_flincs_file();
sub pre_create_any();




my $CWD = ENV_cwd();

my $FILE_IS_IN_CURRENT_GBS_PATH = 0;
my $SAVED_CWD;

my $GENERIC_FILE_NAME;		    # audit, sysflags, sysincs, export, flags, gbsall, gbssub, incs, owners, makefile, etc
my $GENERIC_FILE_NAME_VAR_PART;	    # without the leading '_'
my $FILE_TYPE_GBS = '';		    # .gbs .usr
my $IS_GBS_FILE;

my $SUBSYS = '';
my $COMPONENT = '';
my $SUBDIR = '';
my $AUDIT = '';
my $BUILD = '';
my $TOOL = '';

my $FILESPEC;   			    # FULL filespec
my $FILE_PATH;
my $FILE_NAME;
my $FILE_TYPE;
my $FILE;				    # name + type

my $GBSALL_IN_SCRIPTS_ROOT;	    # used for pre_create_gbsall: bool
my $ABT_NAME;			    # used for pre_create_abt: audit_name, build_name or tool_name
my $PLUGIN;			    # used for pre_create_abt
my $TEMPLATE_SPEC_OR_COMMENT_REF;   # used for pre_create_any





my %FILE_DEFS = (




audit   => [
0,
undef,
\&pre_create_abt,
sub { return $PLUGIN } ],
sysflags   => [
0,
undef,
undef,
undef ],
sysincs   => [
0,
undef,
undef,
undef ],
build  => [
0,
undef,
\&pre_create_abt,
sub { return $PLUGIN } ],
comment_chars   => [
2,
undef,
undef,
undef ],
flags   => [
0,
undef,
\&pre_create_flincs_file,
undef ],
incs    => [
0,
undef,
\&pre_create_flincs_file,
undef ],
export  => [
0,
[],
undef,
undef ],
gbsall  => [
0,
undef,
\&pre_create_gbsall,
sub { return $GBSALL_IN_SCRIPTS_ROOT } ],
gbssub  => [
0,
[ qw( make MSVS Other) ],   # Exclude 'GBS'
undef,
undef ],
makefile  => [
0,
[ qw( make Other) ],
undef,
undef ],
owners  => [
1,
undef,
undef,
undef ],
sca    => [
0,
undef,
undef,
undef ],
scope   => [
0,
[ qw( GBS )],
undef,
undef ],
ssprop  => [
2,
[],
undef,
undef ],
steps   => [
0,
undef,
undef,
undef ],
switch  => [
0,
undef,
undef,
undef ],
sys	  => [
0,
undef,
undef,
undef ],
system  => [
1,
undef,
undef,
undef ],
tool    => [
0,
undef,
\&pre_create_abt,
sub { return $PLUGIN } ],
unkgbs  => [
0,
undef,
undef,
undef ],
any  => [
0,
undef,
\&pre_create_any,
sub { return $TEMPLATE_SPEC_OR_COMMENT_REF } ],
);

my ($IS_SPECIAL_FILE, $ALLOWED_SSTYPES_REF, $PRE_CREATE_FUNC, $EXTRA_DATA_FUNC);






$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( undef);













{
my @genopts = (
[ '<1>',  'basic_filespec', 'ssm', "", 'file, ./file, rel_filespec, filespec or subdir:file'],
[ '<2>',  'editor_opt',	    'sso', "", 'Editor option. e.g. Line-nr to jump to'],
[ 'nco',  'no_checkout',    'bso', 0 , [ 'By default files will also be added if non-exist',
'.usr files will always be forced to no_checkout'] ],
);
GENOPT_set_optdefs( 'gbsedit', \@genopts,
[ 'Create/edit GBS-files and user-files. GBS-files end with .gbs or .usr',
'The switch.gbs, gbssub and gbsall batch files are also considered GBS-files',
'Source, Include and glkbt-files are considered user-files',
'Relevant templates will be used with file-creation',
'On GBS files, where possible, a syntax check is performed after the edit.'],
undef);
GENOPT_parse();
}
my $BASIC_FILESPEC = GENOPT_get( 'basic_filespec');
my $EDITOR_OPT = GENOPT_get( 'editor_opt');
my $NO_CHECKOUT = GENOPT_get( 'no_checkout');

my $MUST_CHECKOUT = !$NO_CHECKOUT;

{



ENV_say( 1, "No current GBS Root/System.")
if ($GBS::ROOT_PATH eq '');
my $cwd_is_in_current_gbs_path = ($GBS::ROOT_PATH ne '' && ENV_is_in_path( $CWD, $GBS::ROOT_PATH)) ? 1 : 0;




$BASIC_FILESPEC = ENV_perl_canon_paths( $BASIC_FILESPEC);	# also Perl-path

if ($BASIC_FILESPEC =~ /:/)
{
if ($GBS::COMPONENT ne '')
{
my @allowed_subdir_names = qw( src inc loc dat opt sav);
my ($subdir, $rest) = split( ':', $BASIC_FILESPEC, 2);
if (grep( $subdir eq $_, @allowed_subdir_names))
{
$FILESPEC = "$GBS::ROOT_PATH/dev/$GBS::SUBSYS/comp/$GBS::COMPONENT/$subdir/$rest";
} else
{
ENV_sig( EE => '<subdir>:<file> notation only possible with subdirs:',
"  (@allowed_subdir_names)");
}
} else
{
ENV_sig( EE => '<subdir>:<file> notation only possible with current Component');
}
} elsif (-f $BASIC_FILESPEC)
{
$FILESPEC = (ENV_is_abs_path( $BASIC_FILESPEC)) ? $BASIC_FILESPEC : "$CWD/$BASIC_FILESPEC";
} else
{
my $path = ENV_split_spec_p( $BASIC_FILESPEC);
if ($path eq '')
{
$FILESPEC = $BASIC_FILESPEC;
} else
{
$FILESPEC = (ENV_is_abs_path( $BASIC_FILESPEC)) ? $BASIC_FILESPEC : "$CWD/$BASIC_FILESPEC";
}
}
$FILESPEC = ENV_perl_canon_paths( $FILESPEC);
($FILE_PATH, my $org_file) = ENV_split_spec_pf( $FILESPEC);




($FILE, $GENERIC_FILE_NAME, $IS_GBS_FILE, $GENERIC_FILE_NAME_VAR_PART, $FILE_TYPE_GBS) =
FLOC_analyse_name( $org_file);
if ($FILE ne $org_file)
{
ENV_exit()
if (ASK_YNQ( "Did you mean '$FILE'?", 'Y', 1) eq 'N');
}
($FILE_NAME, $FILE_TYPE) = ENV_split_spec_nt( $FILE);


if ($GENERIC_FILE_NAME eq 'unkgbs')
{
my @all_gbs_files = FLOC_get_all_gbs_filenames();
my $nr_gbs_files = @all_gbs_files;
my $nr_per_line = $nr_gbs_files / 2;
ENV_sig( W => "Unknown GBS ($FILE_TYPE) file '$FILE'",
"Valid GBS files:",
"- @all_gbs_files[0..$nr_per_line]",
"- @all_gbs_files[$nr_per_line..$#all_gbs_files]");
ENV_exit()
if (ASK_YNQ( 'Edit anyway?', 'N', 1) eq 'N');
$GENERIC_FILE_NAME = 'any';
$IS_GBS_FILE = 0;
}
($FILE_NAME, $FILE_TYPE) = ENV_split_spec_nt( $FILE);
$FILESPEC = ($FILE_PATH eq '') ? $FILE : "$FILE_PATH/$FILE";





ENV_exit()
if ($FILE_TYPE eq '' && ASK_YNQ( "No file-type specified ($FILE). Continue?", 'N', 1) eq 'N');

ENV_sig( EE => "Path '$FILE_PATH' does not exist")
if ($FILE_PATH ne '' && !-d $FILE_PATH);





if (!$cwd_is_in_current_gbs_path && $GENERIC_FILE_NAME ne 'gbsall')
{
if ($GBS::ROOT_PATH ne '')
{
ENV_sig( W => 'The file you are trying to edit is a GBS file',
'Your CWD is not in the Current GBS Root');
if (ASK_YNQ( 'Assume Current Root?', 'Y', 1) eq 'Y')
{
$FILE_IS_IN_CURRENT_GBS_PATH = 1;
$SAVED_CWD = $CWD;
ENV_chdir( $GBS::ROOT_PATH);
$CWD = $GBS::ROOT_PATH;
} else
{
$FILE_IS_IN_CURRENT_GBS_PATH = 0;
ENV_say( 1, 'No special checks will be performed and no GBS templates will be used for file-creation');
if (!ENV_is_abs_path( $FILESPEC))
{
$FILE_PATH = $CWD;
$FILESPEC = "$CWD/$FILE";
}
}
} else
{
$FILE_IS_IN_CURRENT_GBS_PATH = 0;
ENV_sig( W => 'The file you are trying to edit is a GBS file',
'There is no Current GBS Root');
ENV_say( 1, 'No special checks will be performed and no GBS templates will be used for file-creation');
ENV_exit()
if (ASK_YNQ( 'Continue anyway?', 'N', 1) eq 'N');
if (!ENV_is_abs_path( $FILESPEC))
{
$FILE_PATH = $CWD;
$FILESPEC = "$CWD/$FILE";
}
}
} else
{
$FILE_IS_IN_CURRENT_GBS_PATH = 1;
}




($IS_SPECIAL_FILE, $ALLOWED_SSTYPES_REF, $PRE_CREATE_FUNC, $EXTRA_DATA_FUNC) = @{$FILE_DEFS{ $GENERIC_FILE_NAME}};




if ($IS_SPECIAL_FILE > 0)
{
if ($IS_SPECIAL_FILE == 2)
{
ENV_sig( EE => "Cannot create/edit .usr of $FILE_NAME")
if ( $FILE_TYPE eq '.usr');
}
ENV_sig( W => "***",
"** Special GBS file ($FILE) You are on dangerous ground!",
"***");
ENV_exit()
if (ASK_YNQ( 'Edit anyway?', 'N', 1) eq 'N');
}




if ($FILE_IS_IN_CURRENT_GBS_PATH)
{
if ($IS_GBS_FILE)
{
VALIDATE_administrator()
if ($FILE_TYPE_GBS eq '.gbs');
}
}




if ($IS_GBS_FILE && $FILE_PATH eq '')
{



do_dialogue();
} else
{



if ($FILE_PATH eq '')
{
$FILE_PATH = $CWD;
$FILESPEC = "$FILE_PATH/$FILE";
}
}
do_filespec();
}









{



do_the_edit();
}





ENV_chdir( $SAVED_CWD)
if (defined $SAVED_CWD);




{
if (ENV_get_changed_envs())
{



my @lines;
push @lines, GBSENV_changed_setenv_commands( 0);    # $must_log
GBSENV_write_result_script( \@lines, 0);	    # $must_print
}
}

ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
}







sub do_dialogue()
{


my %ask_item_refs = (

S   => [ SubSys	    => \$SUBSYS,    sub { GBSASK_subsys( $ALLOWED_SSTYPES_REF) }	],
C   => [ Component  => \$COMPONENT, sub { GBSASK_component( $SUBSYS) }			],
B   => [ Build	    => \$BUILD,	    sub { GBSASK_build( $SUBSYS, $COMPONENT) }		],
A   => [ Audit	    => \$AUDIT,	    sub { GBSASK_audit( $SUBSYS, $COMPONENT, $BUILD) }	],
T   => [ Tool	    => \$TOOL,	    sub { GBSASK_tool( $SUBSYS) }			],
);
my @ask_items_order = qw( S C B A T );




map { ${$_->[1]} = '' } values %ask_item_refs;  # $value_ref;




my @locations = FLOC_get_locations( $FILE);

my @abs_locations = map { '$GBS_ROOT_PATH' . (($_ eq '') ? '' : "/$_") } @locations;
if (@locations == 1)
{
ENV_say( 1, "Location: $abs_locations[0]");
} else
{
ENV_say( 1, 'Possible location(s):',
map { "  $_" } @abs_locations);
}

my @possible_items;	    #  S C B A T
foreach my $item (@ask_items_order)
{
push @possible_items, $item
if (grep( $_ =~ /<$item>/, @locations));
}





my @wanted_items;
foreach my $item (@possible_items)
{
if ($item ne 'C' || GBSGLO_subsystem_is_full_gbs( $SUBSYS))
{
my $key = "<$item>";




my ($nice_name, $value_ref, $ask_function) = @{$ask_item_refs{$item}};
my $value = $ask_function->();

if ($value ne '')
{
$$value_ref = $value;
push @wanted_items, $item;
} else
{
ENV_sig( W => "No $nice_name selected")
}
} else
{



$COMPONENT = '';
}
}





my @selected_paths;
foreach my $location (@locations)
{
my @found_items = $location =~ /<(.)>/g;

{
my $path = $location;
foreach my $item (@wanted_items)
{
my $value = ${$ask_item_refs{ $item}->[1]}; # $value_ref
$path =~ s/<$item>/$value/;
}
push @selected_paths, $path
if ($path !~ /</);
}
}


my $selected_path = '';
if (@selected_paths)
{
if (@selected_paths == 1)
{
$selected_path = "$GBS::ROOT_PATH/$selected_paths[0]";
} else
{
my @menu_item_refs = [ '', '' ];	# Start with 'None'
my $default_item = 0;

foreach my $rel_path (@selected_paths)
{
my $this_path = ($rel_path eq '') ? "$GBS::ROOT_PATH" : "$GBS::ROOT_PATH/$rel_path";
my $path_name = ($rel_path eq '') ? "\$GBS_ROOT_PATH" : "\$GBS_ROOT_PATH/$rel_path";
if (!-d $this_path)
{
$path_name .= ' x';
} elsif (-e "$this_path/$FILE")
{
$path_name .= ' *';
$default_item = @menu_item_refs
if (@menu_item_refs > $default_item);
}
push @menu_item_refs, [ $path_name, $this_path ];
}
$default_item = @menu_item_refs - 1	    # last entry
if ($default_item == 0);







$selected_path = ASK_value_from_menu( "Select $FILE location:", $default_item, undef,
[ @menu_item_refs ],
"Existing files are marked with '*', non-existing directories with 'x'");
ENV_sig( EE => "No $FILE location selected")
if ($selected_path eq '');
}
$FILE_PATH = $selected_path;
$FILE_PATH =~ s!/$!!;
$FILESPEC = "$FILE_PATH/$FILE";

} else
{
ENV_sig( EE => 'No location selected');
}
}






sub do_filespec()
{


(undef, $SUBSYS, $COMPONENT, $SUBDIR, $AUDIT, $BUILD, $TOOL, $ABT_NAME) = FLOC_analyse_path( $FILE_PATH);
if ($FILE_IS_IN_CURRENT_GBS_PATH)
{
my $errors_ref = FLOC_validate_filespec( $FILESPEC);
if (defined $errors_ref)
{
ENV_sig( EE => "Cannot edit '$FILESPEC'", $errors_ref);
}
}
}




sub do_the_edit()
{



if ($FILE_IS_IN_CURRENT_GBS_PATH)
{
if ($IS_GBS_FILE && $FILE_TYPE eq '.usr')
{
ENV_say( 1, 'Checkout for .usr files is disabled in GBS')
if ($MUST_CHECKOUT);
$MUST_CHECKOUT = 0;
} else
{
my ($scm, $avail) = DIRSTRUCT_file_attrib( $FILESPEC);



if ($scm == 0 && $MUST_CHECKOUT)
{
ENV_say( 1, "Checkout of this file(-type) at this location is not allowed by GBS");
$MUST_CHECKOUT = 0;
}
}
} else
{
$MUST_CHECKOUT = 0;
}

if ($MUST_CHECKOUT)
{
GBSSCM_preset( 0);
GBSSCM_connect();
}

my $must_create = 0;
if (!-f $FILESPEC)
{
ENV_say( 1, "File '$FILESPEC' does not exist");
ENV_exit()
if (ASK_YNQ( 'Create?', 'Y', 1) eq 'N');
ENV_say( 1, "Creating '$FILESPEC'...");
$must_create = 1;
} elsif (-z $FILESPEC)
{
ENV_say( 1, "File '$FILESPEC' exists but has zero size");
if (ASK_YNQ( 'Re-Create?', 'Y', 1) eq 'Y')
{
ENV_say( 1, "Re-Creating '$FILESPEC'...");
$must_create = 1;
}
}




if ($must_create && defined $PRE_CREATE_FUNC)
{



$must_create = $PRE_CREATE_FUNC->();
}

if ($must_create)
{



my $environment_ref = [ $GENERIC_FILE_NAME, $SUBSYS, $COMPONENT, $SUBDIR, $AUDIT, $BUILD, $TOOL, $ABT_NAME ];
my $extra_data = (defined $EXTRA_DATA_FUNC) ? $EXTRA_DATA_FUNC->() : undef;
GBSEDIT_create_file( $FILE_PATH, $FILE, $FILE_IS_IN_CURRENT_GBS_PATH, $environment_ref, $extra_data);
}

SCM_assert_co_file( $FILESPEC)
if ($MUST_CHECKOUT);

GBSEDIT_edit_file( $FILESPEC, $EDITOR_OPT, $FILE_IS_IN_CURRENT_GBS_PATH, undef);	# $POST_EDIT_FUNC
}




sub pre_create_abt()
{
my $must_create = 1;



if ($FILE_IS_IN_CURRENT_GBS_PATH)
{
my $abt_type = $GENERIC_FILE_NAME;	    # audit, build or tool
my $current_abt_name = PLUGIN_get_current_name( $abt_type);

$PLUGIN = '';
$PLUGIN = PLUGIN_get_current_plugin( $abt_type)
if ($ABT_NAME eq $current_abt_name);


if ($PLUGIN eq '')
{



my $abt_type_fuc = ucfirst $abt_type;		# E.g.: Build
my @all_plugins = PLG_get_plugin_names( $abt_type, 1);	# $get_all_platforms = 1
my @all_abt_plugins = PLUGIN_get_all_plugin_names( $abt_type);
@all_plugins = LIST_unique( [ @all_plugins, @all_abt_plugins ]);
push @all_plugins, '<Define Own>';
$PLUGIN = ASK_value_from_menu( "Select $abt_type_fuc Plugin", -1, undef, [ @all_plugins ]);
if ($PLUGIN eq '<Define Own>')
{
$PLUGIN = ASK_dir( "Enter $abt_type_fuc Plugin name", '', -1, 0, '');   # $length, $must_exist, $path
}
}
}

return $must_create;    # 1
}




sub pre_create_gbsall()
{
my $must_create = 1;



$GBSALL_IN_SCRIPTS_ROOT = ($FILE_PATH eq $GBS::SCRIPTS_ROOT) ? 0 : 1;

return $must_create;    # 1
}




sub pre_create_flincs_file()
{
my $must_create = 1;



if ($FILE_IS_IN_CURRENT_GBS_PATH)
{




GBSSCM_preset( 0);
GBSSCM_connect();
my $path_state = SCM_get_states( $FILE_PATH, 1); #prevalidated

if ($path_state < 0) 	# -2 = no such file, -1 = not in SCM
{
if ($path_state == -2)  # -2 = no such file
{
ENV_say( 1, "Path does not exist:", "- '$FILE_PATH;");
ENV_exit()
if (ASK_YNQ( 'Create?', 'N', 1) eq 'N');
}
SCM_add_dirs( $FILE_PATH, \&DIRSTRUCT_get_ignore_spec, 0, 0)	    # $pre_validated, $verbose
}
}

return $must_create;    # 1
}




sub pre_create_any()
{
my $must_create = 1;

if ($FILE_IS_IN_CURRENT_GBS_PATH)
{



my @builds = GBSGLO_component_builds( $SUBSYS, $COMPONENT);
my @template_spec_refs = GBSEDIT_get_templates( \@builds, $SUBDIR, $FILE_TYPE);


if (@template_spec_refs)
{



my $template_spec;
if (@template_spec_refs == 1)
{
$template_spec = $template_spec_refs[0]->[1];
} else
{
ENV_say( 1, "Multiple Templates found:");

my @menu_items;
foreach my $ref (@template_spec_refs)
{
my ($nice_name, $template_spec) = @{$ref};
push @menu_items, [ $nice_name, $template_spec ];
}
$template_spec = ASK_value_from_menu( "  Select Template:", 0, undef, [ @menu_items ]);
}
ENV_say( 1, "- Using $template_spec");
$TEMPLATE_SPEC_OR_COMMENT_REF = $template_spec;
} else
{



ENV_say( 1, 'No Template File found:');
my ($begin_com, $end_com, $start_index) = TEMPLATES_get_comment_chars( $FILE_TYPE);
if (defined $begin_com)
{
$TEMPLATE_SPEC_OR_COMMENT_REF = [ $begin_com, $end_com, $start_index ];
} else
{
($begin_com, $end_com, $start_index) = ( '#', '', 0);
$begin_com = ASK_text( '- Enter Begin Comments character(s)', $begin_com, [ 0 , 3 ]);
if ($begin_com ne '')
{
$end_com = ASK_text( '- Enter   End Comments character(s)', $end_com,  [ 0, 3 ]);
$start_index = ASK_int( '- Enter Begin Comments start index ', $start_index,  [ 0, 2 ], [ [ 0, ] ]);
$TEMPLATE_SPEC_OR_COMMENT_REF = [ $begin_com, $end_com, $start_index ];
TEMPLATES_add_comment_chars( $FILE_TYPE, $TEMPLATE_SPEC_OR_COMMENT_REF);
} else
{
$TEMPLATE_SPEC_OR_COMMENT_REF = '';
ENV_say( 1, "Creating empty file...");
}
}
}

} else
{
my ($begin_com, $end_com, $start_index) = TEMPLATES_get_comment_chars( $FILE_TYPE);
if (defined $begin_com)
{
$TEMPLATE_SPEC_OR_COMMENT_REF = [ $begin_com, $end_com, $start_index ];
}
}

return $must_create;    # 1
}


