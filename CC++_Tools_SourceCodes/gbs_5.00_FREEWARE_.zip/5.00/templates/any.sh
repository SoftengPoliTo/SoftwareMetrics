#!/bin/bash
#=================================================
#   File: %FILE%
#   Path: %PATH%
#=================================================

#set -v -x	# debuging

rc=0

echo "%UC_FILE_NAME%: Executing %FILE%..."
rc=$?

exit $rc
###EOF###
