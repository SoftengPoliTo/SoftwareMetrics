#=================================================
#
#   notify.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*NOTIFY @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::args;
use glo::ask;
use glo::slurp;
use mod::gbsenv;
use mod::run;
use mod::notify;




sub get_command_args();








my ($JOB,
$JOB_RC,
$LOG_FILE_SPEC,
$JOB_STATE);







$| = 1;           # $OUTPUT_AUTOFLUSH

GBSENV_init( undef);

{
get_command_args();





my @lines = NOTIFY_get_lines( $JOB, $JOB_RC, $LOG_FILE_SPEC, $JOB_STATE);
ENV_say( 0, @lines);




my $default_ans = ($JOB_RC == 0) ? 'N' : 'Y';
if (ASK_YN( "View Log & Exit", $default_ans) eq 'Y')
{
if (-e $LOG_FILE_SPEC)
{
if (RUN_viewer( $LOG_FILE_SPEC))
{
sleep 1;	    # give system (lunix) time to start vieuwer
}
} else
{
ENV_sig( E => "Logfile: $LOG_FILE_SPEC", "does not exist");
ASK_pause( 'Quitting...');
}
}
}






END
{
ENV_print_end_msg(0);
}




sub get_command_args()
{


($JOB,
$JOB_RC,
$LOG_FILE_SPEC,
$JOB_STATE) = ARGS_get( [1,4], 'notify.pl [ <job> | test ] <job_rc> <log_filespec> <job_end>', undef);
if ($JOB eq 'test')
{
$JOB_RC = 0
if (!defined $JOB_RC);
if (!defined $LOG_FILE_SPEC)
{
($LOG_FILE_SPEC) = SLURP_dir_file_paths( $GBS::LOG_PATH, 0);		# get first logfile
$LOG_FILE_SPEC = "$GBS::LOG_PATH/gbssysaudit_test_2003-243.log"
if (!defined $LOG_FILE_SPEC);
}
$JOB_STATE = ($JOB_RC == 0) ? 'NORMAL' : 'FAILED'
if (!defined $JOB_STATE);
} else
{
ARGS_fatal( "4 Arguments expected (@ARGV)")
if (@ARGV != 4);
}
}


