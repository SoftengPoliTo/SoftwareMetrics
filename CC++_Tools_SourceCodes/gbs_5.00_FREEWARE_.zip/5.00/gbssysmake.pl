#=================================================
#
#   gbssysmake.pl
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
use strict;
use warnings FATAL => 'all';
use integer;
CORE::say( "*GBSSYSMAKE @ARGV") if ($ENV{GBSDEBUG_FILE});




use lib $ENV{GBS_SCRIPTS_PATH};
use glo::env;
use glo::genopt;
use mod::gbsenv;
use mod::gbsoptenv;
use mod::validate;
use mod::gbssys;














$| = 1;           # $OUTPUT_AUTOFLUSH
my $RC = 0;
GBSENV_init( 'build');













{
my @genopts = (
[ '<*>',    'steps',	      'sao',      "", "Steps and/or Aliases. <empty> == all select steps, 'ALL' == force all steps, '?' == show steps" ],
[ 'i',      'ignore_errors',  'bso',       0, "Continue generation after error(s)" ],
[ 'smm',    'start_makemake', 'bso',       1, "Pre-generate the make-file" ],
[ 'mm',     'run_makemake',   'bso',       1, "Run 'gbsmakemake' on completion of Full GBS SubSystems" ],
[ 'export', 'run_export',     'bso',       1, "Run 'gbsexport' on completion" ],
[ 'builds',  'builds',	      "saos.,$GBS::BUILDS", '*', "(wild-)Builds to Build. '' or '*' == All, '.' == Current" ],
[ 'files',   'files',	      'sao', '*:*.*', "Files to make" ],
[ 'fg',      'foreground',    'bso',       0, "Runs in the foreground if set" ],
[ 'at',      'delay',	      'tso',   "now", "Starting time (10:20), delta (+10:10) or now" ],
[ 'sm',      'mail',	      'bso',       0, "Send mail on completion" ],
[ 'n',       'notify',	      'bso',       1, "Notify user on completion (bg/nowait only)" ],
[ 'wait',    'wait',          'bso',       0, "Wait for completion of bg jobs" ],
[ 'jobs',    'jobs',     'isor1..9',       2, 'Max nr parallel jobs within a submitted job' ],
[ 'c',	 'comment',	      'sso',      "", 'Comments - will be shown in Summary - Specify %20 for space' ],
);
my @genconflicts = (
[ [ fg   => 1 ], '=' => 'at', '=' => 'sm', '=' => 'n' ],
[ [ wait => 1 ], '=' => 'n' ],
);
my @genenvs = qw( LOG_PATH DEBUGGER MODE OPT MAP FLAGS_* APP_* );
GENOPT_set_optdefs( 'gbssysmake', \@genopts,
"Generate part of or whole System using 'make'",
undef);
GENOPT_set_conflicts( \@genconflicts);
GENOPT_set_envdefs( \&GBSOPTENV_set, \&GBSOPTENV_print, \@genenvs);
GENOPT_parse();
}
my @STEPS = GENOPT_get( 'steps');
my $IGNORE_ERRORS = GENOPT_get( 'ignore_errors');
my $START_MAKEMAKE = GENOPT_get( 'start_makemake');	## noperlcheck
my $RUN_MAKEMAKE = GENOPT_get( 'run_makemake');		## noperlcheck
my $RUN_EXPORT = GENOPT_get( 'run_export');		## noperlcheck
my @BUILDS = GENOPT_get( 'builds');
my @FILES = GENOPT_get( 'files');
my $FOREGROUND = GENOPT_get( 'foreground');
my $DELAY = GENOPT_get( 'delay');
my $MAIL = GENOPT_get( 'mail');
my $NOTIFY = GENOPT_get( 'notify');
my $WAIT = GENOPT_get( 'wait');
my $JOBS = GENOPT_get( 'jobs');				## noperlcheck
my $COMMENT = GENOPT_get( 'comment');




$NOTIFY = 0
if ($WAIT);

{



VALIDATE_root();




GBSSYS_init(
'make',
$IGNORE_ERRORS,
\@BUILDS,
undef,		# $audits_ref
\@FILES,
$FOREGROUND,
[ $DELAY, $MAIL, $NOTIFY, $COMMENT ],
$WAIT,
);




my @excludes = qw( steps builds files delay wait comment foreground );
my @opts = GENOPT_get_changed( \@excludes );

$RC = GBSSYS_submit( \@STEPS, \@opts);
}




ENV_exit( $RC);




END
{
ENV_print_end_msg( 1);
}


