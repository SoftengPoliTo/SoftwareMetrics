#=================================================
#
#   templates.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::templates;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
TEMPLATES_reset
TEMPLATES_get_gbs
TEMPLATES_find_by_type
TEMPLATES_find_all_by_path
TEMPLATES_get_path
TEMPLATES_get_comment_chars
TEMPLATES_add_comment_chars
);
}




use glo::env;
use glo::slurp;
use glo::spit;
use glo::scm;
use mod::fspec;
use mod::fcreate;




sub TEMPLATES_reset();
sub TEMPLATES_get_gbs($;$);
sub TEMPLATES_find_by_type($);
sub TEMPLATES_find_all_by_path($);
sub TEMPLATES_get_path($);
sub TEMPLATES_get_comment_chars($);
sub TEMPLATES_add_comment_chars($$);

sub init_templates();








my $GBS_SCRIPTS_TEMPLATE_PATH = "$GBS::SCRIPTS_PATH/templates";		# GBS defined
my $GBS_SYS_TEMPLATES_PATH = "$GBS::SYS_PATH/templates";		# User defined

my (undef, $COMMENT_CHARS_FILE) = FSPEC_comment_chars( $GBS::ROOT_PATH);	# = 'comment_chars.gbs';


my @GBS_COMMENT_CHARS = (



'.asm'    => [ ';'        ],	    # Assembler
'.bat'    => [ '::'       ],	    # DOS Batchfile
'.c'      => [ '/*', '*/' ],	    # C
'.cpp'    => [ '//'       ],	    # C++
'.cmd'    => [ '::'       ],	    # Windows NT Batchfile
'.cs'     => [ '//'	      ],	    # C-sharp
'.css'    => [ '/*', '*/' ],	    # Cascading Style Sheets
'.d'      => [ '//'       ],	    # D
'.for'    => [ 'C', '', 0 ],	    # Fortran
'.f90'    => [ '!'	      ],	    # Fortran 90
'.gbs'    => [ '#'        ],	    # GBS
'.h'      => [ '/*', '*/' ],	    # C headerfile
'.hpp'    => [ '//'       ],	    # C++ headerfile
'.ini'    => [ ';'        ],	    # .ini file
'.inc'    => [ '//'	      ],	    # C/C++, Pascal, Java, PHP and more
'.java'   => [ '//'	      ],	    # Java
'.js'     => [ '//'	      ],	    # JavaScript, JScript
'.l'      => [ '/*', '*/' ],	    # Lex
'.lisp'   => [ ";"	      ],	    # Lisp
'.mk'     => [ '#'        ],	    # Makefile
'.php'    => [ '#'        ],	    # PHP
'.pl'     => [ '#'        ],	    # Perl
'.pm'     => [ '#'        ],	    # Perl
'.ps'     => [ '%'        ],	    # PostScript
'.ps1'    => [ '#'        ],	    # Windows PowerShell
'.py'     => [ '#'        ],	    # Python
'.rb'     => [ '#'        ],	    # Ruby
'.s'      => [ ';'        ],	    # Assembler (Unix)
'.sh'     => [ '#'        ],	    # Bash, Korn & C Script
'.sql'    => [ '--'	      ],	    # SQL
'.tcl'    => [ '#'        ],	    # Tcl
'.vbs'    => [ "'"	      ],	    # Visual Basic Script
'.y'      => [ '/*', '*/' ],	    # yacc

'.cob'    => [ '*',    '',    6 ],	    # COBOL
'.html'   => [ '<!--', '-->'    ],	    # HTML
'.xml'    => [ '<!--', '-->'    ],	    # XML
);




my @TEMPLATES_PATHS = (	# user = 0, shared = 1 (may be undef), GBS = 2
$GBS_SYS_TEMPLATES_PATH,		# User
undef,				# Shared (filled runtime)
$GBS_SCRIPTS_TEMPLATE_PATH		# GBS
);

my %TEMPLATES;

my %TEMPLATES_BY_TYPE;


my %COMMENT_CHARS;





sub TEMPLATES_reset()
{
init_templates();
}




sub TEMPLATES_get_gbs($;$)
{
my ($file,		# $name.gbs, $name.bat, $name.sh, Makefile.mk
$sig_on_error,	# Optional: undef, '', 'EE', etc. Default: ''
) = @_;
my $template_spec;



$sig_on_error = ''
if (!defined $sig_on_error);

$template_spec = "$GBS_SCRIPTS_TEMPLATE_PATH/$file";

if (!-e $template_spec)
{
if ($sig_on_error eq '')
{
ENV_whisper( 1, "No GBS Template file '$template_spec' for '$file'");
} else
{
ENV_sig( $sig_on_error, "GBS Template file '$template_spec' ($file) does not exist")
}
$template_spec = "$GBS_SCRIPTS_TEMPLATE_PATH/any.gbs";
}

return $template_spec;
}




sub TEMPLATES_find_by_type($)
{
my ($filetypes_or_ref,	# [ $primary_filetype, $sec_filetype ] secondary = from BUILD.GBS
) = @_;
my @anyfile_spec_refs;	# [ $nice_name, $anyfile_spec ]

my @any_types = (ref $filetypes_or_ref) ? @{$filetypes_or_ref} : $filetypes_or_ref;


init_templates()
if (!%TEMPLATES);

foreach my $type (@any_types)
{
my $template_refs_ref = $TEMPLATES_BY_TYPE{$type};
if (defined $template_refs_ref)
{
foreach my $ref (@{$template_refs_ref})
{
my ($file_name, undef, $first_path_index) = @{$ref};
my $nice_name = "$file_name$type";
$nice_name =~ s/any_//;
my $template_spec = "$TEMPLATES_PATHS[$first_path_index]/$file_name$type";
push @anyfile_spec_refs, [ $nice_name, $template_spec ];
}
last;	    # no need to search secondary files if at least one primary found
}
}



return (wantarray) ? @anyfile_spec_refs : $anyfile_spec_refs[0];
}





sub TEMPLATES_find_all_by_path($)
{
my ($search_path_index,	# 0 = User path, 1 = Shared path, 2 = GBS path
) = @_;
my @type_template_files;

init_templates()
if (!%TEMPLATES);

foreach my $type (sort keys %TEMPLATES_BY_TYPE)
{
my @template_refs;
foreach my $ref (@{$TEMPLATES_BY_TYPE{$type}})
{
my ($file_name, undef, @path_indexes) = @{$ref};
if (grep( $_ eq $search_path_index, @path_indexes))
{
push @type_template_files, "$file_name$type";
}
}
}



return @type_template_files;
}




sub TEMPLATES_get_path($)
{
my ($search_path_index,	# 0 = User path, 1 = Shared path (may be undef), 2 = GBS path
) = @_;


init_templates()
if (!%TEMPLATES);

return $TEMPLATES_PATHS[$search_path_index];
}





sub TEMPLATES_get_comment_chars($)
{
my ($file_type,
) = @_;
my ($begin_com, $end_com, $start_index);

init_templates()
if (!%TEMPLATES);

my $ref = $COMMENT_CHARS{$file_type};
if (defined $ref)
{
($begin_com, $end_com, $start_index) = @{$ref};
$end_com = ''
if (!defined $end_com);
$start_index = 0
if (!defined $start_index);
}

return ($begin_com, $end_com, $start_index);
}




sub TEMPLATES_add_comment_chars($$)
{
my ($file_type,
$comments_ref,	# [ $begin_com, $end_com, $start_index ]
) = @_;

init_templates()
if (!%TEMPLATES);

$COMMENT_CHARS{$file_type} = [ @{$comments_ref} ];	# clone






{
my $filespec = FSPEC_comment_chars( $GBS::ROOT_PATH);
FCREATE_comment_chars( $GBS::ROOT_PATH)
if (!-e $filespec);
my @lines = SLURP_file( $filespec);

my $last_line;
$last_line = pop @lines
if (substr( $lines[-1], 0, 1) eq '#');	    # '###EOF###' line

my $line_format = '%-7.7s,%-6.6s,%-6.6s,%-3.3s, %s';
my $found = 0;
foreach my $line (@lines)
{
next
if ($line eq '' || substr( $line, 0, 1) eq '#');
my ($this_type, $begin_com, $end_com, $start_index, @comments) = split( /\s*,\s*/, $line);
if ($this_type eq $file_type)
{
$begin_com = $comments_ref->[0];
$end_com = $comments_ref->[1];
$start_index = $comments_ref->[2];
$line = sprintf( $line_format, $this_type, $begin_com, $end_com, $start_index, "@comments");
$found = 1;
last;
}
}
if (!$found)
{
my ($begin_com, $end_com, $start_index) = @{$comments_ref};
my @comments = ();
my $line = sprintf( $line_format, $file_type, $begin_com, $end_com, $start_index, "@comments");
push @lines, $line;
}
if (defined $last_line)
{
push @lines, $last_line;
} else
{
push @lines, '###EOF###';
}




SCM_assert_co_file( $filespec);
SPIT_file_nl( $filespec, \@lines);
}
}




sub init_templates()
{
%TEMPLATES = ();
%TEMPLATES_BY_TYPE = ();
%COMMENT_CHARS = ();





{
my $gbs_templates_path = ENV_getenv_perl_path( 'GBS_TEMPLATES_PATH');	# Shared-defined
if ($gbs_templates_path ne '')
{
if (!-d $gbs_templates_path)
{
ENV_sig( E => 'The directory referred to by GBS_TEMPLATES_PATH does not exist',
"- $gbs_templates_path");
$gbs_templates_path = '';
}
}
$TEMPLATES_PATHS[1] = ($gbs_templates_path ne '') ? $gbs_templates_path : undef;    # Shared
}





%COMMENT_CHARS = @GBS_COMMENT_CHARS;
foreach my $path_index (reverse 0..2)
{
my $path = $TEMPLATES_PATHS[$path_index];
if (defined $path)
{
foreach my $file (SLURP_dir_files( $path, 0))
{
if (substr( $file, 0, 3) eq 'any')
{



my $ref = $TEMPLATES{$file};
if (defined $ref)
{
push @{$ref}, $path_index;
} else
{
my ($name, $type) = ENV_split_spec_nt( $file);
$ref = [ $name, $type, $path_index ];
$TEMPLATES{$file} = $ref;
if ($name =~ /^any(_.+|$)/)
{
push @{$TEMPLATES_BY_TYPE{$type}}, $ref;
}
}
} elsif ($file eq $COMMENT_CHARS_FILE)
{




foreach my $line (SLURP_file_full( "$path/$file", '^#', undef))
{
my ($type, $begin_com, $end_com, $start_index, @comments) = split( /\s*,\s*/, $line);
$COMMENT_CHARS{$type} = [ $begin_com, $end_com, $start_index ];
}
} else
{

}
}
}
}




}

1;

