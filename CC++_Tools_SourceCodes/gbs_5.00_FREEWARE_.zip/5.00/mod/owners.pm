#=================================================
#
#   owners.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package mod::owners;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
OWNERS_read
OWNERS_maintenance
);
}




use glo::env;
use glo::list;
use glo::spit;
use glo::ask;
use glo::format;
use glo::scm;
use mod::gbsglo;
use mod::gbsscm;
use mod::gbsfile;
use mod::fspec;
use mod::run;




sub OWNERS_read();
sub OWNERS_maintenance($$$);

sub sync_file($$$);
sub list_users($$$);
sub add_users($$$);
sub add_user();
sub list_items($$$);
sub prepare_items();
sub edit($$$);
sub find($$$);
sub read_file($);
sub write_file();
sub file_lines();
sub print_list(@);




my $OWNERS_FILE = FSPEC_owners( 'owners', $GBS::ROOT_PATH);

my %ITEMS;


my @ITEMS_HEAD_S = ( 'SubSystem', 'Component', 'UserId');
my @ITEMS_HEAD_L = ( @ITEMS_HEAD_S, 'Email', 'Phone', 'Owner-Name' );

my %USERS;


my @USERS_HEAD = ( 'UserId', 'Email', 'Phone', 'Owner-Name' );

my $FILE_READ = 0;
my $FILE_CHANGED = 0;




sub OWNERS_read()
{
read_file( $OWNERS_FILE);
}










sub OWNERS_maintenance($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref,
) = @_;

if (-f $OWNERS_FILE)
{
read_file( $OWNERS_FILE);
} else
{
ENV_say( 1, "Creating new file");
add_users( undef, undef, undef);
write_file();
sync_file( undef, undef, undef);
}

my @menu_items = (
[ "List Owners",				    \&list_users ],
[ "List SubSystems/Components",		    \&list_items ],
[ "Find item",					    \&find ],
[ "Add Owners",				    \&add_users ],
[ "Synchronise with actual SubSystems/Components", \&sync_file ],
[ "Edit file",					    \&edit ],
);

ASK_menu( "Select function to perform", \@menu_items, $entries_ref);

if ($FILE_CHANGED)
{
ENV_say( 1, "File modified");
if (ASK_YN( "Commit changes?", 'Y') eq 'Y')
{
write_file() ;
}
}
%ITEMS = ();
%USERS = ();
$FILE_READ = 0;
}




sub sync_file($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;

if (%ITEMS)
{



ENV_say( 1, "Validating existing entries...");
my $count = 0;
foreach my $ref (values %ITEMS)
{
my ($subsys, $component) = @{$ref};
my $match;
if ($component eq '-')
{
$match = "$GBS::ROOT_PATH/dev/$subsys";
} else
{
$match = "$GBS::ROOT_PATH/dev/$subsys/comp/$component";
}
if (! -d $match)
{
my $key = "$subsys:$component";
ENV_say( 1, "- Removed $key");
ENV_sig( F => "Cannot delete key '$key'") if (!delete $ITEMS{$key});
$count++;
$FILE_CHANGED = 1;
}
}
ENV_say( 1, "$count line(s) removed")
if ($count > 0);
}




ENV_say( 1, "Searching for new entries...");

my @key_refs;

foreach my $subsys (@GBS::ALL_SUBSYSTEMS)
{
push @key_refs, [ $subsys, '-' ];
if (GBSGLO_subsystem_is_full_gbs( $subsys))
{
foreach my $comp (GBSGLO_components( $subsys))
{
push @key_refs, [ $subsys, $comp ];
}
}
}

my $count = 0;
foreach my $ref (@key_refs)
{
my ($subsys, $component) = @{$ref};
my $key = "$subsys:$component";
if (!exists $ITEMS{$key})
{
$ITEMS{$key} = [ $subsys, $component, '', ];    # $subsys $component $user_id
$FILE_CHANGED = 1;
ENV_say( 1, "- Added $key");
$count ++;
}
}
ENV_say( 1, "$count/" . (scalar keys %ITEMS) . " Added")
if ($count > 0);

my $user_id = '';
foreach my $key (sort keys %ITEMS)
{
if ($ITEMS{$key}->[2] eq '')
{
if ($user_id eq '')
{
ENV_sig( W => "Some entries are not complete",
"Please add the Owners (User-id) to the entries",
"To quit enter a single space");
}
my ($subsys, $comp) = @{$ITEMS{$key}};
ENV_say( 0, '-');
ENV_say( 1, "Incomplete: $subsys : $comp");
my @user_ids = sort keys %USERS;
my $default_index;
if (@user_ids == 0)
{
$default_index = 1; 	# New
} elsif (@user_ids == 1)
{
$default_index = 2; 	# First and Only
} else
{
$default_index = LIST_firstidx_str( $user_id, \@user_ids);
$default_index += 2 if ($default_index >= 0);
}
unshift @user_ids, ('-End processing', '-Add Owner');
my $index = ASK_index_from_menu( '- Userid', $default_index, undef, [ @user_ids ]);

if ($index == 0)
{
last;
} elsif ($index == 1)
{
$user_id = add_user();
} else
{
$user_id = $user_ids[$index];
}
if ($user_id ne '')
{
$ITEMS{$key}->[2] = $user_id;	# $user_id
}
}
}
}




sub list_users($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;

if (scalar %USERS)
{
my @refs = ( \@USERS_HEAD, map { $USERS{$_ }} sort keys %USERS );
my @lines = FORMAT_table( 0, 1, '  ', undef, @refs);


print_list( @lines);
} else
{
ENV_say( 1, "No Owners defined");
}
}




sub add_users($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;

while ( add_user() ) {};
}




sub add_user()
{
my $user_id;

my @users = sort keys %USERS;
$user_id =          ASK_not_word( "New Owner  Userid", '', 0, \@users);
if ($user_id ne '')
{
my $email =         ASK_text( "* New Owner Email", '', 0);
if ($email ne '')
{
my $phone =     ASK_text( "* New Owner Phone", '', -1);
my $user_name = ASK_text( "* New Owner  Name", '', 0);
if ($user_name ne '')
{
$USERS{$user_id} = [$user_id, $email, $phone, $user_name ];
$FILE_CHANGED = 1;
ENV_say( 1, "Owner Added");
} else
{
$user_id = '';
ENV_say( 1, "Owner NOT Added");
}
} else
{
$user_id = '';
ENV_say( 1, "Owner NOT Added");
}
}

return $user_id;
}




sub list_items($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;

if (scalar %ITEMS)
{
my @lines = prepare_items();
print_list( @lines);
} else
{
ENV_say( 1, "No SubSystems/Components defined");
}
}




sub prepare_items()
{
my @lines;

my @refs;
push @refs, \@ITEMS_HEAD_L;

foreach my $key (sort keys %ITEMS)
{
my @i_values = @{$ITEMS{$key}};
my $user_id = $i_values[2];
my @u_values;
if ($user_id ne '' && exists $USERS{$user_id})
{
@u_values = @{$USERS{$user_id}};
shift @u_values;
} else
{
@u_values = ('', '', '');
}
push @refs, [ @i_values, @u_values ];
}
@lines = FORMAT_table( 0, 1, '  ', undef, @refs);

return @lines;
}




sub edit($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;

if (-f $OWNERS_FILE)
{



ENV_say( 1, "Writing tmp file...");
my @lines = file_lines();
my $temp_file = SPIT_tmp_file_nl( 'owners.gbs', \@lines );




ENV_say( 1, "Editing tmp file '$temp_file'...");
if (RUN_editor( $temp_file, undef))
{



ENV_say( 1, "Go to the Editor and implement changes. Then continue here");




if (ASK_YN( "Accept changes from tmp file?", 'Y') eq 'Y')
{
$FILE_READ = 0;
read_file( $temp_file);
$FILE_CHANGED = 1;
}
}
unlink $temp_file;
} else
{
ENV_say( 1, "The Owners file does not exist, please create it");
}
}




sub find($$$)
{
my ($menu_entry,
$data_ref,
$entries_ref) = @_;

if (scalar %ITEMS)
{
my @lines = prepare_items();

my $header = shift @lines;
my $item;
do
{
$item = ASK_text( "Item (SubSys, Component, UserId, etc) to find", "", 0);
if ($item ne "")
{
if (substr($item, 0, 1) eq '/')
{
$item = substr( $item, 1);
} else
{
$item = quotemeta $item;
}
my @finds = grep /$item/, @lines;
print_list( $header, @finds);
}
} while ($item ne "");
} else
{
ENV_sig( W => "No data in the Owners file");
}
}




sub read_file($)
{
my ($owners_file) = @_;

if (!$FILE_READ)
{
ENV_say( 1, "Reading file...");
GBSFILE_open( $owners_file, 1, undef, 0);
$FILE_READ = 1;
%ITEMS = ();
%USERS = ();




my $line = GBSFILE_get_line();
while ($line)
{

my $fc = substr( $line, 0, 1);
if ($fc eq '+')
{
my ($user_id, $email, $phone, $user_name) = split( ' ', substr( $line, 2), 4);
$USERS{$user_id} = [ $user_id, $email, $phone, $user_name ];
} elsif ($fc eq '=')
{
my ($subsys, $comp, $user_id) = split( ' ', substr( $line, 2));
if (defined $user_id)
{
if (!exists $USERS{$user_id})
{
GBSFILE_sig( W => "Unknown User-Id '$user_id'. Please repair");
}
} else
{
$user_id = '';
}
$ITEMS{"${subsys}:$comp"} = [ $subsys, $comp, $user_id ];
} elsif ($fc eq '*')
{
;	# Comments
} else
{
GBSFILE_sig( E => "Invalid line (does not start with '+', '=' or '*')");
}
$line = GBSFILE_get_line();
}
my $nr_users = keys %USERS;
my $nr_items = keys %ITEMS;
ENV_say( 1, "Read: $nr_users User(s) and $nr_items SubSystem/Component(s)");

}
}




sub write_file()
{
if (-f $OWNERS_FILE)
{
ENV_say( 1, "Saving old file...");
ENV_backup_file( $OWNERS_FILE, '.sav', 'E');
}

GBSSCM_preset( 0);

ENV_say( 1, "Writing file...");
my @lines = file_lines();
SCM_store_file( $OWNERS_FILE, \@lines);

$FILE_CHANGED = 0;
}




sub file_lines()
{
my @lines;

push @lines, '#';
push @lines, "#   OWNERS.GBS [$GBS::SYSTEM_NAME]";
push @lines, '#';

{
my @refs = sort { $a->[0] cmp $b->[0] } values %USERS;
my @t_lines = FORMAT_table( undef, 0, '  ', undef, (\@USERS_HEAD, @refs));
foreach my $t_line(@t_lines)
{
$t_line = "+ $t_line";
}
substr( $t_lines[0], 0, 1) = '*';
push @lines, @t_lines;
}

{
push @lines, '';
my @refs = sort { $a->[0] cmp $b->[0] } values %ITEMS;
my @t_lines = FORMAT_table( undef, 0, '  ', undef, (\@ITEMS_HEAD_S, @refs));
foreach my $t_line(@t_lines)
{
$t_line = "= $t_line";
}
substr( $t_lines[0], 0, 1) = '*';
push @lines, @t_lines;
}

push @lines, '##EOF##';

return @lines;
}




sub print_list(@)
{
my ($header,
@lines
) = @_;

ASK_more( 1, $header, \@lines);
}

1;
