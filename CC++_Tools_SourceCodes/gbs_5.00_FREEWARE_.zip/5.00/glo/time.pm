#=================================================
#
#   time.pm
#
#=================================================
#   This file is a part of the GBS (Generic Build Support)
#   package created by Randy Marques, Netherlands
#   For information: http://www.genericbuildsupport.com
#   Copyright � 2015-2025 - Randy Marques - All rights reserved
#=================================================
package glo::time;

use strict;
use warnings FATAL => 'all';
use integer;

BEGIN
{
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
TIME_num2time
TIME_time2num
TIME_time2numdate
TIME_time2num_packed
TIME_date2num_packed
TIME_unpack
TIME_unpack_date
TIME_pack
TIME_deltatime2num
);
}




use Time::Local;
use glo::env;




sub TIME_num2time($);
sub TIME_time2num(;$);
sub TIME_time2numdate(;$);
sub TIME_time2num_packed(;$);
sub TIME_date2num_packed(;$);
sub TIME_unpack($);
sub TIME_unpack_date($);
sub TIME_pack($);
sub TIME_deltatime2num($);







































sub TIME_num2time($)
{
my ($num) = @_;
my $time;

if ($num =~ /^0000-00-00/)
{
$time = 0;
} else
{
my ($year, $month, $day, $hour, $min, $sec) = (0,0,0,0,0,0);
if (length( $num) == 10)
{
($year, $month, $day) = ($num =~ /(\d\d\d\d)-(\d\d)-(\d\d)/);
} else
{
($year, $month, $day, $hour, $min, $sec) = ($num =~ /(\d\d\d\d)-(\d\d)-(\d\d) (\d\d):(\d\d):(\d\d)/);
}
$time = timelocal( $sec, $min, $hour, $day, $month - 1, $year);
}

return $time;
}








sub TIME_time2num(;$)
{
my ($time) = @_;
my @thistime = (defined $time) ? localtime( $time) : localtime;

return sprintf "%4d-%02d-%02d %02d:%02d:%02d",
$thistime[5] + 1900, $thistime[4] + 1,$thistime[3],
$thistime[2], $thistime[1], $thistime[0];
}








sub TIME_time2numdate(;$)
{
my ($time) = @_;
my @thistime = (defined $time) ? localtime( $time) : localtime;

return sprintf "%4d-%02d-%02d",
$thistime[5] + 1900, $thistime[4] + 1,$thistime[3];
}








sub TIME_time2num_packed(;$)
{
my ($time) = @_;
my @thistime = (defined $time) ? localtime( $time) : localtime;

return sprintf "%04d%02d%02d-%02d%02d%02d",
$thistime[5] + 1900, $thistime[4] + 1,$thistime[3],
$thistime[2], $thistime[1], $thistime[0];
}








sub TIME_date2num_packed(;$)
{
my ($time) = @_;
my @thistime = (defined $time) ? localtime( $time) : localtime;

return sprintf "%04d%02d%02d",
$thistime[5] + 1900, $thistime[4] + 1,$thistime[3];
}














sub TIME_unpack($)
{
my ($packed_time) = @_;


my $length = length( $packed_time);

if ($length == 6)
{
my ($hh, $mm, $ss) = $packed_time =~ /(\d\d)(\d\d)(\d\d)/;

return sprintf "%02d:%02d:%02d",
$hh, $mm, $ss;
} elsif ($length == 8)
{
my ($YYYY, $MM, $DD) = $packed_time =~ /(\d\d\d\d)(\d\d)(\d\d)/;

return sprintf "%4d-%02d-%02d",
$YYYY, $MM, $DD;
} elsif ($length == 13)
{
my ($YY, $MM, $DD, $hh, $mm, $ss) = $packed_time =~ /(\d\d)(\d\d)(\d\d)-(\d\d)(\d\d)(\d\d)/;

return sprintf "%4d-%02d-%02d %02d:%02d:%02d",
$YY + 2000, $MM, $DD, $hh, $mm, $ss;
} elsif ($length == 15)
{
my ($YYYY, $MM, $DD, $hh, $mm, $ss) = $packed_time =~ /(\d\d\d\d)(\d\d)(\d\d)-(\d\d)(\d\d)(\d\d)/;

return sprintf "%4d-%02d-%02d %02d:%02d:%02d",
$YYYY, $MM, $DD, $hh, $mm, $ss;
} else
{
ENV_sig( F => "Invalid date/time length for '$packed_time'");
}
}











sub TIME_unpack_date($)
{
my ($packed_time) = @_;


my $length = length( $packed_time);

if ($length == 6)	# hhmmss
{
ENV_sig( F => "Cannot unpack date for time ($packed_time)");
} else
{
return substr( TIME_unpack( $packed_time), 0, 10);
}
}














sub TIME_pack($)
{
my ($unpacked_time) = @_;
my $numtime = $unpacked_time;

my $unpacked_length = length( $unpacked_time);
if ($unpacked_length == 8)
{
$numtime =~ s/://g;
} elsif ($unpacked_length == 10)
{
$numtime =~ s/-//g;
} elsif ($unpacked_length == 19)
{
$numtime =~ s/://g;
$numtime =~ s/-//g;
$numtime =~ s/ /-/g;
} else
{
ENV_sig( F => "Invalid unpacked time format '$unpacked_time",
'Must be hh:mm:ss, YYYY-MM-DD or YYYY-MM-DD hh:mm:ss');
}

return $numtime;
}







sub TIME_deltatime2num($)
{
my ($diff_time) = @_;	    # nr-seconds

my $sec = $diff_time % 60;
my $min = $diff_time / 60;
my $hours = $min / 60;
$min = $min % 60;

return sprintf "%03d:%02d:%02d", $hours, $min, $sec;
}

1;
